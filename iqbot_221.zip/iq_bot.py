# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "3.0"
BUILD_BOT = 221

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": False,       # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT · Nueva actualización",
    "subtitulo": "Lo nuevo de esta actualización",
    "desde": 215,          # quien ya lo vio en la versión 215 o después no lo vuelve a ver
    "para_nuevos": True,   # quien instala el bot por primera vez lo ve una vez (aunque esta versión no muestre aviso)
    "items": [
        ["🧩", "Nuevo apartado Estrategias", "Elige las que quieras: una sola opera como siempre; varias (Auto), todas dan señal y entra cada vez que una pasa tus filtros."],
        ["📚", "Más de 100 estrategias nuevas", "Patrones de velas, ciclos (MHI, Torres Gemelas…), osciladores, tendencia y niveles. Ya vienen todas elegidas."],
        ["🏆", "Ves con qué estrategia ganaste", "Cada resultado muestra la estrategia y su dibujo."],
        ["🎯", "Bollinger + RSI anticipado", "Entra cuando el precio se estira fuera de la banda, antes del cierre. Tú decides cuánto se estira y cuánto retrocede."],
        ["✏️", "Edita cada estrategia", "Toca «Editar» para cambiar periodos, niveles y el modo anticipado."],
        ["✝️", "Una palabra de Dios para ti", "Cada vez que entras, una promesa o un versículo diferente."],
    ],
    "aviso": "Prueba primero en DEMO. Ninguna estrategia garantiza ganancias.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [2],           # manual: una temporalidad de 2 a 5 minutos (M1 ya no se usa)
    "tf_auto": False,                # ya no hay temporalidad Auto: una sola, de M1 a M5
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia · "perdida" (solo el autor) = solo lo perdido
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 12,                  # 12: todas las estrategias elegidas por defecto
    "estrategia": "bbrsi",           # "bbrsi" (Bollinger + RSI, para todos) o "mhi" (solo el autor, en prueba)
    "mhi_modelo": "mhi1_min",        # solo el autor: mhi1/mhi2/mhi3/millon + _min (minoría) o _may (mayoría)
    "rsi_periodo": 2,                # "rsi" (para todos): periodo del RSI
    "rsi_alto": 60,                  # cruza hacia arriba este nivel -> CALL (a favor)
    "rsi_bajo": 40,                  # cruza hacia abajo este nivel -> PUT (a favor)
    "rsi_modo": "favor",             # "favor" (sigue el cruce) o "contra" (al revés)
    "boll_periodo": 20,              # "boll" (solo el autor): Bollinger sola
    "boll_dev": 2.0,
    "bbrsi_momento": "cierre",       # Bollinger + RSI: "cierre" o "anticipado" (para todos)
    "bbrsi_manual": False,           # True: usa los valores editados abajo en vez de los recomendados por temporalidad
    "bbrsi_per": 20, "bbrsi_dev": 2.0, "bbrsi_rp": 14, "bbrsi_alto": 75, "bbrsi_bajo": 25,
    "estrategias_on": "todas",       # apartado Estrategias: las elegidas ("todas", o lista de "bbrsi", "boll", "rsi" y nombres del catálogo)
    "multi_min_acierto": 55,         # con varias prendidas: acierto mínimo a la 1ª (%)
    "multi_min_senales": 150,        # ... y señales mínimas medidas en ese par
    "ant_estiron": 10,               # anticipado: el precio debe salir de la banda al menos este % del ancho media→banda
    "ant_retro_min": 25,             # anticipado: entra cuando retrocede desde este % de lo que se estiró...
    "ant_retro_max": 35,             # ... y hasta este % (si ya retrocedió más, no persigue)
    "ant_desde": 30,                 # anticipado: mira desde estos segundos antes del cierre...
    "ant_hasta": 20,                 # ... hasta estos segundos antes del cierre (después ya no entra)
    "ant_directo": 0,                # si se estira más de este % entra sin esperar retroceso (0 = apagado)       # BB + RSI (solo el autor): "cierre" o "anticipado" (se estira y retrocede, en prueba)
    "boll_momento": "cierre",        # "cierre" (la vela cierra fuera) o "anticipado" (se estira y retrocede, hasta 30 s antes)
    "boll_dir": "regresa",           # "regresa" (contra el estirón) o "sigue" (a favor)
    # Copy Bot
    "copy": False,                   # cliente: copia las operaciones del autor (estrategia "Copy Bot")
    "copy_cuenta": "PRACTICE",       # cliente: copia en su cuenta DEMO o REAL
    "copy_auto": False,              # cliente: el bot se abre solo cuando el autor empieza a operar
    "copy_enviar": False,            # autor: envía sus operaciones a los clientes
    "copy_filtros": False,           # autor: solo envía las que pasan los filtros
    "copy_destino": "propio",        # autor: "propio" = clientes de su broker · "todos" = IQ Option y Exnova
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

LOGIN_INTENTOS = 3                 # al entrar: intentos si la red o el bróker no responden


def _es_fallo_de_red(e):
    """True si el error es de la red o de que el bróker no respondió (no de la librería ni de la cuenta).
    La librería a veces devuelve el error de red como respuesta y falla al leerlo ('ConnectTimeout' object has no
    attribute 'text'): también cuenta como fallo de red."""
    t = (type(e).__name__ + " " + str(e)).lower()
    return any(x in t for x in ("connecttimeout", "readtimeout", "connectionerror", "connection aborted",
                                "connection reset", "max retries", "timed out", "timeout", "newconnectionerror",
                                "nameresolution", "getaddrinfo", "temporarily unavailable", "remote end closed",
                                "proxyerror", "10060", "10054", "10061"))


def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()



def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER, "ia": "1", "copy": "1"}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    global LICENCIA_COPY
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        r = r.split("|")
        r, con_copy = r[0], "COPY" in r[1:]   # "VALID|COPY": lo que el autor habilitó
        respuestas[c] = r
        if r == "VALID":
            LICENCIA_COPY = con_copy
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER,
                               "copy": _firma_licencia(f"{c}|{ahora}|copy") if con_copy else ""}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    LICENCIA_COPY = False
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                LICENCIA_COPY = d.get("copy") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|copy")
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


# =====================================================================
#  COPY BOT
#  El autor envía cada operación (par, dirección, temporalidad y la hora exacta de entrada) unos segundos
#  ANTES de entrar. Los bots de los clientes con Copy Bot entran al mismo segundo (hora del broker), en su
#  propia cuenta, con su monto, sus stops y sus niveles. Una señal que llega tarde se omite.
#  · Señales: Firebase (rápido). Solo el autor puede escribir (con su clave, que está SOLO en su PC);
#    cualquiera puede leer: una señal no tiene datos de nadie.
#  · Estado de los clientes (copiando, meta, stop) y su nombre: hoja del autor (script de Google),
#    solo después de que el cliente acepta los términos del Copy Bot. Nunca se manda saldo ni contraseña.
# =====================================================================
COPY_DB = "https://iqnova-copy-bot-default-rtdb.firebaseio.com"
COPY_DESPERTAR_SEG = 90          # al empezar, 90 s: los bots de los clientes se conectan EN SILENCIO (el autor puede apagar a alguno)
COPY_ANTICIPO_SEG = 5.5          # con Copy Bot el autor decide 5,5 s antes del cierre: la señal llega a todos a tiempo
COPY_TARDE_SEG = 0.25
COPY_SIN_LATIDO_SEG = 300        # si el bot del autor no avisa en 5 min (se apagó su PC), se da por terminado            # si a un cliente le llega con menos de esto antes de la hora de entrada, la omite
COPY_TERMINAR_MAX_SEG = 15 * 60  # al llegar a su stop, el autor sigue enviando recuperaciones hasta 15 min como máximo
COPY_FILTRO_PAYOUT = 0.83
COPY_FILTRO_ACIERTO = 0.60
COPY_TERMINOS_VERSION = 2       # 2: el autor ve la Meta y la Pérdida de cada cliente
LICENCIA_COPY = False            # el autor marcó "SI" en la columna Copy Bot de esta cuenta


def copy_permitido():
    return bool(LICENCIA_COPY)


def copy_ultima_licencia():
    """¿La última licencia verificada (licencia.dat, firmada) tenía el Copy Bot habilitado?"""
    try:
        d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
        return bool(d.get("copy")) and d.get("copy") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|copy")
    except Exception:
        return False


def _archivo_autor(nombre):
    """Las claves del Copy Bot del autor (solo existen en su PC)."""
    lugares = [DATOS, os.getcwd(), os.path.dirname(os.path.abspath(sys.argv[0] or ".")),
               os.path.dirname(os.path.abspath(__file__)),
               os.path.join(os.path.expanduser("~"), "Documents", "IQNOVA"),
               os.path.join(os.path.expanduser("~"), "Documentos", "IQNOVA"),
               os.path.join(os.path.expanduser("~"), "Documents", "IQBot"),
               os.path.join(os.path.expanduser("~"), "Documentos", "IQBot")]
    for d in lugares:
        try:
            r = os.path.join(d, nombre)
            if os.path.isfile(r):
                with open(r, encoding="utf-8") as f:
                    v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return ""


def copy_clave_firebase():
    return _archivo_autor("copybot_firebase.txt")


def copy_clave_autor():
    return _archivo_autor("copybot_autor.txt")


def copy_script(datos, timeout=20):
    """Llama al script del autor (acciones copy_...). Devuelve el texto o None."""
    import requests
    try:
        d = {"key": LICENCIA_KEY, "plataforma": BROKER}
        d.update({k: v for k, v in datos.items() if v is not None})
        r = requests.post(LICENCIA_URL, timeout=timeout, data=d)
        return (r.text or "").strip() if r.status_code == 200 else None
    except Exception:
        return None


class CopyEmisor:
    """SOLO el bot del autor: escribe la sesión y las señales en Firebase."""

    def __init__(self, bot, filtros=False, todos=False):
        import requests
        self.bot = bot
        self.filtros = bool(filtros)
        self.clave = copy_clave_firebase()
        self.s = requests.Session()
        self.ruta = f"{COPY_DB}/copybot/{BROKER}"
        # "todos": la misma señal llega también a los clientes del otro broker (entran en el mismo par allá)
        self.otras = [f"{COPY_DB}/copybot/{x}" for x in BROKERS if x != BROKER] if todos else []
        self.todos = bool(todos)
        self.bloq = dict(bot.cfg.get("copy_bloqueados") or {})      # cuenta → nombre: clientes apagados por el autor
        self.sid = f"{int(time.time())}{os.getpid() % 1000:03d}"
        self.t0 = time.time()        # inicio de esta sesión de envío (metas y stops se cuentan desde aquí)
        self.n = 0
        self.listo_en = 0.0
        self.terminando = None       # hora en que llegó a su stop (sigue enviando solo recuperaciones)
        self.enviadas = 0
        self.no_enviadas = 0
        self.cerrado = False
        self.conectados = []         # clientes conectados (del script)
        self.vivos = {}              # clave → estado en vivo (Firebase)
        self.avisos = deque(maxlen=30)
        self.ultimo_aviso_t = int(time.time() * 1000)
        self.error = ""

    def ok(self):
        return bool(self.clave)

    def _put(self, sub, datos, timeout=4):
        for otra in self.otras:                      # el otro broker, en paralelo (no retrasa la señal principal)
            threading.Thread(target=self._put_en, args=(otra, sub, datos, timeout), daemon=True).start()
        try:
            r = self.s.put(f"{self.ruta}/{sub}.json", params={"auth": self.clave}, json=datos, timeout=timeout)
            if r.status_code != 200:
                self.error = f"Firebase respondió {r.status_code}"
                return False
            self.error = ""
            return True
        except Exception as e:
            self.error = str(e)[:80]
            return False

    def _put_en(self, ruta, sub, datos, timeout):
        try:
            requests_s = getattr(self, "_s2", None)
            if requests_s is None:
                import requests
                requests_s = self._s2 = requests.Session()
            requests_s.put(f"{ruta}/{sub}.json", params={"auth": self.clave}, json=datos, timeout=timeout)
        except Exception:
            pass

    def despertar(self):
        """Primeros 90 s: los bots de los clientes se abren y se conectan a su cuenta, sin avisarles nada."""
        ahora = self.bot.b.ahora()
        self.listo_en = ahora + COPY_DESPERTAR_SEG
        ok = self._put("sesion", {"activa": True, "sid": self.sid, "inicio": round(ahora, 2), "vivo": round(ahora, 2),
                                  "listo_en": round(self.listo_en, 2), "fin": None, "motivo": "", "bloq": self._bloq_claves()})
        self._put("senal", {"sid": self.sid, "n": 0})
        threading.Thread(target=self._despertar_celulares, daemon=True).start()
        return ok

    def _despertar_celulares(self):
        """Copy auto en celulares: el script manda un aviso de Firebase que despierta la app de los clientes
        (el aviso solo dice "despierta": no lleva datos tuyos ni de ellos)."""
        clave = copy_clave_autor()
        if clave:
            copy_script({"accion": "copy_despertar", "clave_autor": clave, "sid": self.sid,
                         "brokers": ",".join(BROKERS) if self.todos else BROKER}, timeout=20)

    def _bloq_claves(self):
        return [copy_clave_estado(cta) for cta in self.bloq]

    def cambiar_bloqueo(self, cuenta, nombre, apagar):
        """El autor apaga (o enciende) a un cliente: se avisa al instante por la sesión y queda guardado."""
        cuenta = str(cuenta or "").strip()
        if not cuenta:
            return
        if apagar:
            self.bloq[cuenta] = str(nombre or "")[:40]
        else:
            self.bloq.pop(cuenta, None)
        self.bot.cfg["copy_bloqueados"] = dict(self.bloq)
        try:
            c = cargar_config()
            c["copy_bloqueados"] = dict(self.bloq)
            guardar_config(c)
        except Exception:
            pass
        if not self.cerrado:
            self._put("sesion/bloq", self._bloq_claves() or None)

    def latido(self):
        """Cada minuto: la sesión sigue viva (si el PC del autor se apaga, los clientes lo notan)."""
        self._put("sesion/vivo", round(self.bot.b.ahora(), 2))

    def despierto(self):
        return self.bot.b.ahora() >= self.listo_en

    def pasa_filtros(self, c):
        """(pasa, motivo). Solo con "Con filtros": el autor tampoco opera las que no pasan (todo lo que toma, les llega)."""
        if not self.filtros:
            return True, ""
        bot = self.bot
        if (c.get("payout") or 0) < COPY_FILTRO_PAYOUT - 1e-9:
            return False, f"paga {(c.get('payout') or 0) * 100:.0f}% (menos de 83 %)"
        h = time.gmtime(bot.b.ahora() - 5 * 3600).tm_hour            # hora de Bogotá
        if h in (9, 10):
            return False, "horario 9:00–10:59"
        ac = (c.get("racha") or (None, 0))[0]
        if ac is None or ac < COPY_FILTRO_ACIERTO - 1e-9:
            return False, "el par no lleva 60 % a la primera"
        if bot.cfg.get("estrategia") == "bbrsi" and not c.get("en_nivel"):   # MHI y RSI no usan niveles
            return False, "no rebota en un nivel"
        return True, ""

    def enviar(self, s, entrar, solo_rec=False):
        """Envía la operación ANTES de entrar. entrar = hora del broker a la que entran todos."""
        self.n += 1
        d = {"sid": self.sid, "n": self.n, "par": s["par"], "dir": s["dir"], "tf": int(s["tf"]),
             "entrar": round(entrar, 3), "inicio_vela": round(s["inicio_vela"], 2),
             "expira": round(s.get("expira") or (s["inicio_vela"] + s["tf"] * 60), 2),
             "post": bool(s.get("post_cierre")), "etiqueta": s.get("etiqueta", "ENTRADA"),
             "solo_rec": bool(solo_rec), "t": round(self.bot.b.ahora(), 3)}
        ok = self._put("senal", d, timeout=2.5)
        if ok:
            self.enviadas += 1
        return ok

    def enviar_cond(self, vence, si_pierde, si_gana):
        """Antes del cierre: qué hacer con el resultado de la operación que vence (cada cliente según el suyo)."""
        self.n += 1
        d = {"sid": self.sid, "n": self.n, "tipo": "cond", "vence": round(vence, 2),
             "si_pierde": si_pierde, "si_gana": si_gana, "t": round(self.bot.b.ahora(), 3)}
        ok = self._put("senal", d, timeout=2.5)
        if ok:
            self.enviadas += 1
        return ok

    def terminar(self, motivo):
        if self.cerrado:
            return
        self.cerrado = True
        self._put("sesion", {"activa": False, "sid": self.sid, "fin": round(self.bot.b.ahora(), 2), "motivo": motivo})

    def leer_clientes(self):
        """Clientes conectados y avisos nuevos (metas y stops) desde la hoja del autor."""
        clave = copy_clave_autor()
        if not clave:
            return
        txt = copy_script({"accion": "copy_estados", "clave_autor": clave, "desde": str(self.ultimo_aviso_t)})
        if not txt or not txt.startswith("{"):
            return
        try:
            d = json.loads(txt)
        except Exception:
            return
        mios = set(BROKERS.values()) if self.todos else {nombre_broker()}
        self.conectados = [c for c in d.get("conectados") or [] if c.get("plataforma") in mios]
        self._aplicar_vivos()
        for a in d.get("avisos") or []:
            self.ultimo_aviso_t = max(self.ultimo_aviso_t, int(a.get("t") or 0))
            if a.get("plataforma") not in mios:
                continue
            ev = str(a.get("evento") or "")
            nombre = str(a.get("nombre") or "").strip() or "Un cliente"
            cid = str(a.get("cuenta") or "")
            corto = (cid[:4] + "…") if len(cid) > 4 else cid
            try:
                m = float(a.get("monto"))
                monto = f" {'+' if m >= 0 else '−'}${abs(m):.2f}"
            except Exception:
                m, monto = None, ""
            hora = datetime.fromtimestamp((a.get("t") or 0) / 1000).strftime("%H:%M")
            if ev == "Meta alcanzada":
                txt = f"{hora} · {nombre} (ID {corto}) llegó a su meta{monto} y dejó de copiar"
                notificar(f"🏆 {nombre} llegó a su meta", f"Copy Bot · ID {corto}{monto}", tipo="copy_meta",
                          nombre=nombre, monto=m)
            elif ev == "Stop loss":
                txt = f"{hora} · {nombre} (ID {corto}) llegó a su stop loss{monto} y dejó de copiar"
                notificar(f"🛡️ {nombre} llegó a su stop loss", f"Copy Bot · ID {corto}{monto}", tipo="copy_stop",
                          nombre=nombre, monto=m)
            elif ev == "Dejó de copiar":
                txt = f"{hora} · {nombre} (ID {corto}) dejó de copiar{monto}"
                notificar(f"✋ {nombre} dejó de copiar", f"Copy Bot · ID {corto}{monto}", tipo="copy_stop",
                          nombre=nombre, monto=m)
            elif ev.startswith("Enlazado"):
                txt = f"{hora} · {nombre} (ID {corto}) se enlazó al Copy Bot"
            else:
                continue
            self.avisos.appendleft({"texto": txt, "tipo": "meta" if ev == "Meta alcanzada" else
                                    ("stop" if ev == "Stop loss" else "enlace"), "ts": time.time()})
            self.bot.log("📡 " + txt, "bold cyan")

    def escuchar_vivos(self):
        """Autor: escucha en vivo los estados que escriben los clientes (Firebase, con tu clave)."""
        import requests
        brokers = list(BROKERS) if self.todos else [BROKER]
        for br in brokers:
            threading.Thread(target=self._escuchar_vivos, args=(br,), daemon=True).start()

    def _escuchar_vivos(self, br):
        import requests
        espera = 1
        while not self.cerrado and not self.bot.terminado:
            try:
                with requests.get(f"{COPY_DB}/estados/{br}.json", params={"auth": self.clave},
                                  headers={"Accept": "text/event-stream"}, stream=True, timeout=(10, 75)) as r:
                    if r.status_code != 200:
                        raise RuntimeError(r.status_code)
                    espera, evento = 1, None
                    for linea in r.iter_lines(chunk_size=1, decode_unicode=True):
                        if self.cerrado or self.bot.terminado:
                            return
                        if not linea:
                            continue
                        if linea.startswith("event:"):
                            evento = linea[6:].strip()
                            continue
                        if not linea.startswith("data:") or evento not in ("put", "patch"):
                            continue
                        try:
                            d = json.loads(linea[5:].strip())
                        except Exception:
                            continue
                        claves = [k for k in str(d.get("path", "/")).split("/") if k]
                        data = d.get("data")
                        if not claves:
                            for k, v in (data or {}).items():
                                if isinstance(v, dict):
                                    self.vivos[k] = dict(self.vivos.get(k) or {}, **v) if evento == "patch" else v
                        elif len(claves) == 1:
                            if data is None:
                                self.vivos.pop(claves[0], None)
                            elif isinstance(data, dict):
                                self.vivos[claves[0]] = dict(self.vivos.get(claves[0]) or {}, **data) if evento == "patch" else data
                        else:
                            self.vivos.setdefault(claves[0], {})[claves[1]] = data
                        self._aplicar_vivos()
            except Exception:
                time.sleep(espera)
                espera = min(espera * 2, 30)

    def _aplicar_vivos(self):
        """Pone encima de la lista del script lo que llegó en vivo (estado, P/L, nivel, par)."""
        ahora = time.time() * 1000
        for c in self.conectados:
            v = self.vivos.get(copy_clave_estado(str(c.get("cuenta") or "")))
            if not v or ahora - float(v.get("t") or 0) > 15 * 60 * 1000:
                continue
            if v.get("e"):
                c["estado"] = v["e"]
            c["_t"] = float(v.get("t") or 0)
            for k_vivo, k in (("m", "monto"), ("mt", "meta"), ("pd", "perdida"), ("nv", "nivel"), ("pa", "par"), ("cu", "cu")):
                if k_vivo in v:
                    c[k] = v[k_vivo]

    def en_recuperacion(self):
        return [c for c in self.conectados if c.get("estado") == "rec"]

    def resumen(self):
        hoy = lambda c: float(c.get("_t") or 0) >= self.t0 * 1000 - 60000    # solo los de esta sesión, no los de ayer
        meta = sum(1 for c in self.conectados if c.get("estado") == "meta" and hoy(c))
        stop = sum(1 for c in self.conectados if c.get("estado") == "stop" and hoy(c))
        copiando = sum(1 for c in self.conectados if c.get("estado") in ("copiando", "rec"))
        falta = max(0, int(self.listo_en - self.bot.b.ahora())) if not self.despierto() else 0
        orden = {"rec": 0, "copiando": 1, "pausa": 2, "meta": 3, "stop": 4, "parado": 5, "fuera": 6}
        clientes = []
        for c in sorted(self.conectados, key=lambda c: (orden.get(c.get("estado"), 9), str(c.get("nombre") or ""))):
            cid = str(c.get("cuenta") or "")
            if cid in self.bloq:
                continue                                 # apagado por el autor: va al final
            if c.get("estado") in ("meta", "stop", "parado", "fuera"):
                continue                                 # terminó o se desconectó: sale de la lista de una vez
            num = lambda k: (float(c[k]) if str(c.get(k, "")).strip() not in ("", "None") else None)
            try:
                clientes.append({"nombre": str(c.get("nombre") or "") or "Cliente", "id": (cid[:4] + "…") if len(cid) > 4 else cid,
                                 "plataforma": c.get("plataforma"), "estado": c.get("estado"), "monto": num("monto"),
                                 "meta": num("meta"), "perdida": num("perdida"), "nivel": int(float(c.get("nivel") or 0)),
                                 "par": str(c.get("par") or ""), "cuenta": cid, "bloq": False,
                                 "cu": str(c.get("cu") or "")})
            except Exception:
                continue
        for cid, nom in self.bloq.items():                   # los apagados: siempre a la vista para volverlos a encender
            clientes.append({"nombre": nom or "Cliente", "id": (cid[:4] + "…") if len(cid) > 4 else cid, "estado": "bloq",
                             "monto": None, "meta": None, "perdida": None, "nivel": 0, "par": "", "cuenta": cid, "bloq": True})
        return {"rol": "autor", "copiando": copiando, "meta": meta, "stop": stop, "enviadas": self.enviadas,
                "clientes": clientes[:60],
                "no_enviadas": self.no_enviadas, "filtros": self.filtros, "despertando": falta,
                "terminando": self.terminando is not None and not self.cerrado, "avisos": [a for a in self.avisos if time.time() - a.get("ts", 0) < 60][:6],   # cada aviso, máx. 1 min
                "error": self.error, "sin_clave": not self.ok()}


def copy_clave_estado(cid):
    """Clave del cliente en el canal de estados en vivo (no lleva su ID a la vista)."""
    import hashlib
    return hashlib.sha256(f"iqnova|{cid}".encode()).hexdigest()[:20]


_VIVO_SIN_CUENTA = [0.0]        # si Firebase no acepta el campo de la cuenta, se manda sin él y se reintenta cada 10 min


def copy_estado_vivo(cid, datos, timeout=3):
    """Cliente: escribe su estado en Firebase para que el autor lo vea al instante (solo escribir: nadie más lo lee)."""
    import requests
    try:
        d = {"e": str(datos.get("estado") or "")[:12], "m": str(datos.get("monto") or "")[:16],
             "mt": str(datos.get("meta") or "")[:16], "pd": str(datos.get("perdida") or "")[:16],
             "nv": str(datos.get("nivel") or "0")[:3], "pa": str(datos.get("par") or "")[:24], "t": {".sv": "timestamp"}}
        if datos.get("tipo_cuenta") and time.time() - _VIVO_SIN_CUENTA[0] > 600:
            d["cu"] = "REAL" if datos.get("tipo_cuenta") == "REAL" else "DEMO"
        url = f"{COPY_DB}/estados/{BROKER}/{copy_clave_estado(cid)}.json"
        r = requests.put(url, json=d, timeout=timeout)
        if r.status_code != 200 and "cu" in d:
            d.pop("cu")
            r = requests.put(url, json=d, timeout=timeout)
            if r.status_code == 200:
                _VIVO_SIN_CUENTA[0] = time.time()
        return r.status_code == 200
    except Exception:
        return False


def copy_escuchar(al_llegar, detener, al_estado=None):
    """Cliente: escucha las señales del autor (Firebase, en vivo). al_llegar(senal), al_estado(sesion)."""
    import requests
    ruta = f"{COPY_DB}/copybot/{BROKER}.json"
    espera = 1
    arbol = {}
    while not detener():
        try:
            with requests.get(ruta, headers={"Accept": "text/event-stream"}, stream=True, timeout=(10, 75)) as r:
                if r.status_code != 200:
                    raise RuntimeError(f"Firebase {r.status_code}")
                espera = 1
                evento = None
                for linea in r.iter_lines(chunk_size=1, decode_unicode=True):   # cada evento apenas llega
                    if detener():
                        return
                    if not linea:
                        continue
                    if linea.startswith("event:"):
                        evento = linea[6:].strip()
                        continue
                    if not linea.startswith("data:") or evento not in ("put", "patch"):
                        continue
                    try:
                        d = json.loads(linea[5:].strip())
                    except Exception:
                        continue
                    claves = [k for k in str(d.get("path", "/")).split("/") if k]
                    data = d.get("data")
                    if not claves:
                        if evento == "put":
                            arbol.clear()
                        arbol.update(data if isinstance(data, dict) else {})
                        tocados = {"sesion", "senal"}
                    else:
                        nodo = arbol
                        for k in claves[:-1]:
                            if not isinstance(nodo.get(k), dict):
                                nodo[k] = {}
                            nodo = nodo[k]
                        if evento == "patch" and isinstance(data, dict):
                            if not isinstance(nodo.get(claves[-1]), dict):
                                nodo[claves[-1]] = {}
                            nodo[claves[-1]].update(data)
                        elif data is None:
                            nodo.pop(claves[-1], None)
                        else:
                            nodo[claves[-1]] = data
                        tocados = {claves[0]}
                    if al_estado and "sesion" in tocados and isinstance(arbol.get("sesion"), dict):
                        al_estado(dict(arbol["sesion"]))
                    if "senal" in tocados and isinstance(arbol.get("senal"), dict) and len(claves) <= 1:
                        al_llegar(dict(arbol["senal"]))
        except Exception:
            pass
        for _ in range(espera * 10):
            if detener():
                return
            time.sleep(0.1)
        espera = min(espera * 2, 15)


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas por el buzón común (si el bróker no da número de pedido)
        self.lock_rid = threading.Lock()      # contador de números de pedido
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self._memo_velas = {}                 # (id del par, tamaño) -> {hora: cierre} de la última respuesta buena
        self._buzon_sucio = 0.0               # hasta cuándo puede llegar tarde una respuesta vieja al buzón común
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        nb = nombre_broker()
        intento = 0
        while True:                                     # si falla por la red, reintenta solo (3 intentos)
            intento += 1
            try:
                ok, motivo = con_timeout(api.connect, 45)
                if ok or not _es_fallo_de_red(motivo):
                    break                               # entró, o la respuesta no es de red (clave, 2FA…)
            except TimeoutError:
                pass
            except json.JSONDecodeError as e:
                crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
                return None, (f"{nb} devolvió una respuesta inesperada al iniciar sesión "
                              "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                              "navegador para confirmar que tu cuenta abre bien."
                              + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
            except Exception as e:
                if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                    return None, (f"No se pudo verificar la conexión segura con {nb} (certificado no válido). "
                                  "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                                  "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
                if not _es_fallo_de_red(e):
                    libreria_conecto(False, culpa_de_libreria=True)
                    return None, f"Error de conexión: {e}"
            if intento >= LOGIN_INTENTOS:
                return None, (f"{nb} no respondió a tiempo (se intentó {LOGIN_INTENTOS} veces). "
                              f"Puede ser tu internet o que los servidores de {nb} estén lentos en este momento. "
                              "Espera un minuto y vuelve a entrar; si sigue igual, prueba con otra red (por ejemplo, los datos del celular).")
            time.sleep(3 * intento)                     # espera un poco más en cada intento
            try:
                api = IQ_Option(email, clave)           # conexión nueva para el siguiente intento
            except Exception:
                pass
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        raw = self._pedir_velas(aid, tf_min * 60, cantidad + 1, time.time())
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _pedir_velas(self, aid, tam, cantidad, hasta):
        """Pide velas con NÚMERO DE PEDIDO propio: la respuesta solo le llega a quien la pidió, así una respuesta
        atrasada de otro par nunca se confunde con esta (antes se mezclaban velas de otros activos).
        Si el bróker no devuelve el número, usa el buzón común con más cuidado. Siempre revisa las velas."""
        inner = self.inner
        raw = None
        if getattr(self, "_rid_ok", None) is not False:
            buzon = getattr(inner, "_iqbot_velas", None)
            if buzon is None:
                buzon = inner._iqbot_velas = {}
            with self.lock_rid:
                self._rid_n = getattr(self, "_rid_n", 0) + 1
                rid = f"iqv{self._rid_n}"
            datos = {"name": "get-candles", "version": "2.0",
                     "body": {"active_id": int(aid), "split_normalization": True, "size": int(tam),
                              "to": int(hasta), "count": int(cantidad), "": int(aid)}}
            try:
                inner.send_websocket_request("sendMessage", datos, request_id=rid)
                raw = _esperar(lambda: buzon.get(rid), 5)
            except Exception:
                raw = None
            buzon.pop(rid, None)
            if raw is not None:
                self._rid_ok = True
            elif getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: buzón común
        if raw is None and getattr(self, "_rid_ok", None) is False:
            with self.lock:                           # buzón común: un pedido a la vez
                espera = self._buzon_sucio - time.time()
                if espera > 0:                        # una respuesta vieja puede llegar todavía: se deja pasar
                    _esperar(lambda: inner.candles.candles_data, min(espera, 3))
                inner.candles.candles_data = None
                inner.getcandles(aid, tam, cantidad, float(hasta))
                raw = _esperar(lambda: inner.candles.candles_data, 5)
                if raw is None:
                    self._buzon_sucio = time.time() + 10
        if not raw:
            return raw
        if not self._velas_buenas(aid, tam, raw, hasta):
            return None
        return raw

    def _velas_buenas(self, aid, tam, raw, hasta):
        """Revisión de seguridad: las velas tienen que ser de ESTE par. Se comparan con las que ya llegaron antes
        (las mismas horas deben tener el mismo cierre) y se descartan saltos imposibles dentro del bloque."""
        try:
            cierres = [float(v["close"]) for v in raw]
            if not cierres or min(cierres) <= 0:
                return False
            orden = sorted(cierres)
            med = orden[len(orden) // 2]
            if any(abs(c / med - 1) > 0.25 for c in cierres):        # dos activos distintos en un mismo bloque
                return False
            memo = self._memo_velas.setdefault((int(aid), int(tam)), {})
            iguales = distintas = 0
            for v in raw[:-1]:                                      # la última puede estar formándose
                previo = memo.get(int(v["from"]))
                if previo is not None:
                    if abs(float(v["close"]) / previo - 1) < 1e-4:
                        iguales += 1
                    else:
                        distintas += 1
            if distintas >= 2 and distintas > iguales:              # las mismas horas con otros precios: es otro par
                return False
            if not iguales and memo:                                # sin horas en común: si son horas cercanas,
                t_ult = int(raw[-1]["from"])                         # el precio debe estar cerca
                cerca = min(memo, key=lambda t: abs(t - t_ult))
                if abs(cerca - t_ult) <= 3 * 3600 and abs(cierres[-1] / memo[cerca] - 1) > 0.25:
                    return False
            for v in raw[:-1]:
                memo[int(v["from"])] = float(v["close"])
            if len(memo) > 3000:
                for t in sorted(memo)[:len(memo) - 2500]:
                    memo.pop(t, None)
            return True
        except Exception:
            return True

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos: una sola temporalidad, de M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
PREPARAR_A_LA_VEZ = 3                          # pares que se leen a la vez antes del cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real). El bot opera los dos: los que estén abiertos."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


BBRSI_PRESETS = {           # "BB + RSI" (autor): la mejor combinación medida en el historial de Exnova para cada temporalidad
    1: (20, 2.0, 14, 75, 25),  # (periodo Bollinger, desviaciones, periodo RSI, nivel alto, nivel bajo) · M1: ~4 veces más señales, mismo acierto
    2: (20, 2.0, 7, 80, 20),
    3: (20, 2.0, 14, 75, 25),
    4: (20, 2.5, 14, 75, 25),
    5: (20, 2.5, 7, 80, 20),
}


def bbrsi_valores(cfg, tf):
    """(periodo Bollinger, desviaciones, periodo RSI, alto, bajo): los recomendados para la temporalidad o, si los
    editaste en Estrategias → Bollinger + RSI → Editar, los tuyos."""
    base = BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])
    if not (cfg or {}).get("bbrsi_manual"):
        return base
    try:
        per = max(5, min(50, int(cfg.get("bbrsi_per", base[0]))))
        dev = max(1.0, min(4.0, round(float(cfg.get("bbrsi_dev", base[1])), 1)))
        rp = max(2, min(50, int(cfg.get("bbrsi_rp", base[2]))))
        alto = max(51, min(99, int(cfg.get("bbrsi_alto", base[3]))))
        bajo = max(1, min(49, int(cfg.get("bbrsi_bajo", base[4]))))
        return (per, dev, rp, alto, bajo)
    except (TypeError, ValueError):
        return base


def bbrsi_preset(cfg):
    try:
        tf = int((cfg.get("temporalidades") or [2])[0])
    except (TypeError, ValueError):
        tf = 2
    return tf, bbrsi_valores(cfg, tf)


RACHA_N, RACHA_MIN = 20, 10   # acierto "a la primera" de cada par: sus últimas 20 señales de BB + RSI (mínimo 10 para contar)


def resultados_bbrsi(velas, tf, desde_t=0, cfg=None):
    """Señales de Bollinger + RSI en velas ya cerradas (posteriores a 'desde_t') y si ganaron a la primera
    (la vela siguiente cerró a favor): {t: True/False}. Los empates no cuentan."""
    per, k, rp, alto, bajo = bbrsi_valores(cfg, tf)
    c = [float(v["c"]) for v in velas]
    serie = _rsi_serie(c, rp)                       # serie[0] corresponde a c[rp]
    out = {}
    for i in range(max(per - 1, rp), len(c) - 1):
        t = velas[i]["t"]
        if t <= desde_t or velas[i + 1]["t"] - t != tf * 60:
            continue
        w = c[i - per + 1:i + 1]
        m = sum(w) / per
        s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
        r = serie[i - rp]
        d = -1 if (c[i] > m + k * s and r > alto) else (1 if (c[i] < m - k * s and r < bajo) else 0)
        mov = c[i + 1] - c[i]
        if d and mov:
            out[t] = (mov > 0) == (d > 0)
    return out


# señal "clara": mercado lateral (ADX < 20) y par con 60 % o más a la primera. En cada cierre se prefiere una clara;
# si no hay, la del par con mejor acierto (sin esperar). Solo M2 a M4 (en M5 no mejoró en el historial).
CLARA_ADX, CLARA_ACIERTO, CLARA_TFS = 20.0, 0.60, (2, 3, 4)


def niveles_de(dias, horas, ahora):
    """Niveles donde el precio suele rebotar: pivô y Fibonacci (38,2/50/61,8 %) del día anterior, y soportes/
    resistencias de H1 tocados al menos 2 veces en las últimas 48 h. 'dias' y 'horas': velas D1 y H1 del bróker."""
    out = []
    hoy = int(ahora // 86400) * 86400
    prev = next((d for d in dias or [] if int(d["from"]) == hoy - 86400), None)
    if prev:
        ph, pl, pc = float(prev["max"]), float(prev["min"]), float(prev["close"])
        p = (ph + pl + pc) / 3
        out += [p, 2 * p - pl, 2 * p - ph, p + (ph - pl), p - (ph - pl)]
        out += [pl + (ph - pl) * x for x in (0.382, 0.5, 0.618)]
    hs = [h for h in horas or [] if int(h["from"]) + 3600 <= ahora]
    if len(hs) >= 10:
        rangos = sorted(float(h["max"]) - float(h["min"]) for h in hs)
        tol = 0.15 * rangos[len(rangos) // 2]
        sw = []
        for i in range(2, len(hs) - 2):
            if int(hs[i + 2]["from"]) + 3600 <= ahora - 48 * 3600:
                continue
            ven = hs[i - 2:i + 3]
            if float(hs[i]["max"]) >= max(float(v["max"]) for v in ven):
                sw.append(float(hs[i]["max"]))
            if float(hs[i]["min"]) <= min(float(v["min"]) for v in ven):
                sw.append(float(hs[i]["min"]))
        out += [x for x in sw if sum(1 for y in sw if abs(y - x) <= tol) >= 2]
    return out


def rechaza_nivel(vela, d, niveles):
    """¿La vela de la señal tocó un nivel y cerró devolviéndose, a favor de la dirección? (PUT: tocó desde abajo
    y cerró debajo; CALL: tocó desde arriba y cerró encima)."""
    o, c, h, l = float(vela["o"]), float(vela["c"]), float(vela["h"]), float(vela["l"])
    for x in niveles:
        if d == "put" and h >= x > c and o < x:
            return True
        if d == "call" and l <= x < c and o > x:
            return True
    return False


def adx_ultimo(velas, n=14):
    """ADX de Wilder (fuerza de la tendencia, 0-100) en la última vela, o None si faltan velas."""
    v = velas[-(n * 6):]
    if len(v) < 2 * n + 2:
        return None
    tr, pdm, mdm = [], [], []
    for a, b in zip(v, v[1:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0)
        mdm.append(dn if dn > up and dn > 0 else 0.0)
        tr.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    atr, sp, sm = sum(tr[:n]) / n, sum(pdm[:n]) / n, sum(mdm[:n]) / n
    dxs = []
    for i in range(n, len(tr)):
        atr = (atr * (n - 1) + tr[i]) / n
        sp = (sp * (n - 1) + pdm[i]) / n
        sm = (sm * (n - 1) + mdm[i]) / n
        if atr <= 0:
            continue
        pdi, mdi = 100 * sp / atr, 100 * sm / atr
        dxs.append(100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi > 0 else 0.0)
    if len(dxs) < n:
        return None
    adx = sum(dxs[:n]) / n
    for x in dxs[n:]:
        adx = (adx * (n - 1) + x) / n
    return adx


def senal(cierres, cfg, estricto=False):
    """(dirección o None, texto) de Bollinger + RSI. 'cierres' termina con el precio de la vela de señal.
    estricto (solo el autor en "Solo pérdida"): el RSI más extremo y el precio más afuera de la banda."""
    _tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
    b = bandas(cierres, per, k)
    serie = _rsi_serie(cierres[-(rp * 12 + 2):], rp)
    if not b or not serie:
        return None, ""
    c, r = cierres[-1], serie[-1]
    extra = 0.0
    if estricto:
        alto, bajo = alto + ESTRICTO_RSI, bajo - ESTRICTO_RSI
        extra = (b[0] - b[2]) * ESTRICTO_FUERA
    if c > b[0] + extra and r > alto:
        return "put", f"sobre la banda y RSI {r:.0f}" + (" · exigente" if estricto else "")
    if c < b[2] - extra and r < bajo:
        return "call", f"bajo la banda y RSI {r:.0f}" + (" · exigente" if estricto else "")
    return None, ""


ESTRICTO_RSI = 5          # "Solo pérdida": el RSI debe pasar 5 puntos más allá de su nivel (ej. 80/20 en vez de 75/25)
ESTRICTO_FUERA = 0.10     # y el precio debe cerrar fuera de la banda al menos un 10 % del ancho de las bandas

PARES_AMBOS = frozenset([
    'AI Power & Datacenter',
    'AIG-OTC',
    'AIRLINES-OTC',
    'ALIBABA-OTC',
    'AMAZON-OTC',
    'AMAZON-op',
    'AMZN/ALIBABA-OTC',
    'AMZN/EBAY-OTC',
    'APPLE-OTC',
    'ARBUSD-OTC',
    'ASMLa',
    'ATOMUSD-OTC',
    'AUDCAD-OTC',
    'AUDCHF-OTC',
    'AUDCHF-op',
    'AUDJPY-OTC',
    'AUDNZD-OTC',
    'AUDNZD-op',
    'AUDUSD-OTC',
    'AUDUSD-op',
    'AUS200-OTC',
    'AUS200:N',
    'Anthropic-OTC',
    'BCHUSD-OTC',
    'BIDU-OTC',
    'BONKUSD-OTC',
    'BTCUSD-op',
    'Bitcoin/Gold-op',
    'CADCHF-OTC',
    'CADJPY-OTC',
    'CANNABIS-OTC',
    'CASINOS-OTC',
    'CHFJPY-OTC',
    'CHFNOK-OTC',
    'CITI-OTC',
    'COCOA-OTC',
    'COFFEE-OTC',
    'COKE-OTC',
    'COTTON-OTC',
    'Crude Oil Brent/BRL',
    'DASHUSD-OTC',
    'DIA',
    'DOTUSD-OTC',
    'DYDXUSD-OTC',
    'EOSUSD-OTC',
    'ETHUSD-OTC',
    'EU50-OTC',
    'EURAUD-OTC',
    'EURCAD-OTC',
    'EURCHF-OTC',
    'EURGBP-OTC',
    'EURJPY-OTC',
    'EURJPY-op',
    'EURNZD-OTC',
    'EURNZD-op',
    'EURTHB-OTC',
    'EURTHB-op',
    'EURUSD-OTC',
    'EURUSD-op',
    'European AI',
    'FACEBOOK-op',
    'FARTCOINUSD-OTC',
    'FB-OTC',
    'FETUSD-OTC',
    'FLOKIUSD-OTC',
    'FR40-OTC',
    'FRANCE40:N',
    'FWONA-OTC',
    'GBPAUD-OTC',
    'GBPAUD-op',
    'GBPCAD-OTC',
    'GBPCHF-OTC',
    'GBPJPY-OTC',
    'GBPJPY-op',
    'GBPNZD-OTC',
    'GBPNZD-op',
    'GBPUSD-OTC',
    'GBPUSD-op',
    'GDX',
    'GER30-OTC',
    'GER30/UK100-OTC',
    'GERMANY30:N',
    'GEV-OTC',
    'GOOGLE-OTC',
    'GOOGLE-op',
    'GOOGLE/MSFT-OTC',
    'GRTUSD-OTC',
    'GS-OTC',
    'Gold/BRL',
    'HBARUSD-OTC',
    'HK33-OTC',
    'HONGKONG33:N',
    'HYPE-OTC',
    'ICPUSD-OTC',
    'IMXUSD-OTC',
    'INJUSD-OTC',
    'INTEL-OTC',
    'INTEL/IBM-OTC',
    'IOTAUSD-OTC',
    'IWM',
    'JAPAN225:N',
    'JP225-OTC',
    'JPM-OTC',
    'JPYTHB-OTC',
    'JUPUSD-OTC',
    'KLARNA-OTC',
    'LABUBUUSD-OTC',
    'LINKUSD-OTC',
    'LTCUSD-OTC',
    'LUNA-OTC',
    'Luxury',
    'MAGNIFICENT7-OTC',
    'MANAUSD-OTC',
    'MATICUSD-OTC',
    'MCDON-OTC',
    'MELANIAUSD-OTC',
    'META/GOOGLE-OTC',
    'MORSTAN-OTC',
    'MSFT-OTC',
    'MSFT-op',
    'MSFT/AAPL-OTC',
    'MU-OTC',
    'Magnificent7-op',
    'NEARUSD-OTC',
    'NFLX/AMZN-OTC',
    'NIKE-OTC',
    'NOKJPY-OTC',
    'NVDA-OTC',
    'NVDA/AMD-OTC',
    'NZDCAD-OTC',
    'NZDCAD-op',
    'NZDCHF-OTC',
    'NZDJPY-OTC',
    'NZDUSD-OTC',
    'NZDUSD-op',
    'ONDOUSD-OTC',
    'ORDIUSD-OTC',
    'OpenAI-OTC',
    'PENGUUSD-OTC',
    'PENUSD-OTC',
    'PEPEUSD-OTC',
    'PLTR-OTC',
    'PYTHUSD-OTC',
    'RAYDIUMUSD-OTC',
    'RENDERUSD-OTC',
    'RONINUSD-OTC',
    'SANDUSD-OTC',
    'SATSUSD-OTC',
    'SEIUSD-OTC',
    'SHIBUSD-OTC',
    'SMH',
    'SOLUSD-OTC',
    'SP500-OTC',
    'SPY',
    'SQQQ',
    'STXUSD-OTC',
    'SUGAR-OTC',
    'SUIUSD-OTC',
    'SpaceX-OTC',
    'SpaceX-op',
    'TAOUSD-OTC',
    'TESLA-OTC',
    'TESLA-op',
    'TESLA/FORD-OTC',
    'TRON-OTC',
    'TRUMPUSD-OTC',
    'UK100-OTC',
    'UK100:N',
    'UKOUSD-OTC',
    'URANIUM-OTC',
    'US AI Semiconductors',
    'US100/JP225-OTC',
    'US2000-OTC',
    'US2000:N',
    'US30-OTC',
    'US30/JP225-OTC',
    'US30:N',
    'USDAED-OTC',
    'USDARS-OTC',
    'USDBDT-OTC',
    'USDBOB-OTC',
    'USDBRL-OTC',
    'USDCAD-OTC',
    'USDCHF-OTC',
    'USDCLP-OTC',
    'USDCOP-OTC',
    'USDDOP-OTC',
    'USDHKD-OTC',
    'USDIDR-OTC',
    'USDINR-OTC',
    'USDJPY-OTC',
    'USDJPY-op',
    'USDMXN-OTC',
    'USDMYR-OTC',
    'USDNGN-OTC',
    'USDPHP-OTC',
    'USDPLN-OTC',
    'USDSAR-OTC',
    'USDSGD-OTC',
    'USDTHB-OTC',
    'USDTHB-op',
    'USDTRY-OTC',
    'USDVND-OTC',
    'USDZAR-OTC',
    'USNDAQ100-OTC',
    'USNDAQ100:N',
    'USOUSD-OTC',
    'USOUSD-op',
    'USSPX500:N',
    'WDC-OTC',
    'WIFUSD-OTC',
    'WLDUSD-OTC',
    'XAGUSD-OTC',
    'XAU/XAG-OTC',
    'XAUUSD-OTC',
    'XAUUSD-op',
    'XLK',
    'XNGUSD-OTC',
    'XPDUSD-OTC',
    'XPTUSD-OTC',
    'XRPUSD-OTC',
])
# Pares con el mismo nombre en IQ Option y en Exnova (revisado el 12/11/2026 con los datos del bot).
# Cuando el autor envía al Copy Bot de los DOS brókers, solo opera estos: así la señal la pueden tomar todos.


MHI_MODELOS = {           # (vela del cuadrante de 5 min en que entra, cuántas velas mira)
    "mhi1": (0, 3), "mhi2": (1, 3), "mhi3": (2, 3), "millon": (0, 5)}
MHI_NOMBRES = {"mhi1": "MHI 1", "mhi2": "MHI 2", "mhi3": "MHI 3", "millon": "Millón"}


def mhi_modelo(cfg):
    m = str(cfg.get("mhi_modelo") or "mhi1_min")
    base, _, lado = m.partition("_")
    if base not in MHI_MODELOS or lado not in ("min", "may"):
        base, lado = "mhi1", "min"
    return base, lado


def senal_mhi(velas, prox, cfg):
    """MHI (M1, cuadrantes de 5 minutos). 'velas' son las M1 cerradas, la última termina en 'prox' (cuando entra).
    MHI 1/2/3: mira las 3 últimas velas del cuadrante anterior y entra en la 1.ª/2.ª/3.ª vela del nuevo.
    Millón: mira las 5 velas del cuadrante anterior y entra en la 1.ª. Minoría: el color que salió menos;
    mayoría: el que salió más. Con una vela sin cuerpo (doji) no entra."""
    base, lado = mhi_modelo(cfg)
    entra, cuantas = MHI_MODELOS[base]
    if (int(prox) // 60) % 5 != entra:
        return None, ""
    fin = int(prox) - entra * 60                       # inicio del cuadrante nuevo
    por_t = {int(v["t"]): v for v in velas}
    mira = [por_t.get(fin - 60 * i) for i in range(cuantas, 0, -1)]
    if any(v is None for v in mira):
        return None, ""
    verdes = sum(1 for v in mira if v["c"] > v["o"])
    rojas = sum(1 for v in mira if v["c"] < v["o"])
    if verdes + rojas != cuantas:
        return None, ""
    mas_verdes = verdes > rojas
    d = ("put" if mas_verdes else "call") if lado == "min" else ("call" if mas_verdes else "put")
    return d, f"{MHI_NOMBRES[base]} {'minoría' if lado == 'min' else 'mayoría'} ({verdes} verdes · {rojas} rojas)"


MHI_RACHA_N = 60          # acierto MHI de cada par: sus últimas 60 señales del modelo elegido (~5 h de velas M1)


def resultados_mhi(velas, cfg):
    """Señales del modelo MHI elegido en velas M1 YA cerradas y si ganaron a la primera: [(t, gano)].
    Los empates y las señales con doji no cuentan."""
    base, lado = mhi_modelo(cfg)
    entra, cuantas = MHI_MODELOS[base]
    por_t = {int(v["t"]): v for v in velas}
    out = []
    for t in sorted(por_t):
        if (t // 60) % 5 != entra:
            continue
        e = por_t[t]                                   # la vela en la que se entra
        fin = t - entra * 60
        mira = [por_t.get(fin - 60 * i) for i in range(cuantas, 0, -1)]
        if any(v is None for v in mira):
            continue
        verdes = sum(1 for v in mira if v["c"] > v["o"])
        rojas = sum(1 for v in mira if v["c"] < v["o"])
        if verdes + rojas != cuantas or e["c"] == e["o"]:
            continue
        call = (verdes < rojas) if lado == "min" else (verdes > rojas)
        out.append((t, (e["c"] > e["o"]) == call))
    return out


def rsi_params(cfg):
    """(periodo, nivel alto, nivel bajo, modo) del RSI del autor, ya validados. Alto y bajo pueden ser iguales (50/50)."""
    def n(k, d, a, b):
        try:
            return max(a, min(b, int(round(float(cfg.get(k, d))))))
        except (TypeError, ValueError):
            return d
    per, alto, bajo = n("rsi_periodo", 2, 2, 50), n("rsi_alto", 50, 1, 99), n("rsi_bajo", 50, 1, 99)
    if bajo > alto:
        alto, bajo = bajo, alto
    return per, alto, bajo, ("contra" if cfg.get("rsi_modo") == "contra" else "favor")


def _rsi_cruce(r0, r1, alto, bajo, modo):
    """+1 CALL / -1 PUT / 0. A favor: cruza hacia arriba el alto -> CALL; hacia abajo el bajo -> PUT. En contra: al revés."""
    d = 1 if (r0 <= alto < r1) else (-1 if (r0 >= bajo > r1) else 0)
    return -d if modo == "contra" else d


def senal_rsi(cierres, cfg):
    """(dirección o None, texto) del RSI del autor. 'cierres' termina con el precio de la vela de señal."""
    per, alto, bajo, modo = rsi_params(cfg)
    serie = _rsi_serie(cierres[-(per * 12 + 3):], per)
    if len(serie) < 2:
        return None, ""
    d = _rsi_cruce(serie[-2], serie[-1], alto, bajo, modo)
    if not d:
        return None, ""
    hacia = "arriba" if serie[-1] > serie[-2] else "abajo"
    return ("call" if d > 0 else "put"), f"RSI {serie[-2]:.0f}→{serie[-1]:.0f} cruza hacia {hacia} · {'a favor' if modo == 'favor' else 'en contra'}"


def resultados_rsi(velas, tf, cfg):
    """Señales del RSI del autor en velas ya cerradas y si ganaron a la primera: [(t, gano)]. Los empates no cuentan."""
    per, alto, bajo, modo = rsi_params(cfg)
    c = [float(v["c"]) for v in velas]
    serie = _rsi_serie(c, per)                      # serie[j] corresponde a c[per + j]
    out = []
    for i in range(per + 1, len(c) - 1):
        if velas[i + 1]["t"] - velas[i]["t"] != tf * 60:
            continue
        d = _rsi_cruce(serie[i - per - 1], serie[i - per], alto, bajo, modo)
        mov = c[i + 1] - c[i]
        if d and mov:
            out.append((velas[i]["t"], (mov > 0) == (d > 0)))
    return out




def boll_params(cfg):
    """(periodo, desviación, momento, dirección) de la Bollinger del autor, ya validados."""
    try:
        per = max(5, min(50, int(round(float(cfg.get("boll_periodo", 20))))))
    except (TypeError, ValueError):
        per = 20
    try:
        dev = max(1.0, min(4.0, round(float(cfg.get("boll_dev", 2.0)), 1)))
    except (TypeError, ValueError):
        dev = 2.0
    return (per, dev, "anticipado" if cfg.get("boll_momento") == "anticipado" else "cierre",
            "sigue" if cfg.get("boll_dir") == "sigue" else "regresa")


def ant_params(cfg):
    """(estirón mínimo, retroceso desde, retroceso hasta) del anticipado, en fracciones y ya validados."""
    def n(k, d, a, b):
        try:
            return max(a, min(b, int(round(float(cfg.get(k, d))))))
        except (TypeError, ValueError):
            return d
    est, rmin, rmax = n("ant_estiron", 10, 0, 1000), n("ant_retro_min", 25, 0, 100), n("ant_retro_max", 35, 0, 100)
    if rmax < rmin:
        rmax = rmin
    return est / 100, rmin / 100, rmax / 100


def ant_tiempo(cfg):
    """(desde, hasta, directo) del anticipado: ventana en segundos antes del cierre y el estirón (fracción) desde el
    que entra sin esperar retroceso (0 = apagado). Validados."""
    def n(k, d, a, b):
        try:
            return max(a, min(b, int(round(float(cfg.get(k, d))))))
        except (TypeError, ValueError):
            return d
    desde, hasta, directo = n("ant_desde", 30, 2, 55), n("ant_hasta", 20, 1, 54), n("ant_directo", 0, 0, 1000)
    if hasta >= desde:
        hasta = max(1, desde - 1)
    return desde, hasta, directo / 100


def _boll_dir(lado, sentido):
    """lado +1 = salió por arriba, -1 = por abajo → 'call' / 'put' según regresa / sigue."""
    sube = (lado < 0) if sentido == "regresa" else (lado > 0)
    return "call" if sube else "put"


def senal_boll(cierres, cfg):
    """Al cierre: la vela que cierra fuera de la banda. 'cierres' termina con el precio de la vela de señal."""
    per, dev, _, sentido = boll_params(cfg)
    b = bandas([float(x) for x in cierres], per, dev)
    if not b:
        return None, ""
    c = float(cierres[-1])
    lado = 1 if c > b[0] else (-1 if c < b[2] else 0)
    if not lado:
        return None, ""
    return _boll_dir(lado, sentido), f"cerró {'arriba' if lado > 0 else 'abajo'} de la banda · {sentido}"


def resultados_boll(velas, tf, cfg):
    """Señales de Bollinger (al cierre) en velas cerradas y si ganaron a la primera: [(t, gano)]."""
    per, dev, _, sentido = boll_params(cfg)
    c = [float(v["c"]) for v in velas]
    out = []
    for i in range(per - 1, len(c) - 1):
        if velas[i + 1]["t"] - velas[i]["t"] != tf * 60:
            continue
        b = bandas(c[:i + 1], per, dev)
        if not b:
            continue
        lado = 1 if c[i] > b[0] else (-1 if c[i] < b[2] else 0)
        mov = c[i + 1] - c[i]
        if lado and mov:
            out.append((velas[i]["t"], (mov > 0) == (_boll_dir(lado, sentido) == "call")))
    return out


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "multi":
        a, n = multi_minimos(cfg)
        return f"Estrategias ({len(estrategias_on(cfg))} elegidas · acierto mínimo {a * 100:.0f} % · {n} señales)"
    if cfg.get("estrategia") == "boll":
        per, dev, mom, sentido = boll_params(cfg)
        return f"Bollinger {per},{dev:g} {'anticipado' if mom == 'anticipado' else 'al cierre'} · {sentido}"
    if cfg.get("estrategia") == "rsi":
        per, alto, bajo, modo = rsi_params(cfg)
        return f"RSI {per} {alto}/{bajo} {'a favor' if modo == 'favor' else 'en contra'}"
    if cfg.get("estrategia") == "mhi":
        base, lado = mhi_modelo(cfg)
        return f"{MHI_NOMBRES[base]} {'minoría' if lado == 'min' else 'mayoría'} (en prueba)"
    tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
    ant = " · anticipado" if cfg.get("bbrsi_momento") == "anticipado" else ""
    return f"BB + RSI (M{tf}: BB {per},{k:g} · RSI {rp} {alto}/{bajo}){ant}"


# =====================================================================
#  ESTRATEGIAS DEL CATÁLOGO (apartado "Estrategias"): 104 estrategias más Bollinger + RSI, Bollinger y RSI.
#  Una sola prendida: opera como siempre. Varias ("multi"): el bot mide en vivo cada una en todos los pares y
#  entra con la combinación par + estrategia que mejor va (si pasa el acierto y las señales mínimas).
#  El código de las estrategias es el de IQNOVA CATÁLOGO, guardado aquí dentro (las actualizaciones solo
#  traen iq_bot.py, app_gui.py e interfaz.html).
# =====================================================================
PROPIAS = ("bbrsi", "boll", "rsi")
NOMBRE_PROPIA = {"bbrsi": "Bollinger + RSI", "boll": "Bollinger", "rsi": "RSI"}
CAT_EXCLUIR = ("Bollinger + RSI",)          # el Bollinger + RSI del catálogo es el mismo que el del bot
MULTI_RANGO_ACIERTO = (50, 90)      # acierto mínimo editable (%)
MULTI_RANGO_SENALES = (10, 1000)    # señales mínimas editables
MULTI_K = 20                                 # peso del promedio de la estrategia en todos los pares (contra la suerte)
MULTI_RECIENTES = 20
MULTI_VENTANA = 130                          # velas para los indicadores en vivo
_CAT = None


def catalogo_mod():
    """El módulo de estrategias del catálogo (se arma una sola vez)."""
    global _CAT
    if _CAT is None:
        import types
        m = types.ModuleType("iqnova_estrategias")
        exec(compile(_CAT_SRC, "estrategias_catalogo", "exec"), m.__dict__)
        info = {}
        exec(compile(_CAT_INFO_SRC, "info_estrategias", "exec"), info)
        m.INFO = info.get("INFO", {})
        m.IDX = {n: k for k, n in enumerate(m.NOMBRES)}
        m.LISTA = [n for n in m.NOMBRES if n not in CAT_EXCLUIR]
        _CAT = m
    return _CAT


def catalogo_lista():
    """[{n, g, d}] de las estrategias del catálogo para la pantalla (nombre, grupo y explicación corta)."""
    m = catalogo_mod()
    return [{"n": n, "g": (m.INFO.get(n) or ("Otras", ""))[0], "d": (m.INFO.get(n) or ("", ""))[1]} for n in m.LISTA]


def estrategias_on(cfg):
    """Las estrategias prendidas en el apartado Estrategias (las propias primero)."""
    lista = cfg.get("estrategias_on")
    if lista == "todas":
        try:
            lista = list(PROPIAS) + list(catalogo_mod().LISTA)
        except Exception:
            lista = list(PROPIAS)
    if not isinstance(lista, list):
        lista = [cfg.get("estrategia") if cfg.get("estrategia") in PROPIAS else "bbrsi"]
    validas = set(PROPIAS)
    try:
        validas |= set(catalogo_mod().LISTA)
    except Exception:
        pass
    vistas, out = set(), []
    for x in lista:
        if isinstance(x, str) and x in validas and x not in vistas:
            vistas.add(x); out.append(x)
    return out


def estrategia_de(lista):
    """Con una sola propia prendida: esa (como siempre). Con varias o con alguna del catálogo: "multi"."""
    if len(lista) == 1 and lista[0] in PROPIAS:
        return lista[0]
    return "multi" if lista else "bbrsi"


def multi_minimos(cfg):
    try:
        a = int(cfg.get("multi_min_acierto", 55))
    except (TypeError, ValueError):
        a = 55
    try:
        n = int(cfg.get("multi_min_senales", 150))
    except (TypeError, ValueError):
        n = 150
    a = min(MULTI_RANGO_ACIERTO[1], max(MULTI_RANGO_ACIERTO[0], a))
    n = min(MULTI_RANGO_SENALES[1], max(MULTI_RANGO_SENALES[0], n))
    return a / 100.0, n


def senal_propia(clave, cierres, cfg):
    if clave == "rsi":
        return senal_rsi(cierres, cfg)
    if clave == "boll":
        return senal_boll(cierres, cfg)
    return senal(cierres, cfg)


class MedidorEstrategias:
    """Mide en vivo cada estrategia en cada par y temporalidad: si la vela siguiente a su señal cerró a favor
    (acierto a la 1ª). Se guarda entre sesiones (medidas_estrategias.json) para juntar más señales."""

    def __init__(self, cfg):
        self.lock = threading.RLock()
        self.cfg = cfg
        self.st, self.rec, self.pool, self.hasta, self.pend = {}, {}, {}, {}, {}
        self.firmas = {}
        self._t_guardar = time.time()
        self.archivo = _ruta_broker("medidas_estrategias.json")
        try:
            with open(self.archivo, encoding="utf-8") as f:
                d = json.load(f)
            self.st = {k: list(v)[:2] for k, v in (d.get("st") or {}).items()}
            self.rec = {k: list(v)[-MULTI_RECIENTES:] for k, v in (d.get("rec") or {}).items()}
            self.hasta = {k: int(v) for k, v in (d.get("hasta") or {}).items()}
            self.firmas = dict(d.get("firmas") or {})
        except Exception:
            pass
        # si cambiaste los valores de Bollinger + RSI, Bollinger o RSI, sus medidas viejas ya no sirven
        for p in PROPIAS:
            f = self.firma(p)
            if self.firmas.get(p) != f:
                for k in [k for k in self.st if k.endswith("|" + p)]:
                    self.st.pop(k, None); self.rec.pop(k, None)
                self.firmas[p] = f
        self.rehacer_pool()

    def firma(self, p):
        c = self.cfg
        if p == "rsi":
            return json.dumps(rsi_params(c))
        if p == "boll":
            return json.dumps(boll_params(c)[:2] + (boll_params(c)[3],))
        return json.dumps([bbrsi_valores(c, t) for t in TEMPORALIDADES])

    def rehacer_pool(self):
        pool = {}
        for key, (n, g) in list(self.st.items()):
            try:
                _par, tf, nombre = key.split("|", 2)
            except ValueError:
                continue
            p = pool.setdefault((int(tf), nombre), [0, 0])
            p[0] += n; p[1] += g
        self.pool = pool

    def guardar(self, forzar=False):
        if not forzar and time.time() - self._t_guardar < 120:
            return
        self._t_guardar = time.time()
        with self.lock:
            d = {"v": 1, "st": dict(self.st), "rec": dict(self.rec), "hasta": dict(self.hasta), "firmas": dict(self.firmas)}
        try:
            tmp = self.archivo + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(tmp, self.archivo)
        except Exception:
            pass

    def procesar(self, par, tf, velas):
        """Velas CERRADAS del par: resuelve las señales pendientes y anota las nuevas (todas las estrategias)."""
        m = catalogo_mod()
        if len(velas) < m.VENTANA_MIN + 2:
            return 0
        clave = f"{par}|{tf}"
        desde = self.hasta.get(clave, 0)
        nuevas = [i for i, v in enumerate(velas) if v["t"] > desde and i >= m.VENTANA_MIN]
        if not nuevas:
            return 0
        a = max(0, nuevas[0] - MULTI_VENTANA)
        serie = m.Serie(velas[a:], tf)
        solo = {m.IDX[n] for n in m.LISTA}
        anotadas = 0
        with self.lock:
            pend = self.pend.setdefault((par, tf), [])
            for i in nuevas:
                j = i - a
                if j >= 1 and serie.t[j] - serie.t[j - 1] != tf * 60:
                    pend.clear()                          # hueco en las velas: esas señales no se pueden resolver
                mov = serie.c[j] - serie.c[j - 1] if j >= 1 else 0.0
                for nombre, d in pend:
                    if not mov:
                        continue                          # empate: no cuenta
                    gano = (mov > 0) == (d == "call")
                    key = f"{par}|{tf}|{nombre}"
                    w = self.st.setdefault(key, [0, 0]); w[0] += 1; w[1] += 1 if gano else 0
                    pw = self.pool.setdefault((tf, nombre), [0, 0]); pw[0] += 1; pw[1] += 1 if gano else 0
                    r = self.rec.setdefault(key, []); r.append(1 if gano else 0); del r[:-MULTI_RECIENTES]
                pend.clear()
                for k, d in m.senales(serie, j, solo=solo).items():
                    pend.append((m.NOMBRES[k], d)); anotadas += 1
                cierres = serie.c[max(0, j - 160):j + 1]
                for p in PROPIAS:
                    try:
                        d, _ = senal_propia(p, cierres, self.cfg)
                    except Exception:
                        d = None
                    if d:
                        pend.append((p, d)); anotadas += 1
                self.hasta[clave] = serie.t[j]
        return anotadas

    def acierto(self, par, tf, nombre):
        """(acierto estimado a la 1ª, señales medidas en este par). Con pocas señales pesa el promedio de la
        estrategia en todos los pares; lo reciente (últimas 20) pesa la mitad."""
        key = f"{par}|{tf}|{nombre}"
        n, g = self.st.get(key) or (0, 0)
        pn, pg = self.pool.get((tf, nombre)) or (0, 0)
        base = (pg / pn) if pn else 0.5
        q = (g + MULTI_K * base) / (n + MULTI_K)
        r = self.rec.get(key) or []
        q = 0.5 * q + 0.5 * ((sum(r) + 5 * q) / (len(r) + 5))
        return q, n

    def elegibles(self, par, tf, activos, min_a, min_n):
        out = {}
        for nombre in activos:
            q, n = self.acierto(par, tf, nombre)
            if n >= min_n and q >= min_a:
                out[nombre] = (q, n)
        return out


_CAT_SRC = r'''# -*- coding: utf-8 -*-
"""
Estrategias de IQNOVA CATÁLOGO.

Son las estrategias que tenía la primera versión del bot (ciclos/cuadrantes, patrones de velas,
indicadores) más Bollinger + RSI de IQNOVA BOT con su configuración por temporalidad.
El código viejo ya no existía, así que están reescritas a partir de sus reglas.

Cada estrategia recibe una Serie (velas de un par en una temporalidad, con los indicadores
calculados UNA vez para toda la serie) y el índice i de la vela que acaba de cerrar.
Devuelve "call", "put" o None. La entrada es en la vela siguiente (i + 1).
"""

import math

CALL, PUT = "call", "put"


# =====================================================================
#  SERIE: velas + indicadores calculados una sola vez
# =====================================================================

class Serie:
    def __init__(self, velas, tf):
        self.v = velas
        self.tf = tf
        self.t = [int(x["t"]) for x in velas]
        self.o = [float(x["o"]) for x in velas]
        self.h = [float(x["h"]) for x in velas]
        self.l = [float(x["l"]) for x in velas]
        self.c = [float(x["c"]) for x in velas]
        self.n = len(velas)
        self._k = {}

    def _memo(self, clave, fn):
        if clave not in self._k:
            self._k[clave] = fn()
        return self._k[clave]

    # ---------- velas ----------
    def color(self, i):
        if i < 0 or i >= self.n:
            return 0
        d = self.c[i] - self.o[i]
        if abs(d) <= 1e-12 * max(1.0, abs(self.c[i])):
            return 0
        return 1 if d > 0 else -1

    def cuerpo(self, i):
        return abs(self.c[i] - self.o[i])

    def rango(self, i):
        return self.h[i] - self.l[i]

    def mecha_arriba(self, i):
        return self.h[i] - max(self.o[i], self.c[i])

    def mecha_abajo(self, i):
        return min(self.o[i], self.c[i]) - self.l[i]

    def pos_cuadrante(self, i):
        """Posición 0..4 de la vela i dentro de su cuadrante de 5 velas (alineado al reloj)."""
        return (self.t[i] // (self.tf * 60)) % 5

    def cuerpo_medio(self, i, n=10):
        a = max(0, i - n + 1)
        w = [self.cuerpo(k) for k in range(a, i + 1)]
        return sum(w) / len(w) if w else 0.0

    # ---------- indicadores ----------
    def sma(self, n, fuente="c"):
        def calc():
            x = getattr(self, fuente)
            out = [None] * self.n
            s = 0.0
            for i, v in enumerate(x):
                s += v
                if i >= n:
                    s -= x[i - n]
                if i >= n - 1:
                    out[i] = s / n
            return out
        return self._memo(("sma", n, fuente), calc)

    def ema(self, n, fuente="c"):
        def calc():
            x = getattr(self, fuente)
            out = [None] * self.n
            if self.n < n:
                return out
            k = 2.0 / (n + 1)
            e = sum(x[:n]) / n
            out[n - 1] = e
            for i in range(n, self.n):
                e = x[i] * k + e * (1 - k)
                out[i] = e
            return out
        return self._memo(("ema", n, fuente), calc)

    def _ema_lista(self, x, n):
        out = [None] * len(x)
        vals = [(i, v) for i, v in enumerate(x) if v is not None]
        if len(vals) < n:
            return out
        k = 2.0 / (n + 1)
        i0 = vals[n - 1][0]
        e = sum(v for _, v in vals[:n]) / n
        out[i0] = e
        for i in range(i0 + 1, len(x)):
            if x[i] is None:
                continue
            e = x[i] * k + e * (1 - k)
            out[i] = e
        return out

    def smma(self, n, fuente="mediana"):
        def calc():
            x = self.mediana() if fuente == "mediana" else getattr(self, fuente)
            out = [None] * self.n
            if self.n < n:
                return out
            s = sum(x[:n]) / n
            out[n - 1] = s
            for i in range(n, self.n):
                s = (s * (n - 1) + x[i]) / n
                out[i] = s
            return out
        return self._memo(("smma", n, fuente), calc)

    def mediana(self):
        return self._memo("mediana", lambda: [(a + b) / 2 for a, b in zip(self.h, self.l)])

    def rsi(self, n):
        def calc():
            out = [None] * self.n
            c = self.c
            if self.n <= n:
                return out
            g = p = 0.0
            for i in range(1, n + 1):
                d = c[i] - c[i - 1]
                g += max(d, 0.0); p += max(-d, 0.0)
            g /= n; p /= n
            out[n] = 100.0 if p == 0 else 100 - 100 / (1 + g / p)
            for i in range(n + 1, self.n):
                d = c[i] - c[i - 1]
                g = (g * (n - 1) + max(d, 0.0)) / n
                p = (p * (n - 1) + max(-d, 0.0)) / n
                out[i] = 100.0 if p == 0 else 100 - 100 / (1 + g / p)
            return out
        return self._memo(("rsi", n), calc)

    def bollinger(self, n, k):
        """(arriba, media, abajo) por vela."""
        def calc():
            c = self.c
            up, mid, lo = [None] * self.n, [None] * self.n, [None] * self.n
            for i in range(n - 1, self.n):
                w = c[i - n + 1:i + 1]
                m = sum(w) / n
                s = (sum((x - m) ** 2 for x in w) / n) ** 0.5
                up[i], mid[i], lo[i] = m + k * s, m, m - k * s
            return up, mid, lo
        return self._memo(("bb", n, k), calc)

    def atr(self, n=14):
        def calc():
            tr = [self.h[0] - self.l[0]]
            for i in range(1, self.n):
                tr.append(max(self.h[i] - self.l[i], abs(self.h[i] - self.c[i - 1]), abs(self.l[i] - self.c[i - 1])))
            out = [None] * self.n
            if self.n < n:
                return out
            a = sum(tr[:n]) / n
            out[n - 1] = a
            for i in range(n, self.n):
                a = (a * (n - 1) + tr[i]) / n
                out[i] = a
            return out
        return self._memo(("atr", n), calc)

    def estocastico(self, k=14, d=3):
        def calc():
            kk = [None] * self.n
            for i in range(k - 1, self.n):
                hh = max(self.h[i - k + 1:i + 1]); ll = min(self.l[i - k + 1:i + 1])
                kk[i] = 50.0 if hh == ll else 100 * (self.c[i] - ll) / (hh - ll)
            dd = [None] * self.n
            for i in range(self.n):
                w = kk[max(0, i - d + 1):i + 1]
                if len(w) == d and None not in w:
                    dd[i] = sum(w) / d
            return kk, dd
        return self._memo(("sto", k, d), calc)

    def macd(self, a=12, b=26, s=9):
        def calc():
            ea, eb = self.ema(a), self.ema(b)
            m = [x - y if x is not None and y is not None else None for x, y in zip(ea, eb)]
            sig = self._ema_lista(m, s)
            return m, sig
        return self._memo(("macd", a, b, s), calc)

    def cci(self, n=20):
        def calc():
            tp = [(h + l + c) / 3 for h, l, c in zip(self.h, self.l, self.c)]
            out = [None] * self.n
            for i in range(n - 1, self.n):
                w = tp[i - n + 1:i + 1]
                m = sum(w) / n
                md = sum(abs(x - m) for x in w) / n
                out[i] = 0.0 if md == 0 else (tp[i] - m) / (0.015 * md)
            return out
        return self._memo(("cci", n), calc)

    def williams(self, n=14):
        def calc():
            out = [None] * self.n
            for i in range(n - 1, self.n):
                hh = max(self.h[i - n + 1:i + 1]); ll = min(self.l[i - n + 1:i + 1])
                out[i] = -50.0 if hh == ll else -100 * (hh - self.c[i]) / (hh - ll)
            return out
        return self._memo(("wr", n), calc)

    def adx(self, n=14):
        """(adx, +DI, -DI) por vela."""
        def calc():
            adx, pdi, mdi = [None] * self.n, [None] * self.n, [None] * self.n
            if self.n < 2 * n + 2:
                return adx, pdi, mdi
            tr, pdm, mdm = [0.0], [0.0], [0.0]
            for i in range(1, self.n):
                up, dn = self.h[i] - self.h[i - 1], self.l[i - 1] - self.l[i]
                pdm.append(up if up > dn and up > 0 else 0.0)
                mdm.append(dn if dn > up and dn > 0 else 0.0)
                tr.append(max(self.h[i] - self.l[i], abs(self.h[i] - self.c[i - 1]), abs(self.l[i] - self.c[i - 1])))
            a = sum(tr[1:n + 1]); sp = sum(pdm[1:n + 1]); sm = sum(mdm[1:n + 1])
            dxs = []
            for i in range(n + 1, self.n):
                a = a - a / n + tr[i]; sp = sp - sp / n + pdm[i]; sm = sm - sm / n + mdm[i]
                if a <= 0:
                    dxs.append((i, 0.0)); continue
                p, m = 100 * sp / a, 100 * sm / a
                pdi[i], mdi[i] = p, m
                dxs.append((i, 100 * abs(p - m) / (p + m) if p + m > 0 else 0.0))
            if len(dxs) < n:
                return adx, pdi, mdi
            x = sum(d for _, d in dxs[:n]) / n
            adx[dxs[n - 1][0]] = x
            for i, d in dxs[n:]:
                x = (x * (n - 1) + d) / n
                adx[i] = x
            return adx, pdi, mdi
        return self._memo(("adx", n), calc)

    def sar(self, paso=0.02, maximo=0.2):
        """Parabolic SAR: (valor, tendencia +1/-1) por vela."""
        def calc():
            val, tend = [None] * self.n, [0] * self.n
            if self.n < 3:
                return val, tend
            up = self.c[1] >= self.c[0]
            ep = self.h[1] if up else self.l[1]
            s = self.l[0] if up else self.h[0]
            af = paso
            for i in range(2, self.n):
                s = s + af * (ep - s)
                if up:
                    s = min(s, self.l[i - 1], self.l[i - 2])
                    if self.l[i] < s:
                        up, s, ep, af = False, ep, self.l[i], paso
                    elif self.h[i] > ep:
                        ep, af = self.h[i], min(maximo, af + paso)
                else:
                    s = max(s, self.h[i - 1], self.h[i - 2])
                    if self.h[i] > s:
                        up, s, ep, af = True, ep, self.h[i], paso
                    elif self.l[i] < ep:
                        ep, af = self.l[i], min(maximo, af + paso)
                val[i], tend[i] = s, (1 if up else -1)
            return val, tend
        return self._memo(("sar", paso, maximo), calc)

    def supertrend(self, n=10, k=3.0):
        """Tendencia +1/-1 por vela."""
        def calc():
            atr = self.atr(n)
            tend = [0] * self.n
            fu = fl = None
            t = 1
            for i in range(self.n):
                if atr[i] is None:
                    continue
                m = (self.h[i] + self.l[i]) / 2
                bu, bl = m + k * atr[i], m - k * atr[i]
                if fu is None:
                    fu, fl = bu, bl
                else:
                    fu = bu if (bu < fu or self.c[i - 1] > fu) else fu
                    fl = bl if (bl > fl or self.c[i - 1] < fl) else fl
                if t == 1 and self.c[i] < fl:
                    t = -1
                elif t == -1 and self.c[i] > fu:
                    t = 1
                tend[i] = t
            return tend
        return self._memo(("st", n, k), calc)

    def vortex(self, n=14):
        def calc():
            vp, vm = [None] * self.n, [None] * self.n
            for i in range(n, self.n):
                sp = sum(abs(self.h[j] - self.l[j - 1]) for j in range(i - n + 1, i + 1))
                sm = sum(abs(self.l[j] - self.h[j - 1]) for j in range(i - n + 1, i + 1))
                tr = sum(max(self.h[j] - self.l[j], abs(self.h[j] - self.c[j - 1]), abs(self.l[j] - self.c[j - 1]))
                         for j in range(i - n + 1, i + 1))
                if tr > 0:
                    vp[i], vm[i] = sp / tr, sm / tr
            return vp, vm
        return self._memo(("vortex", n), calc)

    def aroon(self, n=14):
        def calc():
            au, ad = [None] * self.n, [None] * self.n
            for i in range(n, self.n):
                wh = self.h[i - n:i + 1]; wl = self.l[i - n:i + 1]
                ih = n - max(range(n + 1), key=lambda j: (wh[j], j))
                il = n - min(range(n + 1), key=lambda j: (wl[j], -j))
                au[i], ad[i] = 100.0 * (n - ih) / n, 100.0 * (n - il) / n
            return au, ad
        return self._memo(("aroon", n), calc)

    def demarker(self, n=14):
        def calc():
            dmx = [0.0] + [max(self.h[i] - self.h[i - 1], 0.0) for i in range(1, self.n)]
            dmn = [0.0] + [max(self.l[i - 1] - self.l[i], 0.0) for i in range(1, self.n)]
            out = [None] * self.n
            for i in range(n, self.n):
                a = sum(dmx[i - n + 1:i + 1]); b = sum(dmn[i - n + 1:i + 1])
                out[i] = 0.5 if a + b == 0 else a / (a + b)
            return out
        return self._memo(("dem", n), calc)

    def awesome(self):
        def calc():
            a, b = self.sma(5, "medianas"), self.sma(34, "medianas")
            return [x - y if x is not None and y is not None else None for x, y in zip(a, b)]
        self.medianas = self.mediana()
        return self._memo("ao", calc)

    def heikin(self):
        """(apertura, cierre) Heikin Ashi por vela."""
        def calc():
            ho, hc = [0.0] * self.n, [0.0] * self.n
            for i in range(self.n):
                hc[i] = (self.o[i] + self.h[i] + self.l[i] + self.c[i]) / 4
                ho[i] = (self.o[i] + self.c[i]) / 2 if i == 0 else (ho[i - 1] + hc[i - 1]) / 2
            return ho, hc
        return self._memo("ha", calc)

    def maximo(self, i, n):
        return max(self.h[max(0, i - n + 1):i + 1])

    def minimo(self, i, n):
        return min(self.l[max(0, i - n + 1):i + 1])


def _cruza_arriba(a, b, i):
    return (i >= 1 and None not in (a[i - 1], b[i - 1], a[i], b[i]) and a[i - 1] <= b[i - 1] and a[i] > b[i])


def _cruza_abajo(a, b, i):
    return (i >= 1 and None not in (a[i - 1], b[i - 1], a[i], b[i]) and a[i - 1] >= b[i - 1] and a[i] < b[i])


def _dir(col):
    return CALL if col > 0 else (PUT if col < 0 else None)


def _mayoria(cols):
    if 0 in cols:
        return None                  # con doji no se opera
    s = sum(cols)
    return _dir(1 if s > 0 else -1)


def _minoria(cols):
    if 0 in cols:
        return None
    s = sum(cols)
    return _dir(-1 if s > 0 else 1)


# =====================================================================
#  CICLOS / CUADRANTES (cuadrante = 5 velas alineadas al reloj)
#  i = vela que cierra; la entrada es la vela i+1, en la posición p
# =====================================================================

def _entra_en(s, i, p):
    """True si la vela siguiente a i (la de la entrada) es la posición p del cuadrante."""
    return (s.pos_cuadrante(i) + 1) % 5 == p


def mhi(s, i, p, minoria=True):
    # MHI 1/2/3: entra en la 1a/2a/3a vela del cuadrante con la minoría (o mayoría)
    # de las 3 últimas velas del cuadrante anterior
    if not _entra_en(s, i, p) or i < 7:
        return None
    fin = i - p                       # última vela del cuadrante anterior
    cols = [s.color(fin - 2), s.color(fin - 1), s.color(fin)]
    return _minoria(cols) if minoria else _mayoria(cols)


def milhao(s, i, minoria=False):
    # Milhão: entra en la 1a vela del cuadrante con la mayoría (o minoría) de las 5 velas del anterior
    if not _entra_en(s, i, 0) or i < 5:
        return None
    return (_minoria if minoria else _mayoria)([s.color(k) for k in range(i - 4, i + 1)])


def torres_gemelas(s, i):
    # entra en la 5a vela con el color de la 1a vela del cuadrante
    return _dir(s.color(i - 3)) if _entra_en(s, i, 4) else None


def tres_mosqueteros(s, i):
    # entra en la 4a vela con el color de la 3a
    return _dir(s.color(i)) if _entra_en(s, i, 3) else None


def tres_vecinos(s, i):
    # entra en la 5a vela con el color de la 4a
    return _dir(s.color(i)) if _entra_en(s, i, 4) else None


def padron_23(s, i):
    # entra en la 2a vela con el color de la 1a
    return _dir(s.color(i)) if _entra_en(s, i, 1) else None


def mejor_de_3(s, i):
    # entra en la 3a vela con la mayoría de las 3 velas del centro (2a, 3a, 4a) del cuadrante anterior
    if not _entra_en(s, i, 2) or i < 6:
        return None
    return _mayoria([s.color(i - 5), s.color(i - 4), s.color(i - 3)])


def patron_3x1(s, i):
    # entra en la 5a vela con la minoría de las 3 primeras velas del cuadrante
    if not _entra_en(s, i, 4):
        return None
    return _minoria([s.color(i - 3), s.color(i - 2), s.color(i - 1)])


def minoria_3(s, i):
    return _minoria([s.color(i - 2), s.color(i - 1), s.color(i)]) if i >= 2 else None


def mayoria_3(s, i):
    return _mayoria([s.color(i - 2), s.color(i - 1), s.color(i)]) if i >= 2 else None


# =====================================================================
#  PATRONES DE VELAS
# =====================================================================

def envolvente(s, i):
    if i < 1:
        return None
    a, b = i - 1, i
    if s.color(a) == -1 and s.color(b) == 1 and s.c[b] >= s.o[a] and s.o[b] <= s.c[a] and s.cuerpo(b) > s.cuerpo(a):
        return CALL
    if s.color(a) == 1 and s.color(b) == -1 and s.c[b] <= s.o[a] and s.o[b] >= s.c[a] and s.cuerpo(b) > s.cuerpo(a):
        return PUT
    return None


def pinbar(s, i):
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    cu = s.cuerpo(i)
    if s.mecha_abajo(i) >= 2 * cu and s.mecha_abajo(i) >= 0.6 * r and s.l[i] <= s.minimo(i - 1, 5):
        return CALL
    if s.mecha_arriba(i) >= 2 * cu and s.mecha_arriba(i) >= 0.6 * r and s.h[i] >= s.maximo(i - 1, 5):
        return PUT
    return None


def tres_soldados(s, i):
    if i < 2:
        return None
    w = [i - 2, i - 1, i]
    if all(s.color(k) == 1 for k in w) and s.c[w[0]] < s.c[w[1]] < s.c[w[2]]:
        return CALL
    if all(s.color(k) == -1 for k in w) and s.c[w[0]] > s.c[w[1]] > s.c[w[2]]:
        return PUT
    return None


def harami(s, i):
    if i < 1:
        return None
    a, b = i - 1, i
    if s.cuerpo(a) < 1.2 * s.cuerpo_medio(a) or s.cuerpo(b) == 0:
        return None
    dentro = max(s.o[b], s.c[b]) <= max(s.o[a], s.c[a]) and min(s.o[b], s.c[b]) >= min(s.o[a], s.c[a])
    if dentro and s.color(a) == -1 and s.color(b) == 1:
        return CALL
    if dentro and s.color(a) == 1 and s.color(b) == -1:
        return PUT
    return None


def tres_dentro(s, i):
    # harami confirmado: la tercera vela cierra más allá de la apertura de la primera
    if i < 2:
        return None
    a, b, c = i - 2, i - 1, i
    dentro = max(s.o[b], s.c[b]) <= max(s.o[a], s.c[a]) and min(s.o[b], s.c[b]) >= min(s.o[a], s.c[a])
    if not dentro:
        return None
    if s.color(a) == -1 and s.color(b) == 1 and s.color(c) == 1 and s.c[c] > s.o[a]:
        return CALL
    if s.color(a) == 1 and s.color(b) == -1 and s.color(c) == -1 and s.c[c] < s.o[a]:
        return PUT
    return None


def estrella(s, i):
    # estrella de la mañana / de la tarde
    if i < 2:
        return None
    a, b, c = i - 2, i - 1, i
    med = s.cuerpo_medio(a)
    if med <= 0 or s.cuerpo(b) > 0.5 * s.cuerpo(a):
        return None
    if s.color(a) == -1 and s.cuerpo(a) >= med and s.color(c) == 1 and s.c[c] > (s.o[a] + s.c[a]) / 2:
        return CALL
    if s.color(a) == 1 and s.cuerpo(a) >= med and s.color(c) == -1 and s.c[c] < (s.o[a] + s.c[a]) / 2:
        return PUT
    return None


def pinzas(s, i):
    if i < 1:
        return None
    a, b = i - 1, i
    tol = 0.1 * max(s.rango(a), s.rango(b), 1e-12)
    if s.color(a) == -1 and s.color(b) == 1 and abs(s.l[a] - s.l[b]) <= tol:
        return CALL
    if s.color(a) == 1 and s.color(b) == -1 and abs(s.h[a] - s.h[b]) <= tol:
        return PUT
    return None


def barra_interna(s, i):
    # barra interna (i-1 dentro de i-2) y ruptura de la vela madre al cierre de i
    if i < 2:
        return None
    m, d = i - 2, i - 1
    if not (s.h[d] <= s.h[m] and s.l[d] >= s.l[m]):
        return None
    if s.c[i] > s.h[m]:
        return CALL
    if s.c[i] < s.l[m]:
        return PUT
    return None


def heikin_ashi(s, i):
    # cambio de color Heikin Ashi después de 3 velas del mismo color
    if i < 4:
        return None
    ho, hc = s.heikin()
    col = lambda k: 1 if hc[k] > ho[k] else (-1 if hc[k] < ho[k] else 0)
    if col(i) == 1 and col(i - 1) == col(i - 2) == col(i - 3) == -1:
        return CALL
    if col(i) == -1 and col(i - 1) == col(i - 2) == col(i - 3) == 1:
        return PUT
    return None


def fractal(s, i):
    # fractal confirmado en i-2 (mínimo/máximo de 5 velas)
    if i < 4:
        return None
    k = i - 2
    if s.l[k] < min(s.l[k - 2], s.l[k - 1], s.l[k + 1], s.l[k + 2]) and s.color(i) == 1:
        return CALL
    if s.h[k] > max(s.h[k - 2], s.h[k - 1], s.h[k + 1], s.h[k + 2]) and s.color(i) == -1:
        return PUT
    return None


def rechazo_racha(s, i):
    # 4 velas seguidas del mismo color: entra en contra
    if i < 3:
        return None
    cols = [s.color(k) for k in range(i - 3, i + 1)]
    if all(x == 1 for x in cols):
        return PUT
    if all(x == -1 for x in cols):
        return CALL
    return None


def rechazo_racha_5(s, i):
    # 5 velas seguidas del mismo color: entra en contra (apuesta a que la siguiente cambia de color)
    if i < 4:
        return None
    cols = [s.color(k) for k in range(i - 4, i + 1)]
    if all(x == 1 for x in cols):
        return PUT
    if all(x == -1 for x in cols):
        return CALL
    return None


def agotamiento(s, i):
    # vela muy grande (casi 2 ATR) que cierra en la mitad contraria: se agotó, entra en contra
    atr = s.atr(14)[i - 1] if i >= 1 else None
    if not atr or s.rango(i) < 1.8 * atr:
        return None
    mitad = (s.h[i] + s.l[i]) / 2
    if s.c[i - 1] > s.c[i - 2] and s.c[i] < mitad and s.mecha_arriba(i) > s.cuerpo(i):
        return PUT
    if s.c[i - 1] < s.c[i - 2] and s.c[i] > mitad and s.mecha_abajo(i) > s.cuerpo(i):
        return CALL
    return None


def fluxo_velas(s, i):
    # flujo: 3 velas del mismo color con cuerpo firme (60 %+ del rango): a favor del flujo
    if i < 2:
        return None
    w = [i - 2, i - 1, i]
    firmes = all(s.rango(k) > 0 and s.cuerpo(k) >= 0.6 * s.rango(k) for k in w)
    if firmes and all(s.color(k) == 1 for k in w):
        return CALL
    if firmes and all(s.color(k) == -1 for k in w):
        return PUT
    return None


def retracao_vela(s, i):
    # retração: vela muy grande (1,8x el cuerpo medio): la siguiente devuelve parte del cuerpo
    if i < 10:
        return None
    med = s.cuerpo_medio(i - 1, 10)
    if med <= 0 or s.cuerpo(i) < 1.8 * med:
        return None
    return _dir(-s.color(i))


# =====================================================================
#  INDICADORES
# =====================================================================

def rsi_extremo(s, i):
    r = s.rsi(14)
    if i < 1 or r[i] is None or r[i - 1] is None:
        return None
    if r[i - 1] < 30 <= r[i]:
        return CALL
    if r[i - 1] > 70 >= r[i]:
        return PUT
    return None


def rsi_2(s, i):
    r = s.rsi(2)[i]
    if r is None:
        return None
    return CALL if r < 10 else (PUT if r > 90 else None)


def bollinger_rechazo(s, i):
    up, _m, lo = s.bollinger(20, 2.0)
    if up[i] is None:
        return None
    if s.l[i] < lo[i] < s.c[i]:
        return CALL
    if s.h[i] > up[i] > s.c[i]:
        return PUT
    return None


def doji_bollinger(s, i):
    up, _m, lo = s.bollinger(20, 2.0)
    if up[i] is None or s.rango(i) <= 0 or s.cuerpo(i) > 0.15 * s.rango(i):
        return None
    if s.l[i] <= lo[i]:
        return CALL
    if s.h[i] >= up[i]:
        return PUT
    return None


BBRSI_PRESETS = {   # igual que IQNOVA BOT: (periodo Bollinger, desviaciones, periodo RSI, alto, bajo)
    1: (20, 2.5, 14, 75, 25),
    2: (20, 2.0, 7, 80, 20),
    3: (20, 2.0, 14, 75, 25),
    4: (20, 2.5, 14, 75, 25),
    5: (20, 2.5, 7, 80, 20),
}


def bollinger_rsi(s, i):
    per, k, rp, alto, bajo = BBRSI_PRESETS.get(s.tf, BBRSI_PRESETS[2])
    up, _m, lo = s.bollinger(per, k)
    r = s.rsi(rp)[i]
    if up[i] is None or r is None:
        return None
    if s.c[i] > up[i] and r > alto:
        return PUT
    if s.c[i] < lo[i] and r < bajo:
        return CALL
    return None


def keltner(s, i):
    e, a = s.ema(20)[i], s.atr(10)[i]
    if e is None or a is None:
        return None
    if s.c[i] < e - 2 * a:
        return CALL
    if s.c[i] > e + 2 * a:
        return PUT
    return None


def cruce_ema(s, i, a, b):
    ea, eb = s.ema(a), s.ema(b)
    if _cruza_arriba(ea, eb, i):
        return CALL
    if _cruza_abajo(ea, eb, i):
        return PUT
    return None


def cruce_sma(s, i, a, b):
    sa, sb = s.sma(a), s.sma(b)
    if _cruza_arriba(sa, sb, i):
        return CALL
    if _cruza_abajo(sa, sb, i):
        return PUT
    return None


def pullback_ema(s, i):
    e50, e9 = s.ema(50)[i], s.ema(9)[i]
    if e50 is None or e9 is None:
        return None
    if s.c[i] > e50 and e9 > e50 and s.l[i] <= e9 <= s.c[i] and s.color(i) == 1:
        return CALL
    if s.c[i] < e50 and e9 < e50 and s.h[i] >= e9 >= s.c[i] and s.color(i) == -1:
        return PUT
    return None


def estocastico(s, i):
    k, d = s.estocastico(14, 3)
    if not _cruza_arriba(k, d, i) and not _cruza_abajo(k, d, i):
        return None
    if _cruza_arriba(k, d, i) and k[i] < 25:
        return CALL
    if _cruza_abajo(k, d, i) and k[i] > 75:
        return PUT
    return None


def macd_cruce(s, i):
    m, sig = s.macd()
    if _cruza_arriba(m, sig, i):
        return CALL
    if _cruza_abajo(m, sig, i):
        return PUT
    return None


def cci(s, i):
    x = s.cci(20)
    if i < 1 or x[i] is None or x[i - 1] is None:
        return None
    if x[i - 1] < -100 <= x[i]:
        return CALL
    if x[i - 1] > 100 >= x[i]:
        return PUT
    return None


def williams(s, i):
    w = s.williams(14)
    if i < 1 or w[i] is None or w[i - 1] is None:
        return None
    if w[i - 1] < -80 <= w[i]:
        return CALL
    if w[i - 1] > -20 >= w[i]:
        return PUT
    return None


def adx_di(s, i):
    adx, p, m = s.adx(14)
    if adx[i] is None or adx[i] < 25:
        return None
    if _cruza_arriba(p, m, i):
        return CALL
    if _cruza_abajo(p, m, i):
        return PUT
    return None


def parabolic_sar(s, i):
    _v, t = s.sar()
    if i < 1 or not t[i] or not t[i - 1] or t[i] == t[i - 1]:
        return None
    return _dir(t[i])


def supertrend(s, i):
    t = s.supertrend(10, 3.0)
    if i < 1 or not t[i] or not t[i - 1] or t[i] == t[i - 1]:
        return None
    return _dir(t[i])


def donchian(s, i):
    if i < 21:
        return None
    if s.c[i] > s.maximo(i - 1, 20):
        return CALL
    if s.c[i] < s.minimo(i - 1, 20):
        return PUT
    return None


def ichimoku(s, i):
    if i < 78:
        return None
    ten = lambda k: (s.maximo(k, 9) + s.minimo(k, 9)) / 2
    kij = lambda k: (s.maximo(k, 26) + s.minimo(k, 26)) / 2
    j = i - 26                                    # la nube que se ve en la vela i se calculó 26 velas antes
    sa = (ten(j) + kij(j)) / 2
    sb = (s.maximo(j, 52) + s.minimo(j, 52)) / 2
    arriba, abajo = max(sa, sb), min(sa, sb)
    if ten(i - 1) <= kij(i - 1) and ten(i) > kij(i) and s.c[i] > arriba:
        return CALL
    if ten(i - 1) >= kij(i - 1) and ten(i) < kij(i) and s.c[i] < abajo:
        return PUT
    return None


def awesome(s, i):
    ao = s.awesome()
    if i < 1 or ao[i] is None or ao[i - 1] is None:
        return None
    if ao[i - 1] <= 0 < ao[i]:
        return CALL
    if ao[i - 1] >= 0 > ao[i]:
        return PUT
    return None


def momentum(s, i):
    if i < 11:
        return None
    a, b = s.c[i] - s.c[i - 10], s.c[i - 1] - s.c[i - 11]
    if b <= 0 < a:
        return CALL
    if b >= 0 > a:
        return PUT
    return None


def vortex(s, i):
    vp, vm = s.vortex(14)
    if _cruza_arriba(vp, vm, i):
        return CALL
    if _cruza_abajo(vp, vm, i):
        return PUT
    return None


def aroon(s, i):
    au, ad = s.aroon(14)
    if _cruza_arriba(au, ad, i) and au[i] >= 70:
        return CALL
    if _cruza_abajo(au, ad, i) and ad[i] >= 70:
        return PUT
    return None


def alligator(s, i):
    # mandíbula SMMA13 (desplazada 8), dientes SMMA8 (5), labios SMMA5 (3): se abren y el precio sale de la boca
    if i < 25:
        return None
    jaw, teeth, lips = s.smma(13), s.smma(8), s.smma(5)
    def lineas(k):
        a, b, c = jaw[k - 8], teeth[k - 5], lips[k - 3]
        return None if None in (a, b, c) else (a, b, c)
    x, y = lineas(i), lineas(i - 1)
    if not x or not y:
        return None
    j, t, l = x
    j0, t0, l0 = y
    if l > t > j and not (l0 > t0 > j0) and s.c[i] > l:
        return CALL
    if l < t < j and not (l0 < t0 < j0) and s.c[i] < l:
        return PUT
    return None


def divergencia_rsi(s, i):
    r = s.rsi(14)
    if i < 25 or r[i] is None:
        return None
    a = i - 12
    lo_prev = min(range(a - 10, a + 1), key=lambda k: s.l[k])
    hi_prev = max(range(a - 10, a + 1), key=lambda k: s.h[k])
    if r[lo_prev] is not None and s.l[i] < s.l[lo_prev] and r[i] > r[lo_prev] + 3 and s.color(i) == 1:
        return CALL
    if r[hi_prev] is not None and s.h[i] > s.h[hi_prev] and r[i] < r[hi_prev] - 3 and s.color(i) == -1:
        return PUT
    return None


def demarker(s, i):
    d = s.demarker(14)
    if i < 1 or d[i] is None or d[i - 1] is None:
        return None
    if d[i - 1] < 0.3 <= d[i]:
        return CALL
    if d[i - 1] > 0.7 >= d[i]:
        return PUT
    return None


# =====================================================================
#  NIVELES
# =====================================================================

def rechazo_sr(s, i):
    # toca el mínimo/máximo de las últimas 50 velas y cierra lejos de él
    if i < 51:
        return None
    sop, res = s.minimo(i - 1, 50), s.maximo(i - 1, 50)
    tol = 0.1 * (s.atr(14)[i] or 0)
    if s.l[i] <= sop + tol and s.c[i] > sop and s.mecha_abajo(i) > s.cuerpo(i):
        return CALL
    if s.h[i] >= res - tol and s.c[i] < res and s.mecha_arriba(i) > s.cuerpo(i):
        return PUT
    return None


def retesteo(s, i):
    # rompió el máximo/mínimo de 20 velas en las últimas 5 y vuelve a probar ese nivel desde el otro lado
    if i < 30:
        return None
    for k in range(i - 5, i):
        nivel_h = s.maximo(k - 1, 20)
        nivel_l = s.minimo(k - 1, 20)
        if s.c[k] > nivel_h and s.l[i] <= nivel_h <= s.c[i] and s.color(i) == 1:
            return CALL
        if s.c[k] < nivel_l and s.h[i] >= nivel_l >= s.c[i] and s.color(i) == -1:
            return PUT
    return None


def numero_redondo(s, i):
    p = s.c[i]
    if p <= 0:
        return None
    paso = 10 ** (math.floor(math.log10(p)) - 2)        # 1.08xx -> 0.01 ; 150.xx -> 1
    nivel_bajo = math.floor(s.c[i] / paso) * paso
    nivel_alto = nivel_bajo + paso
    if s.l[i] <= nivel_bajo < s.c[i] and s.mecha_abajo(i) > s.cuerpo(i):
        return CALL
    if s.h[i] >= nivel_alto > s.c[i] and s.mecha_arriba(i) > s.cuerpo(i):
        return PUT
    return None


# =====================================================================
#  LISTA (nombre que se muestra, función)
# =====================================================================


# =====================================================================
#  1.16 · estrategias nuevas (12)
# =====================================================================

def alternancia(s, i):
    # 4 velas alternando colores (verde-roja-verde-roja): sigue la alternancia (la siguiente cambia de color)
    if i < 3:
        return None
    cols = [s.color(k) for k in range(i - 3, i + 1)]
    if 0 in cols or any(cols[k] == cols[k + 1] for k in range(3)):
        return None
    return _dir(-cols[-1])


def seguir_racha_3(s, i):
    # justo 3 velas seguidas del mismo color (la 4a anterior era de otro color): a favor de la racha
    if i < 3:
        return None
    c3 = [s.color(k) for k in range(i - 2, i + 1)]
    if 0 in c3 or len(set(c3)) != 1 or s.color(i - 3) == c3[0]:
        return None
    return _dir(c3[0])


def rechazo_racha_3(s, i):
    # 3 velas seguidas del mismo color: entra en contra
    if i < 2:
        return None
    c3 = [s.color(k) for k in range(i - 2, i + 1)]
    if 0 in c3 or len(set(c3)) != 1:
        return None
    return _dir(-c3[0])


def marubozu(s, i):
    # vela de cuerpo lleno (85 %+ del rango) y grande (1,5x el cuerpo medio): a favor de esa vela
    r = s.rango(i)
    if r <= 0 or i < 10:
        return None
    if s.cuerpo(i) >= 0.85 * r and s.cuerpo(i) >= 1.5 * s.cuerpo_medio(i - 1):
        return _dir(s.color(i))
    return None


def mecha_larga(s, i):
    # mecha de un lado de 2x el cuerpo y 55 %+ del rango: el precio fue rechazado, entra hacia el otro lado
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    cu, ar, ab = s.cuerpo(i), s.mecha_arriba(i), s.mecha_abajo(i)
    if ar >= 2 * max(cu, 1e-12) and ar >= 0.55 * r and ab < 0.2 * r:
        return PUT
    if ab >= 2 * max(cu, 1e-12) and ab >= 0.55 * r and ar < 0.2 * r:
        return CALL
    return None


def doji_tras_racha(s, i):
    # doji (cuerpo de 10 % o menos del rango) después de 3 velas del mismo color: se agotó, entra en contra
    r = s.rango(i)
    if r <= 0 or i < 3 or s.cuerpo(i) > 0.1 * r:
        return None
    c3 = [s.color(k) for k in range(i - 3, i)]
    if 0 in c3 or len(set(c3)) != 1:
        return None
    return _dir(-c3[0])


def rsi_cruce_50(s, i):
    # el RSI 14 cruza la línea de 50: a favor del cruce
    r = s.rsi(14)
    if i < 1 or r[i] is None or r[i - 1] is None:
        return None
    if r[i - 1] <= 50 < r[i]:
        return CALL
    if r[i - 1] >= 50 > r[i]:
        return PUT
    return None


def macd_cruce_cero(s, i):
    # la línea MACD cruza el cero: a favor del cruce
    m, _sig = s.macd()
    if i < 1 or m[i] is None or m[i - 1] is None:
        return None
    if m[i - 1] <= 0 < m[i]:
        return CALL
    if m[i - 1] >= 0 > m[i]:
        return PUT
    return None


def bollinger_squeeze(s, i):
    # bandas de Bollinger en su punto más angosto de las últimas 20 velas y la vela cierra fuera: sigue la ruptura
    up, mid, lo = s.bollinger(20, 2)
    if i < 40 or up[i] is None or up[i - 20] is None:
        return None
    ancho = [(up[k] - lo[k]) / mid[k] for k in range(i - 20, i) if up[k] is not None and mid[k]]
    if not ancho or (up[i - 1] - lo[i - 1]) / mid[i - 1] > min(ancho) * 1.05:
        return None
    if s.c[i] > up[i]:
        return CALL
    if s.c[i] < lo[i]:
        return PUT
    return None


def rebote_ema_20(s, i):
    # tendencia por la EMA 20 (sube o baja 3 velas seguidas); la vela toca la EMA y cierra a favor: sigue
    e = s.ema(20)
    if i < 25 or e[i] is None or e[i - 3] is None:
        return None
    sube = e[i] > e[i - 1] > e[i - 2] > e[i - 3]
    baja = e[i] < e[i - 1] < e[i - 2] < e[i - 3]
    if sube and s.l[i] <= e[i] < s.c[i] and s.color(i) == 1:
        return CALL
    if baja and s.h[i] >= e[i] > s.c[i] and s.color(i) == -1:
        return PUT
    return None


def tres_emas(s, i):
    # EMA 8 > 21 > 50 (o al revés) y la vela cierra a favor del lado de la EMA 8: sigue la tendencia
    a, b, c = s.ema(8), s.ema(21), s.ema(50)
    if a[i] is None or b[i] is None or c[i] is None:
        return None
    if a[i] > b[i] > c[i] and s.c[i] > a[i] and s.color(i) == 1:
        return CALL
    if a[i] < b[i] < c[i] and s.c[i] < a[i] and s.color(i) == -1:
        return PUT
    return None


def retroceso_tendencia(s, i):
    # tendencia por la EMA 50 y 2 velas en contra que no la cruzan: entra a favor de la tendencia
    e = s.ema(50)
    if i < 55 or e[i] is None or e[i - 5] is None:
        return None
    c2 = [s.color(i - 1), s.color(i)]
    if e[i] > e[i - 5] and c2 == [-1, -1] and min(s.l[i - 1], s.l[i]) > e[i]:
        return CALL
    if e[i] < e[i - 5] and c2 == [1, 1] and max(s.h[i - 1], s.h[i]) < e[i]:
        return PUT
    return None


# =====================================================================
#  1.19 · más estrategias (12)
# =====================================================================

def _wma_lista(x, n):
    out = [None] * len(x)
    pesos = list(range(1, n + 1)); tot = sum(pesos)
    for i in range(n - 1, len(x)):
        w = x[i - n + 1:i + 1]
        if None in w:
            continue
        out[i] = sum(a * b for a, b in zip(w, pesos)) / tot
    return out


def _hma(s, n):
    def calc():
        a, b = _wma_lista(s.c, max(1, n // 2)), _wma_lista(s.c, n)
        dif = [2 * x - y if x is not None and y is not None else None for x, y in zip(a, b)]
        return _wma_lista(dif, max(1, int(n ** 0.5)))
    return s._memo(("hma", n), calc)


def martillo_tras_racha(s, i):
    # 3 velas del mismo color y luego una vela con mecha larga en contra de la racha (martillo / estrella fugaz)
    r = s.rango(i)
    if r <= 0 or i < 3:
        return None
    c3 = [s.color(k) for k in range(i - 3, i)]
    if 0 in c3 or len(set(c3)) != 1:
        return None
    cu = s.cuerpo(i)
    if c3[0] == -1 and s.mecha_abajo(i) >= 2 * cu and s.mecha_abajo(i) >= 0.55 * r:
        return CALL
    if c3[0] == 1 and s.mecha_arriba(i) >= 2 * cu and s.mecha_arriba(i) >= 0.55 * r:
        return PUT
    return None


def barra_externa(s, i):
    # el rango de la vela cubre todo el de la anterior y cierra en su tercio extremo: sigue hacia ese lado
    if i < 1:
        return None
    r = s.rango(i)
    if r <= 0 or not (s.h[i] > s.h[i - 1] and s.l[i] < s.l[i - 1]):
        return None
    if s.c[i] >= s.l[i] + 2 * r / 3:
        return CALL
    if s.c[i] <= s.l[i] + r / 3:
        return PUT
    return None


def penetrante(s, i):
    # penetrante / nube oscura: vela que abre más allá y cierra pasando la mitad del cuerpo anterior
    if i < 1:
        return None
    a, b = i - 1, i
    mitad = (s.o[a] + s.c[a]) / 2
    if s.color(a) == -1 and s.color(b) == 1 and s.o[b] <= s.c[a] and mitad < s.c[b] < s.o[a]:
        return CALL
    if s.color(a) == 1 and s.color(b) == -1 and s.o[b] >= s.c[a] and s.o[a] < s.c[b] < mitad:
        return PUT
    return None


def cci_cruce_cero(s, i):
    x = s.cci(20)
    if i < 1 or x[i] is None or x[i - 1] is None:
        return None
    if x[i - 1] <= 0 < x[i]:
        return CALL
    if x[i - 1] >= 0 > x[i]:
        return PUT
    return None


def williams_cruce_50(s, i):
    w = s.williams(14)
    if i < 1 or w[i] is None or w[i - 1] is None:
        return None
    if w[i - 1] <= -50 < w[i]:
        return CALL
    if w[i - 1] >= -50 > w[i]:
        return PUT
    return None


def estocastico_cruce_50(s, i):
    k, _d = s.estocastico(14, 3)
    if i < 1 or k[i] is None or k[i - 1] is None:
        return None
    if k[i - 1] <= 50 < k[i]:
        return CALL
    if k[i - 1] >= 50 > k[i]:
        return PUT
    return None


def trix_cruce(s, i):
    # TRIX 15 (triple EMA) cruza su señal (EMA 9)
    def calc():
        e1 = s.ema(15)
        e2 = s._ema_lista(e1, 15)
        e3 = s._ema_lista(e2, 15)
        tr = [None] + [((e3[j] - e3[j - 1]) / e3[j - 1] * 100) if e3[j] and e3[j - 1] else None
                       for j in range(1, len(e3))]
        return tr, s._ema_lista(tr, 9)
    tr, sig = s._memo("trix", calc)
    if _cruza_arriba(tr, sig, i):
        return CALL
    if _cruza_abajo(tr, sig, i):
        return PUT
    return None


def hull_cruce(s, i):
    a, b = _hma(s, 9), _hma(s, 21)
    if _cruza_arriba(a, b, i):
        return CALL
    if _cruza_abajo(a, b, i):
        return PUT
    return None


def cruce_media_bollinger(s, i):
    _up, mid, _lo = s.bollinger(20, 2)
    if i < 1 or mid[i] is None or mid[i - 1] is None:
        return None
    if s.c[i - 1] <= mid[i - 1] and s.c[i] > mid[i]:
        return CALL
    if s.c[i - 1] >= mid[i - 1] and s.c[i] < mid[i]:
        return PUT
    return None


def cruce_ema_50(s, i):
    e = s.ema(50)
    if i < 1 or e[i] is None or e[i - 1] is None:
        return None
    if s.c[i - 1] <= e[i - 1] and s.c[i] > e[i]:
        return CALL
    if s.c[i - 1] >= e[i - 1] and s.c[i] < e[i]:
        return PUT
    return None


def repeticion_ciclo_3(s, i):
    # las últimas 3 velas repiten los colores de las 3 anteriores: la siguiente repite el inicio del ciclo
    if i < 5:
        return None
    a = [s.color(k) for k in range(i - 5, i - 2)]
    b = [s.color(k) for k in range(i - 2, i + 1)]
    if 0 in a or a != b or len(set(a)) == 1:
        return None
    return _dir(a[0])


def velas_decrecientes(s, i):
    # 3 velas del mismo color con cuerpos cada vez más chicos: la fuerza se acaba, entra en contra
    if i < 2:
        return None
    c3 = [s.color(k) for k in range(i - 2, i + 1)]
    if 0 in c3 or len(set(c3)) != 1:
        return None
    if s.cuerpo(i - 2) > s.cuerpo(i - 1) > s.cuerpo(i) > 0:
        return _dir(-c3[0])
    return None


# =====================================================================
#  1.23: más patrones de velas e indicadores (al final, para no mover las de antes)
# =====================================================================

def _tendencia_previa(s, i, n=3):
    """+1 si el precio subió en las n velas previas a i, -1 si bajó, 0 si no está claro."""
    if i - 1 - n < 0:
        return 0
    d = s.c[i - 1] - s.c[i - 1 - n]
    cols = [s.color(k) for k in range(i - n, i)]
    if d > 0 and sum(cols) >= n - 1:
        return 1
    if d < 0 and sum(cols) <= -(n - 1):
        return -1
    return 0


def martillo_invertido(s, i):
    # mecha de arriba larga y cuerpo abajo: tras bajada = martillo invertido (sube);
    # tras subida = estrella fugaz (baja)
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    cu = s.cuerpo(i)
    if s.mecha_arriba(i) >= 2 * cu and s.mecha_abajo(i) <= 0.15 * r and cu > 0:
        t = _tendencia_previa(s, i)
        if t < 0:
            return CALL
        if t > 0:
            return PUT
    return None


def hombre_colgado(s, i):
    # mecha de abajo larga en la cima de una subida: baja
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    cu = s.cuerpo(i)
    if cu > 0 and s.mecha_abajo(i) >= 2 * cu and s.mecha_arriba(i) <= 0.15 * r and _tendencia_previa(s, i) > 0 \
            and s.h[i] >= s.maximo(i - 1, 5):
        return PUT
    return None


def doji_libelula_lapida(s, i):
    # doji libélula (toda la mecha abajo) = sube; doji lápida (toda la mecha arriba) = baja
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    if s.cuerpo(i) > 0.1 * r:
        return None
    if s.mecha_abajo(i) >= 0.75 * r and s.l[i] <= s.minimo(i - 1, 5):
        return CALL
    if s.mecha_arriba(i) >= 0.75 * r and s.h[i] >= s.maximo(i - 1, 5):
        return PUT
    return None


def peonza(s, i):
    # peonza (spinning top) tras 3 velas de un color: indecisión, entra en contra
    r = s.rango(i)
    if r <= 0 or i < 4:
        return None
    cu = s.cuerpo(i)
    if not (0.1 * r < cu <= 0.3 * r and s.mecha_arriba(i) > cu and s.mecha_abajo(i) > cu):
        return None
    t = _tendencia_previa(s, i)
    return _dir(-t) if t else None


def tres_por_fuera(s, i):
    # envolvente (i-2, i-1) y la tercera vela confirma: sigue en esa dirección
    if i < 3:
        return None
    a, b, c = i - 2, i - 1, i
    if s.color(a) == -1 and s.color(b) == 1 and s.o[b] <= s.c[a] and s.c[b] >= s.o[a] \
            and s.color(c) == 1 and s.c[c] > s.c[b]:
        return CALL
    if s.color(a) == 1 and s.color(b) == -1 and s.o[b] >= s.c[a] and s.c[b] <= s.o[a] \
            and s.color(c) == -1 and s.c[c] < s.c[b]:
        return PUT
    return None


def harami_cruz(s, i):
    # vela grande y luego un doji dentro de su cuerpo: posible giro
    if i < 2:
        return None
    a = i - 1
    med = s.cuerpo_medio(a)
    if med <= 0 or s.cuerpo(a) < 1.2 * med or s.rango(i) <= 0 or s.cuerpo(i) > 0.1 * s.rango(i):
        return None
    alto, bajo = max(s.o[a], s.c[a]), min(s.o[a], s.c[a])
    if bajo <= s.l[i] and s.h[i] <= alto:
        return _dir(-s.color(a))
    return None


def estrella_doji(s, i):
    # estrella de la mañana/tarde con doji en el medio
    if i < 2:
        return None
    a, b, c = i - 2, i - 1, i
    med = s.cuerpo_medio(a)
    if med <= 0 or s.rango(b) <= 0 or s.cuerpo(b) > 0.1 * s.rango(b) or s.cuerpo(a) < med:
        return None
    mitad = (s.o[a] + s.c[a]) / 2
    if s.color(a) == -1 and s.color(c) == 1 and s.c[c] > mitad and s.h[b] <= s.o[a]:
        return CALL
    if s.color(a) == 1 and s.color(c) == -1 and s.c[c] < mitad and s.l[b] >= s.o[a]:
        return PUT
    return None


def cinturon(s, i):
    # cinturón (belt hold): vela grande que abre en su extremo, contra la bajada/subida previa
    r = s.rango(i)
    if r <= 0 or i < 5:
        return None
    med = s.cuerpo_medio(i - 1)
    if med <= 0 or s.cuerpo(i) < 1.5 * med:
        return None
    t = _tendencia_previa(s, i)
    if s.color(i) == 1 and t < 0 and s.mecha_abajo(i) <= 0.05 * r:
        return CALL
    if s.color(i) == -1 and t > 0 and s.mecha_arriba(i) <= 0.05 * r:
        return PUT
    return None


def tres_metodos(s, i):
    # tres métodos ascendentes/descendentes: vela grande, 3 pequeñas en contra dentro de ella,
    # y otra grande que rompe a favor: sigue
    if i < 5:
        return None
    a = i - 4
    med = s.cuerpo_medio(a)
    ca = s.color(a)
    if med <= 0 or ca == 0 or s.cuerpo(a) < 1.2 * med or s.color(i) != ca:
        return None
    for k in (i - 3, i - 2, i - 1):
        if s.cuerpo(k) > 0.6 * s.cuerpo(a) or s.h[k] > s.h[a] or s.l[k] < s.l[a]:
            return None
    if sum(s.color(k) for k in (i - 3, i - 2, i - 1)) * ca > -1:
        return None                    # al menos 2 de las 3 pequeñas en contra
    if ca > 0 and s.c[i] > s.c[a]:
        return CALL
    if ca < 0 and s.c[i] < s.c[a]:
        return PUT
    return None


def palomo(s, i):
    # palomo mensajero: dos velas del mismo color, la segunda dentro del cuerpo de la primera: gira
    if i < 4:
        return None
    a = i - 1
    ca = s.color(a)
    if ca == 0 or s.color(i) != ca or _tendencia_previa(s, a, 2) != ca:
        return None
    alto, bajo = max(s.o[a], s.c[a]), min(s.o[a], s.c[a])
    if bajo < min(s.o[i], s.c[i]) and max(s.o[i], s.c[i]) < alto:
        return _dir(-ca)
    return None


def sandwich(s, i):
    # sándwich: color A, color contrario, color A que cierra igual que la primera;
    # el doble cierre marca soporte/resistencia, entra en contra del color A
    if i < 3:
        return None
    a, b, c = i - 2, i - 1, i
    ca = s.color(a)
    if ca == 0 or s.color(b) != -ca or s.color(c) != ca:
        return None
    med = s.cuerpo_medio(c)
    if med > 0 and abs(s.c[c] - s.c[a]) <= 0.1 * med:
        return _dir(-ca)
    return None


def _rsi_estocastico(s, n=14, k=3, d=3):
    def calc():
        r = s.rsi(n)
        st = [None] * s.n
        for i in range(s.n):
            w = r[max(0, i - n + 1):i + 1]
            if len(w) < n or None in w:
                continue
            hh, ll = max(w), min(w)
            st[i] = 50.0 if hh == ll else 100 * (r[i] - ll) / (hh - ll)
        kk = [None] * s.n
        for i in range(s.n):
            w = st[max(0, i - k + 1):i + 1]
            if len(w) == k and None not in w:
                kk[i] = sum(w) / k
        dd = [None] * s.n
        for i in range(s.n):
            w = kk[max(0, i - d + 1):i + 1]
            if len(w) == d and None not in w:
                dd[i] = sum(w) / d
        return kk, dd
    return s._memo(("stochrsi", n, k, d), calc)


def stoch_rsi(s, i):
    # Stochastic RSI: %K cruza %D por debajo de 20 = sube; por encima de 80 = baja
    k, d = _rsi_estocastico(s)
    if _cruza_arriba(k, d, i) and k[i] < 20:
        return CALL
    if _cruza_abajo(k, d, i) and k[i] > 80:
        return PUT
    return None


def _ultimate(s, a=7, b=14, c=28):
    def calc():
        bp, tr = [0.0] * s.n, [0.0] * s.n
        for i in range(1, s.n):
            bajo = min(s.l[i], s.c[i - 1]); alto = max(s.h[i], s.c[i - 1])
            bp[i], tr[i] = s.c[i] - bajo, alto - bajo
        out = [None] * s.n
        for i in range(c, s.n):
            def prom(n):
                t = sum(tr[i - n + 1:i + 1])
                return sum(bp[i - n + 1:i + 1]) / t if t > 0 else 0.5
            out[i] = 100 * (4 * prom(a) + 2 * prom(b) + prom(c)) / 7
        return out
    return s._memo(("uo", a, b, c), calc)


def ultimate_osc(s, i):
    # Oscilador Último (Larry Williams): sale de la zona extrema = gira
    u = _ultimate(s)
    if i < 1 or u[i] is None or u[i - 1] is None:
        return None
    if u[i - 1] < 30 <= u[i]:
        return CALL
    if u[i - 1] > 70 >= u[i]:
        return PUT
    return None


def elder_ray(s, i):
    # Elder Ray: con EMA 13 subiendo y la fuerza bajista negativa pero recuperándose = sube (y al revés)
    e = s.ema(13)
    if i < 2 or None in (e[i], e[i - 1]):
        return None
    toro, toro_a = s.h[i] - e[i], s.h[i - 1] - e[i - 1]
    oso, oso_a = s.l[i] - e[i], s.l[i - 1] - e[i - 1]
    if e[i] > e[i - 1] and oso < 0 and oso > oso_a and s.color(i) == 1:
        return CALL
    if e[i] < e[i - 1] and toro > 0 and toro < toro_a and s.color(i) == -1:
        return PUT
    return None


def _fisher(s, n=10):
    def calc():
        med = s.mediana()
        val = [0.0] * s.n
        fis = [None] * s.n
        v = f = 0.0
        for i in range(n - 1, s.n):
            w = med[i - n + 1:i + 1]
            hh, ll = max(w), min(w)
            x = 0.0 if hh == ll else 2 * ((med[i] - ll) / (hh - ll) - 0.5)
            v = 0.66 * x + 0.67 * v
            v = max(-0.999, min(0.999, v))
            f = 0.5 * math.log((1 + v) / (1 - v)) + 0.5 * f
            fis[i] = f
        return fis
    return s._memo(("fisher", n), calc)


def fisher(s, i):
    # Fisher Transform: cruza su valor anterior desde un extremo = gira
    f = _fisher(s)
    if i < 2 or None in (f[i], f[i - 1], f[i - 2]):
        return None
    if f[i - 1] < -1.5 and f[i] > f[i - 1] and f[i - 1] <= f[i - 2]:
        return CALL
    if f[i - 1] > 1.5 and f[i] < f[i - 1] and f[i - 1] >= f[i - 2]:
        return PUT
    return None


def _cmo(s, n=9):
    def calc():
        out = [None] * s.n
        for i in range(n, s.n):
            up = dn = 0.0
            for k in range(i - n + 1, i + 1):
                d = s.c[k] - s.c[k - 1]
                if d > 0:
                    up += d
                else:
                    dn -= d
            out[i] = 0.0 if up + dn == 0 else 100 * (up - dn) / (up + dn)
        return out
    return s._memo(("cmo", n), calc)


def chande(s, i):
    # Chande Momentum: sale de -50 = sube; sale de +50 = baja
    c = _cmo(s)
    if i < 1 or None in (c[i], c[i - 1]):
        return None
    if c[i - 1] < -50 <= c[i]:
        return CALL
    if c[i - 1] > 50 >= c[i]:
        return PUT
    return None


def _roc(s, n):
    return [None if k < n or s.c[k - n] == 0 else 100 * (s.c[k] - s.c[k - n]) / s.c[k - n] for k in range(s.n)]


def _sma_lista(x, n):
    out = [None] * len(x)
    for i in range(len(x)):
        w = x[max(0, i - n + 1):i + 1]
        if len(w) == n and None not in w:
            out[i] = sum(w) / n
    return out


def _kst(s):
    def calc():
        partes = [(10, 10, 1), (15, 10, 2), (20, 10, 3), (30, 15, 4)]
        lineas = [_sma_lista(_roc(s, r), m) for r, m, _ in partes]
        k = [None] * s.n
        for i in range(s.n):
            if all(l[i] is not None for l in lineas):
                k[i] = sum(l[i] * p[2] for l, p in zip(lineas, partes))
        return k, _sma_lista(k, 9)
    return s._memo("kst", calc)


def kst(s, i):
    # Know Sure Thing: la línea cruza su señal
    k, sg = _kst(s)
    if _cruza_arriba(k, sg, i):
        return CALL
    if _cruza_abajo(k, sg, i):
        return PUT
    return None


def _tsi(s, r=25, q=13, sg=7):
    def calc():
        m = [None] + [s.c[k] - s.c[k - 1] for k in range(1, s.n)]
        a = [None] + [abs(x) for x in m[1:]]
        num = s._ema_lista(s._ema_lista(m, r), q)
        den = s._ema_lista(s._ema_lista(a, r), q)
        t = [None if x is None or y in (None, 0) else 100 * x / y for x, y in zip(num, den)]
        return t, s._ema_lista(t, sg)
    return s._memo(("tsi", r, q, sg), calc)


def tsi(s, i):
    # True Strength Index: cruza su señal
    t, sg = _tsi(s)
    if _cruza_arriba(t, sg, i):
        return CALL
    if _cruza_abajo(t, sg, i):
        return PUT
    return None


def _cog(s, n=10):
    def calc():
        med = s.mediana()
        g = [None] * s.n
        for i in range(n - 1, s.n):
            num = sum((k + 1) * med[i - k] for k in range(n))
            den = sum(med[i - k] for k in range(n))
            g[i] = 0.0 if den == 0 else -num / den
        sig = [None] + g[:-1]          # señal = valor anterior
        return g, sig
    return s._memo(("cog", n), calc)


def centro_gravedad(s, i):
    # Centro de gravedad (Ehlers): cruza su señal
    g, sg = _cog(s)
    if _cruza_arriba(g, sg, i):
        return CALL
    if _cruza_abajo(g, sg, i):
        return PUT
    return None


def rsi_centro_gravedad(s, i):
    # combinación del blog de IQ Option: Centro de gravedad cruza y el RSI confirma el lado
    r = s.rsi(14)
    d = centro_gravedad(s, i)
    if d is None or r[i] is None:
        return None
    if d == CALL and r[i] < 50:
        return CALL
    if d == PUT and r[i] > 50:
        return PUT
    return None


def vortex_tsi(s, i):
    # combinación del blog de IQ Option: TSI cruza su señal y el Vortex está del mismo lado
    vp, vm = s.vortex(14)
    d = tsi(s, i)
    if d is None or vp[i] is None or vm[i] is None:
        return None
    if d == CALL and vp[i] > vm[i]:
        return CALL
    if d == PUT and vm[i] > vp[i]:
        return PUT
    return None


ESTRATEGIAS = [
    # ciclos / cuadrantes
    ("MHI 1", lambda s, i: mhi(s, i, 0)),
    ("MHI 2", lambda s, i: mhi(s, i, 1)),
    ("MHI 3", lambda s, i: mhi(s, i, 2)),
    ("MHI Mayoría 1", lambda s, i: mhi(s, i, 0, False)),
    ("MHI Mayoría 2", lambda s, i: mhi(s, i, 1, False)),
    ("MHI Mayoría 3", lambda s, i: mhi(s, i, 2, False)),
    ("Milhão Mayoría", lambda s, i: milhao(s, i, False)),
    ("Milhão Minoría", lambda s, i: milhao(s, i, True)),
    ("Torres Gemelas", torres_gemelas),
    ("Tres Mosqueteros", tres_mosqueteros),
    ("Tres Vecinos", tres_vecinos),
    ("Padrón 23", padron_23),
    ("Mejor de 3", mejor_de_3),
    ("Patrón 3x1", patron_3x1),
    ("Minoría 3 velas", minoria_3),
    ("Mayoría 3 velas", mayoria_3),
    # velas
    ("Envolvente", envolvente),
    ("Pinbar", pinbar),
    ("Tres soldados", tres_soldados),
    ("Harami", harami),
    ("Tres dentro", tres_dentro),
    ("Estrella", estrella),
    ("Pinzas", pinzas),
    ("Barra interna", barra_interna),
    ("Heikin Ashi", heikin_ashi),
    ("Fractal", fractal),
    ("Rechazo de racha", rechazo_racha),
    ("Rechazo de racha 5", rechazo_racha_5),
    ("Agotamiento", agotamiento),
    ("Fluxo de velas", fluxo_velas),
    ("Retração de vela", retracao_vela),
    # reversión con indicadores
    ("Bollinger + RSI", bollinger_rsi),
    ("RSI extremo", rsi_extremo),
    ("RSI 2", rsi_2),
    ("Bollinger rechazo", bollinger_rechazo),
    ("Doji Bollinger", doji_bollinger),
    ("Keltner", keltner),
    ("Estocástico", estocastico),
    ("CCI", cci),
    ("Williams %R", williams),
    ("DeMarker", demarker),
    ("Divergencia RSI", divergencia_rsi),
    # tendencia
    ("Cruce EMA 9/21", lambda s, i: cruce_ema(s, i, 9, 21)),
    ("Cruce EMA 5/13", lambda s, i: cruce_ema(s, i, 5, 13)),
    ("Cruce SMA 5/15", lambda s, i: cruce_sma(s, i, 5, 15)),
    ("Pullback EMA", pullback_ema),
    ("Cruce MACD", macd_cruce),
    ("ADX + DI", adx_di),
    ("Parabolic SAR", parabolic_sar),
    ("SuperTrend", supertrend),
    ("Donchian", donchian),
    ("Ichimoku", ichimoku),
    ("Awesome", awesome),
    ("Momentum", momentum),
    ("Vortex", vortex),
    ("Aroon", aroon),
    ("Alligator", alligator),
    # niveles
    ("Soporte y resistencia", rechazo_sr),
    ("Retesteo de ruptura", retesteo),
    ("Número redondo", numero_redondo),
    # 1.16: nuevas (al final, para no mover las de antes)
    ("Alternancia", alternancia),
    ("Seguir racha 3", seguir_racha_3),
    ("Rechazo de racha 3", rechazo_racha_3),
    ("Marubozu", marubozu),
    ("Mecha larga", mecha_larga),
    ("Doji tras racha", doji_tras_racha),
    ("RSI cruce 50", rsi_cruce_50),
    ("MACD cruce cero", macd_cruce_cero),
    ("Bollinger squeeze", bollinger_squeeze),
    ("Rebote EMA 20", rebote_ema_20),
    ("Tres EMAs", tres_emas),
    ("Retroceso en tendencia", retroceso_tendencia),
    # 1.19: más estrategias (al final, para no mover las de antes)
    ("Martillo tras racha", martillo_tras_racha),
    ("Barra externa", barra_externa),
    ("Penetrante / Nube oscura", penetrante),
    ("CCI cruce cero", cci_cruce_cero),
    ("Williams cruce 50", williams_cruce_50),
    ("Estocástico cruce 50", estocastico_cruce_50),
    ("TRIX cruce", trix_cruce),
    ("Hull cruce 9/21", hull_cruce),
    ("Cruce media Bollinger", cruce_media_bollinger),
    ("Cruce EMA 50", cruce_ema_50),
    ("Repetición de ciclo 3", repeticion_ciclo_3),
    ("Velas decrecientes", velas_decrecientes),
    # 1.23: más patrones de velas e indicadores (al final, para no mover las de antes)
    ("Martillo invertido / Estrella fugaz", martillo_invertido),
    ("Hombre colgado", hombre_colgado),
    ("Doji libélula / lápida", doji_libelula_lapida),
    ("Peonza", peonza),
    ("Tres por fuera", tres_por_fuera),
    ("Harami cruz", harami_cruz),
    ("Estrella doji", estrella_doji),
    ("Cinturón", cinturon),
    ("Tres métodos", tres_metodos),
    ("Palomo mensajero", palomo),
    ("Sándwich", sandwich),
    ("Stochastic RSI", stoch_rsi),
    ("Oscilador Último", ultimate_osc),
    ("Elder Ray", elder_ray),
    ("Fisher Transform", fisher),
    ("Chande Momentum", chande),
    ("KST", kst),
    ("TSI", tsi),
    ("Centro de gravedad", centro_gravedad),
    ("RSI + Centro de gravedad", rsi_centro_gravedad),
    ("Vortex + TSI", vortex_tsi),
]
NOMBRES = [n for n, _ in ESTRATEGIAS]
VENTANA_MIN = 80          # velas mínimas antes de pedir señales (para que los indicadores estén listos)


def senales(serie, i, solo=None):
    """{indice_estrategia: "call"/"put"} en la vela i. 'solo' = conjunto de índices a revisar (None = todas)."""
    out = {}
    for k, (_n, fn) in enumerate(ESTRATEGIAS):
        if solo is not None and k not in solo:
            continue
        try:
            d = fn(serie, i)
        except (IndexError, TypeError, ZeroDivisionError, ValueError):
            d = None
        if d:
            out[k] = d
    return out
'''

_CAT_INFO_SRC = r'''# -*- coding: utf-8 -*-
"""
Grupo y explicación corta de cada estrategia (pantalla "Estrategias" de la ventana).
Las reglas exactas están en estrategias.py; aquí solo se explican con palabras.
"""

VELAS, CICLOS, OSC, TEND, NIV = "Patrones de velas", "Ciclos", "Osciladores", "Tendencia", "Niveles"

_MHI = ("Mira las 3 últimas velas del cuadrante anterior (cuadrante = 5 velas alineadas al reloj) y entra en la "
        "{n}ª vela del cuadrante nuevo con el color que salió {cual}.")

INFO = {
    # ----- ciclos / cuadrantes -----
    "MHI 1": (CICLOS, _MHI.format(n=1, cual="menos veces (minoría)")),
    "MHI 2": (CICLOS, _MHI.format(n=2, cual="menos veces (minoría)")),
    "MHI 3": (CICLOS, _MHI.format(n=3, cual="menos veces (minoría)")),
    "MHI Mayoría 1": (CICLOS, _MHI.format(n=1, cual="más veces (mayoría)")),
    "MHI Mayoría 2": (CICLOS, _MHI.format(n=2, cual="más veces (mayoría)")),
    "MHI Mayoría 3": (CICLOS, _MHI.format(n=3, cual="más veces (mayoría)")),
    "Milhão Mayoría": (CICLOS, "Cuenta los colores de las 5 velas del cuadrante anterior y entra en la 1ª vela del "
                               "cuadrante nuevo con el color que más salió."),
    "Milhão Minoría": (CICLOS, "Cuenta los colores de las 5 velas del cuadrante anterior y entra en la 1ª vela del "
                               "cuadrante nuevo con el color que menos salió."),
    "Torres Gemelas": (CICLOS, "Entra en la 5ª vela del cuadrante con el mismo color que tuvo la 1ª."),
    "Tres Mosqueteros": (CICLOS, "Entra en la 4ª vela del cuadrante con el color de la 3ª."),
    "Tres Vecinos": (CICLOS, "Entra en la 5ª vela del cuadrante con el color de la 4ª."),
    "Padrón 23": (CICLOS, "Entra en la 2ª vela del cuadrante con el color de la 1ª."),
    "Mejor de 3": (CICLOS, "Mira las 3 velas del centro del cuadrante anterior (2ª, 3ª y 4ª) y entra en la 3ª vela "
                           "del cuadrante nuevo con el color que más salió."),
    "Patrón 3x1": (CICLOS, "Mira las 3 primeras velas del cuadrante y entra en la 5ª con el color que menos salió."),
    "Minoría 3 velas": (CICLOS, "En cualquier vela: entra con el color que menos salió en las 3 últimas velas."),
    "Mayoría 3 velas": (CICLOS, "En cualquier vela: entra con el color que más salió en las 3 últimas velas."),
    "Repetición de ciclo 3": (CICLOS, "Si las 3 últimas velas repiten los colores de las 3 anteriores, apuesta a que "
                                      "el ciclo sigue repitiéndose."),
    "Alternancia": (CICLOS, "4 velas alternando colores (verde, roja, verde, roja): apuesta a que la siguiente vuelve "
                            "a cambiar de color."),
    # ----- patrones de velas -----
    "Envolvente": (VELAS, "Una vela de color contrario con el cuerpo más grande envuelve por completo a la anterior: "
                          "entra hacia el lado de la vela que envuelve."),
    "Pinbar": (VELAS, "Vela con una mecha muy larga (60 % del rango o más) que toca el mínimo o el máximo de las 5 "
                      "velas anteriores: el precio fue rechazado, entra hacia el otro lado."),
    "Tres soldados": (VELAS, "3 velas seguidas del mismo color, cada una cerrando más allá que la anterior (tres "
                             "soldados blancos o tres cuervos negros): sigue en esa dirección."),
    "Harami": (VELAS, "Vela grande y luego una de color contrario con el cuerpo dentro de ella: posible giro hacia el "
                      "color de la vela pequeña."),
    "Tres dentro": (VELAS, "Harami confirmado: la tercera vela cierra más allá de la apertura de la primera. Sigue hacia "
                           "ese lado."),
    "Estrella": (VELAS, "Estrella de la mañana o de la tarde: vela grande, una pequeña, y otra de color contrario que "
                        "cierra pasando la mitad de la primera. Entra hacia el lado de la última."),
    "Pinzas": (VELAS, "Dos velas de color contrario con el mismo mínimo (o el mismo máximo): el nivel aguantó, entra "
                      "hacia el lado de la segunda vela."),
    "Barra interna": (VELAS, "Una vela queda dentro de la anterior (vela madre) y la siguiente rompe la madre: sigue "
                             "hacia el lado de la ruptura."),
    "Heikin Ashi": (VELAS, "En velas Heikin Ashi, después de 3 del mismo color aparece una del color contrario: entra "
                           "hacia el color nuevo."),
    "Fractal": (VELAS, "Se confirma un fractal (la vela de hace 2 fue el mínimo o el máximo de 5 velas): entra hacia "
                       "el giro."),
    "Rechazo de racha": (VELAS, "4 velas seguidas del mismo color: entra en contra."),
    "Rechazo de racha 5": (VELAS, "5 velas seguidas del mismo color: entra en contra (apuesta a que la siguiente "
                                  "cambia de color)."),
    "Agotamiento": (VELAS, "Vela muy grande (casi 2 veces el ATR) que cierra en su mitad contraria: se agotó, entra "
                           "en contra."),
    "Fluxo de velas": (VELAS, "3 velas del mismo color con cuerpo firme (60 % del rango o más): entra a favor del flujo."),
    "Retração de vela": (VELAS, "Vela muy grande (1,8 veces el cuerpo medio): la siguiente devuelve parte del cuerpo, "
                                "entra en contra."),
    "Seguir racha 3": (VELAS, "Justo 3 velas seguidas del mismo color (la de antes era de otro color): entra a favor "
                              "de la racha."),
    "Rechazo de racha 3": (VELAS, "3 velas seguidas del mismo color: entra en contra."),
    "Marubozu": (VELAS, "Vela de cuerpo lleno (casi sin mechas) y grande: entra a favor de esa vela."),
    "Mecha larga": (VELAS, "Mecha de un lado de 2 veces el cuerpo y más de la mitad del rango: el precio fue "
                           "rechazado, entra hacia el otro lado."),
    "Doji tras racha": (VELAS, "Un doji (cuerpo casi nulo) después de 3 velas del mismo color: la racha se agotó, entra "
                               "en contra."),
    "Martillo tras racha": (VELAS, "3 velas del mismo color y luego un martillo o una estrella fugaz con la mecha en "
                                   "contra de la racha: entra en contra de la racha."),
    "Barra externa": (VELAS, "El rango de la vela cubre todo el de la anterior y cierra en su tercio extremo: sigue "
                             "hacia ese lado."),
    "Penetrante / Nube oscura": (VELAS, "Vela que abre más allá de la anterior y cierra pasando la mitad de su cuerpo: "
                                        "posible giro hacia el lado de la vela nueva."),
    "Velas decrecientes": (VELAS, "3 velas del mismo color con cuerpos cada vez más pequeños: la fuerza se acaba, entra "
                                  "en contra."),
    "Martillo invertido / Estrella fugaz": (VELAS, "Mecha de arriba larga y cuerpo abajo. Después de una bajada es un "
                                                   "martillo invertido (sube); después de una subida es una estrella "
                                                   "fugaz (baja)."),
    "Hombre colgado": (VELAS, "Mecha de abajo larga y cuerpo arriba en la cima de una subida: posible giro a la baja."),
    "Doji libélula / lápida": (VELAS, "Doji con toda la mecha abajo (libélula, sube) o toda la mecha arriba (lápida, "
                                      "baja), tocando el mínimo o el máximo de 5 velas."),
    "Peonza": (VELAS, "Peonza (cuerpo pequeño y mechas largas a los dos lados) después de 3 velas de un color: "
                      "indecisión, entra en contra."),
    "Tres por fuera": (VELAS, "Una envolvente y la tercera vela confirma cerrando más allá: sigue en esa dirección."),
    "Harami cruz": (VELAS, "Vela grande y luego un doji dentro de su cuerpo: posible giro en contra de la vela grande."),
    "Estrella doji": (VELAS, "Estrella de la mañana o de la tarde con un doji en el medio: entra hacia el lado de la "
                             "tercera vela."),
    "Cinturón": (VELAS, "Vela grande que abre justo en su extremo (sin mecha de ese lado) en contra de la bajada o la "
                        "subida anterior: sigue hacia el lado de esa vela."),
    "Tres métodos": (VELAS, "Vela grande, 3 pequeñas en contra que quedan dentro de ella y otra grande que rompe a "
                            "favor: la tendencia sigue."),
    "Palomo mensajero": (VELAS, "Dos velas del mismo color y la segunda queda dentro del cuerpo de la primera: posible "
                                "giro."),
    "Sándwich": (VELAS, "Vela de un color, una del contrario y otra del primero que cierra igual que la primera: el "
                        "doble cierre marca un nivel, entra en contra."),
    # ----- osciladores (reversión) -----
    "Bollinger + RSI": (OSC, "Cierra fuera de las bandas de Bollinger con el RSI en extremo (configuración de IQNOVA "
                             "BOT para cada temporalidad): entra hacia adentro."),
    "RSI extremo": (OSC, "El RSI 14 sale de la zona de 30 (sube) o de 70 (baja)."),
    "RSI 2": (OSC, "RSI de 2 períodos por debajo de 10 (sube) o por encima de 90 (baja)."),
    "Bollinger rechazo": (OSC, "La mecha pasa la banda de Bollinger pero la vela cierra adentro: entra hacia adentro."),
    "Doji Bollinger": (OSC, "Un doji que toca la banda de Bollinger: entra hacia el centro."),
    "Keltner": (OSC, "Cierra fuera del canal de Keltner (EMA 20 ± 2 ATR): entra hacia adentro."),
    "Estocástico": (OSC, "El %K cruza el %D por debajo de 25 (sube) o por encima de 75 (baja)."),
    "CCI": (OSC, "El CCI 20 sale de −100 (sube) o de +100 (baja)."),
    "Williams %R": (OSC, "El Williams %R sale de −80 (sube) o de −20 (baja)."),
    "DeMarker": (OSC, "El DeMarker sale de 0,3 (sube) o de 0,7 (baja)."),
    "Divergencia RSI": (OSC, "El precio hace un mínimo más bajo pero el RSI uno más alto (o al revés en máximos): "
                             "posible giro."),
    "RSI cruce 50": (OSC, "El RSI 14 cruza la línea de 50: entra a favor del cruce."),
    "Bollinger squeeze": (OSC, "Las bandas de Bollinger están en su punto más angosto de 20 velas y la vela cierra "
                               "fuera: sigue la ruptura."),
    "CCI cruce cero": (OSC, "El CCI 20 cruza el cero: entra a favor del cruce."),
    "Williams cruce 50": (OSC, "El Williams %R cruza −50: entra a favor del cruce."),
    "Estocástico cruce 50": (OSC, "El %K del estocástico cruza 50: entra a favor del cruce."),
    "Cruce media Bollinger": (OSC, "El precio cruza la línea media de Bollinger (SMA 20): entra a favor del cruce."),
    "Stochastic RSI": (OSC, "Estocástico aplicado al RSI: el %K cruza el %D por debajo de 20 (sube) o por encima de "
                            "80 (baja)."),
    "Oscilador Último": (OSC, "Oscilador de Larry Williams que mezcla 3 períodos: sale de 30 (sube) o de 70 (baja)."),
    "Fisher Transform": (OSC, "El Fisher Transform gira desde un extremo (por debajo de −1,5 sube; por encima de +1,5 "
                              "baja)."),
    "Chande Momentum": (OSC, "El Chande Momentum sale de −50 (sube) o de +50 (baja)."),
    "RSI + Centro de gravedad": (OSC, "El Centro de gravedad cruza su señal y el RSI confirma (por debajo de 50 para "
                                      "subir, por encima para bajar). Combinación del blog de IQ Option."),
    # ----- tendencia -----
    "Cruce EMA 9/21": (TEND, "La EMA 9 cruza la EMA 21: entra a favor del cruce."),
    "Cruce EMA 5/13": (TEND, "La EMA 5 cruza la EMA 13: entra a favor del cruce."),
    "Cruce SMA 5/15": (TEND, "La media simple 5 cruza la 15: entra a favor del cruce."),
    "Pullback EMA": (TEND, "Con tendencia por la EMA 50, el precio vuelve a tocar la EMA 9 y cierra a favor: sigue la "
                           "tendencia."),
    "Cruce MACD": (TEND, "La línea MACD cruza su señal: entra a favor del cruce."),
    "ADX + DI": (TEND, "Con ADX de 25 o más (tendencia fuerte), el +DI cruza el −DI: entra a favor del cruce."),
    "Parabolic SAR": (TEND, "El Parabolic SAR cambia de lado: entra hacia la nueva dirección."),
    "SuperTrend": (TEND, "El SuperTrend (10, 3) cambia de dirección: entra hacia la nueva."),
    "Donchian": (TEND, "Cierra por encima del máximo (o por debajo del mínimo) de las 20 velas anteriores: sigue la "
                       "ruptura."),
    "Ichimoku": (TEND, "Tenkan cruza Kijun y el precio está fuera de la nube: entra a favor."),
    "Awesome": (TEND, "El Awesome Oscillator cruza el cero: entra a favor."),
    "Momentum": (TEND, "El momentum de 10 velas pasa de negativo a positivo (sube) o al revés (baja)."),
    "Vortex": (TEND, "El VI+ cruza el VI− del Vortex: entra a favor del cruce."),
    "Aroon": (TEND, "Aroon arriba cruza Aroon abajo con fuerza (70 o más): entra a favor."),
    "Alligator": (TEND, "Las 3 líneas del Alligator se abren y el precio sale de la boca: sigue esa dirección."),
    "Rebote EMA 20": (TEND, "Con la EMA 20 subiendo o bajando, la vela la toca y cierra a favor: sigue la tendencia."),
    "Tres EMAs": (TEND, "EMA 8 > 21 > 50 (o al revés) y la vela cierra a favor: sigue la tendencia."),
    "Retroceso en tendencia": (TEND, "Con tendencia por la EMA 50, 2 velas en contra que no la cruzan: entra a favor "
                                     "de la tendencia."),
    "MACD cruce cero": (TEND, "La línea MACD cruza el cero: entra a favor del cruce."),
    "TRIX cruce": (TEND, "El TRIX 15 (triple EMA) cruza su señal: entra a favor."),
    "Hull cruce 9/21": (TEND, "La media Hull 9 cruza la Hull 21: entra a favor del cruce."),
    "Cruce EMA 50": (TEND, "El precio cruza la EMA 50: entra a favor del cruce."),
    "Elder Ray": (TEND, "Con la EMA 13 a favor, la fuerza contraria (Elder Ray) se debilita y la vela cierra a favor: "
                        "sigue la tendencia."),
    "KST": (TEND, "El Know Sure Thing (suma de 4 velocidades del precio) cruza su señal: entra a favor."),
    "TSI": (TEND, "El True Strength Index cruza su señal: entra a favor."),
    "Centro de gravedad": (TEND, "El Centro de gravedad de Ehlers cruza su señal: entra a favor."),
    "Vortex + TSI": (TEND, "El TSI cruza su señal y el Vortex está del mismo lado. Combinación del blog de IQ Option."),
    # ----- niveles -----
    "Soporte y resistencia": (NIV, "Toca el mínimo o el máximo de las últimas 50 velas y cierra lejos de él: rebote."),
    "Retesteo de ruptura": (NIV, "Rompió el máximo o el mínimo de 20 velas y vuelve a probar ese nivel desde el otro "
                                 "lado: sigue la ruptura."),
    "Número redondo": (NIV, "Toca un precio redondo (por ejemplo 1.0800) con mecha y lo rechaza: rebote."),
}

GRUPOS = [VELAS, CICLOS, OSC, TEND, NIV]


def grupo(nombre):
    return INFO.get(nombre, (TEND, ""))[0]


def texto(nombre):
    return INFO.get(nombre, ("", ""))[1]
'''



class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = False                         # una sola temporalidad
        self.tfs = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal, MHI y Solo pérdida)
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.animo_pend, self.animo_grabadas = [], {}       # registro de señales del autor (senales_datos.csv)
        self.hist = {}           # (par, tf) -> velas
        # acierto "a la primera" de cada par (últimas señales de BB + RSI): manda en qué par se entra primero
        try:
            with open(_ruta_broker("racha_pares.json"), encoding="utf-8") as f:
                self.racha = {k: v for k, v in json.load(f).items() if isinstance(v, dict)}
        except Exception:
            self.racha = {}
        self.racha_t, self.racha_guardada = {}, time.time()
        # apartado Estrategias con varias prendidas: se mide cada una en vivo y se entra con la que mejor va
        self.multi_on = estrategias_on(cfg) if cfg.get("estrategia") == "multi" and not cfg.get("copy") else []
        self.medidor = None
        if self.multi_on:
            try:
                self.medidor = MedidorEstrategias(cfg)
            except Exception:
                self.medidor = None
        self.niveles = {}        # par -> (hora en que se calcularon, [niveles de pivô, Fibo y S/R H1])
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None
        # Copy Bot
        self.copy = bool(cfg.get("copy"))      # cliente: copia las operaciones del autor (no analiza)
        self.emisor = None                     # autor: CopyEmisor (app_gui lo pone si envía sus operaciones)
        self.copy_reportar = False             # cliente: aceptó los términos del Copy Bot (avisa copiando/meta/stop)
        self.copy_ses = {}                     # última sesión del autor que llegó
        self.copy_vio_activa = False
        self.copy_autor_fin = False
        self.copy_visto = ("", 0)
        self.copy_omitidas = 0
        self.copy_parado = False               # cliente: tocó "Dejar de copiar"
        self.copy_bloqueado = False            # cliente: el autor lo apagó (sin señales ni avisos)
        self.copy_avisado = True               # cliente: ya se le avisó que el autor empezó (antes: todo en silencio)
        self.copy_aviso = ("", 0.0)            # cliente: último aviso corto para la franja (por ejemplo, señal tarde)
        self.copy_escuchando = False
        self.lock_copy = threading.Lock()

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más.
        Autor con Copy Bot: antes de terminar, sigue enviando SOLO recuperaciones a los clientes que
        tienen un ciclo abierto (él ya no opera)."""
        if self.stop_alcanzado():
            if not self.detener and not self.copy_terminando():
                if self.copy_puede_terminar():
                    self.emisor.terminando = time.time()
                    self.avisar_stop()
                    self.log("📡 Terminando: Copy Bot cierra primero la recuperación en curso de tus clientes "
                             "(tú ya no operas). Luego el bot se detiene.", "bold cyan")
                else:
                    self.detener = True
                    self.avisar_stop()
            return True
        return self.detener

    def copy_terminando(self):
        e = self.emisor
        return bool(e and e.terminando is not None and not e.cerrado)

    def copy_puede_terminar(self):
        """¿Hay clientes copiando con una recuperación abierta? (solo entonces el autor sigue enviando)."""
        e = self.emisor
        if not e or e.cerrado:
            return False
        try:
            e.leer_clientes()
        except Exception:
            pass
        return bool(e.en_recuperacion())

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        return monto_nivel(cfg, self.ciclo_perdida, payout or 0.85)

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf, par=None):
        """(tipo, pago) con el que se opera ese par. Todos los mercados (OTC y real), los que el bróker tenga abiertos:
        binaria (turbo) y, si ese par no la tiene, digital. El pago NO decide el tipo: solo debe pasar el mínimo
        al entrar. (None, None) si no se puede operar.
        Autor enviando al Copy Bot de IQ Option y Exnova a la vez: solo los pares que existen en los dos (PARES_AMBOS)."""
        e = self.emisor
        if par is not None and e is not None and not e.cerrado and e.todos and par not in PARES_AMBOS:
            return None, None
        tipo = "turbo" if tf <= 5 else "binary"
        if pays.get(tipo) is not None:
            return tipo, pays[tipo]
        if tf in (1, 5, 15) and pays.get("digital"):
            return "digital", pays["digital"]
        return None, None

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=True)
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0, par)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def libre_para_entrenar(self):
        """True si no estamos en los segundos del cierre de vela (ahí no se hacen tareas de fondo)."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return 3.0 < t < per - ANALISIS_MAX_SEG - 1.0

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre. Primero los pares que más pagan. Si el bróker devuelve el número
        de pedido, lee hasta 3 pares a la vez (en un celular lento alcanzan más pares antes del cierre)."""
        limite = prox - self.adelanto_analisis() - 1.5
        pago = lambda p: (self.pares.get(p) or {}).get("payout") or 0
        tareas = [(par, tf) for par in sorted(list(self.seleccion), key=pago, reverse=True) for tf in tfs_c]
        if getattr(self.b, "_rid_ok", None) is not True:          # sin número de pedido: uno por uno, como antes
            for par, tf in tareas:
                if not self._preparar_uno(par, tf, prox, limite):
                    return
            return
        from concurrent.futures import ThreadPoolExecutor, wait
        if getattr(self, "_pool_prep", None) is None:
            self._pool_prep = ThreadPoolExecutor(max_workers=PREPARAR_A_LA_VEZ, thread_name_prefix="prep")
        futuros = [self._pool_prep.submit(self._preparar_uno, par, tf, prox, limite) for par, tf in tareas]
        wait(futuros, timeout=max(0.0, limite - self.b.ahora()) + 1.0)
        for f in futuros:
            f.cancel()                                             # lo que no alcanzó a empezar ya no se pide

    def _preparar_uno(self, par, tf, prox, limite):
        """Prepara un par en una temporalidad. Devuelve False si ya no hay tiempo (o se detuvo el bot)."""
        if self.detener or not self.b.conectado or self.b.ahora() > limite:
            return False
        if par in self.pares_en_uso:
            return True
        k = (par, tf)
        try:
            hist = self.hist.get(k) or []
            if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                self.fase = f"Leyendo {par} M{tf}"
                velas = self.b.velas(par, tf, HISTORIA_VELAS)
                if len(velas) < 30:
                    self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); return True
                self.hist[k] = velas
                self.hist_t[k] = time.time()
                if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                        and velas[-1]["t"] >= self.b.ahora() - 180):
                    try:
                        self.vivo_pend[par] = time.time()
                        if not self.b.suscribir_vivo(par, velas):
                            self.vivo_pend.pop(par, None)
                    except Exception:
                        self.vivo_pend.pop(par, None)
            elif hist[-1]["t"] < prox - 2 * tf * 60:
                nuevas = self.b.velas(par, tf, 4)
                por_t = {v["t"]: v for v in hist}
                for v in nuevas: por_t[v["t"]] = v
                self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
            if self.autor and self.cfg.get("estrategia") == "bbrsi":      # en prueba: solo la cuenta del autor
                self.actualizar_niveles(par, limite)
            vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
            self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
        except Exception as e:
            self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)
        return True

    # ---------- prioridad: el par que más gana a la primera ----------
    def actualizar_racha(self, par, tf, cerradas):
        """Suma las señales nuevas del par (ya resueltas por la vela siguiente) a su historial de aciertos."""
        k = (par, tf)
        if len(cerradas) < 2 or self.racha_t.get(k) == cerradas[-2]["t"]:
            return
        try:
            nuevos = resultados_bbrsi(cerradas, tf, self.racha_t.get(k, 0), self.cfg)
            self.racha_t[k] = cerradas[-2]["t"]
            if nuevos:
                d = self.racha.setdefault(f"{par}|{tf}", {})
                for t, g in nuevos.items():
                    d[str(t)] = bool(g)
                if len(d) > 2 * RACHA_N:
                    for t in sorted(d, key=int)[:-2 * RACHA_N]:
                        del d[t]
            if time.time() - self.racha_guardada > 300:
                self.guardar_racha()
        except Exception:
            pass

    def actualizar_niveles(self, par, limite):
        """Una vez por hora y por par: velas D1 y H1 para los niveles (pivô, Fibo, S/R). Solo con tiempo de sobra
        antes del cierre; si el bróker no las da, el par sigue sin niveles (opera igual)."""
        hora = int(self.b.ahora() // 3600)
        if self.niveles.get(par, (None,))[0] == hora or self.b.ahora() > limite - 4:
            return
        self.niveles[par] = (hora, self.niveles.get(par, (0, []))[1])      # no reintentar en la misma hora
        try:
            aid = self.b._id(par)
            if aid is None:
                return
            dias = self.b._pedir_velas(aid, 86400, 3, time.time()) or []
            horas = self.b._pedir_velas(aid, 3600, 60, time.time()) or []
            self.niveles[par] = (hora, niveles_de(dias, horas, self.b.ahora()))
        except Exception:
            pass

    def es_clara(self, c):
        a = (c.get("racha") or (None,))[0]
        return (c.get("tf") in CLARA_TFS and c.get("adx") is not None and c["adx"] < CLARA_ADX
                and a is not None and a >= CLARA_ACIERTO)

    def acierto_par(self, par, tf):
        """(acierto de sus últimas señales a la primera, cuántas). Acierto None si aún tiene pocas."""
        if self.autor and self.cfg.get("estrategia") == "mhi":
            return self.acierto_mhi(par)
        if self.cfg.get("estrategia") == "rsi":
            return self.acierto_rsi(par, tf)
        if self.cfg.get("estrategia") == "boll":
            return self.acierto_boll(par, tf)
        d = self.racha.get(f"{par}|{tf}") or {}
        u = [d[t] for t in sorted(d, key=int)[-RACHA_N:]]
        return (sum(u) / len(u) if len(u) >= RACHA_MIN else None), len(u)

    def acierto_mhi(self, par):
        """MHI: el acierto a la primera del MODELO elegido en este par (sus últimas 60 señales en las velas M1)."""
        velas = self.hist.get((par, 1)) or []
        if not velas:
            return None, 0
        cache = getattr(self, "_mhi_cache", None)
        if cache is None:
            cache = self._mhi_cache = {}
        clave = (velas[-1]["t"], len(velas), self.cfg.get("mhi_modelo"))
        if par in cache and cache[par][0] == clave:
            return cache[par][1]
        r = [g for _, g in resultados_mhi(velas, self.cfg)][-MHI_RACHA_N:]
        val = ((sum(r) / len(r)) if len(r) >= RACHA_MIN else None, len(r))
        cache[par] = (clave, val)
        return val

    def acierto_rsi(self, par, tf):
        """RSI del autor: el acierto a la primera de sus últimas 20 señales en este par (con las velas guardadas)."""
        velas = self.hist.get((par, tf)) or []
        if not velas:
            return None, 0
        cache = getattr(self, "_rsi_cache", None)
        if cache is None:
            cache = self._rsi_cache = {}
        clave = (velas[-1]["t"], len(velas), rsi_params(self.cfg))
        if (par, tf) in cache and cache[(par, tf)][0] == clave:
            return cache[(par, tf)][1]
        r = [g for _, g in resultados_rsi(velas, tf, self.cfg)][-RACHA_N:]
        val = ((sum(r) / len(r)) if len(r) >= RACHA_MIN else None, len(r))
        cache[(par, tf)] = (clave, val)
        return val

    def acierto_boll(self, par, tf):
        """Bollinger del autor: acierto a la primera de sus últimas 20 señales (al cierre) en este par."""
        velas = self.hist.get((par, tf)) or []
        if not velas:
            return None, 0
        cache = getattr(self, "_boll_cache", None)
        if cache is None:
            cache = self._boll_cache = {}
        clave = (velas[-1]["t"], len(velas), boll_params(self.cfg))
        if (par, tf) in cache and cache[(par, tf)][0] == clave:
            return cache[(par, tf)][1]
        r = [g for _, g in resultados_boll(velas, tf, self.cfg)][-RACHA_N:]
        val = ((sum(r) / len(r)) if len(r) >= RACHA_MIN else None, len(r))
        cache[(par, tf)] = (clave, val)
        return val

    # ---------- Bollinger anticipado ----------
    def _boll_anticipado(self):
        """Bollinger anticipado (para todos) o BB + RSI anticipado (solo el autor)."""
        if self.cfg.get("estrategia") == "boll":
            return boll_params(self.cfg)[2] == "anticipado"
        return self.cfg.get("estrategia", "bbrsi") == "bbrsi" and self.cfg.get("bbrsi_momento") == "anticipado"   # para todos

    def _cierres_previos(self, par, tf, prox):
        """Cierres de las velas ya cerradas (sin la que está corriendo) o None si falta alguna."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in self.hist.get((par, tf), []) if v["t"] < inicio}
        if tf == 1:
            for v in (self.b.velas_vivo(par) or []):
                if v["t"] < inicio:
                    por_t[v["t"]] = v
        ts = sorted(por_t)
        if not ts or ts[-1] != inicio - tf * 60:
            return None
        return [float(por_t[t]["c"]) for t in ts[-200:]]

    def _nota_ant(self, msg):
        """Solo al archivo bot.log (no a la pantalla): por qué el anticipado entró o no entró en un par."""
        try:
            hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {txt_broker(msg)}\n")
        except Exception:
            pass

    def vigilar_estiramiento(self, tfs_c, prox, hasta):
        """Anticipado: entre «desde» y «hasta» segundos antes del cierre, si el precio se estira fuera de la banda
        y retrocede lo configurado (o se estira más de «directo»), entra ya. Vence igual que la entrada normal.
        Los pares que se estiraron y no entraron quedan anotados en bot.log con el motivo."""
        notas = {}                                            # (par, tf) -> dict con lo último visto de ese par
        entro = None
        try:
            bbrsi = self.cfg.get("estrategia", "bbrsi") == "bbrsi"      # BB + RSI anticipado: + RSI en su extremo
            per, dev, _, sentido = boll_params(self.cfg)
            a_est, a_rmin, a_rmax = ant_params(self.cfg)
            desde, _hasta, directo = ant_tiempo(self.cfg)
            if not self.b.esperar_hasta(max(self.b.ahora(), prox - desde), lambda: self.detener):
                return
            base, estado, prm = {}, {}, {}
            for par in list(self.seleccion):
                for tf in tfs_c:
                    if bbrsi:
                        per, dev, rp, alto, bajo = bbrsi_valores(self.cfg, tf)
                        prm[tf] = (per, dev, rp, alto, bajo)
                    c = self._cierres_previos(par, tf, prox)
                    if c and len(c) >= max(per - 1, (prm[tf][2] * 3 + 1) if bbrsi else 0):
                        base[(par, tf)] = c
            bloqueo = ""
            while not self.detener and self.b.ahora() < hasta:
                if self.pausado or self.frenar_por_stop():
                    return
                if self.abiertas or self.pares_en_uso or self.plan:
                    bloqueo = "ya había una operación abierta"
                elif self.emisor and not self.emisor.cerrado and not self.emisor.despierto():
                    return
                else:
                    bloqueo = ""
                for (par, tf), cerr in list(base.items()):
                    m1 = self.b.velas_vivo(par)
                    if not m1:
                        continue
                    p = float(m1[-1]["c"])
                    if bbrsi:
                        per, dev, rp, alto, bajo = prm[tf]
                    b = bandas(cerr[-(per - 1):] + [p], per, dev)
                    if not b:
                        continue
                    up, mid, dn = b
                    vela = self.vela_en_formacion(m1, tf, prox)
                    if not vela:
                        continue
                    ancho = abs(up - mid)
                    if ancho <= 0:
                        continue
                    # el extremo REAL de la vela (su máximo / mínimo), aunque se haya estirado antes de la ventana
                    opciones = []
                    for lado, ext, borde in ((1, float(vela["h"]), up), (-1, float(vela["l"]), dn)):
                        estiron = (ext - borde) * lado
                        if not (estiron > 0 and estiron > a_est * ancho):
                            continue
                        retro = max(0.0, (ext - p) * lado)
                        r_ext = None
                        nota = notas.setdefault((par, tf), {})
                        nota.update(lado=lado, est=estiron / ancho, ret=retro / estiron)
                        if bbrsi:      # el RSI con el precio en el extremo del estirón debe estar en su nivel
                            serie = _rsi_serie(cerr[-(rp * 12 + 1):] + [ext], rp)
                            r_ext = serie[-1] if serie else None
                            nota["rsi"] = r_ext
                            if r_ext is None or not (r_ext > alto if lado > 0 else r_ext < bajo):
                                nota["motivo"] = f"el RSI ({r_ext:.0f}) no llegó a {alto if lado > 0 else bajo}" if r_ext is not None else "sin RSI"
                                continue
                        es_directo = directo > 0 and estiron >= directo * ancho
                        if es_directo or a_rmin * estiron <= retro <= a_rmax * estiron:
                            if bloqueo:
                                nota["motivo"] = bloqueo
                                continue
                            opciones.append((estiron, lado, ext, borde, retro, r_ext, es_directo))
                        elif retro > a_rmax * estiron:
                            nota["motivo"] = f"retrocedió de más (más de tu {round(a_rmax * 100)}%)"
                        else:
                            nota["motivo"] = f"no llegó a tu {round(a_rmin * 100)}% de retroceso a tiempo"
                    if not opciones:
                        continue
                    estiron, lado, ext, borde, retro, r_ext, es_directo = max(opciones)
                    info = self.pares.get(par, {})
                    inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf, par)
                    if inst is None or inst == "digital" or (pago is not None and pago < self.cfg["payout_minimo"]):
                        notas.setdefault((par, tf), {})["motivo"] = "pago bajo o sin opción binaria"
                        estado.pop((par, tf), None); base.pop((par, tf), None)
                        continue
                    d = _boll_dir(lado, "regresa" if bbrsi else sentido)
                    como = (f"entra directo (más de tu {round(directo * 100)}%)"
                            if es_directo else f"retrocedió {retro / estiron * 100:.0f}%")
                    cand = {"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre_estrategia(self.cfg, True),
                            "detalle": f"se estiró {'arriba' if lado > 0 else 'abajo'} de la banda hasta {ext:g} "
                                       f"(banda {borde:.6g}) · estirón {estiron / ancho * 100:.0f}%" +
                                       (f" con RSI {r_ext:.0f}" if r_ext is not None else "") +
                                       f" y {como} · entra en {p:g} · anticipado {int(prox - self.b.ahora())} s antes",
                            "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst, "adx": None, "en_nivel": False,
                            "anticipado": True}
                    self.estado(par, f"ANTICIPADO {d.upper()} M{tf} · {cand['detalle']}", "bold green" if d == "call" else "bold red", 1)
                    entro = (par, tf)
                    self._decidir([cand], prox)
                    return
                time.sleep(0.25)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] anticipado\n{traceback.format_exc()}")
        finally:
            # registro: los pares que se estiraron y NO entraron, con el motivo
            try:
                for (par, tf), n in notas.items():
                    if (par, tf) == entro or "est" not in n:
                        continue
                    d = _boll_dir(n.get("lado", 1), "regresa" if self.cfg.get("estrategia", "bbrsi") == "bbrsi"
                                  else boll_params(self.cfg)[3])
                    self._nota_ant(f"NO ENTRÓ {par} M{tf} {d.upper()} · se estiró {n['est'] * 100:.0f}% · "
                                   f"retrocedió {n.get('ret', 0) * 100:.0f}%" +
                                   (f" · RSI {n['rsi']:.0f}" if n.get("rsi") is not None else "") +
                                   f" → {n.get('motivo') or 'no se cumplió a tiempo'}")
            except Exception:
                pass

    def guardar_racha(self):
        self.racha_guardada = time.time()
        try:
            ruta = _ruta_broker("racha_pares.json")
            with open(ruta + ".tmp", "w", encoding="utf-8") as f:
                json.dump(self.racha, f)
            os.replace(ruta + ".tmp", ruta)
        except Exception:
            pass

    # ---------- registro de señales del autor (senales_datos.csv) ----------
    def filtros_autor(self):
        return bool(self.autor)

    @staticmethod
    def volatilidad(cerradas):
        """Tamaño de las últimas 3 velas comparado con lo normal del par (mediana de las 50 anteriores). Solo se anota."""
        rangos = [v["h"] - v["l"] for v in cerradas[-53:]]
        if len(rangos) < 20:
            return None
        base = sorted(rangos[:-3])[len(rangos[:-3]) // 2]
        if base <= 0:
            return None
        return (sum(rangos[-3:]) / 3) / base

    def grabar_senal(self, par, tf, d, cerradas, precio, expira, origen, prob=None, vol=None, pasa=True):
        """Anota la señal (una vez) para ver después cómo terminó el precio: así se mide si los filtros sirven."""
        if not self.filtros_autor():
            return
        clave = (par, tf, int(expira))
        if clave in self.animo_grabadas:
            return
        self.animo_grabadas[clave] = True
        if vol is None:
            vol = self.volatilidad(cerradas)
        self.animo_pend.append({"t": int(self.b.ahora()), "par": par, "tf": tf, "dir": d, "origen": origen, "vol": vol,
                                "prob": prob, "pasa": pasa, "precio": precio, "expira": int(expira)})
        if len(self.animo_grabadas) > 5000:
            self.animo_grabadas.clear()

    def hilo_animo(self):
        """Cuando vence cada señal grabada, mira cómo terminó el precio y lo guarda en senales_datos.csv."""
        ruta = os.path.join(os.path.dirname(os.path.abspath(LOG_FILE)), "senales_datos.csv")
        while not self.detener and not self.terminado:
            time.sleep(3)
            if not self.animo_pend:
                continue
            try:
                ahora = self.b.ahora()
                listas = [r for r in self.animo_pend if ahora >= r["expira"] + 2]
                if not listas:
                    continue
                filas = []
                for r in listas:
                    self.animo_pend.remove(r)
                    m1 = {v["t"]: v for v in (self.b.velas_vivo(r["par"]) or [])}
                    v = m1.get(r["expira"] - 60)
                    if v is None:
                        continue
                    fin = float(v["c"])
                    res = "empate" if fin == r["precio"] else (
                        "gana" if (fin > r["precio"]) == (r["dir"] == "call") else "pierde")
                    filas.append([datetime.fromtimestamp(r["t"]).strftime("%Y-%m-%d %H:%M:%S"), r["par"],
                                  "OTC" if r["par"].endswith("-OTC") else "real", f"M{r['tf']}", r["dir"], r["origen"],
                                  "" if r["vol"] is None else round(r["vol"], 2),
                                  "" if r.get("prob") is None else round(r["prob"] * 100, 1),
                                  "si" if r["pasa"] else "no", r["precio"], fin, res])
                if filas:
                    if os.path.exists(ruta):                        # archivo de una versión anterior (otras columnas):
                        with open(ruta, encoding="utf-8") as f:     # se guarda aparte y se empieza uno nuevo
                            cab = f.readline()
                        if "prob_ia" not in cab:
                            viejo = ruta.replace(".csv", "_viejo.csv")
                            if os.path.exists(viejo):
                                viejo = ruta.replace(".csv", f"_viejo_{int(time.time())}.csv")
                            os.replace(ruta, viejo)
                    nuevo = not os.path.exists(ruta)
                    with open(ruta, "a", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        if nuevo:
                            w.writerow(["fecha", "par", "mercado", "tf", "direccion", "estrategia", "volatilidad", "prob_ia", "pasa_filtro", "precio_entrada", "precio_vence", "resultado"])
                        w.writerows(filas)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] senales\n{traceback.format_exc()}")

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        mhi = self.autor and cfg.get("estrategia") == "mhi"
        multi = cfg.get("estrategia") == "multi"
        rsi_a = cfg.get("estrategia") == "rsi"
        boll = cfg.get("estrategia") == "boll"                         # Bollinger sola: para todos
        solo_anticipado = self._boll_anticipado()     # "Anticipado": entra SOLO cuando se estira, nunca al cierre
        estricto = self.autor and cfg.get("rec_modo") == "perdida"      # "Solo pérdida": BB + RSI más exigente
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                self.actualizar_racha(par, tf, cerradas)
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf, par)
                if inst is None:
                    continue
                if solo_anticipado:
                    self.estado(par, f"M{tf} anticipado: entra solo cuando se estira", "dim", 3); continue
                nom_e, racha_m = nombre, None
                if multi:
                    d, det, nom_e, racha_m = self._senal_multi(par, tf, cerradas, actual)
                elif mhi:
                    d, det = senal_mhi(cerradas + [actual], prox, cfg)
                elif rsi_a:
                    d, det = senal_rsi([v["c"] for v in cerradas] + [actual["c"]], cfg)
                elif boll:
                    d, det = senal_boll([v["c"] for v in cerradas] + [actual["c"]], cfg)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg, estricto)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                self.grabar_senal(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, nom_e if multi else cfg.get("estrategia"))
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nom_e, "detalle": det, "racha_m": racha_m,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst,
                              "adx": adx_ultimo(cerradas + [actual]) if tf in CLARA_TFS else None,
                              "en_nivel": self.autor and cfg.get("estrategia") == "bbrsi" and rechaza_nivel(actual, d, self.niveles.get(par, (0, []))[1])})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def _senal_multi(self, par, tf, cerradas, actual):
        """Varias estrategias prendidas: de las que pasan tu acierto mínimo y tus señales mínimas en este par,
        la que da señal ahora con mejor acierto. (dirección, detalle, nombre, (acierto, señales))."""
        md = self.medidor
        if md is None:
            return None, "", "", None
        min_a, min_n = multi_minimos(self.cfg)
        eleg = md.elegibles(par, tf, self.multi_on, min_a, min_n)
        if not eleg:
            return None, "", "", None
        opciones = []
        cat = [n for n in eleg if n not in PROPIAS]
        if cat:
            m = catalogo_mod()
            serie = m.Serie((cerradas + [actual])[-(MULTI_VENTANA + 1):], tf)
            for k, d in m.senales(serie, serie.n - 1, solo={m.IDX[n] for n in cat}).items():
                opciones.append((eleg[m.NOMBRES[k]], m.NOMBRES[k], d))
        cierres = None
        for p in PROPIAS:
            if p in eleg:
                cierres = cierres or [v["c"] for v in cerradas] + [actual["c"]]
                try:
                    d, _ = senal_propia(p, cierres, self.cfg)
                except Exception:
                    d = None
                if d:
                    opciones.append((eleg[p], p, d))
        if not opciones:
            return None, "", "", None
        opciones.sort(key=lambda x: (x[0][0], x[0][1]), reverse=True)
        (q, n), nom, d = opciones[0]
        nombre = NOMBRE_PROPIA.get(nom, nom)
        return d, f"{nombre} · acierto {q * 100:.0f} % en {n} señales", nombre, (q, n)

    def listas_multi(self):
        """Varias estrategias: las que pasan tus mínimos ahora (mejor acierto y en cuántos pares). Cada 15 s."""
        md = getattr(self, "medidor", None)
        if md is None:
            return None
        c = getattr(self, "_listas_cache", None)
        if c and time.time() - c[0] < 15:
            return c[1]
        out = None
        try:
            min_a, min_n = multi_minimos(self.cfg)
            mejor, pares = {}, set()
            for (par, tf) in list(self.hist.keys()):
                pares.add(par)
                for nom, (q, _n) in md.elegibles(par, tf, self.multi_on, min_a, min_n).items():
                    b = mejor.setdefault(nom, [0.0, 0])
                    b[0] = max(b[0], q); b[1] += 1
            lista = sorted(([NOMBRE_PROPIA.get(k, k), round(v[0] * 100), v[1]] for k, v in mejor.items()),
                           key=lambda x: (-x[1], -x[2]))[:4]
            out = {"lista": lista, "pares": len(pares), "min_a": round(min_a * 100), "min_n": min_n}
        except Exception:
            out = None
        self._listas_cache = (time.time(), out)
        return out

    def hilo_medidor(self):
        """Varias estrategias: mide en segundo plano cada estrategia en las velas ya cerradas de cada par.
        No trabaja en los últimos segundos antes del cierre (ahí el bot analiza y entra)."""
        md = self.medidor
        primera = True
        while not self.detener and md is not None:
            try:
                total = 0
                for (par, tf), velas in list(self.hist.items()):
                    if self.detener:
                        break
                    while not self.detener and (self.b.ahora() % 60) > 52:
                        time.sleep(0.5)                       # cerca del cierre: deja la CPU libre
                    total += md.procesar(par, tf, list(velas))
                    time.sleep(0.002)
                if primera and total:
                    primera = False
                    self.log(f"Estrategias: midiendo {len(self.multi_on)} estrategias en {len(self.hist)} pares "
                             f"({total} señales anotadas). Entra cuando una pasa tu acierto y tus señales mínimas.", "cyan")
                md.guardar()
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] medidor\n{traceback.format_exc()}")
            for _ in range(10):
                if self.detener:
                    break
                time.sleep(0.5)
        if md is not None:
            md.guardar(forzar=True)

    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        a = max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))
        if self.emisor and not self.emisor.cerrado:
            a = max(a, COPY_ANTICIPO_SEG)          # Copy Bot: la señal sale ~5 s antes y llega a todos a tiempo
        return a





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        return monto_nivel(cfg, ciclo, payout or 0.85)


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # entre las señales del mismo momento (todas ya pasaron el mínimo de 80 %), primero el PAR QUE MÁS GANA
        # A LA PRIMERA (sus últimas señales); un par con pocas señales cuenta como 50 %. Luego desempata:
        for c in cands:
            c["racha"] = c["racha_m"] if c.get("racha_m") else self.acierto_par(c["par"], c["tf"])
        r = lambda c: c["racha"][0] if c["racha"][0] is not None else 0.5
        cands = sorted(cands, key=lambda c: (r(c), round(c.get("payout") or 0.0, 3)), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            if self.emisor and not self.emisor.cerrado and self.emisor.despierto():
                try:
                    self.copy_condicional(o, cands, prox)
                except Exception:
                    pass
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        if self.copy:
            self.copy_tras_resultado(vence)           # Copy Bot: lo que el autor dejó dicho antes del cierre
            return
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        terminar = self.copy_terminando()          # autor en su stop: solo envía recuperaciones a los clientes
        if not terminar and (self.frenar_por_stop() or self.pausado):
            return
        if self.emisor and not self.emisor.cerrado and not self.emisor.despierto():
            falta = max(0, int(self.emisor.listo_en - self.b.ahora()))
            self.fase = f"Copy Bot: despertando los bots de los clientes ({falta} s)"
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            etiqueta = f"NIVEL {nivel}"
        else:
            otros = lista
        # entradas y recuperaciones, en cada cierre: 1) la señal que rebota en un NIVEL (pivô, Fibo o S/R H1),
        # 2) una señal CLARA, 3) la del par con mejor acierto a la primera
        elegida, sufijo = self._elegir(otros)
        if not elegida:
            return
        elegida["detalle"] = (elegida.get("detalle") or "") + sufijo
        if terminar:
            if self.b.ahora() < prox - anticipo - 0.6:
                elegida.update({"inicio_vela": prox, "etiqueta": "NIVEL", "expira": prox + elegida["tf"] * 60})
                if self.emisor.enviar(elegida, prox - anticipo, solo_rec=True):
                    self.log(f"📡 Recuperación enviada a los clientes: {elegida['par']} M{elegida['tf']} "
                             f"{elegida['dir'].upper()} (tú no entras).", "cyan")
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        elif elegida.get("anticipado"):
            # Bollinger anticipado: entra ya (con Copy Bot, 1,5 s después para que la señal llegue a todos)
            if self.b.ahora() > prox - 3:
                return
            elegida["disparo"] = (self.b.ahora() + 1.5) if (self.emisor and not self.emisor.cerrado) else None
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        if self.emisor and not self.emisor.cerrado:
            if self.copy_enviar(elegida, prox, plan) == "no":
                return
        self.lanzar(elegida)

    def _elegir(self, otros):
        """(señal, texto) · 1) la que rebota en un NIVEL, 2) una señal CLARA, 3) la del par con mejor acierto."""
        em = getattr(self, "emisor", None)
        if em is not None and not em.cerrado and em.filtros:      # "Con filtros": solo las que también reciben los clientes
            otros = [c for c in otros if em.pasa_filtros(c)[0]]
        for c in otros:
            if c.get("en_nivel"):
                return c, " · rebote en nivel"
        for c in otros:
            if self.es_clara(c):
                return c, " · señal clara"
        return (otros[0], "") if otros else (None, "")

    def copy_condicional(self, o, cands, prox):
        """Autor con una operación que vence en este cierre: ANTES del cierre envía a los clientes lo que se hace
        con el resultado (si pierde: este nivel; si gana: esta entrada). Cada bot lo ejecuta apenas ve su propio
        resultado, igual de rápido que tú: nadie espera una señal después del cierre."""
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]
        pierde, _ = self._elegir([c for c in lista if c["par"] != o["par"]])
        gana, _ = self._elegir(lista)
        if gana is not None and self.pnl + o["monto"] * (o.get("payout") or 0.8) >= float(self.cfg["stop_win"]) - 1e-9:
            gana = None                                       # si gana, llegas a tu meta: no hay entrada después
        ramas = {}
        for nombre, c in (("si_pierde", pierde), ("si_gana", gana)):
            if c is None:
                continue
            pasa, motivo = self.emisor.pasa_filtros(c)
            if not pasa:
                self.emisor.no_enviadas += 1
                self.log(f"📡 Copy Bot: {c['par']} ({'nivel' if nombre == 'si_pierde' else 'entrada'}) no se envía ({motivo}).", "dim")
                continue
            ramas[nombre] = {"par": c["par"], "dir": c["dir"], "tf": int(c["tf"]), "expira": round(prox + int(c["tf"]) * 60, 2)}
        if ramas and self.emisor.enviar_cond(prox, ramas.get("si_pierde"), ramas.get("si_gana")):
            for nombre in ramas:
                ramas[nombre]["n"] = len([x for x in self.emisor.conectados if x.get("estado") in ("copiando", "rec")])
            self.copy_ramas = (prox, ramas)

    def copy_enviar(self, s, prox, plan):
        """Autor: envía la operación a los clientes ANTES de entrar (todos entran al mismo segundo)."""
        if plan:
            # después del resultado: los clientes ya recibieron ANTES del cierre qué hacer (copy_condicional)
            r = getattr(self, "copy_ramas", None)
            if r and abs(r[0] - prox) < 1:
                for rama in r[1].values():
                    if rama["par"] == s["par"] and rama["dir"] == s["dir"]:
                        s["copy_enviada"] = rama.get("n", 0)
                        s["detalle"] = (s.get("detalle") or "") + " · enviada al Copy Bot"
                        break
            return
        pasa, motivo = self.emisor.pasa_filtros(s)
        if not pasa:
            self.emisor.no_enviadas += 1
            self.log(f"📡 Copy Bot: {s['par']} no pasa los filtros ({motivo}): no se opera.", "dim")
            return "no"
        s["expira"] = s.get("expira") or (s["inicio_vela"] + s["tf"] * 60)
        if self.emisor.enviar(s, s["disparo"]):
            s["copy_enviada"] = len([c for c in self.emisor.conectados if c.get("estado") in ("copiando", "rec")])
            s["detalle"] = (s.get("detalle") or "") + " · enviada al Copy Bot"
        else:
            self.log(f"📡 Copy Bot: no se pudo enviar {s['par']} ({self.emisor.error}). La operas tú solo.", "yellow")

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "acierto_m": round(s["racha_m"][0] * 100) if s.get("racha_m") else None,
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     (f"par {s['racha'][0]*100:.0f}% a la primera ({s['racha'][1]} señales) · " if (s.get('racha') or (None,))[0] is not None else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"], "inst": s.get("inst"),
                        "acierto_m": round(s["racha_m"][0] * 100) if s.get("racha_m") else None}
            if self.copy:
                registro["copy"] = "cliente"
            elif s.get("copy_enviada") is not None:
                registro["copy"] = int(s["copy_enviada"])
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.frenar_por_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    if tfs_c and self._boll_anticipado():
                        threading.Thread(target=self.vigilar_estiramiento,
                                         args=(tfs_c, prox, min(prox - adelanto - 0.4, prox - ant_tiempo(self.cfg)[1])), daemon=True).start()
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()) and not self.copy_terminando():
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        if self.copy_puede_terminar():
                            self.emisor.terminando = time.time()
                            self.log("📡 Terminando: Copy Bot cierra primero la recuperación en curso de tus clientes.", "bold cyan")
                        else:
                            self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            if self.emisor:
                self.emisor.terminar("stop" if self.stop_alcanzado() else "autor")
            self.guardar_racha()
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        if self.copy:
            self.log("🔗 Copy Bot: tu bot entra cuando entra el autor, en tu cuenta, con tu monto, tus stops y tus niveles.", "bold")
            for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo_copy,
                             self.hilo_precios, self.hilo_copy_reporte):
                threading.Thread(target=objetivo, daemon=True).start()
            return
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        if self.emisor:
            threading.Thread(target=self.hilo_emisor, daemon=True).start()
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_animo):
            threading.Thread(target=objetivo, daemon=True).start()
        if self.medidor is not None:
            threading.Thread(target=self.hilo_medidor, daemon=True).start()


    # ---------- Copy Bot: autor ----------
    def hilo_emisor(self):
        """Autor: primer minuto para despertar a los clientes; luego lee quién copia y quién llegó a su meta."""
        e = self.emisor
        if not e.ok():
            self.log("📡 Copy Bot: falta la clave de Firebase en este equipo (copybot_firebase.txt). "
                     "Tus operaciones NO se envían.", "bold yellow")
            e.cerrado = True
            return
        e.escuchar_vivos()                       # estados de los clientes en vivo (≈1 s)
        if e.despertar():
            self.log(f"📡 Copy Bot: aviso enviado. 90 s para despertar los bots de tus clientes (en silencio: puedes apagar a quien quieras); "
                     f"después todos empiezan a operar al tiempo"
                     f"{' (solo se envían las que pasan los filtros)' if e.filtros else ''}.", "bold cyan")
        else:
            self.log(f"📡 Copy Bot: no se pudo avisar a los clientes ({e.error}). Se reintenta.", "bold yellow")
        siguiente, t_vivo = 0, time.time()
        while not self.terminado and not e.cerrado:
            if time.time() - t_vivo >= 60:
                t_vivo = time.time()
                e.latido()
            if time.time() >= siguiente:
                try:
                    e.leer_clientes()
                except Exception:
                    pass
                siguiente = time.time() + (5 if not e.despierto() else 10 if e.terminando else 20)   # en los 90 s: cada 5 s
            if e.terminando is not None:
                if not e.en_recuperacion() or time.time() - e.terminando > COPY_TERMINAR_MAX_SEG:
                    e.terminar("stop")
                    self.log("📡 Copy Bot: ningún cliente queda en recuperación. El bot se detiene.", "bold cyan")
                    self.detener = True
                    return
            if self.detener and not e.terminando:
                break
            time.sleep(1)

    # ---------- Copy Bot: cliente ----------
    def ciclo_copy(self):
        """Cliente: no analiza. Escucha al autor y entra a la hora exacta que él indica."""
        try:
            self.fase = "Copy Bot · conectando con el autor…"
            threading.Thread(target=self._escuchar_copy, daemon=True).start()
            while not self.detener:
                time.sleep(0.3)
                ses = self.copy_ses
                if ses.get("activa") and self.b.ahora() - float(ses.get("vivo") or ses.get("inicio") or 0) > COPY_SIN_LATIDO_SEG:
                    self.copy_sesion_cambia(dict(ses, activa=False))      # el bot del autor dejó de avisar
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.terminado = True

    def _escuchar_copy(self):
        def llega(d):
            try:
                self.copy_llega(d)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] copy\n{traceback.format_exc()}")
        self.copy_escuchando = True
        copy_escuchar(llega, lambda: self.detener or self.terminado, self.copy_sesion_cambia)
        self.copy_escuchando = False

    def copy_sesion_cambia(self, ses):
        try:
            mia = copy_clave_estado(str(self.b.id_iq() or ""))
        except Exception:
            mia = ""
        if mia and mia in (ses.get("bloq") or []):
            if not self.copy_bloqueado:                  # el autor lo apagó: se detiene en silencio
                self.copy_bloqueado = True
                self.log("📡 Copy Bot: el autor no está operando ahora.", "dim")    # en silencio (sin decir por qué)
                self.fase = "Copy Bot · el autor no está operando ahora"
                self.detener = True
            self.copy_ses = dict(ses)
            return
        viejo = self.copy_ses
        self.copy_ses = dict(ses)
        if ses.get("activa"):
            if ses.get("sid") != viejo.get("sid") or not viejo.get("activa"):
                self.copy_vio_activa = True
                self.copy_avisado = False                # el aviso sale cuando terminan los 90 s (si no lo apagaron)
                threading.Thread(target=self._copy_aviso_inicio, args=(str(ses.get("sid") or ""),
                                 float(ses.get("listo_en") or 0)), daemon=True).start()
            self.fase = "Copy Bot · esperando la señal del autor"
        elif self.copy_vio_activa and viejo.get("activa") and not self.copy_autor_fin:
            self.copy_autor_fin = True
            self.log("📡 El autor terminó por hoy. Copy Bot deja de copiar.", "bold cyan")
            notificar("📡 El autor terminó por hoy", f"Copy Bot dejó de copiar · Sesión {texto_dinero(self.pnl)}",
                      tipo="autor_fin", monto=self.pnl, ganadas=self.stats["ganadas"])
            self.detener = True
        elif not ses.get("activa"):
            self.fase = "Copy Bot · el autor no está operando ahora"

    def _copy_aviso_inicio(self, sid, listo_en):
        """Al terminar los 90 s del autor (y solo si no lo apagó): «El autor empezó a operar»."""
        fin = time.time() + 150
        while time.time() < fin:
            if self.copy_bloqueado or self.detener or self.terminado or not self.copy_ses.get("activa") \
                    or str(self.copy_ses.get("sid") or "") != sid:
                return
            if self.b.ahora() >= listo_en - 1:
                break
            time.sleep(0.5)
        if self.copy_bloqueado or self.detener or self.terminado:
            return
        self.copy_avisado = True
        self.log("📡 El autor empezó a operar.", "bold cyan")
        notificar("📡 El autor empezó a operar", f"Copy Bot conectado a tu cuenta {'Real' if self.cuenta == 'REAL' else 'Demo'}"
                  f" · Meta {texto_dinero(self.cfg['stop_win'], False)} · Stop {texto_dinero(self.cfg['stop_loss'], False)}",
                  tipo="copy_inicio")

    def copy_llega(self, d):
        if self.copy_bloqueado:
            return
        with self.lock_copy:
            clave = (str(d.get("sid") or ""), int(d.get("n") or 0))
            if not clave[1] or clave == self.copy_visto:
                return
            if clave[0] == self.copy_visto[0] and clave[1] < self.copy_visto[1]:
                return
            self.copy_visto = clave
        if not self.copy_ses.get("activa") or self.copy_ses.get("sid") != clave[0]:
            return
        if d.get("tipo") == "cond":
            self.copy_cond_llega(d)
            return
        par, tf, direc = str(d.get("par") or ""), int(d.get("tf") or 0), str(d.get("dir") or "")
        entrar = float(d.get("entrar") or 0)
        llega = self.b.ahora()
        if llega > entrar - COPY_TARDE_SEG:
            if llega - entrar < 30:
                self.copy_omitidas += 1
                self.copy_aviso = (f"la señal de {par} llegó tarde y no entraste", time.time())
                self.log(f"⏱ Copy Bot: la señal de {par} llegó tarde ({llega - entrar + COPY_TARDE_SEG:+.1f} s); "
                         f"se omite (nunca entra tarde).", "yellow")
            return
        if d.get("solo_rec") and self.nivel == 0:
            return                                   # el autor ya terminó: solo copian quienes tienen un ciclo abierto
        self._copy_entrar(par, tf, direc, float(d.get("inicio_vela") or 0), float(d.get("expira") or 0) or None,
                          entrar, bool(d.get("post")))

    def copy_cond_llega(self, d):
        """Llega ANTES del cierre: qué hacer con el resultado. Si tengo una operación que vence ahí, se ejecuta
        apenas llegue MI resultado; si no, justo después del cierre."""
        vence = float(d.get("vence") or 0)
        if self.b.ahora() > vence + 2:
            return
        with self.lock_copy:
            if not isinstance(getattr(self, "copy_cond", None), dict):
                self.copy_cond = {}
            self.copy_cond = {k: v for k, v in self.copy_cond.items() if k > self.b.ahora() - 30}
            self.copy_cond[round(vence)] = d
        if any(abs(o["vence"] - vence) < 1 for o in list(self.abiertas.values())):
            return                                   # lo ejecuta copy_tras_resultado
        def sin_operacion():
            if self.b.esperar_hasta(vence + 0.8, lambda: self.detener):
                self.copy_tras_resultado(vence)
        threading.Thread(target=sin_operacion, daemon=True).start()

    def copy_tras_resultado(self, vence):
        with self.lock_copy:
            pend = getattr(self, "copy_cond", None) or {}
            d = pend.pop(round(vence), None) if isinstance(pend, dict) else None
            if not d:
                return
        rama = d.get("si_pierde") if self.nivel > 0 else d.get("si_gana")   # según MI resultado (mis niveles)
        if not rama:
            return
        self._copy_entrar(str(rama.get("par") or ""), int(rama.get("tf") or 0), str(rama.get("dir") or ""),
                          float(d.get("vence") or 0), float(rama.get("expira") or 0) or None, None, True)

    def _copy_entrar(self, par, tf, direc, inicio_vela, expira, entrar, post):
        if self.detener or self.pausado or self.stop_alcanzado():
            return
        if par not in self.pares or direc not in ("call", "put") or tf not in TEMPORALIDADES:
            self.log(f"Copy Bot: {par} no está abierto en tu cuenta ahora; esta señal se omite.", "yellow")
            return
        if self.abiertas or self.pares_en_uso:
            self.log(f"Copy Bot: {par} se omite porque tu operación anterior sigue abierta.", "yellow")
            return
        info = self.pares.get(par, {})
        inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
        if inst is None:
            self.log(f"Copy Bot: {par} M{tf} no está disponible en tus mercados; se omite.", "yellow")
            return
        cfg = self.cfg
        nivel, ciclo = self.nivel, self.ciclo_perdida
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, pago)
        etiqueta = f"NIVEL {nivel}" if recuperando else "ENTRADA"
        if recuperando and not self.puede_arriesgar(monto):
            base = self.monto_recuperacion(0, 0.0, pago)
            if self.puede_arriesgar(base):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto, etiqueta = 0, 0.0, False, base, "ENTRADA"
        if not self.puede_arriesgar(monto):
            self.log(f"Copy Bot: entrada de ${monto:.2f} cancelada, el stop loss no deja margen.", "bold yellow")
            return
        s = {"par": par, "tf": tf, "dir": direc, "payout": pago, "estrategia": "Copy Bot", "detalle": "",
             "inst": inst, "inicio_vela": inicio_vela, "expira": expira,
             "disparo": entrar, "post_cierre": post,
             "monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
             "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0}
        self.fase = f"Copy Bot · entrando en {par} con el autor"
        self.lanzar(s)

    def copy_parar(self):
        """El cliente dejó de copiar (desde la app o la notificación): su operación abierta termina normal
        y no entra en ninguna más. Ganando o perdiendo, es su decisión."""
        if not self.copy or self.copy_parado:
            return
        self.copy_parado = True
        self.log(f"✋ Dejaste de copiar al autor · sesión {texto_dinero(self.pnl)}"
                 + (f" · quedó pendiente la recuperación de ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.nivel else ""), "bold cyan")
        self.fase = "Dejaste de copiar al autor"
        self.detener = True

    def copy_estado_deseado(self):
        if self.copy_bloqueado:
            return "fuera"
        if self.copy_parado:
            return "parado"
        if self.stop_alcanzado():
            return "meta" if self.pnl > 0 else "stop"
        if self.detener or self.terminado:
            return "fuera"
        if self.pausado:
            return "pausa"
        return "rec" if self.nivel > 0 else "copiando"

    def hilo_copy_reporte(self):
        """Cliente que aceptó los términos del Copy Bot: avisa al autor si copia, si llegó a su meta o a su stop
        (con el monto de la sesión). Nada más: ni saldo ni contraseña."""
        enviado, t_env, vivo = None, 0, None
        script = {"hilo": None}
        while True:
            fin = self.terminado
            if self.copy_reportar:
                e = self.copy_estado_deseado()
                ab = next(iter(list(self.abiertas.values())), None)
                datos = {"estado": e, "monto": f"{self.pnl:.2f}", "meta": f"{float(self.cfg['stop_win']):.2f}",
                         "perdida": f"{float(self.cfg['stop_loss']):.2f}", "nivel": str(self.nivel),
                         "par": ab["par"] if ab else "", "tipo_cuenta": "REAL" if self.cuenta == "REAL" else "DEMO"}
                firma = tuple(sorted(datos.items()))
                cid = ""
                try:
                    cid = str(self.b.id_iq() or "")
                except Exception:
                    pass
                if cid and firma != vivo and copy_estado_vivo(cid, datos):
                    vivo = firma                                     # al autor, al instante (Firebase)
                h = script["hilo"]
                if cid and (firma != enviado or time.time() - t_env > 120) and (h is None or not h.is_alive()):
                    def al_script(d=dict(datos, accion="copy_estado", cuenta=cid), f=firma):
                        nonlocal enviado, t_env
                        if copy_script(d, timeout=15) is not None:   # historial, avisos y Telegram (más lento)
                            enviado, t_env = f, time.time()
                    script["hilo"] = threading.Thread(target=al_script, daemon=True)
                    script["hilo"].start()
                    if fin:
                        script["hilo"].join(16)
            if fin:
                return
            time.sleep(0.5)

    def resumen_copy(self):
        if self.emisor:
            return self.emisor.resumen()
        if not self.copy:
            return None
        ab = next(iter(list(self.abiertas.values())), None)
        aviso, t_av = self.copy_aviso
        return {"rol": "cliente", "conectado": self.copy_escuchando,
                "autor_activo": bool(self.copy_ses.get("activa")), "autor_fin": self.copy_autor_fin,
                "omitidas": self.copy_omitidas, "parado": self.copy_parado, "nivel": self.nivel,
                "bloqueado": self.copy_bloqueado,
                "abierta": {"par": ab["par"], "dir": ab["dir"]} if ab else None,
                "aviso": aviso if time.time() - t_av < 70 else ""}

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "acierto_m": o.get("acierto_m"), "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0"), "inst": o.get("inst")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bbrsi"),
                           "n_on": len(getattr(self, "multi_on", []) or []), "listas": self.listas_multi()},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "copy": self.resumen_copy(),
            "ant": self.panel_vivo(),
        }

    def panel_vivo(self):
        """Panel en vivo del PC según la estrategia: anticipado (Bollinger o BB + RSI), RSI, Bollinger al cierre
        o BB + RSI al cierre. Solo informa lo que el bot está mirando; no decide entradas."""
        try:
            if self.cfg.get("copy") or self.cfg.get("estrategia") == "multi":
                return None                               # el cliente que copia no lee pares propios · varias: sin panel
            if self._boll_anticipado():
                a = self.panel_anticipado()
                return dict(a, modo="ant") if a else None
            ahora = self.b.ahora()
            cache = getattr(self, "_vivo_cache", None)
            if cache and ahora - cache[0] < 1.0:
                return cache[1]
            if not self.tfs:
                return None
            cfg, tf = self.cfg, int(self.tfs[0])
            estr = cfg.get("estrategia", "bbrsi")
            prox = (int(ahora) // (tf * 60) + 1) * tf * 60
            filas = []
            if estr == "rsi":
                per, alto, bajo, modo = rsi_params(cfg)
            elif estr == "boll":
                per, dev, _, sentido = boll_params(cfg)
            else:
                per, dev, rp, alto, bajo = bbrsi_valores(cfg, tf)
            for par in list(getattr(self, "seleccion", []) or []):
                cerr = self._cierres_previos(par, tf, prox)
                m1 = self.b.velas_vivo(par) if self.b.vivo.get(par) else None
                if not cerr or not m1:
                    continue
                p = float(m1[-1]["c"])
                if estr == "rsi":
                    serie = _rsi_serie(cerr[-(per * 12 + 2):] + [p], per)
                    if len(serie) < 2:
                        continue
                    r0, r1 = serie[-2], serie[-1]
                    d = _rsi_cruce(r0, r1, alto, bajo, modo)
                    if d:
                        estado, orden = ("cruzó " + str(alto if r1 > r0 else bajo)), 0
                    elif r1 < alto and alto - r1 <= 10:
                        estado, orden = f"cerca de {alto}", 1 + (alto - r1) / 100
                    elif r1 > bajo and r1 - bajo <= 10:
                        estado, orden = f"cerca de {bajo}", 1 + (r1 - bajo) / 100
                    else:
                        estado, orden = "sin cruce", 2 + min(abs(r1 - alto), abs(r1 - bajo)) / 100
                    filas.append({"par": par, "r0": round(r0), "r": round(r1), "dir": ("call" if d > 0 else "put") if d else "",
                                  "estado": estado, "o": orden})
                    continue
                if len(cerr) < per - 1:
                    continue
                b = bandas(cerr[-(per - 1):] + [p], per, dev)
                if not b:
                    continue
                up, mid, dn = b
                pos = (p - dn) / (up - dn) if up > dn else 0.5
                lado = 1 if p > up else (-1 if p < dn else 0)
                fila = {"par": par, "pos": round(pos, 3)}
                if estr == "boll":
                    if lado:
                        d = _boll_dir(lado, sentido)
                        fila.update(estado=f"fuera {'arriba' if lado > 0 else 'abajo'}", dir=d, o=0)
                    elif pos >= 0.85 or pos <= 0.15:
                        fila.update(estado="tocando arriba" if pos >= 0.85 else "cerca de abajo", dir="", o=1 + abs(0.5 - pos) * -1)
                    else:
                        fila.update(estado="dentro", dir="", o=2 - abs(0.5 - pos))
                else:
                    serie = _rsi_serie(cerr[-(rp * 12 + 1):] + [p], rp)
                    r = serie[-1] if serie else 50.0
                    fila["r"] = round(r)
                    extremo = (r > alto) if pos >= 0.5 else (r < bajo)
                    casi = (r > alto - 5) if pos >= 0.5 else (r < bajo + 5)
                    if lado and extremo:
                        fila.update(estado="señal", dir="put" if lado > 0 else "call", o=0)
                    elif lado:
                        fila.update(estado="fuera, RSI no llega", dir="", o=1)
                    elif (pos >= 0.85 or pos <= 0.15) and casi:
                        fila.update(estado="cerca · RSI casi", dir="", o=1.5 - abs(0.5 - pos))
                    elif pos >= 0.85 or pos <= 0.15:
                        fila.update(estado="cerca de " + ("arriba" if pos >= 0.5 else "abajo"), dir="", o=2 - abs(0.5 - pos))
                    else:
                        fila.update(estado="dentro", dir="", o=3 - abs(0.5 - pos))
                filas.append(fila)
            filas = [x for x in filas if x.get("dir")]          # solo los que cumplen la señal
            filas.sort(key=lambda x: x["o"])
            for x in filas:
                x.pop("o", None)
            out = {"modo": estr if estr in ("rsi", "boll") else "bbrsi", "falta": round(prox - ahora), "tf": tf,
                   "filas": filas[:3], "leyendo": len(getattr(self, "seleccion", []) or [])}
            if estr == "rsi":
                out.update(per=per, alto=alto, bajo=bajo, contra=modo == "contra")
            elif estr == "boll":
                out.update(per=per, dev=dev, sigue=sentido == "sigue")
            else:
                out.update(per=per, dev=dev, rp=rp, alto=alto, bajo=bajo)
            self._vivo_cache = (ahora, out)
            return out
        except Exception:
            return None

    def panel_anticipado(self):
        """Panel «Anticipado en vivo» del PC: los pares que ya se estiraron fuera de la banda (con su retroceso)
        y los que están más cerca de la banda. Solo informa: la entrada la decide vigilar_estiramiento.
        Se calcula como máximo una vez por segundo."""
        try:
            if not self._boll_anticipado() or not self.tfs:
                return None
            ahora = self.b.ahora()
            cache = getattr(self, "_ant_cache", None)
            if cache and ahora - cache[0] < 1.0:
                return cache[1]
            cfg = self.cfg
            tf = int(self.tfs[0])
            bbrsi = cfg.get("estrategia", "bbrsi") == "bbrsi"
            if bbrsi:
                per, dev, rp, alto, bajo = bbrsi_valores(cfg, tf)
                sentido = "regresa"
            else:
                per, dev, _, sentido = boll_params(cfg)
            a_est, a_rmin, a_rmax = ant_params(cfg)
            desde, hasta, directo = ant_tiempo(cfg)
            prox = (int(ahora) // (tf * 60) + 1) * tf * 60
            falta = prox - ahora
            ventana = falta <= desde
            estirados, cerca = [], []
            for par in list(getattr(self, "seleccion", []) or []):
                cerr = self._cierres_previos(par, tf, prox)
                m1 = self.b.velas_vivo(par) if self.b.vivo.get(par) else None
                if not cerr or len(cerr) < per - 1 or not m1:
                    continue
                p = float(m1[-1]["c"])
                b = bandas(cerr[-(per - 1):] + [p], per, dev)
                vela = self.vela_en_formacion(m1, tf, prox)
                if not b or not vela:
                    continue
                up, mid, dn = b
                ancho = abs(up - mid)
                if ancho <= 0:
                    continue
                mejor = None
                for lado, ext, borde in ((1, float(vela["h"]), up), (-1, float(vela["l"]), dn)):
                    est = (ext - borde) * lado
                    if est > max(a_est * ancho, 0.0) and est > 0:
                        ret = max(0.0, (ext - p) * lado) / est
                        if mejor is None or est > mejor[1]:
                            mejor = (lado, est, ret, ext)
                if mejor:
                    lado, est, ret, ext = mejor
                    if bbrsi:
                        serie = _rsi_serie(cerr[-(rp * 12 + 1):] + [ext], rp)
                        if not serie or not (serie[-1] > alto if lado > 0 else serie[-1] < bajo):
                            mejor = None
                if mejor:
                    lado, est, ret, ext = mejor
                    d = _boll_dir(lado, sentido)
                    if directo > 0 and est >= directo * ancho:
                        estado = "entra directo" if ventana and falta >= hasta else "estirón grande"
                    else:
                        estado = ("retrocedió de más" if ret > a_rmax else "esperando retroceso" if ret < a_rmin
                                  else ("entra ya" if ventana and falta >= hasta else "en zona"))
                    estirados.append({"par": par, "dir": d, "est": round(est / ancho * 100), "ret": round(ret * 100),
                                      "estado": estado})
                else:
                    da, db = (up - p) / ancho, (p - dn) / ancho
                    lado, dist = (1, da) if da <= db else (-1, db)
                    if dist >= 0:
                        cerca.append({"par": par, "lado": "arriba" if lado > 0 else "abajo", "dist": round(dist * 100)})
            # solo los que cumplen (en la zona de retroceso o con estirón para entrar directo)
            estirados = [x for x in estirados if x["estado"] in ("entra ya", "en zona", "entra directo", "estirón grande")]
            estirados.sort(key=lambda x: (x["estado"] not in ("entra ya", "entra directo"), -x["est"]))
            out = {"falta": round(falta), "ventana": ventana, "rmin": round(a_rmin * 100), "rmax": round(a_rmax * 100),
                   "desde": desde, "limite": hasta, "directo": round(directo * 100), "estirados": estirados[:3],
                   "cerca": [], "leyendo": len(getattr(self, "seleccion", []) or [])}
            self._ant_cache = (ahora, out)
            return out
        except Exception:
            return None

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        ent_g = ent_p = niv_g = niv_p = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                niv_g += neto > 0; niv_p += neto < 0
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                ent_g += neto > 0; ent_p += neto < 0
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor,
                "ent_g": ent_g, "ent_p": ent_p, "niv_g": niv_g, "niv_p": niv_p}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas",
             "incluir_otc", "incluir_mercado_real", "incluir_digital", "rec_multiplicador", "bb_periodo", "bb_desv",
             "rsi_periodo", "rsi_alto", "rsi_bajo", "rsi_direccion", "entrada", "estiro", "ia_prob_min", "ia_modo",
             "ia_forzar")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            if int(guardado.get("config_v", 0) or 0) < 6:
                # M1 ya no se opera: quien estaba en M1 pasa a M2
                tfs = [int(t) for t in (guardado.get("temporalidades") or []) if int(t) in (2, 3, 4, 5)]
                guardado["temporalidades"] = tfs[:1] or [2]
                guardado["config_v"] = 6
            if int(guardado.get("config_v", 0) or 0) < 8:
                # 8: a todos les llega la configuración por defecto del autor: RSI 2 · 60/40 a favor y
                # Bollinger 20 · 2. MHI ya no existe (pasa a Bollinger + RSI).
                guardado.update(rsi_periodo=2, rsi_alto=60, rsi_bajo=40, rsi_modo="favor", boll_periodo=20, boll_dev=2.0)
                if guardado.get("estrategia") == "mhi":
                    guardado["estrategia"] = "bbrsi"
                guardado["config_v"] = 8
            if int(guardado.get("config_v", 0) or 0) < 10:
                # anticipado: a todos les llega la configuración de las entradas buenas (10 / 25 / 35)
                guardado.update(ant_estiron=10, ant_retro_min=25, ant_retro_max=35)
                guardado["config_v"] = 10
            if int(guardado.get("config_v", 0) or 0) < 11:
                # 11: apartado Estrategias. Cada uno sigue con la estrategia que tenía (sola).
                e = guardado.get("estrategia")
                guardado["estrategias_on"] = [e if e in ("bbrsi", "rsi", "boll") else "bbrsi"]
                guardado["config_v"] = 11
            if int(guardado.get("config_v", 0) or 0) < 12:
                # 12: a todos les llegan todas las estrategias elegidas (Auto); cada uno puede quitar las que quiera
                guardado["estrategias_on"] = "todas"
                if guardado.get("estrategia") in ("bbrsi", "rsi", "boll"):
                    guardado["estrategia"] = "multi"
                guardado["config_v"] = 12
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = False                       # ya no hay temporalidad Auto
    cfg.pop("tfs_auto", None)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    cfg["estrategias_on"] = estrategias_on(cfg) or ["bbrsi"]
    if cfg.get("estrategia") not in ("bbrsi", "rsi", "boll", "multi"):     # MHI ya no existe
        cfg["estrategia"] = "bbrsi"                # la IA ya no existe: Bollinger + RSI
    if cfg.get("rec_modo") not in ("auto", "perdida"):
        cfg["rec_modo"] = "auto"                   # el multiplicador manual ya no existe: lo calcula el bot
    cfg["config_v"] = DEFAULT_CONFIG["config_v"]
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)
        shutil.rmtree(os.path.join(base, "ia_velas"), ignore_errors=True)   # la IA ya no guarda velas: aprende en vivo


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def monto_nivel(cfg, perdido, payout=0.85):
    """Monto de un nivel. Automático: recupera lo perdido en el ciclo + la ganancia de la entrada base.
    "Solo pérdida" (autor): recupera solo lo perdido (nunca menos que la entrada base)."""
    base = float(cfg["monto_entrada"])
    p = payout or 0.85
    if cfg.get("rec_modo") == "perdida":
        m = max(base, perdido / p)
    else:
        m = (perdido + base * p) / p
    return max(1.0, round(m, 2))


def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            monto = monto_nivel(cfg, perdido, payout)
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

