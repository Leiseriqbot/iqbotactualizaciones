# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "2.0"
BUILD_BOT = 180

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": False,      # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT 3.0",
    "subtitulo": "Más simple, más liviano y tú eliges la estrategia",
    "items": [
        ["📊", "Bandas de Bollinger", "Son dos líneas alrededor del precio (promedio de 20 velas ± 2 desviaciones). Cuando el precio sale por arriba, el bot entra PUT; cuando sale por abajo, CALL, esperando que regrese."],
        ["📈", "RSI", "Mide la fuerza del movimiento de 0 a 100. Con periodo 2 y niveles 60/40: si cruza hacia arriba el 60 la señal es CALL; si cruza hacia abajo el 40, PUT. Si quieres apostar a que el precio se devuelve, cámbialo a dirección invertida: al cruzar el 60 entra PUT y al cruzar el 40 entra CALL."],
        ["⚙️", "Cómo usarlas", "En Configuración → Estrategia elige Bollinger o RSI. Si no estás seguro, deja los valores que trae. Prueba primero en DEMO y usa pocas recuperaciones."],
        ["🪜", "Recuperación por niveles", "Si una entrada pierde, el bot espera la siguiente señal en otro par. Ya no hace gale ni cambia de dirección."],
        ["🎯", "Bollinger al estirarse", "Con Bollinger puedes elegir la entrada: al cierre de la vela o al estirarse (entra apenas el precio se sale de la banda el % que pongas, sin esperar el cierre)."],
        ["⏱️", "Temporalidad en minutos", "Ahora es un solo campo: pones de 1 a 5 minutos con los botones − y +. Viene en 1 minuto."],
        ["🌎", "Todos los pares", "Vigila OTC, digital y mercado real, y solo entra en pares que paguen 80 % o más."],
    ],
    "aviso": "Operar tiene riesgo alto de pérdida. Ninguna estrategia gana siempre ni garantiza resultados.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [2],           # manual: una temporalidad de 2 a 5 minutos (M1 ya no se usa)
    "tf_auto": False,                # ya no hay temporalidad Auto: una sola, de M1 a M5
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "incluir_digital": True,         # también opciones digitales (se usa la que mejor pague)
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 6,                   # 3.0: estrategia única · 4: RSI normal · 5: temporalidad en minutos · 6: sin M1
    # estrategia (3.0)
    "estrategia": "bollinger",       # "bollinger" o "rsi"
    "bb_periodo": 20,
    "bb_desv": 2.0,
    "rsi_periodo": 2,
    "rsi_alto": 60.0,
    "rsi_bajo": 40.0,
    "rsi_direccion": "normal",       # "normal" o "invertida" (el cliente la invierte si quiere)
    "entrada": "cierre",             # "cierre" o "estirado" (al estirarse, solo Bollinger)
    "ia_prob_min": 58,               # modo "segura": mínimo de acierto que calcula la IA para entrar (55 a 70 %)
    "ia_modo": "normal",             # solo el autor: "segura" = la IA entra solo con su señal más segura (espera lo necesario)
    "ia_forzar": False,              # solo el autor: la IA opera aunque no pase el umbral (DEMO o REAL, decisión del autor)
    "estiro": 20.0,                  # al estirarse: % del ancho de las bandas que el precio debe pasar la banda
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

LOGIN_INTENTOS = 3                 # al entrar: intentos si la red o el bróker no responden


def _es_fallo_de_red(e):
    """True si el error es de la red o de que el bróker no respondió (no de la librería ni de la cuenta).
    La librería a veces devuelve el error de red como respuesta y falla al leerlo ('ConnectTimeout' object has no
    attribute 'text'): también cuenta como fallo de red."""
    t = (type(e).__name__ + " " + str(e)).lower()
    return any(x in t for x in ("connecttimeout", "readtimeout", "connectionerror", "connection aborted",
                                "connection reset", "max retries", "timed out", "timeout", "newconnectionerror",
                                "nameresolution", "getaddrinfo", "temporarily unavailable", "remote end closed",
                                "proxyerror", "10060", "10054", "10061"))


def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

LICENCIA_IA = False        # el autor marcó "SI" en la columna IA de la hoja de licencias de esta cuenta


def ia_permitida():
    """¿Esta licencia tiene la IA habilitada por el autor (columna IA = SI)?"""
    return bool(LICENCIA_IA)


def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER, "ia": "1"}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    global LICENCIA_IA
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        r = r.split("|")
        r, con_ia = r[0], "IA" in r[1:]           # "VALID|IA": el autor le habilitó la IA a esta cuenta
        respuestas[c] = r
        if r == "VALID":
            LICENCIA_IA = con_ia
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER,
                               "ia": _firma_licencia(f"{c}|{ahora}|ia") if con_ia else ""}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    LICENCIA_IA = False
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                LICENCIA_IA = d.get("ia") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|ia")
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas por el buzón común (si el bróker no da número de pedido)
        self.lock_rid = threading.Lock()      # contador de números de pedido
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self._memo_velas = {}                 # (id del par, tamaño) -> {hora: cierre} de la última respuesta buena
        self._buzon_sucio = 0.0               # hasta cuándo puede llegar tarde una respuesta vieja al buzón común
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        nb = nombre_broker()
        intento = 0
        while True:                                     # si falla por la red, reintenta solo (3 intentos)
            intento += 1
            try:
                ok, motivo = con_timeout(api.connect, 45)
                if ok or not _es_fallo_de_red(motivo):
                    break                               # entró, o la respuesta no es de red (clave, 2FA…)
            except TimeoutError:
                pass
            except json.JSONDecodeError as e:
                crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
                return None, (f"{nb} devolvió una respuesta inesperada al iniciar sesión "
                              "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                              "navegador para confirmar que tu cuenta abre bien."
                              + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
            except Exception as e:
                if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                    return None, (f"No se pudo verificar la conexión segura con {nb} (certificado no válido). "
                                  "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                                  "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
                if not _es_fallo_de_red(e):
                    libreria_conecto(False, culpa_de_libreria=True)
                    return None, f"Error de conexión: {e}"
            if intento >= LOGIN_INTENTOS:
                return None, (f"{nb} no respondió a tiempo (se intentó {LOGIN_INTENTOS} veces). "
                              f"Puede ser tu internet o que los servidores de {nb} estén lentos en este momento. "
                              "Espera un minuto y vuelve a entrar; si sigue igual, prueba con otra red (por ejemplo, los datos del celular).")
            time.sleep(3 * intento)                     # espera un poco más en cada intento
            try:
                api = IQ_Option(email, clave)           # conexión nueva para el siguiente intento
            except Exception:
                pass
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        raw = self._pedir_velas(aid, tf_min * 60, cantidad + 1, time.time())
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _pedir_velas(self, aid, tam, cantidad, hasta):
        """Pide velas con NÚMERO DE PEDIDO propio: la respuesta solo le llega a quien la pidió, así una respuesta
        atrasada de otro par nunca se confunde con esta (antes se mezclaban velas de otros activos).
        Si el bróker no devuelve el número, usa el buzón común con más cuidado. Siempre revisa las velas."""
        inner = self.inner
        raw = None
        if getattr(self, "_rid_ok", None) is not False:
            buzon = getattr(inner, "_iqbot_velas", None)
            if buzon is None:
                buzon = inner._iqbot_velas = {}
            with self.lock_rid:
                self._rid_n = getattr(self, "_rid_n", 0) + 1
                rid = f"iqv{self._rid_n}"
            datos = {"name": "get-candles", "version": "2.0",
                     "body": {"active_id": int(aid), "split_normalization": True, "size": int(tam),
                              "to": int(hasta), "count": int(cantidad), "": int(aid)}}
            try:
                inner.send_websocket_request("sendMessage", datos, request_id=rid)
                raw = _esperar(lambda: buzon.get(rid), 5)
            except Exception:
                raw = None
            buzon.pop(rid, None)
            if raw is not None:
                self._rid_ok = True
            elif getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: buzón común
        if raw is None and getattr(self, "_rid_ok", None) is False:
            with self.lock:                           # buzón común: un pedido a la vez
                espera = self._buzon_sucio - time.time()
                if espera > 0:                        # una respuesta vieja puede llegar todavía: se deja pasar
                    _esperar(lambda: inner.candles.candles_data, min(espera, 3))
                inner.candles.candles_data = None
                inner.getcandles(aid, tam, cantidad, float(hasta))
                raw = _esperar(lambda: inner.candles.candles_data, 5)
                if raw is None:
                    self._buzon_sucio = time.time() + 10
        if not raw:
            return raw
        if not self._velas_buenas(aid, tam, raw, hasta):
            return None
        return raw

    def _velas_buenas(self, aid, tam, raw, hasta):
        """Revisión de seguridad: las velas tienen que ser de ESTE par. Se comparan con las que ya llegaron antes
        (las mismas horas deben tener el mismo cierre) y se descartan saltos imposibles dentro del bloque."""
        try:
            cierres = [float(v["close"]) for v in raw]
            if not cierres or min(cierres) <= 0:
                return False
            orden = sorted(cierres)
            med = orden[len(orden) // 2]
            if any(abs(c / med - 1) > 0.25 for c in cierres):        # dos activos distintos en un mismo bloque
                return False
            memo = self._memo_velas.setdefault((int(aid), int(tam)), {})
            iguales = distintas = 0
            for v in raw[:-1]:                                      # la última puede estar formándose
                previo = memo.get(int(v["from"]))
                if previo is not None:
                    if abs(float(v["close"]) / previo - 1) < 1e-4:
                        iguales += 1
                    else:
                        distintas += 1
            if distintas >= 2 and distintas > iguales:              # las mismas horas con otros precios: es otro par
                return False
            if not iguales and memo:                                # sin horas en común: si son horas cercanas,
                t_ult = int(raw[-1]["from"])                         # el precio debe estar cerca
                cerca = min(memo, key=lambda t: abs(t - t_ult))
                if abs(cerca - t_ult) <= 3 * 3600 and abs(cierres[-1] / memo[cerca] - 1) > 0.25:
                    return False
            for v in raw[:-1]:
                memo[int(v["from"])] = float(v["close"])
            if len(memo) > 3000:
                for t in sorted(memo)[:len(memo) - 2500]:
                    memo.pop(t, None)
            return True
        except Exception:
            return True

    def velas_hasta_t(self, par, cantidad, hasta):
        """v3: velas M1 CERRADAS que terminan en 'hasta' (para completar la memoria hacia atrás o hacia adelante)."""
        aid = self._id(par)
        if aid is None:
            return []
        raw = self._pedir_velas(aid, 60, int(cantidad), float(hasta))
        if not raw:
            return []
        ahora = self.ahora()
        return [{"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]}
                for v in raw if v["from"] + 60 <= ahora]

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos: una sola temporalidad, de M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
VOL_MAXIMA = 2.0                               # filtro del autor: no entra si las últimas velas miden más del doble de lo normal
PREPARAR_A_LA_VEZ = 3                          # pares que se leen a la vez antes del cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real)."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


BBRSI_PRESETS = {           # "BB + RSI" (autor): la mejor combinación medida en el historial de Exnova para cada temporalidad
    1: (20, 2.5, 14, 75, 25),  # (periodo Bollinger, desviaciones, periodo RSI, nivel alto, nivel bajo)
    2: (20, 2.0, 7, 80, 20),
    3: (20, 2.5, 14, 75, 25),
    4: (20, 2.5, 14, 75, 25),
    5: (20, 2.5, 7, 80, 20),
}


def bbrsi_preset(cfg):
    try:
        tf = int((cfg.get("temporalidades") or [2])[0])
    except (TypeError, ValueError):
        tf = 2
    return tf, BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])


def senal(cierres, cfg, estiro=None):
    """(dirección o None, texto). 'cierres' termina con el precio de la vela de señal.
    estiro: solo Bollinger "al estirarse" (% del ancho de las bandas que el precio debe pasar la banda)."""
    if cfg.get("estrategia") == "bbrsi":          # entra solo si coinciden: fuera de la banda y RSI en su extremo
        _tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
        b = bandas(cierres, per, k)
        serie = _rsi_serie(cierres[-(rp * 12 + 2):], rp)
        if not b or not serie:
            return None, ""
        c, r = cierres[-1], serie[-1]
        if c > b[0] and r > alto:
            return "put", f"sobre la banda y RSI {r:.0f}"
        if c < b[2] and r < bajo:
            return "call", f"bajo la banda y RSI {r:.0f}"
        return None, ""
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres[-(per * 12 + 2):], per)
        if len(serie) < 2:
            return None, ""
        antes, ahora = serie[-2], serie[-1]
        alto, bajo = float(cfg.get("rsi_alto", 60)), float(cfg.get("rsi_bajo", 40))
        d, txt = None, ""
        if antes < alto <= ahora:
            d, txt = "call", f"RSI cruzó hacia arriba {alto:g}"
        elif antes > bajo >= ahora:
            d, txt = "put", f"RSI cruzó hacia abajo {bajo:g}"
        if d and cfg.get("rsi_direccion") == "invertida":
            d = "call" if d == "put" else "put"
            txt += " (invertida)"
        return d, txt
    per = max(2, int(cfg.get("bb_periodo") or 20))
    k = float(cfg.get("bb_desv") or 2)
    b = bandas(cierres, per, k)
    if not b:
        return None, ""
    arriba, _m, abajo = b
    extra = 0.0 if estiro is None else (arriba - abajo) * float(estiro) / 100.0
    c = cierres[-1]
    if c > arriba + extra:
        return "put", (f"estirado {100 * (c - arriba) / (arriba - abajo):.0f}% sobre la banda de arriba"
                       if estiro is not None else "sobre la banda de arriba")
    if c < abajo - extra:
        return "call", (f"estirado {100 * (abajo - c) / (arriba - abajo):.0f}% bajo la banda de abajo"
                        if estiro is not None else "bajo la banda de abajo")
    return None, ""


def ia_minimo(cfg):
    """Modo "señal más segura": el mínimo de acierto que eligió el autor (55 a 70 %), como fracción."""
    try:
        return max(55, min(70, int(cfg.get("ia_prob_min") or IA_PROB_SEGURA * 100))) / 100.0
    except Exception:
        return IA_PROB_SEGURA


def ia_probabilidad(ev, pago):
    """La IA estima cuánto gana por dólar (gana 'pago' o pierde 1): de ahí sale la probabilidad de acertar."""
    p = float(pago or 0.85)
    return max(0.0, min(1.0, (float(ev) + 1.0) / (p + 1.0)))


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "bbrsi":
        tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
        return f"BB + RSI (M{tf}: BB {per},{k:g} · RSI {rp} {alto}/{bajo})"
    if cfg.get("estrategia") == "ia":
        if autor and cfg.get("ia_modo") == "segura":
            return f"IA (señal más segura {ia_minimo(cfg) * 100:.0f}%)"
        return "IA (aprende sola)"
    if cfg.get("estrategia") == "rsi":
        inv = " invertida" if cfg.get("rsi_direccion") == "invertida" else ""
        return f"RSI {int(cfg.get('rsi_periodo') or 2)} ({cfg.get('rsi_alto', 60):g}/{cfg.get('rsi_bajo', 40):g}){inv}"
    t = f" al estirarse {float(cfg.get('estiro', 20)):g}%" if cfg.get("entrada") == "estirado" else ""
    return f"Bollinger {int(cfg.get('bb_periodo') or 20)},{float(cfg.get('bb_desv') or 2):g}{t}"


# =====================================================================
#  IA DEL AUTOR (3.0): aprendizaje por refuerzo EN LÍNEA, en código propio (sin librerías: PC y celular).
#  En binarias cada decisión dura una vela: al cerrar se sabe cuánto habría pagado CALL y cuánto PUT,
#  así que aprende de TODOS los pares en cada cierre, opere o no (premio = pago del par, castigo = −1).
#  Red pequeña: ~34 datos de entrada -> 16 neuronas -> 2 salidas (lo que espera ganar con CALL y con PUT).
#  Empieza en MODO SOMBRA (decide sin operar) y solo opera cuando su acierto real pasa del 55 % en 300 señales.
#  Solo la ven y la usan las cuentas del autor.
# =====================================================================
IA_ARCHIVO = "ia_refuerzo.json"
IA_CARPETA_VELAS = "ia_velas"
IA_VELAS_DESCARGA = 20000         # velas M1 por par para el primer entrenamiento (≈ 2 semanas)
IA_SENALES_MIN = 300              # señales en sombra antes de poder operar (máximo una por minuto)
IA_SENALES_VENTANA = 1000         # se mide con las últimas 1.000 señales
IA_HORAS_MIN = 2.0                # y repartidas en al menos 2 horas
IA_EQUILIBRIO = 1 / 1.85          # acierto que no pierde ni gana con pago de 85 % (≈ 54 %)
IA_Z = 1.645                      # 95 % de seguridad (una cola)
IA_ACIERTO_APAGAR = 0.53          # si opera y baja de esto en las últimas 300, vuelve a modo sombra


def ia_limite_inferior(g, n, z=IA_Z):
    """Límite inferior de Wilson: el acierto mínimo que se puede asegurar con 95 % de confianza."""
    if n <= 0:
        return 0.0
    p = g / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - r) / d


def ia_acierto_necesario(n):
    """Con n señales, qué acierto hace falta para estar sobre el equilibrio con 95 % de seguridad."""
    n = max(int(n), IA_SENALES_MIN)
    for k in range(int(n * IA_EQUILIBRIO), n + 1):
        if ia_limite_inferior(k, n) >= IA_EQUILIBRIO:
            return k / n
    return 1.0
IA_PROB_SEGURA = 0.58             # modo "señal más segura" del autor: mínimo por defecto (él lo ajusta de 55 % a 70 %)
IA_PROB_CLIENTES = 0.60           # clientes con IA: siempre la señal más segura, con 60 % o más (fijo)
IA_UMBRAL = 0.04                  # entra solo si espera ganar más de 4 centavos por dólar
IA_VERSION = 2                    # 2 = IA autónoma: solo velas crudas y contexto (sin indicadores ni estrategias)
IA_OCULTAS = 24
IA_VELAS_VE = 20                  # velas que ve completas (cuerpo y mechas)
IA_ENTRADAS = IA_VELAS_VE * 3 + 19
# Lo aprendido en el PC del autor viaja con cada actualización (lo escribe PUBLICAR_ACTUALIZACION en la línea de abajo).
# Al abrir, el equipo del autor toma esta IA si es más nueva que la suya. (Para los clientes la IA está apagada.)
IA_BASE = {'iqoption': {'v': 2, 'w1': [[-0.039359, -0.014997, -0.010253, -0.031738, 0.020209, -0.023361, 0.039508, -0.013082, -0.015888, -0.002209, 0.062469, -0.00645, 0.035986, -0.054245, 0.049396, 0.095261, 0.153627, -0.010905, -0.018953, -0.004094, -0.083396, -0.064489, 0.045043, 0.028156, -0.051758, -0.013659, -0.09345, 0.083938, -0.099207, 0.037, 0.03328, -0.000143, 0.032884, 0.071524, 0.0244, 0.042159, -0.00588, -0.004881, -0.011434, 0.005704, -0.08046, 0.053341, 0.033345, 0.182981, 0.037507, -0.041751, -0.075286, 0.064327, 0.009177, -0.050683, 0.018459, -0.017736, 0.056507, 0.012364, -0.123942, 0.117947, -0.172661, -0.022937, -0.047786, 0.034635, 0.09044, -0.101824, -0.080048, 0.215069, 0.041204, 0.019968, 0.028183, -0.01028, -0.016177, -0.008559, -0.004472, -0.03307, 0.049028, 0.110955, 0.052006, -0.053446, 0.04978, -0.019334, -0.002075], [0.003688, 0.034697, -0.047965, -0.001869, -0.006498, -0.097439, -0.020119, -0.032356, 0.073993, 0.005141, -0.037125, 0.038944, -0.018917, 0.060712, 0.013388, -0.032574, 0.074829, -0.005663, -0.027354, 0.073955, -0.031044, 0.038233, -0.096291, 0.019879, 0.048657, 0.010295, -0.048254, -0.121862, -0.051669, -0.080248, 0.066346, 0.056915, 0.018926, 0.057827, 0.096869, 0.06151, 0.025016, 0.036773, 0.103647, 0.017386, 0.110441, -0.065697, 0.026765, 0.045569, -0.147181, -0.07566, -0.029854, -0.034541, -0.054396, 0.050887, -0.052294, -0.122308, -0.062473, 0.099032, -0.119912, -0.120586, -0.012125, -0.118811, -0.058639, -0.072773, 0.151772, 0.031877, -0.136268, 0.063505, 0.060223, -0.03635, 0.003623, 0.001898, 0.011741, 0.007526, -0.010859, 0.083229, -0.026759, -0.107312, 0.099235, -0.000684, -0.074328, -0.067968, -0.079108], [-0.010329, 0.030437, 0.115845, 0.066968, 0.025071, 0.011407, 0.012655, -0.089862, 0.014517, -0.004765, 0.065842, 0.034479, 0.036481, 0.016657, -0.027233, 0.079037, 0.008578, 0.121592, -0.010685, -0.005298, -0.074104, 0.051016, -0.141206, 0.006606, 0.154153, 0.125712, 0.059374, -0.019888, 0.106937, -0.099635, -0.005595, -0.142893, 0.026421, -0.011611, -0.040553, -0.040718, 0.100346, 0.072962, 0.028908, -0.062016, 0.103066, -0.123463, -0.167361, 0.07431, -0.044091, -0.003899, 0.025179, 0.008003, -0.064972, 0.033398, -0.02381, -0.171017, -0.072436, 0.14469, -0.047819, 0.016046, 0.034241, -0.019321, -0.148753, -0.066124, 0.101411, -0.147253, -0.044832, 0.135752, 0.063842, 0.01348, 0.033391, -0.015757, -0.010177, -0.050045, 0.056204, 0.026683, -0.027586, 0.097573, -0.050447, 0.069472, -0.072205, -0.042082, 0.000842], [0.014712, 0.073597, -0.013341, 0.003812, 0.006899, -0.004728, -0.064198, -0.100609, 0.005911, 0.025642, 0.120367, 0.05896, 0.029393, -0.090953, 0.034302, 0.056562, -0.04295, -0.011394, 0.03613, -0.128498, -0.002654, -0.165306, -0.006014, 0.040621, -0.013858, 0.034234, 0.028201, 0.056881, -0.079643, -0.111205, 0.029997, 0.035581, 0.025011, 0.13785, -0.07732, -0.039159, 0.07072, 0.075649, -0.005125, 0.044285, -0.006159, 0.027209, -0.040023, 0.108429, -0.070401, 0.029532, -0.022509, 0.050344, 0.01157, -0.012135, 0.0444, -0.118032, 0.127455, 0.125464, -0.117974, -0.000805, 0.007085, -0.037126, -0.246621, 0.239245, 0.145194, -0.083309, -0.136079, 0.066713, 0.004752, 0.00359, 0.008251, 0.009558, -0.035276, -0.010201, 0.076086, 0.089135, -0.098247, 0.11023, 0.028285, -0.099088, -0.052711, -0.016864, -0.01137], [-0.01648, -0.082051, -0.025953, 0.030465, -0.047474, 0.036679, -0.0113, 0.136587, -0.1553, -0.049211, -0.02677, 0.01648, -0.021193, 0.034354, -0.050178, -0.098081, 0.010503, 0.041759, -0.05155, -0.006106, -0.022267, -0.03272, 0.147868, 0.036952, -0.010772, 0.164399, -0.001064, 0.018582, -0.130384, 0.012634, 0.027754, -0.048521, -0.069617, -0.05695, -0.106995, 0.085475, -0.005829, 0.089343, -0.174619, 0.069816, -0.119148, 0.020509, -0.066735, 0.009411, -0.030889, -0.01669, -0.02165, -0.058735, 0.012511, 0.008668, -0.069957, -0.083813, 0.02165, -0.025052, -0.063514, -0.027747, 0.031418, -0.015647, -0.077048, 0.035152, 0.043863, -0.104237, 0.070453, -0.089391, 0.033007, -0.047571, -0.000225, 0.020599, 0.025744, -0.016043, -0.02547, 0.072094, 0.011354, 0.001504, -0.00022, 0.130346, 0.012889, 0.01279, -0.046576], [0.06664, 0.079362, 0.157429, -0.001392, -0.062315, 0.091944, -0.015348, -0.044797, 0.009295, -0.034097, 0.045328, 0.124007, -0.003492, -0.025539, 0.126447, -0.014673, 0.046322, 0.074496, 0.067148, -0.012077, 0.126323, -0.013095, 0.003419, -0.161711, 0.020368, 0.027115, 0.006351, 0.007352, 0.046719, -0.026621, 0.060355, 0.119018, -0.039714, -0.012916, -0.081546, -0.022265, -0.006311, -0.069, -0.037839, 0.058514, -0.009933, -0.009317, 0.075331, -0.087419, 0.047638, -0.065264, 0.015462, -0.079164, -0.043923, 0.006637, 0.030815, 0.059023, 0.15913, -0.117978, -0.005177, -0.061864, 0.099896, 0.041878, 0.01803, -0.202483, -0.101801, -0.02451, -0.073073, 0.004954, 0.041142, 0.000442, 0.016713, -0.017169, -0.000233, -0.022098, -0.054727, 0.038245, -0.059492, -0.088901, 0.045652, 0.005319, 0.009539, -0.001335, 0.083841], [0.015334, -0.22283, 0.075005, 0.057914, -0.022974, 0.082362, -0.011131, 0.080753, -0.050102, 0.102225, 0.028166, 0.083901, -0.051322, 0.018203, -0.028064, 0.008106, -0.016772, -0.077701, 0.075792, 0.13224, 0.009472, -0.106102, 0.023477, 0.116683, 0.036107, 0.089998, 0.001168, -0.029423, 0.116618, 0.042758, 0.020718, -0.066258, -0.085817, 0.019393, 0.036859, -0.075776, 0.059349, 0.00592, 0.013277, -0.062254, -0.083913, 0.027774, -0.111574, 0.044257, -0.081717, 0.067667, -0.026277, 0.0897, -0.016451, -0.060018, -0.012167, -0.175272, -0.044765, 0.067326, -0.194064, 0.092386, -0.129045, -0.096731, 0.054088, 0.011611, 0.336294, -0.227845, 0.027047, 0.015532, -0.030825, 0.033574, -0.036187, -0.00142, -0.0154, 0.021738, 0.034154, -0.01636, -0.113025, 0.076558, -0.09995, 0.059968, 0.010605, 0.014403, 0.133929], [0.013717, 0.060557, -0.112356, -0.046806, 0.059566, -0.025501, -0.066917, 0.052373, -0.008061, 0.020368, -0.129516, 0.030384, 0.091747, -0.046919, 0.099017, 0.002561, 0.023835, -0.022633, -0.046312, -0.035747, 0.05066, -0.122092, 0.016424, -0.089514, 0.023127, 0.032393, -0.071629, -0.059233, -0.017847, 0.013078, 0.094872, 0.177179, 0.068193, -0.106045, -0.055208, -0.131214, -0.006786, -0.002601, 0.044257, 0.063776, 0.121491, -0.065262, 0.004598, -0.020003, -0.055737, -0.004072, 0.06877, -0.115699, -0.093437, 0.012395, 0.043411, 0.103531, 0.212703, 0.037191, -0.03962, -0.165454, 0.071185, 0.079805, -0.046327, 0.028528, -0.205035, 0.168414, 0.005942, 0.010213, 0.01876, -0.00682, 0.017266, 0.03512, -0.002507, 0.007949, -0.006545, 0.067153, -0.082766, 0.105237, -0.134615, -0.028242, -0.084182, 0.019459, -0.048301], [0.043112, -0.122987, -0.027333, -0.100098, 0.006714, 0.025579, -0.03174, -0.078562, -0.155751, -0.085032, 0.094372, -0.017098, 0.072646, 0.055956, -0.061359, -0.037779, 0.018617, 0.037784, 0.032804, -0.053926, -0.023431, 0.021322, 0.061807, -0.014856, 0.027007, -0.062677, -0.079014, 0.101832, -0.005596, 0.110698, 0.00477, 0.057663, 0.100966, -0.032294, -0.017578, -0.048372, -0.075973, -0.096039, -0.042078, -0.071003, 0.012488, -0.13019, -0.102332, 0.07888, 0.051276, -0.096972, 0.028346, -0.087105, -0.017978, -0.083795, 0.151737, 0.035226, 0.120898, -0.015136, -0.012415, -0.025705, 0.076495, 0.072789, 0.044472, -0.144517, -0.159437, 0.007576, 0.059271, -0.098449, 0.02196, 0.029844, -0.025359, -0.039506, -0.005953, -0.041706, 0.003272, 0.052654, 0.031612, 0.053808, 0.024538, -0.045435, 0.077972, 0.03696, 0.058337], [0.056951, 0.107981, -0.143169, -0.077952, 0.098276, -0.028585, 0.006749, 0.08078, 0.019403, -0.076568, 0.014359, 0.064825, 0.041064, 0.055797, 0.088968, 0.082205, -0.089879, -0.124945, -0.033725, 0.078721, 0.047986, 0.007712, 0.069978, -0.032984, -0.067295, -0.067437, 0.03028, 0.045511, -0.075212, 0.061558, 0.120671, 0.142957, -0.008365, -0.024418, -0.068908, -0.015747, -0.101784, 0.023895, -0.016582, 0.010112, 0.026981, 0.072703, 0.126531, 0.079721, 0.118316, -0.009612, -0.019104, 0.098936, -0.034185, -0.051485, -0.110787, -0.004574, 0.041989, -0.029694, -0.073638, 0.048978, -0.087494, -0.032824, -0.208125, 0.215224, 0.001238, 0.05946, 0.00753, 0.179955, -0.021438, 0.01684, 0.064121, -0.013051, -0.025608, 0.004494, -0.093209, -0.049197, -0.129202, 0.093711, 0.025467, 0.070478, -0.121983, -0.010614, -0.061869], [-0.046379, 0.049896, 0.001913, 0.013762, -0.06429, 0.046038, 0.013391, -0.004256, 0.009505, -0.057217, 0.067696, 0.020252, 0.016584, 0.021094, -0.026614, -0.050263, 0.067155, 0.052138, -0.031076, 0.03041, 0.044623, 0.009579, 0.071399, -0.003698, -0.051599, 0.141763, 0.026817, -0.02035, -0.022198, -0.076465, 0.067915, 0.032169, 0.041977, -0.012811, -0.021961, -0.003012, 0.002094, -0.145051, -0.076835, 0.026867, -0.110299, -0.041927, 0.021883, 0.049812, 0.067308, 0.015841, 0.039697, -0.033421, 0.030423, 0.046428, -0.154505, -0.103279, -0.072125, -0.010555, -0.158867, 0.05668, -0.079772, -0.171153, 0.053153, -0.044867, 0.304072, -0.116442, 0.04121, 0.158812, 0.037593, 0.022783, 0.029026, -0.013277, 0.041941, -0.026588, -0.034358, -0.033183, -0.013981, -0.028749, 0.061759, -0.013484, 0.060904, 0.023052, 0.110125], [-0.11857, 0.023228, -0.103588, 0.050447, 0.021773, -0.021946, 0.064168, 0.036691, 0.00618, -0.016768, -0.042081, -0.053021, 0.083691, -0.052321, -0.03963, 0.018768, -0.021897, 0.111557, -0.032667, -0.013515, -0.024082, -0.04129, 0.169593, -0.085847, -0.04068, 0.019397, 0.230398, -0.007399, 0.049617, -0.080456, 0.037055, -0.019747, 0.008434, 0.096668, 0.08925, 0.137762, -0.008285, -0.176722, -0.079206, 0.020543, -0.176781, 0.08519, 0.044898, 0.04681, 0.047732, 0.141873, -0.07256, 0.175467, 0.090046, 0.045942, -0.11232, -0.050981, -0.055091, 0.076854, -0.257767, 0.018292, -0.036156, -0.192819, -0.084408, 0.093784, 0.497701, -0.106077, -0.002067, 0.229125, 0.015542, -0.013451, -0.045122, 0.041599, 0.046904, -0.015987, 0.029272, -0.03814, -0.071356, 0.090957, -0.017686, 0.048978, 0.029034, -0.028241, 0.051071], [-0.027163, 0.084765, -0.056161, 0.02666, -0.053038, 0.035004, -0.043221, -0.027584, 0.153774, 0.071095, 0.004494, -0.101434, 0.010485, -0.099275, 0.062342, 0.033282, 0.047903, 0.068992, 0.010037, -0.004037, 0.104182, -0.03746, 0.063011, -0.046172, -0.134061, 0.016355, 0.179107, 0.037398, 0.102747, 0.146015, -0.081007, 0.057744, -0.050485, 0.110686, -0.034223, -0.105774, 0.111283, -0.104377, 0.012001, 0.075158, 0.014281, 0.009037, -0.013227, 0.026636, 0.121215, 0.053891, 0.031329, -0.048024, 0.096498, 0.009737, 0.048247, -0.057294, 0.022724, -0.189168, 0.130446, 0.066985, 0.033157, 0.050681, -0.116068, 0.10915, -0.279023, 0.032633, 0.065721, -0.02717, 0.061976, 0.009087, -0.069994, 0.041822, 0.044271, -0.013534, 0.039427, 0.049183, -0.180916, -0.080202, -0.03302, 0.049722, -0.073974, -0.072455, -0.009683], [0.035773, -0.05481, 0.011826, -0.134968, 0.102261, -0.048579, -0.014563, -0.060555, 0.032778, 0.013914, -0.062551, -0.03734, -0.024686, 0.046745, -0.0994, -0.030015, -0.031333, -0.032336, 0.047064, 0.057431, -0.044797, 0.004895, 0.000989, -0.006676, -0.032705, -0.031309, 0.050492, -0.019938, 0.054124, 0.03049, 0.011962, 0.032257, -0.02184, -0.035471, 0.08339, 0.01327, -0.020849, -0.116236, 0.043086, -0.012557, 0.117393, -0.041392, 0.03717, 0.111871, 0.116869, -0.026854, 0.08722, -0.023304, 0.02727, -0.08686, -0.064444, 0.050246, 0.061167, -0.012048, -0.035544, -0.072628, 0.073969, 0.022324, 0.082828, -0.141322, -0.003657, 0.130847, 0.052954, -0.136204, 0.026114, 0.021774, -0.050078, -0.041525, 0.027284, -0.01949, -0.051163, -0.016111, -0.016403, 0.032763, 0.046284, 0.09511, 0.105603, 0.029676, -0.003059], [0.018417, 0.020853, 0.00499, -0.010509, -0.044504, -0.004449, -0.009934, -0.012105, 0.017139, 0.070883, -0.131216, -0.052046, -0.015155, 0.003118, 0.087469, 0.020064, -0.033323, -0.101818, -0.029107, 0.036905, 0.029987, -0.11967, 0.023597, 0.067582, -0.027229, 0.029075, 0.002964, 0.045875, -0.006499, 0.032766, -0.078738, -0.086768, -0.077123, -0.003917, 0.149028, 0.043526, -0.080742, -0.094964, -0.006728, -0.037489, 0.042737, -0.105571, 0.043151, -0.052785, 0.018933, -0.088846, -0.019712, -0.056002, -0.064665, -0.084953, 0.1891, 0.049885, 0.036737, -0.062623, -0.059845, -0.039779, 0.007054, 0.042927, 0.190141, -0.158058, 0.086636, 0.119298, -0.034502, -0.052323, -0.053717, -0.026804, -0.03077, 0.036951, -0.022653, 0.045903, -0.012671, -0.038079, 0.046944, 0.092435, -0.063165, -0.112199, 0.034875, 0.040084, -0.086829], [0.008339, -0.040402, 0.02678, -0.032948, -0.091765, -0.004717, 0.007167, -0.119139, 0.025564, -0.065537, 0.074302, -0.038416, 0.057644, 0.003505, -0.08167, -0.01682, -0.019257, 0.050402, 0.057934, 0.001836, -0.004235, 0.084718, 0.087798, 0.019415, -0.128167, -0.019047, -0.0371, 0.111733, -0.129786, -0.089693, -0.031809, -0.036021, 0.025659, 0.010735, -0.123253, -0.038374, -0.109604, 0.021389, 0.085004, -0.007261, -0.001544, 0.016738, 0.013132, -0.065941, -0.036169, 0.057396, 0.11182, -0.008869, 0.039516, -0.089202, -0.018166, 0.107583, -0.03228, -0.02313, 0.038625, 0.00719, 0.087506, 0.015631, 0.124746, -0.111933, -0.088666, 0.214653, 0.069363, -0.276068, -0.156097, -0.016023, 0.002292, -0.054697, -0.04186, 0.019308, 0.011284, 0.013134, 0.143966, -0.087774, 0.10391, -0.064017, 0.109097, 0.092364, 0.056036], [0.089883, -0.000686, -0.030646, -0.068222, 0.089435, 0.09797, -0.040061, -0.241535, 0.045621, 0.087928, -0.107773, -0.00725, 0.049904, 0.062693, 0.014824, -0.083035, -0.013861, -0.002539, 0.052419, 0.017383, 0.032385, -0.017079, 0.005678, 0.059633, -0.075207, 0.018213, 0.051054, -0.037712, 0.061969, -0.067409, 0.091192, 0.09922, -0.118307, 0.078229, -0.04553, -0.051191, 0.012053, 0.011847, 0.15194, 0.058336, -0.017661, -0.011028, -0.005635, 0.103227, -0.132199, 0.049605, 0.003177, 0.054002, 0.067723, 0.111299, -0.154846, -0.044847, 0.076587, 0.14595, -0.056345, -0.030725, -0.014197, -0.073784, -0.158147, 0.071339, 0.054161, 0.038045, -0.038258, 0.022572, 0.025918, 0.023298, -0.038236, -0.0177, 0.024955, -0.006301, 0.011139, 0.094638, -0.184632, -0.015745, 0.046374, 0.032314, -0.09295, -0.027139, -0.082853], [-0.067918, 0.142352, 0.07794, -0.035837, -0.025092, -0.036929, -0.020947, 0.022695, 0.057466, -0.100031, -0.086135, 0.039995, -0.053393, -0.064715, -0.001761, -0.024229, 0.025183, -0.023039, -0.024704, -0.114397, 0.083477, 0.115505, 0.083495, -0.008792, -0.099408, -0.035752, 0.116332, -0.048853, -0.042043, -0.071023, -0.102884, 0.011883, 0.114493, 0.000622, -0.040121, -0.022197, -0.025346, 0.088196, 0.099114, 0.028551, 0.121133, -0.096218, -0.053922, -0.141345, -0.035826, -0.015853, 0.064348, -0.084187, 0.072315, -0.028952, 0.053869, -0.17383, -0.052422, -0.168779, -0.043454, -0.066308, 0.151504, -0.083967, -0.018043, -0.275313, -0.039635, 0.088251, -0.027212, -0.048864, 0.040822, -0.083064, -0.013032, 0.065347, 0.01611, 0.038655, 0.009677, 0.041368, 0.011246, -0.061658, 0.053294, -0.024736, 0.021193, -0.1183, 0.040314], [0.019881, 0.136158, 0.056238, -0.018343, 0.126088, -0.075724, -0.038253, -0.030045, 0.01055, 0.090927, 0.000989, -0.012183, -0.01789, -0.072086, 0.105373, 0.079334, 0.036839, -0.097128, -0.028575, 0.027842, -0.09308, -0.03819, -0.138644, -0.01489, 0.087751, 0.001896, 0.015314, -0.035383, 0.014937, 0.045694, 0.019432, -0.041981, 0.01613, -0.043391, 0.069252, -0.047315, 0.077817, 0.076526, 0.102598, -0.039527, 0.06849, -0.122978, -0.021739, 0.006802, 0.038803, 0.032826, 0.071605, -0.037844, -0.067645, -0.036569, 0.047293, 0.253146, 0.081843, -0.073548, 0.092421, -0.053415, 0.05481, 0.080303, 0.068766, -0.162628, -0.333389, 0.040629, -0.005921, 0.004794, -0.008399, -0.042316, 0.108545, -0.018187, -0.005267, 0.005441, -0.038033, 0.009112, 0.061735, 0.014079, 0.048117, 0.062432, 0.013141, -0.024688, -0.010695], [0.010857, -0.085367, -0.015705, -0.066812, -0.019196, 0.078559, 0.010598, -0.016507, 0.009274, -0.015019, -0.078794, -0.008282, 0.05533, -0.006255, 0.032851, 0.058533, 0.045734, -0.043895, -0.076629, 0.054734, 0.113574, -0.036411, 0.007301, -0.106996, 0.015878, 0.070859, -0.008478, 0.076645, 0.037266, 0.046551, -0.040153, -0.018235, 0.05098, -0.086988, -0.062663, 0.065935, -0.051112, -0.124722, -0.11575, 0.061228, 0.085455, -0.097767, 0.033996, -0.061867, 0.115553, -0.046806, -0.015564, -0.015384, 0.06275, -0.074023, 0.055144, 0.028413, 0.127574, -0.044868, -0.003711, 0.053882, 0.104495, 0.120263, 0.06813, -0.028313, -0.107651, 0.11246, 0.051689, -0.029653, 0.024382, 0.020153, -0.051926, 0.027456, -0.046167, 0.045183, 0.003969, -0.048948, 0.055995, 0.013974, -0.088407, -0.039699, -0.002145, -0.027575, -0.021558], [0.046737, -0.001387, -0.16651, 0.016778, -0.036728, 0.053606, 0.040478, -0.010535, 0.041987, 0.019998, 0.047975, -0.099693, -0.019139, 0.164268, 0.135069, -0.009787, -0.078632, -0.051919, 0.017667, -0.033482, -0.087624, 0.035727, -0.037956, 0.032957, 0.04562, 0.047274, -0.058088, -0.068111, -0.086116, -0.017772, 0.070236, -0.003577, 0.009802, 0.079527, 0.019297, 0.051182, 0.001165, -0.11061, 0.058075, -0.051127, -0.004072, 0.111867, 0.060815, 0.108478, 0.032254, 0.028202, -0.030271, 0.101741, -0.006779, 0.143158, -0.03629, -0.048519, -0.012861, 0.051252, -0.123669, 0.069357, -0.006454, -0.082221, 0.00471, 0.113089, 0.133194, -0.017403, -0.046401, 0.077657, -0.082231, 0.047594, 0.055581, -0.006021, -0.016775, 0.040275, -0.063153, -0.083466, -0.120574, -0.046716, -0.082702, 0.06729, -0.118043, 0.027734, 0.052364], [-0.022844, -0.011403, -0.071741, 0.110803, 0.023573, -0.027385, 0.02061, 0.081771, 0.009186, 0.053085, -0.090298, -0.00051, -0.026821, 0.057446, -0.005076, -0.076554, -0.043871, 0.083481, 0.099313, -0.058831, 0.008216, 0.12126, 0.042976, -0.088674, -0.098712, 0.037152, 0.041006, 0.056038, 0.200342, 0.024237, 0.028111, -0.015748, -0.050561, -0.087246, -0.007928, 0.110232, -0.07128, -0.018701, -0.004223, 0.091709, -0.108593, -0.0568, 0.116343, 0.153282, -0.001567, 0.144571, -0.019239, -0.026979, -0.03596, 0.006753, 0.010551, 0.125374, 0.050972, -0.044335, 0.035738, -0.097681, 0.01455, -0.001617, 0.05905, 0.059732, 0.019497, 0.21044, 0.093974, -0.116411, 0.004916, -0.012239, -0.03112, 0.018087, -0.035111, 0.054385, -0.008952, -0.019076, -0.060957, 0.004378, -0.07367, -0.131265, 0.090168, 0.05028, 0.015556], [0.028038, -0.009658, 0.053769, -0.08073, 0.025161, 0.092179, 0.052269, 0.065687, -0.033596, -0.097946, -0.004578, 0.059368, 0.041533, -0.013094, -0.067751, 0.0542, -0.014128, 0.032292, 0.061278, -0.049184, -0.027791, 0.114215, -0.18115, 0.109823, 0.240268, -0.015482, 0.115547, 0.110327, -0.145566, -0.030383, 0.00685, -0.100659, 0.168264, -0.016733, -0.033907, -0.071244, -0.054287, 0.114072, 0.149105, 0.065888, 0.004724, -0.057138, -0.012848, -0.047614, -0.081765, -0.02976, -0.082579, -0.082213, 0.052513, 0.013182, 0.203396, 0.142756, 0.122449, 0.096383, -0.038591, -0.032112, 0.061425, 0.090156, 0.049114, -0.110352, -0.010249, -0.02365, 0.010551, -0.079831, -0.034373, -0.013737, 0.023222, -0.032223, -0.071023, 0.112438, -0.078514, -0.029294, 0.075503, -0.011871, -0.101685, 0.107945, -0.037421, 0.005772, 0.027289], [-0.012315, 0.069645, -0.011422, 0.096665, -0.120465, 0.07813, 0.006772, 0.039594, 0.060688, -0.019856, 0.000401, -0.026878, -0.077744, -0.055048, -0.074231, -0.081479, -0.031572, 0.04957, 0.079425, 0.001641, 0.101282, 0.121287, 0.084467, -0.024378, -0.001545, -0.095075, -0.01766, 0.014828, -0.151627, -0.00988, -0.032277, 0.129918, -0.051858, 0.076097, -0.066548, 0.006505, -0.006621, 0.079416, 0.03139, 0.070345, -0.136424, 0.076783, 0.05412, 0.104114, -0.178923, -0.02424, -0.006952, 0.055506, 0.123374, 0.057474, -0.01081, -0.022803, -0.101472, 0.093501, 0.064025, -0.031869, 0.006915, -0.022979, -0.019227, -0.071414, -0.156502, 0.041715, -0.033449, -0.206122, 0.005714, 0.001236, 0.00048, -0.009148, 0.001668, 0.009948, -0.09619, 0.09565, -0.123557, 0.049876, -0.030746, 0.057176, -0.044873, 0.091848, -0.07243]], 'w2': [[0.003319, 0.0178, 0.0127, 0.01573, -0.080434, -0.021024, -0.057124, 0.062908, -0.095107, 0.03413, -0.017901, 0.106464, -0.024076, 0.042448, 0.00365, 0.006196, 0.054342, -0.077496, 0.088779, 0.003582, 0.007968, 0.087692, 0.000118, -0.124204, -0.096307], [-0.011823, -0.017493, -0.013017, -0.028117, 0.10066, 0.025072, 0.05495, -0.064641, 0.080917, -0.032551, 0.002576, -0.102663, 0.0314, -0.030823, -0.003096, 0.015738, -0.05528, 0.06239, -0.084623, -0.009226, -0.009924, -0.097591, 0.007745, 0.126574, -0.052085]], 'hist_par': {'USDCHF-OTC': '11101100011011111011', 'SP500-OTC': '11110001010100010000', 'ONDOUSD-OTC': '00011001111110001011', 'EURGBP-OTC': '00001001001100101011', 'RENDERUSD-OTC': '00111110110101010011', 'SUIUSD-OTC': '10000101100000001100', 'HBARUSD-OTC': '10011100110011101111', 'RAYDIUMUSD-OTC': '01001011111100111001', 'GBPUSD-OTC': '10011001110100100010', 'PENGUUSD-OTC': '00011000111111100000', 'DYDXUSD-OTC': '11101000011011111010', 'EURUSD-OTC': '01001100001101101101', 'EURJPY-OTC': '01110011001000101001', 'FETUSD-OTC': '01111011011101000110', 'AMAZON-OTC': '01010110010011011100', 'Gold/BRL': '01111101101011001001', 'NZDCAD-OTC': '10111111111011010000', 'LINKUSD-OTC': '11010010010011000001', 'AUDJPY-OTC': '11110010111100000100', 'SANDUSD-OTC': '10010010010010100111', 'GBPCHF-OTC': '11111111000111000100', 'XNGUSD-OTC': '10100000010000110101', 'INJUSD-OTC': '00010111101001000000', 'NEARUSD-OTC': '11010100011001000010', 'FARTCOINUSD-OTC': '00001000000100000101', 'AUDCAD-OTC': '11101011001011001000', 'NZDUSD-OTC': '00100000011011011000', 'USOUSD-op': '11110010110011100111', 'DIA': '00000010000011001100', 'FR40-OTC': '01010111000111010010', 'EURCHF-OTC': '10010101100100001111', 'XAUUSD-OTC': '00100101101111101110', 'Crude Oil Brent/BRL': '11001101000011010000', 'IWM': '11001101001101010001', 'SQQQ': '11111111100011110001', 'XLK': '10111111111000110100', 'SMH': '00111001110111011001', 'EURTHB-op': '11111111111000101101', 'UKOUSD-OTC': '11010001110111000011', 'ATOMUSD-OTC': '11100111110111000110', 'MELANIAUSD-OTC': '11000110010001110100', 'JPM-OTC': '01000111011100101101', 'AIRLINES-OTC': '01010110110110010110', 'WIFUSD-OTC': '00111101001000101011', 'USDJPY-OTC': '00111011001011010010', 'IMXUSD-OTC': '00110111000100011101', 'FWONA-OTC': '01010001001111111100', 'DASHUSD-OTC': '00111110001111010110', 'GDX': '11010101110010110101', 'PEPEUSD-OTC': '01011000101100100100', 'SPY': '00100011010111111000', 'WLDUSD-OTC': '00001101001111110111', 'USDTHB-OTC': '00001011001101000011', 'JP225-OTC': '01001100010101011110', 'USNDAQ100:N': '01011101110110101110', 'USSPX500:N': '11010011000100111100', 'ARBUSD-OTC': '01000001010100001100', 'PENUSD-OTC': '00101111010111110011', 'AUS200-OTC': '11101010100101001110', 'GBPCAD-OTC': '10111010000101110110', 'EURTHB-OTC': '01000101110011101101', 'CHFNOK-OTC': '00110000100100110111', 'MCDON-OTC': '01110100101110001010', 'US30:N': '00011101110110010100', 'JPYTHB-OTC': '00110110100010101101', 'GRTUSD-OTC': '01001000010000101101', 'AUDCHF-OTC': '10010110001010111000', 'SOLUSD-OTC': '10011110000111010100', 'USOUSD-OTC': '00001110100100100001', 'COKE-OTC': '01011001111001110000', 'OpenAI-OTC': '11101110010011000010', 'SHIBUSD-OTC': '11101000000101001011', 'MAGNIFICENT7-OTC': '11100110010011100000', 'USNDAQ100-OTC': '11001100101000110010', 'USDDOP-OTC': '10000001111011100000', 'EURAUD-OTC': '11010110100100010000', 'JAPAN225:N': '10100010001101010100', 'GERMANY30:N': '01100011110011110001', 'FRANCE40:N': '00010101110101011001', 'XRPUSD-OTC': '01111101111000100010', 'JUPUSD-OTC': '10110100111010101000', 'GBPJPY-OTC': '10101000100111001100', 'USDSEK-OTC': '10111101000110111010', 'USDBRL-OTC': '00111001010110010010', 'APPLE-OTC': '00100100010001001010', 'US2000-OTC': '11111100110101010100', 'CADJPY-OTC': '01110011001011000110', 'EOSUSD-OTC': '11100010101000001001', 'AI Power & Datacenter': '11111000111101101010', 'FB-OTC': '00010100001111111111', 'US30-OTC': '01110001111100001001', 'Bitcoin/Gold-op': '00000111101101100110', 'US AI Semiconductors': '01011100010011011100', 'AUDNZD-OTC': '01100111110011011110', 'PLTR-OTC': '10000000101111001110', 'AUS200:N': '10111000011000001100', 'XAGUSD-OTC': '01000001010000101101', 'CADCHF-OTC': '00000011011001100101', 'USDCAD-OTC': '11111110001011100101', 'SNAP-OTC': '01011100100000001100', 'BTCUSD-OTC-op': '01001111010110110110', 'IOTAUSD-OTC': '11011011011111010110', 'MATICUSD-OTC': '10111110101010000100', 'USDPLN-OTC': '01010001100110011110', 'USDSGD-OTC': '11101010101100000101', 'CHFJPY-OTC': '00100100111010011111', 'NZDJPY-OTC': '00111101001111001100', 'USDZAR-OTC': '01100100110111100101', 'KLARNA-OTC': '11111100110101010111', 'HK33-OTC': '00000010100111001000', 'US2000:N': '11110010010000100001', 'HONGKONG33:N': '00010110000110101010', 'USDNOK-OTC': '11100110101001001111', 'Anthropic-OTC': '00011100110111111001', 'UK100-OTC': '10011001001110100011', 'USDCOP-OTC': '10111000001001110001', 'CASINOS-OTC': '00111000100100100011', 'EURCAD-OTC': '01011100111101100000', 'EU50-OTC': '10110101001111110000', 'SATSUSD-OTC': '11010000111001000011', 'URANIUM-OTC': '00100000101000001101', 'BONKUSD-OTC': '10001111110100111101', 'CANNABIS-OTC': '01011100101010011100', 'MSFT-OTC': '00010001001111101010', 'MORSTAN-OTC': '10100001100011111000', 'ETHUSD-OTC': '00111000011011110011', 'AUDUSD-OTC': '11010100000010001001', 'USDARS-OTC': '10100101010101101011', 'TRON-OTC': '00010000010001000111', 'GER30-OTC': '01011001111110100000', 'GBPNZD-OTC': '10011000011111011000', 'GOOGLE-OTC': '11101101000011100111', 'TIAUSD-OTC': '11101000110011001100', 'UK100:N': '10100010100000101110', 'Magnificent7-op': '11001100001100111001', 'GS-OTC': '11100100111111011110', 'GBPAUD-OTC': '00010101100000111001', 'TESLA-OTC': '01110111110100000100', 'LABUBUUSD-OTC': '00000001110011011000', 'USDTRY-OTC': '11011110010001010001', 'DOTUSD-OTC': '00010011011011100010', 'ALIBABA-OTC': '01000000101111000010', 'TRUMPUSD-OTC': '11110011001001001101', 'PYTHUSD-OTC': '01100100010000100111', 'EURNZD-OTC': '00010100011101100100', 'LTCUSD-OTC': '10001000010101100001', 'GER30/UK100-OTC': '11000010001100010101', 'COTTON-OTC': '00011100010110011110', 'US30/JP225-OTC': '00011100100110110011', 'EURJPY-op': '11101101101110100000', 'TESLA/FORD-OTC': '01100011000111110011', 'NVDA/AMD-OTC': '10011000010101100011', 'XAU/XAG-OTC': '00111010110100110011', 'GOOGLE/MSFT-OTC': '01111110000001000001', 'META/GOOGLE-OTC': '00111011111011011110', 'LUNA-OTC': '01011000000011111110', 'USDAED-OTC': '00001001100010011100', 'US100/JP225-OTC': '10000100011001000000', 'MSFT/AAPL-OTC': '10001110101001101101', 'AMZN/EBAY-OTC': '11000010011111011100', 'NVDA-OTC': '11110001100001011111', 'EURUSD-op': '10011000010000000111', 'EURGBP-op': '11010110010000100001', 'USDTHB-op': '10001111111000100111', 'USDMYR-OTC': '00011010101000111111', 'AMZN/ALIBABA-OTC': '00111011010111100011', 'USDVND-OTC': '11110101011101100101', 'COCOA-OTC': '10101000011101100100', 'USDBOB-OTC': '10100101001111001110', 'ICPUSD-OTC': '11000110111100100100', 'USDIDR-OTC': '00011011010100100001', 'XPDUSD-OTC': '11110110001010101000', 'USDHKD-OTC': '11011111101100001010', 'WDC-OTC': '10000010111011011010', 'COFFEE-OTC': '11111010010011011010', 'USDPHP-OTC': '11010111001110001111', 'USDJPY-op': '00011100110110101111', 'XPTUSD-OTC': '10010100101001100110', 'SUGAR-OTC': '11001111000101010110', 'GBPJPY-op': '10000000010101111110', 'USDNGN-OTC': '10011110011001100111', 'INTEL/IBM-OTC': '00001101000010001000', 'SEIUSD-OTC': '01101001010011110111', 'USDSAR-OTC': '10110110110100000011', 'RONINUSD-OTC': '11100001110110010000', 'HYPE-OTC': '00010000101111011000', 'NIKE-OTC': '00101101011001000100', 'MU-OTC': '10110110101010010110', 'GEV-OTC': '11110000110111000110', 'USDBDT-OTC': '10001001111011101011', 'NFLX/AMZN-OTC': '11111011110001000110', 'GBPUSD-op': '10000100011100001111', 'USDCLP-OTC': '10110000111010000110', 'XAUUSD-op': '01100001111110110101', 'SpaceX-OTC': '01000000111001000001', 'SpaceX-op': '10000111011011101111', 'ASMLa': '101100', 'NZDCAD-op': '00011', 'European AI': '011000', 'Luxury': '010011101', 'AUDCAD-op': '000010', 'AUDUSD-op': '011101101', 'GBPCAD-op': '0001101101111', 'BTCUSD-op': '01010001100', 'GBPAUD-op': '111110101010', 'AUDNZD-op': '0110', 'GBPNZD-op': '11101110011', 'AUDCHF-op': '0101110000010', 'AUDJPY-op': '11100', 'EURNZD-op': '111110000'}, 'hist_ctx': {'otc20': '11100111011101011111101000011110010011111100011111', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '01001111000100001010100011100001000100100000101111', 'otc1': '11001110011011001101111111000101101111100101011111', 'otc2': '00101110110101000010001011011111110000011100100011', 'otc3': '10000000010111111100111100000101000001001110011110', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '10000110100111100110100000111000101011100001001010', 'otc13': '11100000111010110011100011101001111000010100000110', 'otc14': '10111110010001010011001010011110101101100101111100', 'otc15': '00001101110011111100001001111001111011001000011100', 'otc16': '11110010100110101000000000101001101001011011011111', 'otc18': '00100111011101010010001101111100010101000100000000', 'otc19': '11011111011100101010011101000000111101000000111000', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '00111101000101110100001010011000011010101001000101', 'real17': '01110001000100000000010000000010101101011111111111', 'real12': '01000100000110011001010001010110111110001010000110', 'real13': '11011110111101110111111110110010011101011100000000', 'real14': '11101100000110011111111011101111100101011110110111', 'real15': '00100001101001110000000110001011010111111111111111', 'real16': '10011001111101111111111111100100001010011111111100', 'real18': '01101001101011011001100100010100111111101111110111', 'real19': '00001111010010001000101001100000001000101001100010', 'real20': '11100011001110010000110111111111111000000010100001', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '00111100101110101101110000101100000110111100100100', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5844032, 'preentreno': True, 'sombra': '011110100000001001000101100011011011111001001010011000000001010010101000111011010100010001100101110111001111000000100101000001100101111101111101100101011111110011000011110111111110110101010100001000101110011001011101000011000000011011110101010101111111100001111100001011101100010110010001111111111101011100000110001010100001010001111110110000111100110111011100011011101000000001000111000001011101111010101000111001100001100101101000101001011011001000100010100', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960, 1793413740, 1793413860, 1793413920, 1793413980, 1793414040, 1793414220, 1793413800, 1793414280, 1793414340, 1793414160, 1793414460, 1793414520, 1793414580, 1793414100, 1793414760, 1793414820, 1793414700, 1793414940, 1793414640, 1793415000, 1793414400, 1793415180, 1793415120, 1793415060, 1793415480, 1793415540, 1793415600, 1793415240, 1793449860, 1793449920, 1793449980, 1793450040, 1793450100, 1793450160, 1793450220, 1793450280, 1793450340, 1793450400, 1793450460, 1793459520, 1793459580, 1793459640, 1793459700, 1793459760, 1793459820, 1793459880, 1793459940, 1793460000, 1793460060, 1793460120, 1793460180, 1793460240, 1793460300, 1793460360, 1793460780, 1793460840, 1793460900, 1793460960, 1793461020, 1793461080, 1793461140, 1793461200, 1793461260, 1793461320, 1793461380, 1793461440, 1793461500, 1793461560, 1793461620, 1793461680, 1793461740, 1793461800, 1793560080, 1793560140, 1793560200, 1793560260, 1793560380, 1793560440, 1793560500, 1793560560, 1793560620, 1793560680, 1793560740, 1793560800, 1793560860, 1793560920, 1793560980, 1793561040, 1793561100, 1793561160, 1793561220, 1793561280, 1793561340, 1793561400, 1793562360, 1793562480, 1793562600, 1793562720, 1793562840, 1793562960, 1793563080, 1793563200, 1793563320, 1793563440, 1793563560, 1793563680, 1793563800, 1793563920, 1793625840, 1793626080, 1793626200, 1793626320, 1793626440, 1793626560, 1793626680, 1793626800, 1793626920, 1793627040, 1793627280, 1793627400, 1793627760, 1793627880, 1793628000, 1793628120, 1793629680, 1793629800, 1793629920, 1793630040, 1793630160, 1793630280, 1793630400, 1793630520, 1793630640, 1793630760, 1793630880, 1793631000, 1793631120, 1793631240, 1793631360, 1793638080, 1793638200, 1793638320, 1793638800, 1793638920, 1793639040, 1793639160, 1793639280, 1793639400, 1793639520, 1793639640, 1793639760, 1793639880, 1793640240, 1793640360, 1793640480, 1793640600, 1793640720], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1460, 'activa': False, 'ev_prom': -0.04209332479521771, 'ultima_senal': 1793719938.6423228, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1793837298}, 'exnova': {'v': 2, 'w1': [[-0.012311, -0.000708, -0.00693, -0.002331, 0.013264, -0.032544, 0.072246, 0.017959, -0.047973, 0.049376, 0.083672, -0.024602, -0.016394, -0.076516, 0.067611, 0.068188, 0.142888, -0.005492, 0.035734, -0.013155, -0.042813, 0.022279, 0.028585, 0.015213, -0.076202, 0.003679, -0.085355, 0.096318, -0.116796, 0.040492, 0.035204, -0.024196, 0.046461, 0.072216, 0.029747, 0.040996, -0.059731, -0.024619, -0.006859, -0.03896, -0.066988, 0.044068, 0.016863, 0.177089, 0.048795, -0.028466, -0.086098, 0.075037, -0.018314, -0.048196, 0.007936, 0.036135, 0.074246, -0.005426, -0.092488, 0.128885, -0.161088, -0.03158, -0.047526, 0.021305, 0.128602, -0.117077, -0.143663, 0.192228, 0.037245, 0.024405, 0.039482, -0.016373, -0.007913, -0.008559, -0.011258, -0.017302, 0.0445, 0.110955, 0.053294, -0.048, 0.031332, -0.011546, -0.007367], [0.036691, 0.020477, -0.052555, 0.015533, -0.023483, -0.087887, -0.047871, -0.045686, 0.108663, -0.085194, -0.055589, 0.033897, -0.09651, 0.07818, -0.016589, -0.043836, 0.06319, 0.014497, -0.031206, 0.066716, -0.087849, 0.004062, -0.077672, 0.006072, 0.099507, 0.004242, -0.040826, -0.117421, -0.046667, -0.066715, -0.010285, 0.07284, 0.011072, 0.051202, 0.123201, 0.078932, -1.2e-05, 0.072251, 0.086298, 0.007386, 0.062864, -0.090423, 0.040623, 0.046869, -0.148941, -0.100011, -0.031449, -0.015511, -0.008339, 0.073382, -0.036404, -0.141282, -0.060792, 0.125782, -0.181683, -0.141508, -0.010889, -0.094202, -0.086091, -0.068378, 0.121508, -0.02853, -0.094512, 0.078536, 0.076648, -0.045429, -0.00309, 0.012424, 0.002813, 0.007526, 0.031941, 0.095752, -0.008802, -0.107312, 0.102211, -0.006673, -0.045176, -0.056056, -0.057031], [0.037939, 0.027519, 0.143858, 0.144276, -0.011066, 0.050401, -0.037943, -0.085955, 0.0326, -0.084001, 0.036105, 0.039824, 0.043397, -0.022358, -0.016746, -0.006441, 0.005026, 0.121007, 0.004435, -0.000104, -0.140023, -0.019969, -0.141903, 0.00981, 0.117418, 0.102147, 0.090377, -0.003422, 0.088077, -0.050632, 0.042862, -0.135244, 0.017824, -0.039953, -0.001006, -0.035502, -0.026632, 0.078664, 0.004539, -0.044764, 0.089671, -0.173022, -0.137081, 0.058154, -0.019087, -0.003405, 0.069771, -0.000896, -0.037202, 0.051417, -0.031321, -0.18048, -0.088538, 0.149295, -0.093961, -0.017788, 0.033888, -0.059238, -0.170534, -0.093289, 0.056812, -0.201508, -0.067298, 0.105849, 0.085005, 0.007983, 0.036743, -0.01109, -0.011303, -0.050045, 0.17036, 0.016178, 0.02019, 0.097573, -0.049093, 0.054097, -0.038629, -0.013684, -0.011864], [0.044485, 0.074488, -0.010391, 0.059785, -0.031543, 0.055268, 0.022767, -0.122299, 0.001502, 0.000848, 0.107657, 0.01173, 0.068265, -0.157602, 0.072694, -0.069807, -0.067861, -0.008332, 0.030452, -0.143901, -0.008425, -0.040133, -0.011798, 0.07667, 0.038953, 0.026409, 0.053156, 0.064698, -0.070132, -0.122649, 0.069528, 0.032143, 0.021565, 0.142625, -0.054873, -0.032253, -0.061441, 0.077446, -0.024555, -0.076697, -0.006598, -0.058022, 0.012394, 0.084884, -0.077275, 0.120365, 0.018411, 0.029426, 0.033466, 0.006479, 0.026876, -0.084102, 0.147368, 0.095285, -0.170623, -0.003646, -0.018744, -0.054145, -0.26343, 0.21158, 0.126942, -0.1341, -0.158507, 0.108563, 0.009878, 0.02112, 0.026974, -0.004335, -0.015781, -0.010201, 0.05584, 0.12628, -0.13245, 0.11023, 0.030043, -0.108175, -0.048824, -0.012191, -0.048076], [-0.089236, -0.118579, -0.001148, -0.034871, 0.020045, -0.013678, 0.056374, 0.102691, -0.122996, -0.018464, -0.011726, 0.014417, 0.037969, 0.059161, -0.060568, -0.06318, 0.025347, 0.040863, -0.054461, 0.006034, -0.013982, -0.010338, 0.130677, 0.060018, 0.050637, 0.185716, -0.051838, 0.036944, -0.128531, -0.028959, -0.016179, -0.042157, -0.100425, -0.038222, -0.136293, 0.101656, 0.133187, 0.091909, -0.179434, 0.092578, -0.153524, 0.086795, -0.054531, 0.031371, -0.027692, -0.01724, -0.009754, -0.066983, 0.047033, 0.038251, -0.064436, -0.046711, 0.021283, -0.041748, -0.070704, -0.057134, 0.044238, -0.06574, -0.086979, 0.039894, 0.031302, -0.044504, 0.152832, -0.042477, 0.038084, -0.051716, -0.005902, 0.031517, 0.026732, -0.016043, 0.009878, 0.068715, 0.053805, 0.001504, -0.001682, 0.136084, 0.033319, -0.005921, 0.002521], [0.059041, 0.097318, 0.157004, 0.027248, -0.06643, 0.127283, 0.044222, -0.058248, -0.024152, -0.057678, 0.093385, 0.063334, 0.041935, -0.099501, 0.185509, -0.125977, 0.054847, 0.059886, 0.087356, -0.024424, 0.156696, 0.087613, -0.005082, -0.143168, 0.012622, 0.025698, 0.058779, 0.014674, 0.064334, -0.050651, 0.094655, 0.10011, 0.026145, 0.034113, -0.051602, -0.012384, -0.045436, -0.069777, -0.026665, 0.004352, 0.019986, -0.094119, 0.121583, -0.07666, -0.003014, -0.004425, 0.054324, -0.095413, -0.026771, -0.014053, 0.081865, 0.109753, 0.189007, -0.140389, 0.04596, -0.033513, 0.090367, -0.071073, 0.029368, -0.21209, -0.107453, -0.007255, -0.184127, 0.036758, 0.029938, -0.007144, 0.009916, -0.019392, -0.009224, -0.022098, -0.163436, 0.086595, -0.076559, -0.088901, 0.045116, 0.011453, 0.002783, 0.040246, 0.006397], [-0.021677, -0.209748, 0.09649, 0.069444, -0.004154, 0.082093, 0.058699, 0.066453, -0.043876, 0.128566, 0.0253, 0.095821, 0.035202, 0.008305, -0.009665, -0.007296, 0.011807, -0.09021, 0.027134, 0.146996, 0.042487, -0.084081, 0.010722, 0.136392, 0.036147, 0.098179, -0.026904, -0.01976, 0.103233, 0.040527, 0.085482, -0.061238, -0.10546, 0.00872, 0.023596, -0.082195, 0.046759, 0.001017, 0.005675, -0.030053, -0.076696, 0.069192, -0.109264, 0.031519, -0.068695, 0.094899, 0.010517, 0.059985, -0.018788, -0.057593, -0.029529, -0.143506, -0.046471, 0.056908, -0.142061, 0.096915, -0.128519, -0.102719, 0.059179, 0.004033, 0.374892, -0.162471, 0.067226, 0.040511, -0.042232, 0.026985, -0.015963, 0.001284, -0.003918, 0.021738, 0.020989, -0.016469, -0.124392, 0.076558, -0.098125, 0.055464, 0.011198, 0.011848, 0.125161], [0.019443, 0.06587, -0.138898, -0.074257, 0.054223, -0.045135, -0.018199, 0.043297, -0.012258, -0.066006, -0.09035, 0.030677, 0.032511, 0.002246, 0.0643, 0.035171, 0.003013, -0.013609, -0.037666, -0.045589, 0.013237, -0.13251, 0.017379, -0.11535, 0.047421, 0.011108, -0.066541, -0.06134, 0.021117, -0.006766, 0.036066, 0.203338, 0.055683, -0.051911, -0.055976, -0.145298, 0.045299, 0.015458, 0.038383, 0.093131, 0.109883, -0.049432, -0.018524, -0.013754, -0.038143, -0.067574, 0.02262, -0.081289, -0.04134, 0.018264, 0.01138, 0.075856, 0.216764, 0.070381, -0.127026, -0.173453, 0.073976, 0.088183, -0.03629, 0.037613, -0.256061, 0.147513, 0.036919, 0.044162, 0.019191, -0.0011, 0.021153, 0.03516, 0.004416, 0.007949, -0.04299, 0.030398, -0.081567, 0.105237, -0.134822, -0.013564, -0.066591, -0.01136, -0.033116], [0.002456, -0.171104, -0.027013, -0.177397, 0.056252, 0.014292, 0.037675, -0.104563, -0.12698, -0.070303, 0.103826, -0.043258, 0.0362, 0.065403, -0.079972, -0.052989, 0.022038, 0.040898, 0.073272, -0.064029, -0.011256, 0.072214, 0.08972, -0.002537, 0.116981, -0.031034, -0.118063, 0.053885, -0.013549, 0.078835, -0.097791, 0.048358, 0.110572, 0.039104, -0.008493, 0.004665, -0.038441, -0.081524, -0.029978, -0.083756, -0.028239, -0.164977, -0.016509, 0.092821, 0.017249, -0.111882, 0.040667, -0.088615, -0.015416, -0.068725, 0.218628, 0.070815, 0.136064, -0.008054, 0.02796, -0.034468, 0.088273, -0.044704, 0.017814, -0.12835, -0.187344, -0.004233, 0.049385, -0.078562, 0.033215, 0.011076, -0.036619, -0.025449, -0.016271, -0.041706, -0.045225, 0.112734, 0.032465, 0.053808, 0.033073, -0.039181, 0.083175, 0.054355, 0.097998], [0.082783, 0.162383, -0.152973, 0.006233, 0.051126, -0.000934, -0.036661, 0.09489, -0.009554, -0.105453, -0.004766, 0.101835, -0.032311, 0.07297, 0.095355, 0.092212, -0.086829, -0.11349, -0.032859, 0.076984, 0.015458, 0.001518, 0.065127, -0.031921, -0.06775, -0.075891, 0.067085, 0.022356, -0.075067, 0.096827, 0.028975, 0.14456, -0.015997, -0.048473, -0.052017, -0.036581, -0.171579, 0.044146, -0.016778, 0.037412, 0.049513, 0.066234, 0.100215, 0.056862, 0.128298, 0.02113, -0.020719, 0.100435, -0.018013, -0.063739, -0.13915, -0.030712, 0.032866, -0.007342, -0.071483, 0.088736, -0.108227, 0.055449, -0.183601, 0.205482, 0.039808, 0.040552, 0.007522, 0.167632, -0.031218, 0.009658, 0.063401, -0.014085, -0.034788, 0.004494, -0.101949, -0.07528, -0.195137, 0.093711, 0.026943, 0.056702, -0.137298, -0.001409, -0.071565], [-0.002164, 0.063838, 0.005477, 0.061515, -0.067469, 0.041887, -0.003636, -0.003683, 0.004138, -0.121907, 0.084496, 0.022691, 0.026435, 0.00742, -0.006079, -0.057989, 0.085804, 0.021923, -0.035533, 0.036588, 0.017749, 0.006831, 0.05801, -0.010449, -0.088175, 0.117258, 0.051807, -0.027323, -0.01624, -0.047856, 0.089127, 0.032619, 0.061036, 0.019984, -0.010216, -0.01545, -0.01964, -0.133382, -0.075484, 0.041001, -0.102983, -0.05117, 0.014138, 0.042569, 0.066099, 0.028435, 0.041803, -0.037861, 0.02554, 0.050233, -0.142098, -0.126827, -0.076351, 0.002552, -0.141862, 0.053229, -0.075315, -0.188319, 0.070195, -0.057182, 0.295352, -0.115213, 0.031345, 0.140985, 0.04206, 0.015183, 0.016939, -0.00949, 0.028847, -0.026588, -0.031848, -0.077473, 0.003097, -0.028749, 0.060832, -0.018262, 0.067575, 0.03754, 0.090654], [-0.069022, 0.015901, -0.090141, 0.013453, -0.010869, 0.048469, 0.001601, 0.044905, -0.026899, -0.04662, -0.091234, 0.007833, 0.048823, -0.031925, -0.080515, 0.078234, -0.089928, 0.142669, -0.059604, -0.029502, -0.081683, -0.011069, 0.187355, -0.054454, -0.01415, 0.007181, 0.225832, -0.081977, 0.069645, -0.085651, -0.023821, 0.033218, -0.028313, 0.105283, 0.066923, 0.137218, -0.074532, -0.157229, -0.065147, 0.006309, -0.176153, 0.082982, 0.039848, 0.013994, 0.092147, 0.237828, -0.080301, 0.152204, 0.114573, 0.083043, -0.153326, -0.140624, -0.080159, 0.114522, -0.260246, 0.033556, -0.067513, -0.164735, -0.070417, 0.062409, 0.470658, -0.138794, 0.060158, 0.213082, 0.018975, -0.007473, -0.047625, 0.032198, 0.041183, -0.015987, 0.037902, -0.116609, -0.099648, 0.090957, -0.017868, 0.039575, 0.029717, -0.044824, 0.087027], [-0.071426, 0.066575, -0.069602, 0.003037, -0.033224, 0.004327, 0.035256, -0.023507, 0.114166, 0.155653, 0.05991, -0.137073, 0.090371, -0.11989, 0.079006, 0.058719, 0.052773, 0.066176, 0.048057, -0.021257, 0.168966, 0.12348, 0.014676, -0.038906, -0.119519, 0.01533, 0.158376, 0.061664, 0.106003, 0.094287, -0.013226, 0.022322, -0.028564, 0.108111, -0.059913, -0.118401, 0.208943, -0.130612, 0.019483, 0.036499, 0.038409, 0.035222, -0.0233, 0.039838, 0.116995, -0.01435, -0.001684, -0.034286, 0.032541, 0.005861, 0.027302, 0.039398, 0.03053, -0.23393, 0.124261, 0.058944, 0.017255, 0.035927, -0.119988, 0.103385, -0.241625, 0.062356, 0.020341, 0.006977, 0.045246, 0.031037, -0.040473, 0.01862, 0.067172, -0.013534, -0.028838, 0.060734, -0.155598, -0.080202, -0.039396, 0.072314, -0.085992, -0.110898, -0.033482], [0.04814, -0.014365, 0.018065, -0.119699, 0.052337, 0.007489, -0.028028, -0.072343, 0.040781, -0.035233, -0.090774, -0.01186, -0.059411, 0.028353, -0.071085, -0.0863, -0.048217, -0.042537, 0.029143, 0.05876, -0.070527, -0.051087, 0.010649, 0.002836, -0.054596, -0.047995, 0.093448, -0.018545, 0.067983, 0.056824, 0.033295, 0.04979, -0.015833, -0.003061, 0.098807, 0.001529, -0.130289, -0.109579, 0.046035, -0.061097, 0.128512, -0.083182, 0.033271, 0.107782, 0.107881, 0.052606, 0.100822, -0.028868, 0.033823, -0.11051, -0.070979, -0.000471, 0.062884, 0.012381, -0.009178, -0.040386, 0.06525, 0.071237, 0.092303, -0.125531, 0.011428, 0.120743, 0.016034, -0.138938, 0.023091, 0.017784, -0.06423, -0.034934, 0.020187, -0.01949, -0.08507, -0.003458, -0.089749, 0.032763, 0.050245, 0.077798, 0.099057, 0.056128, -0.033544], [-0.016324, 0.01052, -0.04294, -0.048868, -0.009633, 0.001769, 0.059842, -0.005345, 0.007059, 0.169654, -0.100489, -0.072659, 0.018072, 0.024653, 0.069617, 0.027311, -0.039408, -0.075322, -0.047815, -0.007047, 0.097608, 0.009246, 0.073628, 0.088024, 0.060406, 0.045059, -0.022383, -0.011794, 0.018913, -0.041653, -0.115195, -0.062879, -0.049553, 0.044911, 0.148193, 0.060872, -0.002277, -0.079887, 0.015219, -0.097039, 0.061769, -0.120361, 0.092889, -0.047819, 0.009766, -0.055256, -0.032885, -0.066467, -0.025186, -0.060834, 0.213828, 0.094424, 0.062852, -0.06098, -0.091464, -0.021051, -0.013735, -0.040726, 0.205111, -0.151751, 0.048878, 0.154268, 0.021643, 0.008188, -0.090945, -0.031963, -0.031739, 0.038823, -0.028569, 0.045903, -0.163753, -0.0258, 0.029439, 0.092435, -0.062486, -0.093783, -0.011126, 0.02601, -0.08964], [0.029955, -0.046293, 0.003201, -0.041489, -0.085801, 0.012008, 0.035688, -0.118298, 0.011477, 0.006841, 0.108504, -0.096148, 0.104212, -0.039878, -0.049917, -0.079346, -0.022402, 0.027278, 0.062797, -0.02397, 0.047999, 0.150628, 0.098187, 0.026809, -0.138368, -0.017151, -0.01804, 0.108, -0.109689, -0.110244, 0.03555, -0.051917, 0.086829, 0.083983, -0.114146, -0.030341, -0.116089, 0.009179, 0.110119, -0.071749, 0.03132, -0.057175, 0.061059, -0.058262, -0.082698, 0.09401, 0.113565, -0.016639, -0.02668, -0.105111, 0.02134, 0.11379, -0.000512, -0.058522, 0.070988, 0.017719, 0.08541, -0.053081, 0.128621, -0.115577, -0.106636, 0.219387, -0.026048, -0.270204, -0.168269, -0.007121, -0.003673, -0.063803, -0.037814, 0.019308, -0.098948, 0.045642, 0.148349, -0.087774, 0.102467, -0.052101, 0.076466, 0.105327, -0.003704], [0.160539, -0.005115, -0.022011, 0.047847, 0.042222, 0.179397, -0.091064, -0.271651, 0.084262, -0.074199, -0.136768, -0.01913, 0.047509, 0.059151, 0.000629, -0.127321, -0.039673, 0.027568, -0.017422, 0.007487, -0.075508, 0.031143, 0.006148, 0.081755, 0.033558, -0.007971, 0.098388, -0.062108, 0.097566, -0.044647, 0.127146, 0.150146, -0.125307, 0.096867, -0.009773, -0.052158, -0.07888, 0.084368, 0.135024, 0.048677, -0.03045, -0.070216, 0.03299, 0.088651, -0.133111, 0.092395, 0.035815, 0.04632, 0.08618, 0.145764, -0.161882, -0.134038, 0.06071, 0.174464, -0.149795, -0.033212, -0.04356, -0.0666, -0.162813, 0.041101, -0.03305, -0.038028, 0.021264, 0.071776, 0.041714, 0.01069, -0.034011, 0.002544, 0.025568, -0.006301, 0.050363, 0.064552, -0.176547, -0.015745, 0.051858, 0.014001, -0.053257, 0.001193, -0.099611], [-0.105642, 0.080887, 0.079521, -0.095455, 0.002688, -0.041993, -0.01397, -0.016954, 0.086294, -0.066554, -0.093116, 0.019915, 0.008554, -0.073527, -0.012954, -0.022437, 0.02321, -0.033282, 0.002976, -0.121476, 0.071823, 0.113726, 0.084929, 0.009271, -0.037058, -0.047045, 0.096424, -0.055221, -0.038365, -0.10223, -0.09972, 0.005581, 0.131916, 0.052584, -0.042991, 0.009164, 0.059063, 0.09893, 0.100398, 0.007647, 0.098208, -0.126617, 0.01076, -0.114636, -0.077748, -0.048825, 0.06836, -0.088786, 0.064965, -0.017373, 0.101187, -0.16511, -0.061063, -0.177543, -0.021766, -0.086358, 0.125952, -0.139323, -0.048975, -0.255251, -0.056906, 0.112241, -0.008376, -0.011463, 0.050587, -0.077227, -0.023562, 0.063273, 0.019094, 0.038655, 0.013446, 0.07991, 0.045048, -0.061658, 0.051785, -0.019684, 0.030846, -0.123912, 0.032342], [0.018021, 0.136587, 0.033494, -0.10328, 0.09923, -0.05215, -0.044108, -0.011319, -0.019429, 0.062973, 0.03852, -0.0059, -0.063834, -0.061942, 0.084714, 0.095322, -0.005934, -0.081484, 0.019595, 0.009848, -0.080615, -0.051776, -0.114958, -0.042789, 0.02767, -0.011154, 0.033157, -0.086847, 0.04524, 0.026019, 0.030885, -0.021555, 0.045363, -0.002022, 0.080806, -0.049265, 0.07437, 0.061007, 0.118593, -0.059582, 0.08503, -0.144976, -0.05016, 0.016419, 0.043873, 0.018082, 0.036729, -0.008861, -0.040627, -0.057656, 0.044915, 0.231068, 0.09015, -0.043841, 0.107189, -0.04001, 0.058909, 0.060912, 0.087833, -0.15149, -0.346567, 0.037067, -0.095307, -0.016922, -0.017039, -0.041767, 0.09404, -0.017833, -0.016076, 0.005441, -0.095495, 0.005416, 0.073127, 0.014079, 0.046847, 0.081798, 0.015983, -0.018372, -0.035906], [-0.025713, -0.093478, -0.018925, -0.121072, 0.002549, 0.044298, 0.023218, -0.016705, 0.00994, 0.009397, -0.070457, 0.006332, 0.043415, 0.036498, -8e-06, 0.121177, 0.019536, -0.017386, -0.039795, 0.049158, 0.101645, -0.061961, 0.001592, -0.113265, 0.020918, 0.072639, -0.03003, 0.059433, 0.043915, 0.02705, -0.076626, -0.010964, 0.019905, -0.058336, -0.088913, 0.057126, 0.040441, -0.127583, -0.11924, 0.090263, 0.080703, -0.055126, 0.014426, -0.050469, 0.13763, -0.096615, -0.051562, -0.001594, 0.06985, -0.070321, 0.021187, 0.023559, 0.112854, -0.043359, -0.037464, 0.052337, 0.103529, 0.10768, 0.070187, -0.019473, -0.132045, 0.122491, 0.07154, -0.034325, 0.024168, 0.030491, -0.046076, 0.026091, -0.02996, 0.045183, 0.016294, -0.074483, 0.062901, 0.013974, -0.089411, -0.031489, -0.001554, -0.062422, 0.013981], [-0.01471, -0.019557, -0.15563, -0.085685, -0.024113, 0.05808, 0.000993, -0.002947, -0.003782, 0.03606, 0.062415, -0.088841, -0.090611, 0.202589, 0.089314, 0.10324, -0.099361, -0.006356, 0.056106, -0.043404, -0.049953, 0.078077, -0.048721, 0.039753, 0.089689, 0.078863, -0.086962, -0.128727, -0.080782, -0.050487, -0.016154, 0.005708, 0.006103, 0.031063, -0.016625, 0.059688, 0.071703, -0.112177, 0.075053, 0.020459, -0.011399, 0.166888, 0.027679, 0.11404, 0.028118, 0.003089, -0.047206, 0.11812, -0.026454, 0.132112, -0.033394, -0.064875, -0.017886, 0.063418, -0.023272, 0.102726, -0.022364, -0.082454, -0.004333, 0.128412, 0.173372, -0.001272, -0.071815, 0.073578, -0.079119, 0.045146, 0.05592, -0.00605, -0.017191, 0.040275, -0.052554, -0.06427, -0.102918, -0.046716, -0.081603, 0.082025, -0.110644, 0.017342, 0.097147], [0.007306, -0.02223, -0.0755, 0.059212, -0.009464, 0.021179, -0.080742, 0.088582, -0.023254, 0.071921, -0.113888, 0.00227, -0.017672, 0.068983, -0.041104, -0.018655, -0.084744, 0.123974, 0.053753, -0.078976, -0.003667, 0.097358, 0.052622, -0.075165, -0.056658, 0.051831, 0.047589, -0.000752, 0.211342, -0.003188, 0.006419, -0.001275, -0.041834, -0.101951, -0.032748, 0.11497, -0.047969, -0.026915, 0.015061, 0.084365, -0.091967, -0.073234, 0.116201, 0.153038, -0.015588, 0.170396, -0.0379, -0.03553, -0.044304, -0.008257, 0.010462, 0.060687, 0.04021, -0.06074, 0.026109, -0.082644, -0.006185, -0.023222, 0.074473, 0.037953, -0.026695, 0.180625, 0.059867, -0.151976, -0.002316, 0.00968, -0.030298, -0.005115, -0.037836, 0.054385, -0.064021, -0.053694, -0.060309, 0.004378, -0.080234, -0.128753, 0.065484, 0.020943, 0.016679], [-0.015589, -0.080906, 0.087152, -0.176654, 0.033067, 0.118993, -0.040896, 0.056662, -0.025723, -0.096486, -0.044434, 0.05724, 0.036156, -0.007856, -0.130317, 0.118199, -0.066871, 0.082129, 0.100001, -0.066838, -0.065694, 0.060622, -0.147839, 0.111632, 0.261525, 0.003854, 0.091349, 0.030161, -0.159634, -0.045607, -0.034495, -0.10314, 0.165398, -0.015618, -0.039921, -0.027435, -0.023107, 0.110859, 0.15638, 0.098466, -0.027472, -0.086174, 0.051319, -0.034745, -0.09444, -0.017231, -0.063899, -0.096554, 0.025, 0.018402, 0.247313, 0.102048, 0.079404, 0.094945, 0.024937, -0.025996, 0.03458, -0.011443, 0.015213, -0.105611, -0.05354, -0.038497, -0.043073, -0.118141, -0.008695, -0.016486, 0.030924, -0.023538, -0.055626, 0.112438, 0.031319, 0.002476, 0.140191, -0.011871, -0.098482, 0.112528, -0.029992, 0.019678, 0.057434], [-0.113352, -0.004581, 0.006349, 0.000863, -0.06029, 0.03179, 0.047036, 0.004266, 0.069468, 0.027652, 0.016989, -0.06496, -0.009553, -0.052974, -0.091621, -0.000805, -0.015489, 0.070777, 0.058125, -0.003554, 0.14275, 0.19774, 0.058456, -0.010372, 0.074474, -0.052364, -0.059962, 0.023322, -0.149951, -0.069735, -0.054803, 0.092311, -0.027331, 0.042696, -0.097511, 0.047796, 0.185305, 0.07891, 0.043865, 0.126111, -0.179103, 0.111996, 0.097236, 0.136148, -0.240823, -0.089022, -7e-06, 0.044565, 0.06358, 0.058903, 0.051072, 0.065568, -0.111329, 0.060656, 0.165283, -0.037677, 0.001369, -0.051894, -0.055702, -0.048463, -0.083644, 0.130627, -0.001513, -0.139481, 0.013951, 0.004145, -0.004737, -0.010943, -0.001129, 0.009948, -0.063316, 0.147617, -0.059024, 0.049876, -0.032268, 0.06861, -0.036949, 0.083105, -0.048873]], 'w2': [[-0.010086, -0.012751, -0.052603, -0.011105, -0.058674, -0.003476, 0.028342, 0.002046, -0.101849, 0.126215, 0.014767, 0.050419, -0.003988, 0.038286, 0.063683, 0.007404, 0.033962, -0.039369, -0.030042, -0.039351, -0.017497, 0.019193, -0.077339, -0.042675, 0.023255], [0.00869, 0.02016, 0.064325, -0.005456, 0.07848, 0.009733, -0.028462, -0.006086, 0.089762, -0.119455, -0.026315, -0.043381, 0.016163, -0.027009, -0.063332, 0.001484, -0.034236, 0.029913, 0.0341, 0.033096, 0.016557, -0.033259, 0.084893, 0.041704, -0.178328]], 'hist_par': {'USDCHF-OTC': '11101110100010101000', 'SP500-OTC': '10110011110000010111', 'ONDOUSD-OTC': '00100101010000011101', 'EURGBP-OTC': '11101010011110101111', 'RENDERUSD-OTC': '10101000001111101111', 'SUIUSD-OTC': '11000011001101000101', 'HBARUSD-OTC': '01010010011111101111', 'RAYDIUMUSD-OTC': '00000111010111011000', 'GBPUSD-OTC': '10111010010000101011', 'PENGUUSD-OTC': '11010001111010111001', 'DYDXUSD-OTC': '10010000001010010110', 'EURUSD-OTC': '10100001000100000110', 'EURJPY-OTC': '10100010000010100001', 'FETUSD-OTC': '10111101010100011101', 'AMAZON-OTC': '10100010001011010000', 'Gold/BRL': '00000010100101100110', 'NZDCAD-OTC': '11100000101111101001', 'LINKUSD-OTC': '00000010011001010110', 'AUDJPY-OTC': '11000000101100000101', 'SANDUSD-OTC': '11011000100011010011', 'GBPCHF-OTC': '11000011110011111100', 'XNGUSD-OTC': '00110111101101110110', 'INJUSD-OTC': '11000100110011010010', 'NEARUSD-OTC': '01100011100100001111', 'FARTCOINUSD-OTC': '00000111000000000010', 'AUDCAD-OTC': '01011001011001000100', 'NZDUSD-OTC': '00011110010011010100', 'USOUSD-op': '00101010011100010011', 'DIA': '10110111101100101100', 'FR40-OTC': '00100110110101110011', 'EURCHF-OTC': '00101000101001110010', 'XAUUSD-OTC': '10110111011111000110', 'Crude Oil Brent/BRL': '00111100011100010011', 'IWM': '00001100000010000010', 'SQQQ': '11111000101111100110', 'XLK': '00101000100011100011', 'SMH': '10000011000011100011', 'EURTHB-op': '01010101101101100010', 'UKOUSD-OTC': '10000011101111111111', 'ATOMUSD-OTC': '01100111010011011110', 'MELANIAUSD-OTC': '00010011111000101110', 'JPM-OTC': '11100000100001010111', 'AIRLINES-OTC': '00001100111011001001', 'WIFUSD-OTC': '11101001010000010100', 'USDJPY-OTC': '01011001101000000001', 'IMXUSD-OTC': '10101101101110110110', 'FWONA-OTC': '01000001010011111010', 'DASHUSD-OTC': '11010110101011010001', 'GDX': '10110110000110001000', 'PEPEUSD-OTC': '01011001001001011010', 'SPY': '10000000001110000100', 'WLDUSD-OTC': '00000101010001001101', 'USDTHB-OTC': '00010101010011000001', 'JP225-OTC': '10011011111100011000', 'USNDAQ100:N': '01000001001011100011', 'USSPX500:N': '10000000001110000100', 'ARBUSD-OTC': '11011000100111010110', 'PENUSD-OTC': '11111001100001011000', 'AUS200-OTC': '01110101010111101010', 'GBPCAD-OTC': '10111110001011100110', 'EURTHB-OTC': '00011110011100010110', 'CHFNOK-OTC': '10111100101000011111', 'MCDON-OTC': '01000001110000001110', 'US30:N': '00110111011100101100', 'JPYTHB-OTC': '00000000011110101001', 'GRTUSD-OTC': '00111001111001011110', 'AUDCHF-OTC': '00111110001101101101', 'SOLUSD-OTC': '00000101110010101011', 'USOUSD-OTC': '01010101001100000000', 'COKE-OTC': '11000001100111111010', 'OpenAI-OTC': '11111101101110111100', 'SHIBUSD-OTC': '11010000001010010110', 'MAGNIFICENT7-OTC': '00010100101011000010', 'USNDAQ100-OTC': '00111101111011110011', 'USDDOP-OTC': '01111100001110001100', 'EURAUD-OTC': '01010000110111111010', 'JAPAN225:N': '00100000101110000110', 'GERMANY30:N': '10011010010101011011', 'FRANCE40:N': '10001000001111000110', 'XRPUSD-OTC': '10111111001110000111', 'JUPUSD-OTC': '01100001010010011001', 'GBPJPY-OTC': '11011000111010111011', 'USDSEK-OTC': '10110001011011010101', 'USDBRL-OTC': '10110000011000010111', 'APPLE-OTC': '01100100011010010011', 'US2000-OTC': '01010001110001010101', 'CADJPY-OTC': '11000110000010110111', 'EOSUSD-OTC': '00010011011011111111', 'AI Power & Datacenter': '10001010000011000110', 'FB-OTC': '00111111011110110110', 'US30-OTC': '01001010100011011101', 'Bitcoin/Gold-op': '00010111100111010000', 'US AI Semiconductors': '10000001000011100011', 'AUDNZD-OTC': '01111010000001111011', 'PLTR-OTC': '00010000011001111111', 'AUS200:N': '00010100011110010111', 'XAGUSD-OTC': '11111100101011001111', 'CADCHF-OTC': '10000011101000111110', 'USDCAD-OTC': '00111100110110011110', 'SNAP-OTC': '01011100100000001100', 'BTCUSD-OTC-op': '00010111001110111000', 'IOTAUSD-OTC': '01000010011110010010', 'MATICUSD-OTC': '10110000100101001001', 'USDPLN-OTC': '11010100001110101011', 'USDSGD-OTC': '00101011101001011100', 'CHFJPY-OTC': '00110000101110100101', 'NZDJPY-OTC': '00011001111011011110', 'USDZAR-OTC': '01001001100011001100', 'KLARNA-OTC': '10111110100011001101', 'HK33-OTC': '11011000100101001010', 'US2000:N': '10000011000010000010', 'HONGKONG33:N': '01111101100000111001', 'USDNOK-OTC': '01010111110101010000', 'Anthropic-OTC': '10001100100010101110', 'UK100-OTC': '10100100111100011100', 'USDCOP-OTC': '00101101110111100101', 'CASINOS-OTC': '10101110001001110101', 'EURCAD-OTC': '00111000101011010111', 'EU50-OTC': '10000100111111110101', 'SATSUSD-OTC': '11010000111001000011', 'URANIUM-OTC': '10110000001100011111', 'BONKUSD-OTC': '01011100100101010110', 'CANNABIS-OTC': '00001001001110101100', 'MSFT-OTC': '01100101100111110100', 'MORSTAN-OTC': '11010011101101100000', 'ETHUSD-OTC': '11100110001110111000', 'AUDUSD-OTC': '10011010110011110111', 'USDARS-OTC': '11100101011111110010', 'TRON-OTC': '01110000100101111111', 'GER30-OTC': '01101111101010010011', 'GBPNZD-OTC': '10000011011101110100', 'GOOGLE-OTC': '11010010101010110111', 'TIAUSD-OTC': '10101001101100110011', 'UK100:N': '11001001011001000110', 'Magnificent7-op': '01100110000001010011', 'GS-OTC': '01000001110011101101', 'GBPAUD-OTC': '00110111001000101110', 'TESLA-OTC': '00001100100001000111', 'LABUBUUSD-OTC': '00011111000010000101', 'USDTRY-OTC': '11101011100011010110', 'DOTUSD-OTC': '01110001011111111100', 'ALIBABA-OTC': '11000010111100001111', 'TRUMPUSD-OTC': '11110011001001001101', 'PYTHUSD-OTC': '10011100010011010011', 'EURNZD-OTC': '01100111101011111011', 'LTCUSD-OTC': '10011000100110110110', 'GER30/UK100-OTC': '10010000100000111110', 'COTTON-OTC': '10011111100000111110', 'US30/JP225-OTC': '00010111100111110000', 'EURJPY-op': '10010011001101010001', 'TESLA/FORD-OTC': '00111111111111111010', 'NVDA/AMD-OTC': '10000110110101100000', 'XAU/XAG-OTC': '10111111101000010001', 'GOOGLE/MSFT-OTC': '00111000101011100100', 'META/GOOGLE-OTC': '10001011010110001010', 'LUNA-OTC': '11001000000011110010', 'USDAED-OTC': '11101000001110100000', 'US100/JP225-OTC': '11000101010110011010', 'MSFT/AAPL-OTC': '01111111001010100000', 'AMZN/EBAY-OTC': '10000111000101001111', 'NVDA-OTC': '01101001011001101111', 'EURUSD-op': '00100011000100111011', 'EURGBP-op': '10000100110011011000', 'USDTHB-op': '00010101111001111100', 'USDMYR-OTC': '00110100111010101001', 'AMZN/ALIBABA-OTC': '10011010100110100100', 'USDVND-OTC': '11000101010111101011', 'COCOA-OTC': '00000110000000100100', 'USDBOB-OTC': '11010110110011110001', 'ICPUSD-OTC': '10100000111100110011', 'USDIDR-OTC': '01001101011100011001', 'XPDUSD-OTC': '10000110111001011001', 'USDHKD-OTC': '01111001010011000011', 'WDC-OTC': '11111111110100111000', 'COFFEE-OTC': '11101000010000111110', 'USDPHP-OTC': '10100111000100000110', 'USDJPY-op': '10000111110111001001', 'XPTUSD-OTC': '01011001100100100000', 'SUGAR-OTC': '10010111101101110001', 'GBPJPY-op': '00000110101011000001', 'USDNGN-OTC': '00111111100001011001', 'INTEL/IBM-OTC': '10110100010011110010', 'SEIUSD-OTC': '01101001010011110111', 'USDSAR-OTC': '00110000001110001111', 'RONINUSD-OTC': '01000000010111000100', 'HYPE-OTC': '01101101000011111000', 'NIKE-OTC': '00001011110111101111', 'MU-OTC': '10011111000010011001', 'GEV-OTC': '10010110110110111101', 'USDBDT-OTC': '10100011011111011101', 'NFLX/AMZN-OTC': '10010100011010010110', 'GBPUSD-op': '11000111000000111001', 'USDCLP-OTC': '11010111001111011111', 'XAUUSD-op': '00000100010010001000', 'SpaceX-OTC': '11011001011010010100', 'SpaceX-op': '11000100011010011110', 'ASMLa': '10110001001100010000', 'NZDCAD-op': '10101101000101110100', 'European AI': '11010100110100010000', 'Luxury': '11001001010000010100', 'AUDCAD-op': '01001111000000000101', 'AUDUSD-op': '11111001001110010010', 'GBPCAD-op': '11000111100100010111', 'BTCUSD-op': '10101001110001100110', 'GBPAUD-op': '10010010111011010101', 'AUDNZD-op': '01101001001111101011', 'GBPNZD-op': '00011011000110110101', 'AUDCHF-op': '01011001101000000011', 'AUDJPY-op': '10101111000100000011', 'EURNZD-op': '01011110000101000001', 'AMAZON-op': '00110010001011100010', 'GOOGLE-op': '11001011000011111110', 'USDMXN-OTC': '00111001101110110001', 'FACEBOOK-op': '11000010100010000111', 'MSFT-op': '11111000010000000110', 'TESLA-op': '1111010000000010000'}, 'hist_ctx': {'otc20': '00000001101010000111100110010010010111011111011010', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '01001111000100001010100011100001000100100000101111', 'otc1': '11001110011011001101111111000101101111100101011111', 'otc2': '00101110110101000010001011011111110000011100100011', 'otc3': '10000000010111111100111100000101000001001110011110', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '00010000110011100010011100000011011110010110101101', 'otc13': '11100111110001001010011110001101000001100101101111', 'otc14': '11000000010110000110100000101011010100010000110011', 'otc15': '01011000011001000010001100010010101000100011101011', 'otc16': '10111110011011000100001100001001100101010001110110', 'otc18': '01110000000110110011010011100010011111111111011100', 'otc19': '00010100001011001110000101100100001010010111010010', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '00111101000101110100001010011000011010101001000101', 'real17': '01110001000100000000010000000010101101011111111111', 'real12': '00110011001010001010110111110001010000110100111110', 'real13': '11111101100001001000001011101001111010111110000001', 'real14': '01111111111110111110101001101110111111011100111001', 'real15': '11000111111111110011101111111010101000100111111100', 'real16': '10101111010100000100101010000000001000000111111110', 'real18': '10000101111111000000010000000000000000000010010100', 'real19': '00010111011111101101110001111111111111011101100110', 'real20': '01011011111101001000110000010001000111111111111111', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '00111100101110101101110000101100000110111100100100', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5882166, 'preentreno': True, 'sombra': '01111010000000100100010110001101101111100100101001100000000101001010100011101101010001000110010111011100111100000010010100000110010111110111110110010101111111001100001111011111111011010101010000100010111001100101110100001100000001101111010101010111111110000111110000101110110001011001000111111111110101110000011000101010000101000111111011000011110011011101110001101110100000000100011100000101110111101010100011100110000110010110100010100101101100100010001010011111010111000000100011001000000011111000011001000011011011100000011011110001000001000001010101010111110000011101', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960, 1793413740, 1793413860, 1793413920, 1793413980, 1793414040, 1793414220, 1793413800, 1793414280, 1793414340, 1793414160, 1793414460, 1793414520, 1793414580, 1793414100, 1793414760, 1793414820, 1793414700, 1793414940, 1793414640, 1793415000, 1793414400, 1793415180, 1793415120, 1793415060, 1793415480, 1793415540, 1793415600, 1793415240, 1793449860, 1793449920, 1793449980, 1793450040, 1793450100, 1793450160, 1793450220, 1793450280, 1793450340, 1793450400, 1793450460, 1793459520, 1793459580, 1793459640, 1793459700, 1793459760, 1793459820, 1793459880, 1793459940, 1793460000, 1793460060, 1793460120, 1793460180, 1793460240, 1793460300, 1793460360, 1793460780, 1793460840, 1793460900, 1793460960, 1793461020, 1793461080, 1793461140, 1793461200, 1793461260, 1793461320, 1793461380, 1793461440, 1793461500, 1793461560, 1793461620, 1793461680, 1793461740, 1793461800, 1793560080, 1793560140, 1793560200, 1793560260, 1793560380, 1793560440, 1793560500, 1793560560, 1793560620, 1793560680, 1793560740, 1793560800, 1793560860, 1793560920, 1793560980, 1793561040, 1793561100, 1793561160, 1793561220, 1793561280, 1793561340, 1793561400, 1793562360, 1793562480, 1793562600, 1793562720, 1793562840, 1793562960, 1793563080, 1793563200, 1793563320, 1793563440, 1793563560, 1793563680, 1793563800, 1793563920, 1793625840, 1793626080, 1793626200, 1793626320, 1793626440, 1793626560, 1793626680, 1793626800, 1793626920, 1793627040, 1793627280, 1793627400, 1793627760, 1793627880, 1793628000, 1793628120, 1793629680, 1793629800, 1793629920, 1793630040, 1793630160, 1793630280, 1793630400, 1793630520, 1793630640, 1793630760, 1793630880, 1793631000, 1793631120, 1793631240, 1793631360, 1793638080, 1793638200, 1793638320, 1793638800, 1793638920, 1793639040, 1793639160, 1793639280, 1793639400, 1793639520, 1793639640, 1793639760, 1793639880, 1793640240, 1793640360, 1793640480, 1793640600, 1793640720, 1793644680, 1793644800, 1793644920, 1793645040, 1793645160, 1793645280, 1793645400, 1793645520, 1793645640, 1793710440, 1793710560, 1793710680, 1793710800, 1793710920, 1793711040, 1793711160, 1793711280, 1793711400, 1793713680, 1793713800, 1793713920, 1793714040, 1793714160, 1793714280, 1793714400, 1793714520, 1793714640, 1793714760, 1793714880, 1793715000, 1793735400, 1793735520, 1793735640, 1793735760, 1793735880, 1793736000, 1793736120, 1793736240, 1793736360, 1793736480, 1793736600, 1793736720, 1793736840, 1793736960, 1793737080, 1793737200, 1793737320, 1793737440, 1793737560, 1793737680, 1793737800, 1793737920, 1793738040, 1793738160, 1793804160, 1793804580, 1793804640, 1793804700, 1793804760, 1793804820, 1793804880, 1793805120, 1793805180, 1793805240, 1793805300, 1793805360, 1793805420, 1793805480, 1793805540, 1793805600, 1793805660, 1793805720, 1793805780, 1793805840, 1793805900, 1793806080, 1793806800, 1793806860, 1793806920, 1793806980, 1793807040, 1793807100, 1793807280, 1793807340, 1793807400, 1793807460, 1793807520, 1793807580, 1793807640, 1793807700, 1793807760, 1793807820, 1793808120, 1793808240, 1793808360, 1793808480, 1793808600, 1793808720, 1793808840, 1793808960, 1793809800, 1793809920, 1793810040, 1793810160, 1793810280, 1793810400, 1793810520, 1793810640, 1793810760, 1793810880, 1793811000, 1793811120, 1793811240], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1573, 'activa': False, 'ev_prom': 0.026430696379244376, 'ultima_senal': 1793811499.7876549, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1793837298}}
_CRIPTO = ("BTC", "ETH", "SOL", "XRP", "LTC", "DOT", "ADA", "CARDANO", "DOGE", "SHIB", "PEPE", "BONK", "TRON", "TRX",
           "SUI", "ARB", "HBAR", "FET", "ONDO", "TAO", "WIF", "WLD", "SEI", "JUP", "DYDX", "EOS", "DASH", "ATOM",
           "LUNA", "TRUMP", "RAYDIUM", "RENDER", "PENGU", "PEN", "SATS", "HYPE", "FARTCOIN", "MELANIA", "FLOKI",
           "LINK", "NEAR", "MATIC", "IMX", "INJ", "ORDI", "PYTH", "STX", "GRT", "SAND", "MANA", "ICP", "IOTA", "RONIN",
           "BCH", "LABUBU")
_DIVISAS = ("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "THB", "MXN", "BRL", "COP", "ZAR", "TRY", "INR",
            "IDR", "PHP", "PLN", "SGD", "HKD", "NOK", "SEK", "ARS", "CLP", "DOP", "BOB", "BDT", "NGN", "VND", "MYR",
            "AED", "SAR", "EGP", "PKR")


def ia_tipo_par(par):
    """(es_otc, es_divisa, es_cripto) a partir del nombre del par."""
    p = str(par).upper().replace("-OTC", "").replace("-OP", "")
    otc = "OTC" in str(par).upper()
    cripto = any(p.startswith(c) for c in _CRIPTO)
    divisa = (not cripto) and len(p) == 6 and p[:3] in _DIVISAS and p[3:] in _DIVISAS
    return otc, divisa, cripto


def _ia_lim(x, a=3.0):
    return a if x > a else (-a if x < -a else x)


def ia_rasgos(velas, par, pago, t, tf=1, digital=False, propio=(0.0, 0.0, 0.0, 0.0)):
    """Lo que 've' la IA autónoma: velas crudas y contexto. Nada de indicadores ni estrategias hechas.
    velas: dicts o,h,l,c (la última es la vela de señal). Devuelve IA_ENTRADAS números o None."""
    n = len(velas)
    if n < 40:
        return None
    c = [v["c"] for v in velas]
    tr = [max(velas[i]["h"], c[i - 1]) - min(velas[i]["l"], c[i - 1]) for i in range(n - 14, n)]
    atr = sum(tr) / 14.0                               # tamaño normal de una vela ahora (para comparar)
    if atr <= 0:
        atr = abs(c[-1]) * 1e-5 or 1e-9
    tr50 = [velas[i]["h"] - velas[i]["l"] for i in range(max(1, n - 50), n)]
    atr50 = (sum(tr50) / len(tr50)) or atr
    f = []
    for v in velas[-IA_VELAS_VE:]:                     # las últimas 20 velas tal cual: cuerpo y mechas
        f.append(_ia_lim((v["c"] - v["o"]) / atr))
        f.append(_ia_lim((v["h"] - max(v["o"], v["c"])) / atr))
        f.append(_ia_lim((min(v["o"], v["c"]) - v["l"]) / atr))
    f.append(_ia_lim((c[-1] - c[-4]) / atr / 2))      # cuánto se ha movido el precio (corto, medio, largo)
    f.append(_ia_lim((c[-1] - c[-11]) / atr / 3))
    f.append(_ia_lim((c[-1] - c[-31]) / atr / 5))
    alto = max(v["h"] for v in velas[-30:]); bajo = min(v["l"] for v in velas[-30:])
    f.append(_ia_lim(((c[-1] - bajo) / ((alto - bajo) or 1e-12)) * 2 - 1))   # dónde está dentro del rango reciente
    f.append(_ia_lim(atr / atr50 - 1.0))              # ¿más agitado o más quieto que de costumbre?
    h = (t % 86400) / 86400.0 * 2 * math.pi           # hora del día (UTC), día y fin de semana
    f.append(math.sin(h)); f.append(math.cos(h))
    dia = int(t // 86400 + 4) % 7                      # 0 = domingo
    f.append(math.sin(dia / 7 * 2 * math.pi)); f.append(math.cos(dia / 7 * 2 * math.pi))
    f.append(1.0 if dia in (0, 6) else 0.0)
    otc, divisa, cripto = ia_tipo_par(par)
    f.append(1.0 if otc else 0.0); f.append(1.0 if divisa else 0.0); f.append(1.0 if cripto else 0.0)
    f.append(1.0 if digital else 0.0)
    f.append((tf - 1) / 4.0)                           # temporalidad: 0 = M1 … 1 = M5
    f.append(_ia_lim(((pago or 0.85) - 0.85) * 10))    # payout del par
    f.extend(propio)                                   # cómo le viene yendo en ese par y en ese mercado a esa hora
    f.append(1.0)                                      # sesgo
    return f


class IARefuerzo:
    """Red pequeña que estima cuánto se gana por dólar con CALL y con PUT, y aprende en línea."""

    def __init__(self, ruta):
        self.ruta = ruta
        self.lock = threading.Lock()
        rnd = __import__("random").Random(7)
        e = 1.0 / math.sqrt(IA_ENTRADAS)
        self.w1 = [[rnd.uniform(-e, e) for _ in range(IA_ENTRADAS)] for _ in range(IA_OCULTAS)]
        self.w2 = [[rnd.uniform(-0.1, 0.1) for _ in range(IA_OCULTAS + 1)] for _ in range(2)]
        self.lr = 0.004
        self.aprendidas = 0                # ejemplos con los que ha aprendido
        self.preentreno = False            # ¿ya hizo el primer entrenamiento con el historial?
        self.tfs_entrenadas = []           # temporalidades con primer entrenamiento hecho
        self.velas_tf = {}                 # temporalidad -> velas M1 por par con las que se entrenó
        self.hist_hecho = []               # temporalidades ya entrenadas con el historial grande (20.000 velas)
        self.sombra = deque(maxlen=IA_SENALES_VENTANA)    # últimas señales evaluadas (True gana / False pierde)
        self.sombra_t = deque(maxlen=IA_SENALES_VENTANA)  # hora de cada una
        self.mejor = {}                                    # cierre -> (lo que esperaba, par, tf): la que cuenta ese minuto
        self.hist_par = {}                                 # par -> últimas 20 decisiones propias (gana / pierde)
        self.hist_ctx = {}                                 # mercado+hora -> últimas 50 decisiones propias
        self.total_senales = 0
        self.activa = False                # False = modo sombra · True = opera
        self.fase = "Esperando"
        self.base_publicado = 0            # de qué publicación del autor viene lo aprendido
        self.ev_prom = None                # lo que espera ganar por dólar en promedio (su mejor opción), últimos cierres
        self.ultima_senal = 0.0            # hora de su última señal
        self.senales_t = deque(maxlen=500) # horas de las señales (para "señales en la última hora")
        self.revisados = 0                 # pares revisados en el último cierre
        self._cierre = None
        self._cuenta = 0
        self.cargar()
        self.tomar_publicada()

    # --- red ---
    def _adelante(self, x):
        oc = []
        for fila in self.w1:
            s = 0.0
            for wi, xi in zip(fila, x):
                s += wi * xi
            oc.append(math.tanh(s))
        oc.append(1.0)
        q = [sum(w * o for w, o in zip(fila, oc)) for fila in self.w2]
        return oc, q

    def q(self, x):
        with self.lock:
            return self._adelante(x)[1]

    def aprender(self, x, r_call, r_put):
        """Un paso: acerca lo que espera ganar a lo que de verdad habría ganado con CALL y con PUT."""
        with self.lock:
            oc, q = self._adelante(x)
            errs = (q[0] - r_call, q[1] - r_put)
            lr = self.lr
            grad_oc = [0.0] * IA_OCULTAS
            for k in range(2):
                e = errs[k]
                fila = self.w2[k]
                for j in range(IA_OCULTAS):
                    grad_oc[j] += e * fila[j]
                for j in range(IA_OCULTAS + 1):
                    fila[j] -= lr * (e * oc[j] + 1e-4 * fila[j])
            for j in range(IA_OCULTAS):
                g = grad_oc[j] * (1 - oc[j] * oc[j])
                if g == 0.0:
                    continue
                fila = self.w1[j]
                for i in range(IA_ENTRADAS):
                    fila[i] -= lr * g * x[i]
            self.aprendidas += 1

    # --- modo sombra ---
    def anotar_senal(self, gano, cuando=None):
        """Una señal resuelta (máximo una por minuto). Se activa solo si el acierto está sobre el
        equilibrio con 95 % de seguridad, con 300 señales o más repartidas en al menos 2 horas."""
        with self.lock:
            self.sombra.append(bool(gano))
            self.sombra_t.append(float(cuando or time.time()))
            self.total_senales += 1
            r = self._medida()
            if not self.activa and r["listo"]:
                self.activa = True
                return "activa"
            ult = list(self.sombra)[-IA_SENALES_MIN:]
            if self.activa and len(ult) >= IA_SENALES_MIN and sum(ult) / len(ult) < IA_ACIERTO_APAGAR:
                self.activa = False
                return "sombra"
        return None

    def _medida(self):
        n = len(self.sombra)
        g = sum(self.sombra)
        horas = (self.sombra_t[-1] - self.sombra_t[0]) / 3600.0 if n > 1 else 0.0
        nec = ia_acierto_necesario(n)
        listo = n >= IA_SENALES_MIN and horas >= IA_HORAS_MIN and ia_limite_inferior(g, n) >= IA_EQUILIBRIO
        return {"n": n, "g": g, "horas": horas, "necesita": nec, "listo": listo}

    @staticmethod
    def _ctx(par, t):
        return ("otc" if "OTC" in str(par).upper() else "real") + str(int(t % 86400 // 3600))

    def propio(self, par, t):
        """Su propio historial: cómo le viene yendo en este par y en este mercado a esta hora."""
        hp = self.hist_par.get(par) or ()
        hc = self.hist_ctx.get(self._ctx(par, t)) or ()
        fp = (2 * sum(hp) - len(hp)) / len(hp) if hp else 0.0
        fc = (2 * sum(hc) - len(hc)) / len(hc) if hc else 0.0
        return (fp, len(hp) / 20.0, fc, len(hc) / 50.0)

    def registrar(self, par, t, gano):
        with self.lock:
            self.hist_par.setdefault(par, deque(maxlen=20)).append(bool(gano))
            self.hist_ctx.setdefault(self._ctx(par, t), deque(maxlen=50)).append(bool(gano))

    def mirar(self, cierre, q_mejor, senal):
        """Anota cada revisión (para mostrar qué opina del mercado aunque no marque señales)."""
        with self.lock:
            if cierre != self._cierre:
                if self._cierre is not None:
                    self.revisados = self._cuenta
                self._cierre, self._cuenta = cierre, 0
            self._cuenta += 1
            self.ev_prom = q_mejor if self.ev_prom is None else self.ev_prom * 0.998 + q_mejor * 0.002
            if senal:
                ahora = time.time()
                self.ultima_senal = ahora
                self.senales_t.append(ahora)

    def resumen(self):
        n = len(self.sombra)
        hora = time.time() - 3600
        m = self._medida()
        return {"activa": self.activa, "senales": n, "total": self.total_senales,
                "necesita": round(100 * m["necesita"], 1), "horas": round(m["horas"], 2), "horas_min": IA_HORAS_MIN,
                "acierto": round(100 * sum(self.sombra) / n, 1) if n else None,
                "necesarias": IA_SENALES_MIN, "aprendidas": self.aprendidas,
                "preentreno": self.preentreno, "fase": self.fase, "velas": max(self.velas_tf.values() or [0]),
                "ev": round(self.ev_prom * 100, 1) if self.ev_prom is not None else None,
                "revisados": self.revisados or self._cuenta,
                "ultima_senal": int(self.ultima_senal) or None,
                "senales_hora": sum(1 for t in self.senales_t if t >= hora)}

    def resumen_cliente(self):
        """Lo único que ve un cliente: si está lista y cuánto aprendió (sin cifras de sombra ni umbral)."""
        return {"cliente": True, "preentreno": self.preentreno, "aprendidas": self.aprendidas, "fase": self.fase}

    # --- guardar / cargar ---
    def guardar(self):
        with self.lock:
            d = {"v": IA_VERSION, "w1": self.w1, "w2": self.w2,
                 "hist_par": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_par.items()},
                 "hist_ctx": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_ctx.items()}, "aprendidas": self.aprendidas, "preentreno": self.preentreno,
                 "sombra": "".join("1" if x else "0" for x in self.sombra), "sombra_t": [int(t) for t in self.sombra_t],
                 "regla": 2, "velas_tf": {str(k): v for k, v in self.velas_tf.items()}, "hist_hecho": self.hist_hecho,
                 "total": self.total_senales,
                 "activa": self.activa, "base_publicado": self.base_publicado,
                 "ev_prom": self.ev_prom, "ultima_senal": self.ultima_senal, "tfs_entrenadas": self.tfs_entrenadas}
        tmp = self.ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        os.replace(tmp, self.ruta)

    def cargar(self):
        try:
            with open(self.ruta, encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                self.total_senales = int(d.get("total", 0) or 0)
                return                                 # IA de otra versión: la autónoma aprende desde cero
            self.w1, self.w2 = d["w1"], d["w2"]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            if d.get("regla") == 2:                    # medición nueva: una por minuto, con su hora
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:                                      # la medición vieja se reinicia (contaba señales repetidas)
                self.activa = False
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = int(d.get("base_publicado", 0) or 0)
            vt = d.get("velas_tf")
            self.velas_tf = {int(k): int(v) for k, v in vt.items()} if isinstance(vt, dict) else (
                {1: 5000} if d.get("preentreno") else {})
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            self.ev_prom = d.get("ev_prom")
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.ultima_senal = float(d.get("ultima_senal") or 0)
        except Exception:
            pass

    def tomar_publicada(self):
        """Si la actualización trae una IA más nueva (entrenada en el PC del autor), se usa esa."""
        try:
            d = (IA_BASE or {}).get(BROKER) or {}
            if not d and (not self.aprendidas or self.base_publicado):
                d = (IA_BASE or {}).get("exnova") or {}     # IQ Option sin IA propia: arranca con lo aprendido en Exnova
            pub = int(d.get("publicado", 0) or 0)
            if not pub or pub <= self.base_publicado:
                return False
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                return False
            self.w1, self.w2 = d["w1"], d["w2"]
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.sombra.clear(); self.sombra_t.clear()
            if d.get("regla") == 2:
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:
                self.activa = False
            vt = d.get("velas_tf")
            if isinstance(vt, dict):
                self.velas_tf = {int(k): int(v) for k, v in vt.items()}
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = pub
            try:
                self.guardar()
            except Exception:
                pass
            return True
        except Exception:
            return False


def ia_limpiar_velas(velas):
    """Quita de la memoria de la IA los días con velas de OTRO activo (un error viejo de descarga las mezclaba).
    Señal: saltos imposibles de un minuto al siguiente. velas: {hora: vela}. Devuelve cuántas quitó."""
    ts = sorted(velas)
    if len(ts) < 200:
        return 0
    saltos = []
    for a, b in zip(ts, ts[1:]):
        if b - a <= 120 and velas[a]["c"] > 0 and velas[b]["c"] > 0:      # velas seguidas (o casi)
            saltos.append((b, abs(math.log(velas[b]["c"] / velas[a]["c"]))))
    if not saltos:
        return 0
    orden = sorted(x for _, x in saltos)
    normal = orden[len(orden) // 2] or 1e-6
    limite = max(normal * 60, 0.05)                      # 60 veces el movimiento normal y al menos 5 %
    dias_malos = {t // 86400 for t, x in saltos if x > limite}
    if not dias_malos:
        return 0
    quitar = [t for t in ts if t // 86400 in dias_malos]
    for t in quitar:
        velas.pop(t, None)
    return len(quitar)


def ia_agrupar(m1, tf):
    """Velas M1 -> velas de tf minutos (solo las completas)."""
    if tf == 1:
        return m1
    out, grupo, ini = [], [], None
    for v in m1:
        g = v["t"] - v["t"] % (tf * 60)
        if g != ini:
            if len(grupo) == tf:
                out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                            "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
            grupo, ini = [], g
        grupo.append(v)
    if len(grupo) == tf:
        out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                    "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
    return out


def ia_estado_guardado(cliente=False):
    """Para la pantalla de Configuración (sin bot andando): el estado de la IA (resumido para el cliente)."""
    ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
    return ia.resumen_cliente() if cliente else ia.resumen()


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = False                         # una sola temporalidad
        self.tfs = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal e IA)
        self.ia_cliente = False  # app_gui: cliente con la IA habilitada en la hoja (columna IA = SI)
        self.ia = None           # IA del autor (solo con estrategia "ia")
        self.ia_pend = {}        # (par, tf) -> decisiones por resolver cuando cierre la vela operada
        self.ia_cola = deque(maxlen=20000)     # ejemplos nuevos para aprender
        self.ia_repaso = deque(maxlen=20000)   # memoria de repaso (refuerzo con repetición de experiencias)
        self.ia_ev = {}                        # (par, tf) -> lo que la IA espera ganar por dólar en este cierre
        self.ia_prob = {}                      # (par, tf) -> probabilidad de acertar que calcula la IA en este cierre
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.animo_pend, self.animo_grabadas = [], {}       # filtro del autor (volatilidad): señales por resolver
        self.hist = {}           # (par, tf) -> velas
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None
        self.estirado_hecho = set()   # bot Bollinger: (par, tf, inicio de vela) ya tomados al estirarse

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más."""
        if self.stop_alcanzado():
            if not self.detener:
                self.detener = True
                self.avisar_stop()
            return True
        return self.detener

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que conviene operar ese par: binaria/turbo o digital, el que mejor pague
        entre los mercados elegidos. (None, None) si no se puede operar."""
        cfg = self.cfg
        tipo = "turbo" if tf <= 5 else "binary"
        opciones = []
        if (cfg["incluir_otc"] if es_otc else cfg["incluir_mercado_real"]) and pays.get(tipo) is not None:
            opciones.append((pays[tipo], tipo))
        if cfg.get("incluir_digital") and tf in (1, 5, 15) and pays.get("digital"):
            opciones.append((pays["digital"], "digital"))
        if not opciones:
            return None, None
        pago, t = max(opciones)
        return t, pago

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=bool(cfg.get("incluir_digital")))
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        if cfg.get("incluir_digital"):
            self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre. Primero los pares que más pagan. Si el bróker devuelve el número
        de pedido, lee hasta 3 pares a la vez (en un celular lento alcanzan más pares antes del cierre)."""
        limite = prox - self.adelanto_analisis() - 1.5
        pago = lambda p: (self.pares.get(p) or {}).get("payout") or 0
        tareas = [(par, tf) for par in sorted(list(self.seleccion), key=pago, reverse=True) for tf in tfs_c]
        if getattr(self.b, "_rid_ok", None) is not True:          # sin número de pedido: uno por uno, como antes
            for par, tf in tareas:
                if not self._preparar_uno(par, tf, prox, limite):
                    return
            return
        from concurrent.futures import ThreadPoolExecutor, wait
        if getattr(self, "_pool_prep", None) is None:
            self._pool_prep = ThreadPoolExecutor(max_workers=PREPARAR_A_LA_VEZ, thread_name_prefix="prep")
        futuros = [self._pool_prep.submit(self._preparar_uno, par, tf, prox, limite) for par, tf in tareas]
        wait(futuros, timeout=max(0.0, limite - self.b.ahora()) + 1.0)
        for f in futuros:
            f.cancel()                                             # lo que no alcanzó a empezar ya no se pide

    def _preparar_uno(self, par, tf, prox, limite):
        """Prepara un par en una temporalidad. Devuelve False si ya no hay tiempo (o se detuvo el bot)."""
        if self.detener or not self.b.conectado or self.b.ahora() > limite:
            return False
        if par in self.pares_en_uso:
            return True
        k = (par, tf)
        try:
            hist = self.hist.get(k) or []
            if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                self.fase = f"Leyendo {par} M{tf}"
                velas = self.b.velas(par, tf, HISTORIA_VELAS)
                if len(velas) < 30:
                    self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); return True
                self.hist[k] = velas
                self.hist_t[k] = time.time()
                if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                        and velas[-1]["t"] >= self.b.ahora() - 180):
                    try:
                        self.vivo_pend[par] = time.time()
                        if not self.b.suscribir_vivo(par, velas):
                            self.vivo_pend.pop(par, None)
                    except Exception:
                        self.vivo_pend.pop(par, None)
            elif hist[-1]["t"] < prox - 2 * tf * 60:
                nuevas = self.b.velas(par, tf, 4)
                por_t = {v["t"]: v for v in hist}
                for v in nuevas: por_t[v["t"]] = v
                self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
            vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
            self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
        except Exception as e:
            self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)
        return True

    # ---------- filtro del autor: volatilidad (cada señal se graba para medirla) ----------
    def filtros_autor(self):
        return bool(self.autor)

    @staticmethod
    def volatilidad(cerradas):
        """Tamaño de las últimas 3 velas comparado con lo normal del par (mediana de las 50 anteriores). 1 = normal."""
        rangos = [v["h"] - v["l"] for v in cerradas[-53:]]
        if len(rangos) < 20:
            return None
        base = sorted(rangos[:-3])[len(rangos[:-3]) // 2]
        if base <= 0:
            return None
        return (sum(rangos[-3:]) / 3) / base

    def filtrar_autor(self, par, tf, d, cerradas, precio, expira, origen):
        """Devuelve (pasa, motivo). Graba cada señal, entre o no, para medir después si los filtros ayudan."""
        if not self.filtros_autor():
            return True, ""
        vol = self.volatilidad(cerradas)
        motivo = f"mercado agitado (velas {vol:.1f}× lo normal)" if vol is not None and vol > VOL_MAXIMA else ""
        self.grabar_senal(par, tf, d, cerradas, precio, expira, origen, vol=vol, pasa=not motivo)
        return (not motivo), motivo

    def grabar_senal(self, par, tf, d, cerradas, precio, expira, origen, prob=None, vol=None, pasa=True):
        """Anota la señal (una vez) para ver después cómo terminó el precio: así se mide si los filtros sirven."""
        if not self.filtros_autor():
            return
        clave = (par, tf, int(expira))
        if clave in self.animo_grabadas:
            return
        self.animo_grabadas[clave] = True
        if vol is None:
            vol = self.volatilidad(cerradas)
        if vol is not None and vol > VOL_MAXIMA:
            pasa = False
        self.animo_pend.append({"t": int(self.b.ahora()), "par": par, "tf": tf, "dir": d, "origen": origen, "vol": vol,
                                "prob": prob, "pasa": pasa, "precio": precio, "expira": int(expira)})
        if len(self.animo_grabadas) > 5000:
            self.animo_grabadas.clear()

    def hilo_animo(self):
        """Cuando vence cada señal grabada, mira cómo terminó el precio y lo guarda en senales_datos.csv."""
        ruta = os.path.join(os.path.dirname(os.path.abspath(LOG_FILE)), "senales_datos.csv")
        while not self.detener and not self.terminado:
            time.sleep(3)
            if not self.animo_pend:
                continue
            try:
                ahora = self.b.ahora()
                listas = [r for r in self.animo_pend if ahora >= r["expira"] + 2]
                if not listas:
                    continue
                filas = []
                for r in listas:
                    self.animo_pend.remove(r)
                    m1 = {v["t"]: v for v in (self.b.velas_vivo(r["par"]) or [])}
                    v = m1.get(r["expira"] - 60)
                    if v is None:
                        continue
                    fin = float(v["c"])
                    res = "empate" if fin == r["precio"] else (
                        "gana" if (fin > r["precio"]) == (r["dir"] == "call") else "pierde")
                    filas.append([datetime.fromtimestamp(r["t"]).strftime("%Y-%m-%d %H:%M:%S"), r["par"],
                                  "OTC" if r["par"].endswith("-OTC") else "real", f"M{r['tf']}", r["dir"], r["origen"],
                                  "" if r["vol"] is None else round(r["vol"], 2),
                                  "" if r.get("prob") is None else round(r["prob"] * 100, 1),
                                  "si" if r["pasa"] else "no", r["precio"], fin, res])
                if filas:
                    if os.path.exists(ruta):                        # archivo de una versión anterior (otras columnas):
                        with open(ruta, encoding="utf-8") as f:     # se guarda aparte y se empieza uno nuevo
                            cab = f.readline()
                        if "prob_ia" not in cab:
                            viejo = ruta.replace(".csv", "_viejo.csv")
                            if os.path.exists(viejo):
                                viejo = ruta.replace(".csv", f"_viejo_{int(time.time())}.csv")
                            os.replace(ruta, viejo)
                    nuevo = not os.path.exists(ruta)
                    with open(ruta, "a", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        if nuevo:
                            w.writerow(["fecha", "par", "mercado", "tf", "direccion", "estrategia", "volatilidad", "prob_ia", "pasa_filtro", "precio_entrada", "precio_vence", "resultado"])
                        w.writerows(filas)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] senales\n{traceback.format_exc()}")

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def al_estirarse(self):
        """Entrada "al estirarse" (solo Bollinger; para todos)."""
        return self.cfg.get("estrategia", "bollinger") == "bollinger" and self.cfg.get("entrada") == "estirado"

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        if self.al_estirarse():
            return cands, revisados             # "al estirarse": solo entra a mitad de vela (hilo_estirado)
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                if cfg.get("estrategia") == "ia":
                    d, det = self.ia_analizar(par, tf, cerradas, actual, pago, prox, inst)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg)
                    if self.ia is not None:
                        d, det = self.ia_filtrar(par, tf, cerradas, actual, pago, prox, d, det, inst)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                pasa, motivo = self.filtrar_autor(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, cfg.get("estrategia"))
                if not pasa:
                    self.estado(par, f"M{tf}: señal {d.upper()}, pero {motivo}", "dim", 3); continue
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre, "detalle": det,
                              "ev": self.ia_ev.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "prob": self.ia_prob.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def hilo_estirado(self):
        """Bot Bollinger 'al estirarse': durante la vela mira el precio cada segundo. Si el precio sale de la banda
        y se estira lo pedido, entra YA (mejor precio = margen por si se devuelve) y vence al cierre de la vela
        siguiente, a la misma hora que la entrada normal (máximo 5 minutos, lo que permite el broker)."""
        while not self.detener and not self.terminado:
            time.sleep(1.0)
            try:
                if not self.al_estirarse():
                    time.sleep(4); continue
                if not self.b.conectado or self.pausado or self.plan or self.abiertas or self.pares_en_uso:
                    continue                                   # una operación a la vez
                if self.frenar_por_stop():
                    continue
                ahora = self.b.ahora()
                self.entrar_estirado(ahora)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] estirado\n{traceback.format_exc()}")

    def entrar_estirado(self, ahora):
        cfg = self.cfg
        mejores = []
        for par in list(self.seleccion):
            if par in self.pares_en_uso or not self.b.vivo.get(par):
                continue
            if self.descanso.get(par, 0) > time.time():
                continue
            if self.nivel > 0 and par == self.par_perdio:
                continue                                       # el nivel va en otro par
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            pays = self.pares.get(par, {}).get("pays", {})
            ok_m = cfg["incluir_otc"] if par.endswith("-OTC") else cfg["incluir_mercado_real"]
            pago = pays.get("turbo") if ok_m else None
            if pago is None or pago < cfg["payout_minimo"]:
                continue
            for tf in self.tfs:
                inicio = int(ahora) // (tf * 60) * tf * 60
                cierre = inicio + tf * 60
                if cierre - ahora < 2.0 or ahora - inicio < 1.0:
                    continue                                   # pegado al cierre: lo resuelve el ciclo normal
                if (par, tf, inicio) in self.estirado_hecho:
                    continue
                partes = [v for v in m1 if inicio <= v["t"] < cierre]
                if not partes:
                    continue
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get((par, 1), [])}
                    for v in m1:
                        if v["t"] < inicio: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)]
                else:
                    cerradas = [v for v in self.hist.get((par, tf), []) if v["t"] < inicio]
                    if cerradas and cerradas[-1]["t"] == inicio - 2 * tf * 60:
                        ult = self.vela_en_formacion(m1, tf, inicio)     # la vela que acaba de cerrar, con las M1 en vivo
                        if ult:
                            cerradas = cerradas + [ult]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    continue
                d, det = senal([v["c"] for v in cerradas] + [partes[-1]["c"]], cfg, float(cfg.get("estiro", 20) or 0))
                if d:
                    exp = cierre + tf * 60
                    while exp - ahora > 300:
                        exp -= 60
                    pasa, motivo = self.filtrar_autor(par, tf, d, cerradas + [{"h": max(v["h"] for v in partes), "l": min(v["l"] for v in partes)}],
                                                      partes[-1]["c"], exp, "bollinger estirado")
                    if not pasa:
                        self.estado(par, f"M{tf}: señal {d.upper()}, pero {motivo}", "dim", 3); continue
                    mejores.append((pago, par, tf, inicio, cierre, d, det))
        if not mejores:
            return
        mejores.sort(reverse=True)                             # primero el que más paga
        pago, par, tf, inicio, cierre, d, det = mejores[0]
        expira = cierre + tf * 60
        while expira - ahora > 300:
            expira -= 60                                       # el broker no deja más de 5 minutos
        nivel, ciclo = self.nivel, self.ciclo_perdida
        if nivel > int(cfg["rec_max"]) or cfg["recuperacion"] == "ninguna":
            nivel, ciclo = 0, 0.0
        monto = self.monto_recuperacion(nivel, ciclo, pago)
        if nivel > 0 and not self.puede_arriesgar(monto):
            if not self.puede_arriesgar(self.monto_recuperacion(0, 0.0, pago)):
                return
            self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                     f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
            with self.lock:
                self.nivel, self.ciclo_perdida = 0, 0.0
                self.ciclo_n += 1
            nivel, ciclo = 0, 0.0
            monto = self.monto_recuperacion(0, 0.0, pago)
        if not self.puede_arriesgar(monto):
            return
        self.estirado_hecho.add((par, tf, inicio))
        if len(self.estirado_hecho) > 5000:
            self.estirado_hecho = {k for k in self.estirado_hecho if k[2] > ahora - 3600}
        s = {"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre_estrategia(cfg, True), "inst": "turbo", "inicio_vela": cierre, "disparo": None, "detalle": det,
             "expira": expira, "exp_min": max(1, int(round((expira - ahora) / 60))), "monto": monto,
             "etiqueta": f"NIVEL {nivel}" if nivel else "ENTRADA", "ciclo_n": self.ciclo_n,
             "nivel_usado": nivel, "ciclo_antes": ciclo}
        self.estado(par, f"SEÑAL {d.upper()} M{tf} al estirarse · {det}", "bold green" if d == "call" else "bold red", 1)
        self.lanzar(s)



    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # entre las señales del mismo momento (todas ya pasaron el mínimo de 80 %), primero la que MÁS PAGA;
        # si pagan igual, la que la IA ve mejor
        if self.ia_exigencia()[0] and self.cfg.get("estrategia") == "ia":
            # modo "señal más segura": primero la que la IA ve más probable de ganar; el payout solo desempata
            cands = sorted(cands, key=lambda c: (c.get("prob") or 0.0, round(c.get("payout") or 0.0, 3)), reverse=True)
        else:
            cands = sorted(cands, key=lambda c: (round(c.get("payout") or 0.0, 3), c.get("ev") if c.get("ev") is not None else -9.0), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        if self.frenar_por_stop() or self.pausado:
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            elegida = otros[0] if otros else None
            etiqueta = f"NIVEL {nivel}"
        else:
            elegida = lista[0] if lista else None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        self.lanzar(elegida)

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.avisar_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_estirado, self.hilo_animo):
            threading.Thread(target=objetivo, daemon=True).start()
        if self.autor or (self.ia_cliente and self.cfg.get("estrategia") == "ia"):
            threading.Thread(target=self.hilo_ia, daemon=True).start()      # autor: aprende siempre · cliente: solo con IA

    # ---------- IA del autor (refuerzo en línea) ----------
    def ia_segundos(self):
        """(segundos desde el último cierre, segundos hasta el próximo) de la temporalidad elegida."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return t, per - t

    def ia_sin_operar(self):
        """Mientras la IA entrena con estrategia IA, el bot no opera: puede descargar y aprender a toda velocidad."""
        return self.cfg.get("estrategia") == "ia" and getattr(self, "ia_entrenando", False)

    def ia_esperar_ventana(self, margen=8):
        """La IA solo trabaja lejos del cierre: nunca le quita tiempo al análisis ni a las órdenes.
        Si el bot no está operando (IA entrenando), no espera nada."""
        if self.ia_sin_operar():
            return
        while not self.terminado:
            desde, hasta = self.ia_segundos()
            if desde > 5 and hasta > margen:
                return
            time.sleep(0.4)

    @staticmethod
    def ia_recompensas(mov, pago):
        """(premio CALL, premio PUT) por dólar según cómo se movió la vela operada."""
        if mov > 0:
            return pago, -1.0
        if mov < 0:
            return -1.0, pago
        return 0.0, 0.0

    def ia_pago(self, par):
        pays = (self.pares.get(par, {}) or {}).get("pays") or {}
        vals = [v for v in pays.values() if isinstance(v, (int, float)) and v > 0]
        return max(vals) if vals else 0.85

    def ia_descargar(self, par, carpeta):
        """Hasta 20.000 velas M1 del par. Se guardan en ia_velas: solo se baja lo que falta (lo nuevo y lo más viejo)."""
        ruta = os.path.join(carpeta, "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in par) + ".csv")
        velas = {}
        try:
            with open(ruta, encoding="utf-8") as fh:
                for ln in fh:
                    t, o, h, l, c = ln.strip().split(",")
                    velas[int(float(t))] = {"t": int(float(t)), "o": float(o), "h": float(h), "l": float(l), "c": float(c)}
        except Exception:
            velas = {}
        limpias = ia_limpiar_velas(velas)                  # velas de otro activo guardadas por el error viejo
        n0 = len(velas) + (1 if limpias else 0)            # si se limpió algo, el archivo se vuelve a guardar

        def bajar(hasta, falta):
            while falta > 0 and not self.terminado:
                self.ia_esperar_ventana(15)
                bloque = self.b.velas_hasta_t(par, min(1000, falta), hasta)
                if not bloque:
                    return False
                nuevas = 0
                for v in bloque:
                    if int(v["t"]) not in velas:
                        nuevas += 1
                    velas[int(v["t"])] = {"t": int(v["t"]), "o": v["o"], "h": v["h"], "l": v["l"], "c": v["c"]}
                falta -= len(bloque)
                hasta = bloque[0]["t"] - 1
                time.sleep(0.08 if self.ia_sin_operar() else 0.25)
                if nuevas == 0:
                    return False
            return True

        ahora = self.b.ahora()
        if velas:
            ult = max(velas)
            if ahora - ult > 120:                                   # lo nuevo desde la última vez
                bajar(ahora, min(IA_VELAS_DESCARGA, int((ahora - ult) / 60) + 5))
            if len(velas) < IA_VELAS_DESCARGA * 0.95:               # lo más viejo, hasta completar
                bajar(min(velas) - 1, IA_VELAS_DESCARGA - len(velas))
        else:
            bajar(ahora, IA_VELAS_DESCARGA)
        if len(velas) != n0:
            lista = [velas[t] for t in sorted(velas)][-(IA_VELAS_DESCARGA + 1000):]
            try:
                with open(ruta, "w", encoding="utf-8") as fh:
                    fh.write("".join(f"{v['t']},{v['o']},{v['h']},{v['l']},{v['c']}\n" for v in lista))
            except Exception:
                pass
        return [velas[t] for t in sorted(velas)][-IA_VELAS_DESCARGA:]

    def ia_preentrenar(self, tf=None):
        """Entrenamiento con el historial de una temporalidad: baja hasta 20.000 velas M1 de cada par y aprende."""
        self.ia_entrenando = True                 # con estrategia IA: no opera hasta terminar (descarga rápida)
        try:
            return self._ia_preentrenar(tf)
        finally:
            self.ia_entrenando = False

    def _ia_preentrenar(self, tf=None):
        ia = self.ia
        carpeta = os.path.join(DATOS_BROKER, IA_CARPETA_VELAS)
        os.makedirs(carpeta, exist_ok=True)
        ia.fase = "Esperando la lista de pares"
        while not self.terminado and not self.seleccion:
            time.sleep(2)
        tf = tf or (self.tfs[0] if self.tfs else 1)
        pares = list(self.seleccion)
        self.log(f"🤖 IA: entrenamiento M{tf} con hasta {IA_VELAS_DESCARGA:,} velas M1 de {len(pares)} pares (en segundo plano).", "bold")
        ejemplos = 0
        velas_max = 0
        for i, par in enumerate(pares):
            if self.terminado:
                return
            ia.fase = f"M{tf}: descargando y aprendiendo {i + 1}/{len(pares)}"
            try:
                m1 = self.ia_descargar(par, carpeta)
                velas_max = max(velas_max, len(m1))
                velas = ia_agrupar(m1, tf)
            except Exception:
                continue
            pago = self.ia_pago(par)
            for j in range(60, len(velas) - 1):
                if j % 150 == 0:
                    self.ia_esperar_ventana()
                    if self.terminado:
                        return
                if velas[j + 1]["t"] - velas[j]["t"] != tf * 60:
                    continue
                tramo = velas[j - 59 if j >= 59 else 0: j + 1]
                t_ = velas[j]["t"] + tf * 60
                x = ia_rasgos(tramo, par, pago, t_, tf, False, ia.propio(par, t_))
                if x is None:
                    continue
                mov = velas[j + 1]["c"] - velas[j]["c"]
                q_ = ia.q(x)
                k_ = 0 if q_[0] >= q_[1] else 1
                if q_[k_] >= IA_UMBRAL and mov != 0:           # su propio historial, como en vivo
                    ia.registrar(par, t_, (mov > 0) == (k_ == 0))
                rc, rp = self.ia_recompensas(mov, pago)
                ia.aprender(x, rc, rp)
                ejemplos += 1
        ia.preentreno = True
        if tf not in ia.tfs_entrenadas:
            ia.tfs_entrenadas.append(tf)
        ia.velas_tf[tf] = velas_max or ia.velas_tf.get(tf, 0)
        if tf not in ia.hist_hecho:
            ia.hist_hecho.append(tf)           # hecho hasta donde el bróker deja: no se repite en cada inicio
        ia.fase = "Aprendiendo en vivo"
        ia.guardar()
        self.log(f"🤖 IA: entrenamiento M{tf} listo ({ejemplos:,} ejemplos). Sigue aprendiendo en vivo.", "bold")

    def hilo_ia(self):
        try:
            self.ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
        except Exception as e:
            self.log(f"🤖 IA: no se pudo iniciar ({e}).", "red")
            return
        ia = self.ia
        estado = "opera" if ia.activa else "modo sombra"
        self.log(f"🤖 IA lista ({estado} · {ia.aprendidas:,} ejemplos aprendidos).", "bold")
        for tf_ in list(self.tfs):                       # cada temporalidad: entrenamiento con el historial (una vez)
            if self.cfg.get("estrategia") != "ia":       # con Bollinger/RSI no se hace: no le quita fuerza al bot
                break
            if tf_ in ia.hist_hecho or self.terminado:
                continue
            try:
                self.ia_preentrenar(tf_)
            except Exception as e:
                self.log(f"🤖 IA: el primer entrenamiento M{tf_} se cortó ({str(e)[:60]}); sigue aprendiendo en vivo.", "yellow")
        ia.fase = "Aprendiendo en vivo"
        rnd = __import__("random").Random()
        guardado = time.time()
        while not self.terminado:
            hechos = 0
            while self.ia_cola and hechos < 300:
                desde, hasta = self.ia_segundos()
                if hasta < 8 or desde < 4:
                    break
                x, rc, rp = self.ia_cola.popleft()
                ia.aprender(x, rc, rp)
                self.ia_repaso.append((x, rc, rp))
                if len(self.ia_repaso) > 200:                 # repasa una experiencia vieja al azar
                    ia.aprender(*self.ia_repaso[rnd.randrange(len(self.ia_repaso))])
                hechos += 1
            if time.time() - guardado > 300:
                try: ia.guardar()
                except Exception: pass
                guardado = time.time()
            time.sleep(0.2 if hechos else 1.0)
        try: ia.guardar()
        except Exception: pass

    def ia_procesar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """En cada cierre: resuelve lo pendiente (aprende de lo que pasó) y da la opinión de la IA.
        Devuelve (dirección de la IA o None, lo que espera ganar, [espera con CALL, espera con PUT])."""
        ia = self.ia
        pago = pago or self.ia_pago(par)
        pend = self.ia_pend.setdefault((par, tf), deque(maxlen=3))
        if pend:
            por_t = {v["t"]: v for v in cerradas[-4:]}
            for p_ in list(pend):
                v = por_t.get(p_["t_op"])
                if v is None:
                    continue
                pend.remove(p_)
                mov = v["c"] - p_["precio"]
                self.ia_cola.append((p_["x"],) + self.ia_recompensas(mov, p_["pago"]))
                if p_["d"] and mov != 0:
                    ia.registrar(par, p_["t_op"], (mov > 0) == (p_["d"] == "call"))
                m_ = ia.mejor.get(p_["t_op"])
                if p_["d"] and mov != 0 and m_ and m_[1] == par and m_[2] == tf:     # una sola por minuto
                    cambio = ia.anotar_senal((mov > 0) == (p_["d"] == "call"), p_["t_op"])
                    r = ia.resumen()
                    if cambio == "activa":
                        self.log(f"🤖 IA: acierto real {r['acierto']} % en {r['senales']} señales y {r['horas']:.1f} h "
                                 f"(necesitaba {r['necesita']} %) → "
                                 + ("EMPIEZA A OPERAR." if self.cfg.get("estrategia") == "ia" else "ya podría operar con la estrategia IA."), "bold green")
                    elif cambio == "sombra":
                        self.log(f"🤖 IA: el acierto bajó a {r['acierto']} % → vuelve a modo sombra.", "bold yellow")
        x = ia_rasgos(cerradas[-59:] + [actual], par, pago, prox, tf, inst == "digital", ia.propio(par, prox))
        if x is None:
            return None, 0.0, None
        q = ia.q(x)
        k = 0 if q[0] >= q[1] else 1
        d = ("call" if k == 0 else "put") if q[k] >= IA_UMBRAL else None
        ia.mirar(prox, q[k], d)
        if d:
            with ia.lock:
                if q[k] > ia.mejor.get(prox, (-9.0,))[0]:
                    ia.mejor[prox] = (q[k], par, tf)
                if len(ia.mejor) > 30:
                    for k_ in sorted(ia.mejor)[:-10]:
                        ia.mejor.pop(k_, None)
        pend.append({"x": x, "precio": actual["c"], "t_op": prox, "pago": pago, "d": d})
        return d, q[k], q

    def ia_analizar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """Estrategia IA: la decisión es de la IA. En modo sombra no opera."""
        if self.ia is None:
            return None, ""
        d, ev, _ = self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        self.ia_ev[(par, tf)] = ev
        if not d:
            return None, ""
        prob = ia_probabilidad(ev, pago)                          # qué tan probable cree que gane (sin el payout)
        self.ia_prob[(par, tf)] = prob
        segura, minimo = self.ia_exigencia()
        self.grabar_senal(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, "ia",
                          prob=prob, pasa=(prob >= minimo) if segura else True)
        det = f"IA {prob * 100:.0f}% de acierto"
        if not self.autor and not ia_permitida():                        # el autor le quitó la IA a este cliente
            self.estado(par, "IA no habilitada para esta licencia", "dim", 3)
            return None, ""
        forzar = bool(self.cfg.get("ia_forzar")) and (self.autor or self.ia_cliente)   # opera sin el umbral
        if getattr(self, "ia_entrenando", False) or not (self.ia.activa or forzar):     # entrenando o en sombra: no opera
            self.estado(par, f"IA (sombra) {d.upper()} M{tf} · {det}", "yellow", 2)
            return None, ""
        if segura and prob < minimo:                              # no es de las seguras: espera otra (entrada o nivel)
            self.estado(par, f"IA {d.upper()} M{tf} · {prob * 100:.0f}%: espera una más segura ({minimo * 100:.0f}%)", "dim", 3)
            return None, ""
        return d, det

    def ia_exigencia(self):
        """(¿solo la señal más segura?, mínimo de acierto). Autor: lo que elija. Clientes con IA: siempre 60 %."""
        if self.autor:
            return self.cfg.get("ia_modo") == "segura", ia_minimo(self.cfg)
        return bool(self.ia_cliente), IA_PROB_CLIENTES

    def ia_filtrar(self, par, tf, cerradas, actual, pago, prox, d, det, inst=None):
        """Bollinger/RSI del autor: la IA solo aprende en segundo plano. NO decide ni bloquea ninguna señal."""
        try:
            self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        except Exception:
            pass
        return d, det

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bollinger")},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "ia": (dict(self.ia.resumen(), forzar=bool(cfg.get("ia_forzar")) and self.autor) if self.autor
                   else self.ia.resumen_cliente()) if self.ia else None,
            "ia_cliente": self.ia_cliente,
        }

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        ent_g = ent_p = niv_g = niv_p = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                niv_g += neto > 0; niv_p += neto < 0
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                ent_g += neto > 0; ent_p += neto < 0
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor,
                "ent_g": ent_g, "ent_p": ent_p, "niv_g": niv_g, "niv_p": niv_p}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            if int(guardado.get("config_v", 0) or 0) < 6:
                # M1 ya no se opera: quien estaba en M1 pasa a M2
                tfs = [int(t) for t in (guardado.get("temporalidades") or []) if int(t) in (2, 3, 4, 5)]
                guardado["temporalidades"] = tfs[:1] or [2]
                guardado["config_v"] = 6
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = False                       # ya no hay temporalidad Auto
    cfg.pop("tfs_auto", None)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    if cfg.get("estrategia") not in ("bollinger", "rsi", "ia", "bbrsi"):
        cfg["estrategia"] = "bollinger"
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

