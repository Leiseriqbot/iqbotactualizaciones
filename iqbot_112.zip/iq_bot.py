# -*- coding: utf-8 -*-
"""
IQ BOT ESCANER  -  Opciones binarias / turbo en IQ Option
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras monto, temporalidades, recuperación, stops y estrategias.
  5) Confirmas y arranca.

Qué hace:
- Escanea todos los pares abiertos (mercado real y OTC) en M1, M2, M5 y M15.
- Cataloga cada estrategia en cada par y elige la mejor por valor esperado.
- Varias operaciones al mismo tiempo (nunca dos en el mismo par).
- Recuperación: ninguna, martingala o niveles. Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, random, threading, csv, getpass, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.
DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"
VERSION_BOT = "1.12"
BUILD_BOT = 112
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [1, 5, 15],    # minutos: 1=M1, 5=M5, 15=M15
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 25,                 # cuántos pares analizar (los de mejor payout)
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "martingala",    # "ninguna", "martingala", "niveles" o "auto" (la IA elige por par)
    "rec_max": 2,                    # máximo de gales (martingala) o de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por gale/nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "velas_catalogo": 300,           # velas del historial para catalogar (fijo, ya no se muestra)
    "min_senales_catalogo": 10,      # mínimo de señales históricas para confiar
    "winrate_minimo": 0.75,          # % de acierto mínimo de la estrategia en ese par (catalogación)
    "ev_minimo": 0.05,               # valor esperado mínimo por $1 (0.05 = +5 %)
    "confluencia_minima": 1,         # nº de estrategias que deben coincidir
    "solo_velas_fuertes": True,      # solo entra si la vela de la señal tiene cuerpo fuerte (sin mechas largas ni doji)
    "estrategias_auto": True,
    "ia_filtra": True,               # True: las IAs bloquean señales flojas · False: solo ordenan (operas cada minuto)
    "ia_precision_alta": False,      # True: la Juez exige más (menos operaciones, más acierto)        # en cada par se activan solas las estrategias que superan el acierto mínimo
    "estrategias_activas": "todas",  # "todas" o lista de nombres (si no es automático)
    "filtros_v": 3,
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    rich_ok = importlib.util.find_spec("rich") is not None
    if not falta_iq and ws_ok and req_ok and rich_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if not rich_ok and not _pip(["rich"]):
        raise SystemExit("No se pudo instalar 'rich' (la pantalla del bot). Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def reiniciar_bot():
    """Vuelve a abrir el bot en esta misma ventana (por ejemplo, tras actualizar la librería)."""
    print("\nReiniciando el bot...\n")
    env = dict(os.environ, IQBOT_REINICIADO="1")
    comando = [sys.executable] + (sys.argv[1:] if CONGELADO else sys.argv)
    codigo = subprocess.call(comando, env=env)
    os._exit(codigo)

def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

# =====================================================================
#  INDICADORES (Python puro, sin dependencias)
# =====================================================================

def ema(vals, n):
    if len(vals) < n:
        return None
    k = 2 / (n + 1)
    e = sum(vals[:n]) / n
    for v in vals[n:]:
        e = v * k + e * (1 - k)
    return e

def ema_series(vals, n):
    out = [None] * len(vals)
    if len(vals) < n:
        return out
    k = 2 / (n + 1)
    e = sum(vals[:n]) / n
    out[n - 1] = e
    for i in range(n, len(vals)):
        e = vals[i] * k + e * (1 - k)
        out[i] = e
    return out

def rsi(closes, n=14):
    if len(closes) < n + 1:
        return None
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0); losses += max(-d, 0)
    ag, al = gains / n, losses / n
    for i in range(n + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (n - 1) + max(d, 0)) / n
        al = (al * (n - 1) + max(-d, 0)) / n
    if al == 0:
        return 100.0
    return 100 - 100 / (1 + ag / al)

def bollinger(closes, n=20, k=2.0):
    if len(closes) < n:
        return None
    w = closes[-n:]
    m = sum(w) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in w) / n)
    return m - k * sd, m, m + k * sd

def estocastico(c, n=14, d=3):
    if len(c) < n + d:
        return None
    ks = []
    for j in range(d + 1):
        idx = len(c) - 1 - j
        w = c[idx - n + 1: idx + 1]
        hh = max(x["h"] for x in w); ll = min(x["l"] for x in w)
        ks.append(50.0 if hh == ll else 100 * (w[-1]["c"] - ll) / (hh - ll))
    ks.reverse()  # antiguo -> reciente
    k_now, k_prev = ks[-1], ks[-2]
    d_now = sum(ks[-d:]) / d
    d_prev = sum(ks[-d - 1:-1]) / d
    return k_prev, d_prev, k_now, d_now

def color(v):
    if v["c"] > v["o"]: return 1
    if v["c"] < v["o"]: return -1
    return 0

# =====================================================================
#  ESTRATEGIAS
#  Cada una recibe la lista de velas CERRADAS (más antigua -> más reciente)
#  y devuelve "call", "put" o None para la vela siguiente.
# =====================================================================

def st_mhi(c):
    """Minoría de las 3 últimas velas, en cualquier vela (versión continua, sin cuadrante)."""
    cols = [color(v) for v in c[-3:]]
    if 0 in cols: return None
    return "call" if cols.count(1) < cols.count(-1) else "put"

def st_mayoria(c):
    """Mayoría de las 3 últimas velas, en cualquier vela (versión continua, sin cuadrante)."""
    cols = [color(v) for v in c[-3:]]
    if 0 in cols: return None
    return "call" if cols.count(1) > cols.count(-1) else "put"

def st_rsi(c):
    """RSI 14 en zona extrema y la última vela ya gira."""
    cl = [v["c"] for v in c]
    r = rsi(cl, 14)
    if r is None: return None
    if r < 30 and color(c[-1]) == 1: return "call"
    if r > 70 and color(c[-1]) == -1: return "put"
    return None

def st_bollinger(c):
    """Toque de banda de Bollinger con rechazo (cierre de vuelta dentro)."""
    cl = [v["c"] for v in c]
    b = bollinger(cl, 20, 2.0)
    if not b: return None
    lo, _, up = b
    v = c[-1]
    if v["l"] < lo and v["c"] > lo: return "call"
    if v["h"] > up and v["c"] < up: return "put"
    return None

def st_cruce_ema(c):
    """Cruce de EMA 9 sobre EMA 21 en la última vela."""
    cl = [v["c"] for v in c]
    f = ema_series(cl, 9); s = ema_series(cl, 21)
    if None in (f[-1], f[-2], s[-1], s[-2]): return None
    if f[-2] <= s[-2] and f[-1] > s[-1]: return "call"
    if f[-2] >= s[-2] and f[-1] < s[-1]: return "put"
    return None

def st_envolvente(c):
    """Vela envolvente tras al menos 2 velas en sentido contrario."""
    a, b = c[-2], c[-1]
    if color(c[-3]) == -1 and color(a) == -1 and color(b) == 1 and b["c"] > a["o"] and b["o"] <= a["c"]:
        return "call"
    if color(c[-3]) == 1 and color(a) == 1 and color(b) == -1 and b["c"] < a["o"] and b["o"] >= a["c"]:
        return "put"
    return None

def st_pinbar(c):
    """Martillo / estrella fugaz: mecha >= 2x cuerpo en extremo de 10 velas."""
    v = c[-1]
    cuerpo = abs(v["c"] - v["o"]); rango = v["h"] - v["l"]
    if rango == 0: return None
    cuerpo = max(cuerpo, rango * 0.05)
    mecha_inf = min(v["o"], v["c"]) - v["l"]
    mecha_sup = v["h"] - max(v["o"], v["c"])
    w = c[-10:]
    if mecha_inf >= 2 * cuerpo and mecha_sup < cuerpo and v["l"] <= min(x["l"] for x in w):
        return "call"
    if mecha_sup >= 2 * cuerpo and mecha_inf < cuerpo and v["h"] >= max(x["h"] for x in w):
        return "put"
    return None

def st_tres_soldados(c):
    """Tres soldados / tres cuervos con cierres progresivos (continuación)."""
    w = c[-3:]
    if all(color(v) == 1 for v in w) and w[0]["c"] < w[1]["c"] < w[2]["c"]: return "call"
    if all(color(v) == -1 for v in w) and w[0]["c"] > w[1]["c"] > w[2]["c"]: return "put"
    return None

def st_estocastico(c):
    """Cruce %K/%D del estocástico en sobreventa / sobrecompra."""
    s = estocastico(c, 14, 3)
    if not s: return None
    kp, dp, k, d = s
    if kp <= dp and k > d and k < 25: return "call"
    if kp >= dp and k < d and k > 75: return "put"
    return None

def st_pullback_ema(c):
    """Tendencia por EMA 50 y retroceso que toca la EMA 9 y cierra a favor."""
    cl = [v["c"] for v in c]
    e50 = ema(cl, 50); e9 = ema(cl, 9)
    if e50 is None or e9 is None: return None
    v = c[-1]
    if v["c"] > e50 and e9 > e50 and v["l"] <= e9 <= v["c"] and color(v) == 1: return "call"
    if v["c"] < e50 and e9 < e50 and v["h"] >= e9 >= v["c"] and color(v) == -1: return "put"
    return None

def _williams(c, n=14, idx=-1):
    w = c[len(c) + idx - n + 1: len(c) + idx + 1] if idx != -1 else c[-n:]
    if len(w) < n: return None
    hh = max(x["h"] for x in w); ll = min(x["l"] for x in w)
    return -50.0 if hh == ll else -100 * (hh - w[-1]["c"]) / (hh - ll)

def st_williams(c):
    """Williams %R 14: sale de sobreventa (-80) o de sobrecompra (-20) en la última vela."""
    if len(c) < 16: return None
    prev, now = _williams(c[:-1]), _williams(c)
    if prev is None or now is None: return None
    if prev <= -80 and now > -80: return "call"
    if prev >= -20 and now < -20: return "put"
    return None

def _cci(c, n=20):
    if len(c) < n: return None
    tp = [(x["h"] + x["l"] + x["c"]) / 3 for x in c[-n:]]
    m = sum(tp) / n
    md = sum(abs(t - m) for t in tp) / n
    return 0.0 if md == 0 else (tp[-1] - m) / (0.015 * md)

def st_cci(c):
    """CCI 20: vuelve desde fuera de ±100 (agotamiento del movimiento)."""
    if len(c) < 22: return None
    prev, now = _cci(c[:-1]), _cci(c)
    if prev is None or now is None: return None
    if prev < -100 and now > -100: return "call"
    if prev > 100 and now < 100: return "put"
    return None

def st_macd(c):
    """Cruce de la línea MACD (12, 26) con su señal (9) en la última vela."""
    cl = [v["c"] for v in c]
    if len(cl) < 40: return None
    e12, e26 = ema_series(cl, 12), ema_series(cl, 26)
    macd = [a - b for a, b in zip(e12, e26) if a is not None and b is not None]
    if len(macd) < 12: return None
    sig = ema_series(macd, 9)
    if None in (sig[-1], sig[-2]): return None
    if macd[-2] <= sig[-2] and macd[-1] > sig[-1]: return "call"
    if macd[-2] >= sig[-2] and macd[-1] < sig[-1]: return "put"
    return None

def st_agotamiento(c):
    """Agotamiento: 4 velas seguidas del mismo color y la última más chica que la anterior -> reversión."""
    w = c[-4:]
    cols = [color(v) for v in w]
    if 0 in cols or len(set(cols)) != 1: return None
    if abs(w[-1]["c"] - w[-1]["o"]) >= abs(w[-2]["c"] - w[-2]["o"]): return None
    return "put" if cols[0] == 1 else "call"

def st_vela_fuerza(c):
    """Vela de fuerza: cuerpo >= 2x el promedio de las 10 anteriores y cierre en su extremo -> continuación."""
    v = c[-1]; rango = v["h"] - v["l"]; cuerpo = abs(v["c"] - v["o"])
    if rango == 0 or len(c) < 11: return None
    prom = sum(abs(x["c"] - x["o"]) for x in c[-11:-1]) / 10
    if prom == 0 or cuerpo < 2 * prom: return None
    if color(v) == 1 and (v["h"] - v["c"]) <= 0.2 * rango: return "call"
    if color(v) == -1 and (v["c"] - v["l"]) <= 0.2 * rango: return "put"
    return None

# ---------- Niveles: soportes, resistencias y números redondos ----------

def _atr(c, n=14):
    w = c[-n:]
    return sum(v["h"] - v["l"] for v in w) / len(w) if w else 0.0

def _pivotes(c, desde, hasta, lado=2):
    """Techos y pisos locales (fractales) entre las velas [desde, hasta)."""
    altos, bajos = [], []
    for i in range(max(lado, desde), min(hasta, len(c) - lado)):
        h, l = c[i]["h"], c[i]["l"]
        if all(h >= c[j]["h"] for j in range(i - lado, i + lado + 1) if j != i):
            altos.append(h)
        if all(l <= c[j]["l"] for j in range(i - lado, i + lado + 1) if j != i):
            bajos.append(l)
    return altos, bajos

def _niveles(precios, tol, minimo=2):
    """Agrupa precios parecidos: devuelve los niveles tocados al menos `minimo` veces."""
    grupos = []
    for p in sorted(precios):
        if grupos and p - grupos[-1][-1] <= tol:
            grupos[-1].append(p)
        else:
            grupos.append([p])
    return [sum(g) / len(g) for g in grupos if len(g) >= minimo]

def st_rechazo_sr(c):
    """Rechazo en soporte/resistencia: el precio toca un nivel donde ya rebotó 2+ veces y deja una mecha
    de rechazo (mecha de al menos la mitad de la vela) -> entra a favor del rebote."""
    if len(c) < 50: return None
    v = c[-1]; rango = v["h"] - v["l"]
    atr = _atr(c)
    if rango <= 0 or atr <= 0: return None
    tol = 0.25 * atr
    altos, bajos = _pivotes(c, len(c) - 50, len(c) - 3)
    for s in _niveles(bajos, tol):
        mecha = min(v["o"], v["c"]) - v["l"]
        if v["l"] <= s + tol and v["c"] > s and mecha >= 0.5 * rango:
            return "call"
    for r in _niveles(altos, tol):
        mecha = v["h"] - max(v["o"], v["c"])
        if v["h"] >= r - tol and v["c"] < r and mecha >= 0.5 * rango:
            return "put"
    return None

def st_retesteo(c):
    """Retesteo de ruptura: el precio rompió un techo (o piso) en las últimas velas, vuelve a tocarlo
    y lo respeta -> entra a favor de la ruptura (el techo roto ahora es piso)."""
    if len(c) < 50: return None
    v = c[-1]; atr = _atr(c)
    if atr <= 0: return None
    tol = 0.25 * atr
    altos, bajos = _pivotes(c, len(c) - 50, len(c) - 12)
    recientes = c[-12:-1]
    for r in _niveles(altos, tol):
        rompio = any(x["c"] > r + tol for x in recientes)
        if rompio and v["l"] <= r + tol and v["c"] > r and color(v) == 1:
            return "call"
    for s in _niveles(bajos, tol):
        rompio = any(x["c"] < s - tol for x in recientes)
        if rompio and v["h"] >= s - tol and v["c"] < s and color(v) == -1:
            return "put"
    return None

def _paso_redondo(precio):
    """Distancia entre números redondos: 1.1000/1.1050 (paso 0.005), 180.0/180.5 (paso 0.5)…"""
    if precio <= 0: return None
    return 0.5 * 10 ** (math.floor(math.log10(precio)) - 2)

def st_numero_redondo(c):
    """Agotamiento en número redondo: 3 velas seguidas del mismo color llegan a un número redondo
    (ej. 1.1000, 1.1050, 180.00) -> reversión (los números redondos frenan el precio)."""
    if len(c) < 20: return None
    w = c[-3:]
    cols = [color(x) for x in w]
    if 0 in cols or len(set(cols)) != 1: return None
    v = c[-1]; paso = _paso_redondo(v["c"]); atr = _atr(c)
    if not paso or atr <= 0: return None
    tol = 0.15 * atr
    if cols[0] == 1:
        nivel = math.ceil((w[0]["o"]) / paso) * paso       # siguiente número redondo hacia arriba
        if v["h"] >= nivel - tol and v["c"] <= nivel + tol: return "put"
    else:
        nivel = math.floor((w[0]["o"]) / paso) * paso
        if v["l"] <= nivel + tol and v["c"] >= nivel - tol: return "call"
    return None

# ---------- Estrategias de CUADRANTE (velas de 1 minuto, cuadrantes de 5 velas: :00-:04, :05-:09...) ----------
# Posición de la vela dentro del cuadrante: 0 = 1a vela (minuto :00/:05), ... 4 = 5a vela.
# Con doji en las velas analizadas NO se opera. Solo dan señal en M1.

def _cuadrante(c):
    """Devuelve (posición de la vela de entrada 0-4, función color_en(pos, cuadrante)) o None."""
    if len(c) < 12 or c[-1]["t"] - c[-2]["t"] != 60:
        return None
    t_entrada = c[-1]["t"] + 60
    pos = (t_entrada // 60) % 5
    inicio_actual = t_entrada - pos * 60
    por_t = {v["t"]: v for v in c[-12:]}
    def color_en(p, cuad=0):
        """cuad 0 = cuadrante de la entrada, -1 = cuadrante anterior."""
        v = por_t.get(inicio_actual + cuad * 300 + p * 60)
        if v is None: return None
        col = color(v)
        return col if col != 0 else None   # doji = no operar
    return pos, color_en

def _dir(col):
    return "call" if col == 1 else "put"

def _minoria(cols):
    if None in cols: return None
    return _dir(1 if cols.count(1) < cols.count(-1) else -1)

def _mayoria(cols):
    if None in cols: return None
    return _dir(1 if cols.count(1) > cols.count(-1) else -1)

def _hacer_mhi(pos_entrada, tipo):
    def f(c):
        q = _cuadrante(c)
        if not q or q[0] != pos_entrada: return None
        _, col = q
        cols = [col(2, -1), col(3, -1), col(4, -1)]   # 3 últimas velas del cuadrante anterior
        return _minoria(cols) if tipo == "minoria" else _mayoria(cols)
    return f

st_mhi1 = _hacer_mhi(0, "minoria")
st_mhi1.__doc__ = "MHI 1: minoría de las 3 últimas velas del cuadrante anterior; entra en la 1a vela."
st_mhi2 = _hacer_mhi(1, "minoria")
st_mhi2.__doc__ = "MHI 2: igual que MHI 1, pero entra en la 2a vela del cuadrante."
st_mhi3 = _hacer_mhi(2, "minoria")
st_mhi3.__doc__ = "MHI 3: igual que MHI 1, pero entra en la 3a vela del cuadrante."
st_mhi_may1 = _hacer_mhi(0, "mayoria")
st_mhi_may1.__doc__ = "MHI Mayoría 1: mayoría de las 3 últimas velas; entra en la 1a vela."
st_mhi_may2 = _hacer_mhi(1, "mayoria")
st_mhi_may2.__doc__ = "MHI Mayoría 2: mayoría de las 3 últimas velas; entra en la 2a vela."
st_mhi_may3 = _hacer_mhi(2, "mayoria")
st_mhi_may3.__doc__ = "MHI Mayoría 3: mayoría de las 3 últimas velas; entra en la 3a vela."

def st_torres_gemelas(c):
    """Torres Gemelas: entra en la 5a vela con el color de la 1a vela del mismo cuadrante."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    v = q[1](0, 0)
    return _dir(v) if v else None

def st_tres_mosqueteros(c):
    """Tres Mosqueteros: entra en la 4a vela con el color de la 3a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 3: return None
    v = q[1](2, 0)
    return _dir(v) if v else None

def st_tres_vecinos(c):
    """Tres Vecinos: entra en la 5a vela con el color de la 4a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    v = q[1](3, 0)
    return _dir(v) if v else None

def st_padron_23(c):
    """Padrón 23: entra en la 2a vela con el color de la 1a vela del cuadrante."""
    q = _cuadrante(c)
    if not q or q[0] != 1: return None
    v = q[1](0, 0)
    return _dir(v) if v else None

def st_mejor_de_3(c):
    """Mejor de 3: mayoría de las 3 velas del centro (2a, 3a, 4a) del cuadrante anterior; entra en la 3a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 2: return None
    col = q[1]
    return _mayoria([col(1, -1), col(2, -1), col(3, -1)])

def st_patron_3x1(c):
    """Patrón 3x1: minoría de las 3 primeras velas del cuadrante; entra en la 5a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    col = q[1]
    return _minoria([col(0, 0), col(1, 0), col(2, 0)])


def _hacer_milhao(tipo):
    def f(c):
        q = _cuadrante(c)
        if not q or q[0] != 0: return None
        col = q[1]
        cols = [col(p, -1) for p in range(5)]          # las 5 velas del cuadrante anterior
        return _minoria(cols) if tipo == "minoria" else _mayoria(cols)
    return f

st_milhao_may = _hacer_milhao("mayoria")
st_milhao_may.__doc__ = "Milhão Maioria: mayoría de las 5 velas del cuadrante anterior; entra en la 1a vela del nuevo."
st_milhao_min = _hacer_milhao("minoria")
st_milhao_min.__doc__ = "Milhão Minoria: minoría de las 5 velas del cuadrante anterior; entra en la 1a vela del nuevo."

ESTRATEGIAS_CUADRANTE = {
    "MHI_1": st_mhi1,
    "MHI_2": st_mhi2,
    "MHI_3": st_mhi3,
    "MHI_Mayoria_1": st_mhi_may1,
    "MHI_Mayoria_2": st_mhi_may2,
    "MHI_Mayoria_3": st_mhi_may3,
    "Torres_Gemelas": st_torres_gemelas,
    "Tres_Mosqueteros": st_tres_mosqueteros,
    "Tres_Vecinos": st_tres_vecinos,
    "Padron_23": st_padron_23,
    "Mejor_de_3": st_mejor_de_3,
    "Patron_3x1": st_patron_3x1,
    "Milhao_Maioria": st_milhao_may,
    "Milhao_Minoria": st_milhao_min,
}

def st_reversao(c):
    """Reversão: tras 4+ velas seguidas de un color aparece la 1a vela contraria con cuerpo firme
    (>= 60 % de la anterior y cierre más allá de la mitad de esa vela, sin llegar a envolverla: eso ya
    lo cubre Envolvente) -> entra con el giro (patrón de penetración tras racha larga)."""
    if len(c) < 6: return None
    v = c[-1]; cv = color(v)
    if cv == 0: return None
    n = 0
    for x in reversed(c[:-1]):
        if color(x) == -cv: n += 1
        else: break
    if n < 4: return None
    a = c[-2]; ca = abs(a["c"] - a["o"])
    if ca == 0 or abs(v["c"] - v["o"]) < 0.6 * ca: return None
    mitad = (a["o"] + a["c"]) / 2
    if cv == 1 and mitad < v["c"] <= a["o"]: return "call"
    if cv == -1 and a["o"] <= v["c"] < mitad: return "put"
    return None

def _heikin(c):
    ha = []
    for v in c:
        hc = (v["o"] + v["h"] + v["l"] + v["c"]) / 4
        ho = (v["o"] + v["c"]) / 2 if not ha else (ha[-1][0] + ha[-1][1]) / 2
        ha.append((ho, hc, max(v["h"], ho, hc), min(v["l"], ho, hc)))
    return ha

def st_heikin_ashi(c):
    """Heikin-Ashi: tras 3+ velas HA de un color, la HA cambia de color y nace sin mecha en contra
    (señal de giro con fuerza) -> entra con el nuevo color."""
    if len(c) < 30: return None
    ha = _heikin(c[-30:])
    o, cl, h, l = ha[-1]
    rango = h - l
    if rango <= 0: return None
    col = 1 if cl > o else -1 if cl < o else 0
    if col == 0: return None
    previas = ha[-4:-1]
    if not all((x[1] < x[0]) if col == 1 else (x[1] > x[0]) for x in previas): return None
    if col == 1 and (min(o, cl) - l) <= 0.05 * rango: return "call"
    if col == -1 and (h - max(o, cl)) <= 0.05 * rango: return "put"
    return None

ESTRATEGIAS_INDICADORES = {
    "Minoria_3_velas": st_mhi,
    "Mayoria_3_velas": st_mayoria,
    "RSI_extremo": st_rsi,
    "Bollinger_rechazo": st_bollinger,
    "Cruce_EMA_9_21": st_cruce_ema,
    "Envolvente": st_envolvente,
    "Pinbar": st_pinbar,
    "Tres_soldados": st_tres_soldados,
    "Estocastico": st_estocastico,
    "Pullback_EMA": st_pullback_ema,
    "Williams_R": st_williams,
    "CCI_extremo": st_cci,
    "Cruce_MACD": st_macd,
    "Agotamiento": st_agotamiento,
    "Vela_de_fuerza": st_vela_fuerza,
    "Rechazo_SR": st_rechazo_sr,
    "Retesteo_ruptura": st_retesteo,
    "Numero_redondo": st_numero_redondo,
    "Reversao": st_reversao,
    "Heikin_Ashi": st_heikin_ashi,
}
ESTRATEGIAS = {**ESTRATEGIAS_CUADRANTE, **ESTRATEGIAS_INDICADORES}
ALIAS_ESTRATEGIAS = {"MHI_minoria": "Minoria_3_velas", "Mayoria": "Mayoria_3_velas"}  # nombres de versiones anteriores
VENTANA = 60  # velas que ve cada estrategia (suficiente para EMA 50)

# =====================================================================
#  CATALOGACIÓN: winrate histórico de cada estrategia en cada par
# =====================================================================

SENALES_RECIENTES = 12      # cuántas de las últimas señales se miran para saber si la estrategia "se enfrió"

def catalogar(velas, fn):
    """Devuelve (señales, ganadas_sin_gale, ganadas_hasta_G1, señales_recientes, ganadas_recientes,
    ganadas_hasta_G2, ganadas_hasta_G3)."""
    n = g0 = g1 = g2 = g3 = 0
    ult = []
    total = len(velas)
    for i in range(VENTANA, total - 1):
        d = fn(velas[i - VENTANA + 1: i + 1])
        if not d: continue
        n += 1
        obj = 1 if d == "call" else -1
        gano_en = None
        for k in range(4):                      # 0 = la entrada, 1..3 = gales
            if i + 1 + k >= total:
                break
            if color(velas[i + 1 + k]) == obj:
                gano_en = k
                break
        if gano_en == 0: g0 += 1
        if gano_en is not None and gano_en <= 1: g1 += 1
        if gano_en is not None and gano_en <= 2: g2 += 1
        if gano_en is not None: g3 += 1
        ult.append(1 if gano_en == 0 else 0)
    ult = ult[-SENALES_RECIENTES:]
    return n, g0, g1, len(ult), sum(ult), g2, g3

def ciclo_reciente(cerradas, fn, velas_ciclo):
    """Cómo le fue a la estrategia en las últimas `velas_ciclo` velas (el momento actual del par).
    Devuelve (señales, ganadas) de la entrada sin gale."""
    total = len(cerradas)
    inicio = max(VENTANA, total - 1 - int(velas_ciclo))
    n = g = 0
    for i in range(inicio, total - 1):
        d = fn(cerradas[i - VENTANA + 1: i + 1])
        if not d: continue
        n += 1
        if color(cerradas[i + 1]) == (1 if d == "call" else -1):
            g += 1
    return n, g

CUERPO_MIN_RANGO = 0.50      # el cuerpo debe ser al menos la mitad de la vela (mechas cortas)
CUERPO_MIN_PROMEDIO = 0.80   # y no más chico que el 80 % del cuerpo promedio de las 10 velas anteriores
SIN_FILTRO_CUERPO = {"Pinbar", "Rechazo_SR"}   # son velas de mecha larga a propósito

def vela_fuerte(c):
    """¿La vela de la señal (la que está cerrando) tiene cuerpo fuerte? Evita doji, peonzas y velas de mechas."""
    if len(c) < 11:
        return False
    v = c[-1]
    rango = v["h"] - v["l"]
    cuerpo = abs(v["c"] - v["o"])
    if rango <= 0 or cuerpo <= 0 or cuerpo / rango < CUERPO_MIN_RANGO:
        return False
    prom = sum(abs(x["c"] - x["o"]) for x in c[-11:-1]) / 10
    return prom <= 0 or cuerpo >= CUERPO_MIN_PROMEDIO * prom

def acierto_confiable(ganadas, total, z=1.64):
    """Acierto 'seguro' (límite inferior de Wilson, 90 %): castiga los porcentajes con pocas señales.
    Ej.: 8 de 8 (100 %) da 75 %, mientras que 45 de 50 (90 %) da 81 %: la segunda es más confiable."""
    if total <= 0:
        return 0.0
    p = ganadas / total
    den = 1 + z * z / total
    centro = p + z * z / (2 * total)
    margen = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total))
    return max(0.0, (centro - margen) / den)

def orden_senal(c):
    """Orden de prioridad: primero la de mayor puntaje (acierto del historial, corregido por la cantidad
    de señales; en martingala también pesa el acierto con gale)."""
    return (c.get("puntaje", c.get("conf", c["wr"])), c.get("conf", c["wr"]), c["wr"], c["n"])

def valor_esperado(wr0, wr1, payout, con_gale):
    """Ganancia esperada por cada $1 de entrada base."""
    if not con_gale:
        return wr0 * payout - (1 - wr0)
    m2 = (1 + payout) / payout                 # gale automático
    p_g2 = max(0.0, wr1 - wr0); p_l = 1 - wr1
    return wr0 * payout + p_g2 * (m2 * payout - 1) - p_l * (1 + m2)

# =====================================================================
#  INTELIGENCIA LS: aprende de cada señal (simulada y real) y filtra las que suelen perder
# =====================================================================
#  Cómo funciona:
#   - Cada vez que una estrategia da señal, se anota "cómo estaba el mercado" (rasgos): estrategia, par,
#     temporalidad, hora, fuerza de la vela, tendencia, volatilidad, lateralidad, RSI, payout...
#   - Cuando esa vela cierra se sabe si habría ganado o perdido, y la IA suma ese resultado a cada rasgo.
#     Las operaciones REALES pesan el triple.
#   - Antes de entrar, la IA estima la probabilidad de ganar con lo que aprendió de situaciones parecidas.
#     Si el contexto suele perder, bloquea la entrada; si suele ganar, la pone primero.
#   - Lo aprendido (conteos por rasgo) ocupa pocos MB y NUNCA se borra. Las muestras en bruto van a un
#     archivo con tope fijo que se reescribe por encima (lo más viejo, que ya fue aprendido).

IA_ARCHIVO = os.path.join(DATOS, "ia_ls.json")
IA_MUESTRAS = os.path.join(DATOS, "ia_muestras.jsonl")
IA_TOPE_MUESTRAS = 30 * 1024 * 1024        # tope del archivo de muestras en bruto (se reescribe al llenarse)
IA_MIN_ACTIVA = 400                        # señales aprendidas antes de empezar a filtrar
IA_NIVELES = (0, 400, 2000, 8000, 25000, 75000, 200000, 500000, 1000000)
IA_TOPE_CONTEOS = 3_000_000                # al pasar este total se reescala (mantiene lo aprendido)


def _logit(p):
    p = min(0.99, max(0.01, p))
    return math.log(p / (1 - p))


def _sigmoide(x):
    return 1 / (1 + math.exp(-x))


def _tramo(v, cortes, nombres):
    for c, n in zip(cortes, nombres):
        if v < c:
            return n
    return nombres[-1]


def tramo_sent(animo, d):
    """animo = fracción de traders de IQ Option comprando CALL. Devuelve si la señal va con la mayoría o en contra."""
    if animo is None:
        return None
    a_favor = animo if d == "call" else 1 - animo
    return "favor" if a_favor >= 0.65 else ("contra" if a_favor <= 0.35 else "neutral")


def _adx(c, n=14):
    """ADX de Wilder: fuerza de la tendencia (sin importar la dirección)."""
    if len(c) < 2 * n + 1:
        return None
    trs, pdm, mdm = [], [], []
    for a, b in zip(c[-2 * n - 1:-1], c[-2 * n:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0); mdm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    dxs = []
    for i in range(n, len(trs) + 1):
        tr = sum(trs[i - n:i])
        if tr <= 0:
            continue
        pdi, mdi = 100 * sum(pdm[i - n:i]) / tr, 100 * sum(mdm[i - n:i]) / tr
        if pdi + mdi > 0:
            dxs.append(100 * abs(pdi - mdi) / (pdi + mdi))
    return sum(dxs) / len(dxs) if dxs else None


def indicadores(c, d):
    """Indicadores técnicos clásicos, contados a favor o en contra de la dirección de la señal."""
    sentido = 1 if d == "call" else -1
    cl = [x["c"] for x in c]
    out = []
    try:
        if len(cl) >= 40:                                            # MACD 12/26/9
            e12, e26 = ema_series(cl, 12), ema_series(cl, 26)
            macd = [a - b for a, b in zip(e12, e26) if a is not None and b is not None]
            sig = ema_series(macd, 9) if len(macd) >= 10 else [None]
            if sig[-1] is not None:
                h = (macd[-1] - sig[-1]) * sentido
                out.append(f"macd:{'favor' if h > 0 else 'contra'}")
        es = estocastico(c, 14, 3)                                   # estocástico
        if es:
            k = es[2]
            out.append("sto:" + ("bajo" if k < 20 else "alto" if k > 80 else "medio"))
        b = bollinger(cl, 20, 2.0)                                   # posición en Bollinger
        if b and b[2] > b[0]:
            pb = (cl[-1] - b[0]) / (b[2] - b[0])
            pb = pb if sentido == 1 else 1 - pb
            out.append("bb:" + ("abajo" if pb < 0.2 else "arriba" if pb > 0.8 else "medio"))
        a = _adx(c)                                                  # fuerza de tendencia
        if a is not None:
            out.append("adx:" + ("debil" if a < 20 else "fuerte" if a > 35 else "media"))
        e50 = ema(cl, 50)                                            # lado de la EMA 50
        if e50 is not None:
            out.append(f"e50:{'favor' if (cl[-1] - e50) * sentido > 0 else 'contra'}")
        racha = 1                                                    # velas seguidas del mismo color
        col = color(c[-1])
        for x in reversed(c[:-1]):
            if col != 0 and color(x) == col: racha += 1
            else: break
        out.append(f"racha:{min(racha, 4)}{'f' if col == sentido else 'c'}")
    except Exception:
        pass
    return out


def rasgos_mercado(c, par, tf, d, nombre, wr0, payout, inicio, animo=None):
    """Rasgos de la situación en que una estrategia da señal (las claves que la IA aprende)."""
    v = c[-1]
    rango = v["h"] - v["l"]
    cuerpo = abs(v["c"] - v["o"])
    prom = sum(abs(x["c"] - x["o"]) for x in c[-11:-1]) / 10 if len(c) >= 11 else 0
    rangos = [x["h"] - x["l"] for x in c]
    atr14 = sum(rangos[-14:]) / max(1, len(rangos[-14:]))
    atr_l = sum(rangos[-60:]) / max(1, len(rangos[-60:]))
    cierres = [x["c"] for x in c]
    e = ema_series(cierres, 20)
    pend = 0.0
    if e[-1] is not None and e[-6] is not None and atr14 > 0:
        pend = (e[-1] - e[-6]) / atr14
    sentido = 1 if d == "call" else -1
    tend = "plana" if abs(pend) < 0.3 else ("favor" if pend * sentido > 0 else "contra")
    w = cierres[-16:]
    mov = sum(abs(w[i] - w[i - 1]) for i in range(1, len(w)))
    efic = abs(w[-1] - w[0]) / mov if mov > 0 else 0
    r = rsi(cierres[-40:], 14)
    otc = "otc" if "OTC" in par.upper() else "real"
    hora = time.localtime(inicio).tm_hour
    cu = _tramo(cuerpo / rango if rango > 0 else 0, (0.3, 0.5, 0.7), ("c0", "c1", "c2", "c3"))
    ta = _tramo(cuerpo / prom if prom > 0 else 1, (0.8, 1.5), ("chica", "normal", "grande"))
    vo = _tramo(atr14 / atr_l if atr_l > 0 else 1, (0.7, 1.3), ("baja", "normal", "alta"))
    ef = _tramo(efic, (0.2, 0.4), ("lateral", "media", "tendencia"))
    rs = "na" if r is None else _tramo(r, (30, 45, 55, 70), ("<30", "30-45", "45-55", "55-70", ">70"))
    wr = _tramo(wr0, (0.80, 0.85), ("75-80", "80-85", "85+"))
    py = _tramo(payout or 0, (0.80, 0.87), ("<80", "80-87", "87+"))
    return [f"e:{nombre}", f"tf:{tf}", f"m:{otc}", f"h:{hora}", f"cu:{cu}", f"ta:{ta}", f"tr:{tend}",
            f"vo:{vo}", f"ef:{ef}", f"rs:{rs}", f"wr:{wr}", f"py:{py}", f"d:{d}", f"p:{par}",
            f"e|p:{nombre}|{par}", f"e|tf:{nombre}|{tf}", f"e|tr:{nombre}|{tend}", f"e|vo:{nombre}|{vo}",
            f"e|cu:{nombre}|{cu}", f"e|ef:{nombre}|{ef}", f"e|h:{nombre}|{hora}", f"e|m:{nombre}|{otc}"] + \
           [x for i in indicadores(c, d) for x in (i, "e|{}:{}|{}".format(*i.split(":", 1)[:1], nombre, i.split(":", 1)[1]))] + \
           ([f"st:{tramo_sent(animo, d)}", f"e|st:{nombre}|{tramo_sent(animo, d)}"] if animo is not None else [])


class InteligenciaLS:
    def __init__(self):
        self.lock = threading.Lock()
        self.d = {"v": 1, "total": 0.0, "ganadas": 0.0, "c": {}, "estr": {}}
        self.hoy = {"dia": "", "bloqueadas": 0, "paso_n": 0, "paso_g": 0}
        self.cambios = 0
        self.t_guardado = time.time()
        try:
            if os.path.exists(IA_ARCHIVO):
                with open(IA_ARCHIVO, encoding="utf-8") as f:
                    d = json.load(f)
            else:
                d = cerebro_inicial("ia") or {}              # primera vez: arranca con el cerebro inicial
                self.cambios = 1
            if isinstance(d.get("c"), dict):
                self.d.update(d)
            self.d.setdefault("estr", {})
            for k in ("reg", "horas", "sent"):          # datos de las IAs retiradas (régimen, horas, traders)
                self.d.pop(k, None)
            if isinstance(d.get("hoy"), dict):
                self.hoy.update(d["hoy"])
        except Exception:
            pass

    # ---------- aprender ----------
    def aprender(self, claves, gano, peso=1.0, extra=None):
        with self.lock:
            c = self.d["c"]
            self.d["total"] += peso
            self.d["ganadas"] += peso if gano else 0
            for k in claves:
                x = c.get(k)
                if x is None:
                    x = c[k] = [0.0, 0.0]
                x[0] += peso if gano else 0
                x[1] += peso
            if self.d["total"] > IA_TOPE_CONTEOS:       # reescala: mismas proporciones, sigue aprendiendo
                self.d["total"] /= 2; self.d["ganadas"] /= 2
                for x in c.values():
                    x[0] /= 2; x[1] /= 2
            self.cambios += 1
        try:
            fila = {"t": int(time.time()), "g": int(bool(gano)), "p": peso, "k": claves}
            if extra: fila.update(extra)
            with open(IA_MUESTRAS, "a", encoding="utf-8") as f:
                f.write(json.dumps(fila, separators=(",", ":")) + "\n")
        except Exception:
            pass

    def _rotar_muestras(self):
        """El archivo de muestras tiene tope fijo: al llenarse se queda con la mitad más nueva."""
        try:
            if os.path.getsize(IA_MUESTRAS) <= IA_TOPE_MUESTRAS:
                return
            with open(IA_MUESTRAS, "rb") as f:
                f.seek(-IA_TOPE_MUESTRAS // 2, os.SEEK_END)
                resto = f.read()
            resto = resto[resto.find(b"\n") + 1:]
            tmp = IA_MUESTRAS + ".tmp"
            with open(tmp, "wb") as f:
                f.write(resto)
            os.replace(tmp, IA_MUESTRAS)
        except Exception:
            pass

    def guardar(self, forzar=False):
        if not forzar and (not self.cambios or time.time() - self.t_guardado < 300):
            return
        with self.lock:
            datos = json.dumps(dict(self.d, hoy=self.hoy), separators=(",", ":"))
            self.cambios = 0
        self.t_guardado = time.time()
        try:
            os.makedirs(DATOS, exist_ok=True)
            tmp = IA_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datos)
            os.replace(tmp, IA_ARCHIVO)
        except Exception:
            pass
        self._rotar_muestras()

    # ---------- predecir ----------
    @property
    def activa(self):
        return self.d["total"] >= IA_MIN_ACTIVA

    def evaluar(self, claves):
        """Devuelve (probabilidad de ganar, ajuste). Ajuste < 0 = contexto que suele perder."""
        with self.lock:
            tot = self.d["total"]
            if tot < 50:
                return None, 0.0
            g = self.d["ganadas"] / tot
            ajuste = 0.0
            for k in claves:
                x = self.d["c"].get(k)
                if not x or x[1] <= 0:
                    continue
                tasa = (x[0] + 20 * g) / (x[1] + 20)        # se acerca al promedio si hay pocos datos
                peso = x[1] / (x[1] + 40)
                ajuste += 0.35 * peso * (_logit(tasa) - _logit(g))
            ajuste = max(-1.5, min(1.5, ajuste))
            return _sigmoide(_logit(g) + ajuste), ajuste

    def bloquea(self, prob, ajuste):
        return self.activa and prob is not None and (prob < 0.50 or ajuste < -0.35)

    # ---------- ranking de estrategias (se apagan solas las que pierden) ----------
    def anotar_estrategia(self, nombre, gano):
        with self.lock:
            e = self.d["estr"].setdefault(nombre, {"r": [], "n": 0, "g": 0, "off": False})
            e["r"] = (e["r"] + [1 if gano else 0])[-ESTR_VENTANA:]
            e["n"] += 1; e["g"] += 1 if gano else 0
            r = e["r"]
            if not e["off"]:
                mala_racha = len(r) >= ESTR_RACHA and sum(r[-ESTR_RACHA:]) == 0
                bajo = len(r) >= ESTR_MIN and sum(r) / len(r) < ESTR_EQUILIBRIO
                encendidas = sum(1 for x in self.d["estr"].values() if not x["off"])
                if (mala_racha or bajo) and encendidas > ESTR_MIN_ENCENDIDAS:
                    e["off"] = True
                    e["motivo"] = "racha de pérdidas" if mala_racha else f"{sum(r)/len(r)*100:.0f}% en sus últimas {len(r)}"
                    e["desde"] = len(r)
                    e["r"] = r[-10:]                     # para volver tiene que demostrar con señales nuevas
                    return "off"
            else:
                if len(r) >= ESTR_MIN and sum(r[-ESTR_MIN:]) / ESTR_MIN >= ESTR_VOLVER:
                    e["off"] = False; e.pop("motivo", None)
                    return "on"
        return None

    def estrategia_apagada(self, nombre):
        e = self.d["estr"].get(nombre)
        return bool(e and e.get("off"))

    def ranking(self):
        with self.lock:
            filas = []
            for n, e in self.d["estr"].items():
                r = e["r"]
                if len(r) >= 10:
                    filas.append({"nombre": n, "acierto": round(sum(r) / len(r), 3), "senales": len(r),
                                  "off": bool(e.get("off")), "motivo": e.get("motivo", "")})
            filas.sort(key=lambda x: (not x["off"], x["acierto"], x["senales"]), reverse=True)
            return filas

    # ---------- IA 4: bandido (Thompson sampling) ----------
    def bandido(self, nombre, sortear=True):
        """Probabilidad de ganar de la estrategia según sus señales recientes. Con sortear=True agrega el
        'azar inteligente' del bandido: a veces le da chance a estrategias con pocos datos (explorar)."""
        e = self.d["estr"].get(nombre)
        r = e["r"] if e else []
        g, n = sum(r), len(r)
        if sortear:
            return random.betavariate(g + 1, n - g + 1)
        return (g + 1) / (n + 2), n

    def _dia(self):
        d = time.strftime("%Y-%m-%d")
        if self.hoy.get("dia") != d:
            self.hoy = {"dia": d, "bloqueadas": 0, "paso_n": 0, "paso_g": 0}

    def anotar_bloqueo(self):
        with self.lock:
            self._dia(); self.hoy["bloqueadas"] += 1

    def anotar_paso(self, gano):
        with self.lock:
            self._dia(); self.hoy["paso_n"] += 1; self.hoy["paso_g"] += 1 if gano else 0

    def resumen(self):
        with self.lock:
            self._dia()
            tot = self.d["total"]
            nivel = sum(1 for x in IA_NIVELES if tot >= x)
            if nivel < len(IA_NIVELES):
                a, b = IA_NIVELES[nivel - 1], IA_NIVELES[nivel]
                progreso = (tot - a) / (b - a)
            else:
                progreso = 1.0
            h = self.hoy
            return {"nivel": nivel, "progreso": round(max(0.0, min(1.0, progreso)), 3), "estudiadas": int(tot),
                    "activa": tot >= IA_MIN_ACTIVA, "faltan": max(0, int(IA_MIN_ACTIVA - tot)),
                    "bloqueadas": h["bloqueadas"],
                    "acierto_paso": round(h["paso_g"] / h["paso_n"], 3) if h["paso_n"] >= 5 else None,
                    "paso_n": h["paso_n"]}


_IA = None
_IA_LOCK = threading.Lock()


def inteligencia():
    """Una sola IA por programa (la comparten todas las sesiones)."""
    global _IA
    with _IA_LOCK:
        if _IA is None:
            _IA = InteligenciaLS()
        return _IA


# =====================================================================
#  ESTADO DEL MERCADO (cada 15 minutos): avisa cuando no conviene operar
# =====================================================================
MERCADO_CADA_SEG = 15 * 60


def eficiencia(velas):
    """0 = lateral (va y viene sin avanzar), 1 = tendencia limpia."""
    w = [v["c"] for v in velas]
    mov = sum(abs(w[i] - w[i - 1]) for i in range(1, len(w)))
    return abs(w[-1] - w[0]) / mov if mov > 0 else 0.0


def vela_debil(v, prom):
    rango = v["h"] - v["l"]
    cuerpo = abs(v["c"] - v["o"])
    return rango <= 0 or cuerpo / rango < 0.35 or (prom > 0 and cuerpo < 0.6 * prom)


# ---------- ranking de estrategias ----------
ESTR_VENTANA = 50          # se juzga cada estrategia por sus últimas 50 señales (en todos los pares)
ESTR_MIN = 30              # mínimo de señales antes de juzgarla
ESTR_RACHA = 8             # 8 pérdidas seguidas = se apaga
ESTR_EQUILIBRIO = 0.54     # con payout 85 % hay que ganar más de 54 % para no perder plata
ESTR_VOLVER = 0.62         # vuelve si en sus últimas 30 señales (simuladas) acierta 62 % o más
ESTR_MIN_ENCENDIDAS = 5    # nunca deja menos de 5 estrategias encendidas
VELA_VIVO_SEG = 15         # velas de 15 s en la tabla de operaciones abiertas (como IQ Option)


# =====================================================================
#  RÉGIMEN DEL MERCADO (cómo está cada par): dato que reciben las IAs y el aviso de mercado
# =====================================================================
REGIMENES = {"tendencia": "Tendencia", "normal": "Normal", "lateral": "Lateral", "explosivo": "Explosivo",
             "muerto": "Sin movimiento"}


def regimen(velas):
    """tendencia (avanza limpio) · lateral (va y viene) · explosivo (velas enormes) · muerto (doji, sin rango)."""
    if len(velas) < 30:
        return None
    rangos = [v["h"] - v["l"] for v in velas]
    atr14 = sum(rangos[-14:]) / 14
    atr_l = sum(rangos[-60:]) / len(rangos[-60:])
    ratio = atr14 / atr_l if atr_l > 0 else 1.0
    ult = velas[-10:]
    debiles = 0
    for i in range(len(velas) - 10, len(velas)):
        prom = sum(abs(x["c"] - x["o"]) for x in velas[max(0, i - 10):i]) / 10
        debiles += vela_debil(velas[i], prom)
    if ratio > 1.6:
        return "explosivo"
    if ratio < 0.5 or debiles >= 8:
        return "muerto"
    ef = eficiencia(velas[-16:])
    if ef >= 0.35:
        return "tendencia"
    if ef < 0.12:
        return "lateral"           # va y viene sin avanzar (de verdad, no el vaivén normal de M1)
    return "normal"


# =====================================================================
#  IA 3: ÁRBOLES POTENCIADOS (patrones combinados), entrenados en el propio equipo
# =====================================================================
IA3_ARCHIVO = os.path.join(DATOS, "ia_arboles.json")
IA3_MIN_MUESTRAS = 2000        # muestras necesarias para el primer entrenamiento
IA3_REENTRENAR = 1500          # se vuelve a entrenar con cada 1.500 muestras nuevas
IA3_MAX_MUESTRAS = 9000        # usa las más recientes (las de hoy pesan más que las de hace semanas)
IA3_RONDAS = 45
IA3_TASA = 0.15
IA3_LAMBDA = 8.0
IA3_HOJA_MIN = 25.0


class ArbolesLS:
    """Gradient boosting con árboles de 2 niveles sobre los rasgos de cada señal. Puro Python, sin librerías."""

    def __init__(self):
        self.modelo = None          # {"base", "vocab": [claves], "arboles": [...], "muestras", "acierto", "fecha"}
        self.entrenando = False
        self.progreso = 0.0
        self.ultimo_total = 0
        self.lock = threading.Lock()
        try:
            if os.path.exists(IA3_ARCHIVO):
                with open(IA3_ARCHIVO, encoding="utf-8") as f:
                    m = json.load(f)
            else:
                m = cerebro_inicial("arboles") or {}
            if m.get("arboles"):
                self.modelo = m
                self.ultimo_total = int(m.get("total_ia", 0))
                self._indice = {k: i for i, k in enumerate(m["vocab"])}
        except Exception:
            pass

    @property
    def lista(self):
        return bool(self.modelo and self.modelo.get("util"))

    def probabilidad(self, claves, cruda=False):
        """cruda=True: opina aunque todavía no haya demostrado ser útil sola (la Juez decide cuánto creerle)."""
        m = self.modelo
        if not m or not (m.get("util") or cruda):
            return None
        idx = self._indice
        tiene = {idx[k] for k in claves if k in idx}
        f = m["base"]
        for j, a, b in m["arboles"]:
            rama = a if j in tiene else b
            j2, v1, v0 = rama
            f += v1 if j2 in tiene else v0
        return _sigmoide(f)

    def quiza_entrenar(self, total_ia, puede_trabajar):
        """Lanza un entrenamiento en segundo plano cuando hay suficientes muestras nuevas."""
        if self.entrenando or total_ia < IA3_MIN_MUESTRAS:
            return
        if self.modelo and total_ia - self.ultimo_total < IA3_REENTRENAR:
            return
        self.entrenando = True
        threading.Thread(target=self._entrenar, args=(total_ia, puede_trabajar), daemon=True).start()

    # ---------- entrenamiento ----------
    def _leer_muestras(self):
        filas = []
        try:
            with open(IA_MUESTRAS, encoding="utf-8") as f:
                for linea in f:
                    try:
                        filas.append(json.loads(linea))
                    except Exception:
                        continue
        except Exception:
            return []
        return filas[-IA3_MAX_MUESTRAS:]

    def _entrenar(self, total_ia, puede_trabajar):
        try:
            filas = self._leer_muestras()
            if len(filas) < IA3_MIN_MUESTRAS // 2:
                return
            cuenta = {}
            for r in filas:
                for k in r["k"]:
                    cuenta[k] = cuenta.get(k, 0) + 1
            vocab = [k for k, c in sorted(cuenta.items(), key=lambda x: -x[1]) if c >= 30][:400]
            indice = {k: i for i, k in enumerate(vocab)}
            X = [[indice[k] for k in r["k"] if k in indice] for r in filas]
            Y = [int(r["g"]) for r in filas]
            W = [float(r.get("p", 1)) for r in filas]
            corte = int(len(X) * 0.8)                         # 80 % para aprender, 20 % (lo más nuevo) para comprobar
            Xe, Ye, We, Xv, Yv = X[:corte], Y[:corte], W[:corte], X[corte:], Y[corte:]
            tw = sum(We); tg = sum(w * y for w, y in zip(We, Ye))
            p0 = min(0.95, max(0.05, tg / tw))
            base = _logit(p0)
            F = [base] * len(Xe)
            arboles = []
            nf = len(vocab)
            for ronda in range(IA3_RONDAS):
                while not puede_trabajar():                  # no estorba justo antes de un cierre de vela
                    time.sleep(0.2)
                self.progreso = ronda / IA3_RONDAS
                G = [0.0] * len(Xe); H = [0.0] * len(Xe)
                for i in range(len(Xe)):
                    p = _sigmoide(F[i])
                    G[i] = We[i] * (p - Ye[i]); H[i] = We[i] * p * (1 - p)
                todos = range(len(Xe))
                j, con, sin = self._mejor_corte(Xe, G, H, todos, nf)
                if j is None:
                    break
                ramas = []
                for grupo in (con, sin):
                    j2, a, b = self._mejor_corte(Xe, G, H, grupo, nf)
                    if j2 is None:
                        v = self._hoja(G, H, grupo)
                        ramas.append([-1, v, v])
                    else:
                        ramas.append([j2, self._hoja(G, H, a), self._hoja(G, H, b)])
                arboles.append([j, ramas[0], ramas[1]])
                conj = None
                for i in range(len(Xe)):
                    s = set(Xe[i])
                    j2, v1, v0 = ramas[0] if j in s else ramas[1]
                    F[i] += v1 if j2 in s else v0
                time.sleep(0)
            # comprobación con señales que el modelo NO vio
            def pred(xs):
                s = set(xs); f = base
                for j, a, b in arboles:
                    j2, v1, v0 = a if j in s else b
                    f += v1 if j2 in s else v0
                return _sigmoide(f)
            ll_mod = ll_base = 0.0
            aprobadas = ganadas = 0
            for xs, y in zip(Xv, Yv):
                p = min(0.99, max(0.01, pred(xs)))
                ll_mod -= math.log(p if y else 1 - p)
                ll_base -= math.log(p0 if y else 1 - p0)
                if p >= p0:
                    aprobadas += 1; ganadas += y
            util = bool(Xv) and ll_mod < ll_base             # solo se usa si predice mejor que adivinar el promedio
            acierto = ganadas / aprobadas if aprobadas else None
            modelo = {"base": base, "vocab": vocab, "arboles": arboles, "muestras": len(filas), "util": util,
                      "acierto": acierto, "promedio": sum(Yv) / len(Yv) if Yv else None,
                      "fecha": time.strftime("%Y-%m-%d %H:%M"), "total_ia": total_ia}
            with self.lock:
                self._indice = indice
                self.modelo = modelo
                self.ultimo_total = total_ia
            tmp = IA3_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(modelo, f, separators=(",", ":"))
            os.replace(tmp, IA3_ARCHIVO)
        except Exception:
            try:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] IA 3\n{traceback.format_exc()}")
            except Exception:
                pass
        finally:
            self.entrenando = False
            self.progreso = 0.0

    @staticmethod
    def _hoja(G, H, grupo):
        g = sum(G[i] for i in grupo); h = sum(H[i] for i in grupo)
        return -IA3_TASA * g / (h + IA3_LAMBDA)

    @staticmethod
    def _mejor_corte(X, G, H, grupo, nf):
        grupo = list(grupo)
        gs = [0.0] * nf; hs = [0.0] * nf
        Gt = Ht = 0.0
        for i in grupo:
            g = G[i]; h = H[i]
            Gt += g; Ht += h
            for j in X[i]:
                gs[j] += g; hs[j] += h
        if Ht < 2 * IA3_HOJA_MIN:
            return None, None, None
        padre = Gt * Gt / (Ht + IA3_LAMBDA)
        mejor, mj = 1e-6, None
        for j in range(nf):
            hl = hs[j]; hr = Ht - hl
            if hl < IA3_HOJA_MIN or hr < IA3_HOJA_MIN:
                continue
            gl = gs[j]; gr = Gt - gl
            gan = gl * gl / (hl + IA3_LAMBDA) + gr * gr / (hr + IA3_LAMBDA) - padre
            if gan > mejor:
                mejor, mj = gan, j
        if mj is None:
            return None, None, None
        con = [i for i in grupo if mj in X[i]]
        sin = [i for i in grupo if mj not in X[i]]
        return mj, con, sin

    def resumen(self, total_ia):
        m = self.modelo
        return {"lista": self.lista, "entrenando": self.entrenando, "progreso": round(self.progreso, 2),
                "muestras": m["muestras"] if m else 0, "acierto": m.get("acierto") if m else None,
                "promedio": m.get("promedio") if m else None, "util": bool(m and m.get("util")),
                "fecha": m.get("fecha") if m else None, "faltan": max(0, int(IA3_MIN_MUESTRAS - total_ia))}


_IA3 = None


def arboles():
    global _IA3
    with _IA_LOCK:
        if _IA3 is None:
            _IA3 = ArbolesLS()
        return _IA3


# =====================================================================
#  IA 2 (Aprendizaje continuo), IA 5 (Memoria de patrones) e IA 6 (Juez)
#  - IA 2: regresión logística en línea: cada señal resuelta ajusta un peso por rasgo.
#  - IA 5: k vecinos más cercanos: busca momentos pasados con velas parecidas y mira qué pasó después.
#  - IA 6: "stacking": aprende cuánto confiar en cada IA y da la probabilidad final.
#  Todas se miden ANTES de aprender cada señal (evaluación "prequential"): así sabemos si de verdad
#  predicen señales que todavía no habían visto. La Juez solo decide cuando lo demostró.
# =====================================================================
MODELOS_ARCHIVO = os.path.join(DATOS, "ia_modelos.json")
LOGIT_TASA = 0.02
LOGIT_L2 = 1e-3
MEMORIA_TOPE = 5000            # momentos que recuerda la IA 5 (los más nuevos)
MEMORIA_K = 50                 # vecinos que consulta
MEMORIA_MIN = 500              # momentos mínimos antes de opinar
JUEZ_TASA = 0.01
JUEZ_MIN = 300                 # señales evaluadas antes de que la Juez pueda decidir
JUEZ_VENTANA = 1500            # se la juzga por sus últimas 1.500 evaluaciones
JUEZ_MARGEN = 0.0              # normal: entra si la Juez la ve sobre el promedio (≈ la mitad de las señales)
JUEZ_MARGEN_ALTA = 0.02        # precisión alta: 2 puntos sobre el promedio (menos operaciones, más acierto)
JUEZ_LIFT = 0.02               # para mandar, lo que aprueba debe ganar 2+ puntos más que el promedio


def vector_patron(c):
    """Forma de las últimas 10 velas (cuerpo / ATR) y dónde está el precio en el rango de 20 velas."""
    if len(c) < 21:
        return None
    rangos = [x["h"] - x["l"] for x in c[-14:]]
    atr = sum(rangos) / len(rangos)
    if atr <= 0:
        return None
    v = [max(-3.0, min(3.0, (x["c"] - x["o"]) / atr)) for x in c[-10:]]
    w = c[-20:]
    hi = max(x["h"] for x in w); lo = min(x["l"] for x in w)
    v.append(0.0 if hi == lo else 2 * (c[-1]["c"] - lo) / (hi - lo) - 1)
    return [round(x, 3) for x in v]


class ModelosLS:
    def __init__(self):
        self.lock = threading.Lock()
        self.w = {}                     # IA 2: peso por rasgo
        self.b = 0.0
        self.mem = deque(maxlen=MEMORIA_TOPE)   # IA 5: (vector, subió 1/0)
        self.jw = [0.0, 0.0, 0.0, 0.0, 0.0]    # IA 6: sesgo + peso de IA1, IA2, IA3, IA5
        self.g = 0.0; self.t = 0.0      # promedio de las señales resueltas
        self.ev = {"logit": deque(maxlen=JUEZ_VENTANA), "mem": deque(maxlen=JUEZ_VENTANA),
                   "juez": deque(maxlen=JUEZ_VENTANA)}     # (p, p0, ganó)
        self.gale = {"cambio": [0, 0], "igual": [0, 0]}
        self.cambios = 0
        self.t_guardado = time.time()
        self.cargado = False
        try:
            if os.path.exists(MODELOS_ARCHIVO):
                with open(MODELOS_ARCHIVO, encoding="utf-8") as f:
                    d = json.load(f)
            elif not os.path.exists(IA_MUESTRAS):            # equipo nuevo: cerebro inicial
                d = cerebro_inicial("modelos")
                if not d: raise ValueError("sin cerebro inicial")
                self.cambios = 1
            else:
                raise FileNotFoundError                      # tiene señales propias: aprende de ellas
            self.w = d.get("w", {}); self.b = d.get("b", 0.0)
            self.mem.extend(tuple(x) for x in d.get("mem", []))
            self.jw = (d.get("jw") or self.jw)[:5]
            self.g, self.t = d.get("g", 0.0), d.get("t", 0.0)
            for k in self.ev:
                self.ev[k].extend(tuple(x) for x in d.get("ev", {}).get(k, []))
            self.gale.update(d.get("gale", {}))
            self.cargado = True
        except Exception:
            pass

    # ---------- predicciones ----------
    def base(self):
        return (self.g + 10) / (self.t + 20)

    def p_logit(self, claves):
        if self.t < 200 or not claves:
            return None
        z = self.b + sum(self.w.get(k, 0.0) for k in claves)
        return _sigmoide(max(-20.0, min(20.0, z)))

    def p_sube(self, v):
        """IA 5: probabilidad de que la próxima vela sea verde, según los momentos más parecidos."""
        if v is None or len(self.mem) < MEMORIA_MIN:
            return None
        n = len(v)
        mejores = []
        for x, y in self.mem:
            d = 0.0
            for i in range(n):
                e = x[i] - v[i]; d += e * e
            mejores.append((d, y))
        mejores.sort(key=lambda z: z[0])
        sub = sum(y for _, y in mejores[:MEMORIA_K])
        return (sub + 5) / (MEMORIA_K + 10)

    def p_mem(self, v, d):
        p = self.p_sube(v)
        return None if p is None else (p if d == "call" else 1 - p)

    def p_juez(self, p1, p2, p3, p5):
        p0 = self.base()
        x = [1.0] + [(_logit(p) - _logit(p0)) if p is not None else 0.0 for p in (p1, p2, p3, p5)]
        return _sigmoide(_logit(p0) + sum(a * b for a, b in zip(self.jw, x))), x

    # ---------- ¿demostró que sirve? ----------
    @staticmethod
    def _medir(ev, margen=JUEZ_MARGEN):
        if len(ev) < JUEZ_MIN:
            return None
        ll_m = ll_b = 0.0; ap = ga = 0; tot = 0
        for p, p0, y in ev:
            pm = min(0.99, max(0.01, p)); pb = min(0.99, max(0.01, p0))
            ll_m -= math.log(pm if y else 1 - pm); ll_b -= math.log(pb if y else 1 - pb)
            tot += y
            if p >= p0 + margen:
                ap += 1; ga += y
        prom = tot / len(ev)
        acierto = ga / ap if ap else None
        return {"n": len(ev), "aprobadas": ap, "acierto": acierto, "promedio": prom,
                "mejor": ll_m < ll_b, "lift": (acierto - prom) if acierto is not None else None}

    def juez_lista(self):
        m = self._medir(self.ev["juez"])
        return bool(m and m["mejor"] and m["aprobadas"] >= 50 and (m["lift"] or 0) >= JUEZ_LIFT)

    def mem_lista(self):
        m = self._medir(self.ev["mem"], 0.0)
        return bool(m and m["mejor"])

    # ---------- aprender (cada señal resuelta) ----------
    def aprender(self, claves, v, d, gano, p1, p3, p_up=False):
        """p1 y p3 son lo que opinaban la IA 1 y la IA 3 ANTES de saber el resultado.
        p_up: opinión de la IA 5 ya calculada para ese momento (False = calcularla aquí)."""
        if p_up is False:
            p_up = self.p_sube(v) if v is not None else None
        with self.lock:
            p0 = self.base()
            p2 = self.p_logit(claves)
            p5 = None if p_up is None else (p_up if d == "call" else 1 - p_up)
            pj, x = self.p_juez(p1, p2, p3, p5)
            y = 1 if gano else 0
            if p2 is not None: self.ev["logit"].append((round(p2, 4), round(p0, 4), y))
            if p5 is not None: self.ev["mem"].append((round(p5, 4), round(p0, 4), y))
            if any(p is not None for p in (p1, p2, p3, p5)):
                self.ev["juez"].append((round(pj, 4), round(p0, 4), y))
            e = pj - y                                   # la Juez aprende cuánto confiar en cada IA
            for i in range(len(self.jw)):
                self.jw[i] -= JUEZ_TASA * e * x[i]
            if claves:                                   # IA 2
                pz = _sigmoide(max(-20.0, min(20.0, self.b + sum(self.w.get(k, 0.0) for k in claves))))
                e2 = pz - y
                self.b -= LOGIT_TASA * e2
                for k in claves:
                    wk = self.w.get(k, 0.0)
                    self.w[k] = wk - LOGIT_TASA * (e2 + LOGIT_L2 * wk)
            self.g += y; self.t += 1
            self.cambios += 1

    def recordar(self, v, subio):
        """IA 5: guarda la forma de las velas y si la vela siguiente fue verde."""
        if v is not None:
            with self.lock:
                self.mem.append((v, 1 if subio else 0))
                self.cambios += 1

    def anotar_gale(self, cambio, gano):
        with self.lock:
            x = self.gale["cambio" if cambio else "igual"]
            x[0] += 1 if gano else 0; x[1] += 1
            self.cambios += 1

    def arrancar_con_historial(self, ia1):
        """Primera vez: aprende de las señales ya guardadas (en orden, midiendo antes de aprender)."""
        if self.cargado or self.t > 0:
            return
        try:
            filas = []
            with open(IA_MUESTRAS, encoding="utf-8") as f:
                for linea in f:
                    try:
                        r = json.loads(linea)
                    except Exception:
                        continue
                    if r.get("k") and not r.get("real"):
                        filas.append(r)
        except Exception:
            return
        copia = InteligenciaLS.__new__(InteligenciaLS)      # IA 1 desde cero, para no hacer trampa
        copia.lock = threading.Lock(); copia.d = {"total": 0.0, "ganadas": 0.0, "c": {}}
        for r in filas[-20000:]:
            p1 = copia.evaluar(r["k"])[0] if copia.d["total"] >= IA_MIN_ACTIVA else None
            d = next((k[2:] for k in r["k"] if k.startswith("d:")), "call")
            self.aprender(r["k"], r.get("v"), d, bool(r["g"]), p1, None)
            g = bool(r["g"]); c = copia.d["c"]
            copia.d["total"] += 1; copia.d["ganadas"] += 1 if g else 0
            for k in r["k"]:
                x = c.setdefault(k, [0.0, 0.0]); x[0] += 1 if g else 0; x[1] += 1
        self.guardar(forzar=True)

    def guardar(self, forzar=False):
        if not forzar and (not self.cambios or time.time() - self.t_guardado < 300):
            return
        with self.lock:
            datos = json.dumps({"w": {k: round(v, 5) for k, v in self.w.items() if abs(v) > 1e-5}, "b": self.b,
                                "mem": list(self.mem), "jw": self.jw, "g": self.g, "t": self.t,
                                "ev": {k: list(v) for k, v in self.ev.items()}, "gale": self.gale},
                               separators=(",", ":"))
            self.cambios = 0
        self.t_guardado = time.time()
        try:
            tmp = MODELOS_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datos)
            os.replace(tmp, MODELOS_ARCHIVO)
        except Exception:
            pass

    def resumen(self):
        with self.lock:
            lg = self._medir(self.ev["logit"]); me = self._medir(self.ev["mem"], 0.0); ju = self._medir(self.ev["juez"])
            return {"logit": lg, "mem": me, "mem_n": len(self.mem), "mem_lista": self.mem_lista(),
                    "juez": ju, "juez_lista": self.juez_lista(), "evaluadas": int(self.t),
                    "pesos": {"IA1": round(self.jw[1], 2), "IA2": round(self.jw[2], 2), "IA3": round(self.jw[3], 2),
                              "IA5": round(self.jw[4], 2)},
                    "gale": {k: v[:] for k, v in self.gale.items()}}


_MODELOS = None


def modelos():
    global _MODELOS
    with _IA_LOCK:
        if _MODELOS is None:
            _MODELOS = ModelosLS()
        return _MODELOS


# =====================================================================
#  ESTADO DEL MERCADO (cada minuto, desde que se inicia sesión)
# =====================================================================
class EstadoMercado:
    """Decide si mostrar el aviso rojo y pausar el bot. Se prende cuando el mercado está malo y se apaga
    cuando vuelve a estar óptimo (o lleva 5 minutos seguidos aceptable)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.aviso = False
        self.operar_igual = False      # el cliente decidió operar aunque el mercado esté malo
        self.racha_viable = 0
        self.ultimo = None             # último diagnóstico
        self.cambio = 0

    def actualizar(self, diag):
        with self.lock:
            antes = self.aviso
            n = diag["nivel"]
            if n == "malo":
                self.aviso = True; self.racha_viable = 0
            elif n == "optimo":
                self.aviso = False; self.racha_viable = 0
            else:
                self.racha_viable += 1
                if self.aviso and self.racha_viable >= 5:
                    self.aviso = False
            if not self.aviso:
                self.operar_igual = False   # la próxima vez que se ponga malo vuelve a pausar
            self.ultimo = dict(diag, aviso=self.aviso)
            if antes != self.aviso:
                self.cambio = time.time()
            return antes, self.aviso

    @property
    def pausa(self):
        return self.aviso and not self.operar_igual

    def resumen(self):
        with self.lock:
            if not self.ultimo:
                return {"leyendo": True, "aviso": False}
            return dict(self.ultimo, aviso=self.aviso, operar_igual=self.operar_igual, leyendo=False)


MERCADO = EstadoMercado()


def diagnosticar_mercado(pct_ok, pct_deb, regs, acierto, cfg, n_acierto=0):
    """Junta las mediciones y dice: malo / viable / óptimo, con los motivos en palabras.
    Lo que más pesa es cómo vienen acertando las señales (es lo que de verdad dice si el bot puede ganar)."""
    total = sum(regs.values()) or 1
    lateral = (regs.get("lateral", 0) + regs.get("muerto", 0)) / total
    motivos = []
    muy_malo = acierto is not None and n_acierto >= 20 and acierto < 0.48
    if acierto is not None and n_acierto >= 12 and acierto < 0.53:
        motivos.append(f"señales recientes acertando {acierto*100:.0f} %")
    if lateral >= 0.60:
        motivos.append(f"{lateral*100:.0f} % de los pares de lado a lado o sin movimiento")
    if pct_deb > 0.55:
        motivos.append(f"{pct_deb*100:.0f} % de velas sin cuerpo")
    if pct_ok is not None and pct_ok < 0.05:
        motivos.append(f"casi ningún par tiene estrategias sobre el {cfg['winrate_minimo']*100:.0f} %")
    if muy_malo or len(motivos) >= 2:
        nivel = "malo"
    elif not motivos and lateral < 0.45 and (acierto is None or acierto >= 0.60):
        nivel = "optimo"
    else:
        nivel = "viable"
    dominante = max(regs, key=regs.get) if regs else None
    return {"nivel": nivel, "motivos": motivos, "revisado": time.strftime("%H:%M"),
            "pares_ok": None if pct_ok is None else round(pct_ok, 3), "velas_debiles": round(pct_deb, 3),
            "regimen": dominante, "regimen_txt": REGIMENES.get(dominante, ""),
            "regimen_pct": round(regs.get(dominante, 0) / total, 3) if dominante else None,
            "regimenes": {k: round(v / total, 3) for k, v in regs.items()},
            "acierto": None if acierto is None else round(acierto, 3)}


class MonitorMercado:
    """Lee el mercado cada minuto desde que el cliente inicia sesión (antes de arrancar el bot)."""
    PARES = 15

    def __init__(self, broker, cfg):
        self.b = broker
        self.cfg = cfg
        self.parar = False
        threading.Thread(target=self._hilo, daemon=True).start()

    def _hilo(self):
        while not self.parar:
            t0 = time.time()
            try:
                self.revisar()
            except Exception:
                pass
            while not self.parar and time.time() - t0 < 60:
                time.sleep(1)

    def revisar(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos()
        lista = []
        for par, pays in activos.items():
            otc = par.endswith("-OTC")
            if (otc and not cfg.get("incluir_otc", True)) or (not otc and not cfg.get("incluir_mercado_real", True)):
                continue
            pago = pays.get("turbo") or pays.get("binary") or 0
            if pago >= cfg.get("payout_minimo", 0.8):
                lista.append((pago, par))
        lista.sort(reverse=True)
        regs, ok, total, deb, ndeb = {}, 0, 0, 0, 0
        gan = sen = 0
        for _, par in lista[: self.PARES]:
            if self.parar:
                return
            try:
                velas = self.b.velas(par, 1, 160)
            except Exception:
                continue
            if len(velas) < VENTANA + 40:
                continue
            r = regimen(velas)
            if r:
                regs[r] = regs.get(r, 0) + 1
            for i in range(len(velas) - 15, len(velas)):
                prom = sum(abs(x["c"] - x["o"]) for x in velas[i - 10:i]) / 10
                deb += vela_debil(velas[i], prom); ndeb += 1
            # catalogación rápida con lo viejo y prueba con las últimas 30 velas
            viejas = velas[:-30]
            total += 1
            buena = False
            for nombre, fn in ESTRATEGIAS.items():
                n, g0 = catalogar(viejas, fn)[:2]
                if n >= 8 and g0 / n >= cfg.get("winrate_minimo", 0.75):
                    buena = True
                    for i in range(len(velas) - 31, len(velas) - 1):
                        d = fn(velas[i - VENTANA + 1: i + 1])
                        if d:
                            sen += 1
                            gan += color(velas[i + 1]) == (1 if d == "call" else -1)
            ok += buena
        if not total:
            return
        diag = diagnosticar_mercado(ok / total, deb / ndeb if ndeb else 0.0, regs,
                                    gan / sen if sen >= 12 else None, cfg, sen)
        MERCADO.actualizar(diag)


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

def _consultar_licencia(cuenta):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión."""
    import requests
    try:
        r = requests.get(LICENCIA_URL, timeout=15, params={
            "cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
            "build": BUILD_BOT, "v": VERSION_BOT})
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c)
        if r is None:
            sin_red = True; continue
        respuestas[c] = r
        if r == "VALID":
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}")}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, ("Este correo / ID de IQ Option NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de IQ Option: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        cliente._iqbot_parche = True
    except Exception:
        pass
    _conexion_segura()


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas (la librería tiene un solo buzón para velas)
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        try:
            ok, motivo = con_timeout(api.connect, 60)
        except TimeoutError:
            return None, ("IQ Option no respondió. Revisa tu internet; si estás en una red que "
                          "bloquea IQ Option (trabajo, universidad, operador), prueba otra red.")
        except json.JSONDecodeError as e:
            crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
            return None, ("IQ Option devolvió una respuesta inesperada al iniciar sesión "
                          "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                          "navegador para confirmar que tu cuenta abre bien."
                          + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
        except Exception as e:
            if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                return None, ("No se pudo verificar la conexión segura con IQ Option (certificado no válido). "
                              "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                              "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
            libreria_conecto(False, culpa_de_libreria=True)
            return None, f"Error de conexión: {e}"
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset

    def dormir(self, s):
        time.sleep(s)

    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t == 1: out["REAL"] = (bal.get("amount"), bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (bal.get("amount"), bal.get("currency", ""))
        return out

    def usar_cuenta(self, cuenta):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)

    def saldo(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else "?"
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta)
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self):
        """{par: {"turbo": 0.87, "binary": 0.85}} solo con pares abiertos. También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        return res

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock:                       # la librería tiene un solo "buzón" para velas
            inner.candles.candles_data = None
            inner.getcandles(aid, tf_min * 60, cantidad + 1, time.time())
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        ok = _esperar(lambda: True if inner.candle_generated_check[par][60] is True else None, 10, 0.1)
        self.vivo[par] = bool(ok)
        return bool(ok)

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- ánimo de los traders (dato para las IAs) ----------
    def suscribir_animo(self, par):
        try:
            from iqoptionapi import constants as OP
            self.inner.api.subscribe_Traders_mood(OP.ACTIVES[par])
            return True
        except Exception:
            return False

    def animo(self, par):
        """Fracción de traders de IQ Option comprando CALL en ese par (0 a 1), o None si no hay dato."""
        try:
            from iqoptionapi import constants as OP
            v = self.inner.api.traders_mood.get(OP.ACTIVES[par])
            return float(v) if v is not None else None
        except Exception:
            return None

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(float(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise TimeoutError("IQ Option no confirmó la orden (revisa la plataforma)")
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > limite - 230 and time.time() - ultimo_hist > 3:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

    def resultado(self, oid, exp_min, monto, payout):
        """Resultado neto de la orden y cómo se confirmó.
        1) aviso de cierre con estado explícito, 2) confirmación en el historial oficial.
        Si las dos fuentes no coinciden, manda el historial."""
        limite = time.time() + exp_min * 60 + 240
        rapido, via = None, ""
        t_rapido = None
        ultimo_hist = 0
        while time.time() < limite:
            if rapido is None:
                rapido, via = self._leer_rapido(oid, monto)
                if rapido is not None:
                    t_rapido = time.time()
            if self.conectado and time.time() - ultimo_hist > 3 and (rapido is not None or time.time() > limite - 230):
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if oficial is not None:
                    if oficial == "win":
                        oficial = round(monto * (payout or 0.8), 2)
                        return oficial, "historial (monto estimado por payout)"
                    if rapido not in (None, "win") and abs(oficial - rapido) > 0.009:
                        return oficial, f"historial (corrigió {rapido:+.2f})"
                    return oficial, "historial"
            # si el historial no responde en 15 s, se usa el aviso de cierre
            if rapido is not None and t_rapido and time.time() - t_rapido > 15:
                if rapido == "win":
                    return round(monto * (payout or 0.8), 2), via + " (monto estimado por payout)"
                return rapido, via + " (sin confirmar en historial)"
            time.sleep(0.3)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 5, 15)               # minutos
LIMITE_ENTRADA_SEG = {1: 3, 2: 3, 3: 4, 5: 5, 10: 8, 15: 8}    # si la orden sale tarde, máx. segundos después del cierre
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes
RESCATE_GALE = 0.60                            # modo automático: gale en el mismo par si el gale rescata 60 %+
FUERTE_WR = 0.80                               # mercado malo y en negativo: solo señales de 80 %+ ...
FUERTE_IA = 0.58                               # ... y que las IAs vean con 58 %+
SEPARACION_ORDENES_SEG = 0.25                  # varias órdenes al tiempo: se escalonan para que todas salgan antes del cero
REFRESCO_CATALOGO_VELAS = 10                   # recatalogar cada N velas
REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
MAX_PARES = 250                                # máximo de pares con velas en vivo (IQ suele tener 150-200 abiertos)


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        act = cfg["estrategias_activas"]
        if act == "todas" or cfg.get("estrategias_auto", True):
            self.estrategias = dict(ESTRATEGIAS)
        else:
            nombres = [ALIAS_ESTRATEGIAS.get(k, k) for k in act]
            self.estrategias = {k: ESTRATEGIAS[k] for k in nombres if k in ESTRATEGIAS} or dict(ESTRATEGIAS)
        self.tfs = sorted(cfg["temporalidades"])
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.total_abiertos = 0
        self.hist = {}           # (par, tf) -> velas
        self.cat = {}            # (par, tf) -> {"t": ultima vela catalogada, "res": {estrategia: (n, g0, g1)}}
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.prox_cierre = None
        self.tfs_prox = []
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.t_saldo = time.time()
        self.ultimo_cierre = 0.0
        self.ajustes_saldo = 0
        self.ultima_lectura_pares = None
        self.seq = 0
        self.reconexiones = 0
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.enfriar = {}
        self.ia = inteligencia()  # Inteligencia LS (aprende de cada señal y operación)
        self.ia_pend = []        # señales esperando que cierre su vela para aprender el resultado
        self.mo_cola = []        # señales resueltas que esperan a las IA 2, 5 y 6 (se procesan sin apuro)
        threading.Thread(target=modelos().arrancar_con_historial, args=(self.ia,), daemon=True).start()
        self.ia_vistas = set()   # (par, tf, vela) ya contadas como bloqueadas por la IA
        self.virtuales = deque(maxlen=600)   # (hora, ganó) de las señales que pasaron todos los filtros
        self.pausa_inicio = MERCADO.aviso and not MERCADO.operar_igual   # mercado malo al iniciar: arranca en pausa
        self.confianza = None    # medidor del panel (lo que opinan las 6 IAs de la mejor señal)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.mercado = None      # último diagnóstico del mercado
        self.ultimo_escaneo = {}
        self.pausado = False
        self.resultados = deque(maxlen=200)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.inicio_sesion = time.time()
        self.reserva = None      # señales del último cierre que no entraron porque había operaciones por vencer
        self.ultima_entrada = None

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)

    def monto_gale(self, ultimo, perdido, base, payout):
        if self.cfg["rec_modo"] == "multiplicador":
            m = ultimo * float(self.cfg["rec_multiplicador"])
        else:  # automático: recupera lo perdido en esta operación + la ganancia de la entrada base
            p = payout or 0.85
            m = (perdido + base * p) / p
        return max(1.0, round(m, 2))

    # ---------- pares abiertos (hilo en segundo plano) ----------
    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos()
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            if es_otc and not cfg["incluir_otc"]: continue
            if not es_otc and not cfg["incluir_mercado_real"]: continue
            pago = pays.get("turbo") or pays.get("binary")
            if pago is not None and pago < cfg["payout_minimo"]: continue
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc))
        lista.sort(key=lambda x: (x[1].get("turbo") or x[1].get("binary") or 0), reverse=True)
        lista = lista[: min(int(cfg.get("max_pares", 20)), MAX_PARES)]
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": pays.get("turbo") or pays.get("binary"), "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        self.total_abiertos = len(activos)
        self.ultima_lectura_pares = time.time()
        return len(activos), len(lista)

    def hilo_pares(self):
        espera = 0
        ultimo_saldo = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Analizando los {sel} de mejor payout.", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par): continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                try:
                    ok = self.b.iniciar_vivo(par)
                    if ok:
                        self.b.suscribir_animo(par)
                except Exception as e:
                    ok = False
                if ok is False:                       # no envió velas: se deja en paz 10 min
                    self.bloqueados[par] = time.time() + 600
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in list(self.b.vivo) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.t_saldo = pedido
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.ajustes_saldo += 1
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.log(f"=== STOP {'WIN' if self.pnl > 0 else 'LOSS'} alcanzado: {self.pnl:+.2f} ===",
                             "bold green" if self.pnl > 0 else "bold red")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})..."
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------
    def evaluar(self, par, tf, velas, payout):
        """Devuelve (candidato o None, texto_estado, estilo)."""
        cfg = self.cfg
        ultima = velas[-VENTANA:]
        cerradas = velas[:-1]                  # sin la vela que se está formando
        cat = self.cat.get((par, tf), {}).get("res", {})
        usa_gale = cfg["recuperacion"] == "martingala" and cfg["rec_max"] >= 1
        pago = payout or cfg["payout_minimo"]
        senales, descartes = {}, []
        fuerte = vela_fuerte(ultima) if cfg.get("solo_velas_fuertes", True) else True
        inicio = ultima[-1]["t"] + tf * 60          # la vela donde entraría la operación
        ia = self.ia
        ia3 = arboles()
        try:
            reg = regimen(velas[-VENTANA - 10:])     # tipo de mercado de este par ahora
        except Exception:
            reg = None
        auto = cfg.get("estrategias_auto", True)
        animo = self.b.animo(par) if hasattr(self.b, "animo") else None      # lado de los traders (dato para las IAs)
        mo = modelos()
        try:
            vpat = vector_patron(ultima)               # forma de las velas (IA 5)
        except Exception:
            vpat = None
        juez = mo.juez_lista()
        filtra = cfg.get("ia_filtra", True)
        pu_cache = False
        for nombre, fn in self.estrategias.items():
            try:
                d = fn(ultima)
            except Exception:
                d = None
            if not d: continue
            n, g0, g1, _nr, _gr, g2, g3 = (tuple(cat.get(nombre, ())) + (0,) * 7)[:7]
            if n < cfg["min_senales_catalogo"]:
                descartes.append(f"{nombre} pocas señales"); continue
            wr0, wr1 = g0 / n, g1 / n
            if wr0 < cfg["winrate_minimo"]:
                descartes.append(f"{nombre} {wr0*100:.0f}%"); continue
            # la IA aprende de TODAS las señales que pasan la catalogación (también las que se descartan después)
            try:
                claves = rasgos_mercado(ultima, par, tf, d, nombre, wr0, pago, inicio, animo)
                if reg:
                    claves += [f"rg:{reg}", f"e|rg:{nombre}|{reg}"]
            except Exception:
                claves = None
            pend = None
            if claves:
                pend = {"par": par, "tf": tf, "dir": d, "fin": inicio + tf * 60, "k": claves, "paso": False,
                        "e": nombre, "reg": reg, "st": tramo_sent(animo, d),
                        "h": time.localtime(inicio).tm_hour, "v": vpat}
                if len(self.ia_pend) < 6000:
                    self.ia_pend.append(pend)
            if auto and ia.estrategia_apagada(nombre):
                descartes.append(f"{nombre} desactivada por malos resultados"); continue
            st = tramo_sent(animo, d)
            if not fuerte and nombre not in SIN_FILTRO_CUERPO:
                descartes.append(f"{nombre} vela sin cuerpo fuerte"); continue
            ev = valor_esperado(wr0, wr1, pago, usa_gale)
            if ev <= cfg["ev_minimo"]:
                descartes.append(f"{nombre} EV {ev*100:+.0f}%"); continue
            prob, ajuste = ia.evaluar(claves) if claves else (None, 0.0)
            p3 = ia3.probabilidad(claves) if claves else None
            g_prom = ia.d["ganadas"] / ia.d["total"] if ia.d["total"] else 0.5
            bloquea3 = p3 is not None and (p3 < 0.50 or p3 < g_prom - 0.07)
            p1 = prob if ia.activa else None
            p2 = mo.p_logit(claves) if claves else None
            if pu_cache is False:                        # IA 5 se consulta una sola vez por par
                pu_cache = mo.p_sube(vpat) if mo.mem_lista() else None
            p5 = None if pu_cache is None else (pu_cache if d == "call" else 1 - pu_cache)
            pj = mo.p_juez(p1, p2, ia3.probabilidad(claves, True) if claves else None, p5)[0]
            if not filtra:                               # el usuario apagó el filtro: las IAs solo ordenan
                bloquea_ia = False; quien = ""
            elif juez:                                   # la Juez ya demostró que sirve: ella decide
                margen = JUEZ_MARGEN_ALTA if cfg.get("ia_precision_alta") else JUEZ_MARGEN
                bloquea_ia = pj < mo.base() + margen
                quien = f"Juez {pj*100:.0f}%"
            else:
                bloquea_ia = ia.bloquea(prob, ajuste) or bloquea3
                quien = f"{prob*100:.0f}%" if ia.bloquea(prob, ajuste) else f"cerebro {(p3 or 0)*100:.0f}%"
            if bloquea_ia:
                descartes.append(f"{nombre} la IA lo ve flojo ({quien})")
                vista = (par, tf, inicio)
                if vista not in self.ia_vistas:
                    self.ia_vistas.add(vista); ia.anotar_bloqueo()
                    if len(self.ia_vistas) > 3000: self.ia_vistas.clear()
                continue
            conf = acierto_confiable(g0, n)
            # martingala: también cuenta cuántas veces se salvó con los gales que tienes configurados
            wg = wr0
            puntaje = conf
            if usa_gale:
                gk = (g0, g1, g2, g3)[max(0, min(3, int(cfg["rec_max"])))]
                wg = gk / n
                puntaje = (conf + acierto_confiable(gk, n)) / 2
            if juez:
                prob = pj
                puntaje = 0.5 * puntaje + 0.5 * pj        # la Juez también decide el orden
            else:
                probs = [x for x in (p1, p3) if x is not None]
                if probs:
                    prob = sum(probs) / len(probs)        # IA 1 + IA 3 juntas
                    puntaje = 0.5 * puntaje + 0.5 * prob
            senales.setdefault(d, []).append((nombre, wr0, wr1, n, ev, conf, puntaje, 0, 0, wg, prob, pend,
                                              p1, p3, reg, st, p2, p5, pj))
        if "call" in senales and "put" in senales:
            bc = max(x[6] for x in senales["call"]); bp = max(x[6] for x in senales["put"])
            if abs(bc - bp) < 0.05:
                return None, f"M{tf} señales contrarias, no entra", "yellow"
            senales.pop("put" if bc > bp else "call")
        for d, lst in senales.items():
            if len(lst) < cfg["confluencia_minima"]:
                return None, f"M{tf} {d.upper()} sin confluencia ({len(lst)}/{cfg['confluencia_minima']})", "yellow"
            lst.sort(key=lambda x: (x[6], x[5], x[1], x[3]), reverse=True)
            mejor = lst[0]                      # la estrategia con mejor puntaje en este momento
            c = {"par": par, "tf": tf, "dir": d, "payout": pago,
                 "estrategia": "+".join(x[0] for x in lst),
                 "wr": mejor[1], "wr_g1": mejor[2], "n": mejor[3], "conf": mejor[5],
                 "puntaje": mejor[6] + 0.01 * (len(lst) - 1), "nr": mejor[7], "gr": mejor[8], "wg": mejor[9],
                 "ia": mejor[10] if (self.ia.activa or arboles().lista or juez) else None, "ia_keys": (mejor[11] or {}).get("k"),
                 "p1": mejor[12], "p3": mejor[13], "reg": mejor[14], "st": mejor[15],
                 "p2": mejor[16], "p5": mejor[17], "pj": mejor[18] if juez else None,
                 "ev": mejor[4] + 0.02 * (len(lst) - 1)}
            if mejor[11]:
                mejor[11]["paso"] = True                # esta señal pasó todos los filtros
            txt = f"SEÑAL {d.upper()} M{tf} · {c['estrategia']} {mejor[1]*100:.0f}%"
            return c, txt, ("bold green" if d == "call" else "bold red")
        if descartes:
            return None, f"M{tf} descartada: {', '.join(descartes[:2])}", "dim"
        return None, f"M{tf} sin señal", "dim"

    def preparar(self, tfs_c, prox):
        """Durante la vela: descarga historial, cataloga y deja todo listo para el cierre."""
        cfg = self.cfg
        limite = prox - self.adelanto_analisis() - 1.5
        for par in list(self.seleccion):
            for tf in tfs_c:
                if self.detener or not self.b.conectado or self.b.ahora() > limite:
                    return
                if par in self.pares_en_uso:
                    continue
                k = (par, tf)
                c = self.cat.get(k)
                try:
                    if not c or (prox - c["t"]) >= REFRESCO_CATALOGO_VELAS * tf * 60:
                        self.fase = f"Catalogando {par} M{tf}"
                        self.estado(par, f"Catalogando M{tf}...", "yellow", 2)
                        velas = self.b.velas(par, tf, cfg["velas_catalogo"])
                        if len(velas) < VENTANA + 20:
                            self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); continue
                        self.hist[k] = velas
                        res = {n: catalogar(velas, fn) for n, fn in self.estrategias.items()}
                        self.cat[k] = {"t": velas[-1]["t"], "res": res}
                        buenas = sum(1 for r in res.values()
                                     if r[0] >= cfg["min_senales_catalogo"] and r[1] / r[0] >= cfg["winrate_minimo"])
                        self.cat[k]["activas"] = buenas
                        if not buenas:
                            self.estado(par, f"M{tf}: ninguna estrategia llega al {cfg['winrate_minimo']*100:.0f}%", "dim", 3)
                            continue
                    elif tf > 1:
                        # velas M5/M15 cerradas más recientes (la que se forma se arma con las M1 en vivo)
                        hist = self.hist.get(k, [])
                        if not hist or hist[-1]["t"] < prox - 2 * tf * 60:
                            nuevas = self.b.velas(par, tf, 4)
                            por_t = {v["t"]: v for v in hist}
                            for v in nuevas: por_t[v["t"]] = v
                            self.hist[k] = [por_t[t] for t in sorted(por_t)][-cfg["velas_catalogo"]:]
                    vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
                    act = (self.cat.get(k) or {}).get("activas")
                    if act == 0:
                        self.estado(par, f"M{tf}: ninguna estrategia llega al {cfg['winrate_minimo']*100:.0f}%", "dim", 3)
                        continue
                    txt_act = f"{act} estrategias activas, " if act else ""
                    self.estado(par, f"Listo para el cierre M{tf} ({txt_act}{vivo})", "" if self.b.vivo.get(par) else "dim", 3)
                except Exception as e:
                    self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}

    def analizar_antes_del_cierre(self, tfs_c, prox):
        """1,2 s antes del cierre: toma la vela que se está formando como si ya cerrara y busca señales."""
        cfg = self.cfg
        cands, revisados = [], 0
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        vencen = {o["par"] for o in list(self.abiertas.values()) if abs(o["vence"] - prox) < 1}
        orden = [p for p in self.seleccion if p in vencen] + [p for p in self.seleccion if p not in vencen]
        for par in orden:
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:      # nunca se pasa del momento de enviar la orden
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso and par not in vencen:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.cat:
                    continue
                formando = self.vela_en_formacion(m1, tf, prox)
                if not formando:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v       # M1 cerradas que llegaron en vivo
                    cerradas = [por_t[t] for t in sorted(por_t)][-cfg["velas_catalogo"]:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < formando["t"]]
                if not cerradas or cerradas[-1]["t"] != formando["t"] - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.cat.pop(k, None)   # fuerza recatalogar
                    continue
                revisados += 1
                tipo = "turbo" if tf <= 5 else "binary"
                pago = info.get("pays", {}).get(tipo) or info.get("payout")
                c, txt, est = self.evaluar(par, tf, cerradas + [formando], pago)
                self.estado(par, txt, est, 1 if c else 3)
                if c:
                    c["inicio_vela"] = prox
                    cands.append(c)
        return cands, revisados

    def ia_resolver(self, prox):
        """Las señales cuya vela ya cerró: la IA aprende si habrían ganado o perdido."""
        quedan = []
        velas_par = {}
        for p in self.ia_pend:
            if p["fin"] > prox - 60:                 # su vela todavía no cierra
                quedan.append(p); continue
            par = p["par"]
            if par not in velas_par:
                velas_par[par] = self.b.velas_vivo(par) if self.b.vivo.get(par) else []
            vela = self.vela_en_formacion(velas_par[par], p["tf"], p["fin"]) if velas_par[par] else None
            if vela is None:
                if p["fin"] > prox - 20 * 60:
                    quedan.append(p)                 # quizá llegan las velas en el próximo minuto
                continue
            col = color(vela)
            if col == 0:
                continue                             # empate: no enseña nada
            gano = col == (1 if p["dir"] == "call" else -1)
            # lo que opinaban la IA 1 y la IA 3 ANTES de saber el resultado (para medirlas con honestidad)
            try:
                p1 = self.ia.evaluar(p["k"])[0] if self.ia.activa else None
                p3 = arboles().probabilidad(p["k"], True)
            except Exception:
                p1 = p3 = None
            if len(self.mo_cola) < 5000:
                self.mo_cola.append((p["k"], p.get("v"), p["dir"], gano, p1, p3, (par, p["tf"], p["fin"]), col == 1))
            self.ia.aprender(p["k"], gano, extra={"v": p["v"]} if p.get("v") else None)
            if p.get("e"):
                cambio = self.ia.anotar_estrategia(p["e"], gano)
                if cambio == "off":
                    self.log(f"⛔ {p['e']} se desactivó: {self.ia.d['estr'][p['e']].get('motivo', 'malos resultados')}. "
                             f"Sigue en observación y vuelve sola si mejora.", "yellow")
                elif cambio == "on":
                    self.log(f"✔ {p['e']} volvió a activarse: mejoró en sus últimas señales.", "green")
            if p["paso"]:
                self.ia.anotar_paso(gano)
                self.virtuales.append((time.time(), gano))
        self.ia_pend = quedan

    def aprender_modelos(self):
        """Justo después del cierre (lejos del momento de enviar órdenes): aprenden las IA 2, 5 y 6."""
        mo = modelos()
        cola, self.mo_cola = self.mo_cola, []
        cache, momentos, calculos = {}, {}, 0
        for k, v, d, gano, p1, p3, clave, subio in cola:
            if clave not in cache:
                if v is not None and calculos < 80:
                    cache[clave] = mo.p_sube(v); calculos += 1
                else:
                    cache[clave] = None
                momentos[clave] = (v, subio)
            mo.aprender(k, v, d, gano, p1, p3, cache[clave])
        for v, subio in momentos.values():
            mo.recordar(v, subio)
        mo.guardar()

    def revisar_mercado(self):
        """Cada minuto: ¿el mercado está lateral/errático? Si está malo, el bot se pausa solo."""
        cfg = self.cfg
        sel = set(self.seleccion)
        cats = [v for k, v in self.cat.items() if k[0] in sel and "activas" in v]
        if len(cats) < 3:
            return
        pct_ok = sum(1 for v in cats if v["activas"] > 0) / len(cats)
        debiles = total = 0
        regs = {}
        tf_base = min(self.tfs)
        for par in sel:
            h = self.hist.get((par, tf_base)) or []
            if len(h) < 70:
                continue
            r = regimen(h[-70:])
            if r:
                regs[r] = regs.get(r, 0) + 1
            for i in range(len(h) - 15, len(h)):
                prom = sum(abs(x["c"] - x["o"]) for x in h[i - 10:i]) / 10
                debiles += vela_debil(h[i], prom); total += 1
        recientes = [g for t, g in self.virtuales if t > time.time() - 30 * 60]
        acierto = sum(recientes) / len(recientes) if len(recientes) >= 12 else None
        diag = diagnosticar_mercado(pct_ok, debiles / total if total else 0.0, regs, acierto, cfg, len(recientes))
        antes, ahora = MERCADO.actualizar(diag)
        self.mercado = MERCADO.resumen()
        if ahora and not antes:
            self.log("⚠ Mercado lateral y errático (" + "; ".join(diag["motivos"]) + "). "
                     "El bot se pausa hasta que mejore. Puedes elegir operar de todos modos.", "bold yellow")
        elif antes and not ahora:
            self.log("✔ El mercado mejoró: el bot vuelve a operar normalmente.", "bold green")

    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def bandido_resumen(self):
        """IA 4: la estrategia que el bandido prefiere ahora (mayor probabilidad media con 10+ señales)."""
        mejor = None
        for n, e in self.ia.d["estr"].items():
            if e.get("off") or len(e["r"]) < 10:
                continue
            m, k = self.ia.bandido(n, sortear=False)
            if not mejor or m > mejor[1]:
                mejor = (n, m, k)
        return {"estrategia": mejor[0], "prob": round(mejor[1], 3), "senales": mejor[2]} if mejor else None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))

    def libre_para_entrenar(self):
        """La IA 3 entrena en segundo plano, pero nunca en los segundos cercanos a un cierre de vela."""
        prox = self.prox_cierre
        if not prox:
            return True
        ahora = self.b.ahora()
        return prox - ahora > 6 or ahora - prox > 3

    # ---------- pausa por mercado malo ----------
    def pausa_mercado(self):
        """Mercado malo: al iniciar la sesión el bot arranca en pausa (decide el cliente). Ya operando, solo se
        pausa si va en positivo, sin operaciones abiertas y sin recuperación pendiente."""
        if not MERCADO.aviso or MERCADO.operar_igual:
            self.pausa_inicio = False
            return False
        if self.pausa_inicio:
            return True
        return self.pnl > 0 and not self.abiertas and self.nivel == 0

    def modo_estricto(self):
        """Mercado malo y el bot siguió operando (en negativo o recuperando): solo señales fuertes."""
        return MERCADO.aviso and not MERCADO.operar_igual and not self.pausa_mercado()

    @staticmethod
    def rescate(s):
        """De cada 100 veces que esta estrategia perdió en este par, cuántas se salvó en la vela siguiente."""
        wr0, wr1 = s.get("wr") or 0, s.get("wr_g1") or 0
        return (wr1 - wr0) / (1 - wr0) if wr0 < 0.999 else 0.0

    def _estimar(self, o):
        """Antes del cierre: ¿la operación que vence va ganando o perdiendo? (precio en vivo contra el de entrada)"""
        precio = self.precio_actual(o["par"])
        if precio is None or not o.get("entrada"):
            return "dudoso"
        h = self.hist.get((o["par"], 1)) or []
        rangos = [v["h"] - v["l"] for v in h[-14:]]
        margen = 0.12 * (sum(rangos) / len(rangos)) if rangos else 0.0
        dif = precio - o["entrada"]
        if abs(dif) <= margen:
            return "dudoso"                               # demasiado cerca del precio de entrada: no se adivina
        return "ganando" if (dif > 0) == (o["dir"] == "call") else "perdiendo"

    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))

    def confianza_de(self, c):
        """Medidor del panel: qué opina cada una de las 6 IAs de esta señal. Si la Juez ya demostró que sirve,
        el número grande es su probabilidad; si no, el promedio de las que opinan."""
        ia, mo = self.ia, modelos()
        g = ia.d["ganadas"] / ia.d["total"] if ia.d["total"] else 0.5
        p0 = mo.base()
        votos, valores = [], []
        def votar(v, umbral):
            if v is None:
                votos.append("gris"); return
            valores.append(v); votos.append("ok" if v >= umbral else "duda")
        votar(c.get("p1"), g)                                                       # IA 1
        votar(c.get("p2"), p0)                                                      # IA 2
        votar(c.get("p3"), g)                                                       # IA 3
        m, n = ia.bandido(c["estrategia"].split("+")[0], sortear=False)
        votar(m if n >= 10 else None, ESTR_EQUILIBRIO)                              # IA 4
        votar(c.get("p5"), p0)                                                      # IA 5
        pj = c.get("pj")
        votar(pj, p0 + JUEZ_MARGEN)                                                 # IA 6
        if pj is not None:
            valor = round(100 * pj)
        else:
            valor = round(100 * sum(valores) / len(valores)) if valores else None
        return {"valor": valor, "votos": votos, "par": c["par"], "dir": c["dir"], "juez": pj is not None}

    def lectura_vivo(self, o, prox):
        """Gale con cambio de dirección: lee el par EN VIVO justo antes del cierre y decide CALL o PUT.
        Votan: las estrategias de ese par ahora, el impulso de los últimos 15 s, la vela que se forma
        y la Memoria de patrones (IA 5). Devuelve (dirección, puntaje, detalle)."""
        cfg = self.cfg
        par, tf = o["par"], o["tf"]
        votos, pesos, detalle = [], [], []
        m1 = self.b.velas_vivo(par) if self.b.vivo.get(par) else []
        formando = self.vela_en_formacion(m1, tf, prox) if m1 else None
        k = (par, tf)
        cerradas = [v for v in self.hist.get(k, []) if not formando or v["t"] < formando["t"]]
        velas = (cerradas + [formando])[-VENTANA:] if formando else cerradas[-VENTANA:]
        atr = _atr(velas) if len(velas) >= 14 else 0.0
        # 1) estrategias de ese par, pesadas por su acierto en el catálogo
        cat = self.cat.get(k, {}).get("res", {})
        sc = tot = 0.0
        if len(velas) >= 30:
            for nombre, fn in self.estrategias.items():
                try:
                    d = fn(velas)
                except Exception:
                    d = None
                r = cat.get(nombre)
                if not d or not r or r[0] < cfg["min_senales_catalogo"]:
                    continue
                w = max(0.0, r[1] / r[0] - 0.5)
                sc += w if d == "call" else -w; tot += w
        if tot > 0:
            votos.append(sc / tot); pesos.append(0.35); detalle.append(f"estrategias {sc / tot:+.2f}")
        # 2) impulso de los últimos 15 segundos
        ticks = list(o.get("ticks") or [])
        ahora = self.b.ahora()
        viejos = [p for t, p in ticks if t <= ahora - 15]
        p_ahora = self.precio_actual(par) or (ticks[-1][1] if ticks else None)
        if viejos and p_ahora is not None and atr > 0:
            imp = max(-1.0, min(1.0, (p_ahora - viejos[-1]) / (0.3 * atr)))
            votos.append(imp); pesos.append(0.25); detalle.append(f"impulso 15 s {imp:+.2f}")
        # 3) la vela que se está formando
        if formando and formando["h"] > formando["l"]:
            cu = (formando["c"] - formando["o"]) / (formando["h"] - formando["l"])
            votos.append(cu); pesos.append(0.20); detalle.append(f"vela actual {cu:+.2f}")
        # 4) IA 5: momentos parecidos del pasado
        mo = modelos()
        if mo.mem_lista():
            pu = mo.p_sube(vector_patron(velas)) if velas else None
            if pu is not None:
                vm = max(-1.0, min(1.0, (pu - 0.5) * 4))
                votos.append(vm); pesos.append(0.20); detalle.append(f"memoria {pu * 100:.0f}% sube")
        puntaje = sum(v * w for v, w in zip(votos, pesos)) / sum(pesos) if pesos else 0.0
        if abs(puntaje) >= 0.05:
            return ("call" if puntaje > 0 else "put"), puntaje, detalle
        # empate: decide el último movimiento del precio (3 s); si no se movió, sigue la dirección original
        cortos = [p for t, p in ticks if t <= ahora - 3]
        if cortos and p_ahora is not None and p_ahora != cortos[-1]:
            detalle.append("empate: decide el último movimiento")
            return ("call" if p_ahora > cortos[-1] else "put"), puntaje, detalle
        detalle.append("empate sin movimiento: sigue la dirección original")
        return o["dir"], puntaje, detalle

    def disparar(self, cands, tfs_c, prox, revisados):
        """Elige UNA operación y la envía justo antes del cierre (nunca tarde).
        Si la operación que vence en este cierre va perdiendo, la recuperación (gale o nivel) se decide ya,
        con el análisis de esta misma vela: puede cambiar de dirección, y si no hay señal clara no hace gale."""
        cfg = self.cfg
        rec = cfg["recuperacion"]
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        ia = self.ia
        # IA 4 (bandido) ordena: mezcla el puntaje de cada señal con el azar inteligente de su estrategia
        for c in cands:
            c["bandido"] = ia.bandido(c["estrategia"].split("+")[0])
            c["orden"] = 0.6 * c.get("puntaje", c.get("conf", c["wr"])) + 0.4 * c["bandido"]
        cands.sort(key=lambda c: c["orden"], reverse=True)
        self.confianza = self.confianza_de(cands[0]) if cands else None
        self.ultimo_escaneo = {"hora": datetime.fromtimestamp(prox).strftime("%H:%M"), "revisados": revisados,
                               "senales": len(cands), "entradas": 0}
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        siguen = [o for o in abiertas if o["vence"] > prox + 1]
        if siguen:
            return                                         # una operación a la vez
        nivel, ciclo, par_gale, s_gale = self.nivel, self.ciclo_perdida, None, None
        for o in [o for o in abiertas if abs(o["vence"] - prox) < 1]:
            est = self._estimar(o)
            if est == "dudoso":
                self.log(f"{o['par']}: el precio está pegado al de entrada; se espera el resultado (no se arriesga "
                         f"otra entrada en este cierre).", "dim")
                return
            if est == "perdiendo" and rec != "ninguna":
                nivel = o["nivel_usado"] + 1
                ciclo = round(o["ciclo_antes"] + o["monto"], 2)
                par_gale, s_gale = o["par"], o
            elif est == "ganando":
                nivel, ciclo = 0, 0.0
        if nivel > int(cfg["rec_max"]):
            self.log(f"✘ Se agotaron las recuperaciones (−${ciclo:.2f}). Se vuelve a la entrada base.", "bold red")
            nivel, ciclo, par_gale = 0, 0.0, None
        recuperando = nivel > 0 and rec != "ninguna"
        if self.pausado:
            return
        if not recuperando and self.pausa_mercado():
            return
        lista = cands
        if self.modo_estricto():
            lista = [c for c in cands if c["wr"] >= FUERTE_WR and (c.get("ia") is None or c["ia"] >= FUERTE_IA)]
            if cands and not lista:
                self.estado_global = "Mercado malo: solo se aceptan señales fuertes"
        elegida, etiqueta = None, "ENTRADA"
        if recuperando:
            quiere_gale = rec == "martingala" or (rec == "auto" and s_gale and s_gale.get("rescate", 0) >= RESCATE_GALE)
            if quiere_gale and par_gale and s_gale:
                # gale SIEMPRE en el mismo par; la dirección la decide la lectura en vivo
                try:
                    d_gale, punt, det = self.lectura_vivo(s_gale, prox)
                except Exception as e:
                    d_gale, punt, det = s_gale["dir"], 0.0, [f"sin lectura ({str(e)[:40]})"]
                cambio = d_gale != s_gale["dir"]
                elegida = {"par": par_gale, "tf": s_gale["tf"], "dir": d_gale, "payout": s_gale.get("payout") or 0.8,
                           "estrategia": s_gale.get("estrategia", "Gale"), "wr": s_gale.get("wr") or 0.0,
                           "wr_g1": s_gale.get("wr") or 0.0, "n": s_gale.get("n") or 0, "conf": s_gale.get("conf"),
                           "wg": s_gale.get("wg"), "inicio_vela": prox, "cambio_dir": cambio,
                           "rescate_fijo": s_gale.get("rescate", 0.0)}
                etiqueta = f"GALE {nivel}"
                lectura = " · ".join(det) if det else "sin datos"
                if cambio:
                    self.log(f"↻ {par_gale}: el mercado giró; el gale va en {d_gale.upper()} (la entrada fue "
                             f"{s_gale['dir'].upper()}) · {lectura}", "cyan")
                else:
                    self.log(f"→ {par_gale}: el gale sigue en {d_gale.upper()} · {lectura}", "dim")
            else:
                otros = [c for c in lista if c["par"] != par_gale]
                elegida = otros[0] if otros else None
                etiqueta = f"NIVEL {nivel + 1}"
        else:
            elegida = lista[0] if lista else None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso and elegida["par"] != par_gale:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        if not self.puede_arriesgar(monto + sum(o["monto"] for o in abiertas)):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if self.b.ahora() > prox - anticipo:
            self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
            return
        elegida.update({"disparo": prox - anticipo, "monto": monto, "etiqueta": etiqueta,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0,
                        "rescate": elegida.get("rescate_fijo", self.rescate(elegida))})
        self.ultimo_escaneo["entradas"] = 1
        self.lanzar(elegida)

    # ---------- ejecución ----------
    def _tomar_suplente(self, s_rechazada):
        """Si IQ Option rechaza una entrada, toma la siguiente mejor señal del mismo cierre."""
        with self.lock:
            lista = s_rechazada.get("suplentes") or []
            while lista:
                c = lista.pop(0)
                if c["par"] not in self.pares_en_uso and self.bloqueados.get(c["par"], 0) < time.time():
                    self.pares_en_uso.add(c["par"])
                    c["suplentes"] = lista
                    return c
        return None

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        cfg = self.cfg
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.detener:
                return
            if self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s["inicio_vela"] + tf * 60
            t_envio = self.b.ahora()
            try:
                oid = self.b.comprar(monto, par, d, tf, expira)
            except Exception as e:
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} ${monto:.2f}: {e}", "bold red")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden; revísala en la plataforma.", "bold red")
                else:
                    self._bloquear(par, str(e))
                return
            precio_entrada = self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "wr": s["wr"], "conf": s.get("conf", s["wr"]), "n": s["n"], "wg": s.get("wg"),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "rescate": s.get("rescate", 0.0), "puntaje": s.get("puntaje")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            rel = t_envio - s["inicio_vela"]
            extra = f", IA {s['ia']*100:.0f}%" if s.get("ia") is not None else ""
            self.log(f"{etiqueta} {par} M{tf} {d.upper()} ${monto:.2f} · {s['estrategia']} "
                     f"({s['wr']*100:.0f}% en {s['n']} señales{extra}, payout {s['payout']*100:.0f}%) · "
                     f"enviada a {rel:+.2f}s del cierre", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real.", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                    elif res < 0:
                        n = s.get("nivel_usado", 0) + 1
                        ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                        if n > int(self.cfg["rec_max"]):
                            self.nivel, self.ciclo_perdida = 0, 0.0
                        else:
                            self.nivel, self.ciclo_perdida = n, ciclo
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S"),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and s.get("ia_keys"):
                self.ia.aprender(s["ia_keys"], res > 0, 2.0, {"real": 1})      # las reales pesan más
            if res != 0 and s.get("cambio_dir") is not None:
                modelos().anotar_gale(s["cambio_dir"], res > 0)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.log(f"=== STOP {'WIN' if self.pnl > 0 else 'LOSS'} alcanzado: {self.pnl:+.2f} ===",
                         "bold green" if self.pnl > 0 else "bold red")

    def _encadenar(self):
        """Al cerrar una operación justo en el cierre de vela, entra ya en la siguiente vela con la mejor señal
        de ese mismo cierre (en niveles, si se está recuperando, la de mayor acierto). Así no se pierde un minuto."""
        cfg = self.cfg
        if self.detener or self.pausado or MERCADO.pausa or not self.b.conectado:
            return
        with self.lock:
            r = self.reserva
            if not r or not r["cands"]:
                return
            ahora = self.b.ahora()
            ocupadas = self.activas() - 1                  # este hilo está terminando
            libres = cfg["max_operaciones_simultaneas"] - ocupadas
            recuperando = cfg["recuperacion"] == "niveles" and self.nivel > 0
            if recuperando:
                libres = min(libres, 1 - ocupadas)          # recuperando: una operación a la vez
            r["cands"].sort(key=orden_senal, reverse=True)
            elegidas = []
            for c in list(r["cands"]):
                if len(elegidas) >= libres:
                    break
                if ahora - r["prox"] > LIMITE_ENTRADA_SEG.get(c["tf"], 3):
                    continue
                if c["par"] in self.pares_en_uso or self.bloqueados.get(c["par"], 0) > time.time():
                    continue
                if not self.puede_arriesgar(self.monto_base() * (len(elegidas) + 1)):
                    break
                r["cands"].remove(c)
                self.pares_en_uso.add(c["par"])
                anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
                c["disparo"] = r["prox"] - anticipo if ahora < r["prox"] - anticipo else None
                c["suplentes"] = []
                elegidas.append(c)
        for c in elegidas:
            self.log(f"→ Entrada encadenada: {c['par']} M{c['tf']} entra ya en la vela que empezó "
                     f"({c.get('conf', c['wr'])*100:.0f}% confiable), sin esperar al próximo cierre.", "cyan")
            h = threading.Thread(target=self.operar, args=(c,), daemon=True)
            with self.lock_hilos:
                h.start(); self.hilos.append(h)

    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = [tf for tf in self.tfs if (prox // 60) % tf == 0
                             and expiracion_valida(tf, prox + tf * 60, prox - 1)]
                    self.prox_cierre, self.tfs_prox = prox, tfs_c
                    if not tfs_c:
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener); continue
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    self.ia_resolver(prox)
                    cands, revisados = self.analizar_antes_del_cierre(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, tfs_c, prox, revisados)
                    if self.pausado:
                        self.fase = "En pausa: analiza pero no abre operaciones"
                    elif self.pausa_mercado():
                        self.fase = "Mercado malo: en pausa hasta que mejore"
                    self.fase = "Esperando el cierre de vela"
                    try:
                        self.revisar_mercado()
                        self.ia.guardar()
                        arboles().quiza_entrenar(self.ia.d["total"], self.libre_para_entrenar)
                    except Exception:
                        pass
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                    self.aprender_modelos()
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.ia.guardar(forzar=True)
            modelos().guardar(forzar=True)
            self.terminado = True

    # ---------- pantalla ----------
    def render(self, alto, ancho=130):
        """Pantalla liviana: cabecera, operaciones abiertas y eventos de operaciones."""
        from rich.table import Table
        from rich.panel import Panel
        from rich.layout import Layout
        from rich.text import Text
        from rich import box
        cfg = self.cfg
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        wr = f"{st['ganadas']/tot*100:.0f}%" if tot else "-"
        pnl_est = "bold green" if self.pnl > 0 else ("bold red" if self.pnl < 0 else "bold white")
        cuenta_est = "bold black on yellow" if self.cuenta == "REAL" else "bold black on cyan"
        modo = "auto" if cfg["rec_modo"] == "auto" else f"x{cfg['rec_multiplicador']:g}"
        if cfg["recuperacion"] == "martingala":
            rec = f"Martingala {cfg['rec_max']} gales ({modo})"
        elif cfg["recuperacion"] == "niveles":
            rec = f"Niveles ({modo}) · nivel {self.nivel + 1}/{int(cfg['rec_max']) + 1}"
            if self.nivel > 0:
                rec += f" · por recuperar ${self.ciclo_perdida:.2f}"
        else:
            rec = "Sin recuperación"
        real = self.pnl_segun_saldo()
        inicio = f"{self.saldo_inicio:,.2f}" if isinstance(self.saldo_inicio, (int, float)) else "?"
        l1 = Text.assemble((f" {self.cuenta} ", cuenta_est), "  Saldo ", (self.saldo_txt, "bold"), (f" (inicio {inicio})", "dim"),
                           "   P/L ", (f"{self.pnl:+.2f}", pnl_est),
                           (f" (saldo real {real:+.2f})" if real is not None and abs(real - self.pnl) >= 0.01 else "", "dim"),
                           "   ", (f"{st['ganadas']} G", "green"), " · ", (f"{st['perdidas']} P", "red"),
                           " · ", (f"{st['empates']} E", "yellow"), f" · acierto {wr}",
                           (f" · {st.get('sin_resultado', 0)} sin resultado" if st.get("sin_resultado") else "", "red"))
        l2 = Text.assemble("Stop win ", (f"+{cfg['stop_win']:g}", "green"), " · Stop loss ", (f"-{cfg['stop_loss']:g}", "red"),
                           f"    {rec}    Entrada ${cfg['monto_entrada']:g}")
        if not self.b.conectado:
            con = Text.assemble(("● SIN CONEXIÓN  ", "bold red"), (self.fase, "yellow"))
        else:
            n_vivo = sum(1 for p in self.seleccion if self.b.vivo.get(p))
            if self.prox_cierre and not self.detener:
                falta = max(0, int(self.prox_cierre - self.b.ahora()))
                prox_txt = f"próximo cierre {', '.join('M'+str(t) for t in self.tfs_prox) or 'M1'} en {falta:>2}s"
            else:
                prox_txt = self.fase
            con = Text.assemble(("● ", "red" if self.detener else "green"),
                                ("Conectado" if not self.detener else self.fase, ""), "   ",
                                (prox_txt, "bold yellow"), "   ",
                                (f"vigilando {n_vivo} pares en vivo · TF {', '.join('M'+str(t) for t in self.tfs)}"
                                 + (f" · reconexiones {self.reconexiones}" if self.reconexiones else ""), "dim"))
        for t in (l1, l2, con):
            t.no_wrap = True; t.overflow = "ellipsis"
        cab_txt = Text("\n").join([l1, l2, con])
        cab_txt.no_wrap = True; cab_txt.overflow = "ellipsis"
        cab = Panel(cab_txt, title="[bold]IQ BOT ESCÁNER[/]", border_style="blue", box=box.ROUNDED)

        ta = Table(box=box.SIMPLE_HEAD, expand=True, header_style="bold blue", pad_edge=False)
        for c in ("Par", "TF", "Dirección", "Monto", "Tipo", "Vence en"):
            ta.add_column(c, no_wrap=True)
        ahora = self.b.ahora()
        for o in list(self.abiertas.values()):
            falta = max(0, int(o["vence"] - ahora))
            ta.add_row(o["par"], f"M{o['tf']}",
                       Text("▲ CALL", style="bold green") if o["dir"] == "call" else Text("▼ PUT", style="bold red"),
                       f"${o['monto']:.2f}", o["intento"], f"{falta//60}:{falta%60:02d}")
        if not self.abiertas:
            ta.add_row(Text("Esperando señal..." if self.b.conectado else "Sin conexión", style="dim"), "", "", "", "", "")
        alto_ab = min(cfg["max_operaciones_simultaneas"], 8) + 5
        arriba = Panel(ta, title=f"Operaciones abiertas ({len(self.abiertas)}/{cfg['max_operaciones_simultaneas']})",
                       border_style="magenta", box=box.ROUNDED)

        alto_ev = max(3, alto - 5 - alto_ab - 3)
        lineas = [Text.assemble((h + " ", "dim"), (m, e)) for h, m, e in list(self.eventos)[-alto_ev:]]
        cuerpo_ev = Text("\n").join(lineas) if lineas else Text("Todavía no hay operaciones.", style="dim")
        cuerpo_ev.no_wrap = True; cuerpo_ev.overflow = "ellipsis"
        ev = Panel(cuerpo_ev, title="Operaciones y resultados", border_style="green", box=box.ROUNDED)

        raiz = Layout()
        raiz.split_column(Layout(cab, size=5), Layout(arriba, size=alto_ab), Layout(ev),
                          Layout(Text(" Ctrl + C para detener", style="dim"), size=1))
        return raiz

    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios):
            threading.Thread(target=objetivo, daemon=True).start()

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma velas de 15 segundos desde la entrada (como las de IQ Option)."""
        t0 = o["t0"]
        por = {}
        for t, p in list(o["ticks"]):
            k = max(0, int((t - t0) // VELA_VIVO_SEG))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = o["tf"] * 60
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": math.ceil(dur / VELA_VIVO_SEG)}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "estrategia": o.get("estrategia", ""), "wr": o.get("wr"), "conf": o.get("conf"),
                             "n": o.get("n"), "nr": o.get("nr"), "gr": o.get("gr"), "wg": o.get("wg"), "vivo": vivo})
        ue = None
        if self.ultima_entrada:
            u = self.ultima_entrada
            ue = {"par": u["par"], "tf": u["tf"], "dir": u["dir"], "wr": u.get("wr"), "conf": u.get("conf"),
                  "n": u.get("n"), "nr": u.get("nr"), "gr": u.get("gr"), "wg": u.get("wg"), "tipo": u["intento"],
                  "hace": int(time.time() - u["hora"])}
        real = self.pnl_segun_saldo()
        prox = None
        if self.prox_cierre and not self.detener:
            prox = {"seg": max(0, int(self.prox_cierre - ahora)),
                    "tfs": [f"M{t}" for t in (self.tfs_prox or [1])]}
        return {
            "cuenta": self.cuenta, "saldo": self.saldo_actual, "saldo_inicio": self.saldo_inicio,
            "pnl": self.pnl, "pnl_real": real, "ajustes_saldo": self.ajustes_saldo,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "sin_resultado": st.get("sin_resultado", 0),
            "acierto": round(st["ganadas"] / tot * 100, 1) if tot else None,
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"], "entrada": cfg["monto_entrada"],
            "recuperacion": cfg["recuperacion"], "rec_modo": cfg["rec_modo"], "rec_max": cfg["rec_max"],
            "rec_mult": cfg["rec_multiplicador"], "nivel": self.nivel + 1, "por_recuperar": self.ciclo_perdida,
            "proxima_entrada": self.monto_siguiente_nivel(0.85),
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "prox_cierre": prox, "reloj": round(self.b.offset, 2), "ultima_entrada": ue,
            "vigilando": sum(1 for p in self.seleccion if self.b.vivo.get(p)), "pares_abiertos": self.total_abiertos,
            "escaneo": self.ultimo_escaneo, "catalogados": len({k[0] for k in self.cat}),
            "tfs": [f"M{t}" for t in self.tfs], "reconexiones": self.reconexiones,
            "max_ops": cfg["max_operaciones_simultaneas"], "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "curva": [round(p, 2) for _, p in self.curva[-300:]],
            "eventos": [{"hora": h, "texto": m, "estilo": e} for h, m, e in list(self.eventos)[-40:]],
            "omitidos": [p for p, t in self.bloqueados.items() if t > time.time()][:12],
            "mercado": MERCADO.resumen(), "pausa_mercado": self.pausa_mercado(), "estricto": self.modo_estricto(),
            "confianza": self.confianza, "hora_server": round(self.b.ahora(), 2),
            "bandido": self.bandido_resumen(), "modelos": modelos().resumen(), "ia_filtra": bool(cfg.get("ia_filtra", True)),
            "ia": self.ia.resumen(), "ia3": arboles().resumen(self.ia.d["total"]),
            "ranking": self.ia.ranking() if cfg.get("estrategias_auto", True) else [],
        }

    def correr(self):
        from rich.console import Console
        from rich.live import Live
        consola = Console(file=sys.__stdout__)
        # la librería escribe mensajes sueltos: se mandan a un archivo para no ensuciar la pantalla
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        viejo_out, viejo_err = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = archivo_lib
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        threading.Thread(target=self.hilo_pares, daemon=True).start()
        threading.Thread(target=self.hilo_vigilante, daemon=True).start()
        threading.Thread(target=self.hilo_saldo, daemon=True).start()
        threading.Thread(target=self.hilo_licencia, daemon=True).start()
        principal = threading.Thread(target=self.ciclo, daemon=True)
        principal.start()
        try:
            with Live(self.render(consola.size.height, consola.size.width), console=consola, screen=True,
                      refresh_per_second=1, transient=False) as live:
                while not self.terminado:
                    try:
                        live.update(self.render(consola.size.height, consola.size.width))
                        time.sleep(1)
                    except KeyboardInterrupt:
                        if not self.detener:
                            self.detener = True
                            self.log("Deteniendo... se esperan las operaciones abiertas (Ctrl + C otra vez para salir ya).", "yellow")
                        else:
                            break
                live.update(self.render(consola.size.height, consola.size.width))
                time.sleep(1)
        finally:
            sys.stdout, sys.stderr = viejo_out, viejo_err
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        wr = (st["ganadas"] / tot * 100) if tot else 0
        print("\n" + "=" * 60)
        print(f"FIN DE LA SESIÓN ({self.cuenta})")
        final = self.b.saldo()
        print(f"Ganadas: {st['ganadas']}  Perdidas: {st['perdidas']}  Empates: {st['empates']}  Acierto: {wr:.1f}%"
              + (f"  Sin resultado: {st['sin_resultado']}" if st.get("sin_resultado") else ""))
        if isinstance(final, (int, float)) and isinstance(self.saldo_inicio, (int, float)):
            print(f"Saldo inicial: {self.saldo_inicio:,.2f}   Saldo final: {final:,.2f}   "
                  f"P/L REAL (según IQ Option): {final - self.saldo_inicio:+.2f}")
        print(f"P/L calculado por el bot: {self.pnl:+.2f}" + (f"  (se cuadró con el saldo {self.ajustes_saldo} vez/veces)" if self.ajustes_saldo else ""))
        print("Últimos eventos:")
        for h, m, _ in list(self.eventos)[-8:]:
            print(f"  {h} {m}")
        print("=" * 60)

# =====================================================================
#  MENÚ
# =====================================================================

def preguntar(texto, defecto, tipo=str):
    while True:
        r = input(f"{texto} [{defecto}]: ").strip()
        if not r:
            return defecto
        try:
            if tipo is bool:
                if r.lower() in ("s", "si", "sí", "y", "yes", "1"): return True
                if r.lower() in ("n", "no", "0"): return False
                raise ValueError
            if tipo is float: return float(r.replace(",", "."))
            return tipo(r)
        except ValueError:
            print("   Valor no válido, intenta de nuevo.")

def preguntar_lista(texto, defecto, conv=float):
    while True:
        r = input(f"{texto} [{','.join(str(x) for x in defecto)}]: ").strip()
        if not r:
            return list(defecto)
        try:
            return [conv(x.strip()) for x in r.replace(";", ",").split(",") if x.strip()]
        except ValueError:
            print("   Escribe números separados por coma, por ejemplo: 1,2.2,4.8")

def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if "rec_max" not in guardado and "martingala_max_gales" in guardado:   # versión anterior
                guardado["rec_max"] = max(1, int(guardado.get("martingala_max_gales") or 1))
                if float(guardado.get("martingala_factor") or 0) > 0:
                    guardado["rec_modo"] = "multiplicador"
                    guardado["rec_multiplicador"] = float(guardado["martingala_factor"])
            for k in ("martingala_max_gales", "martingala_factor", "niveles_montos"):
                guardado.pop(k, None)
            if int(guardado.get("filtros_v", 0) or 0) < 2:
                # v1.2: filtros más simples (acierto simple, sin ciclo reciente ni pausa)
                for k in ("filtro_reciente", "ciclo_reciente", "pausa_tras_perdida"):
                    guardado.pop(k, None)
                guardado["winrate_minimo"] = 0.75
                guardado["min_senales_catalogo"] = 10
                guardado["velas_catalogo"] = 300
                guardado["filtros_v"] = 2
            if int(guardado.get("filtros_v", 0) or 0) < 3:
                guardado["max_operaciones_simultaneas"] = 1      # v1.10: una operación a la vez
                guardado["filtros_v"] = 3
            if isinstance(guardado.get("estrategias_activas"), list):
                guardado["estrategias_activas"] = [ALIAS_ESTRATEGIAS.get(k, k) for k in guardado["estrategias_activas"]]
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    if cfg.get("recuperacion") not in ("ninguna", "martingala", "niveles", "auto"):
        cfg["recuperacion"] = "martingala"
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES}) or [1]
    except Exception:
        cfg["temporalidades"] = [1]
    return cfg

def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def paso_login(cfg):
    print("\n========== 1) INICIAR SESIÓN EN IQ OPTION ==========")
    for intento in range(1, 4):
        email = input(f"Correo [{cfg['email']}]: ").strip() if cfg.get("email") else input("Correo: ").strip()
        email = email or cfg.get("email", "")
        if "@" not in email:
            print("   Escribe un correo válido."); continue
        clave = getpass.getpass("Contraseña (no se ve mientras escribes): ")
        if not clave:
            print("   La contraseña está vacía."); continue
        print("Conectando con IQ Option...")
        broker, error = BrokerIQ.iniciar_sesion(
            email, clave, lambda: input("IQ Option te envió un código por SMS. Escríbelo: ").strip())
        clave = None
        if broker:
            cfg["email"] = email
            guardar_config(cfg)
            print("✔ Sesión iniciada correctamente.")
            return broker
        print(f"✘ No se pudo iniciar sesión: {error}")
        if "inesperada" in error and not os.environ.get("IQBOT_REINICIADO"):
            print("   Puede que IQ Option haya cambiado algo. Se busca una versión nueva de la librería...")
            if actualizar_libreria():
                reiniciar_bot()
            print("   No hay versión nueva de la librería todavía.")
        if intento < 3:
            print("   Intenta de nuevo.\n")
    print("\nSe alcanzaron 3 intentos. Verifica tus datos entrando a iqoption.com desde el navegador.")
    return None

def paso_cuenta(broker, cfg):
    print("\n========== 2) ELEGIR CUENTA ==========")
    try:
        s = broker.saldos()
    except Exception:
        s = {}
    demo = s.get("PRACTICE"); real = s.get("REAL")
    fmt = lambda x: f"{x[0]:,.2f} {x[1]}" if x and x[0] is not None else "?"
    print(f"  1 = DEMO  (práctica)   saldo: {fmt(demo)}")
    print(f"  2 = REAL  (dinero real) saldo: {fmt(real)}")
    actual = "2" if cfg.get("cuenta") == "REAL" else "1"
    while True:
        op = input(f"Elige 1 o 2 [{actual}]: ").strip() or actual
        if op in ("1", "2"): break
        print("   Escribe 1 o 2.")
    cfg["cuenta"] = "REAL" if op == "2" else "PRACTICE"
    broker.usar_cuenta(cfg["cuenta"])
    nombre = "REAL" if cfg["cuenta"] == "REAL" else "DEMO"
    print(f"✔ Cuenta {nombre} seleccionada. Saldo: {broker.saldo()}")
    return nombre

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = {"martingala": "Gale", "auto": "Recuperación"}.get(cfg["recuperacion"], "Nivel")
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else (f"{nombre} {i}" if nombre != "Nivel" else f"{nombre} {i + 1}")
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

def mostrar_tabla_recuperacion(cfg, payout=0.85):
    filas = tabla_recuperacion(cfg, payout)
    print(f"\n   Montos de recuperación (calculados con payout {payout*100:.0f}%; el bot usa el payout real de cada par):")
    print(f"   {'':<10}{'Monto':>10}{'Si gana aquí':>16}{'Si pierde, va perdiendo':>26}")
    for et, monto, perdido, neto in filas:
        print(f"   {et:<10}{'$'+format(monto, '.2f'):>10}{format(neto, '+.2f'):>16}{'-$'+format(perdido, '.2f'):>26}")
    total = filas[-1][2]
    print(f"   Riesgo total si se pierde todo: ${total:.2f}")
    if cfg["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:]):
        print("   ⚠ Con ese multiplicador, ganar en algún paso NO alcanza a recuperar lo perdido. "
              "Usa el modo automático o un multiplicador mayor.")
    print()
    return total

def paso_ajustes(cfg):
    print("\n========== 3) AJUSTES (Enter = dejar el valor entre corchetes) ==========")
    cfg["monto_entrada"] = preguntar("Monto de entrada $", cfg["monto_entrada"], float)
    tfs = preguntar_lista("Temporalidades en minutos (1, 2, 5, 15)", cfg["temporalidades"], int)
    cfg["temporalidades"] = sorted({t for t in tfs if t in TEMPORALIDADES}) or [1]
    cfg["incluir_mercado_real"] = preguntar("¿Operar mercado real? (s/n)", "s" if cfg["incluir_mercado_real"] else "n", bool) in (True, "s")
    cfg["incluir_otc"] = preguntar("¿Operar OTC? (s/n)", "s" if cfg["incluir_otc"] else "n", bool) in (True, "s")
    if not cfg["incluir_mercado_real"] and not cfg["incluir_otc"]:
        print("   Tienes que elegir al menos uno; se activan los dos."); cfg["incluir_mercado_real"] = cfg["incluir_otc"] = True
    cfg["payout_minimo"] = preguntar("Payout mínimo en % (ej. 80)", int(round(cfg["payout_minimo"] * 100)), float) / 100
    cfg["max_pares"] = min(MAX_PARES, max(1, preguntar(f"¿Cuántos pares vigilar? (los de mejor payout, máx. {MAX_PARES})",
                                                         min(cfg.get("max_pares", 20), MAX_PARES), int)))
    cfg["max_operaciones_simultaneas"] = max(1, preguntar("Máximo de operaciones al mismo tiempo", cfg["max_operaciones_simultaneas"], int))
    print("\nRecuperación:  1 = ninguna   2 = martingala (gale en el mismo par, vela siguiente)")
    print("               3 = niveles (la pérdida se recupera en la siguiente señal, en cualquier par)")
    act = {"ninguna": "1", "martingala": "2", "niveles": "3"}.get(cfg["recuperacion"], "2")
    op = preguntar("Elige 1, 2 o 3", act)
    cfg["recuperacion"] = {"1": "ninguna", "2": "martingala", "3": "niveles"}.get(op, cfg["recuperacion"])
    if cfg["recuperacion"] != "ninguna":
        palabra = "gales" if cfg["recuperacion"] == "martingala" else "niveles de recuperación"
        cfg["rec_max"] = min(6, max(1, preguntar(f"¿Cuántos {palabra}?", cfg["rec_max"], int)))
        print("Cálculo del monto:  1 = automático (recupera todo lo perdido + deja la ganancia)")
        print("                    2 = multiplicador fijo (ej. 2.2 = cada entrada es 2.2 veces la anterior)")
        m = preguntar("Elige 1 o 2", "1" if cfg["rec_modo"] == "auto" else "2")
        cfg["rec_modo"] = "multiplicador" if m == "2" else "auto"
        if cfg["rec_modo"] == "multiplicador":
            cfg["rec_multiplicador"] = max(1.0, preguntar("Multiplicador", cfg["rec_multiplicador"], float))
        total = mostrar_tabla_recuperacion(cfg)
        sugerido = math.ceil(total)
    else:
        sugerido = cfg["monto_entrada"] * 3
    cfg["stop_win"] = preguntar("Stop WIN (ganancia para detenerse) $", cfg["stop_win"], float)
    if cfg["stop_loss"] < sugerido:
        print(f"   Para que la recuperación completa quepa, el stop loss debería ser al menos ${sugerido}.")
    cfg["stop_loss"] = preguntar("Stop LOSS (pérdida máxima) $", max(cfg["stop_loss"], sugerido) if cfg["recuperacion"] != "ninguna" else cfg["stop_loss"], float)
    if cfg["recuperacion"] != "ninguna" and cfg["stop_loss"] < sugerido:
        print(f"   ⚠ Con stop loss ${cfg['stop_loss']:g} la recuperación se cortará antes del último "
              f"{'gale' if cfg['recuperacion'] == 'martingala' else 'nivel'} (se necesitan ${sugerido}).")
    nombres = list(ESTRATEGIAS)
    print("\nEstrategias de CUADRANTE (solo M1):")
    for i, n in enumerate(nombres, 1):
        if i == len(ESTRATEGIAS_CUADRANTE) + 1:
            print("Estrategias de VELAS e INDICADORES (M1 a M15):")
        doc = (ESTRATEGIAS[n].__doc__ or "").split(":", 1)[-1].strip()
        print(f"  {i:>2}. {n:<18} {doc[:70]}")
    act = cfg["estrategias_activas"]
    act_txt = "todas" if act == "todas" else ",".join(str(nombres.index(a) + 1) for a in act if a in nombres) or "todas"
    print("Escribe 'todas', 'cuadrante', 'indicadores' o los números separados por coma (ej: 1,2,3,7,8).")
    r = input(f"¿Cuáles usar? [{act_txt}]: ").strip() or act_txt
    if r.lower() == "todas":
        cfg["estrategias_activas"] = "todas"
    elif r.lower().startswith("cuad"):
        cfg["estrategias_activas"] = list(ESTRATEGIAS_CUADRANTE)
    elif r.lower().startswith("indi"):
        cfg["estrategias_activas"] = list(ESTRATEGIAS_INDICADORES)
    else:
        sel = []
        for x in r.replace(" ", "").split(","):
            if "-" in x and all(p.isdigit() for p in x.split("-", 1)):   # rangos tipo 1-12
                a_, b_ = (int(p) for p in x.split("-", 1))
                sel += [nombres[i - 1] for i in range(a_, b_ + 1) if 1 <= i <= len(nombres)]
            elif x.isdigit() and 1 <= int(x) <= len(nombres):
                sel.append(nombres[int(x) - 1])
        cfg["estrategias_activas"] = list(dict.fromkeys(sel)) or "todas"
    if cfg["estrategias_activas"] != "todas" and all(n in ESTRATEGIAS_CUADRANTE for n in cfg["estrategias_activas"]) \
            and 1 not in cfg["temporalidades"]:
        print("   ⚠ Elegiste solo estrategias de cuadrante, que funcionan en M1, pero M1 no está activado. Se activa M1.")
        cfg["temporalidades"] = sorted(set(cfg["temporalidades"]) | {1})
    guardar_config(cfg)
    print(f"✔ Ajustes guardados en {CONFIG_FILE}")

def main():
    print("=" * 60)
    print(f"   IQ BOT ESCANER {VERSION_BOT} - Opciones binarias (M1 / M2 / M5 / M15)")
    print("=" * 60)
    ordenar_archivos()
    asegurar_librerias()
    cfg = cargar_config()
    if cfg.get("actualizar_libreria", True) and not os.environ.get("IQBOT_REINICIADO"):
        actualizar_libreria()

    broker = paso_login(cfg)
    if not broker:
        return
    print("\nVerificando licencia...")
    ok, msg = verificar_licencia(cfg.get("email"), broker.id_iq())
    print(("✔ " if ok else "✘ ") + msg)
    if not ok:
        return
    nombre = paso_cuenta(broker, cfg)
    paso_ajustes(cfg)

    saldo = broker.saldo()
    if isinstance(saldo, (int, float)) and cfg["stop_loss"] > saldo:
        print(f"\nTu stop loss ({cfg['stop_loss']}) es mayor que tu saldo ({saldo}). Bájalo y vuelve a iniciar.")
        return
    rec = cfg["recuperacion"]
    modo = "automático" if cfg["rec_modo"] == "auto" else f"multiplicador x{cfg['rec_multiplicador']:g}"
    extra = (f" ({cfg['rec_max']} gales, {modo})" if rec == "martingala"
             else f" ({cfg['rec_max']} niveles, {modo})" if rec == "niveles" else "")
    print("\n========== 4) RESUMEN ==========")
    print(f"Cuenta {nombre} | saldo {saldo}")
    print(f"Entrada ${cfg['monto_entrada']} | {', '.join('M'+str(t) for t in cfg['temporalidades'])} | "
          f"{'real ' if cfg['incluir_mercado_real'] else ''}{'OTC' if cfg['incluir_otc'] else ''} | "
          f"máx. {cfg['max_operaciones_simultaneas']} a la vez")
    print(f"Recuperación: {rec}{extra} | stop win {cfg['stop_win']} / stop loss {cfg['stop_loss']}")
    pregunta = "¿Iniciar con DINERO REAL? (s/n): " if nombre == "REAL" else "¿Iniciar en la cuenta DEMO? (s/n): "
    if input(pregunta).strip().lower() not in ("s", "si", "sí"):
        print("Cancelado."); return
    Bot(broker, cfg, nombre).correr()


def arrancar():
    try:
        main()
    except KeyboardInterrupt:
        print("\nDetenido.")
    except SystemExit as e:
        if e.code not in (None, 0):
            print(f"\n{e.code}")
    except Exception:
        err = traceback.format_exc()
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{err}")
        print("\n" + "!" * 60)
        print("Ocurrió un error inesperado:")
        print(err)
        print(f"Quedó guardado en {os.path.join(DATOS, ERROR_LOG)}. Envíamelo para corregirlo.")
        print("!" * 60)
    finally:
        try:
            input("\nPresiona Enter para cerrar esta ventana...")
        except Exception:
            pass

# =====================================================================
#  CEREBRO INICIAL: lo que las IAs ya aprendieron con miles de señales reales de LS SmartTrade.
#  Se usa solo la primera vez (cuando el equipo todavía no tiene IAs propias); desde ahí cada bot
#  sigue aprendiendo con sus propias señales.
# =====================================================================
CEREBRO_INICIAL = (
    "eNqsvWtzHUdyIPpXFIy4+8WSVc/urhMbGwESEIUhCcAE6CFHd0KBoaAhd0mCC5Kyveb+9613ZWZlNhi2PeEZCZ2nuroq389/f/D2+sHh3x/88eCgv3/w+fbz"
    "9bsHh2VV9h/V9w/+fv3h+rfrTw8O1qw6/eF1Ar05PLr78vrm12dHj44fHH7RXsVH1sX//mtc4feDjn+0xvr412XRIf/5/eH2c/zxL0ZZF//utLf5728OxqQ1"
    "tIl/NWrLf3z95fDalr+mRYx1Bfjz9eHvd9cffruJz8Ji8y/W+uju8PFd3G3+lV/yr0x59Mft4cPt3fv0Xb9Y7de0Lbes+dnN74d3159v7vJDvSxpF9Yu5Yd3"
    "nw7O/+B9XjN/vzGhPPqXu8Pqf9hUXjL/Ki5ZNv/x3w6b+mFb08dalx65zer86LfDxy+f84mFtENrQjmcj4eXRy9+fHn0+Ifzq0fxeTrPpezv60dw2F9lsHjs"
    "AC7dgLbpS63yDeIOQrTDWtNGtNMVKJ4VAOrHpp3PB2MqWLwgAJbvKt0DWOgG7Qecscp3Y9pKbyBYRgWTtu1dff4ePi8oFFS++Pqmw9Xt3d3Np18f37y/eZdQ"
    "9Redt2Ld2nEpHceSMVrrbW2o1L9u8/nRakNDpd+v/7i9y6eT7k8vq2kI4f0Pq8rolw8ubKZf+voP6e8mpL9v9Re/HV5fvyu4tfpCJa5e+fOTs+OT5y8uj+tt"
    "5h8uoV87/q6vFDyj47h8Aq2nc8gIQKDaZy6JJHW/3YgEBHAgwrJSRCCg+bDTSX6/rgMXCNDAhzUfV//sNxSycAfwre8pREEKrTNWmIYVJ58+376+/vT57evb"
    "9HTzkEXdHV7ffvh8l5mFzZdv1sp60smD37LHvo5jh6D5zLfMCy0gOggyXuu39NYN0B2EG+e9boVRjPNG66V3ZtrczDhsCDFOOvHQ78PWDxpC5VP2gJ28R4/b"
    "EVeO2474wx+37/64+fA5sWNtMl1vg+jSkkvmmpF7hMZtP99E9v3hdZI5v/hFF5LUjacmxpnY7ZaxIvhKKvH4Hz29qDfgNMStj2AbXxFcRn5wUwMsX5TR5drB"
    "RQ2Ifk8+71ABygBQ45bqx1twS2CxdBI24cW6gUsaAPBM8rYcuKUBVrhjfj6IATyvt6SKoKo3eXj06PTXm3/9fHfzPhNC5vd27bI67y39bXP95hJ/ywws8kTt"
    "Grt8/ebt6+siC7JQ3oJuTNGqH1y5tsxIglkbjzt6dXz64hlgculW/Lg8sLuvE3A6MgfkG4A1VPzdoceDzlzakQkLkG8ADvC1hHHWL0DAwfUUx9QgBLrD9JHO"
    "DwkHN552vuWjHRIOPK8ibs3n2LSDPx8/asifjo/TDHgQrBVkVprJgtcJBtZneWhXXtqns8h62aLr/i5eXf08rs0CFon2iMHS9Wl2H00sZVxfBJ1Dt120Ozsc"
    "/T0qr+/fRlrImJ7lqXEdSf+7VZk8DNA/Ph4uL7xSYONDCoDlvlIogJUQrDCWorKCI4Yg/YyX/P3GDsSEYJS1wLtAy+VjSPjkwkBMCIEQM+u+qiMmhCuCNh9O"
    "6JgJAQpmbpnCFwM4888/MRwXXTyC0uPeD/8cJfivv938+vuXm7v/U+Ri5k86jPUvH3fmsUDe+JH8+iuCJVRAQPNFuUzy2oyLIlAND/OetHbjqgjguK1MOVYB"
    "cU1Ai13jsvQPgJcQsCG2t8KHh75MIDtDGbdGIKpcyJdvbJfE729+y0ihVdmN9u3QH5/8M3ujQNbwIETupU8tanLnq1jwtS0UDSaIemozVrLyqa1t+3x4cfTi"
    "mN0qRFwEBrBvoqXEH3zWPNTCE1PbcLFtAZI+fP4USjjnBDIYcOTc0EYyjqSNVIX15vDw9t27tx/+fnP3693N6zfX/+d2GGUaaElHzy/bd7os5/s2pgW+InCF"
    "rYkZ2lCgOwZoiN3CSCwgmRl6UE2WrFaB42DWVk332wCnm+HaFRXdsqlBkW6YbzL1HnwnnRmoUE9F44Z5kZudnT9hBBm6bwHq4+H8482Ho9N2U5nBs/osgkNy"
    "B2mrjTwcVlYxrQ2OUiSPVwNtrp6/QkboJmDvgFMYe6Fg7jZ8M40Pj46eHx+dnbfvSK/YNPe9GHC84+Ph2fnzy6ujM4aI0R5lMOyP6HS8DZvo4+GnP5+fHbXf"
    "ZruLdcJAMELFSGcsbjDozCA6Y2d/med0Ov7TxTPmlDFP42AyQ3x0dMyQ9MQQMZjmdZXOdhNM8DxLBHiVubNut3707C9nPx49PX149PCI8Vlg3f8eYKL962HJ"
    "LE44fdt3tDSPy9PTsydYTWVVaQymRCSCmlWm4casC8zJs6Nfw69GD11vaeryycXJeEFRtpUhW2k//4qhDTkVDJtelj0L2iiqWnegdq0+axbNnB+uvw7YGTTR"
    "VTvBd0ggsSw9qw4EXBEBItQbCpj5cvELES9gBylc2WZXAGBkp8fPG/ZkdqkFL8GAK2fAugmaT0SvLNdt2mH2Z2+NBE9eeMUiGPglC5OpF2AFskWgMwaBEXRA"
    "Pp26ihdcR+nKnBpm3OQ6auxpywhqGpd8+Ohn/v2TQi5Czgp52uwK7MZZI+7M0g7xke/85yfHyDMUBOE14GzXlov0+/khMBo2AWUwlOc13myNGSg55g+BbCMj"
    "8LJIpI9ELjSrGQo0Tfe0y/i0Zy+7LEyn6xZWHmBA2bw19eOXbic8t+rHF090t40Jg8db3AdnPklVy6Yb648vWdkG7ZLLmW0fLt5++Nv1XeNQNnS15PhPF69Y"
    "86H84qsIEQ+mgmiybOYS9dnwp+SQwOCz9flQgDeorMeTaAuo6eFNf3MjiMwoXeel9WnXbUcgpT6p5qDFWudsSw/jAH35ZCV3LSFvpGPf0enj+/RjDiRdy+Xp"
    "2fnlDkYV5XoC06xmgbwCxPpDCoNp+uDaGPJPT8+fnPKaAFYI9+BYw2tQNdwRa3hpYOnZPeOr3YPNDLIJxfPnx6c4esGKJAwGdcqTF88H6yP+ACAsEJgG1/ny"
    "4goIgSVHSrkdIDjIhAiLVdR/SpRqGGrMvl/djuLPpz9RrcuwCj4CHDT05qBdY7JLW/Tx+fnjpycsss5XJALzFm83IFa3Z/ECDTxrM9bt2Lz5E8ark5p+9Jfz"
    "Mx7FkYIugGH3dl7eA/n67PKnqx+Pji6egq/mfawcpOBEbapX9vBa1p2ZNwLk+eHi+vPd7Ydf7b9qEA90Pfz+GGP/IJLxu68TFNBnANj8giIUBgTRwIGXBAAB"
    "6VBiilA+DLASAtQESwAAcCVmnF/GgcFNO/JN7+HTFgDMB64biz89uzp5yh4aICYJCAX++9vR0j+ePnwGkIF1RO4BouhZR3w9dEerWLxHit/9MFgSiWAwhqAw"
    "f2No3zTtPNhuNZ4B9pXUubDKNuMZ1rx3TLeMrvnmRYOsn51n0bnrOWu2t53hEVUNY3dhMRVpxstwRKWrOjs++iet1H2i+B5AwKkQky8mMx9L7HI1c+J2G2en"
    "T07uu3EWJkW5/T/kTKjh4P14OD4H4i8HWDfWEsFwcNsTEkzsyop+A1PRZGGPao7b8ToADtMDFMfJBhmbhiZx9+nwP3JKjc7alwEGHDFScGy/sYpnj44l+YU/"
    "kgeMYKdX3ceaeZCoFQPIjOleCsp0ftaJ9+nVc/78xtWyMFHp8M0v6xV7MrNby/Ei0TdMB9bzX47aO3O62LYK1vOAU4jDQibu6+u1ERmJRyYkd3IeIUf80heX"
    "BsVeeYeoCEZjK91Odg2BLs+fEsaqlZeQCAGzDuYO2gNsWSbpoU+f/eX4W+zlCVILnhzVrS8jZAGhrJuAopmENj12cBz+/DaKpuv3n359nllWTmdUwGM14roO"
    "8Y/xu68TFHAvADA9vSCzYgABsqcUSDbKihMAG4pTyCe/AcUJrqZa6NyDtBwAACyJYi2bcWZw35581nv4tCXlFD9G4HeSXHGhpDw5lrPOCRYWBMhPnrBWMOGe"
    "PBhR3z3hjQ9Pj1+g1B0lYSuAhObfs6PHZ6c/nT46ObtaWQYIozd7sIkTHA96wNhWXRsIgngtKkhPErbAYw+8KtB8zMoudawQBkU+AZzC8NflrY+Ii95hYgTM"
    "sJqs39O3qRklx5AeCyorlug4RjwkR+S2aiccB3yYAuQcmGhmXZZRoeVu/+36f2YvtEaxnKOLi6cn3yL1JcA53FFfNA7s/eHupibhZOFofEX/NwejCJ6fvHzV"
    "dDrPKm4VQDJPyIIkta/uA2ZdxT3onkpilcaJ5M1RvlpJlxmAJLBME1Ya0y2+6p3MlubDN0rMVdHNn2lWKVulfWqAXqwTxP4MTAtDogbBoQgSFhH1qks6Cc+T"
    "DZMyC57nTwFKYN/j7cfuEVa8pwzAGWQQo+iNrkxOGzYltx5TydLsGTGR+w0GguNPkPIRGJYGyN+vqXsZLyOw/Ki3DK+56L9FUMShBFIW+zGsLNXoKW2PoBMM"
    "1oMQ1OH5zeebT59vbn+9+/Lx85eiVeTMWR060y4Um5PrhlpMf/i1gDlcizFB6ekFmdgmOBRVXEHMYIIcak5dFuSuTsCvR5wCqIgTWM+LyHbQwMwJ0PRc0h7X"
    "eD9DVSQt36J2vro7xJLVv/8hPb1kEYNZONK3DrTEaqhWrLWL4EC6f9xL9s38evm8R9kVsKQGNhskcsfPviIo4vkHYJquXw+tA3Qkgfwr40gH6dhBFspn2qFK"
    "UpUdQY+KFh2g2zAGXvUbCNIrNDRAhP60Vn1lNduyjNQQNe/y59OHwMRSOE6FsnIRpBU0Qj7VhcUt1QKlJuwQCTSmwmBNWfZ2zl4iSYqNdAAwrFOBvQZ4tVNE"
    "a8ABe57lTij8hYDZE7DT1hmyrilxWfr1VP9IMwO3vVTAJkAVDRklEjtRQ0bEaQZ1D1RwIB2WZF6wFVQfD8dHl0BzyFV7m2jqYGDRn4NzEwAnSlr1CSr78m73"
    "Bgc0FKccbtJYUNdOqjOwaB0OUiMpMBxgHmsfAKry9ZIW1OPpP7+6OIEHuDrpAAHkuOqMAxI5w6gxhIL0Ux8UBYwkVc6/z2AOIRq4O/ElKYf3+AppolK25IBT"
    "4COj7oVlgJNUNAxmRa/o0bcGnqHmCfUVNju3qsgLzjphIhW2pzmGnTTapq8GUD7A+Y8ZtTQd+uXFS6/U4awZQU7yQENAQN9V8rLKOb61Dga1xbMv72/uIpXd"
    "/Hb74bdbzPfTEvg59kOQPEYCquliUdITkG6BGXxnBKxLfLRcvDO6nKrXqoH3g8CgohHkUCaATHkmgSjCwsP3MXvSSG2Ktq1tm7R8GZUlLILN77Z7ucIop0s2"
    "QOxEWCyHRl4St6M428mFjsw+OyFuDWhllM7x10VAfQhIHC0QsOnapc5aKiw1Pb3S1ysJ2QmT72R1LTB3XGwkg12DcKUCocUvDt1AaKrAyZe724831x++Ozqd"
    "7U9SGYJhVyD35yqSTkdFvMvVzoD1Qe8AXS5dVXZEB7nQuVcjZINDi2XOoWUDhCDVOTeha1Eu8eOT58+Ozl7Zcu3ZTbXspqAg+BVT2AweWrHL2nnxk/OhSCho"
    "ULK5TgB6pF3eHK7Sl/3zzeu3H24/jWK9dRAZBJiLsBVM/EjV7xBaMwsmbIAwvWQi6bqbB6gAoUAVXqG8DWADBCzJtNl4BUwVgQzNrFpkABcgXOhYNQxrBNAi"
    "CqWPQg/FHL9s+VWg6gcE1wvAAnwlJDxvOwryeSQdlUs1HJtFEnqcwHJpJA2FF5BQTPnFUecXPQbx9vPr27cffnx8++63incW68yEUuYfkFwrSsmmkc66cV7F"
    "eT0PDSlkzoae3h64cFA9gVInvS47lDP8s9CdwCaAIWmdWfEoCYuM8bvLm/fxZD/89uX159u7Tw1NguKJTfgNleAY/1XXhrWA/z1/2xEuB4Ga8xfFZ2sWLqOw"
    "T9IVgmK/5gQachwxJ1bxxhsUpwZpGgCs80eQNACue44WGzbU2A7HI8o4PPv59Fddus/kWubBafMTgCMBpiNEhliec7+NnLA87FXWqCQ/ssDyGLgXN8Bp8t0X"
    "iKL5Z9ENvqo8A3ZoAEZiOr0CEHrW2mBz5UljEh7JuWr4l5vVMMpAjbsOhjUxABQ6nazgoJ9d/9vt3dvrcuD5sXF+GG1djC1Y9Uc//QoBDXYJY8D5Lf1qBlC7"
    "onxQweIrGmDjqkpsxW74qgZk8Z7SmjQMgwstHLq3ARU6KS/o/gZEvcecxLa5kcT2+AXpebN64TAJMLzPadeIBypYJ073VevYS2MfPjcMekE0zlkEUKFHiPhW"
    "DsjkXUn+R8EQDQsHpoTqDqexk6T/3eL8LyRGKVgLpT398q9f7v6tn9IinH0Hg760GZ9sDwy29X86AQlqhTushG0hEI2jj5W1dFUdVYoN1tNbqviJ9UBMKPQQ"
    "CIepJmlxkEkHMHUjYTY6oLs+idq8zOelWoL+skmYDBTFgDQtukNBUGuc/EQ2oHtupcUJ4AXRsmItuF4BHE7hglChFxErtotE4wp+lGplmkgV+nnpFfluy4XB"
    "58SJX/GBnmvUaZ5eTZY7PosZYrrWgYcgwbolH5QTW2E/FfoKAKhgzv3p4/FHSh3ooQZp9OCK9EZ+BJ7P3wPQ00PFr8v6avDCQGonJxQS7CdwdXL59Ai6Wo10"
    "yAAQKOGTDKtbcOhAZlUXLqdHfD8riV3wB5i4MzmfISTn9umA3ZixQSpDhckKviekXv/9w9vf376O+L6CI7KbcEQzPExvvfx4/frmJVR8KHVACIPdtZU6dE9N"
    "6Vz6+dHZoxNXvQZ2GPiAS0MQEmpJjrOhDEkERgHpxlEKdvk2t+e+BhLR770XxeFwBHhYBx7XB08775B2olHIgoVgc407EsqfimpEKFg3AG0IQB9oK9kNq0qW"
    "Yrvjnx8ewfaCG26eg379FcMizxdRXU1NZYDvmjinGapr8TQLuqsBXutSQu95yWWqi8WS/h8YBlSYLyjq/YYADuvDsFqiqTrCqmBBQwYpTdjyYSrM9MxcOAYr"
    "ywuIZn5eD88McZNbXOplwacGTssU0zUQTcMUzcij+OVNezdMaM1NqoATp0CE5hIbJRrv66NWNpo1Kr/iFjxAebDkTCAEiiiOLdvRtWChe+5epxW1IGi7qgx4"
    "K/fkpSygSZnz2PFJwEP35m0g7HfeyxtLbRf5UAQCBXu/3iaFi+0B/OUY9VCJR47VWiuR2YgNrbAHGMlo6S41xzkpiofeQw8CyYUbnUw89N9+un332/Vv2YFr"
    "PeNRas+r71HhhBcMoqdFmsu2g/Rv3UhiHwYbvX4drKJpLquxnOlSZyE+qw4DKAa5it4QuEBTH98TgKb2At3tcHH9W3KM5pDPWhpNgAr09lBS8w1ucDbg9bxc"
    "Ltdqz3s9k4a1uLn2sIH0IyztO5cFeowb0OvWpcMgf3F7PI6uxA824C9uMGESxO/B06ZcOezsBYhJ4wIoG+f87PgcqBcbaKc1kRyGRcrFRHL9/BQ042Z5pRkH"
    "4/i4+Y2BPeSRt+eZI6qWrEbBJfiaydReOJQYhRUbaeEyYJAd0FvF5YqooiZ5nPCET2PAaZyDjcGAFSAK+bnT5irI8JZ+aAf+9SyrsheL41dMltWQW0pS4ZDD"
    "D7hpuga54BBmEQYQwOGLKQBIg9qWSWrqHrSw0s76C0iTqOHcMqTLFfg9gpt0YIO0bI9bfuJsSrQLwyApVBEUjtQAHLXNYeZ7X48v79797fr1/0r2WGtNaYBD"
    "Bz6fm5zA4m0IqOelErFAEFQSCns4I6jBRbPOpEDBL4IrgggV+N2QPQFmWrSzkWKP4EKjYT/UNwRQGYYDWeMzsaLqYcbfAphcr6FazKwOjZpBnI41cFh1GWMs"
    "1fzmauCFlY7gNQZrXQOqxzrQOhi/VH/O8j/kVlSwz87J+SXgsQ6naDBmLATHqcLos0a1q1yZi1RFnDVJVFpUGYHzycpx42RaA/pS/fnpMfHo+lXAHAQaoH8m"
    "/vmfz7oVa3HErGPMACmtBqRq1JEQuUDf9svnsIPWgkvkK9eCICU0xjZEwXAwPfnF41Eyq3CaIzlzCAplw09Hz68enZ8CInMOmattszNg8f4F4fhRIpLD7bQw"
    "ZJfmIHyXL+ni5wuYwxkCp3chuJIaHtiKzZ7Xr0DKQ+lM9aofosY1Ux0ZBogDDUWOPnx+c3f78e1r2FLGeypdKdRenzJBwwZZWuj07NRGmt6ErSbXxkRlB4xm"
    "1iHaJlDNcGN4ojlZGK5VyLQnPLsJ0gUWeNzQrQFHioehxzcELvS6ccvqYF2Jr61JFThO2zu/GqI2WibjwuC64QKmmSXqCYKTK5nQhni97ZTd44nvycJiExJ4"
    "HPpwifgYdED1YBCXe1+f4ERYLeDPjtGnlYQrXWMMsLHj4dnN/7y9S+huwQAPwEL6Y+mtKyLw3+EvNLNk2teA6KNUCjHAAMAAAg20S/9vqO4OsOIp8igqdoP2"
    "A5rdlOK8UTYGoLJ/pxT6gyjxeN68SpkrA9ZEFMp7w29Ub+wXtCKDbVIIbZMt28qrcc2yUZD0GvFMg2Vwv8KK2qr7CSfUBtNZ8gk4isO1AAQz9dJeY9iCUCMc"
    "Rwugig/SsQhRDcEi7hb2qjsBLiRKSrg7fCNgInMXdxAFA8YekGYkH0Hv1R0yuQsSrfdQ+yKH2i3oLemsxLaRVAf1K+DURvgfKJWEyvRUsYX748Ilmlr08CgV"
    "g5ZTdkRHGUsDqDB8waXlcWfz7Es7BFvDnUHA/TWt8+XTkz7VYBGOv8BY3N0IgyB7b1nFKzKTS6LR5PB/oN51XRaBguRtIlXdvGCoDLWX2ElJb7hmcCgSCp4G"
    "KuUL3SO6crV8kOvASBIUIDQJfWWFQtcLA8jB+Hg4Pj3qTjO+C1CBgE1IU4eu8jaLbxmXydiRyNc1+YuXWcHodLWRSwMAC+RDXcXodZieGO/lMfJUeeC56G+Y"
    "ezt7+o4eujdAg+qmzvAvBQm9ASCulC7rQweWxW3JKvrZZoCTRC2LymWK4SuW1PbILeGEAydAcyXSagzypt6NQMGYNWFgqoWxAiveawZYqV7WYmS2JQlgnoTN"
    "oBH9JRFpJK6hE8wA3P3TC2BkZnXRS9eIQA2aWYABq2zWqB3QJJ5ABd6GK02pHgpGVpAYPiR7AOUmJBvL0Wr8RZJks5O3239X53CelMdiCmwKA8Kez4/OH50f"
    "QX/Gxi6AwFAK3dUjsgO35/BB4LA35uXRFfQcLdgXCxgvAcSJaACuyymkf+GKbmDa6VF1M2gaOT6MmPtg53E7slxUPdy0CuiDV9pYhQ85BB0cwHL0HNaBL3t0"
    "hEHhZZyABrjF2Ga7WSE4kZlB18+K/GDPj85OX7RulbzcwTAWCbvjy+FUZVLPymEOEE2SxdChDwfLAh0VYCXcp7hPPzn/6aeTxj6KeSwQEIRD3Uiq7CFeGly3"
    "jVgoTRzGzAOBIk+tIQE4CNgVWZL4hoCwTm1h/PvZ7af//eUmklMOgZccBOCJojA4GEfitxOwnpdsEXEI1j3bjriHJkgcjtCOBsYhbHGGozF2N8we29kUY8Hh"
    "4DgEDF0/I4UfEAim3BgBDcTU4cmGVsRcKg1AeuTPiTXAEMwihARcYBgNK5lQAxL+lIwKCFphl8EEjCs27c4dN7MZ23bz9Wqu0cUEBkSFggYlc3etURawLXK7"
    "/nIaG3azT7/ugMhLC46bN3FSMWKv0Nmwfg1LeZ5Ag4SP9gJVX0vqHlbWYfrpXD/wggkK03afMMq27TkdSGKekuLVuOEAHxVG2YRijwWcgiTOMaFNCR0fpJra"
    "ZZjeGx6EiwqxGr43/DGbAkmPAMlNLJsnnEMxjBXLP9JhYcDhoyDHD6ZooeNHFW5QMdDIEqclqiP33HO9nguv6k3l+L6ROK2TlFITkwC5dfiGOySlhmFbbfPd"
    "Ml5IwibAbKTPWc7dBFuhIp7sUQdykBe/yi3IiS2XnENPJpuYVIYWENQu//LZ0+tpPg/5GQRaJCDAcjzpy0PrU1XzGcMhXAQInSbK0XlxCSq2PZTpqEAYgrm9"
    "r4M1brunhxkmoUcMikxpjID0SgBvLY49w1MaTRdfpdrVMZ7ZSi8FvokNoxlSOkBDPJLzA84Z5uUYadQATSviGR6el0d6mpFPABY/LCe7ev7iGXVCLDwfJ6Ck"
    "vcrZ45Zck8NPm9+56gG7YPyB9zJ3Oherj3U32US0oZ4H4aVMxF1MvpgSfo30ciwB8aXPpwNacuOWZiSdCYTq71lxGHo45oJQbspL4fuMTGAs/iKfR1GVAn/i"
    "2AeGJBlYD0GRXtiwiYHpc7rVzlAt0H0LfSeUdXhuDSJBxDThfGLc4+vR+QUcRmf3mN+AxSVhWHeAuhsx2Ykw5yzrppY/fYGnXLqFvcEB5bBrc450gasx2AtM"
    "u3FO5EXcpjhruqsknKrRoZquUTKJjZjvbUkvdibfG7kONHYdoAwkMWFklPh9d3H7Lzd33/23746vP1+n4q6bu54Jx6ua4m/Ett6kuk7zw8RBYEzqKFjDIw66"
    "OUvn5vF3YaZxB4JdzmpzpVHlvJidHkxcMTNwWeLBTcgknxtvMa0VuaZaHWlwcw0CBdoY4I4fBC6Q901dsED+P6hGe/zwAtYyblIheIezkxNNY8OPZrQNkOdP"
    "7w1Fa+z8DbKBiwYT41bseEHsuYauzD+lnvYPwauMVOeMIImSM3vbEbTaa5yHnZvL/sQ2bAMuXXvqE0W4NDb9FQDslkoi+YZtCxxwGqLLinEWjSUKXA6n53Xn"
    "IaIpmjmKWmwpubq8Fp8Vt/QiJkWenPIePHw/o2ZJZuiaxj4nfg5nJCKtp+XZErfyCgtI/nR0cXRmjC+uo4DVS+CdQHDzrRjUi4GUeeLuh4CO75kkN1G0EZSY"
    "Y2lWK/JXUV1nSg5GfWwAjyk5o0/P0NR5sW3tACTEAM9h1hEWMYghFlweesTn1z+SjtU0DcCnMMBu2yPYxYX8TE8wdxMMlDUw84OAdQe9o2WSBPC1JWXJN/O+"
    "umse4OObCSrQ3b+fQKrkQlAk3G6YBAEg5AmN4Xpq2Hs2O1v2MqVweomSWssDr7CYTgRp1uyaWdgvIcYbdNfz2RAukpikoxcAQ4N67umFgN2dxDWMDw7Z0nsB"
    "emypFkpnY7ZY62die7jeRmNHDeCeUIQiMYTSMZh0bjLzgKnVJ4YfBMSIQcd80cC/mEZBXCJuT45ibxhNA4NfW/V1c18Ux/bpwIvs50asm6SCzkv2/lBT3K8Z"
    "oSgzA8V+Gc7Htq5luBWob5K4Q6khJu3OqZMHRQcNViqpc3DEAmFo+/Ty0TlIUPSsiAJQOxNTce8X3oBDAuw+Dyk2lRQ7i7HJGo/K16MB0X2OpLCGjJZHNYlB"
    "aI0tpEbNM6Qx7wQViP3wV+waghcOoNQ97xmKE/btEf0KFK1wwwIm00HPE7n1NJmpPgl8yKkhHM5GKvxQSw0YgV8RR7twd3kMtXFeHJSCEfBZAzBspmETG2nl"
    "tIoMtEU/Pr+YE16kfsnHyDph01pRx3opBMkXivTeORd9KJOztGvOxSs2KwUbUXPQaVIRSkoqIklaCVoZup9FtEafae+R+HON3iaMGQGll4zLAMQCZNbEydxF"
    "kq2ju+zKNRSYUrNZBRhkL7gd7ddMhiO2Qud+SkzLRoMYKpNBa6YAkpjrT8I+LDdD+p+edFyDLTrSXp6jIDyQ0+wM1xnV/RpLRHjbiFGovbGUmFco5lOmUe52"
    "B6fZPnt8d38WlDemic1BR4FhpZfBO8RkpmQd4GcFYNP8OPbqqObBpg+CiDUMd5chp8Uf4eZWYPYrBBBdKxDxRRsKqgJ6t7CY5DavAkcahanEjII1Cr1nhhHs"
    "MT4+54R6q475XnZl7q+IO3HR1E+zE2NCR2yFAMdODRkffRsdf+VcpmH+2v1uyVOHN17bJYkKq7Cxx8JUFYwGoIsSUB+OXx2/JNm3fs8hi+FX6B/KcqcrNqCh"
    "iOeTsKBRhtUopPgAJ7yRgpTQwBQH1gvuLTbtjU7jCbNff6i06h6xqQhqM2YYtO1kxWDWueQOdzhjaDhH+xycuS8Yd98QGKtsdKplKfjao02E9Y4PqIBkhj2T"
    "fooLiDYKVv93g55kONIidJQq2bIWNbEjdAtSzRZc5IG4JHFiqJ3pddhB7fDsrWFdsomMEMqR4kOKq3p3Ki2o6PRYo4RQgPR3bJGiuA7Cj4tcv/vcU9J6a4Q6"
    "uGzaPTfdbOISuE6xrm/2kLRlkGHKot0ezoUcoaKGTTkTTm6JCvOIdqdIjw4de2VR2PzY5ONHjkkt9AeC/rjZYMuq8+nxcxEAlB9J2eOUBmkJNQmhYeA+Utrg"
    "blKk8AS0T1bYegE1S7AXs6iGDHm85yynTcyljU0uKLGhOEu+aGu0k5OW3EwC1Jz2OXqli0GuWaLe55Ya6DnHri12cqzYZp/V+SuS2SUSGbWnrUQ/k5kD259c"
    "vgA6aK5xXMKO8xdC00bNE/T0YnNPYcJw75IhhuTTgY+fDDCclpyKd4zeS+R6filnezd/GrEFPRaFsLRrEJYVNXBgYm2MGG8vZZpAi7njcxXwnsFMLTMx2gqa"
    "KWHGCoU/7VG0CKUKtPGB2ZlMDAxhMWtsGukEcqfOTp+cAL+MkmZtdDDsncHzPlHIpxcePH0xcyhQb8A8Rnnw0Jkj0rHcQA+aA1QkeTma0uuAYN+F87MnYoY/"
    "1hcwKPFogowIVOUCXpXE7NlzWK1hFyGpa8B53NGAZHCoxmFZQYcUGCXN8cMmhpGbzNumeWFK5JxrY/+lrICd4wsU9RVzAogrII9Sjm9OeRrtzH8+P3v8JP6/"
    "tcVI33BrBLgGAXVzHikqf+lOAmKMwOoSKtvExJWRA3ufu2/Kb5ZSmLDo8thzieJsQtaknxbXIj+4fPbzLBlqnCA/kivToN/0Hn8LCokrMa8cJ1xpMcC4k4VK"
    "PbI9kVYOV5IiGZYgaU7wXo41brapBZ5EwmLolKfzQ/436tLDG5hUGbFSG/bHIP2BABTgHDtueZwmpUjC31iNsbhZuPv7/0GzAEjyGQfs7KwwQln4McpF11LD"
    "h+7IkzVz2B9EFLZTlThP5jvF5HOFUPWRerGqEipRRqLtuZ5QtNenkAfveifTOmGo8p/+6Z8m0qscqDwiAWmiT02B6XmLYr9e6HG8IIlCu7bPDqOaaYPho7Tt"
    "LPXFrnw6meyy7fmWPUPBTtmMqF0m3xKY4Wf39nqjZjWa2yInmM3q1jrT7UijECNGJHFL4wAiTN+YOC7riZgmF4rfOfUm0XVgsM4e59xr2GzsVZbJAxZPWBuP"
    "ywIOin6mt0CG8rO207XMWUGU2vhrNX3sXKteBq1KcTNccQtjHEn36BMMHU7TJ+0H4HiiHXkIq19RSsoEmT8M+zrmMB7KttHSbAytaPERNzdYd83e8J2qM0Ag"
    "PZNKJg0Ip0ONuWfa5J+S0jhQxvaS5nXgiBCQ5IYbYTs25qRhzR2kx1/p4GAmFEzG/OY1SC3p1D74VGKHZEMYwxU2gTCKg1g3W2vDz861XLc45h7gVBEUosOz"
    "OAFYp17NB5DmZQw7jHEgnO9dlh+dPDw/fwKnlMnloQhYbriNhrM1I+304ekVHUuCDrUCYJObyatiqA9C9bPaqVc/mZj67HPPCUtYH4MljUK7jCkf8fLipQdz"
    "6fXCFzJ3d5nbcZfRQnsyZjd/OeddLWGXUZ2N1QHW/MQDu9hALmpjTm1PdtFRbUN6P5DGALD7VNHlfW+qdHXVvaSEMaCjQoB28l9rIoIsorw6F1jx9UhaNKYx"
    "UpJRtgq38+R1TzDM2kgT9/o199mUT08fHj08Ap0z2W48CEyL5ghu0TOZSBqRod/xTSBRPmm0GrY55QLMsPEkYq7Qq8LoIuXXU7nRujtFHAeBpBo7PgtG6JWD"
    "shAxs6E9uyT/EX77XB+/CY5FydGE7o+z18jngm4AeicFFHf6Q6hLZuIxYmz4VItOAiu74RSkQY1KNFS+IU0I0oNAxTg7cewAZBUZko8NZR+kMmmWC5yuKafn"
    "7ROQIeLYIwOhztFTfbesTIDm134QHYgxbrYqBKXNbd08664r0SSrpwCQHqfMzJSRYUHUCTKwCkYglNggBLioxaQFFEaTogKTiONmsRC31tR8kBrfuGGS1pzq"
    "BFyOar9mB7iHkOOCziwYpKq53vCzfdMM8VkV1aTrP6OgEWP54tX0IdDozo9pEAf4KqdW1YTjwsHEezZ79sXMZGFRTgm8v1y0gWLxntsgBXLSeAySNMq6ImnX"
    "YLrXqZJ4L4MMaU16NyUTuEm9TIOW8aSwnplJhiyCRxXUo8teXjgK24rV7QAPvFhuSZrU7fg8YOqWnOsH7HYjNoOjkveeIueRiLfXImGvRx6ij516aHh8UtcC"
    "4KSY+sjuGQhQKHrY9/7l01f3Gkavpi3QRmKIDvSO6SAO9pqtO+T63jA7JObISM4KYgs2OTgBzC7YomrvM1Al+boDiL3ydEliOkPUGAzizUHnNgNrfo8NbvJG"
    "6VnzI0PgJ4/UZEH1KY/OUFNNT81dqSdNT1M0iWukj28FM76ZvJLLOXubde2NwYNANgx1TmHXJpDlEAyLT+hV0rP9S9PCgJmmd+3JXpRt2H4aOBxDnH7QSaVb"
    "jtO2R+Z1fIFs0uneddtJ2f1CvjcKIoH0OWw/ImeR7uPrHetS0b3dm+gURqILOxKoV1i35oKLlmNkxxL3mVP0+Ol3k9k1JtsbzrIaM1Nkx3e3zcTtlDCFQ+0l"
    "In/B7SWIhoKfd+JSePAkBdNzORcFaQW+xMtLwYAHGnaSIFC5hBx++828p9ZJAvtep53Trb+fQGonCVmBgGJSzWNiDSyMN9Qe1K1T6hr4EaN96VWst0ClASQb"
    "BHlAGP0ZWtO8zwXHtjpLWdhUi2/Myp1aY207AR7WxUxz9IWAPRnn0YthsEsBMTOZ3JH8IvUOgWpaINsfz72ozytaLTjYRGy+LkW9Yo0+3VuYrFJsUE/KNEzc"
    "nuMCszXTubYjE7koVRrJvuySfBFFA0tBeCdAfC7SBxUUt2LOKg1v8yNdpv6kQSpBOT9jPfgIoZ5fSDXqtM9QN+DQ3I6HRRHz8yRw/bU8IwospIzej2pXA+iq"
    "Hm+XTSE91iMjue8s7Nt6BDsxW9xuvrBEBIJNdpjk8uR8p8bM4ATVdbaHTYtuYe6DrpdMv/JCmTwTmp2rj4lfz0qjxFsVz375D8xQssg/O8fQhzJBU6uOX766"
    "p/IE3cUqZ+miAXmkKzlbSixQe94W5QaWz3U+2cvOEjxKfXAZOGaauIKkKaEsVA6CtPC97kRT6GPncHD3NmZ7RVs3E8pbPC2Md6zSrEHJ0wYcvlaqQQUwnilH"
    "odlMEorBlDbZw4g8G0aO3Zz01ByhTRv2hmLOMTNGUrK3yb4mvrp0L/+nD7MQGs/NK25c8mrtQfbq/hSgqescL4hgNABHC5g4ndxtGO7u+YXUR412EkTZmUIT"
    "W5KNbHeyeXGDHS+9drjryBFPZwgkfsCKNlySNAdbd8c5YJNxp84JhxtJ7sIEjcso1T08mVZ5eZwpBRONdJvAurI9eUZyHJ9YkR+veHmaqJT1xY1Ra3sakm7N"
    "7xctFb6jvDDD7YWruqaZD1I3rJkWSCEDmccKXrvjvpkcn7TCij1TkoypGMwAPkiQlWnE/BdodokJLBAIs3jctIx2X7Is3qCSWoWJa5rQcCal0sLrfS72uEOt"
    "poYjmAZSccd0XH4Z9tqid5KmVIpBUecuUdAiKC7/o2qyMLfr7I+3v729huMmxCpHCKqk/DqiT2lRcsiKncZBa9GYx31AeD0G6WgL259KqI9oz2HIj9sr9FZa"
    "/vdCXTGJ3Fzt914pmWDI4JQjkBoj14KRC5whU1S1p+Y8HExZdIPCy7XiqB2aIcEGx5GOS+yv7o5C2gpp5E7eiEyh/UKmUVwKNfvD88uOW7P6CB7OqTp6eEUh"
    "nKbLpA5X4PkYCAuBUlUqAOqddS0ZtINWah5M0PkSPkcDdlBeMtovrcN4jx7Xrh1z6p2ZJpRYNruGOlQkixsBonSGNOCweM5ouxc+KDEc5EL/EK5RnNiC8VIY"
    "bkIjAJ13rTIOoVlauDoGXayZaIjOZxGTjJmpTa+adssHuOfsS76d6eU9pcskfVmqfkVKtzzNBIF5UHd0+udn7Xv28mYLmJwXPedP827DuQDKCZiCxkqw9dUz"
    "YzO7mZBSugPyp8PM33V32h42nqTgLw4rKzIVirSaxhaMOGgOg0nl3khzQcsxCQrdQadwQ50ZtDp8FNOHBSUIEucVrAzoYVIzF24hXUNLyYOoAYKQrwZq1cUp"
    "xmaucZaarfL9FtvOkSIddqPXqFsNSZEEfredWTBSJ5e9ZqiCvrJT7ZFS0luDBSsGowcMl6JFtRhBgtBOCc3J/bDEn0c2mmHT4iDYIpeSyBGwKTmta7TyzBwm"
    "lZ+9SCxbtKS5kg54YgUpplRh4A+gUVZvJG0ixfbm08ApVlKhk1D7rjM0wUTvu2l2SpHRiSBVx4uNW8bJkdZcEAi4s1kTkozvlgz6qTEfL22KVFVydxbY907f"
    "09RIaD1IuA9uArKb9sBTJW0JQLMbaU70yC0XW1nL2eBQH4KWKsdrjkYEj00n5Xkde31sByamXfgzdvQW5BIVn/z9ZUm9X6iXZk5DICel/k/ShW3lR1X23S5c"
    "SOOQ6RDaL27HSQx0P56zTm6uXc2FzmpQkuUx8tfF9mWoB7PIqmnrIpLbUJCDUi4syMQWBWDWLOLzFRUfD4/Pzx9DVxL7YwokdGB4wq4DvHaI+szcOW+4RYFn"
    "aseVOUXnjOAXFXxLeFTq/dxDTmyZnY54SoATnJhDjC27pW/i5EqM9BxS0bIybGSRZusFpCLTwjSLJa4sUTmgVRx7CgLW/vgvQ1V3cn+P0UZ/kStGsE7vBQY4"
    "LN2Vu5rqKTwWXKzgKNDWRUsdsqD9GpWpzSZsXF34BpwVtdNNA0wgMfv9xrEXWGrsOrA5yD1TLkf0dE+Y0eKO/VZb2Jjl9SRQBDS00DcHnR07ZssJvj6sUnZ1"
    "AnPZWaZpdnV/FKTsatNCaACCJr8mGF8ahQnJuGNElpCjnQCW4lYye8nXps120Sawqcr5TFRpib3yacgJJGQE84FNwc5TgBbcaowMtEQ5+PujNlvbugW3giNQ"
    "ZZoRCvUTiPLtuLQLJjSbllG5hp0snj4heFNcxrDpecygoTg438pgHVeSCI4e1AnApE/TmnYGVnkr9sAiZieM8jEtqC/ICOAblnUzCDM0lIjbYeTIEc/6pwRt"
    "02sPpApMpFrISQ1zQ01HeAuYHPNCcCPVKkzCsPlzQsx63a0o7BPkl0AzNjNdF3//xmaeJoA1A1jD9wCDQl9NuUZ2FrCLWA9h5mmK0FMOKrhIUjiE4hPCURDE"
    "TJlVjEMWRpUXfL5zkk+mHIWTJaA4p+WfrG4wBbL5xIzMH7NDeZN7wOSjLIzYC7kVndWEHUkuJkbgJAJUP8aPeupEu0ohehprlTomERWQJpngvGjTSzAsOxZF"
    "cEaRY4DeaieqIIPp7KU1oYQVx3b6nVoYiErbNJlXCLCANFpGMzd8cisO0Zyjy/ECi0eDRbRk7Y5iUjFnHTflkPIAScdMefICYLpqdux1fKFBO2FAHzvrh4+4"
    "Pbv86WpIq4W31+TBobTYh+mOA8+WyU5iTUTsaHOiWxI5bMS0EeS/uIeU7hk1pRlf88I3lDzdmwqsGZFs5NJ00vrAynkZI7VgJ/Y7lWsaIfirdttkk/YCko5C"
    "BKMV3mV3XTFyfi5OFcfM14osR5xCWU1J6PshwYIKwbDmUddq5hooIgNpHaY4NOIvqMU4HS49kmaE6hCMr2zHR1zvzoeqUIzOSg5t3Ptp7ioPGwU8e/WcjfP3"
    "xo1ofqCU1U5wUB5+TNrdCzGDOUThd7Ktp4KVaL9BAoHlhloyBq9OLp8ecQEzOgUHjLdgnIgox5peww4sUv601D1ocsTtZQtM5f1it1mp4eMk0VAwc69J2JTX"
    "IOVR4ragVtAXhs+MEcu9ih9ZO3t9uSef2CpE5Y6F/DWSzDCEnyelOkP4kRKlKRIzNSt1u7EWsW222fF2SFEVojnTmiv+dCTVi7wWT3uzckCYcz5CINIddoer"
    "FRcDmRNGttUMQNHHALJ35EEaU8mDoDicnF+KgTgwwRaigJ+4sZaapfbGd4A1ySJ3ClvMmbmASe91FkPZ0jv5QyhlzjDd/ia2NonX0Yxur/sy0CbW/S7nw9Dk"
    "cnigreruJUVQaMXlO8bFhFGV5WVnfzmWGtOAckrUp8fupEwhd7SVWiNDU3Xl5T7OtVtliT7MNKxBIArABg6fWgkbDEyaIGguLundowGnZfVtrFXsjd8dTso9"
    "AUuloWPfSpibaLSBOiG1p4heHvGJV/Wc0M2pe2p950RP0TbeaRYEZ1kji1FLaf2kVpp1dCGmQHIJAWE8f7g/u6roTXLVxBQ7/YaBFLSeFxqZojEN9Hsx8Deo"
    "5J7Y2QA0skJEzHyzM2jpHNXuiGodkh1yR4edPBfUT+mUx6iovs+oyivxVfDJ2VuFxzInQXN8RozRCPmYkzovDozAA2KtkNt5zI83nzJXzr+hbxnIhtvNh5J7"
    "qaI0M9pozgh5k5L8p7wDoz7/CWMUltjYGxbO7xXGlApYLv0A5Txzgyp2DOxqpveSRpbTTPOI7dwfE2tXe/x5mh5luMn0wC1Ly+dR5wMnaQNTTS77aVMzFNYt"
    "jXNKZy0dGb1YNIr2Feigt8edZGcSSAKamgSrff/I8TmfqI5yILFeTtnTNHNb/NDhjDE7zhHU3FzMkkRZjfdMYcAlDWI1nuz3xuY6VkAE6YRsIr3b3hacC4fk"
    "5N6FmUCwR+6+cN3xskzKL87uvafDOnaSswUhVKdkc3rwdZn9u93pGI4mLRPeurMidrQouaznXBjeOg/WAS+nClTjcsdTk7PhBAYTIaQpXfdM02J4L5caSwIa"
    "tJmy0GaiF4tMmCt7mOA5fttr9nRvsBy0N7k9TXQpDud9LmYFEvl/TzTH4ojJPaGhiY54S2k3VXDuDnv18zdLLdTCHax7+Pnm7f96++HXo09v3rbAT0/zsjXp"
    "DMyuBeCz2gBKSSGcxgtnXRk+h6l3QFeAIL2QFK3z+gsCem2IwXCD99HcZ9CYf4N3agkjeY8e145n3CiFkmZkiWLMZpLZeZ4KyRaxU/MVmCRmp8gRSmiz5DKm"
    "pBk7de9EGXMWGdVlfNIRH41k+lVwigA8wuPezkvzyNDrilEIjN60It4LnJBmd5Oj4hG46RbhATvi7uay2dyeyo9y9GRTZIdpwY+tydgz76CHYqcCaYTbjvwc"
    "43YpkAZ9tyP9hz4xy7Apj2F3dEzYbcMYsNF6ePb23Zvr23hJb9MlzcV8+DlmvvCycnNPBKrpYrm5JwJpHAglOebmngiscyG0XG4kiODyTcB8oZtpU++uI18e"
    "HA1kuJHNB+Juek8hysWBNh2ZZFPrB840Iog1wDTOO4NwY6+4UxvCrjCxHcRVwv0yspYJcjM/ZvoL92t8taiVa6ILqT3MRez0OjXhx/N1wshMY5zx/Snv4B4v"
    "H4KSZ7+QSe4C7w8zbyUbbTnB9p4CVeRSwDTOiLRwnzKFfbayeMDdFfHIegiHptUjHgOhjJ47b0xoMunYhqAKgTdM33HytXzEOdNl6t96TwLsDhTA27mmge3q"
    "bfTkHoUnNA+R5FkFbtAkZ0v0VEdu5iMGzDtb8OWQc0SOILzWjITzZWPiMJp2R5sUrwyCu2jAQ0AO+d28jBTPiiYSdzcEst8PX3XM1ATZvYm/nC5B3hh1iaGo"
    "iRVgO2M7ivUDZwZMbaHtuN2dwgOzl1O/X+yHzJBd7xhVku4d11vbBN0f1JINXNylZXIBkEqXgbhK9EV3rVlwr81qNZPLbeZOymgRPPld/iI54xS29D65kvxR"
    "2F0JCzbV/AEdrhPn3ti1qXt3GwL77OjsaHc/8KBmYMnXCnML7xluM9KBYDFpokbEKXa2hWDhx9VdcF662WtKYc1efheOlbAOJRlodkJMc713gKcpQ5qMVoXA"
    "bDRhdpjIBhf2BeNpd2JPol333FS5YPTcnQU4+ZHqQ9jFgBqLGEFQnz1+IVIxzGLrmUIM12ju7k5zbqdsF6OTGKTGRCVHFCaKYPcPEoPhrOez8ycSdkOv4wQm"
    "7hqlOIoBmkmm6n2fOq7gM7vNWb5hk8j3Im5yonxxvckm0WIvzlG2v1dEw5uZCGrH3YpZKc4qImwQO0qEIM4EJx8sZBj3la/jAPoeJBg4JpJBra6/l4yPJZWU"
    "3inpPLG7R0btFFBgFxJ3FN5bEr++tq78BsiqPHDfD5tJYl11r9Trvs/YAZtK9IkGrSVf1p6qOzmEOPMTNYSjehcfnnlyLsVT8Ouk/g2Ml0RNDRgJBJhDQ6PN"
    "8yB1WjFO1b++eJnhMSdposc7LwAOwwqryWLAi1IhxFlACKq7C+Fi4OAqWHcv6dm9VEGGBw47vQmYoTt/TyGKsxDnQRAQKZg7n0J31Ws67AiDmdmXQ0CoO0dL"
    "+2ciMA2FIlkiVVxLHygBzh/YnGX3fJ+6PzoPC0DV3ubOnx+fioYsfbG9Lz2z6iX3vxZlce+5dxBX2wPckV/k3VOHYZkOYAW0zLKkDrcMzzJCc+Sa//wNzHtH"
    "S5tml4uAeEnY0El2e0wpK5Sn7qiutFWO7NiqvajlkVJk7zvxdQI5lwLLXmvEabScsY87CEmAoO5L71/Y0ELUPUJS0lfmsBWfBzCHFChPZGsbkeGxj1TsoPm9"
    "jV4Kg0PnLmX7kCVvFjmaORwjCqLsefu2dpIGOM2kJhnmnhGiZnJ1SUlwsi8QeXNpdIM2yGCLrzVpd9Jdq9y8vXtWGIDdkUBLOnGohlp1YNy8IG2JLS/JZHTM"
    "U4q2FmscXuY+giyYoXMkhL1jGSsH3kUvAUlZgGqCFTZeZ9LcO5Rvx6Seu0RKfmrSmkYQwyhL9mqPOM1eqhEoGvoWoJ1U217HJDkfSF3+04t73oVks96ZvSiF"
    "wLB7/OT0W3LMDC68lvZG53HvLIYbt97jWhrAsvtrApNevif382XtuFIIM34hGuqQlMSSbHQTqKiB25ZYlkQ2tesTaUt9o4NjxxWDe3+w1hXqTWR2R17uMbkp"
    "1RdHHaSEqB6F9HwasrDMNHRtx+VRU0eloPUUptzRwGe8/0bSzDPdRHwdH7zjf6oj7FBZL/RB1uTY+0SLAJbjQRJqA5a1AwVx7eJb1trR3/AUVdGcK0dyfvXN"
    "SDmGmjXA/xshP32+e3D49wfT7aY/5vTQ71X8j/6+/K/K/6vBP7W/q+nv7T/zrwh03PCHBwerzPcP/v7goO32/YPb339/cPh89+Xm+we/3Xz67ebBwavvH7y/"
    "/fz2j7izB978f9/dfPju05dP3/3/X5T6/frd57fvrz9959WD+E1AF2pfMX9D+3cN/g3/k6b/VPfpQtnn0vYZX/8JbjRuAeifYwv0RfQItfDPeLP4QDX8p7JB"
    "o3XZoLb/yYMcjtqBDfhm5xPrf6unZeutruv9m1G7t9oVJ3qi+BToFeNLnlFVsbdS/1NPdPPlI8z9qHl3Hcnnu99uvvuYvuEm3P329rfrT+kDhn4IsZK77nkr"
    "e5evWOj63/UD3FI+QP2naQuZoTNuz7ehmQ2r77/t06ebCFv+DmfQZ4y9W37vVj3oH2sTfQIVYkZtjpVxLI3Sq2Kvo8NUgtD1KlYjsw9sdEBWPHMMtXPW+yxu"
    "PvnGQVZXWTG/R+viHocwoyeIORPmaPxZcsiuyO/gGfrKgjcln2Gp98FiTAkCqb+jfr+q1AJXj0tSBzNG/3nb9HV64pSYIWnCwiZuqn1hRIkfsfgv0y4+nGHT"
    "wctThK+r6bokwlC8rAxlu35hr8n5uBOsgPIMZUbmdh5rXj+Qe8LhShkFtIBszPtEIcKgj7VUQ/iPclsY9IVHo0WVS7Gqi5rEhxJoDSCbsVXqJX3iP4Vt2dWI"
    "hZ6m/H3ajSyzNSPh0anU/Zsm9FZ+/+5bpQXyUGNurFkxPaOShMqiHtLuYK2ah/mvQKWWzkFxSbNqvWZJRFJR5psEyv1W5LaV+Jb6xpvonhxqnvCYMGO6ZvVv"
    "ntkgotZr0apX/1+ITIYzDiRdTjNHr0UdcVKM62ds6r9GgmQ/DdVMFKPJcaaCZgQgb5qR7dut0LTpsvk/bNsA19ZMDjOH55B9X1lkIZqJVhSszQnItP4HkMly"
    "ZoUStVSJB89iX02U0yREV5TUfwFRWKpO8crHJN/qXpbK7W34T2LG8L9wmoMWlFfGHGf/w+mEwFq2VXOwsmJLE2w59VszBtms+cz75JTxycGgfdmloH2XC21I"
    "+esfUAeTqGmsXQjDE42upiLMyzWCyr+a9PVLxhHEaDz11YXBW7IIKtWmujIrEOtyBR/X6UtwxSVloLProm3P767XErImJbH8urJN9OP/G39+ffe323c3+UD/"
    "dv0p3t4P6h+V12qLtp/fVrvqJTOrP6K5/Le48IPPvx90JN5/uYuS8Ict0fEft4eac/X9g4//FrHih22N//j+kNKeIlYcXl+/S89ufj+0jKr0149fPsf//Xx9"
    "eP3m7evr9I93h5pxUKedpDVy6lF+VuJ93z+4+xQNhx+8j//4+svhtS0rlxyVvN7f764/RDzMkN7/sKryj1b94Hzd4voP9dcqvyuUH/aviG8ruWYFyJQN6fqv"
    "urxxZArkvLgsDltmWxmQ8QB1RO+r3wA/cPsFrO99MI/hAL+Fzs36Y1SM+IAZywZ+TkyjugLt9p9BgfevgsGpAQ96b6H+t/EaZu4X2ANgsO3AwISIDAL9MxUG"
    "zXQpRzE8gsxsQ7wbEHbFD8CrwRZnd3jdBVOGmX9APDbiPFnw8nRzoDT7AdOOuNNDhqZzeNpbyN/7KyLOqgc1BYvAFLIBIev2dniC4O14xgH8iDuIp+MXJT4B"
    "CaJcbSTE/7GqfqegcL2gJzR4G3KiKRMPYDFK+yu50vw2iHDIfgN7AlOTHtTMx0yrhXOVH6IfaEzV4/f4SOZ7BycDYwPMNFOw0ntKRHVfaTeozrtCk0tu0H1c"
    "mnAkljuSRolIT258AI2Mqi8HjKC9+D2+pfLniAH/3ar6HCBA+9EN4oZDYuQngGDgE3IdFh8iWK685E1UwPuKgNzIywoukPegb0evgaQzTgCu3/4KRijRuzDc"
    "XTRZQkdf1TeMMxkvwANeKhOAlFoYwOTRrG+fS//b909P0BkAbkqwb3yLdDdV1EfNIqkQvt0CIQF4Hfh06+9vRrrHkFt94FW5fdMWB8c0Fo47zl2iWlZkvivA"
    "DN9XDtNeWP8wmAFAZUKScPfxQhCvt3WtmXn0F6FefuAcp4ln0230w5msB8hl0QyiTgZjFXz480YH2kP2BDBhegv4iHgegB3U40jnP97ftLLBqfvR3CBpAjfa"
    "r7BpkMw0OkDxlv4Y4AiUx3eQ8MbSiB777iI0wePxKfOzsdpNEztwT3SiVgWcrwNfF0QRgLqIoQ0Gwg7ja2g7vnBcE/wjpJXpygeSgJMFGyKH0Z9wQ6nquwmV"
    "wdsoxwfRZP6yZjwUHIQaUNefKhNQHdcAVPv5xwMohJ75goF8oaw3XjwzOvQMsMnxdzB1De/SQry3M+sacrIrFHcYDxB2QlrGFADwsJ85yVTm5Cz6NMw6McqW"
    "y4MI05gf4CkkMxpwFHJPyGKLq02iDNwPQE2EHeCL6zFjDjmAu3o/Ooy1RSBHUTNJB4bzDJTGGjf6O75bdIeEQsazuB10vx3D4V8J98lYFh5I00HbED16vES9"
    "QrrhfO8WXQdEzgH78QBKaDj8rnT/8QDKFBBtQJnQh6Tyg1GbhQRk1FDqQUC1q1Cj29FQnvrfhsvkQIsEGNQlIokgFvwIwkUCI+8Ch8wND/H8zvmb27s+HkDR"
    "SV2PvLuuiRG5Yd7HA2h2JPzeVriRecm1tAnwRpGMvqEmjWxNQK5KxxoybHCcOFGrDYvdgCvckd0jSoSMoTNxtBL4ugjP2Jlq55kZGmCPBEL1b0w5ZN+NGMpE"
    "3RMn0jJzMmCtm4lPEosLbw3QDduAn2VKHeMRTdcjrnLTQuk+8H0Id5BgzoouUaoZwt3QJiCHapVls62nWTsDqpeFKY9jpcnGgZXzCI+R5qMF3RQgIKGUMO87"
    "5C8bvUo4bk71GTTJOv0c5LhC2oIqJZZPeEpyyQ8eGdAzS0N4PZMNOiN6GoanaipWTLtCftirsLgWrMiBkzAlmiNZvHfESCxjqUE1GaMPvCXGNNCMYaIZV4QW"
    "NHnNWsSK92t1kgFV91gBNo2iWrUKY7h0mDZXjOHBeqiDTfEkFjwUoYazxdsXc6O5WdSZ5RdRQaECYthzMzsyoJ800EW68Ic7D01Ij842XbHrv8SMDXPqor5F"
    "Bp7bBAnjsvG9ac4616LIGbpE7zUBNbnyBaBfMnjZ2ETVMtqYJ+QJgFhPBtxnDagOLOP4p2EtwI66oz8+FkGc1wPLfIif5oEwoHu2YrDxQ+IMSFDTUAF6O8FV"
    "ZB/Df8e8xtRvPsV6HBpEXw+01ulInCbMPD4gYzgwRhn+9m42a7J5y9tRiIfiR4NwgMjRA5+GWTLhLmW1Zr6hcTxIW4KIiG1TvDeq3RhGwy97xa1Qvk8x3s4d"
    "W9ec+q+tiIRHB82rP2OX76muV5hEvPkLwMqTytCr6KdAQachONuARTvVdt2aFrdvKkPWOE2dogq1bjVrI2hOwCiW5wVeH0ZINi6+fsKzR8dlWl/nhJ0DD3sM"
    "1czxigP9OohKYUa7sTaYc5Fbqr58Vf736mcigCc8H2jICCMr4JEVfGIzExvnLdLI+NFfQb7DL7/o5ftftP1e/aNSy2ZX7xev/OKcXpbvUxaEVcFqE/9mnfPa"
    "GPvX738xW4J3a1jtakJw62q9d3kNF+IqS/z3Reu42F//mlf/xa75F8Eum1q91stqzJb/pvXm4grB2EVbY9c1/aK82izOu03ZbVHpv8saSm1mdZvx6c2rW5zJ"
    "71D6+19+0Pln3lu/LkqtZt2M2up3TH9N3+HyIx23G+wWv3FdvVKhfEn8x21zq9l0iG9XS3mNy69J622rj9tzxpn4cGX+FOEXkz/bqvhuY+NCiws++PxWZdf4"
    "AhV8fKC10aadlck/MsHpoNYtbm4x8ZSWsimj45FbE79fhbCY9JMC71Zv43rpWNNNqfLVKhjtdVjjclvclFnTS4JqHxHPPV52cItZ44/9yv1t3EdcSektfmKI"
    "+/ZWlwuPW0oHp9Y1foVx9DbcusQPiLdr4yfG37J/TL/Zyjt0vCS7OuW2sPiIjeWzVxdfokPcl16Ds38tSPiL0fUC452G+M0qaKOcygcSz1nH81jjw8XE2x33"
    "bSJmWhuCNfFB+sj8DuusiciRvlxbHe8yf4kJ40uWxbi4mlniL7e6X/rH+vX5kV5sfM2SkojiG8txRRSP68cdbVvEfJ9fErGk3oddE8rHBa2NV1fIkv6tXGBe"
    "PxJd/Djv1+BXZxpaRRKM9Gt8iBQST7kclu5f7+JbfTAmUa9e6ra09nZz3mgXSdov5TPyMS6L9SbyhtUbs9hCGmaLf4jP4/1F+lCDym25jkjjerM2E+pW6Vbb"
    "SFpGRRIwetniy+NvVl++I4LGi9VxUzouXLYZSX5JZKQjqcZ3+WW6Dh3PfHHbsqp4l8ayfwSIFb8x6Pgk3soW8akg1hJ/ED978WskG1XOapBHZEkRReJ5xMOJ"
    "K7J/S4dbPzviQfxq55dIbNtSsMqENfJP7+LbI/tcAuEiLvLWYJWLBL2sawjc3wCjiixJxd3Gu3CJZ9TL2Fyi+4gM8aIayx0EGFE//iLSgYtMPSIT+8d6tvnR"
    "EiKviCzEh0Tcql65T3zeR6JMB+gaOwSv8VvEqshqlkimwXrH/zX9ypXziogW0TnE84z8McRrqC+yWyTBZcvCJTLU9CIfr70wJxORM8T7iv+fOFFlDyodfPxb"
    "FFxRKARIhPGdIS6olyRHnKtsMfKA+OLIWE2I+9hsIUTtAXqpxSeKUGGJ6zr+j+k3q6ovinccBUDErU1F/C4fE6VoJIWI3S6ytPoxSeJu+VRN5LUhnpA33iRu"
    "1PBo1fG4QiShsK2Rw/61MzoVxUGUIDbEy47Ut+Uji8QR17aRJ8czSaiMeYqJ8jUJJrssfokSgPvbX7sOEBHbxnekr4hyydTjijeuXVQE4gPlIn+h/DfeYaS2"
    "NT6LW9lCUQ/iYUfJHbWKSJEhcRSzFEawJJYVGeIS3+F9Ic+kG0TeHZyPnxA5V2EqgBTV5iJyR9EdxeaiysVPf4w/2TJvTLLLxEUi01kj+20iNyJZZJgJD+Kb"
    "lnjSE7FE7mziJUd9JPHolf1j/E0hiiWxjIRb8SCDdWs9rIwCKp1gOuNC8hHn+zvMkthCRNeIM5EI2T8OwW5d/I7EoCNZZplQEDh9wZq4fRL4UYei+Bt5c1JC"
    "VJSvkUEs/B8B/kaOsMRvibhto4za1vKFUWVx8SuTPhFZpCtvWR14i05iKOJq/EcfyZX/a0LIvKArS6Zz85F96nov8Z2RBiPLSf8QMVKvjeork9NJsifVIKJk"
    "/ICwlpNJlx+POP2w0Ekje7tGuRuXic8iLzNrI/ukEUQ9zK9RZUlX5KlUiUgYeWJUNCJnckHxfxxSRSUZEBE+8RNttlB4WFRwo6qcpFBirlWzU2vH5SQaI+HH"
    "k4iEoDfub4Aio56UlPCoXkUIWxmBj/cW0kfGRxHZNkLzUXGKQiLqjil/OWoB7B+7Jh/FbiTWxAfjvuOFV0Q2SfuM/CYSWRSPwU6XH3XUeCaRnqI2l4QX98d+"
    "9Tb+a+SGkU7iP0VUajcSj2mLbD1KlYh6m5nw2CR9JiTFwCQOz/4R4rFL6m+0C3x6vFb1Zk0GRlST4rVHNlXpHtBkFAMh4VY8g2CjEeL4vwKqjIp72CKpJn64"
    "NtYdkdAlhS2ec2RyNv1f4/gFM6LylYROXC/yQddek8WkSqJwSSLWF9zPb7FZfka+sEUFSZdFEuOMKn3iefGPkYoJE4t4mLAlqsxR+Y+34fi/djYWCS/KjzWS"
    "SpJWS8XsqExHzmN1vBuTiOavRQ9pPD9hi0t6jkraRxXeS9KE4+dHHh7V3sxfynHpaEW5xEUjrsZLCRXDkkpmk7m0JHkQWTIlx8jHdTqdaOzEY66ISf84VDAV"
    "lc14zfGkooIXNdNiMUZWGbE4ss/CjwKWLFHhSFrCFtWJpIsEw/6xa6vRxHFReY7qQ9Qn4itMpZXIoeIJR+0sip3Ixyd9wqqkEsddJUZi2glMf4WYHFd0iSfE"
    "l5ikmpfLTyIio52N1Gn0Vl40SD8kURwJNl5OtMGL3Tj9sUvjeIYRdeLxZ8mYkLsYEdH2jFQara1o1sWfEg4WCWMzySCJlxpZyrqxf0zHXD8z3lOUizruOx5q"
    "ReMkA6LGErl6PuRQ1Iqt68bxpHUyViI+xSPwG/e3tC1d36EjZkdjOjKrqIOUw1LJSIkv0FGnjOzZFmG8jbuPrDWaV0uxWKKpwf4RUr1Okj3qD/Hv2oV699Fw"
    "tJGuI7v36WWEF8fLsVEiJAfAkjwB7B87yWeKiAgetxDtPW+X9o4o9tYtiZSonG1JcP31+wfvv6TONakSaEma/YMvn9++64VI16/f3tylzivqHxN3jcpkVFq3"
    "yOrjUT74eHeb/JH5aSbguPXIGuKpRkby4PfkmnpweBBZ1fKDVj9o853RB5MKWj7ffr5+92uqsYmWgPnHVOX0/va3m3elAutf0n9N9RWH/MVRQJS6mfSvUVF3"
    "rTom/Xt8va1JqYei2elWZ5KLcaJU1LA8Jf8xMssF1KmkvxWHD6jGye9ePCq8ORTlYQPFMfFP0UJNjQV6TU/+0xq1ulYsk/5gcj11reZJf4hsYpu9x2krUclK"
    "nSO42Q0YthBDkKpQxunJGZSH4uxxYbfsJK2UdG4x0FqWiUruftZxuZGoRfGzJgz6JDZ9P99AxHNa5ZJ/GJkZKINKhxxVfN2qpcrLVz93QZuvQEWb07GVM4fq"
    "gpMLPjJWRrVfLqrJa0QbzvKZA+UV2u8kMmU0sc7Pccd6iJHHWD6v/lDM64zZsAYoLxk5o22FYflIt1R6PqrC8tIm9Q/pJWWZKKPiBkrLymXYFRS0ldVdOpUe"
    "+BunHeVXmPs7SlC08qdcrFmclFicMUGpVSxmKlS3RGOdy9BNP4/2eJCLKA5Fh9mmCFG7De1WttrgUFyBmUZRbVo+1S3xshxNKjgZVYtWd5f3tFoNSgAzkYbE"
    "zVF53aFayQaU8ZUTcwkHIgMi3VeLU6JfCIhzcpDRKNdMIZ1pT51cl3UoyqWWS+7yJ0VS4LMbMi8IhsmQBV+fSWnTzGi1ym0qoc+lJmX5RA8fD38+ftRZblRs"
    "zYSsHADG03oiJhcpCynfGQ/Xgg5zPCz/PpkipPasiLRMW6XesvKXxNR7OUjhGItZSGpHEZqW7cEKQHRjeaTq7FA9w5uY3lnQslwTWwdXEGVzgU3QKJi/bNuc"
    "W0ZwPNoDbgonm7qCXgueTTVT9VISnn48pJbiCLsjdvjpricorbSTImrlcpL7Zb7SenxGZ16PKtvyqdmqaaSCr8JAly3f3+VFZGfg/aub+zYDmOIpCWzpW5ZW"
    "axE2fLJ6vn5vnFxslyC8WwOXEF3ekNTr3dhiOYjNbHNktV1hNAUcXx2TvyFLqoLaredjFnQqMHPeEYxW6VSnItS8qlvaqn28VrZYNNvemIBFojFS8WlRZPy6"
    "l2BesaPoXWKlaj5f74NYqpo/ZClcVK6pyhsOfmED902O5QYiQq1kEkmuslqpKKco1VlQtqLzgsHGbCUn4Z/htawTW+IApsqnSitFv+LyUbN0DZupA5h639TM"
    "NrWeiYkARYt247P/i9BYvJhsUhlGUlW5OunC4631FeuOnl8OOt+2ZhfwXZQhbNT7N7Ho2hCYnZLbemP2vpLssnGd1Q8xt7rw6SiG7qklKrtz4tRU0zSuZa+U"
    "rmq0uom83qM8I9y6cnwBwUS5wN2yrYRpdNYNIis5O38CpYGal+aBPh6enT+/vDo6G3w6rLPAkYC4HPyqKTpHEpDKlldtuK9GQPHIApvwWcnKO5oTnJF+1W6i"
    "VgRU1jabVBRRjcOQrwtOVsvu/yaHwc8gTDGZjJZrGfPuoyKelweNzLN8Vsy5AJh8dJvh1NDCyVftjVipVa7EJwPi4+FPF8+Q4rDOzIYByWyq9+IvId3GCwif"
    "QlDJrynWXxyKe8TvVCxlM0OHzJuPnv3l7Mejp6cPjx6OY1GmsUs0B24PdGq5UbwhwfNVvfXeQqa1p6dnT6D7Q3s3XxwCqsksy0wvRPlIgS2S0pwPaA0syXSY"
    "4vP2DiTHDXoz7cdYs+5A2Ta0hpFiBa+C8r4M4fYK/IJZlYXA2nozDHxjiM9engEaWI1lRzQjKKNWTo80VU4od1/mXD2XTEy01jE/i2I71PREq3588URDLdZo"
    "fvyxDMvVEZbvtc7t1YMVnXPd3G6dZPWmeI84ZofqMs911iRU6xSiTtEYdsh3vbtI0EFMBK1o3PjwPPKGsPnVCJuuyt7SNeo+/qd4cZr2i5EaAqUYU9GugEoS"
    "5eXMxCGAKs6AQ+s9W2zpKm7GKIYsvptaX2C/Cs9T94ICoMFyJU+z/B1Y3ilw0nxE9Sn0BZtuw7WfFnVPV8lw0981lEyrq4uuPmmai6mlTOWv/fJUVuMjBZ4+"
    "hqfSzHPAgQSI2R7pSmFGL73x9ojBz4WS8MyRjFkFtLHNDVy010dHl6dn5+PtKdNw1osIkK4nRmcVYbtKL3zdRvUXZYz56en5k1MiBrybpfwOGKtldyLKG/E7"
    "jY0amwn31EY1CZflPJrzU7ZTbA2s+lAorU2QSrMKW812TZIkz6H0sbkbHTMwFIkotXmxcD+bfcXZC9PQq9+GUQopkFGFERMBqJpSV7RpoddMCa0UiQbnqKcj"
    "XQznqANARWc0udWTq/5uV+zQ8/PHT08A6uogoYQAKpUPVQPPb/e2nahG0LKJZWMOvDHpZ0d/OT+DXGFZONWMhyJVQ66qVzYjzbPLn65+PDq6eAr1T73M6gID"
    "mPK5GBUUejhq3IgUCbnqaskcG7ZTy2pZUKGEEh5jZFrcOo3JpUB69VxLtrEu3z6gyIiwWrF3W3GEuY2thascXju5eU7ROVRzV8PdObT1qV9U9mgYn6nw9Ozq"
    "5Cmkr23muwIMLm9xzS1nTV/3x9OHz5DiOzOnHThc6uOarlBMoxeXVk3KAFUz7gVBEqVAzTxocqB2fw5b9104qF89KbzPvG+1C6twYbioTllJcDY3ulkNq/21"
    "g1Ku+wvnrjqHEpfc2CYZVU3trJStbCtmrq1KX50OCM5xdZzLZA8OcBTCd00wXqykK3H9NSPF2emTE3iXZsY3CYScIuUCOd+UtRCae0kx/HMOEWzJQE9xFv8P"
    "TVoGUnid8GRZzYysEKYElpOfvHb5yzS9NEWXWGUwOKOWYjKVOidwETh40b9PhCOjweA7jN4CF66u7uUagiDVu66paw7V9FWXb/PA0RnkCCwlyvK1ZI0ogipk"
    "+fTqObyV6axngCj2S7Da66ZjwVOmzgaTEhxnOeWrL78YPHCOXo4qr8pz/gMIxMeOtW/MyQpswVer2wgn5KstVDQ/OC45h7tXnk4wXFKQLG+6Qu/W0rXLPqps"
    "5ElMryBgOjO+ePgvLg2w4HU1x/CtCEDUSVtp2FrHN6YqON2DInyjoyqyuTyLerjR9NKkJ23V24rmBAdelrKOaZYZAdGbN1xbW7Cs0Dc06y+qR4vmBrg1tL8s"
    "TOcV1fQn4+U2kkUOWmXmFhsebX7qGll+uXTX0+XJExgmY1kcCwPvAPHiwtEXJmnHoIdTI8eCwOvK5Ah0ElRFQ3l4evwCmKrKsNiNoNRWVeijx2enP50+Ojm7"
    "WmdfO3b3fzvoeFXV4ool8OIY+4qVXzhCwlDJQK+/7sRZE3pX5GuBACVHiPhUhhS3i7LYN4JTZsKK3COdqLY5kt/uwiyBiZAwBkr1bxEHOQyRGcfLPRxI05Wv"
    "R64D2Y7dBDcbCzd7GYEBpEPyH7a+mfWta3Z4H11cPIXKTQi8B1SAm/2W4xU2S/TaI7wq+img+uZgVGOtWytXrhlSc55IfljsSCb7Ai7E1aEX2svR0NxVtmQj"
    "LAa2h8jhgWB5ZaEDtXKQ3S4MFYGsF2LlzcuqHS9R6w7VarXcWqVY+GuxmWqJdxqdmn3b3WCB3pYB80NxgRkmr0+3RJnFCw0piyKmLCktr9kR6zxDGMMY3XM8"
    "ANDAl6glebZlV7n+1U9Coe3ZmEXXOaGd49SM5ZlCKVAlIJITUlGl5lDiFTD/LYEjOKC5oIrXExeZgII2c0pfc+x1Mx0ifDPzXUlRnUeelRzlLAaPKumkUsc2"
    "K5qU/zcQvS6b3Ft4LLrX6KVFGMw9rYgL33ar2JKgZharrilMIDCKr7XQwaf6wqOhZ/aafDT90u53TiuacM/gnHfdcx42w2obKKCX6txIX8IcClUtLwMHG1bN"
    "zfpGMMo4rrNhX5U2poDZY4tbxA6IYIGpK1H2149kFPBwRCic2rZ2Qf1xS/epm34PnzVvk/HWVcpCGu7WxC5UpCBQ8R5uDLtoV6RDPubLn08fYney8UyeG4QC"
    "6eNQXSHakAoilqgWk3USbmN/iTUljwOMyM6HqudIFwAZzKUkrB1BI9NoNgCCgHwRkfFMIZKZah3QzJMZpuiI4NpMRYNZRYR32w2y6VRoglwNKwgtTSr333Ya"
    "yZbYu2rMG1mkfa8o/k3qIvRGO7yVJR2vtyHAmpLGxu5hcoD2voVI+2z6qkpv8kFhUB3W+zq+FjlWlLHqxaqIphyXN/94xjOus3aNF4eAWoDlU7ILb7gPqBqN"
    "rnb7MTp7p+Y4G4QZGmr/bSMcY6VfVgijltmdSxcvTgHUcelQG0ywyRwIyJgSQIyKCNIGot64sOoKgtLWrrzD7gjHGL0UUMIqo65ZM2zuXVHOclQi6L0+QYeu"
    "ku60yC+cryX+U1/gEbT4dE13ubx46VVqIJX1GKUt91sEpK23QIbWr1wNE+PGIPHucpYunXia1wz11/jh18mUNWtzEBBIjRaKopg8RwaEdy1NgEABDaotFW+E"
    "LlWdT6YnJRGAqXajuSYIXE8KqV/1ngI0Phq5kRP2opvBnQ0w2/MJxKCjqYVBq3JMTYXtLjM+zxAmR6WCwlm7tvihwEFxpqtdJRWzrWaLOCImlW05ITjkkTD1"
    "h1JayPoHAFipsw9MMRgMGS4b3+KwJgZuZYhWyX/UW+Zcx9XmjmgflnkT47FVnms+WUR9YOjxqBvsxUJ98eQcsBu/WCsmPwzImlvo5T6D1SbJH/Pw7efXt28/"
    "/Pj49t1v/edua7KLZIqz0GqUF8w9ZAt7aHbi1MK7bmWT5yM0R4+ebGR2M7pHO1Cz3kNrwsLPZil1EKa4Bb7c3X68uf7w3dFpK2nU7GFQQLPYsNtZuNTedYOB"
    "AAHvj++p2nPf8Fo54fZGKwwFjccW4L5JyQJGzHcg7G4pB4hnWVU/UeMqqH0gU70Z96758VdoIb7db/6wbVTEMpOyKt9xVmgNXFz9Zttr1V8xSS1sL+jmRdiE"
    "QVBVdzMlVfL4ZU1eaOoTiO+2h6amXk990kv9SLcSp9EN2f9WRQzKSQgtra959+hAkoKwixG7jefCa22a1YK+UvxBMvCc0LCyhLBXLXeRb+WNmjnYvmm1Fkd6"
    "zSqsvNGuqySTMGBqeyRIpFDDUstCW3AWNcgtYp4RgVW6haeRfUJkmPYttwa1fM3OSFV8VHW8eGtKRzpDV29mC2KWXq/0ua5q05jyBpabhwvkt1u9cNPVaqqF"
    "XXBz2cLkI8V51NkZG+Obas6m1sG4+JNDoPNQahZWBifz7YpPqjgsn3751y93/9bCIG4cwWi22UCKNRiE6XhjUXGGQS1E3Pbm4xW+7KSunxmFVr2x/fUJm3XV"
    "XziPg6hVUEZsmV/zNwJ3HFyJcDwXs9Pm/QCy/LgWyXWmqjW7E2/yCYdWnjYPFIMpOA2NkYiquUQdV8GtBNVTf3uv44rgm2bnTBUpZDczTVEqxXilXAB1B69v"
    "agEC/AUzpBleLHJiLc1/9Su3lMxXtZZQqwVm7AISDZs2ZDXnhAdAJTq0cT1zi/7tjNBLvzrEQnUCpRK8FkkxTsOrBE+LWuxW2lq74Flx2Fw9vWpeHhaN6XOp"
    "zXwp0y/ZNyUE13fgW2Yc/iGGMmZ1LeG7/W0xa4CfBp/pUnKWwp1dKhnvIDh8pjbvmJEilWcvHjHgoRsa4zXTQL9gqNmyc/bq5PLpUXtP8K0ihRxjB6rhOcNy"
    "t+7GaA5nTv6hF/qlhEej3E0OyoGK2H/U/VYETpvVsyk1TYnfjGbLLIa1UGqK4gdf//3D29/fvo5Iu45rDZYl4wm49BhzOwNRSjSmVH1/vH5987K/xCu9wYsn"
    "j1u1xSCBlnxcK9FAZ/8qEQIW8uB5iZgZkEDe3HG99hxvHkPZniYKvQXEUanr++m0pcIElBZGVo4uEtllB1dMvY+4zQGw4kNF303SyFPiSAC5Tc1TuWnR9AGQ"
    "RY1f+Bx7sJxClzm2SoMGThkQzmx/3tbNCrcAwbRzvEQg1WyhRHaq97/d4eZY3yyiq+Amj07oMXUPsks6EnP9eAiMbVUxJZAzvsYzPUpEIJj9SzLcVusmwx/C"
    "FOrQWpomWJIjtnbLKPDVHTVOzxH47sZxXnPJSbXlVUnOJpOnStVI6E4UNDwkG30/gFQFZkYVWqCZwv05dHhGfdzvTZMq369XaJSNhVpUb+llUhgA6UzGbSsw"
    "iDtQszWXlv+OH8NIcb5wMMW2GL/NnTja8+8YmE6tzOxbuBDT6L8E/lYvTZqtCb49+w6MKWgdLvzixIk59ecbnf0RmslkFjrlcdiznnFtMc3EFqPnicpV01VZ"
    "cTo/Oz7Heui2MhqU+ToD1nwBZjgzeIM426H6hpzeG4pcFnLbxo+q0T3NyezOGStchx8/UVMWFmlAadW9Ww76uAx0IMXgmBGhdkupbTjoxM7qSivxuodH6O4W"
    "Tn6Yrwis8OE17IyUa0U0QRr2cyjuE8NmY1Hrr/SWM8JQucqgmuo4vpW6F4zpYRlwVjAiUy0XRDjDe6VrO4Q2pKgYsCt3XhBE1fYYE7aBnKha3DShEqmqcN6K"
    "84yqxrlZkA3QRd/KZVMAoNp6u1FtrcOuHo+PdTQO1Wj0tkBHhWm8bQ2BG9pdE4Kg7m6gR0Ity0IHiOUeiGFjR8FXFbxFD9o81ColXIADqjtJpUEXrLSHmtza"
    "49FQ7Um9G+BxgMclq39jhgC2kMBKR2y1kiUzzdGujSocu024oRL6y8nhULlbPHfZBCiqERp+DE48sSoEZkQyLBOYEnOQhriUtIna72aY02GBLyWPayYcnKBc"
    "1NKeZDeokq5c8QqzQdvanGRJDsYdtvYmnb3CUYiwV0Gpi2yJ9HgWLV6En+lIWy8hEOSqHPtHwzF7upm2e0N4q53imZm5lSLCYlZh1HgxmfXCMTJYfVZ1OMPz"
    "dNUQyyCmAWtUiithpcO8IfEzc7iKc8eus+KFq19M9ZMxM7uKgawNN9mpKkQmTJyfuDq3UFKeTs4vUU5sTydjLDgMqns7RPQVvT6q0ggrgUkZWBNVk/yF3UMd"
    "Yy3jdVTqxM7K4BNan1ZTR9u9Tll1ESBbZn9+eoyPx7LfQ8CiBafJmLDymZsj2AQeq5V08mgJAj01Kju2bGhJPOcwbyBoTZZGz1sxV2fowM1sC3sDs5fzZreA"
    "NosfK6/MnPcOYYpeVYzmMZmwUK+zfGsGAqdMb2TJTistLgdu3HWtyVkR8bJAiVa5GyVdIpTvLIubQ3do80zIXPDavMUsk6EBgXKnyl76OU1ir5kBui3+7NXg"
    "QKUdIrr3/rjmpxc3wYfPb+5uP759jRQeizQADJKtk9KRDQ0BbD92fj422ysf0lwgxrCxvWZr6yYjGTEINVi7WUbXtCilqIbTuFmF5fSVsruDuwtZGcdPOK4u"
    "VG3FUfCtO12PG9raRApcjBUSOJSHp9Ts6dE5tI5ZBH517C7GR7E6Q8cz1hKznk4JZ5CWHl3NEmmjLqsZBr4XfqddjObuXfYbuKD4m0YqpSs2dp+vWTzoS/eg"
    "j8Gb8ptaKfdnNKhTo6XwFNQuT1O38o5q4zlIJzduhJbAGNXqSam2Lx4RCttxbD23GwCEVuLeY7HjWVOetd+6soD1OtlRoxdOhwPKg7VaGF5eGzwFJ40Vr5zV"
    "r0JvHXFXUEO3XH6KClbT2en5apzWCHtRc84VY2rruVlavIMpl6VNzzahEwJIwwZnLBiRmK23GASPobtTCxVZ4y1Fv18XvnspqHVTYa6KZSKey8qL0hlUVSSl"
    "pAuD9Ssbce4+GOuRXktHeRfcCD1yMM4I5gxo15OsICXVZNNtmfspwB1al63Zh0epnqnda2sHANZDAMvibOsz2P0Yfple1J4D+w23RgdODlUUsZdPT1o6KXu6"
    "7bnetrAzCriKssCffuvK7Q2koe6WKbrS4pBg6Fi72i1gutItxhamCh2cs6Nr7AJX4YBRArqLD/C8p0C5uVCm+wQ231z/iLeTTB27DeExwIBr2ZTo+/Fps4IN"
    "17QgPy6269aaqrQIntvYQusOUJp8p/bSL7PwbnFGs8C7wE/N2iuzyuMhaLZVBcTNaGKzrf1ULk5ILyuYamO/TgDJg4veCfpoLbr4+qp+3uNMnhfmBCxNx4Gv"
    "JrUHOEGiy0S9wAiiJYnrK9uHicYIFzvLf9IwI2xWnG5ek4d7DAZC1K7ExtlJ9I7S/N4HjAbTRgRQe88q97AiRrXSDyROiZdJraUoE4xFLs4rLpRgv0KwIi9s"
    "4FTU5hJJU35ZQYFqXEY3QqreoSbATjcfFiJeBKOsctxSpMus3oxnRQpxmYTS8fXo6vwZkWp+Zv4cVBkB/uh8vFvbLgMgfiGYFOEtWW9Xj5D5q63Y/IyA6qWk"
    "11weXV2SjlvNtQkY5ARVm8RzE7rzvVb8w6WMKAGsOxwLIVIj3fTmmNOdo/6CC5sIBb1OK4sUcJF0nLMGRasHTQmKP4cljHmOE7dNCFbjNPm0T05xHXdzH8Fw"
    "9gntKqhmmUR9ErX+/8Xzo7PTF7AnMSKd+OUQoPR1MIQfXgJXoh90jk4PWfM6GMpTSftSSybdl3h2b06K8BwBJY/Xirj87DFIhRgMI2NUzc1qzsE7dbxdArMe"
    "SjC1C+sqBgpnmunYMwGe3X76319uIvLffqrpeQqmx4PHU0CtDXxqWQEQVqPFWl4AhBjWld7cBhMDIBQc4aJ7T8QJrDeeGW2GJphhw+s+ymUCCjjh+f0M0Qwm"
    "vTb9FZ3znNS8edZ0VDVXe2nlz0cwFOI3rq8AhDF+m+VoVp7rHG4LO8MP1cQLt0shre5NvydYGN2wS5AuD9aJ9DSy+e4qrgQrXh3OXqjND5m7GQZ3VBqX2jm4"
    "27IoyQX+rAK1aXrTqZK8/LX4aHOj6JZyr/xcqg0BlOI60mIlWLUsJmTAAq21zOC2XA4cDN9F1sj0LcN9BFe7GM5axhlNi2PDxrjQ1XMhVZIcpYye075o2zrd"
    "c8NgRTZuL6LXhTnHqezaqFJb+vICRyMcU1CPQbTjVNhJeKVR0QI2UW92NJj45nsYarV8xT7pFDwb+z05LM2HnNPgaIqH0RvvAEEuh97UCO55ysaJBvjGlUAB"
    "T6WzCwcBDY7g7ZwTh1ScNAdYagEHcxhcSeAsbUm7i0poW9rskaU05Hz59Enj2C3fk1SsZQjY4ury2dMqUKzhRy0OEOt5CMICRs4MradrEq5mzcwFdTRZZK2p"
    "ILAwczN2bmyLQZTjv55kxWovwM2GeI+4EEiaMWrUxtdyYvamVSMChFEkEzb09C2Mdy2ivnl++6RvpGYVLtQbyOjgpzOlySPecCAozThwjULn2SfdCUU2jpsq"
    "mHz5V89fPEPG8eK5l0xgUW1uXUXOHp+NCGdoAbD5JgFcykQIzA1NbUo3r9k7ajMcdGs5TF5HLGLXG9ejZdjoZRrgy8ASm8VvXPPZKYQs3MQkjVRYxXND2RFr"
    "Y1Y0IwVGPu2ySIuhQGcwesI5mJFQQwiGSSqnUOs6L0WMduMcR5XEOWO036aVCEy0C7kS09qX34YgDaZAHVG0soybcuoar5lDgiZ44RWjx845ENmuX9d8EwjQ"
    "b4pFOpIcrraFT8ZgAs2m5ME/fYEGEHW/I7wnBKLt4rhUbyT8a3LYlM0NxLqvSvicqG27nPJsojZNq+l1XyiHQ6wuW0pNZXx8cfsvN3ff/bfvjq8/X6damJu7"
    "alFZRt2S4dW2Mg1ZUJ1QlEsrM7ewBwxMr+LA7MJ2t3ztH1faOrY/+mC4T4cgZt08GAlUZUW0Ttkm2hAmNTubnWW0f7ZrDf3mlie4SUMvYCOAcP6z6TWjBAjH"
    "H93G9iEJ+FVTG5KRhl6b9keB//jhRa/lMt6z5TEARjtlYI0ONGVyCV7Y6OPnT5G3i62PIYk+ppdfQ2wgo8ham0S6FvJmlqmznuUJrHSzfcDZHNxEq+Z06RTe"
    "e4WaqTjtPbcrCme0EkcIUtioGmvW/MGOOO/2xqUgUyme3VK0m/MzMNsN3d14VkebspV0VPJ0hywOTSDBYrSV6p860y9einXOT4KG0bIwfGcYc4vXfKZlzwld"
    "+fGhqNlH5fmG59V9WFZ3iWMANFszWJq8yPgxXSnw+NPRxdGZMb7zsT6QEFjeFEgr60iGNQxuRT1bs02lIA2nThE7eIToeTR8oll11M1tlOZ0iWOs2miG7KHC"
    "USbgohRo4iaxYWmtrS+eAvx1fttYfbRDlQ7Lmonb1cY2oaRB9zDAr38kVaUr4o2x4cd76Sn1Nyl3iPxIE4i7CQINpu2ylULB4oC1956iUC16uq29ToBAQCz2"
    "vSKHAAW86fcTACja7ccFxznPtGC5tnrNy6DCsvFBJNp7o9cVQlkPXIujVxxMzCC0NawGgBu0osP3/mnU/kDBWc/nquveCtBPegeRfmrryaEAiDgwQoudMJRM"
    "QkVGBzYiN1mcfeAbZCGsKNXGsPdDW0GGkd83DpamzZvNkigUGoeoPDM6HUsw0yUziqxPhoE2fbAQBARV+bZxoElFIJ7mpSTn1k7KnQs7z7e+JHDxYJzo8a+V"
    "GY0CyE6wO6LGvIUpHyT2jI1Q+M7J2LJa3l+bU92nLCG7DeOpclZic6j6dR1JeQQMqcc9KwoQc2u+5AJvb8KYU+H1lneQoZrmGjV+dHr56HwkZ3CV1AME1lwR"
    "VMR9K3pjeygxpwoy0XyGhozVzszzikaCkCmtIKOeDz1uvndpgV9CgJS1lmsDCtJVVNgWaSoi4op1gEydnTvaK5iZORMYYwStnQm1bKwGhNXjtXsBSutiqpGD"
    "Ipw2g1L3XKqARikE/AuCUShrpNhulu3Bhf1mqicm4J64HajIqzC5MmgE3gQ3e28mC8px9gcNK9UkiPi3Y+i5MSbI/SOPkbq/zDE3PoW9xhsuL161yKBFDTja"
    "3+0q2hkj5KEXLte5Z/fp0YEOAXTXhdpILyPc9dc25AdimvQO3qwopqciIavXletxjgq5rEZGOmkW3CNByLvDFGsEYWpQY6a6usJRkT3oIWMXQS0FKcdjGNvE"
    "+nsXci6py3zlG75omK9qKCNcwoZKV3DEwyjBHsTBik3NJVNEO9MII83sB+n5TxxV4KK82u+C67gPijS059rpT+RuhL48c6KYsuikqNu3lX7NKMt1HlPbxjRP"
    "5arULde6GFsGXVQwVToAsxwzrpVmaOg66S+uA6CAqretUqN1HDfVqie0DR2WBEnDGK3VLZPNGpzmip6GRfD7AJRu7RyoeERCOnihRpFUHXfywMwFtflVlplx"
    "oNF8WprQw1oHNfGNloygOdDeMaXS/HI9RQD2lyFeiKgEL5zrfq8VW3OqQXyE/er46YTQujS9IHVCItr6yRrPWFcjwF16KQVuR49R93avxdnjAHeGtoHvG6kR"
    "oTREOH51/BJN9dU9pDXzAArc5mHiYa2ja7plCjupNaWUYRRi4J6upZVu0meoXeXVPAByQqoxMoWTTQo36GZMEppjv3FN6/muxp6zDqbMEWVKkUBtfN+7mEl3"
    "QuCMYA/24hIdeCuVtiPr2A2T6LCCs2gaFeix7pq15clzrI6rICn3MKqr+lABGvybUrN7szTMB+hUBWu4HkcjV99wLcFBILw01OQS8WcD3ayeJUVovSi/WQkj"
    "u8tQM+wBVZzZtStmEAaUnClJ6I12Vi4JxrjC9bvPCcPtzQ/FeKtTTroxbII0CAWQrJ+rnsq6JVDCJy7VxCDY+XguqEaN0osq1ceYAKk3p4ECmGLVrVAbopUQ"
    "Rnuh3SHIPSnzC/kRi7AmP0prNoaC1MLI4o1wSbPLTk9NE4jXR6NKsqyvnh6jJHBr2MIK2iCoa42YZOYWVy1jeYqQg8RYv26sT5L2Pd2Ysi4CMxqnoOHTMHFM"
    "a80m+xNeZtiSO+qX4SMtdIJKUy7BnqaOLlazPhgEtLhlb7xrr5riPEqc4FM9RWTmuDDbRjtccE5cAnZbJCuHQJb5OalpA6ygiNbKJqWIYsjUqFrKuWesDG2N"
    "kxKzgU3ljZnTidnGyj0rllwA9kCnXqVSfjb2iDppYO80c0MJs09nv7ba2JSyOeriutsE1q3gYsNeGYjRu1kvOZCuF+Z1rNUeqZNJk54UQB/kpuzY4NGK67FE"
    "+Wzv3IJEM5HfamEzwYk9qvtwoAnV4eDGRWjXNncA1G5MXe89pRzb3BfB9DHleCQXMFVNLm9J2bovul+daasyP0V5zCQXo2u3UKX+f4V9a891yXHVf5nPsdSX"
    "qr7MtzETEsvYQ7AtBBFCJphkwCYICEiE/HfOeU7XbVXv4YOVzHn72Zfe3dV1WbUWHg7dCL7Ae3HSgeUjTfzzH6LmtylGxSM+jGsfLwRL7Kmt9XK+ArtXryQ0"
    "cL/4ta2GNSbdUEN+zMto1TtWoGhMmQv54FAIojsmmYC5sFn+LZ5GxykLB/It0eQfe64cFIU+zVcwflkIERvXtPgRK/jfg5D5l6v4lz/8+i9++fpf7xb+XsxA"
    "HPahKehPjQO/9GXfsvPHwqz17nfp4QBf1LTGFRER/LK69h2VFM+rqfzyoQL0CLHrpWygWfdb+ivefx2fv/pLTeuHDPDXPzzInqemPE2IhzZp0L95V21vFvY5"
    "keKVK1psuNNqm79WyJ69kaJpeca191akezozAx3dXv15S4SqcqvlStSUA8q2nkImzEGZeh085tWxqDXTh0CrfLuQyJgBIH5MPgFyZswLVUmOUz/cjjDs5kS2"
    "3i8ZOehsTf2pPqBvhW/tqaG8VPaka1u4S2G1m1yp4wb4WcjYu6f1W+Pjplx2Bu6flzP42INhWcNZxu0M8nyYikT0YWBqAV7rnqZJCfs1LrMQxGxOVunTOf5X"
    "f/VXwt4YkjOffzixCT3od1fJ2N3TkMCVeTmOAfQlqZhbJAGGqZb1NFTNY2k3WYB2IbgYxBecEvqlkQcP6Nr5Xr5Cq6R19GS9HvFjfA1FUX5g7X5toIZXpc6I"
    "sAkKq2YKbZ8hkqcrC7oHA6CxbL1nvE8Cl8w7TwjWputXvf3vvq2HXGOOXJz7/hDEtUONHmjxzx/SEmXC3Ih9tIjVe49uXeKTLlRvzOlV3D910XMXrRRWx8wQ"
    "FuxCfJ1j1ek+a6bqknFzQ37mhF4uW8QO3U+pZ48H/Sx5G5HYupWWIphp7Sv9tFyod1GPzE5WFYpTFT8LPLLliE7lzg1j/T9ZxFiA0CRjOV2hQVbtXJcPxjUJ"
    "GsqT81R+vBDqut7tWvZFXU7nkJkeuCl/ETHnDx13meO973UVCjDUgmLKXb75Xo44fDWBb0kffZd8SOXqz1FVDDqNcok2bzFDukadc2VVEl099SMU98+/+2d/"
    "/vMffvil9jTUcj+Mw8CfBZRS9MhN86eXT9f6L37+i9+qlkaaw8+/OsL1K2rG3I7BWY9JLE5fD120f67A1ifnTvErpgPv+7N8X33TYgiCyFAwuF46MH3BulG7"
    "CUNq12/vI2ng6UpS4ZUDnDLQxcno9ICrqioklQsM2oD6Yar4KTi7P+MaU25DBZrdvkb9icuF/oXZ79s1ssy8+27qh0Llt78NLRc8bnqMfhhbwuNAfeCQqAfO"
    "KUp8ZnI6R22ra+T5s0D1AWJ6cuKu/eTkOVE3kR2DQbLST2Xmu3/xi59/9/PvHFvYRawFB70Tg3mjeajHJ14NLxzFve/yRHBslhqUzgLbX6+rRgiaK9mXsS7a"
    "wGr/eg/V0dTToUQCN23XqNzU+vVFrjn+cmuISHizuuu+8++EWK/cFY1SH695mTGBBumWQpdv5R3IaxcZNjX3chXeQ66sC6e4+g18VBy90Ius2fbE4vyYA+l0"
    "0zLRM2zWnJ15Tgn5RmB5NL/nxiw3BQTYPC83gFJx8LsA370hYHBrLKS9jsdw30Fj4szgKBc3F8OXtup9lsPhVDbP+zDoBQFgHuCIy6JQB0Uqg8TMH8rztV0X"
    "hM+Vf4zaxd+JlHiqPAis7I4d/PUs60aF75MjSkBmQxJRwVTgYIpPQ3shT8rOTszAdY09Uo8BpEjKHDfqaw2RVmuJuVi3CY8QqGZP8aDihV9aPIXerjyDX2jh"
    "I3mVU0mCJSbSzlWXiROiVQXTBCMZAf1lXUvompSoiiuVANxzilAXpZLAVtkvNLRuzCd/cw2kHfTvw/iXLwTUmOZtHv5R7PGrj/2nybXppd2BeBH5w7SuD59g"
    "83vn3KW38591scYtVejpgdotDRgVT9u40b3at/5yJFsmHwMKFt71IQsA8JRWbvn46B0bmisAJeN5WKj/hOfq2UdoXjG4UKGqN/I2rPVoHctPVmowUKaJy9KJ"
    "iqHty51/Vy//DWaTIOY4PQDKZYCsQZGskTXNidVxWEMPDTfQTlcVgQm+u8JuPpHv5fyLGXKNX11IEsty+umxYyT0v7bZbtV/yLNOPcJOlAWhSlnrTsPiP/vp"
    "XRtfaTkRlVt3EeTvXLM2X6MMabBeMY4RuNukfUsJaSfluEiZ6h+X+WixjPWuH4rsa2JKZKikfyou1UsbJ4wRfHFMrlgv0R3cAcFLkwQVBlcVi8m+2AAy9q/X"
    "7DlHI1K1ozy2qFim4YjTQ5ijeo1X2PLvYjbkBpJ1aKdPU89FwboKWby42JIlOJUIzWH5zEMFXAyyuQE9jyxQTGBW5LRNlZjvwYbQekJXgZJRnSn4EA17ukNJ"
    "jP1g1ntSUbLhZctEQjgiO+6jFfztr16GIvW7V3UX4r96Isiq3KY4qMYB/z0N8Dod2n6Fg3yvh7LNwxjh0nm5uUqBDkN8b7sYk/TA8Yn/lAY4AcFbywIcYoVD"
    "+0pzPDi11BApnXVd+aLf5qtMo+ctnroL6EayYw6oUvb6gBKkoUcuoKgNbBkplfpVFVvmzUBWeh5PNYXQW8ebbsDdSBt3A1pEUpu+b02h6Ui7i6IAZrw9RDbn"
    "O54KcgxsZEtzOHoDZls6Nf4k/6pcPsJGn8pNVWRictzis9pGuhE9f2dyz7q4ba8WqTc15JI1oRAcMOgxedAyfjcecbxaBh04UMvlE7s8wseUXmjXkRnQ5HkB"
    "rO9Ycrr1lfnFgipkrT7Qjfjwpn9Afj8/FnnNFvpY5fd62duOslRm73I06wXo8hmwuqQQWq8r/px+og+5wW+/i6Un7i1Q0OC/m1fkYQ2/9LHuyxAFtD0CCSmo"
    "yjQruVRVZQnfz2vJ9r3mrZ3XSoGt3aG3kJiqa94lkO1KvYWA/nuTIL8W7v1Mha7rOCzahfoMjICir2Yfcy33dO9RDWgcdGcV8RVgon8elZRi6T8mQEpUizGQ"
    "0ltCxd8ZWoyqlnYDCB6hK1J4T7IVLqH+wS4/Fc0S59KAL2iSLzEV4onqetsXDwBAW1VZUW8gtABMIr6mrWKRq5X8bcIIDpoeHSkaHqhaAFb9erVLhgyDeQXX"
    "ROkRXf2K5PVfM2XxivKBZ7sWtkAr7Ymx5FrP7ke15Ib0kI1AlwxtutiXKBld+In+jXoxTyme1C7SbtI0kJyumx6DsMTKWUY25nhIVd79Tgfm+z/nnSgxACW7"
    "5sQy9jJ2sK0HBrKQfhpjPUxcOIqZ2+X5gfWnPObZfLj1KV4/jUw4p9WfhqKUzvE7IrCkflhXWsm9qnpIvE+5XG7XTbRnu4NSTlB7uHIQcaKZhXHvpQ2kKrXl"
    "cri1hz4wC4PN5/3onWT8N+0LVgETFa84u14zdQjzJ86pM8TutTXpnj3zwIBd9oUIOHYI0rzqTXi3ZtHtwZNO8M7fHTSHSUsFiTkckrSK2vOfEH1Vfbt0Fl1Y"
    "QV4BxbzQysR2wrn4xgkckfKtPbIw+31Z9wOMwpPyfAA8+QyEMdHFqf/XoDyvQ/sLgfDr//Xjf/zx964PZN+TOjCurpKZE0JNoOxb2Q9DoUkUO6GtynlKGJfW"
    "0ND0UG/qDuBQNQBDoHMyApYBa04BmVkhPSfSbO5ffcujnqxQNEhY5UvbMPTSllrnE7uPz6L1lWU6sumpKpiWDZXEYX0/dBjgV6y3ogfgNPfK5VTwVOscmI9J"
    "jgOP6518DzaN+exqxoa4r0X87b/6ja4coeBSGpTfuCQKGK5aVQvXD6vxGm8eG/evnu5Dhry76NwQIbH0Q970I/4qWmZQ6Sb/z8DF0CXHFh6zqsnkIyHp/lV7"
    "/m0qTmxqNbYPcoUzmiKu26Y7NAapuLzHulTh1Ivu5zHfIlWfjBAKXVG7EQ9cLHpffPfJfhNbNcYDxZrDEnIXTIqfvNhRKS2r+Alb+NcsCYABQlMll6QHcrIe"
    "2qkSgBYeIXcoqC4EOr+xU3v0C1tIxLdUjQejkxxoLqpqskMfivd9+0dz5Bf/+lfiWT+jv3SQhbSRJydBXG+JMvSv6ry3xHlS9X7JSCXTRKM/49aC2tLsl9oQ"
    "AC/LvIVIqWOrzSsCDsrS8xqi4skhBa10yziqL74BaMBDaKs9Rm9BVZePwNjLCuaRrrGrUjBECOzqChv0yOwjSvumloKWlUBIt6+Ir5AKMF4TDz/SjtLPgh9X"
    "UFY6OMalUyy5i5tDXhGVtjSWzRGoUll80go5TfUMfrVSREyM3JHyyhJy8SGuRIblw5n4z374pSP+ZDH8kcnNDWkBxdYzGm/dTD+0OH/a6V/P+ilz2rq5iELC"
    "mFJavxZVwqBZ1gPwyMGTXsv01ggbYQdrXci9woHw2YeX1h8cpAd0mNygar3nvkhVuGzlvohYB+6D0h4YgpGsnC9ybUlctI+fyGAEYv3S+08MDX2T0niANLWW"
    "KTcz5EdodvuackwCpEo8F8/FSO+kyzV8E6TOqfPipdgRqJFdWPOO9OpTltnPpfdAEVbv1iTQDRxA0J0zEnZbHXRpYI4IA2uBOJyLguZVOeELsYPf95S/CNaA"
    "W4kp7e9ObMM9lwkf2MkusdmFY6Upp7py6P7KgfHXhWLbOJ+08/cKVRMKu8+03qiS3IjWbwMCu1EZM9Pg3QhRGz12mEfgxpXGzwm8t5tCYoK5t/aMpwTB6LsD"
    "77tR6oUAKcln98vJAxGO+UTu80f+kgNxiEgypJ+TrnVw3j11xchGH6DpX/ph/+3bv/jhh79wmZZ6sUxxSO2XA0WP2K/Hv2Qikfmu0T13GNumxlo3Va8Y6hdl"
    "Oorpw5B4Wbf+qwgsoSv7S+QCbfsp7RbMcl3rKuwVpVzavkPUUBem3DgNL+umrhlq4Bhp0aqe88T1cFIkgc4pnlfkns/thIc3pYEEYnceWDEWB/c+0HNUlR8w"
    "dDYeH7xeXcuGvCzlpiKOaoGl0iVf9n2s/86cocQmKb6UeMHWtHU/QTOY4jjsb4LXjwkwveqiiJuUkwpk+mW1p9R0YFitvK+8tX/uAL6dL4wLGuaP8UzCjTtI"
    "fchbQs2nrksvFyfLmiY+dK7zCyj7QdLcO+3aecTVAga2Cak1rxsGtp1t8YRb/Pz7Ot4s4Cnl2qe/EgC0TWtU9AiNPWNmKzPjSr/uXakIdikgRptU30fL2Ngj"
    "Yqh1G9A4Q9xz2esuu2aUU1SVzB/GGHpwXAXXzsOcaCyCS5t0MPTcQNaUpl1OQTc3atA6iZTAwQKeP1snQRNReCK4ccnMfDnJH4xGNhPa/lKYrlG4VwfOGYUQ"
    "MVS6uDUhuKoKEowUKt60HqGrhEttQCka/xkd3VJu5KyJfu5TIm4Xiv7QrdFmSD5gvWtIf1vG1ui3LjdV9BjjiNBbQg82kcv0HYRdDQMpdt6hCj9brJqqm6fr"
    "gcxg02aOz4UTTzosOYOYy+vtfkn8QpPK7vuSnHf4W2l1gcx8w+rwJaEYBQTpZKduGA/ZsxnVAHQ/be3cfIxKhdpg4Ov7ajw33Yv0TepJfCvSy/v2R+kMKLIr"
    "T3wsTztPuSoe0Vdt3d7lfqHPiMW7OvjKmnzhiOIrIvW819YqjzM0Lr0yHsvRWJwd9UZnZl58pcG39IMP9XsbuaSa2qDfbZJXtyfhPfollxHhja0H5KBHDCqC"
    "LVYI/F93bVaPZtrzur88o7vKjW91q6qF5DsaPUcV91uHFxK7qDA3EonH3o7W13X1ICPYtW/qyo3Wb971r37zz3/rCrF9XEIYlIfTnnTslNDOlnHriMvEhBfk"
    "RuKxVN5m+DQhI9E09o8ObejufTO2PWyUJEcSYQW5lqa0SYGr7RegZhaEbu5MroPbEwLXvOLZHwr3vhr90YzGIwUKOQ+1xKJwiUsFEOWc69WfiGdXa+N6o64L"
    "jW5Uzj5ssFAZYL85Ap3XHHVQECOKbCkuv/HJQC0VXPgMMAMr/2ZNUg1y43BcRSx+bTdeG9RhX8FfEgRFG/tWmcAsfQ1t9nDYtXJJUmE1iC6tKLGeaJ5oakFW"
    "DfjP+vBMKR2Pj7bblTUcFlm9c7UlOud1NbmJ9c9aAjLmVdq75scnfUU+fvF7tekh3xvCmqDc3TXxjKoKxrD+qS0/sZr5iT/V6ieubiQKUEkwr8uJVLm9PBL8"
    "YPuqOgywwhO32rqSV0MZzNRv4XKpn8n1b/lUmmIMfxb4HuPBHkqqLcozal8xJl9EsBhtLCR8mlIhx9JLSLKOUq9VcF9WJS0H+wMrdnX8BHz5mTOlVTkJc6AP"
    "SfwW6w1QaysqcQDeK/Sn9H6TaIilmC0gA3imMOp1sKyHUqPdjG/lSIQbV5V4AtfpXyoauPW7bvwJrj5wuXHJI3pUh3V3xz44AOfNq1f4w29iXFQuuoLxi9TF"
    "IWML3INKTHMYqqK5qfPylTCpviJSEa1t47lumwSi+wduIwRItUAqWpOdsrbfcyYqf9TpoOs3NySkQyc9cpvGErYqjavMndvQbe+fYEQzHNCFPeZ1oRBnUDzm"
    "f/1vvw8uv4pn+Y4yoO54WaAnftSAztfckotWXDz4BZzhDSd1QFaFfw5nsA+Lyryu7xhX9Fst2rc+WyhwjJHQ6b68p+uaU1Xrql1j3tFMHkC7kvaYReD9mCvB"
    "U0ypy/wNo52yrZqEhoPAxeK7YN1vvGtI9Ii0TfR1ygR25jFh6ur9ueDgb3zh3MfQrGzOlZbQcNJqydnVrAW0c4EcHZG28s5IePYnbd9HfjFjioHWxRjJmVqD"
    "ryRG9eFO+U11D3wYv560XfywVvpNzzaHznwF94XEh3YBYh8AEuYpejxIlCMQol44tnCiapPqQV6r3pOengquJghPVV7kj5281CZVL+hQiwVMv6PwVCA4oCN3"
    "o+vOi7LBmoOJoL0o9bToAeQQxLQqzUubY+QDLWM/5YaiSO68YZ09adRnz9x81cCoU+hJAi7QMyknkH90lVE53NpZZhc6gMu4HSjVGgDrjKINQPn9MryB+BFi"
    "2F4jF50gdWq79Gmn6kerE6jqoojnfj4fkuNSFRBny8ZwYH2GVlhQUn+tuPakYOCko3OaFukXuopEeHZEMKtPISicZq3TNaKJRwvNuwGGTExfObN+lSgtk59I"
    "z7wOdlU5swB0C2oYe0a2UWRiW3QHLmtm4wMIWrdcg7c8jwxEiVtNlVWzZmDu07505CDt1eJ2C4bjFxrlRjfsQ5FjW58YDsN8tBLa3+Nnfi3ReSGPiySUk54m"
    "ISctNj84o1E9XZsTrki4mDSulOfVOXsf+5hBIKkBoO0nfAPiReaNOAWYN1Z7ulrOWqi4eajXeC9ACvo3eYd4X21JNqNlDAwHMGLpUSNGp7uW5FXWevOzFXVw"
    "x7lvssquDPFBnF2YcRSwD0wEkKK5NZ/Ey9faLp8qucCjZgy1i+o+SYKo+RcD/6JQbVBRjCbfoAhwUEPloiwCUkyrEZx2x/YT+lYxQTQueeuLK6bYpMzMCOJR"
    "XNsz3DpSGvPXEfftX/7hx//y43/999/9j7/7UdWW1hf+p8tSOe/rRiY+jPExtv/zP4VR1V/xy2n1/+rAV6tLbcAP8G12co2/+YcwRHq05pDeM/+vLtc0hfA6"
    "PF8X1sNDZeT/UfmM5J8juqVHvfQr4Kirs32HKnQ91znDirrqGbQL3qkfw+gBWA6ecf65CnohIKm6iIA3Uev4zkUYROOxEd8yF2LY/YwpuU+l2/f2jZUi9oCf"
    "0xRJLrz8XauMdH1pOhWdfplNEsa8/gSLIYEB063OqRAuz9gcZihanZedm3mGDn7WmWutFoZpAI44WLUU/zguW+0LbfttqF77eH8gObVfUG9bW0wvgLGtGs8r"
    "r/8tzUv7Q8n3x7/7/d+/PsaP748hLqE4FOEfsara6OM6frHyhYE1XOeLlC/8u+fkOyfOFylfGCRGxF3pizYsDPqbLujIqZx8YcAff/+youcynZpQpsHzbukL"
    "WcLJF/7969MowvJr57371I1jW9JQsGT8IPETwNLp851Q62bsdrgA2ISt2aufYG8KmQh6RpjtM6I8sjj87nu41gVXuYUMczx8NKG5PDIg+at5INfeX41trzu/"
    "S+B26mfvAofQujAZhyzca/X1i43e4R/z+jXAZ/mJnloIwgvx84Fz7qggX3BlUjJT8VN+oWD9SeTQYclBd3eZAiv1g1pV1oonJ/nSqfM+ch/WVlOa3QdBaMwl"
    "f1Vcvvbam1/R1Ywu6MfnQW5dprb4KexNblCrck6OPMEX/dd1OU4zJzXzIfXNP+ekDw5bgmyOw1pFxWiYUEifvE7f+rT+9GsPEWjx++HMCRe+u0P6JONmB30u"
    "+mToHvHW70DEgmj5PDDuPE7r44LeuCAIx6JHzUaDcIz7Q71Ofe8/FTWNAewZKelBijJwbBvC+/OPut4+tuYCHG/IvOxO+lvXizZwBLf/mkU6ImjoxJzjm3r7"
    "KYoSF5Ds2/xCTDqutTBjoapC+xn+XZZWK/1uNYz1e95SUEZbWZ80+fQL7HqV8EbdtJsEIgIUL1kpZJ4s2rAbU3jYZrrbuCFg1ZzSM5I5YUe+JJVfy/K7X38X"
    "rfZD6IkDa8QK6cNEtdH3uf6QnAzdSHN+aJL+bdj2rliFj+NHnuzfOnZV9/Kh5XuS5cWhdT5ijWI5wCy9P1HikMJP7IFZa1V7ptNYUBMQKhzR3/NDLXNey9Ot"
    "MbypF2pln2L49AffsU0Piat5RaaffWUpU5fURk9FYCkB+96EQlGKdfEo/vVf/A7maV2AUQJK+UjF9AtGXp5z9Kci6fdxyShZFAwMu+V0KVyaWGC91wua3gCj"
    "n1X+1Zn66x9+GZ6jKTDAp+FwVFVSBCw9oFb3XBm1j6ff5p8SwAvdUsr8dSOO8OWFeyXW5y2MYiI3FcDL9gcmwd/Bad8eqPq0h/nw3o9bM0QI68pFVSNhpvsV"
    "L5a1v5mbk+Zxczlvihs4zGgycDKxjDEfGBeBsNO8ojwu4P8NnRMKuNGw70035GJwDusTExP00H+2833DZhT0vCId87g1xo0EFIeNed9Sh77O9bffzeg54t2y"
    "3bn5JHqNSmuT23LsdrU/qqs5KrCHnluokLNWjGPoe/M4n9Iq6qNoOSxwSkF4Qjd+jwD7LNoRADeCrtqXl9IeMg+qENquiR6nvdB7oHdMurhSdpAWWg2CWlk+"
    "sfahuU8k0OFf89XriQ1dbu0MrfFSLjlxBvjk2uobkmtnkM/Qy6XcdJ1RkqiRp/lDepqQvmo8dlwIZ1SDh/4TDtDcJykzAYyA4uPRSc5vH3LVp4//8mItjsgv"
    "5pIk7n7pwU07gQJs57XnvEeshgX+HIZNxQjBuJNwOoDBh3cq4SJ35zei9dp9Mf6r738Bi3Gvh3tqMWXdwTLHgXC0cXS9J2q224mCeFoMtfcVOJPPnnW9LyKS"
    "JTmRF4RLSVoGA+0Q8u+ekuPFEJ22TQ1rjzzpBxRr5y/V640ublR9kJ1F4ZG7WUd9t3ErgiBooig67iz65FJGghdj9MCUEJewe5JeiqK741Mj+KfX+/kQejA/"
    "xn3dM7tiPtygC1hbyU0Ckw9Iw3pqhnrV84zO5FGtWk8nXCwmVHoq0cRK9Sx8T7GDgeML4ZP3/j/Wct2/w00U+DUv8+kRIxvo5CeUIAzkC7Yr5FpPUissyltL"
    "8eBroTTqH+8rltxB5/aNWkB9nk5XpBBkisou8wavguTZvlR2UeNje8xRu2XnBe4nLBCS+dpJtPj2xyeg8+wTkhheM7QjJF5UA3oEZWDPLNzqPVS+n6JhShG0"
    "W9bkO6JdhLQP7U6PJJCRzr3WzL8bTsbPGt/ZTGIILlEzVNX9mT7v/D1HtcGt7c13slGMW5945GLiVrF/QNMR0xMXXQo8NccOoGQEt7SaQMc4pPS0CLNgJEEn"
    "Sqj2qUQG9Dl7/vd20z6LN+F5qy6BAVm3XHNK3LUnUiZob03U3MCTNsaDIHVgJarlJ5nuItdWvaGkcVSleW0kSiqEQbG+5bxEwJg6W/q772GjlAtiKba/ln3V"
    "R8bGUAv5j3RUaC55ObTXRu1bksHT27ecDHh95Ad+hJDWaO1KkBBCGilFuyGSAjWVKvs3NFiGg0s4UJ92r4X2DYSjadB6A6fGzP3q1/ZzzCGstiPQEOuvsryg"
    "5AVe8CuieeTCxT1X+DoHr5UWE2pNumij2HVI3wyvPtZjK+VJBH+VHw6A0p5BYg2/iq+DvoofcM2dS0fPg/xqStKg88b19puoCFyuUt3xSTnw+YB+SBn01I6u"
    "aj0nTvunP/vmP5zl/DowXr7kHHMePqA//eFP33z71//uz775z//79X+/uoDXm3S90xdXz5si74uqq7TN9CYff7fmrNdv7WVb6GUTXt4Pl89P5f2/16X+9ptv"
    "e6H5+u9v/uc3347W9vv//cP/+ubbf/zmj3//tz++fvzr161e7s98/QW9vYbXn71/oXp+ofMLvePWr1/6+aW+u2S+fml/Vr9+ae9dccacX3gvuU49V25N7vX5"
    "hd/9Pl+/DLn7m0AjPA+9QXvxed6lpnivt45QGNNng+ehNmp8Huov8xaeZ1R50yHP/Ja5+/plniuPIveSMe+C0RlyLvzGxXz9ss4f8et54hh+l8LPmPPLmxrj"
    "65etNz+/vE6Yc/N39+bXL/qDfImtFx5hRF9DR8gvRPHx6E27D2+5e/wOr7gB5pjf/SxhXbQqa6fJL2+WzK9f5BXakHvpZ6hNhtSzvKjChfeqccFRI4ofuL8d"
    "k7jgZmNccJ3h4727y+OX4brjl/msTz+F73bzMGRWma+ti+B8cl0D8u10yFsM+jPi/Hc/C3tVXRMypOnTnR9kal4/DBlyvuZbrwGWTd/xTtQJ7rTKjJcZHUec"
    "ebFbz4rPu85mXV3vdL7cIn2nde4tX2X2s0SXmIE5zwpYagZYZkLNwDuxDs8z4R34Hd6FJ3zdasF0NZlSe4uzo3XW6V0Mi/fam/FefcZp72ImdZ+Jwdn6YRZs"
    "xb7PnXQrNjWAQ1dfBaPd9tiw9kdpYEjfumxgkMVEs75nYbgX4a1WH/EyPBpehs7isW22BhpA2rCH+GWGYA+tDXtIZt2MmZw7ZmprjRPYW4VThibOTcGXIhLj"
    "pmPefbPRAOpR0O3YiWaKO1c4h3aZcKtWdpy/14fZ8MRFTiZ7nN3idca2k6mkl5DtKN9TxgyCuWDZD/qejQkcANLDQHfIEAOoh3LvsCZHX+AAjD7hRXtZ+DwL"
    "1y2/tbHCmLEqLsoCpr+XDttolFLheKgFZqd1gkemN44/PvK7JBpfi2uHMX2k6wzwI9qbHCDskdk7mIepT6j7aMrd9SzqxwzaQTNHPGm4iX2tajthiK4UM4v7"
    "HJ5q3O1IMJ9gbzgAjoNpQ96NrnCZgWfEPntNz4jR9Ig4bznWGTLVkO8Rx7wWigzRD3zuvcx4HROjDlQ9z2eHvfyR/sLHbzXDJF7XtD+ChxlVvLmp53+LV+ni"
    "x+plxpuNJ1zGnEJdJcfLsYfRzzLREOgJO7bc3DbI8YR0DL/lN8Ip/Do9K37wgV9zitEme54Oi6JyQ69AfAk1cPN40Xqd1zLucAqPhs5Pl7+SZTspnfh91jjm"
    "tZYITvye1qQYEH1CpgE+CU/xbWxtT1j/vQ6Ob2F+goVTu8YxrdcRx8jJZ0N09ZhrQ+gJzrbDidqIZzxRqRAYFCqL4WCm84tai7ZhSqkTPg3anNcWo3CVXieD"
    "C6WTJc/bxGjLs7S5IOKZDdx1Pe+Xnk2rxiHNmVoxgBK6WGil7ohsmdnQYZ89vnXvBdzL+cZug6uNHvvkAda4oMEW13FZHLVh8sqA5x3m1MvMbHij0uMym1We"
    "Vj2YAvt7SryrS5H2BA96DAweygb/eQ7w1Zn6hKvQGmBJ+gKL1DlZiQ5bhwhPqb7kj8iiqHiVQQU+7RB/3i16/Py0K0ZayRztgkNG4WSyMLioED2+AiQYwlsi"
    "G1nkYpotxcCyby3+2JiFaHELEh+zZ074qJjw2K2BF07iVg4z1eDqNQnOzPUchDmGcQ7W6UJizD3tAR4Z9Y1eGxOjR9bR+5sVnrBLGGpBwLvzNAYBEie09DiW"
    "jMLk2CuGmuCwDvAhXyEw5sbqWTkW0q2FcUIV460rW45jfeLXIb4xvTInzPuSKE8tm+xpze0QS3hmodfnVkNNcT1u5dB1+5ZMOmM0txMvQ+2sC71Mn+et9DKv"
    "C1e4jMQWGKDbiCFeuTpgE573tbRJbqQJtc8HH1O/L+GYUWEMUYP3ft2cQiKsidGcLuWS4knZe+pg8MQwC4IaDUGHhdUQQ2g4p3tc3Ffdv7xXinsqrMe+0loT"
    "D0TX0dB13SztteM7DYxAWYMuPWHqHLAcy8DpowJjeEj+T/NBe0Iqm7jivSTw0TG9SGZRN/2y1KfM8oAxkruzRxa3Ux9nlAmXmaVCopN0DZgTviARwX0x3Itl"
    "jJ4g4vnpfhH7pyM0XYrn+tTzg2Z8A2qDYNJnATth69rmE79dKTARGiXad2kdbkVFQmhLfRa4FQ944lHhs7ws+oCJ2CfY1KvMSmD71oq2hNcxzmpLmM7xOyzx"
    "bnZCDsXjvA49hMY5kYdlaM6aHerzSDJtaImGz4E3dM3usxuGOj3iVA49PsRWDD2FZtHn0WOygm0rx1cy+yfpKn2vQSf7PSyzeMJ1e69V4BeS7MFw3t2Et5D0"
    "mb3FPNGlvgXLthpmvE7MpfdqpcJ1iPA6ox5zprPR+WS5bDYWHAbibNo3lqKSm4sOL64nHmk9bcRnsXXh4vUK7yRu2LDD31aKzNaE15acw3BeDywUO0v144kl"
    "sOtMu46WaPCRy944hmEM7b3xtSY8z6DZ4VNNeWZNwEhW2j6EBL/+efDVZ4u/jNoXzCkfqzMsybtwh7YNY0YhmFNJZrh3OPGwLVvxY3UMtQYblKXip+8pAadN"
    "aevwafKabGAJXpapxRE2E2zTN/C9aUbL1OVGapiWTLr6NDRwvRUmNBY93olLARtIUksZDWspww5BsQOWyN4wRKL8YYdr/KHX4wmxBk3h35sEgfrvbZ8AwNJ6"
    "XW+rlaodJ8o2ZreV1+AN1XBUm4UdH3+dy/C2WOjzR6x5gMUwpvH5/KxGXhIObDWdczSwJVrObOp1qBcYM6QiorPDa2z4KOLum3/QYBkN5gGzI47usJN9rnid"
    "l38As8zit+l1WBLLdh1J87hZlnWu+1Jsiw7RvatPc1ajfYhyHC62TNvYuNbShHKcUG69wXIUv81VwAbcehwjZpeRyNFuJR9Kl4DMpy6BvtuMl6HdYfGTpM9t"
    "IjasABIkgdXpJ6wAohMl2gpoAzyc2exMF5vFG76uns+6AhrDdTSGsgNndThwpviwZojrCZnVNxiSdBiWq4ch3DCY5H5cWHOmKp4L6lmyRdUET9M3+G2864ox"
    "6evCLfqsUxaOgRTEgbBqSIcx3BaMmXrO63UkjzMMDiFFWJtjCEgsuLAUPMT03CBmYbV/BoBh/AqSIhzmvQ/4ME2Sp+bYCVjJ/mpkb1ncK/14sxB8PAHb2Flb"
    "GQ91qcHa11PfWHca9QHZFh6wmMbu4I32hc/TCR0RjYnteSRRbM8j4a0tA6mG2MfhHoOkMQY8Mq8OwQQL3sseeXcIkvpGB7qYf4BOhY0x71hsVfJ6qFZwEbPX"
    "Ixk/uzIt9BFlg1rwKv5pM+wbOCetjeglUJU9XC0Z38CdKhU8fIVcuXhRvB59nEXolhXCSGHjnFLvFT3ABRFHV/fdzmX5Ws22McVXZwHwWb62whnRdBvrLp7g"
    "tLBgENwRdioIdj7NAzuxo1DWvzsKCc6wvsQnsPQ7OF488LwfA4+5JjbFop8Ba2BzPAmH7nIrzM84nVVdx6qITXQjeoOZ6bK22JKAx/7q6V4FCmrO20DXlvSs"
    "VPepELo5G3zAVyAGH+EV1/T4OG0vdTakeHlcNTZTelIjbNv1zChbSCcf0wFcznU0203HLeRm+eUlY+SZz3bQ61CvDGOk6MlWDD9GkTEQZAuc5SXYdvmQ15Is"
    "A884GRpusxnFs7r0Oi9bv3B6xIm3MgjMaZeCMFtNQbYVWUQ+41u1JXOhY/SLujEtjumdevwSVI/Z1l96lSXnKhFneqrGHWItLNdKOkamR6bQVjdcps/j7Ogy"
    "YMEz2gOOc2bomN42LIM2GkyGzbv6mAVW5cu/HXArCWjZEp4T3orqcUx1uZ9ZJ/P0z/Ii3VniSpBV4o/PSa6kAT/s4+SR5QFbhctI5UtvznMTjDn7ijae92Sl"
    "7RmHvM7BEYewbHwybOWAO3EdOhVaM6cwWaM1GDIFIKdJGclt6pRPGKCRlBpoPie7WZMFy5z5nIm20iTzZGNGmXHM0EXT00mlEY+45zZGomnbdguf5xUstLTJ"
    "WnzvNk8Sg7E2q7P3JdYYVuPE79Qm49flc7DbWuvHgyGrLJ4jhMw3guXYecECqOIO2wI4gZQBEgdaCdktVk/ruOX0nLQhHFcASSLWdq4zNmjXDDDDMFebR5yZ"
    "V3yBu7BvSmNaHKOpRtsb6+RKbOFLUwAb3h82sx4neqtZzrlpjzNXxVu1eCeWJgZLsRK8OKNlGYKMt08p+T9LkBeGGZ5yBljRBr7chM3c20oLouFlB8FVxmrx"
    "+w/pg7DtLYBL28x1wxmqcTQ7tAF4Ib2tGt2HseBEH5I7Ue9BoHVscTQRDBnikSnOUBAn6rWt5PwN4phOHWNDUDOl7cFyF6WDCzk55v+YKuTSVsywCtLTUoj6"
    "J7oDuaJ/LgGOvOCs4DYPsVaWOF/gy1LFh9dYWaegww88MJc1MFM91oJAgFtr4Pf3CllI5gp/1QW+Zbk2yDmSdAGwdapUxsTuhNig84QxXeqzFj/0BvEDVbgV"
    "pVXW94TYgMuElCerpTRQBvW4oruAPHVFcztr01Z9n7APdJWwizt79H45OXNduhssftBXb1aiJbT3EgVpMkRdN/nAFM8eM2BqWFoFD3XqmaZZUDFyruMAYiLW"
    "sNh10EFMpGkO82Kk48Aslh6O5tF3cFFenmSLz8O7DQhCNpijV3xY4VNJZkY/VRU3ll2DYcUAsQ6MidD0EROu/3UCahf3roqmr2yM5ReaE0gajFLBOhLDkCno"
    "GDMWkyFzRNIVYJchqPlIQ5Vte8Ha6S9DkjC287S0YHn5Ab8MjPYXlBpGJ6hGTE36WfRPUJYhxiSHeB/61osWTN6oC+Zhlb7g8cBcs00VZDTs1uIUWIVgzFSy"
    "rPjLwArly7RBHm5QbVAV7oRjaoMrT+l/0TFN9ourWHQsoe6c/2QATkiGxcoI+oBWOZLcvqU/Z3pRSVPaa5WG9yIoWfQhNVHd9FqUTt6kS91DCl6LQOY8bATj"
    "KdBEt7McZ1aN0MLbtnR2BBROTc+6P6qhhMGzA7BpipE3hJeEtwpsWsVwf2I5FkCS5kKo06wNAF2bAXj1igU5DpFz04bsWGGZHXGVs8BFXlEoQKpmZXz+3uA+"
    "MnnmG5zdYRgwCZEMmSUe2nROHEA4tX6/LbvRoDAhDZT24RTLaNOAtRTCahnporZC+gYgVMVS08tng0JOx/LZa70SPLAaKStzzfixWeAZNn2SpdPpm9J2Y9g3"
    "iUIMjTmwsVpLYYbqrAUwz1OKInYdSVlOM1vYEKjuqjXyNcBFz4XNpXNOaOd8LfwOYzY21w1FZav/IBlUHTO1n3OiNTZgrOROpjms1i8uJqnBdWaBBhTmBl35"
    "owguUUt1urStKInducPaHBXcjeBQwWAbqL5NQKaS9Bs5oPEEkPjrkIYxQzo2rAe/N7x7nzDGdqx+453aVHsDsDEzNsmSAyRrgErw/ah3/KUs6POZfUGfj+A/"
    "XaoT+iZISmGW1MBO8yHr1LpXeqvQvVIadJANKRS6BsqB/Tazbuy5wy771xEH/X2zypVd0EzQ37cmdrT1wdhxs+OtxpKeMvMa1oR2Q0EoWygjG9uCfHHEDW4s"
    "9tSuI3baZexS16d0nFqReUITJSmvguFTOzzO2Nyhe1QgUPrVNdbS1tCx5QENJdDgXrxwerRU6PpdJ7yWmlg76jhehQayJvQhTWJW+SXsvBQomvtlzPg0pN1a"
    "1j/a4F6vfQTdokMKf3ZlbXRzME3o+xziB9hyEmy9fRvldXBt7AxjUussL2JYYLpLprX81Hjlro3QRpFD0PbcNu5aaoQNZZLN1TFNe4StC7bDu2t93zU104B1"
    "KUG3dQBLDdY1CdOCMcrMYVnhPMa2pCKqoIFaTL41UHd5QIs1ZR+bD3nMigKEdoEhLLW3bb2rFYecKFEvK+1Zlkk8A6xWc04Ee5KmQ3S5nYuo9yp1g209nMfl"
    "2ObvnIWz1d+Rbqitxr0fg7udT1RljFjTYxw2GwRrxeu81jrcawjqyV3n2MXN0PazbQ+fE33bHm5wqz5lMgwv1+CXNs9u3OanH89gW6OpTJglJkf8mtoqubFV"
    "Y1t/5TkLt3U1nMts82Xkm1t6ZE94mlrj07xO3R7XbMsLUtvGrSH4nHy6mOqCxfRyuWt84ilIUVsE0k1kC0WqgTZGvFX9wFP6VvQDS2/3NsoBWRXDCFRWHMMT"
    "ftBDd1v296QF9sL8x7Y3/9xc97PUi3XE64jjz4iIF3vzHirBxPnFmo8/VvRdIVAfivGXz7p+d9GeskSt5zq6hU5F8avTVgp9K/7VawjBL73LZfTznsvooXxc"
    "6TeEWb2Pcxk1osdnsTHzwIffY8RWyCNbNu7zwd2Y4zHZmNfJhPc6HWVfkOrzPLTiM4+5Fow5EJSvDiExvvDu4wCG3HX0Tc2xkTe1dNvHCrkZKz0OIb2V+fqU"
    "bs4w8QITtL/qHW/+iqM5rgPmietgF1hPtBqsp6krwzE/bLjOQQV81bLgF0W5nbPcfiFeuge0nDTjLtk1jnit0+l3mhYWtsGrTvS0DeAhllT9HOH7sl+EUGJb"
    "+/OG86FLKUatUBNODh3ThGdqW3YynRjJajfxS9VONknbbYMLNfyrteHKvYt11Y4IaUpV61+XvAUwGugIpSp0wNUahzS1rfota4UjRPktrFgonrXV0TZ4YV2o"
    "5BznRcPASHLC1mIi0DMLsCQaXg5nDH69dlHomCr4YBfMydHoSJEWcLUId6EV349pcs/TBz6z9ES5+lav6O3OCfMzjHxHkR8MroTEKxua8rZVUzk6G3SiPXMD"
    "BS1kfoTg6cwfscNdpvjkymyIQOqdyyLbs2G33zb6GVzGn/UQxrQCTgLpsjXIEO6YzRQvw+V88W1ZnF7hMrPBnTbDnUjIUewXyZHYm1O+Drq/QqdgHqjE2DZG"
    "8mDbgSo7jJGXsuOdorfE+sXVH5b9uhkbBM1DljyiXbiJv2Qka2JJ2XoQ4IfC6NMLP8Z2JGuwcmgU/DBszi6kgmyOpXduOwZVgnu1iiu52WKXQ6+CO971rwww"
    "WXHTLDPsCqBpsEcEVmxjNlhkFlCdwx5N2PRd5st68iEQ7bL6HeXQAqde31KRZmhdWNgzNVBpbcMbtQ7z2SVh7ywDNwybOl5HerBsjCClbcwcMIYLhl/aimS8"
    "iQvjHW5wWAkNh6MYIsYJxdTDEDispRVWJSRdY7iO5uyss6xD5mHIEexIpzqEkH2CVWdB/VpAVgYeBXpYVPO9KZ7t0vNuLy4oNn2aJnGn/VXvHVab2DvnI6wJ"
    "k0N9w70EXuLo5hiY7UgJohayGJjXoPxVM/GaGnqwQQ6I2qyYXWqYR1MmpJH40xwcE2aDlLnLkEetp7fA60zCMVJStbcosHK7cheaR7cYs1RjwsRLD6fdCh6G"
    "mCcuyoJX2RUemFtd8FJC6eCmvUIauwl8wGXVZ4fUZEqwdl7oBTbI+pOgSl31oCVHEZLNChA2l29itv7lWqATKLA8d50G6VVWd9co85AykuyJAZVpQyTfZW/V"
    "UmZZOf1cOgTWtsZXrht54O4bYOGGTqkVdQscNEOaGXVJDnQetRhraUb1SIxh2XJF4segY/jySBh+EZoFyye12SCftHtMDc0TnFrQOFthGCMUwnsiXkDD0Slc"
    "EduaIjukoeY6K8XGCC3QtoIHJjC5zZRzFf/DeBYGOmw9uXDSdWKZM94b7iWlOnMX9wCvjiVn7bzinU7rCv5Q35iBJimlWApzb/DPujSxmluyIW3NgvW0y+gH"
    "TPhm68fYC8MrzXuWgOv0DKlAtKqt7TZGUqNm8zqa9pdLByyvvSOVaWMwgkoaZ7UXxvpo78hAapUxi1it6iVnz1h4XuKLcl0wGSTxgPMDkFL29ThwFjaqaImU"
    "/9SAc2OmMWDv22qMh8SGSt1rDGEdGgkbX+E7EHp2gVEZO31rQG1Jgjiyv1IyeovFS+Sp1J1ltO2rIyW7JPUdqyMhr2oiLHY0lBWIFSkVJqxfdQJ/rfqZVssT"
    "+I2dNnNh2XCmQ2sCVWUXQg+7uST+l+v5AkZRO6IsfiKYQaUvd1ICE7ma9fOZrdxQwhXItGuZSNXZusAfG1LCWtjSZYffXqkAOCCJk7I42j5uNaQJJm9gkDWl"
    "xccCACEgMb7YCbm9lQMWdA3b4uQcFkqeatqvHbJrXRC1rvthp0r/RH97JUswGKwXzQZ+i7KfLHcQ47eTWbcasMNBFCgCW2TB4ILz6vCBe4EqHC8mOGkmZFlH"
    "xZhvdHSjXDSu/UQVPnCHi0j74Lb+C1yNBKtRwNwukNztMSWs0AoYolbeetYJ479ZUvxH8LUls2YfuxQM7TAMJxfyK2YpvONY8AOX4vbXv/PaRf/wh//z0RSi"
    "NZGnVDpgPGMhwsvKQCJGBZM52lTUTpDA3OguW0OeWeU7NWrxgRpHcyLLomowkMWH+DyTOzzPrqhx1EEKg4R53WB9DWWHWECipimkWFiLlQdKAUgm12CGKhth"
    "ifCORNKS7bXN3DkRX4OQyUwM2xMeT8po7jWFPshJTdBM6yLxfHZkZywMrDCK7cStaayUSB3Zk6CQorvt6wJOkaaJcCgKFz/cAMChwnX8RwERE64V8aGTEZRY"
    "Wgc9IWRqZilHmB+FBNUsQbt5bBu8Jq2MLKxbujUjbLbPHhtTg6sIA6QN6ahl1KnikOTCKRSNkKfKAcYIDlVWfIdr/QSXl7YxnQPxl71EXaCKQROJzO3KqVFv"
    "uaILkpQT8uVz3QvZ2jkCU2kj1T0LvZ7biBXsDUBr9RhwUkEVkNrESTJHZtTZ4gUwbM7SRQ05v43s2b7nRGZuYQh0sl19wD4THsTp2v1BKuC1+tHU7Q2GTMJ8"
    "s7PCpmbzx41xCglx2MLG4Y4GHMOloaBQ2Si0s4CZ26uu1Ug9Z7dSbSCnWoMaSNo/Yo9TF+LzEXBuUmiMkE4nGcUjXXnAWSpQaEeyPIDrWjMc7vwn7CBQ+Qor"
    "602kTR/4OD0rCqWjSf/KxtSOMlcM6kXGtc1pETruzQRkR7Wngfz11ikxEhzfrtMGuBp94S4RkK5vVsCNVFCZUMo1N4R8hVyOBfULj4ikhKDpdWt434z6MoRY"
    "d+nAsDHCAGxjFA1hWC7EGigfmMMH75VUfDriERB8K5qRHhGLMMEd02Wv2YIaATcJjux4LxMfZuEDc0GIuiaxzFVbEOIpnM8FjwQgC9ZUU5KwdGTgA1HsM+HG"
    "Nx7EKhBllhIPYhY+PPc998Bv3nCMkI86xwDLI+ZEGbM8Jf9n1f+vhofWoBq6uzZGBFAtQaW1PkKBKuPYwGYPk4DsyL3s0psdBVgkg+GyYwskhV7RFObUBnVM"
    "fSW1kkUoMyKL2cqeKTrgiZKaAyWF1iSwFymFJXhl9zATc4mo0UNJ8oZHdAJIsl72LIr0NS2qjQqgKJIkkmrTgb3QI+HkkDA8LScxShXYaoYLQWW2uXdytgkm"
    "ZqUkK+PcKTrNvhIMIQwxSEv5VphY8Www8TFrn16YhlWohkF6UIDHKQbpUZ9EhRbsS+mz8xEQ+uI9SZh1fBpKmVrNYLjtjUlhlfhwMUZJ4kQF/X4n5KQ8Cyhs"
    "WpI6X+2EZivLyfa0myd+4Apfb1PHZQKaQYTLWjm0LQYhzEPMCSkF6Vew/TNMIhnu7FxxbqjtieKQ1LEl8uUXYfapDZSbKMnPJnTcVL7DOW4jOXfoQgvnmEuP"
    "5UAgaZBIztXcY+qoKiRAoOlU9VCadST/WNWWLTROaqgjhYiiseBkhWaSTUFJlNR3KovfsjsDtTdUHsvAJg1bsyVBag3TtTdUAwKtH1UsHYl3zGv0QN81CZhj"
    "YvTs7rTiCKEldTdCUSEalASDCoqFEHJFy3za864GmbDOIHijIhEuoqygn8VldFxIE/OaQvXvEpsVow1tzHZ8PxOTnyNFNn3hBmHMxaqSWUdZUXsvgXvM5CLO"
    "RMNoS3KWJAfTJ4rTbOA3sNSr5YV6SjDi/kgiuiq965quMShGy8BK+2B7qBB+dAIFI2V0ctYjJbz3wlsVFNzhtF2FwdYoJirma1XCzUxQlMIys27TSSgrpGki"
    "V0dOqx8vs9Pql0DC5VxmMkrIXvFatRueuKKCUVu4kLQQYQm9CpOl2nrGdDaiweGKrBPsyNU1pkKpE8HaOQ0QAgmX19oCtR3JSTrxDqSbJtV0MWwWoY7OQlZt"
    "BqYXDQKdbSsL7V9DknbBADj9FuYkSYLk3CoPZK9JICqkSBSnilOQpH2jVJMJwbABjvE6AtBw4kQmz6K1J5wNpYNb6EkO18w8kyoAoaDSQgbvwqjzMpK4ACNz"
    "kGovOF0hXAUbydXFENhlpF3XEbDjDKrk2E/MIAnTpz3yymMmMhmJYpfdS8CSw4H74WMlWQWRcnRbDaWuNEz1BPHwntroYlOqO8AyvY3SygVZIanwOOkcmvgO"
    "DTjttdhp0zWRi6ksUBXSbgTHDVVxo++OX6Y2vFNDUai0TiS54t57g2Ui6fhwlmmn+ZtomtZKEkYD7+WE08AmOwa2RUjk1oHkbCG7pMZaA1xoCxUGkkuqYpUl"
    "0hP/+gTmS8E1G4Oc6o2ZczI6vKNa5IZye56FE55mJ3Uaidod1ftACk3pAzNaSEH/G3PkMvkhdZbwOgPlh16bCmdn98i4b7vMkFKtAt2bRhPOS0RpIWX7d10t"
    "C2Z575lWUr4OCjitgmpIE+n+pGDwrO+jMS+7KB3+iDhNKDACatXI0Z1uWAPCGOAYRhdehZDtXwCabgkMWAG8UFlIAOfulUCZi2bBBTBQqEm3d8WuCFsAhZDd"
    "r6GZYGGP8vpjoMGo5TNv0lGnRBK+Zq/bAtVBEqyZqa+IhK+TTUGd2k+feHAi9GAylwptuuAPnU1nOANVINUepzAG5IxqmFxRNahCmCwFQMeMtoDcjXtBrrS6"
    "kStNycnszEblYoG9WbGloViwsunZVIEqsaULFqK9bYJVTc6ilIV/pRo4E5Hlbgkkb7ilbzeS4z02JyEfVKBCcsSXMYFvRyvpWLWBjzwIHS5OOkcSxrvXGulx"
    "COWlJDVnX7jElAu3hatNONrdp+GKT7zTBKbgYZjCYY1pVjcmSWpKRs2/eXbWV4rHVgpdUFdoEaejCelhJb9o50VLqodoAweqq5EUrodLiHJSwsQDbu6B10GV"
    "Npt3c/EJXfOFukKaknf3Ggxvvkw3UFMNcEJwW+hjgfSQWm07rpKEIg10T2al5Aqh6o24hO50qug04qcT+KAdcX2kUxDodVfyPBnEiwhcRJzIOtDlqBto3PX1"
    "7Nwfie679EdG8Bqr3P51OnwPwqmVAN6rOu1EeDzQxWhI/y1FPOOLVq/D5puAPFu13Zkwt2LSLQJLNfLsAdzZSgJvlxkN9YTGwlvJxmCHBwJFAOnlMHptCQCM"
    "81oIWp2eUOLOHkkrSMJhGyP4UhszB45RkR+zmBXFb/rC6RFlbBsj57obUyqK6OyV9HrwFyFbMHEOjVoMQIrKO2wqL3qrEdjaSUB+dhUVunQe4YanmRXHSG+v"
    "vae0i7plgHpCpFIWtpyI8F6T4bVEF5tTttaWewHFHm2QMckRITFxGj51whhRkqRU4TD1EDEhdh2J/MkZ44H32iAyQ9I7SK7SjmMEqm1jxH9y91oNxkwTadEA"
    "N2re6DlurD4qI4G5RE7FeEsTMoiKaBrC2ZSBa1tqlG7FrYZjJsgTadKUO1aWTIqkpB26URiBBBbMqY5pK074gpyEFcMECirGib2IeUdggtOISr/wAlErlfMg"
    "OwFO4otcMhYVdlDBSnYsuSNrwcdD9TFtCrRqcsV5AFkZ8zpckWnBbAqFhF2lR5UJTZbavLS0NQeKKRFKMml13oaIKbO9IdUWt/AHPM3s+DSSLiAr+zOaBUlM"
    "uFt1TtJOcKtDB+ZuNfGJueATKyLHtFkr43ciEG5SbR8Un7EkuywQtx7SZdNVCE4lloKhl+SA00P1S2wrT9Qt3MmH0MyjAShRo0N7HUykg00RvET0iI0ZKArD"
    "VFBuU5gOTKWhgUqDhvAjMcQMjOnNk1zc0e/F+ABFRUl4IO1ZVGDVJhSlhcoCBxvdZ5YFkGJ157DO5AlvuGyelpmymQV8edNrcJCtivLqKLgk/UdOzpwHvgG8"
    "wETVIFKhHMtJjQ1juDFm/ibmh4XX2MZI16S7V104pvWUzsRJV6Euex4iVJ5J3vPaID9kymL2Cw3wgwWB52R4KghrKibFKfMN9FalYmemQ7p6rLoEB5LCrQzM"
    "TqhaWLIkYW0oJbgx1kC51YsfKtp9zgPZOwkkjuewRmsfqLZaUFlIeI98OIK6UKovZYkgVJHVGeYQH7vQqKXQiFGyVWUXJ4bdTnEHJYK1tdb5I6gMZnUktcxo"
    "1qQ/zwwSbnkSmSiXNxpoBWYn0F2rmMlfNYkwTywB7ZGKCBVfe8c0hwp8DgROsqODhqyWgEbMrrWCiQ5N2zdTYsAJ7gW1naWCYRPR0FhvOCa4r433nlhnSLpC"
    "ZeMvdY5UDIVfWG2z66zAMZqxtda6BIwoo+Lz5BL5qglkgGVWAZZbTUOIr0cqfjpjiBXxMXqSOQINI1IlH7NsE/AV9j3Nd90zlU9S5n5vrHvslKyuSbplYbKa"
    "UGvotYui+gxLzO3+SABvVlBBZN9KGFaR5DMEl1AdGIyKkqSOgt3NwBDIBolTNJ0/0wD2NTpepcFbKpjCSLlqB1UbQliV1BvdG6SHafi82vbkPGfsKxb0k12m"
    "Ao5zI45TGo9dgYoafjgB5VrdC3GnqiW/Ur3Axa4IAFIogNNbxGXNlLSFaCQxpFxNgbVWZkcEZEU4nqTwbAwh/pepIiJTmE8dsnOAthALcZzD7DEiVsdK3XrY"
    "bdknwZi1odGUxWY7hR0G3RntErNmVIGzGSx9Y9e/SsIaOFZCLAPHqg6Ordu2sBuVUktfgeYaDbKtW0U65Fzb30IWAmk7mCPB7VMI7ZDqG6kU6gZAJTs5M3B8"
    "nALR3AmhCgJSxEnbqOyKC6riV04fWUQEXFdywX5ZSca4D5gaJVWSaGI/nmudHND4INRZC8803wkVG3WUXLliDO24fPgn+uS11a2ibFDHdjhtsXKtdygPUwhp"
    "pBdSTav2mMuJYJefaCW4R14dbiXgnOUYF/BWypzF6Mk614uRQVsSrq57ESWKXr+MxMQDvZSJdkXy8O4sZ8I+054UXJAuUFXmHeNQmcgC0yu2diIDozJhMkp/"
    "u8epODkDKb8VTLIYMdG+CxEbMCXT4H4hYITUHKGT6GTsihSkof0iYBHXSrmRuHwi0eXL4cAxvQFJEg98HJwu7Rh1qwK/g/JKTmx4d/XSgTycTNh2pjyXlrxL"
    "3HYb29dIPxbCWN0WQVJLTrS9LdOWckNq34HcsImv/bW2UytxxzECbHVGrwMVFFfk4FJny9H9AgPTqAt5X0GHhpEDSWWOjbOJkASJkZ164ZBJwPb8mgZgdGdg"
    "Jh4FWeCNcbubRjxwebNyYHY78IAwnZHXfLQCGg2aw7TLDNMCktk1NnSN4iYKzBAwprMSeRJ2PThNoY7k8X0BBaYe0jvxBqYGLvepJtD8o6SQMbE3zBDZ47Uk"
    "BSBYds/HOaHJfyMPJCPtmPAHuUXeYPEtJLRTJWzjhJU6uH27ORIPKRLAlqQYJR2k27nDFdSCmBbyop5Q1cYQcrnSlr+aSPSwk8SpCQaVj6G1A1CUsXREUErp"
    "In1TgeHf9ITEzpjay8tBa/DLFB0ZAilg038ZJ+9u+i+i9uzUg2jiL+cMMF0bPr3STlSn1gGCQufQciI/VFccIx/TxILGWX0mFmTvZVTVacxpRfH32gPFgipI"
    "8ZzA2Q0h0woq4eu6Vz/+tHv1QhWuc3Ko/jqowMSHP9qNqagnRMx4c5h2EwYaIGHmLnO4i5wMUF+wCpZ8K8vWgajUqAOvQhXXUgMtIdZJN2tYQUuIqygrmUn6"
    "FIMsFSFTZVmbMxEIYt8OtNYieTORyJdYPYQZfikbqZoljHDaGh2UNEgidBvjZO2gqm8nhSRY7Je6CaVSGmicvJ4nXacDj/bL+UKz35EsWeCXrkSHRM2E/JQV"
    "OZgLSE5ok7GTEkDCYJoYDpAGjoYsJiAV7nuhrz/LSATx6C0K76InIO2JIR6Ih01+w8YsJDJVVmhOz+MK7hgzyIJzLPIobaSU7KnM41jbUc9Vj3VHKEsVnL+k"
    "i4Kak2ujklDfSPm9CCVQCooCSRTrhD4mJ1eFk9wKiO5oLtHdvY80ZqIwT4Fd9fKLUWmR0HXSdurdsdvHXQf1hjSLs13zEfyRrC57ZN2cqWvdaf4wmg+Jfh0b"
    "fOvgKwlBg42RnbXdUd7BV5KipnlGQvbr+OFRTojVGDjKhopCRQsk1ljFFRk7s51Dv2bSYwLHUTnXtmM1gSUmBCq7I8zH3aps1OBsNTnMEyVpOgrZOLXWGtt3"
    "nAbXRps8ykKXvidhnXz3tUDiZUAgqODxjYJM7hcCTRpyCi+ajYLLECqfaiu7I9hHiSTV60vM6m5MmixOQ3oaM1BzSP3sBmRHzuSp8G6JhQZ3YiXxOzFWztyi"
    "rA6NpEC8MVfQIFWmxtSzqaFEjDDhOaa0icI7yoeVkOcJhmRrTSp1fmXBD0I9t7Ft0k1fpyS1hGpCq6OkCPekOIRaBCOtWOPlVrOQuLs3jhHImHMb+oa/2oSq"
    "KELg7q7TCXOYC1WKVkOVg9XxyoyKCnpOuytjbkrtlLvORrUjOYfdW7QN9xooiKF9pt6Fw1+cSEx5Ul/aDcWgSvqAK73oxNeipFs0GKe5L/DX9GB2oNpM6Nch"
    "w6ydph5niXJCujQYMXTOo9wNvU7GVH/BcoAxrI/0poYjQN0F6kkGYmEym5CDUDu2nMJD7ymZjdni1nHiBX/r1jfqJZhYkFHHpd2/eCaBagZzhfp8rzgX5R8F"
    "3mx+FEo7Kg2sG9IJs4XJkZmgPz7UhzOxJZFisHrKAs0hFtCr5Y4E6rdN9XgvuI40GpkWtpgDG+Okr0skGHR+FUPy0nKylA4Fx0ELUkos7SzmHaqGOyObifMX"
    "N7hadq+OjCc7cRE5Nwq9sTlRBK8Qxq0qNGiuDTpawoHnZN4nBrfSQLWxAdbFWJDGnSjEphRVzs8q6HBs1M01jjkLkXdWrsPQtkKtiRIZoCAazRIQ4Q+8MWat"
    "uO154bG2UOLQhP5scpKUisqMOH4xtP8u+C0B0O9RzC1ZKtSOax1p1CWP4rSAC/LzCsDb0YqiKpBSwTiKdBwyOzKtN5QS0rDVTSCwzitAbDVs2HFUjgWYJUUs"
    "1orVUllwB0TFY6Yh5apWhw2yOhpoC+2Ji0nIUv3BjPeihRSwyplrd09krqqLVa0xAeWGtNBbk39o36qNxOSMBVqs2GrgthIo0BXuU1lSVYvMHZuosqL5qo3l"
    "xJ9Sb6lJ6ySdnqhuK7lvX5TaEFhiGIl6L60iZbMqmk10Txyh5k6GrGOBeaO4YV0oCb7Q1xZ8mIe9oaXYJeEXJiWSacKAC7/k3O3JZXe8VzsVhjFK6zWeHyav"
    "+RjKS+I7iPpioo9SIDcwkMsrD087xtNOSVh3Sv3ZGkJteWG/8VVqWGYqpuqKORg7MAoJKT2pC7+ybBQGRITfpKRCPKMryijmpdmoLyWhf/qzb/7293/8wzff"
    "/uM3f/P7P/2HH//+m2//urwf6Zsf//Yffv/H81//9Br2n/7wN3/3+2++/aa9bM7PavlZ7d/80/8DVUouzQ=="
)


_CEREBRO = None


def cerebro_inicial(parte):
    global _CEREBRO
    try:
        if _CEREBRO is None:
            import zlib, base64
            _CEREBRO = json.loads(zlib.decompress(base64.b64decode("".join(CEREBRO_INICIAL))).decode("utf-8"))
        x = _CEREBRO.get(parte)
        return json.loads(json.dumps(x)) if x is not None else None      # copia
    except Exception:
        return None


if __name__ == "__main__":
    arrancar()
