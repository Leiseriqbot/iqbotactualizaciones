# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "2.2"
BUILD_BOT = 196

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": True,      # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT 2.0",
    "subtitulo": "Llega Copy Bot: copia las operaciones del autor",
    "items": [
        ["🔗", "Copy Bot", "En Estrategia elige Copy Bot: tu bot entra cuando entra el autor, en tu cuenta y en el mismo segundo."],
        ["🛡️", "Tú controlas tu riesgo", "Tú configuras el riesgo: tu monto, tu meta (stop win), tu stop loss y tus niveles. Al llegar a tu meta o a tu stop, tu bot deja de copiar."],
        ["🔔", "Copy auto", "Puedes dejar Copy auto activado: cada vez que el autor opere, tus operaciones se copian sin que abras el bot y te llegan las notificaciones."],
        ["🧪", "Demo o real", "Elige si copias en tu cuenta DEMO o REAL. Prueba primero en DEMO."],
    ],
    "solo_copy": ["Copy Bot", "Tú controlas tu riesgo", "Copy auto", "Demo o real"],   # solo quienes tienen el Copy Bot habilitado
    "aviso": "Copiar al autor no garantiza ganancias. Operas en tu cuenta y bajo tu propio riesgo.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [2],           # manual: una temporalidad de 2 a 5 minutos (M1 ya no se usa)
    "tf_auto": False,                # ya no hay temporalidad Auto: una sola, de M1 a M5
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia · "perdida" (solo el autor) = solo lo perdido
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 7,                   # 7: sin mercado real, sin IA, sin multiplicador manual
    "estrategia": "bbrsi",           # "bbrsi" (Bollinger + RSI, para todos) o "mhi" (solo el autor, en prueba)
    "mhi_modelo": "mhi1_min",        # solo el autor: mhi1/mhi2/mhi3/millon + _min (minoría) o _may (mayoría)
    # Copy Bot
    "copy": False,                   # cliente: copia las operaciones del autor (estrategia "Copy Bot")
    "copy_cuenta": "PRACTICE",       # cliente: copia en su cuenta DEMO o REAL
    "copy_auto": False,              # cliente: el bot se abre solo cuando el autor empieza a operar
    "copy_enviar": False,            # autor: envía sus operaciones a los clientes
    "copy_filtros": False,           # autor: solo envía las que pasan los filtros
    "copy_destino": "propio",        # autor: "propio" = clientes de su broker · "todos" = IQ Option y Exnova
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

LOGIN_INTENTOS = 3                 # al entrar: intentos si la red o el bróker no responden


def _es_fallo_de_red(e):
    """True si el error es de la red o de que el bróker no respondió (no de la librería ni de la cuenta).
    La librería a veces devuelve el error de red como respuesta y falla al leerlo ('ConnectTimeout' object has no
    attribute 'text'): también cuenta como fallo de red."""
    t = (type(e).__name__ + " " + str(e)).lower()
    return any(x in t for x in ("connecttimeout", "readtimeout", "connectionerror", "connection aborted",
                                "connection reset", "max retries", "timed out", "timeout", "newconnectionerror",
                                "nameresolution", "getaddrinfo", "temporarily unavailable", "remote end closed",
                                "proxyerror", "10060", "10054", "10061"))


def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

LICENCIA_IA = False        # el autor marcó "SI" en la columna IA de la hoja de licencias de esta cuenta


def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER, "ia": "1", "copy": "1"}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    global LICENCIA_IA, LICENCIA_COPY
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        r = r.split("|")
        r, con_ia, con_copy = r[0], "IA" in r[1:], "COPY" in r[1:]   # "VALID|IA|COPY": lo que el autor habilitó
        respuestas[c] = r
        if r == "VALID":
            LICENCIA_IA, LICENCIA_COPY = con_ia, con_copy
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER,
                               "ia": _firma_licencia(f"{c}|{ahora}|ia") if con_ia else "",
                               "copy": _firma_licencia(f"{c}|{ahora}|copy") if con_copy else ""}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    LICENCIA_IA = LICENCIA_COPY = False
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                LICENCIA_IA = d.get("ia") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|ia")
                LICENCIA_COPY = d.get("copy") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|copy")
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


# =====================================================================
#  COPY BOT
#  El autor envía cada operación (par, dirección, temporalidad y la hora exacta de entrada) unos segundos
#  ANTES de entrar. Los bots de los clientes con Copy Bot entran al mismo segundo (hora del broker), en su
#  propia cuenta, con su monto, sus stops y sus niveles. Una señal que llega tarde se omite.
#  · Señales: Firebase (rápido). Solo el autor puede escribir (con su clave, que está SOLO en su PC);
#    cualquiera puede leer: una señal no tiene datos de nadie.
#  · Estado de los clientes (copiando, meta, stop) y su nombre: hoja del autor (script de Google),
#    solo después de que el cliente acepta los términos del Copy Bot. Nunca se manda saldo ni contraseña.
# =====================================================================
COPY_DB = "https://iqnova-copy-bot-default-rtdb.firebaseio.com"
COPY_DESPERTAR_SEG = 60          # al empezar, el autor espera 1 minuto: los bots de los clientes se abren y conectan
COPY_ANTICIPO_SEG = 5.5          # con Copy Bot el autor decide 5,5 s antes del cierre: la señal llega a todos a tiempo
COPY_TARDE_SEG = 0.25
COPY_SIN_LATIDO_SEG = 300        # si el bot del autor no avisa en 5 min (se apagó su PC), se da por terminado            # si a un cliente le llega con menos de esto antes de la hora de entrada, la omite
COPY_TERMINAR_MAX_SEG = 15 * 60  # al llegar a su stop, el autor sigue enviando recuperaciones hasta 15 min como máximo
COPY_FILTRO_PAYOUT = 0.83
COPY_FILTRO_ACIERTO = 0.60
COPY_TERMINOS_VERSION = 2       # 2: el autor ve la Meta y la Pérdida de cada cliente
LICENCIA_COPY = False            # el autor marcó "SI" en la columna Copy Bot de esta cuenta


def copy_permitido():
    return bool(LICENCIA_COPY)


def copy_ultima_licencia():
    """¿La última licencia verificada (licencia.dat, firmada) tenía el Copy Bot habilitado?"""
    try:
        d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
        return bool(d.get("copy")) and d.get("copy") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|copy")
    except Exception:
        return False


def _archivo_autor(nombre):
    """Las claves del Copy Bot del autor (solo existen en su PC)."""
    lugares = [DATOS, os.getcwd(), os.path.dirname(os.path.abspath(sys.argv[0] or ".")),
               os.path.dirname(os.path.abspath(__file__)),
               os.path.join(os.path.expanduser("~"), "Documents", "IQBot"),
               os.path.join(os.path.expanduser("~"), "Documentos", "IQBot")]
    for d in lugares:
        try:
            r = os.path.join(d, nombre)
            if os.path.isfile(r):
                with open(r, encoding="utf-8") as f:
                    v = f.read().strip()
                if v:
                    return v
        except Exception:
            pass
    return ""


def copy_clave_firebase():
    return _archivo_autor("copybot_firebase.txt")


def copy_clave_autor():
    return _archivo_autor("copybot_autor.txt")


def copy_script(datos, timeout=20):
    """Llama al script del autor (acciones copy_...). Devuelve el texto o None."""
    import requests
    try:
        d = {"key": LICENCIA_KEY, "plataforma": BROKER}
        d.update({k: v for k, v in datos.items() if v is not None})
        r = requests.post(LICENCIA_URL, timeout=timeout, data=d)
        return (r.text or "").strip() if r.status_code == 200 else None
    except Exception:
        return None


class CopyEmisor:
    """SOLO el bot del autor: escribe la sesión y las señales en Firebase."""

    def __init__(self, bot, filtros=False, todos=False):
        import requests
        self.bot = bot
        self.filtros = bool(filtros)
        self.clave = copy_clave_firebase()
        self.s = requests.Session()
        self.ruta = f"{COPY_DB}/copybot/{BROKER}"
        # "todos": la misma señal llega también a los clientes del otro broker (entran en el mismo par allá)
        self.otras = [f"{COPY_DB}/copybot/{x}" for x in BROKERS if x != BROKER] if todos else []
        self.todos = bool(todos)
        self.sid = f"{int(time.time())}{os.getpid() % 1000:03d}"
        self.n = 0
        self.listo_en = 0.0
        self.terminando = None       # hora en que llegó a su stop (sigue enviando solo recuperaciones)
        self.enviadas = 0
        self.no_enviadas = 0
        self.cerrado = False
        self.conectados = []         # clientes conectados (del script)
        self.vivos = {}              # clave → estado en vivo (Firebase)
        self.avisos = deque(maxlen=30)
        self.ultimo_aviso_t = int(time.time() * 1000)
        self.error = ""

    def ok(self):
        return bool(self.clave)

    def _put(self, sub, datos, timeout=4):
        for otra in self.otras:                      # el otro broker, en paralelo (no retrasa la señal principal)
            threading.Thread(target=self._put_en, args=(otra, sub, datos, timeout), daemon=True).start()
        try:
            r = self.s.put(f"{self.ruta}/{sub}.json", params={"auth": self.clave}, json=datos, timeout=timeout)
            if r.status_code != 200:
                self.error = f"Firebase respondió {r.status_code}"
                return False
            self.error = ""
            return True
        except Exception as e:
            self.error = str(e)[:80]
            return False

    def _put_en(self, ruta, sub, datos, timeout):
        try:
            requests_s = getattr(self, "_s2", None)
            if requests_s is None:
                import requests
                requests_s = self._s2 = requests.Session()
            requests_s.put(f"{ruta}/{sub}.json", params={"auth": self.clave}, json=datos, timeout=timeout)
        except Exception:
            pass

    def despertar(self):
        """Primer minuto: los bots de los clientes con Copy auto se abren y se conectan a su cuenta."""
        ahora = self.bot.b.ahora()
        self.listo_en = ahora + COPY_DESPERTAR_SEG
        ok = self._put("sesion", {"activa": True, "sid": self.sid, "inicio": round(ahora, 2), "vivo": round(ahora, 2),
                                  "listo_en": round(self.listo_en, 2), "fin": None, "motivo": ""})
        self._put("senal", {"sid": self.sid, "n": 0})
        threading.Thread(target=self._despertar_celulares, daemon=True).start()
        return ok

    def _despertar_celulares(self):
        """Copy auto en celulares: el script manda un aviso de Firebase que despierta la app de los clientes
        (el aviso solo dice "despierta": no lleva datos tuyos ni de ellos)."""
        clave = copy_clave_autor()
        if clave:
            copy_script({"accion": "copy_despertar", "clave_autor": clave, "sid": self.sid,
                         "brokers": ",".join(BROKERS) if self.todos else BROKER}, timeout=20)

    def latido(self):
        """Cada minuto: la sesión sigue viva (si el PC del autor se apaga, los clientes lo notan)."""
        self._put("sesion/vivo", round(self.bot.b.ahora(), 2))

    def despierto(self):
        return self.bot.b.ahora() >= self.listo_en

    def pasa_filtros(self, c):
        """(pasa, motivo). Solo con "Con filtros": el autor tampoco opera las que no pasan (todo lo que toma, les llega)."""
        if not self.filtros:
            return True, ""
        bot = self.bot
        if (c.get("payout") or 0) < COPY_FILTRO_PAYOUT - 1e-9:
            return False, f"paga {(c.get('payout') or 0) * 100:.0f}% (menos de 83 %)"
        h = time.gmtime(bot.b.ahora() - 5 * 3600).tm_hour            # hora de Bogotá
        if h in (9, 10):
            return False, "horario 9:00–10:59"
        ac = (c.get("racha") or (None, 0))[0]
        if ac is None or ac < COPY_FILTRO_ACIERTO - 1e-9:
            return False, "el par no lleva 60 % a la primera"
        if bot.cfg.get("estrategia") != "mhi" and not c.get("en_nivel"):     # MHI no usa niveles
            return False, "no rebota en un nivel"
        return True, ""

    def enviar(self, s, entrar, solo_rec=False):
        """Envía la operación ANTES de entrar. entrar = hora del broker a la que entran todos."""
        self.n += 1
        d = {"sid": self.sid, "n": self.n, "par": s["par"], "dir": s["dir"], "tf": int(s["tf"]),
             "entrar": round(entrar, 3), "inicio_vela": round(s["inicio_vela"], 2),
             "expira": round(s.get("expira") or (s["inicio_vela"] + s["tf"] * 60), 2),
             "post": bool(s.get("post_cierre")), "etiqueta": s.get("etiqueta", "ENTRADA"),
             "solo_rec": bool(solo_rec), "t": round(self.bot.b.ahora(), 3)}
        ok = self._put("senal", d, timeout=2.5)
        if ok:
            self.enviadas += 1
        return ok

    def enviar_cond(self, vence, si_pierde, si_gana):
        """Antes del cierre: qué hacer con el resultado de la operación que vence (cada cliente según el suyo)."""
        self.n += 1
        d = {"sid": self.sid, "n": self.n, "tipo": "cond", "vence": round(vence, 2),
             "si_pierde": si_pierde, "si_gana": si_gana, "t": round(self.bot.b.ahora(), 3)}
        ok = self._put("senal", d, timeout=2.5)
        if ok:
            self.enviadas += 1
        return ok

    def terminar(self, motivo):
        if self.cerrado:
            return
        self.cerrado = True
        self._put("sesion", {"activa": False, "sid": self.sid, "fin": round(self.bot.b.ahora(), 2), "motivo": motivo})

    def leer_clientes(self):
        """Clientes conectados y avisos nuevos (metas y stops) desde la hoja del autor."""
        clave = copy_clave_autor()
        if not clave:
            return
        txt = copy_script({"accion": "copy_estados", "clave_autor": clave, "desde": str(self.ultimo_aviso_t)})
        if not txt or not txt.startswith("{"):
            return
        try:
            d = json.loads(txt)
        except Exception:
            return
        mios = set(BROKERS.values()) if self.todos else {nombre_broker()}
        self.conectados = [c for c in d.get("conectados") or [] if c.get("plataforma") in mios]
        self._aplicar_vivos()
        for a in d.get("avisos") or []:
            self.ultimo_aviso_t = max(self.ultimo_aviso_t, int(a.get("t") or 0))
            if a.get("plataforma") not in mios:
                continue
            ev = str(a.get("evento") or "")
            nombre = str(a.get("nombre") or "").strip() or "Un cliente"
            cid = str(a.get("cuenta") or "")
            corto = (cid[:4] + "…") if len(cid) > 4 else cid
            try:
                m = float(a.get("monto"))
                monto = f" {'+' if m >= 0 else '−'}${abs(m):.2f}"
            except Exception:
                m, monto = None, ""
            hora = datetime.fromtimestamp((a.get("t") or 0) / 1000).strftime("%H:%M")
            if ev == "Meta alcanzada":
                txt = f"{hora} · {nombre} (ID {corto}) llegó a su meta{monto} y dejó de copiar"
                notificar(f"🏆 {nombre} llegó a su meta", f"Copy Bot · ID {corto}{monto}", tipo="copy_meta",
                          nombre=nombre, monto=m)
            elif ev == "Stop loss":
                txt = f"{hora} · {nombre} (ID {corto}) llegó a su stop loss{monto} y dejó de copiar"
                notificar(f"🛡️ {nombre} llegó a su stop loss", f"Copy Bot · ID {corto}{monto}", tipo="copy_stop",
                          nombre=nombre, monto=m)
            elif ev == "Dejó de copiar":
                txt = f"{hora} · {nombre} (ID {corto}) dejó de copiar{monto}"
                notificar(f"✋ {nombre} dejó de copiar", f"Copy Bot · ID {corto}{monto}", tipo="copy_stop",
                          nombre=nombre, monto=m)
            elif ev.startswith("Enlazado"):
                txt = f"{hora} · {nombre} (ID {corto}) se enlazó al Copy Bot"
            else:
                continue
            self.avisos.appendleft({"texto": txt, "tipo": "meta" if ev == "Meta alcanzada" else
                                    ("stop" if ev == "Stop loss" else "enlace"), "ts": time.time()})
            self.bot.log("📡 " + txt, "bold cyan")

    def escuchar_vivos(self):
        """Autor: escucha en vivo los estados que escriben los clientes (Firebase, con tu clave)."""
        import requests
        brokers = list(BROKERS) if self.todos else [BROKER]
        for br in brokers:
            threading.Thread(target=self._escuchar_vivos, args=(br,), daemon=True).start()

    def _escuchar_vivos(self, br):
        import requests
        espera = 1
        while not self.cerrado and not self.bot.terminado:
            try:
                with requests.get(f"{COPY_DB}/estados/{br}.json", params={"auth": self.clave},
                                  headers={"Accept": "text/event-stream"}, stream=True, timeout=(10, 75)) as r:
                    if r.status_code != 200:
                        raise RuntimeError(r.status_code)
                    espera, evento = 1, None
                    for linea in r.iter_lines(chunk_size=1, decode_unicode=True):
                        if self.cerrado or self.bot.terminado:
                            return
                        if not linea:
                            continue
                        if linea.startswith("event:"):
                            evento = linea[6:].strip()
                            continue
                        if not linea.startswith("data:") or evento not in ("put", "patch"):
                            continue
                        try:
                            d = json.loads(linea[5:].strip())
                        except Exception:
                            continue
                        claves = [k for k in str(d.get("path", "/")).split("/") if k]
                        data = d.get("data")
                        if not claves:
                            for k, v in (data or {}).items():
                                if isinstance(v, dict):
                                    self.vivos[k] = dict(self.vivos.get(k) or {}, **v) if evento == "patch" else v
                        elif len(claves) == 1:
                            if data is None:
                                self.vivos.pop(claves[0], None)
                            elif isinstance(data, dict):
                                self.vivos[claves[0]] = dict(self.vivos.get(claves[0]) or {}, **data) if evento == "patch" else data
                        else:
                            self.vivos.setdefault(claves[0], {})[claves[1]] = data
                        self._aplicar_vivos()
            except Exception:
                time.sleep(espera)
                espera = min(espera * 2, 30)

    def _aplicar_vivos(self):
        """Pone encima de la lista del script lo que llegó en vivo (estado, P/L, nivel, par)."""
        ahora = time.time() * 1000
        for c in self.conectados:
            v = self.vivos.get(copy_clave_estado(str(c.get("cuenta") or "")))
            if not v or ahora - float(v.get("t") or 0) > 15 * 60 * 1000:
                continue
            if v.get("e"):
                c["estado"] = v["e"]
            for k_vivo, k in (("m", "monto"), ("mt", "meta"), ("pd", "perdida"), ("nv", "nivel"), ("pa", "par")):
                if k_vivo in v:
                    c[k] = v[k_vivo]

    def en_recuperacion(self):
        return [c for c in self.conectados if c.get("estado") == "rec"]

    def resumen(self):
        meta = sum(1 for c in self.conectados if c.get("estado") == "meta")
        stop = sum(1 for c in self.conectados if c.get("estado") == "stop")
        copiando = sum(1 for c in self.conectados if c.get("estado") in ("copiando", "rec"))
        falta = max(0, int(self.listo_en - self.bot.b.ahora())) if not self.despierto() else 0
        orden = {"rec": 0, "copiando": 1, "pausa": 2, "meta": 3, "stop": 4, "parado": 5, "fuera": 6}
        clientes = []
        for c in sorted(self.conectados, key=lambda c: (orden.get(c.get("estado"), 9), str(c.get("nombre") or ""))):
            if c.get("estado") in ("meta", "stop", "parado"):
                continue                                 # ya terminó su sesión: sale de la lista de una vez
            cid = str(c.get("cuenta") or "")
            num = lambda k: (float(c[k]) if str(c.get(k, "")).strip() not in ("", "None") else None)
            try:
                clientes.append({"nombre": str(c.get("nombre") or "") or "Cliente", "id": (cid[:4] + "…") if len(cid) > 4 else cid,
                                 "plataforma": c.get("plataforma"), "estado": c.get("estado"), "monto": num("monto"),
                                 "meta": num("meta"), "perdida": num("perdida"), "nivel": int(float(c.get("nivel") or 0)),
                                 "par": str(c.get("par") or "")})
            except Exception:
                continue
        return {"rol": "autor", "copiando": copiando, "meta": meta, "stop": stop, "enviadas": self.enviadas,
                "clientes": clientes[:60],
                "no_enviadas": self.no_enviadas, "filtros": self.filtros, "despertando": falta,
                "terminando": self.terminando is not None and not self.cerrado, "avisos": [a for a in self.avisos if time.time() - a.get("ts", 0) < 60][:6],   # cada aviso, máx. 1 min
                "error": self.error, "sin_clave": not self.ok()}


def copy_clave_estado(cid):
    """Clave del cliente en el canal de estados en vivo (no lleva su ID a la vista)."""
    import hashlib
    return hashlib.sha256(f"iqnova|{cid}".encode()).hexdigest()[:20]


def copy_estado_vivo(cid, datos, timeout=3):
    """Cliente: escribe su estado en Firebase para que el autor lo vea al instante (solo escribir: nadie más lo lee)."""
    import requests
    try:
        d = {"e": str(datos.get("estado") or "")[:12], "m": str(datos.get("monto") or "")[:16],
             "mt": str(datos.get("meta") or "")[:16], "pd": str(datos.get("perdida") or "")[:16],
             "nv": str(datos.get("nivel") or "0")[:3], "pa": str(datos.get("par") or "")[:24], "t": {".sv": "timestamp"}}
        r = requests.put(f"{COPY_DB}/estados/{BROKER}/{copy_clave_estado(cid)}.json", json=d, timeout=timeout)
        return r.status_code == 200
    except Exception:
        return False


def copy_escuchar(al_llegar, detener, al_estado=None):
    """Cliente: escucha las señales del autor (Firebase, en vivo). al_llegar(senal), al_estado(sesion)."""
    import requests
    ruta = f"{COPY_DB}/copybot/{BROKER}.json"
    espera = 1
    arbol = {}
    while not detener():
        try:
            with requests.get(ruta, headers={"Accept": "text/event-stream"}, stream=True, timeout=(10, 75)) as r:
                if r.status_code != 200:
                    raise RuntimeError(f"Firebase {r.status_code}")
                espera = 1
                evento = None
                for linea in r.iter_lines(chunk_size=1, decode_unicode=True):   # cada evento apenas llega
                    if detener():
                        return
                    if not linea:
                        continue
                    if linea.startswith("event:"):
                        evento = linea[6:].strip()
                        continue
                    if not linea.startswith("data:") or evento not in ("put", "patch"):
                        continue
                    try:
                        d = json.loads(linea[5:].strip())
                    except Exception:
                        continue
                    claves = [k for k in str(d.get("path", "/")).split("/") if k]
                    data = d.get("data")
                    if not claves:
                        if evento == "put":
                            arbol.clear()
                        arbol.update(data if isinstance(data, dict) else {})
                        tocados = {"sesion", "senal"}
                    else:
                        nodo = arbol
                        for k in claves[:-1]:
                            if not isinstance(nodo.get(k), dict):
                                nodo[k] = {}
                            nodo = nodo[k]
                        if evento == "patch" and isinstance(data, dict):
                            if not isinstance(nodo.get(claves[-1]), dict):
                                nodo[claves[-1]] = {}
                            nodo[claves[-1]].update(data)
                        elif data is None:
                            nodo.pop(claves[-1], None)
                        else:
                            nodo[claves[-1]] = data
                        tocados = {claves[0]}
                    if al_estado and "sesion" in tocados and isinstance(arbol.get("sesion"), dict):
                        al_estado(dict(arbol["sesion"]))
                    if "senal" in tocados and isinstance(arbol.get("senal"), dict) and len(claves) <= 1:
                        al_llegar(dict(arbol["senal"]))
        except Exception:
            pass
        for _ in range(espera * 10):
            if detener():
                return
            time.sleep(0.1)
        espera = min(espera * 2, 15)


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas por el buzón común (si el bróker no da número de pedido)
        self.lock_rid = threading.Lock()      # contador de números de pedido
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self._memo_velas = {}                 # (id del par, tamaño) -> {hora: cierre} de la última respuesta buena
        self._buzon_sucio = 0.0               # hasta cuándo puede llegar tarde una respuesta vieja al buzón común
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        nb = nombre_broker()
        intento = 0
        while True:                                     # si falla por la red, reintenta solo (3 intentos)
            intento += 1
            try:
                ok, motivo = con_timeout(api.connect, 45)
                if ok or not _es_fallo_de_red(motivo):
                    break                               # entró, o la respuesta no es de red (clave, 2FA…)
            except TimeoutError:
                pass
            except json.JSONDecodeError as e:
                crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
                return None, (f"{nb} devolvió una respuesta inesperada al iniciar sesión "
                              "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                              "navegador para confirmar que tu cuenta abre bien."
                              + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
            except Exception as e:
                if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                    return None, (f"No se pudo verificar la conexión segura con {nb} (certificado no válido). "
                                  "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                                  "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
                if not _es_fallo_de_red(e):
                    libreria_conecto(False, culpa_de_libreria=True)
                    return None, f"Error de conexión: {e}"
            if intento >= LOGIN_INTENTOS:
                return None, (f"{nb} no respondió a tiempo (se intentó {LOGIN_INTENTOS} veces). "
                              f"Puede ser tu internet o que los servidores de {nb} estén lentos en este momento. "
                              "Espera un minuto y vuelve a entrar; si sigue igual, prueba con otra red (por ejemplo, los datos del celular).")
            time.sleep(3 * intento)                     # espera un poco más en cada intento
            try:
                api = IQ_Option(email, clave)           # conexión nueva para el siguiente intento
            except Exception:
                pass
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        raw = self._pedir_velas(aid, tf_min * 60, cantidad + 1, time.time())
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _pedir_velas(self, aid, tam, cantidad, hasta):
        """Pide velas con NÚMERO DE PEDIDO propio: la respuesta solo le llega a quien la pidió, así una respuesta
        atrasada de otro par nunca se confunde con esta (antes se mezclaban velas de otros activos).
        Si el bróker no devuelve el número, usa el buzón común con más cuidado. Siempre revisa las velas."""
        inner = self.inner
        raw = None
        if getattr(self, "_rid_ok", None) is not False:
            buzon = getattr(inner, "_iqbot_velas", None)
            if buzon is None:
                buzon = inner._iqbot_velas = {}
            with self.lock_rid:
                self._rid_n = getattr(self, "_rid_n", 0) + 1
                rid = f"iqv{self._rid_n}"
            datos = {"name": "get-candles", "version": "2.0",
                     "body": {"active_id": int(aid), "split_normalization": True, "size": int(tam),
                              "to": int(hasta), "count": int(cantidad), "": int(aid)}}
            try:
                inner.send_websocket_request("sendMessage", datos, request_id=rid)
                raw = _esperar(lambda: buzon.get(rid), 5)
            except Exception:
                raw = None
            buzon.pop(rid, None)
            if raw is not None:
                self._rid_ok = True
            elif getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: buzón común
        if raw is None and getattr(self, "_rid_ok", None) is False:
            with self.lock:                           # buzón común: un pedido a la vez
                espera = self._buzon_sucio - time.time()
                if espera > 0:                        # una respuesta vieja puede llegar todavía: se deja pasar
                    _esperar(lambda: inner.candles.candles_data, min(espera, 3))
                inner.candles.candles_data = None
                inner.getcandles(aid, tam, cantidad, float(hasta))
                raw = _esperar(lambda: inner.candles.candles_data, 5)
                if raw is None:
                    self._buzon_sucio = time.time() + 10
        if not raw:
            return raw
        if not self._velas_buenas(aid, tam, raw, hasta):
            return None
        return raw

    def _velas_buenas(self, aid, tam, raw, hasta):
        """Revisión de seguridad: las velas tienen que ser de ESTE par. Se comparan con las que ya llegaron antes
        (las mismas horas deben tener el mismo cierre) y se descartan saltos imposibles dentro del bloque."""
        try:
            cierres = [float(v["close"]) for v in raw]
            if not cierres or min(cierres) <= 0:
                return False
            orden = sorted(cierres)
            med = orden[len(orden) // 2]
            if any(abs(c / med - 1) > 0.25 for c in cierres):        # dos activos distintos en un mismo bloque
                return False
            memo = self._memo_velas.setdefault((int(aid), int(tam)), {})
            iguales = distintas = 0
            for v in raw[:-1]:                                      # la última puede estar formándose
                previo = memo.get(int(v["from"]))
                if previo is not None:
                    if abs(float(v["close"]) / previo - 1) < 1e-4:
                        iguales += 1
                    else:
                        distintas += 1
            if distintas >= 2 and distintas > iguales:              # las mismas horas con otros precios: es otro par
                return False
            if not iguales and memo:                                # sin horas en común: si son horas cercanas,
                t_ult = int(raw[-1]["from"])                         # el precio debe estar cerca
                cerca = min(memo, key=lambda t: abs(t - t_ult))
                if abs(cerca - t_ult) <= 3 * 3600 and abs(cierres[-1] / memo[cerca] - 1) > 0.25:
                    return False
            for v in raw[:-1]:
                memo[int(v["from"])] = float(v["close"])
            if len(memo) > 3000:
                for t in sorted(memo)[:len(memo) - 2500]:
                    memo.pop(t, None)
            return True
        except Exception:
            return True

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos: una sola temporalidad, de M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
PREPARAR_A_LA_VEZ = 3                          # pares que se leen a la vez antes del cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real). El bot solo opera OTC."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


BBRSI_PRESETS = {           # "BB + RSI" (autor): la mejor combinación medida en el historial de Exnova para cada temporalidad
    1: (20, 2.0, 14, 75, 25),  # (periodo Bollinger, desviaciones, periodo RSI, nivel alto, nivel bajo) · M1: ~4 veces más señales, mismo acierto
    2: (20, 2.0, 7, 80, 20),
    3: (20, 2.0, 14, 75, 25),
    4: (20, 2.5, 14, 75, 25),
    5: (20, 2.5, 7, 80, 20),
}


def bbrsi_preset(cfg):
    try:
        tf = int((cfg.get("temporalidades") or [2])[0])
    except (TypeError, ValueError):
        tf = 2
    return tf, BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])


RACHA_N, RACHA_MIN = 20, 10   # acierto "a la primera" de cada par: sus últimas 20 señales de BB + RSI (mínimo 10 para contar)


def resultados_bbrsi(velas, tf, desde_t=0):
    """Señales de Bollinger + RSI en velas ya cerradas (posteriores a 'desde_t') y si ganaron a la primera
    (la vela siguiente cerró a favor): {t: True/False}. Los empates no cuentan."""
    per, k, rp, alto, bajo = BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])
    c = [float(v["c"]) for v in velas]
    serie = _rsi_serie(c, rp)                       # serie[0] corresponde a c[rp]
    out = {}
    for i in range(max(per - 1, rp), len(c) - 1):
        t = velas[i]["t"]
        if t <= desde_t or velas[i + 1]["t"] - t != tf * 60:
            continue
        w = c[i - per + 1:i + 1]
        m = sum(w) / per
        s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
        r = serie[i - rp]
        d = -1 if (c[i] > m + k * s and r > alto) else (1 if (c[i] < m - k * s and r < bajo) else 0)
        mov = c[i + 1] - c[i]
        if d and mov:
            out[t] = (mov > 0) == (d > 0)
    return out


# señal "clara": mercado lateral (ADX < 20) y par con 60 % o más a la primera. En cada cierre se prefiere una clara;
# si no hay, la del par con mejor acierto (sin esperar). Solo M2 a M4 (en M5 no mejoró en el historial).
CLARA_ADX, CLARA_ACIERTO, CLARA_TFS = 20.0, 0.60, (2, 3, 4)


def niveles_de(dias, horas, ahora):
    """Niveles donde el precio suele rebotar: pivô y Fibonacci (38,2/50/61,8 %) del día anterior, y soportes/
    resistencias de H1 tocados al menos 2 veces en las últimas 48 h. 'dias' y 'horas': velas D1 y H1 del bróker."""
    out = []
    hoy = int(ahora // 86400) * 86400
    prev = next((d for d in dias or [] if int(d["from"]) == hoy - 86400), None)
    if prev:
        ph, pl, pc = float(prev["max"]), float(prev["min"]), float(prev["close"])
        p = (ph + pl + pc) / 3
        out += [p, 2 * p - pl, 2 * p - ph, p + (ph - pl), p - (ph - pl)]
        out += [pl + (ph - pl) * x for x in (0.382, 0.5, 0.618)]
    hs = [h for h in horas or [] if int(h["from"]) + 3600 <= ahora]
    if len(hs) >= 10:
        rangos = sorted(float(h["max"]) - float(h["min"]) for h in hs)
        tol = 0.15 * rangos[len(rangos) // 2]
        sw = []
        for i in range(2, len(hs) - 2):
            if int(hs[i + 2]["from"]) + 3600 <= ahora - 48 * 3600:
                continue
            ven = hs[i - 2:i + 3]
            if float(hs[i]["max"]) >= max(float(v["max"]) for v in ven):
                sw.append(float(hs[i]["max"]))
            if float(hs[i]["min"]) <= min(float(v["min"]) for v in ven):
                sw.append(float(hs[i]["min"]))
        out += [x for x in sw if sum(1 for y in sw if abs(y - x) <= tol) >= 2]
    return out


def rechaza_nivel(vela, d, niveles):
    """¿La vela de la señal tocó un nivel y cerró devolviéndose, a favor de la dirección? (PUT: tocó desde abajo
    y cerró debajo; CALL: tocó desde arriba y cerró encima)."""
    o, c, h, l = float(vela["o"]), float(vela["c"]), float(vela["h"]), float(vela["l"])
    for x in niveles:
        if d == "put" and h >= x > c and o < x:
            return True
        if d == "call" and l <= x < c and o > x:
            return True
    return False


def adx_ultimo(velas, n=14):
    """ADX de Wilder (fuerza de la tendencia, 0-100) en la última vela, o None si faltan velas."""
    v = velas[-(n * 6):]
    if len(v) < 2 * n + 2:
        return None
    tr, pdm, mdm = [], [], []
    for a, b in zip(v, v[1:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0)
        mdm.append(dn if dn > up and dn > 0 else 0.0)
        tr.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    atr, sp, sm = sum(tr[:n]) / n, sum(pdm[:n]) / n, sum(mdm[:n]) / n
    dxs = []
    for i in range(n, len(tr)):
        atr = (atr * (n - 1) + tr[i]) / n
        sp = (sp * (n - 1) + pdm[i]) / n
        sm = (sm * (n - 1) + mdm[i]) / n
        if atr <= 0:
            continue
        pdi, mdi = 100 * sp / atr, 100 * sm / atr
        dxs.append(100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi > 0 else 0.0)
    if len(dxs) < n:
        return None
    adx = sum(dxs[:n]) / n
    for x in dxs[n:]:
        adx = (adx * (n - 1) + x) / n
    return adx


def senal(cierres, cfg, estricto=False):
    """(dirección o None, texto) de Bollinger + RSI. 'cierres' termina con el precio de la vela de señal.
    estricto (solo el autor en "Solo pérdida"): el RSI más extremo y el precio más afuera de la banda."""
    _tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
    b = bandas(cierres, per, k)
    serie = _rsi_serie(cierres[-(rp * 12 + 2):], rp)
    if not b or not serie:
        return None, ""
    c, r = cierres[-1], serie[-1]
    extra = 0.0
    if estricto:
        alto, bajo = alto + ESTRICTO_RSI, bajo - ESTRICTO_RSI
        extra = (b[0] - b[2]) * ESTRICTO_FUERA
    if c > b[0] + extra and r > alto:
        return "put", f"sobre la banda y RSI {r:.0f}" + (" · exigente" if estricto else "")
    if c < b[2] - extra and r < bajo:
        return "call", f"bajo la banda y RSI {r:.0f}" + (" · exigente" if estricto else "")
    return None, ""


ESTRICTO_RSI = 5          # "Solo pérdida": el RSI debe pasar 5 puntos más allá de su nivel (ej. 80/20 en vez de 75/25)
ESTRICTO_FUERA = 0.10     # y el precio debe cerrar fuera de la banda al menos un 10 % del ancho de las bandas

MHI_MODELOS = {           # (vela del cuadrante de 5 min en que entra, cuántas velas mira)
    "mhi1": (0, 3), "mhi2": (1, 3), "mhi3": (2, 3), "millon": (0, 5)}
MHI_NOMBRES = {"mhi1": "MHI 1", "mhi2": "MHI 2", "mhi3": "MHI 3", "millon": "Millón"}


def mhi_modelo(cfg):
    m = str(cfg.get("mhi_modelo") or "mhi1_min")
    base, _, lado = m.partition("_")
    if base not in MHI_MODELOS or lado not in ("min", "may"):
        base, lado = "mhi1", "min"
    return base, lado


def senal_mhi(velas, prox, cfg):
    """MHI (M1, cuadrantes de 5 minutos). 'velas' son las M1 cerradas, la última termina en 'prox' (cuando entra).
    MHI 1/2/3: mira las 3 últimas velas del cuadrante anterior y entra en la 1.ª/2.ª/3.ª vela del nuevo.
    Millón: mira las 5 velas del cuadrante anterior y entra en la 1.ª. Minoría: el color que salió menos;
    mayoría: el que salió más. Con una vela sin cuerpo (doji) no entra."""
    base, lado = mhi_modelo(cfg)
    entra, cuantas = MHI_MODELOS[base]
    if (int(prox) // 60) % 5 != entra:
        return None, ""
    fin = int(prox) - entra * 60                       # inicio del cuadrante nuevo
    por_t = {int(v["t"]): v for v in velas}
    mira = [por_t.get(fin - 60 * i) for i in range(cuantas, 0, -1)]
    if any(v is None for v in mira):
        return None, ""
    verdes = sum(1 for v in mira if v["c"] > v["o"])
    rojas = sum(1 for v in mira if v["c"] < v["o"])
    if verdes + rojas != cuantas:
        return None, ""
    mas_verdes = verdes > rojas
    d = ("put" if mas_verdes else "call") if lado == "min" else ("call" if mas_verdes else "put")
    return d, f"{MHI_NOMBRES[base]} {'minoría' if lado == 'min' else 'mayoría'} ({verdes} verdes · {rojas} rojas)"


MHI_RACHA_N = 60          # acierto MHI de cada par: sus últimas 60 señales del modelo elegido (~5 h de velas M1)


def resultados_mhi(velas, cfg):
    """Señales del modelo MHI elegido en velas M1 YA cerradas y si ganaron a la primera: [(t, gano)].
    Los empates y las señales con doji no cuentan."""
    base, lado = mhi_modelo(cfg)
    entra, cuantas = MHI_MODELOS[base]
    por_t = {int(v["t"]): v for v in velas}
    out = []
    for t in sorted(por_t):
        if (t // 60) % 5 != entra:
            continue
        e = por_t[t]                                   # la vela en la que se entra
        fin = t - entra * 60
        mira = [por_t.get(fin - 60 * i) for i in range(cuantas, 0, -1)]
        if any(v is None for v in mira):
            continue
        verdes = sum(1 for v in mira if v["c"] > v["o"])
        rojas = sum(1 for v in mira if v["c"] < v["o"])
        if verdes + rojas != cuantas or e["c"] == e["o"]:
            continue
        call = (verdes < rojas) if lado == "min" else (verdes > rojas)
        out.append((t, (e["c"] > e["o"]) == call))
    return out


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "mhi":
        base, lado = mhi_modelo(cfg)
        return f"{MHI_NOMBRES[base]} {'minoría' if lado == 'min' else 'mayoría'} (en prueba)"
    tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
    return f"BB + RSI (M{tf}: BB {per},{k:g} · RSI {rp} {alto}/{bajo})"




class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = False                         # una sola temporalidad
        self.tfs = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal, MHI y Solo pérdida)
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.animo_pend, self.animo_grabadas = [], {}       # registro de señales del autor (senales_datos.csv)
        self.hist = {}           # (par, tf) -> velas
        # acierto "a la primera" de cada par (últimas señales de BB + RSI): manda en qué par se entra primero
        try:
            with open(_ruta_broker("racha_pares.json"), encoding="utf-8") as f:
                self.racha = {k: v for k, v in json.load(f).items() if isinstance(v, dict)}
        except Exception:
            self.racha = {}
        self.racha_t, self.racha_guardada = {}, time.time()
        self.niveles = {}        # par -> (hora en que se calcularon, [niveles de pivô, Fibo y S/R H1])
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None
        # Copy Bot
        self.copy = bool(cfg.get("copy"))      # cliente: copia las operaciones del autor (no analiza)
        self.emisor = None                     # autor: CopyEmisor (app_gui lo pone si envía sus operaciones)
        self.copy_reportar = False             # cliente: aceptó los términos del Copy Bot (avisa copiando/meta/stop)
        self.copy_ses = {}                     # última sesión del autor que llegó
        self.copy_vio_activa = False
        self.copy_autor_fin = False
        self.copy_ultima = None                # hora de la última señal copiada
        self.copy_visto = ("", 0)
        self.copy_omitidas = 0
        self.copy_parado = False               # cliente: tocó "Dejar de copiar"
        self.copy_aviso = ("", 0.0)            # cliente: último aviso corto para la franja (por ejemplo, señal tarde)
        self.copy_escuchando = False
        self.lock_copy = threading.Lock()

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más.
        Autor con Copy Bot: antes de terminar, sigue enviando SOLO recuperaciones a los clientes que
        tienen un ciclo abierto (él ya no opera)."""
        if self.stop_alcanzado():
            if not self.detener and not self.copy_terminando():
                if self.copy_puede_terminar():
                    self.emisor.terminando = time.time()
                    self.avisar_stop()
                    self.log("📡 Terminando: Copy Bot cierra primero la recuperación en curso de tus clientes "
                             "(tú ya no operas). Luego el bot se detiene.", "bold cyan")
                else:
                    self.detener = True
                    self.avisar_stop()
            return True
        return self.detener

    def copy_terminando(self):
        e = self.emisor
        return bool(e and e.terminando is not None and not e.cerrado)

    def copy_puede_terminar(self):
        """¿Hay clientes copiando con una recuperación abierta? (solo entonces el autor sigue enviando)."""
        e = self.emisor
        if not e or e.cerrado:
            return False
        try:
            e.leer_clientes()
        except Exception:
            pass
        return bool(e.en_recuperacion())

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        return monto_nivel(cfg, self.ciclo_perdida, payout or 0.85)

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que se opera ese par. Solo pares OTC (el mercado real ya no se opera, ni en digital):
        binaria (turbo) y, si ese par no la tiene, digital. El pago NO decide el tipo: solo debe pasar el mínimo
        al entrar. (None, None) si no se puede operar."""
        if not es_otc:
            return None, None
        tipo = "turbo" if tf <= 5 else "binary"
        if pays.get(tipo) is not None:
            return tipo, pays[tipo]
        if tf in (1, 5, 15) and pays.get("digital"):
            return "digital", pays["digital"]
        return None, None

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=True)
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def libre_para_entrenar(self):
        """True si no estamos en los segundos del cierre de vela (ahí no se hacen tareas de fondo)."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return 3.0 < t < per - ANALISIS_MAX_SEG - 1.0

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre. Primero los pares que más pagan. Si el bróker devuelve el número
        de pedido, lee hasta 3 pares a la vez (en un celular lento alcanzan más pares antes del cierre)."""
        limite = prox - self.adelanto_analisis() - 1.5
        pago = lambda p: (self.pares.get(p) or {}).get("payout") or 0
        tareas = [(par, tf) for par in sorted(list(self.seleccion), key=pago, reverse=True) for tf in tfs_c]
        if getattr(self.b, "_rid_ok", None) is not True:          # sin número de pedido: uno por uno, como antes
            for par, tf in tareas:
                if not self._preparar_uno(par, tf, prox, limite):
                    return
            return
        from concurrent.futures import ThreadPoolExecutor, wait
        if getattr(self, "_pool_prep", None) is None:
            self._pool_prep = ThreadPoolExecutor(max_workers=PREPARAR_A_LA_VEZ, thread_name_prefix="prep")
        futuros = [self._pool_prep.submit(self._preparar_uno, par, tf, prox, limite) for par, tf in tareas]
        wait(futuros, timeout=max(0.0, limite - self.b.ahora()) + 1.0)
        for f in futuros:
            f.cancel()                                             # lo que no alcanzó a empezar ya no se pide

    def _preparar_uno(self, par, tf, prox, limite):
        """Prepara un par en una temporalidad. Devuelve False si ya no hay tiempo (o se detuvo el bot)."""
        if self.detener or not self.b.conectado or self.b.ahora() > limite:
            return False
        if par in self.pares_en_uso:
            return True
        k = (par, tf)
        try:
            hist = self.hist.get(k) or []
            if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                self.fase = f"Leyendo {par} M{tf}"
                velas = self.b.velas(par, tf, HISTORIA_VELAS)
                if len(velas) < 30:
                    self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); return True
                self.hist[k] = velas
                self.hist_t[k] = time.time()
                if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                        and velas[-1]["t"] >= self.b.ahora() - 180):
                    try:
                        self.vivo_pend[par] = time.time()
                        if not self.b.suscribir_vivo(par, velas):
                            self.vivo_pend.pop(par, None)
                    except Exception:
                        self.vivo_pend.pop(par, None)
            elif hist[-1]["t"] < prox - 2 * tf * 60:
                nuevas = self.b.velas(par, tf, 4)
                por_t = {v["t"]: v for v in hist}
                for v in nuevas: por_t[v["t"]] = v
                self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
            if self.autor and self.cfg.get("estrategia") == "bbrsi":      # en prueba: solo la cuenta del autor
                self.actualizar_niveles(par, limite)
            vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
            self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
        except Exception as e:
            self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)
        return True

    # ---------- prioridad: el par que más gana a la primera ----------
    def actualizar_racha(self, par, tf, cerradas):
        """Suma las señales nuevas del par (ya resueltas por la vela siguiente) a su historial de aciertos."""
        k = (par, tf)
        if len(cerradas) < 2 or self.racha_t.get(k) == cerradas[-2]["t"]:
            return
        try:
            nuevos = resultados_bbrsi(cerradas, tf, self.racha_t.get(k, 0))
            self.racha_t[k] = cerradas[-2]["t"]
            if nuevos:
                d = self.racha.setdefault(f"{par}|{tf}", {})
                for t, g in nuevos.items():
                    d[str(t)] = bool(g)
                if len(d) > 2 * RACHA_N:
                    for t in sorted(d, key=int)[:-2 * RACHA_N]:
                        del d[t]
            if time.time() - self.racha_guardada > 300:
                self.guardar_racha()
        except Exception:
            pass

    def actualizar_niveles(self, par, limite):
        """Una vez por hora y por par: velas D1 y H1 para los niveles (pivô, Fibo, S/R). Solo con tiempo de sobra
        antes del cierre; si el bróker no las da, el par sigue sin niveles (opera igual)."""
        hora = int(self.b.ahora() // 3600)
        if self.niveles.get(par, (None,))[0] == hora or self.b.ahora() > limite - 4:
            return
        self.niveles[par] = (hora, self.niveles.get(par, (0, []))[1])      # no reintentar en la misma hora
        try:
            aid = self.b._id(par)
            if aid is None:
                return
            dias = self.b._pedir_velas(aid, 86400, 3, time.time()) or []
            horas = self.b._pedir_velas(aid, 3600, 60, time.time()) or []
            self.niveles[par] = (hora, niveles_de(dias, horas, self.b.ahora()))
        except Exception:
            pass

    def es_clara(self, c):
        a = (c.get("racha") or (None,))[0]
        return (c.get("tf") in CLARA_TFS and c.get("adx") is not None and c["adx"] < CLARA_ADX
                and a is not None and a >= CLARA_ACIERTO)

    def acierto_par(self, par, tf):
        """(acierto de sus últimas señales a la primera, cuántas). Acierto None si aún tiene pocas."""
        if self.autor and self.cfg.get("estrategia") == "mhi":
            return self.acierto_mhi(par)
        d = self.racha.get(f"{par}|{tf}") or {}
        u = [d[t] for t in sorted(d, key=int)[-RACHA_N:]]
        return (sum(u) / len(u) if len(u) >= RACHA_MIN else None), len(u)

    def acierto_mhi(self, par):
        """MHI: el acierto a la primera del MODELO elegido en este par (sus últimas 60 señales en las velas M1)."""
        velas = self.hist.get((par, 1)) or []
        if not velas:
            return None, 0
        cache = getattr(self, "_mhi_cache", None)
        if cache is None:
            cache = self._mhi_cache = {}
        clave = (velas[-1]["t"], len(velas), self.cfg.get("mhi_modelo"))
        if par in cache and cache[par][0] == clave:
            return cache[par][1]
        r = [g for _, g in resultados_mhi(velas, self.cfg)][-MHI_RACHA_N:]
        val = ((sum(r) / len(r)) if len(r) >= RACHA_MIN else None, len(r))
        cache[par] = (clave, val)
        return val

    def guardar_racha(self):
        self.racha_guardada = time.time()
        try:
            ruta = _ruta_broker("racha_pares.json")
            with open(ruta + ".tmp", "w", encoding="utf-8") as f:
                json.dump(self.racha, f)
            os.replace(ruta + ".tmp", ruta)
        except Exception:
            pass

    # ---------- registro de señales del autor (senales_datos.csv) ----------
    def filtros_autor(self):
        return bool(self.autor)

    @staticmethod
    def volatilidad(cerradas):
        """Tamaño de las últimas 3 velas comparado con lo normal del par (mediana de las 50 anteriores). Solo se anota."""
        rangos = [v["h"] - v["l"] for v in cerradas[-53:]]
        if len(rangos) < 20:
            return None
        base = sorted(rangos[:-3])[len(rangos[:-3]) // 2]
        if base <= 0:
            return None
        return (sum(rangos[-3:]) / 3) / base

    def grabar_senal(self, par, tf, d, cerradas, precio, expira, origen, prob=None, vol=None, pasa=True):
        """Anota la señal (una vez) para ver después cómo terminó el precio: así se mide si los filtros sirven."""
        if not self.filtros_autor():
            return
        clave = (par, tf, int(expira))
        if clave in self.animo_grabadas:
            return
        self.animo_grabadas[clave] = True
        if vol is None:
            vol = self.volatilidad(cerradas)
        self.animo_pend.append({"t": int(self.b.ahora()), "par": par, "tf": tf, "dir": d, "origen": origen, "vol": vol,
                                "prob": prob, "pasa": pasa, "precio": precio, "expira": int(expira)})
        if len(self.animo_grabadas) > 5000:
            self.animo_grabadas.clear()

    def hilo_animo(self):
        """Cuando vence cada señal grabada, mira cómo terminó el precio y lo guarda en senales_datos.csv."""
        ruta = os.path.join(os.path.dirname(os.path.abspath(LOG_FILE)), "senales_datos.csv")
        while not self.detener and not self.terminado:
            time.sleep(3)
            if not self.animo_pend:
                continue
            try:
                ahora = self.b.ahora()
                listas = [r for r in self.animo_pend if ahora >= r["expira"] + 2]
                if not listas:
                    continue
                filas = []
                for r in listas:
                    self.animo_pend.remove(r)
                    m1 = {v["t"]: v for v in (self.b.velas_vivo(r["par"]) or [])}
                    v = m1.get(r["expira"] - 60)
                    if v is None:
                        continue
                    fin = float(v["c"])
                    res = "empate" if fin == r["precio"] else (
                        "gana" if (fin > r["precio"]) == (r["dir"] == "call") else "pierde")
                    filas.append([datetime.fromtimestamp(r["t"]).strftime("%Y-%m-%d %H:%M:%S"), r["par"],
                                  "OTC" if r["par"].endswith("-OTC") else "real", f"M{r['tf']}", r["dir"], r["origen"],
                                  "" if r["vol"] is None else round(r["vol"], 2),
                                  "" if r.get("prob") is None else round(r["prob"] * 100, 1),
                                  "si" if r["pasa"] else "no", r["precio"], fin, res])
                if filas:
                    if os.path.exists(ruta):                        # archivo de una versión anterior (otras columnas):
                        with open(ruta, encoding="utf-8") as f:     # se guarda aparte y se empieza uno nuevo
                            cab = f.readline()
                        if "prob_ia" not in cab:
                            viejo = ruta.replace(".csv", "_viejo.csv")
                            if os.path.exists(viejo):
                                viejo = ruta.replace(".csv", f"_viejo_{int(time.time())}.csv")
                            os.replace(ruta, viejo)
                    nuevo = not os.path.exists(ruta)
                    with open(ruta, "a", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        if nuevo:
                            w.writerow(["fecha", "par", "mercado", "tf", "direccion", "estrategia", "volatilidad", "prob_ia", "pasa_filtro", "precio_entrada", "precio_vence", "resultado"])
                        w.writerows(filas)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] senales\n{traceback.format_exc()}")

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        mhi = self.autor and cfg.get("estrategia") == "mhi"
        estricto = self.autor and cfg.get("rec_modo") == "perdida"      # "Solo pérdida": BB + RSI más exigente
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                self.actualizar_racha(par, tf, cerradas)
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                if mhi:
                    d, det = senal_mhi(cerradas + [actual], prox, cfg)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg, estricto)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                self.grabar_senal(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, cfg.get("estrategia"))
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre, "detalle": det,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst,
                              "adx": adx_ultimo(cerradas + [actual]) if tf in CLARA_TFS else None,
                              "en_nivel": self.autor and cfg.get("estrategia") == "bbrsi" and rechaza_nivel(actual, d, self.niveles.get(par, (0, []))[1])})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        a = max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))
        if self.emisor and not self.emisor.cerrado:
            a = max(a, COPY_ANTICIPO_SEG)          # Copy Bot: la señal sale ~5 s antes y llega a todos a tiempo
        return a





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        return monto_nivel(cfg, ciclo, payout or 0.85)


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # entre las señales del mismo momento (todas ya pasaron el mínimo de 80 %), primero el PAR QUE MÁS GANA
        # A LA PRIMERA (sus últimas señales); un par con pocas señales cuenta como 50 %. Luego desempata:
        for c in cands:
            c["racha"] = self.acierto_par(c["par"], c["tf"])
        r = lambda c: c["racha"][0] if c["racha"][0] is not None else 0.5
        cands = sorted(cands, key=lambda c: (r(c), round(c.get("payout") or 0.0, 3)), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            if self.emisor and not self.emisor.cerrado and self.emisor.despierto():
                try:
                    self.copy_condicional(o, cands, prox)
                except Exception:
                    pass
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        if self.copy:
            self.copy_tras_resultado(vence)           # Copy Bot: lo que el autor dejó dicho antes del cierre
            return
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        terminar = self.copy_terminando()          # autor en su stop: solo envía recuperaciones a los clientes
        if not terminar and (self.frenar_por_stop() or self.pausado):
            return
        if self.emisor and not self.emisor.cerrado and not self.emisor.despierto():
            falta = max(0, int(self.emisor.listo_en - self.b.ahora()))
            self.fase = f"Copy Bot: despertando los bots de los clientes ({falta} s)"
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            etiqueta = f"NIVEL {nivel}"
        else:
            otros = lista
        # entradas y recuperaciones, en cada cierre: 1) la señal que rebota en un NIVEL (pivô, Fibo o S/R H1),
        # 2) una señal CLARA, 3) la del par con mejor acierto a la primera
        elegida, sufijo = self._elegir(otros)
        if not elegida:
            return
        elegida["detalle"] = (elegida.get("detalle") or "") + sufijo
        if terminar:
            if self.b.ahora() < prox - anticipo - 0.6:
                elegida.update({"inicio_vela": prox, "etiqueta": "NIVEL", "expira": prox + elegida["tf"] * 60})
                if self.emisor.enviar(elegida, prox - anticipo, solo_rec=True):
                    self.log(f"📡 Recuperación enviada a los clientes: {elegida['par']} M{elegida['tf']} "
                             f"{elegida['dir'].upper()} (tú no entras).", "cyan")
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        if self.emisor and not self.emisor.cerrado:
            if self.copy_enviar(elegida, prox, plan) == "no":
                return
        self.lanzar(elegida)

    def _elegir(self, otros):
        """(señal, texto) · 1) la que rebota en un NIVEL, 2) una señal CLARA, 3) la del par con mejor acierto."""
        em = getattr(self, "emisor", None)
        if em is not None and not em.cerrado and em.filtros:      # "Con filtros": solo las que también reciben los clientes
            otros = [c for c in otros if em.pasa_filtros(c)[0]]
        for c in otros:
            if c.get("en_nivel"):
                return c, " · rebote en nivel"
        for c in otros:
            if self.es_clara(c):
                return c, " · señal clara"
        return (otros[0], "") if otros else (None, "")

    def copy_condicional(self, o, cands, prox):
        """Autor con una operación que vence en este cierre: ANTES del cierre envía a los clientes lo que se hace
        con el resultado (si pierde: este nivel; si gana: esta entrada). Cada bot lo ejecuta apenas ve su propio
        resultado, igual de rápido que tú: nadie espera una señal después del cierre."""
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]
        pierde, _ = self._elegir([c for c in lista if c["par"] != o["par"]])
        gana, _ = self._elegir(lista)
        if gana is not None and self.pnl + o["monto"] * (o.get("payout") or 0.8) >= float(self.cfg["stop_win"]) - 1e-9:
            gana = None                                       # si gana, llegas a tu meta: no hay entrada después
        ramas = {}
        for nombre, c in (("si_pierde", pierde), ("si_gana", gana)):
            if c is None:
                continue
            pasa, motivo = self.emisor.pasa_filtros(c)
            if not pasa:
                self.emisor.no_enviadas += 1
                self.log(f"📡 Copy Bot: {c['par']} ({'nivel' if nombre == 'si_pierde' else 'entrada'}) no se envía ({motivo}).", "dim")
                continue
            ramas[nombre] = {"par": c["par"], "dir": c["dir"], "tf": int(c["tf"]), "expira": round(prox + int(c["tf"]) * 60, 2)}
        if ramas and self.emisor.enviar_cond(prox, ramas.get("si_pierde"), ramas.get("si_gana")):
            for nombre in ramas:
                ramas[nombre]["n"] = len([x for x in self.emisor.conectados if x.get("estado") in ("copiando", "rec")])
            self.copy_ramas = (prox, ramas)

    def copy_enviar(self, s, prox, plan):
        """Autor: envía la operación a los clientes ANTES de entrar (todos entran al mismo segundo)."""
        if plan:
            # después del resultado: los clientes ya recibieron ANTES del cierre qué hacer (copy_condicional)
            r = getattr(self, "copy_ramas", None)
            if r and abs(r[0] - prox) < 1:
                for rama in r[1].values():
                    if rama["par"] == s["par"] and rama["dir"] == s["dir"]:
                        s["copy_enviada"] = rama.get("n", 0)
                        s["detalle"] = (s.get("detalle") or "") + " · enviada al Copy Bot"
                        break
            return
        pasa, motivo = self.emisor.pasa_filtros(s)
        if not pasa:
            self.emisor.no_enviadas += 1
            self.log(f"📡 Copy Bot: {s['par']} no pasa los filtros ({motivo}): no se opera.", "dim")
            return "no"
            return
        s["expira"] = s.get("expira") or (s["inicio_vela"] + s["tf"] * 60)
        if self.emisor.enviar(s, s["disparo"]):
            s["copy_enviada"] = len([c for c in self.emisor.conectados if c.get("estado") in ("copiando", "rec")])
            s["detalle"] = (s.get("detalle") or "") + " · enviada al Copy Bot"
        else:
            self.log(f"📡 Copy Bot: no se pudo enviar {s['par']} ({self.emisor.error}). La operas tú solo.", "yellow")

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     (f"par {s['racha'][0]*100:.0f}% a la primera ({s['racha'][1]} señales) · " if (s.get('racha') or (None,))[0] is not None else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"], "inst": s.get("inst")}
            if self.copy:
                registro["copy"] = "cliente"
            elif s.get("copy_enviada") is not None:
                registro["copy"] = int(s["copy_enviada"])
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.frenar_por_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()) and not self.copy_terminando():
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        if self.copy_puede_terminar():
                            self.emisor.terminando = time.time()
                            self.log("📡 Terminando: Copy Bot cierra primero la recuperación en curso de tus clientes.", "bold cyan")
                        else:
                            self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            if self.emisor:
                self.emisor.terminar("stop" if self.stop_alcanzado() else "autor")
            self.guardar_racha()
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        if self.copy:
            self.log("🔗 Copy Bot: tu bot entra cuando entra el autor, en tu cuenta, con tu monto, tus stops y tus niveles.", "bold")
            for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo_copy,
                             self.hilo_precios, self.hilo_copy_reporte):
                threading.Thread(target=objetivo, daemon=True).start()
            return
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        if self.emisor:
            threading.Thread(target=self.hilo_emisor, daemon=True).start()
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_animo):
            threading.Thread(target=objetivo, daemon=True).start()


    # ---------- Copy Bot: autor ----------
    def hilo_emisor(self):
        """Autor: primer minuto para despertar a los clientes; luego lee quién copia y quién llegó a su meta."""
        e = self.emisor
        if not e.ok():
            self.log("📡 Copy Bot: falta la clave de Firebase en este equipo (copybot_firebase.txt). "
                     "Tus operaciones NO se envían.", "bold yellow")
            e.cerrado = True
            return
        e.escuchar_vivos()                       # estados de los clientes en vivo (≈1 s)
        if e.despertar():
            self.log(f"📡 Copy Bot: aviso enviado. Primer minuto para despertar los bots de tus clientes; "
                     f"después todos empiezan a operar al tiempo"
                     f"{' (solo se envían las que pasan los filtros)' if e.filtros else ''}.", "bold cyan")
        else:
            self.log(f"📡 Copy Bot: no se pudo avisar a los clientes ({e.error}). Se reintenta.", "bold yellow")
        siguiente, t_vivo = 0, time.time()
        while not self.terminado and not e.cerrado:
            if time.time() - t_vivo >= 60:
                t_vivo = time.time()
                e.latido()
            if time.time() >= siguiente:
                try:
                    e.leer_clientes()
                except Exception:
                    pass
                siguiente = time.time() + (10 if e.terminando else 20)
            if e.terminando is not None:
                if not e.en_recuperacion() or time.time() - e.terminando > COPY_TERMINAR_MAX_SEG:
                    e.terminar("stop")
                    self.log("📡 Copy Bot: ningún cliente queda en recuperación. El bot se detiene.", "bold cyan")
                    self.detener = True
                    return
            if self.detener and not e.terminando:
                break
            time.sleep(1)

    # ---------- Copy Bot: cliente ----------
    def ciclo_copy(self):
        """Cliente: no analiza. Escucha al autor y entra a la hora exacta que él indica."""
        try:
            self.fase = "Copy Bot · conectando con el autor…"
            threading.Thread(target=self._escuchar_copy, daemon=True).start()
            while not self.detener:
                time.sleep(0.3)
                ses = self.copy_ses
                if ses.get("activa") and self.b.ahora() - float(ses.get("vivo") or ses.get("inicio") or 0) > COPY_SIN_LATIDO_SEG:
                    self.copy_sesion_cambia(dict(ses, activa=False))      # el bot del autor dejó de avisar
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.terminado = True

    def _escuchar_copy(self):
        def llega(d):
            try:
                self.copy_llega(d)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] copy\n{traceback.format_exc()}")
        self.copy_escuchando = True
        copy_escuchar(llega, lambda: self.detener or self.terminado, self.copy_sesion_cambia)
        self.copy_escuchando = False

    def copy_sesion_cambia(self, ses):
        viejo = self.copy_ses
        self.copy_ses = dict(ses)
        if ses.get("activa"):
            if ses.get("sid") != viejo.get("sid") or not viejo.get("activa"):
                self.copy_vio_activa = True
                falta = max(0, int((ses.get("listo_en") or 0) - self.b.ahora()))
                self.log("📡 El autor empezó a operar" + (f": en {falta} s empiezan todos al tiempo." if falta else "."), "bold cyan")
                notificar("📡 El autor empezó a operar", f"Copy Bot conectado a tu cuenta {'Real' if self.cuenta == 'REAL' else 'Demo'}"
                          f" · Meta {texto_dinero(self.cfg['stop_win'], False)} · Stop {texto_dinero(self.cfg['stop_loss'], False)}",
                          tipo="copy_inicio")
            self.fase = "Copy Bot · esperando la señal del autor"
        elif self.copy_vio_activa and viejo.get("activa") and not self.copy_autor_fin:
            self.copy_autor_fin = True
            self.log("📡 El autor terminó por hoy. Copy Bot deja de copiar.", "bold cyan")
            notificar("📡 El autor terminó por hoy", f"Copy Bot dejó de copiar · Sesión {texto_dinero(self.pnl)}",
                      tipo="autor_fin", monto=self.pnl, ganadas=self.stats["ganadas"])
            self.detener = True
        elif not ses.get("activa"):
            self.fase = "Copy Bot · el autor no está operando ahora"

    def copy_llega(self, d):
        with self.lock_copy:
            clave = (str(d.get("sid") or ""), int(d.get("n") or 0))
            if not clave[1] or clave == self.copy_visto:
                return
            if clave[0] == self.copy_visto[0] and clave[1] < self.copy_visto[1]:
                return
            self.copy_visto = clave
        if not self.copy_ses.get("activa") or self.copy_ses.get("sid") != clave[0]:
            return
        if d.get("tipo") == "cond":
            self.copy_cond_llega(d)
            return
        par, tf, direc = str(d.get("par") or ""), int(d.get("tf") or 0), str(d.get("dir") or "")
        entrar = float(d.get("entrar") or 0)
        llega = self.b.ahora()
        if llega > entrar - COPY_TARDE_SEG:
            if llega - entrar < 30:
                self.copy_omitidas += 1
                self.copy_aviso = (f"la señal de {par} llegó tarde y no entraste", time.time())
                self.log(f"⏱ Copy Bot: la señal de {par} llegó tarde ({llega - entrar + COPY_TARDE_SEG:+.1f} s); "
                         f"se omite (nunca entra tarde).", "yellow")
            return
        if d.get("solo_rec") and self.nivel == 0:
            return                                   # el autor ya terminó: solo copian quienes tienen un ciclo abierto
        self._copy_entrar(par, tf, direc, float(d.get("inicio_vela") or 0), float(d.get("expira") or 0) or None,
                          entrar, bool(d.get("post")))

    def copy_cond_llega(self, d):
        """Llega ANTES del cierre: qué hacer con el resultado. Si tengo una operación que vence ahí, se ejecuta
        apenas llegue MI resultado; si no, justo después del cierre."""
        vence = float(d.get("vence") or 0)
        if self.b.ahora() > vence + 2:
            return
        with self.lock_copy:
            if not isinstance(getattr(self, "copy_cond", None), dict):
                self.copy_cond = {}
            self.copy_cond = {k: v for k, v in self.copy_cond.items() if k > self.b.ahora() - 30}
            self.copy_cond[round(vence)] = d
        if any(abs(o["vence"] - vence) < 1 for o in list(self.abiertas.values())):
            return                                   # lo ejecuta copy_tras_resultado
        def sin_operacion():
            if self.b.esperar_hasta(vence + 0.8, lambda: self.detener):
                self.copy_tras_resultado(vence)
        threading.Thread(target=sin_operacion, daemon=True).start()

    def copy_tras_resultado(self, vence):
        with self.lock_copy:
            pend = getattr(self, "copy_cond", None) or {}
            d = pend.pop(round(vence), None) if isinstance(pend, dict) else None
            if not d:
                return
        rama = d.get("si_pierde") if self.nivel > 0 else d.get("si_gana")   # según MI resultado (mis niveles)
        if not rama:
            return
        self._copy_entrar(str(rama.get("par") or ""), int(rama.get("tf") or 0), str(rama.get("dir") or ""),
                          float(d.get("vence") or 0), float(rama.get("expira") or 0) or None, None, True)

    def _copy_entrar(self, par, tf, direc, inicio_vela, expira, entrar, post):
        if self.detener or self.pausado or self.stop_alcanzado():
            return
        if par not in self.pares or direc not in ("call", "put") or tf not in TEMPORALIDADES:
            self.log(f"Copy Bot: {par} no está abierto en tu cuenta ahora; esta señal se omite.", "yellow")
            return
        if self.abiertas or self.pares_en_uso:
            self.log(f"Copy Bot: {par} se omite porque tu operación anterior sigue abierta.", "yellow")
            return
        info = self.pares.get(par, {})
        inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
        if inst is None:
            self.log(f"Copy Bot: {par} M{tf} no está disponible en tus mercados; se omite.", "yellow")
            return
        cfg = self.cfg
        nivel, ciclo = self.nivel, self.ciclo_perdida
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, pago)
        etiqueta = f"NIVEL {nivel}" if recuperando else "ENTRADA"
        if recuperando and not self.puede_arriesgar(monto):
            base = self.monto_recuperacion(0, 0.0, pago)
            if self.puede_arriesgar(base):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto, etiqueta = 0, 0.0, False, base, "ENTRADA"
        if not self.puede_arriesgar(monto):
            self.log(f"Copy Bot: entrada de ${monto:.2f} cancelada, el stop loss no deja margen.", "bold yellow")
            return
        self.copy_ultima = time.time()
        s = {"par": par, "tf": tf, "dir": direc, "payout": pago, "estrategia": "Copy Bot", "detalle": "",
             "inst": inst, "inicio_vela": inicio_vela, "expira": expira,
             "disparo": entrar, "post_cierre": post,
             "monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
             "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0}
        self.fase = f"Copy Bot · entrando en {par} con el autor"
        self.lanzar(s)

    def copy_parar(self):
        """El cliente dejó de copiar (desde la app o la notificación): su operación abierta termina normal
        y no entra en ninguna más. Ganando o perdiendo, es su decisión."""
        if not self.copy or self.copy_parado:
            return
        self.copy_parado = True
        self.log(f"✋ Dejaste de copiar al autor · sesión {texto_dinero(self.pnl)}"
                 + (f" · quedó pendiente la recuperación de ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.nivel else ""), "bold cyan")
        self.fase = "Dejaste de copiar al autor"
        self.detener = True

    def copy_estado_deseado(self):
        if self.copy_parado:
            return "parado"
        if self.stop_alcanzado():
            return "meta" if self.pnl > 0 else "stop"
        if self.detener or self.terminado:
            return "fuera"
        if self.pausado:
            return "pausa"
        return "rec" if self.nivel > 0 else "copiando"

    def hilo_copy_reporte(self):
        """Cliente que aceptó los términos del Copy Bot: avisa al autor si copia, si llegó a su meta o a su stop
        (con el monto de la sesión). Nada más: ni saldo ni contraseña."""
        enviado, t_env, vivo = None, 0, None
        script = {"hilo": None}
        while True:
            fin = self.terminado
            if self.copy_reportar:
                e = self.copy_estado_deseado()
                ab = next(iter(list(self.abiertas.values())), None)
                datos = {"estado": e, "monto": f"{self.pnl:.2f}", "meta": f"{float(self.cfg['stop_win']):.2f}",
                         "perdida": f"{float(self.cfg['stop_loss']):.2f}", "nivel": str(self.nivel),
                         "par": ab["par"] if ab else ""}
                firma = tuple(sorted(datos.items()))
                cid = ""
                try:
                    cid = str(self.b.id_iq() or "")
                except Exception:
                    pass
                if cid and firma != vivo and copy_estado_vivo(cid, datos):
                    vivo = firma                                     # al autor, al instante (Firebase)
                h = script["hilo"]
                if cid and (firma != enviado or time.time() - t_env > 120) and (h is None or not h.is_alive()):
                    def al_script(d=dict(datos, accion="copy_estado", cuenta=cid), f=firma):
                        nonlocal enviado, t_env
                        if copy_script(d, timeout=15) is not None:   # historial, avisos y Telegram (más lento)
                            enviado, t_env = f, time.time()
                    script["hilo"] = threading.Thread(target=al_script, daemon=True)
                    script["hilo"].start()
                    if fin:
                        script["hilo"].join(16)
            if fin:
                return
            time.sleep(0.5)

    def resumen_copy(self):
        if self.emisor:
            return self.emisor.resumen()
        if not self.copy:
            return None
        ab = next(iter(list(self.abiertas.values())), None)
        aviso, t_av = self.copy_aviso
        return {"rol": "cliente", "conectado": self.copy_escuchando,
                "autor_activo": bool(self.copy_ses.get("activa")), "autor_fin": self.copy_autor_fin,
                "omitidas": self.copy_omitidas, "parado": self.copy_parado, "nivel": self.nivel,
                "abierta": {"par": ab["par"], "dir": ab["dir"]} if ab else None,
                "aviso": aviso if time.time() - t_av < 70 else ""}

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0"), "inst": o.get("inst")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bbrsi")},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "copy": self.resumen_copy(),
        }

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        ent_g = ent_p = niv_g = niv_p = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                niv_g += neto > 0; niv_p += neto < 0
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                ent_g += neto > 0; ent_p += neto < 0
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor,
                "ent_g": ent_g, "ent_p": ent_p, "niv_g": niv_g, "niv_p": niv_p}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas",
             "incluir_otc", "incluir_mercado_real", "incluir_digital", "rec_multiplicador", "bb_periodo", "bb_desv",
             "rsi_periodo", "rsi_alto", "rsi_bajo", "rsi_direccion", "entrada", "estiro", "ia_prob_min", "ia_modo",
             "ia_forzar")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            if int(guardado.get("config_v", 0) or 0) < 6:
                # M1 ya no se opera: quien estaba en M1 pasa a M2
                tfs = [int(t) for t in (guardado.get("temporalidades") or []) if int(t) in (2, 3, 4, 5)]
                guardado["temporalidades"] = tfs[:1] or [2]
                guardado["config_v"] = 6
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = False                       # ya no hay temporalidad Auto
    cfg.pop("tfs_auto", None)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    if cfg.get("estrategia") not in ("bbrsi", "mhi"):
        cfg["estrategia"] = "bbrsi"                # la IA ya no existe: Bollinger + RSI
    if cfg.get("rec_modo") not in ("auto", "perdida"):
        cfg["rec_modo"] = "auto"                   # el multiplicador manual ya no existe: lo calcula el bot
    cfg["config_v"] = DEFAULT_CONFIG["config_v"]
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)
        shutil.rmtree(os.path.join(base, "ia_velas"), ignore_errors=True)   # la IA ya no guarda velas: aprende en vivo


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def monto_nivel(cfg, perdido, payout=0.85):
    """Monto de un nivel. Automático: recupera lo perdido en el ciclo + la ganancia de la entrada base.
    "Solo pérdida" (autor): recupera solo lo perdido (nunca menos que la entrada base)."""
    base = float(cfg["monto_entrada"])
    p = payout or 0.85
    if cfg.get("rec_modo") == "perdida":
        m = max(base, perdido / p)
    else:
        m = (perdido + base * p) / p
    return max(1.0, round(m, 2))


def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            monto = monto_nivel(cfg, perdido, payout)
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

