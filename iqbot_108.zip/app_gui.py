# -*- coding: utf-8 -*-
"""
IQ Bot Escáner - aplicación con ventana.
La interfaz (interfaz.html) se muestra con el motor de Edge (WebView2) mediante pywebview,
y habla con el bot (iq_bot.py) a través de la clase Api.
"""
import os, sys, threading, time, traceback

if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")

import iq_bot as nucleo


REINICIAR = None      # Android pone aquí su forma de recargar la app tras una actualización
ABRIR_ENLACE = None   # Android pone aquí su forma de abrir el navegador del celular
ENLACE_REGISTRO = "https://iqoption.net/lp/mobile-partner-pwa/es/?aff=838529&aff_model=revenue"   # afiliado de Leiner Serpa


def ruta_recurso(nombre):
    """Ruta de un archivo de esta versión (la descargada por actualización, la del .exe o junto al script)."""
    junto = os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)
    if os.path.isfile(junto):
        return junto
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, nombre)


def _arranque():
    """El módulo que verifica actualizaciones (solo existe si el programa se abrió con arranque.py)."""
    return sys.modules.get("arranque")


def reiniciar_programa():
    """Vuelve a abrir el programa para usar la versión recién descargada."""
    if REINICIAR:
        REINICIAR()
        return
    import subprocess
    env = dict(os.environ, PYINSTALLER_RESET_ENVIRONMENT="1")
    if getattr(sys, "frozen", False):
        comando = [sys.executable] + sys.argv[1:]
    else:
        comando = [sys.executable, os.path.abspath(sys.argv[0])] + sys.argv[1:]
    subprocess.Popen(comando, env=env, close_fds=True)
    os._exit(0)


_TECLADO = []   # se guarda la referencia para que Android no la descarte antes de usarla


def ajustar_teclado_android():
    """Android: al abrir el teclado, la pantalla se DESPLAZA hacia arriba en vez de encogerse.
    Encoger la ventana es lo que dejaba la mitad de la app en negro al escribir el correo o la clave."""
    try:
        from java import jclass, dynamic_proxy
    except ImportError:
        return False                      # PC: no aplica
    try:
        actividad = jclass("org.beeware.android.MainActivity").singletonThis
        modo = jclass("android.view.WindowManager$LayoutParams").SOFT_INPUT_ADJUST_PAN
        Runnable = jclass("java.lang.Runnable")

        class Aplicar(dynamic_proxy(Runnable)):
            def run(self):
                try:
                    actividad.getWindow().setSoftInputMode(modo)
                except Exception:
                    pass

        tarea = Aplicar()
        _TECLADO.append(tarea)
        actividad.runOnUiThread(tarea)
        return True
    except Exception:
        return False


def anotar_error():
    try:
        with open(nucleo.ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}]\n{traceback.format_exc()}")
    except Exception:
        pass


ETIQUETAS = {
    "MHI_1": "MHI 1", "MHI_2": "MHI 2", "MHI_3": "MHI 3", "MHI_Mayoria_1": "Mayoría 1", "MHI_Mayoria_2": "Mayoría 2",
    "MHI_Mayoria_3": "Mayoría 3", "Torres_Gemelas": "Torres Gemelas", "Tres_Mosqueteros": "Tres Mosqueteros",
    "Tres_Vecinos": "Tres Vecinos", "Padron_23": "Padrón 23", "Mejor_de_3": "Mejor de 3", "Patron_3x1": "Patrón 3x1",
    "Minoria_3_velas": "Minoría 3 velas", "Mayoria_3_velas": "Mayoría 3 velas", "RSI_extremo": "RSI extremo",
    "Bollinger_rechazo": "Bollinger", "Cruce_EMA_9_21": "Cruce EMA 9/21", "Envolvente": "Envolvente", "Pinbar": "Pinbar",
    "Tres_soldados": "Tres soldados", "Estocastico": "Estocástico", "Pullback_EMA": "Pullback EMA",
    "Williams_R": "Williams %R", "CCI_extremo": "CCI extremo", "Cruce_MACD": "Cruce MACD",
    "Agotamiento": "Agotamiento", "Vela_de_fuerza": "Vela de fuerza", "Rechazo_SR": "Rechazo en S/R",
    "Retesteo_ruptura": "Retesteo de ruptura", "Numero_redondo": "Número redondo",
}


class Api:
    """Métodos que la ventana puede llamar (window.pywebview.api.*)."""

    def __init__(self):
        self._cfg = nucleo.cargar_config()
        self._broker = None
        self._bot = None
        self._nombre = "DEMO"
        self._login = {"fase": "inactivo", "mensaje": ""}
        self._evento_codigo = threading.Event()
        self._codigo = ""
        self._monitor = None   # lee el mercado desde que se inicia sesión (antes de arrancar el bot)
        ajustar_teclado_android()
        self._prep = {"listo": False, "mensaje": "Revisando la librería de IQ Option…"}
        threading.Thread(target=self._preparar, daemon=True).start()

    # ---------- arranque ----------
    def _preparar(self):
        try:
            if not nucleo.CONGELADO:
                nucleo.asegurar_librerias()
                if self._cfg.get("actualizar_libreria", True):
                    nucleo.actualizar_libreria()
            elif self._cfg.get("actualizar_libreria", True):
                # .exe / Android: busca versión nueva de la librería en GitHub y la usa si es válida
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones de la librería de IQ Option…"}
                cambio, msg = nucleo.actualizar_libreria_embebida()
                if cambio:
                    self._prep = {"listo": True, "mensaje": msg}
            # actualizaciones del bot publicadas por el autor (firmadas)
            arr = _arranque()
            if arr is not None and getattr(arr, "URL_ACTUALIZACIONES", ""):
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones del bot…"}
                nueva = arr.buscar_actualizacion(lambda t: self._prep.update(mensaje=t))
                if nueva:
                    self._prep = {"listo": False, "mensaje": f"Actualización {nueva} instalada. Reiniciando…"}
                    time.sleep(1.5)
                    reiniciar_programa()
                    return
            if self._prep.get("mensaje", "").startswith("Librería de IQ Option actualizada"):
                self._prep = {"listo": True, "mensaje": self._prep["mensaje"]}
            else:
                self._prep = {"listo": True, "mensaje": "Listo para conectar" + self._estado_actualizaciones(arr)}
        except BaseException as e:
            anotar_error()
            self._prep = {"listo": True, "mensaje": f"Aviso al preparar: {str(e)[:80]}"}

    def _estado_actualizaciones(self, arr):
        """Texto corto para la pantalla de inicio: versión y si la revisión de actualizaciones falló."""
        if arr is None or not getattr(arr, "URL_ACTUALIZACIONES", ""):
            return f" · v{nucleo.VERSION_BOT}"
        try:
            with open(os.path.join(arr.DATOS, "actualizaciones.log"), encoding="utf-8") as f:
                ultima = f.read().strip().splitlines()[-1]
            hora = time.mktime(time.strptime(ultima[1:20], "%Y-%m-%d %H:%M:%S"))
            if time.time() - hora < 120 and ("No se pudo" in ultima or "inválida" in ultima or "no coincide" in ultima):
                return f" · v{nucleo.VERSION_BOT} · no se pudo revisar actualizaciones"
        except Exception:
            pass
        return f" · v{nucleo.VERSION_BOT} al día"

    def preparacion(self):
        return self._prep

    def inicio(self):
        arr = _arranque()
        if arr is not None:
            try:
                arr.confirmar()        # la ventana abrió bien con esta versión
            except Exception:
                pass
        return {"email": self._cfg.get("email", ""), "cuenta": self._cfg.get("cuenta", "PRACTICE"),
                "version": nucleo.VERSION_BOT}

    def crear_cuenta(self):
        """Abre el registro de IQ Option con el enlace de afiliado del autor (en el navegador del equipo)."""
        try:
            if ABRIR_ENLACE:
                ABRIR_ENLACE(ENLACE_REGISTRO)
            else:
                import webbrowser
                webbrowser.open(ENLACE_REGISTRO, new=2)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mensaje": str(e)}

    # ---------- inicio de sesión ----------
    def iniciar_sesion(self, email, clave, cuenta):
        if self._login["fase"] in ("conectando", "codigo", "licencia"):
            return {"ok": False, "mensaje": "Ya se está conectando…"}
        if "@" not in (email or ""):
            return {"ok": False, "mensaje": "Escribe un correo válido."}
        if not clave:
            return {"ok": False, "mensaje": "Escribe tu contraseña."}
        if not self._prep["listo"]:
            return {"ok": False, "mensaje": "Espera un momento: se está preparando la librería de IQ Option."}
        self._login = {"fase": "conectando", "mensaje": ""}
        threading.Thread(target=self._hacer_login, args=(email.strip(), clave, cuenta), daemon=True).start()
        return {"ok": True}

    def _pedir_codigo(self):
        self._evento_codigo.clear()
        self._login = {"fase": "codigo", "mensaje": ""}
        self._evento_codigo.wait(300)
        self._login = {"fase": "conectando", "mensaje": ""}
        return self._codigo

    def enviar_codigo(self, codigo):
        self._codigo = (codigo or "").strip()
        self._evento_codigo.set()
        return {"ok": True}

    def _hacer_login(self, email, clave, cuenta):
        try:
            broker, error = nucleo.BrokerIQ.iniciar_sesion(email, clave, self._pedir_codigo)
            clave = None
            if not broker:
                self._login = {"fase": "error", "mensaje": error}
                return
            self._login = {"fase": "licencia", "mensaje": ""}
            id_iq = broker.id_iq()
            ok, msg = nucleo.verificar_licencia(email, id_iq)
            if not ok:
                self._login = {"fase": "sin_licencia", "mensaje": msg, "id_iq": id_iq}
                return
            cuenta = "REAL" if cuenta == "REAL" else "PRACTICE"
            broker.usar_cuenta(cuenta)
            self._broker = broker
            self._nombre = "REAL" if cuenta == "REAL" else "DEMO"
            self._cfg["email"] = email
            self._cfg["cuenta"] = cuenta
            nucleo.guardar_config(self._cfg)
            self._login = {"fase": "listo", "mensaje": "", "licencia": msg}
            self._vigilar_mercado()
        except Exception as e:
            anotar_error()
            self._login = {"fase": "error", "mensaje": f"Error inesperado al conectar: {e}"}

    # ---------- lectura del mercado ----------
    def _vigilar_mercado(self):
        if self._monitor:
            self._monitor.parar = True
        self._monitor = nucleo.MonitorMercado(self._broker, self._cfg) if self._broker else None

    def _dejar_de_vigilar(self):
        if self._monitor:
            self._monitor.parar = True
            self._monitor = None

    def mercado(self):
        return nucleo.MERCADO.resumen()

    def operar_igual(self):
        """El cliente decide operar aunque el mercado esté malo."""
        nucleo.MERCADO.operar_igual = True
        if self._bot:
            self._bot.log("▶ Operando aunque el mercado está malo, por decisión del usuario.", "yellow")
        return {"ok": True}

    def estado_login(self):
        return self._login

    def cerrar_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "Detén el bot primero."}
        try:
            if self._broker:
                self._broker.api.api.close()
        except Exception:
            pass
        self._dejar_de_vigilar()
        self._broker = None
        self._bot = None
        self._login = {"fase": "inactivo", "mensaje": ""}
        return {"ok": True}

    # ---------- configuración ----------
    def datos_config(self):
        estrategias = []
        for n, fn in nucleo.ESTRATEGIAS.items():
            estrategias.append({"nombre": n, "etiqueta": ETIQUETAS.get(n, n.replace("_", " ")),
                                "grupo": "cuadrante" if n in nucleo.ESTRATEGIAS_CUADRANTE else "indicadores",
                                "descripcion": (fn.__doc__ or "").strip()})
        c = dict(self._cfg)
        c["max_pares"] = min(int(c.get("max_pares", 20)), nucleo.MAX_PARES)
        saldo = self._broker.saldo() if self._broker else None
        return {"cfg": c, "estrategias": estrategias, "email": self._cfg.get("email", ""),
                "cuenta": self._cfg.get("cuenta", "PRACTICE"), "saldo": saldo if isinstance(saldo, (int, float)) else None}

    def _mezclar(self, parcial):
        c = dict(self._cfg)
        c.update({k: v for k, v in (parcial or {}).items() if k in nucleo.DEFAULT_CONFIG})
        return c

    def tabla_recuperacion(self, parcial):
        c = self._mezclar(parcial)
        if c.get("recuperacion") == "ninguna":
            return {"filas": [], "total": float(c.get("monto_entrada") or 0), "mult_insuficiente": False}
        try:
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            filas = nucleo.tabla_recuperacion(c, 0.85)
        except Exception:
            return {"filas": [], "total": 0, "mult_insuficiente": False}
        return {"filas": [{"paso": e, "monto": m, "perdido": p, "neto": round(n, 2)} for e, m, p, n in filas],
                "total": filas[-1][2] if filas else 0,
                "mult_insuficiente": c["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:])}

    def iniciar_bot(self, parcial):
        if not self._broker:
            return {"ok": False, "mensaje": "No hay sesión iniciada."}
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "El bot ya está funcionando."}
        c = self._mezclar(parcial)
        try:
            c["monto_entrada"] = float(c["monto_entrada"])
            c["max_operaciones_simultaneas"] = max(1, int(c["max_operaciones_simultaneas"]))
            c["max_pares"] = max(1, min(nucleo.MAX_PARES, int(c["max_pares"])))
            c["payout_minimo"] = float(c["payout_minimo"])
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            c["stop_win"] = float(c["stop_win"]); c["stop_loss"] = float(c["stop_loss"])
            c["winrate_minimo"] = float(c["winrate_minimo"]); c["confluencia_minima"] = max(1, int(c["confluencia_minima"]))
            c["anticipo_ms"] = max(50, min(1500, int(c["anticipo_ms"])))
            c["min_senales_catalogo"] = max(5, min(60, int(c["min_senales_catalogo"])))
            c["winrate_minimo"] = max(0.50, min(0.95, c["winrate_minimo"]))
            c["solo_velas_fuertes"] = bool(c.get("solo_velas_fuertes", True))
            c["estrategias_auto"] = bool(c.get("estrategias_auto", True))
            if c["estrategias_auto"]:
                c["estrategias_activas"] = "todas"
            for k in ("filtro_reciente", "ciclo_reciente", "pausa_tras_perdida"):
                c.pop(k, None)
            c["temporalidades"] = sorted({int(t) for t in c["temporalidades"] if int(t) in nucleo.TEMPORALIDADES})
        except Exception:
            return {"ok": False, "mensaje": "Revisa los números de la configuración."}
        if c["monto_entrada"] < 1:
            return {"ok": False, "mensaje": "La entrada mínima en IQ Option es $1."}
        if not c["temporalidades"]:
            return {"ok": False, "mensaje": "Elige al menos una temporalidad."}
        if not (c["incluir_mercado_real"] or c["incluir_otc"]):
            return {"ok": False, "mensaje": "Elige mercado real, OTC o ambos."}
        if c["estrategias_activas"] != "todas" and not c["estrategias_activas"]:
            return {"ok": False, "mensaje": "Elige al menos una estrategia."}
        if c["stop_win"] <= 0 or c["stop_loss"] <= 0:
            return {"ok": False, "mensaje": "Los stops deben ser mayores que cero."}
        if (c["estrategias_activas"] != "todas" and 1 not in c["temporalidades"]
                and all(n in nucleo.ESTRATEGIAS_CUADRANTE for n in c["estrategias_activas"])):
            return {"ok": False, "mensaje": "Las estrategias de cuadrante solo funcionan en M1: activa M1."}
        saldo = self._broker.saldo()
        if isinstance(saldo, (int, float)) and c["stop_loss"] > saldo:
            return {"ok": False, "mensaje": f"El stop loss (${c['stop_loss']:.2f}) es mayor que tu saldo (${saldo:.2f})."}
        self._cfg = c
        nucleo.guardar_config(c)
        try:
            self._bot = nucleo.Bot(self._broker, c, self._nombre)
            self._bot.iniciar_hilos()
            self._dejar_de_vigilar()          # con el bot andando, él mismo lee el mercado cada minuto
            if nucleo.MERCADO.pausa:
                self._bot.log("⚠ El mercado está malo: el bot arranca en pausa hasta que mejore.", "bold yellow")
        except Exception as e:
            anotar_error()
            return {"ok": False, "mensaje": f"No se pudo iniciar: {e}"}
        return {"ok": True}

    # ---------- operaciones ----------
    def estado(self):
        if not self._bot:
            return {}
        try:
            return self._bot.resumen_gui()
        except Exception:
            anotar_error()
            return {}

    def pausar(self):
        if self._bot:
            self._bot.pausado = not self._bot.pausado
            self._bot.log("⏸ Bot en pausa: sigue analizando pero no abre operaciones." if self._bot.pausado
                         else "▶ Bot reanudado.", "yellow")
        return {"pausado": bool(self._bot and self._bot.pausado)}

    def detener(self):
        if self._bot and not self._bot.detener:
            self._bot.detener = True
            self._bot.log("Deteniendo por pedido del usuario: se esperan las operaciones abiertas.", "yellow")
        return {"ok": True}

    def nueva_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False}
        self._bot = None
        self._vigilar_mercado()
        return {"ok": True}

    def bot_operando(self):
        """True solo si el bot está trabajando (no detenido). Así la X pregunta solo cuando hace falta."""
        return bool(self._bot and not self._bot.detener and not self._bot.terminado)

    def al_cerrar(self):
        self._dejar_de_vigilar()
        try:
            nucleo.inteligencia().guardar(forzar=True)
        except Exception:
            pass
        if self._bot:
            self._bot.detener = True


def main():
    nucleo.ordenar_archivos()
    import webview
    api = Api()
    with open(ruta_recurso("interfaz.html"), encoding="utf-8") as f:
        html = f.read()
    ventana = webview.create_window("IQ Bot Escáner", html=html, js_api=api, width=1240, height=800,
                                    min_size=(720, 540), background_color="#0B0F14", confirm_close=False)

    def al_intentar_cerrar():
        # pregunta solo si el bot está operando; si ya se detuvo (o no ha empezado) cierra directo
        ventana.confirm_close = api.bot_operando()

    ventana.events.closing += al_intentar_cerrar
    ventana.events.closed += lambda: api.al_cerrar()
    opciones = {"gui": "edgechromium"} if sys.platform == "win32" else {}
    webview.start(**opciones, localization={
        "global.quitConfirmation": "El bot está operando. ¿Cerrarlo? Las operaciones abiertas siguen en IQ Option hasta su vencimiento.",
        "global.ok": "Aceptar", "global.quit": "Cerrar", "global.cancel": "Cancelar"})


def arrancar():
    try:
        main()
    except Exception:
        anotar_error()
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, "No se pudo abrir la ventana de IQ Bot Escáner.\n\n"
                                             "Si la ventana no aparece, instala 'Microsoft Edge WebView2 Runtime' "
                                             "(gratis, de microsoft.com) y vuelve a abrir el programa.\n\n"
                                             "Detalle en errores.log, carpeta: " + nucleo.DATOS, "IQ Bot Escáner", 0x10)
        except Exception:
            raise


if __name__ == "__main__":
    arrancar()
