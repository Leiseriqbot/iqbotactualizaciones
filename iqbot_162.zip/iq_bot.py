# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "3.0"
BUILD_BOT = 162

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": False,      # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT 3.0",
    "subtitulo": "Más simple, más liviano y tú eliges la estrategia",
    "items": [
        ["📊", "Bandas de Bollinger", "Son dos líneas alrededor del precio (promedio de 20 velas ± 2 desviaciones). Cuando el precio sale por arriba, el bot entra PUT; cuando sale por abajo, CALL, esperando que regrese."],
        ["📈", "RSI", "Mide la fuerza del movimiento de 0 a 100. Con periodo 2 y niveles 60/40: si cruza hacia arriba el 60 la señal es CALL; si cruza hacia abajo el 40, PUT. Si quieres apostar a que el precio se devuelve, cámbialo a dirección invertida: al cruzar el 60 entra PUT y al cruzar el 40 entra CALL."],
        ["⚙️", "Cómo usarlas", "En Configuración → Estrategia elige Bollinger o RSI. Si no estás seguro, deja los valores que trae. Prueba primero en DEMO y usa pocas recuperaciones."],
        ["🪜", "Recuperación por niveles", "Si una entrada pierde, el bot espera la siguiente señal en otro par. Ya no hace gale ni cambia de dirección."],
        ["🎯", "Bollinger al estirarse", "Con Bollinger puedes elegir la entrada: al cierre de la vela o al estirarse (entra apenas el precio se sale de la banda el % que pongas, sin esperar el cierre)."],
        ["⏱️", "Temporalidad en minutos", "Ahora es un solo campo: pones de 1 a 5 minutos con los botones − y +. Viene en 1 minuto."],
        ["🌎", "Todos los pares", "Vigila OTC, digital y mercado real, y solo entra en pares que paguen 80 % o más."],
    ],
    "aviso": "Operar tiene riesgo alto de pérdida. Ninguna estrategia gana siempre ni garantiza resultados.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [1],           # manual: las que elija (1, 2, 3 y/o 5 minutos)
    "tf_auto": False,                # 3.0: ya no hay Auto; una sola temporalidad de 1 a 5 minutos
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "incluir_digital": True,         # también opciones digitales (se usa la que mejor pague)
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 5,                   # 3.0: estrategia única · 4: RSI normal · 5: temporalidad en minutos
    # estrategia (3.0)
    "estrategia": "bollinger",       # "bollinger" o "rsi"
    "bb_periodo": 20,
    "bb_desv": 2.0,
    "rsi_periodo": 2,
    "rsi_alto": 60.0,
    "rsi_bajo": 40.0,
    "rsi_direccion": "normal",       # "normal" o "invertida" (el cliente la invierte si quiere)
    "entrada": "cierre",             # "cierre" o "estirado" (al estirarse, solo Bollinger)
    "ia_forzar": False,              # solo el autor: la IA opera aunque no pase el umbral (DEMO o REAL, decisión del autor)
    "estiro": 20.0,                  # al estirarse: % del ancho de las bandas que el precio debe pasar la banda
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        respuestas[c] = r
        if r == "VALID":
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas (la librería tiene un solo buzón para velas)
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        try:
            ok, motivo = con_timeout(api.connect, 60)
        except TimeoutError:
            return None, ("IQ Option no respondió. Revisa tu internet; si estás en una red que "
                          "bloquea IQ Option (trabajo, universidad, operador), prueba otra red.")
        except json.JSONDecodeError as e:
            crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
            return None, ("IQ Option devolvió una respuesta inesperada al iniciar sesión "
                          "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                          "navegador para confirmar que tu cuenta abre bien."
                          + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
        except Exception as e:
            if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                return None, ("No se pudo verificar la conexión segura con IQ Option (certificado no válido). "
                              "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                              "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
            libreria_conecto(False, culpa_de_libreria=True)
            return None, f"Error de conexión: {e}"
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        if not getattr(self, "_campos_saldo_vistos", False):     # una vez: deja anotados los campos que manda IQ Option
            self._campos_saldo_vistos = True
            try:
                for bal in raw.get("msg", []):
                    if bal.get("type") == 1:
                        campos = {k: v for k, v in bal.items() if isinstance(v, (int, float)) and k not in ("id", "user_id", "type", "tournament_id")}
                        with open(os.path.join(DATOS, "campos_saldo.log"), "w", encoding="utf-8") as f:
                            f.write(json.dumps(campos, ensure_ascii=False))
            except Exception:
                pass
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def campos_saldo(self):
        """Campos numéricos que manda IQ Option de cada cuenta (para el diagnóstico)."""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05) or {}
        out = []
        for bal in raw.get("msg", []):
            out.append({k: v for k, v in bal.items() if k not in ("id", "user_id") and not isinstance(v, (dict, list))})
        return out

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock:                       # la librería tiene un solo "buzón" para velas
            inner.candles.candles_data = None
            inner.getcandles(aid, tf_min * 60, cantidad + 1, time.time())
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def velas_rapidas(self, par, cantidad, hasta):
        """Como velas_hasta_t pero con número de pedido propio: se pueden pedir 2 pares a la vez."""
        if getattr(self, "_rid_ok", None) is False:
            return self.velas_hasta_t(par, cantidad, hasta)
        aid = self._id(par)
        if aid is None:
            return []
        inner = self.inner
        buzon = getattr(inner, "_iqbot_velas", None)
        if buzon is None:
            buzon = inner._iqbot_velas = {}
        with self.lock:
            self._rid_n = getattr(self, "_rid_n", 0) + 1
            rid = f"iqv{self._rid_n}"
        datos = {"name": "get-candles", "version": "2.0",
                 "body": {"active_id": int(aid), "split_normalization": True, "size": 60,
                          "to": int(hasta), "count": int(cantidad), "": int(aid)}}
        inner.send_websocket_request("sendMessage", datos, request_id=rid)
        raw = _esperar(lambda: buzon.get(rid), 6)
        buzon.pop(rid, None)
        if raw is None:
            if getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: modo normal
                return self.velas_hasta_t(par, cantidad, hasta)
            return []
        self._rid_ok = True
        ahora = self.ahora()
        return [{"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]}
                for v in raw if v["from"] + 60 <= ahora]

    def velas_hasta_t(self, par, cantidad, hasta):
        """v3: velas M1 CERRADAS que terminan en 'hasta' (para completar la memoria hacia atrás o hacia adelante)."""
        aid = self._id(par)
        if aid is None:
            return []
        inner = self.inner
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, int(cantidad), float(hasta))
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if not raw:
            return []
        ahora = self.ahora()
        return [{"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]}
                for v in raw if v["from"] + 60 <= ahora]

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos (un solo campo de 1 a 5)
TFS_AUTO = (1, 2, 3, 4, 5)                   # temporalidad Auto (solo el autor, en pruebas): M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real)."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


def senal(cierres, cfg, estiro=None):
    """(dirección o None, texto). 'cierres' termina con el precio de la vela de señal.
    estiro: solo Bollinger "al estirarse" (% del ancho de las bandas que el precio debe pasar la banda)."""
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres[-(per * 12 + 2):], per)
        if len(serie) < 2:
            return None, ""
        antes, ahora = serie[-2], serie[-1]
        alto, bajo = float(cfg.get("rsi_alto", 60)), float(cfg.get("rsi_bajo", 40))
        d, txt = None, ""
        if antes < alto <= ahora:
            d, txt = "call", f"RSI cruzó hacia arriba {alto:g}"
        elif antes > bajo >= ahora:
            d, txt = "put", f"RSI cruzó hacia abajo {bajo:g}"
        if d and cfg.get("rsi_direccion") == "invertida":
            d = "call" if d == "put" else "put"
            txt += " (invertida)"
        return d, txt
    per = max(2, int(cfg.get("bb_periodo") or 20))
    k = float(cfg.get("bb_desv") or 2)
    b = bandas(cierres, per, k)
    if not b:
        return None, ""
    arriba, _m, abajo = b
    extra = 0.0 if estiro is None else (arriba - abajo) * float(estiro) / 100.0
    c = cierres[-1]
    if c > arriba + extra:
        return "put", (f"estirado {100 * (c - arriba) / (arriba - abajo):.0f}% sobre la banda de arriba"
                       if estiro is not None else "sobre la banda de arriba")
    if c < abajo - extra:
        return "call", (f"estirado {100 * (abajo - c) / (arriba - abajo):.0f}% bajo la banda de abajo"
                        if estiro is not None else "bajo la banda de abajo")
    return None, ""


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "ia":
        return "IA (aprende sola)"
    if cfg.get("estrategia") == "rsi":
        inv = " invertida" if cfg.get("rsi_direccion") == "invertida" else ""
        return f"RSI {int(cfg.get('rsi_periodo') or 2)} ({cfg.get('rsi_alto', 60):g}/{cfg.get('rsi_bajo', 40):g}){inv}"
    t = f" al estirarse {float(cfg.get('estiro', 20)):g}%" if cfg.get("entrada") == "estirado" else ""
    return f"Bollinger {int(cfg.get('bb_periodo') or 20)},{float(cfg.get('bb_desv') or 2):g}{t}"


def indicador_grafico(velas, cfg):
    """Para dibujar la estrategia en el gráfico de la operación: valores alineados con 'velas' (las previas)."""
    cierres = [v["c"] for v in velas]
    n = len(cierres)
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres, per)
        vals = [None] * (n - len(serie)) + [round(x, 1) for x in serie]
        return {"tipo": "rsi", "vals": vals, "alto": float(cfg.get("rsi_alto", 60)), "bajo": float(cfg.get("rsi_bajo", 40))}
    per = max(2, int(cfg.get("bb_periodo") or 20)); k = float(cfg.get("bb_desv") or 2)
    sup, med, inf = [], [], []
    for i in range(n):
        b = bandas(cierres[:i + 1], per, k)
        sup.append(round(b[0], 6) if b else None); med.append(round(b[1], 6) if b else None)
        inf.append(round(b[2], 6) if b else None)
    return {"tipo": "bb", "sup": sup, "med": med, "inf": inf}



# =====================================================================
#  IA DEL AUTOR (3.0): aprendizaje por refuerzo EN LÍNEA, en código propio (sin librerías: PC y celular).
#  En binarias cada decisión dura una vela: al cerrar se sabe cuánto habría pagado CALL y cuánto PUT,
#  así que aprende de TODOS los pares en cada cierre, opere o no (premio = pago del par, castigo = −1).
#  Red pequeña: ~34 datos de entrada -> 16 neuronas -> 2 salidas (lo que espera ganar con CALL y con PUT).
#  Empieza en MODO SOMBRA (decide sin operar) y solo opera cuando su acierto real pasa del 55 % en 300 señales.
#  Solo la ven y la usan las cuentas del autor.
# =====================================================================
IA_ARCHIVO = "ia_refuerzo.json"
IA_CARPETA_VELAS = "ia_velas"
IA_VELAS_DESCARGA = 20000         # velas M1 por par para el primer entrenamiento (≈ 2 semanas)
IA_SENALES_MIN = 300              # señales en sombra antes de poder operar (máximo una por minuto)
IA_SENALES_VENTANA = 1000         # se mide con las últimas 1.000 señales
IA_HORAS_MIN = 2.0                # y repartidas en al menos 2 horas
IA_EQUILIBRIO = 1 / 1.85          # acierto que no pierde ni gana con pago de 85 % (≈ 54 %)
IA_Z = 1.645                      # 95 % de seguridad (una cola)
IA_ACIERTO_APAGAR = 0.53          # si opera y baja de esto en las últimas 300, vuelve a modo sombra


def ia_limite_inferior(g, n, z=IA_Z):
    """Límite inferior de Wilson: el acierto mínimo que se puede asegurar con 95 % de confianza."""
    if n <= 0:
        return 0.0
    p = g / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - r) / d


def ia_acierto_necesario(n):
    """Con n señales, qué acierto hace falta para estar sobre el equilibrio con 95 % de seguridad."""
    n = max(int(n), IA_SENALES_MIN)
    for k in range(int(n * IA_EQUILIBRIO), n + 1):
        if ia_limite_inferior(k, n) >= IA_EQUILIBRIO:
            return k / n
    return 1.0
IA_UMBRAL = 0.04                  # entra solo si espera ganar más de 4 centavos por dólar
IA_VERSION = 2                    # 2 = IA autónoma: solo velas crudas y contexto (sin indicadores ni estrategias)
IA_OCULTAS = 24
IA_VELAS_VE = 20                  # velas que ve completas (cuerpo y mechas)
IA_ENTRADAS = IA_VELAS_VE * 3 + 19
# Lo aprendido en el PC del autor viaja con cada actualización (lo escribe PUBLICAR_ACTUALIZACION en la línea de abajo).
# Al abrir, el equipo del autor toma esta IA si es más nueva que la suya. (Para los clientes la IA está apagada.)
IA_BASE = {'exnova': {'v': 2, 'w1': [[-0.04174, -0.01996, -0.01597, -0.049201, 0.039034, -0.008754, 0.050329, -0.007482, -0.020372, 0.010725, 0.061351, 0.005484, 0.053536, -0.060776, 0.045818, 0.120689, 0.162513, -0.012164, -0.011438, -0.035856, -0.095012, -0.033416, 0.039772, 0.024988, -0.051141, -0.029691, -0.077136, 0.055365, -0.10532, 0.03462, 0.063657, -0.025386, 0.038787, 0.054083, 0.016102, 0.023717, -0.012375, -0.005371, -0.021291, -0.04254, -0.066546, 0.031524, 0.009489, 0.182397, 0.037738, -0.033603, -0.083983, 0.069751, -0.011089, -0.051907, 0.030821, -0.006382, 0.057697, 0.011418, -0.10633, 0.126284, -0.178482, -0.009164, -0.052602, 0.052648, 0.116069, -0.111192, -0.074085, 0.231261, 0.044771, 0.028914, 0.03886, -0.009194, -0.015777, -0.009155, 0.003239, -0.023286, 0.024819, 0.110955, 0.042528, -0.051617, 0.034406, -0.020656, -0.009862], [0.029447, 0.028393, -0.011973, 0.086895, -0.045495, -0.118081, -0.002941, -0.033582, 0.083808, 0.044347, 0.00942, 0.02297, -0.097446, 0.082181, -0.010301, -0.028945, 0.072035, -0.024651, -0.021366, 0.107073, 0.00335, 0.032437, -0.076535, 0.038886, -0.026772, 0.031581, -0.051718, -0.060767, -0.023463, -0.065883, 0.023542, 0.064265, 0.018843, 0.07878, 0.109578, 0.065687, -0.013558, 0.024538, 0.119715, 0.054738, 0.079926, -0.029383, 0.007482, 0.064849, -0.121685, -0.07558, -0.026988, -0.038048, -0.024581, 0.037737, -0.064358, -0.124754, -0.099602, 0.11257, -0.107845, -0.075192, -0.042716, -0.112238, -0.029343, -0.103219, 0.163174, 0.03565, -0.07813, 0.094519, 0.050407, -0.048062, -0.004915, 0.000211, 0.024385, 0.019026, -0.008829, 0.056876, 0.01765, -0.107312, 0.123705, 0.004816, -0.016923, -0.038806, -0.06295], [0.001228, 0.067155, 0.082608, 0.036806, -0.010844, -0.016277, 0.098609, -0.132878, 0.044245, -0.015554, 0.067818, 0.007236, 0.072874, 0.031418, -0.040402, -0.029875, -0.007448, 0.156825, 0.033447, 0.007453, -0.043571, 0.048841, -0.121431, -0.00695, 0.033259, 0.101467, 0.057371, 0.01742, 0.095965, -0.066904, 0.023537, -0.098753, 0.010838, -0.049288, -0.023363, -0.022487, 0.091337, 0.083025, 0.045263, -0.029926, 0.088417, -0.127536, -0.126355, 0.071657, -0.043097, 0.084661, 0.044311, 0.030576, 0.005828, 0.053928, -0.056487, -0.101426, -0.075731, 0.118084, -0.098804, 0.037047, 0.028841, -0.010506, -0.18234, -0.097266, 0.087743, -0.085642, -0.047282, 0.158601, 0.082205, 0.027274, 0.040374, -0.010367, -0.022423, -0.06457, 0.021959, 0.027062, -0.01007, 0.097573, -0.028631, 0.058242, -0.038762, -0.049108, 0.013492], [0.071398, 0.056973, -0.010419, 0.033288, -0.001673, -0.018002, -0.011419, -0.093641, -0.005992, 0.065366, 0.125812, 0.016173, 0.037579, -0.057301, 0.011674, -0.012254, -0.034546, 0.021331, 0.025091, -0.122828, -0.016667, -0.137224, 0.005397, 0.055854, -0.066726, 0.024452, 0.049267, 0.10806, -0.063966, -0.108645, 0.06098, 0.036331, -0.016473, 0.07502, -0.052987, -0.038443, 0.003895, 0.070148, -0.028742, 0.088502, -0.021732, 0.032805, -0.005625, 0.122818, -0.063871, 0.010938, -0.033351, 0.071313, 0.016029, 0.008536, 0.021316, -0.103103, 0.132876, 0.115196, -0.037114, 0.012125, -0.023988, -0.041808, -0.23426, 0.221797, 0.202523, -0.054226, -0.076229, 0.1128, 0.002996, 0.017152, 0.010636, 0.002641, -0.040472, -0.01128, 0.0356, 0.067981, -0.057383, 0.11023, 0.020132, -0.097534, -0.019556, -0.01164, 0.000349], [0.044319, -0.072148, -0.028188, -0.017812, -0.020742, 0.029408, -0.016018, 0.131451, -0.117633, -0.014292, -0.017846, 0.043901, 0.012635, 0.058446, -0.04369, -0.083317, 0.002848, 0.042517, -0.016421, 0.017695, -0.01597, -0.058154, 0.123019, 0.036754, -0.065227, 0.156874, 0.015715, -0.024333, -0.118233, 0.012496, 0.062507, -0.032816, -0.083421, -0.056831, -0.075811, 0.098773, -0.010368, 0.115108, -0.165619, 0.070298, -0.077362, -0.003706, -0.033844, 0.008794, -0.029028, 0.033139, -0.02394, -0.076857, -0.033713, 0.010863, -0.066965, -0.047637, 0.028172, -0.034197, -0.014739, -0.030282, 0.070273, -0.01545, -0.101208, 0.042607, 0.079331, -0.06365, 0.094791, -0.046013, 0.032741, -0.064505, -0.015411, 0.021847, 0.038599, -0.004909, 0.028428, 0.023022, 0.020369, 0.001504, -0.001777, 0.126166, 0.0121, 0.031664, -0.043653], [0.035215, 0.047476, 0.180301, 0.106488, -0.067544, 0.078725, -0.010925, -0.041293, -0.007345, 0.019658, 0.067962, 0.094033, -0.038417, -0.030915, 0.100331, -0.017942, 0.046507, 0.064042, 0.055937, -0.026031, 0.153934, -0.019867, 0.048181, -0.148339, -0.016695, 0.017636, 0.018701, 0.012492, 0.048478, -0.044346, -0.004033, 0.090816, -0.054798, 0.055396, -0.07634, -0.047741, 0.012991, -0.09494, -0.03253, 0.039537, -0.035526, 0.017635, 0.03846, -0.051621, 0.014234, -0.026784, 0.011567, -0.064275, -0.055389, -0.000745, 0.030347, 0.041585, 0.107743, -0.130585, 0.062467, -0.04305, 0.090106, 0.061127, 0.071668, -0.212822, -0.058833, 7.4e-05, -0.000845, 0.037061, 0.034992, -0.003467, 0.011632, -0.013759, 0.003132, -0.022151, -0.034126, 0.043903, -0.049423, -0.088901, 0.044027, -0.000864, 0.018026, -0.002107, 0.072634], [-0.080213, -0.184451, 0.015988, -0.037378, -0.017473, 0.074482, 0.015857, 0.042222, -0.023888, -0.015673, -0.010351, 0.072711, 0.050918, 0.023884, -0.023684, -0.008505, -0.022641, -0.011713, 0.070309, 0.10673, -0.013746, -0.097927, 0.015303, 0.100537, 0.028712, 0.064151, -0.022781, -0.007005, 0.063127, 0.040987, 0.093816, -0.020796, -0.079521, 0.003868, 0.006491, -0.019838, 0.112446, 0.039387, 0.017945, 0.022848, -0.090969, 0.049846, -0.023303, 0.030576, -0.108341, 0.070617, -0.009817, 0.134588, -0.024054, -0.006151, -0.014657, -0.108756, 0.005317, 0.042689, -0.221975, 0.018981, -0.105541, -0.10445, -0.023076, 0.01354, 0.308992, -0.146532, 0.009033, 0.047601, 0.010677, 0.053839, -0.04005, -0.007664, -0.029148, 0.013336, 0.029033, 0.004452, -0.10135, 0.076558, -0.117806, 0.057307, -0.036666, -0.005566, 0.130602], [0.007669, 0.021486, -0.067649, 0.007811, 0.019003, -0.057283, -0.055346, 0.075129, -0.049135, 0.017058, -0.111964, -0.003539, 0.023088, -0.029343, 0.072961, -0.084254, 0.036654, -0.014284, -0.017947, -0.044832, 0.078515, -0.053421, 0.070831, -0.075664, -0.060219, 0.017348, -0.043695, -0.016534, -0.005699, 0.017888, 0.043584, 0.171904, 0.051693, -0.076404, -0.044887, -0.15098, -0.066021, -0.012571, 0.028625, 0.027442, 0.099016, -0.054024, -0.017017, 0.016715, -0.060931, -0.068759, 0.03555, -0.098332, -0.147307, 0.009301, 0.024688, 0.049403, 0.168539, 0.019863, 0.086988, -0.168514, 0.011517, 0.083576, 0.023325, 0.01053, -0.151875, 0.117995, 0.047984, -0.012276, -0.015542, -0.026186, 0.006732, 0.042893, 0.004942, 0.009316, -0.011672, 0.076489, -0.074006, 0.105237, -0.103249, -0.013652, -0.006534, 0.044327, -0.032285], [0.01907, -0.11123, -0.031581, -0.086246, 0.046282, 0.026892, -0.026178, -0.066961, -0.139028, -0.075233, 0.084402, -0.017483, 0.108109, 0.06755, -0.055062, -0.027694, 0.013604, 0.04083, 0.050511, -0.057987, -0.030318, -0.03128, 0.046475, -0.037158, 0.037367, -0.071722, -0.072331, 0.090609, -0.011859, 0.115827, 0.055566, 0.044875, 0.07964, -0.020631, -0.008992, -0.051377, -0.088026, -0.109501, -0.036794, -0.068269, 0.047583, -0.136875, -0.025851, 0.081258, 0.039713, -0.049835, 0.031022, -0.076485, -0.04605, -0.051073, 0.166391, 0.054539, 0.130872, -0.014879, 0.007911, -0.044466, 0.093398, 0.121993, 0.041799, -0.151465, -0.122489, 0.086977, 0.059266, -0.037856, 0.030896, 0.024927, -0.045635, -0.031052, -0.007127, -0.04997, 0.005249, 0.061383, -0.017868, 0.053808, 0.016317, -0.055822, 0.059201, 0.046523, 0.046192], [0.002639, 0.083481, -0.100988, -0.00184, 0.076188, -0.015434, -0.026215, 0.116117, -0.026421, -0.065157, 0.012026, 0.058365, -0.013144, 0.027804, 0.09524, 0.022045, -0.07203, -0.147605, -0.026951, 0.039658, 0.069558, 0.035887, 0.118679, -0.030129, -0.098572, -0.06259, 0.051803, 0.111332, -0.071631, 0.052434, 0.081416, 0.123415, -0.001, 0.024281, -0.067341, -0.056968, -0.113349, 0.001434, -0.017184, -0.093836, 0.014514, 0.084047, 0.042622, 0.100999, 0.108893, -0.067914, -0.036612, 0.106958, -0.051871, -0.053911, -0.117065, -0.068661, 0.00204, -0.031928, -0.056122, 0.073917, -0.120702, -0.024742, -0.149492, 0.22914, 0.00643, -0.025043, -0.02114, 0.105999, -0.043099, -0.010961, 0.054943, 0.007718, -0.012286, 0.001354, -0.075053, 0.02726, -0.164893, 0.093711, 0.04681, 0.082471, -0.10668, 0.007858, -0.064258], [-0.048705, 0.043224, -0.006653, -0.019856, -0.047528, 0.057405, 0.001113, -0.003693, 0.013678, -0.070738, 0.059989, 0.039387, 0.043563, 0.008962, -0.02675, -0.019056, 0.065452, 0.044919, -0.028455, 0.008777, 0.032515, -0.002895, 0.064765, -0.012887, -0.025398, 0.138802, 0.021253, -0.086006, -0.039633, -0.090746, 0.097353, 0.015675, 0.060574, -0.004383, -0.037141, -0.007893, 0.047467, -0.148704, -0.070489, 0.003668, -0.095173, -0.069065, -0.006529, 0.035842, 0.049097, -0.003643, 0.038049, -0.043831, 0.028384, 0.042783, -0.139454, -0.136634, -0.074912, -0.013846, -0.149164, 0.035899, -0.059708, -0.165738, 0.039395, -0.023867, 0.29174, -0.122407, 0.022144, 0.15293, 0.045298, 0.027868, 0.044411, -0.014146, 0.038696, -0.027927, -0.02835, -0.022758, -0.047433, -0.028749, 0.041359, -0.019401, 0.014579, 0.001312, 0.09635], [-0.073161, 0.021011, -0.09715, -0.038228, 0.028291, -0.006021, 0.049101, 0.046271, 0.005595, -0.053435, -0.030265, 0.005651, 0.121387, -0.067761, -0.008638, 0.097233, -0.006624, 0.108001, -0.061892, -0.014685, -0.048178, -0.045314, 0.152529, -0.091836, 0.0112, 0.048909, 0.230752, -0.038805, 0.048381, -0.087273, 0.07633, -0.019242, 0.0525, 0.082412, 0.065528, 0.146664, 0.019244, -0.169608, -0.074253, 0.00456, -0.144592, 0.050557, 0.010719, 0.023363, 0.070501, 0.035106, -0.072689, 0.15135, 0.041468, 0.021207, -0.083939, -0.165513, -0.028739, 0.085061, -0.263862, -0.009634, -0.021336, -0.203715, -0.110439, 0.125713, 0.430158, -0.204289, -0.025698, 0.173764, -0.000678, -0.009186, -0.040341, 0.039627, 0.061261, -0.002459, 0.036666, -0.012454, -0.072791, 0.090957, -0.038008, 0.064755, -0.001197, -0.020767, 0.041687], [0.039491, 0.046789, -0.026761, 0.059564, -0.04326, 0.058875, -0.005573, 0.006246, 0.123501, 0.086817, -0.02748, -0.118001, -0.016543, -0.083965, 0.080264, -0.077763, 0.07076, 0.035883, 0.013652, -0.00669, 0.084943, -0.021426, 0.058728, -0.038611, -0.059463, 0.031395, 0.201949, 0.043509, 0.144227, 0.127262, -0.051994, 0.028972, -0.057882, 0.019572, 0.012943, -0.116079, 0.070849, -0.097935, -0.030684, 0.088115, 0.002337, -0.004049, -0.023624, 0.029328, 0.123713, 0.039193, 0.007696, -0.071851, 0.044611, -0.011692, 0.034976, -0.027366, 0.063281, -0.165611, 0.078566, 0.098831, 0.019696, 0.012926, -0.080073, 0.122815, -0.26984, -0.023584, 0.088435, -0.048024, 0.047598, 0.041717, -0.049132, 0.008099, 0.044248, 0.008503, 0.04649, 0.05112, -0.169577, -0.080202, -0.056835, 0.057371, -0.063362, -0.071075, -0.00326], [-0.022864, -0.071325, 0.026903, -0.070007, 0.113017, -0.042654, -0.047343, -0.035555, 0.025823, 0.021235, -0.060968, -0.048177, -0.078899, 0.045041, -0.093801, -0.01587, -0.038528, -0.0584, 0.015344, 0.046308, -0.043751, -0.013137, 0.016322, -0.009764, 0.039337, -0.027034, 0.039874, -0.03997, 0.040054, 0.027271, 0.007618, 0.004252, -0.009581, 0.004521, 0.071265, 0.004776, -0.014152, -0.13413, 0.048388, -0.025786, 0.108209, -0.016058, 0.03354, 0.123205, 0.101046, -0.071488, 0.088173, -0.013967, -0.018696, -0.087513, -0.041514, 0.00434, 0.04764, 0.007028, -0.058606, -0.08846, 0.067113, 0.02954, 0.110613, -0.140525, -0.034728, 0.091889, 0.030486, -0.164399, 0.026977, 0.023352, -0.058672, -0.042685, 0.030565, -0.016435, -0.054438, 0.005801, -0.057547, 0.032763, 0.034069, 0.093473, 0.086351, 0.036518, -0.015807], [-0.020891, 0.018694, -0.001713, 0.013421, -0.044167, -0.011389, -0.045813, -0.026648, 0.019143, 0.065604, -0.111551, -0.056647, -0.034, 0.001218, 0.064743, 0.091845, -0.022888, -0.074564, -0.052893, 0.012417, 0.019469, -0.024591, 0.040681, 0.087509, 0.013972, 0.005079, -0.002972, -0.004116, -0.034859, 0.035979, -0.115296, -0.102511, -0.060453, 0.055221, 0.114768, 0.060091, -0.048091, -0.076044, -0.002923, -0.058813, 0.043318, -0.082216, 0.02703, -0.033518, 0.016403, -0.062314, -0.010529, -0.027697, -0.061658, -0.073274, 0.215739, -0.001156, 0.038113, -0.062256, -0.005874, -0.07304, 0.009025, 0.037287, 0.195685, -0.136081, 0.068375, 0.128767, -0.009001, -0.027043, -0.04325, -0.034854, -0.035709, 0.032082, -0.011717, 0.058776, 0.004841, -0.031336, 0.032567, 0.092435, -0.068637, -0.111604, 0.024824, 0.049713, -0.099929], [0.019017, -0.04922, 0.017118, -0.010975, -0.026753, 0.027146, -0.058834, -0.079005, 0.01675, -0.051781, 0.057209, -0.021685, 0.069311, 0.003571, -0.068985, 0.059884, -0.020837, 0.037935, 0.019338, -0.000237, -0.047509, 0.05325, 0.038232, 0.009949, 0.000147, -0.00144, -0.032205, 0.016001, -0.121731, -0.108573, -0.014877, -0.075338, 0.011238, -0.018764, -0.118998, -0.058245, -0.107788, 0.002654, 0.076431, 0.004377, 0.029813, -0.021531, 0.032368, -0.083378, -0.044349, 0.030106, 0.095335, -0.033631, -0.013873, -0.088617, 0.001415, 0.10767, -0.003728, -0.007092, 0.043373, -0.01716, 0.110861, 0.040569, 0.136481, -0.087308, -0.050435, 0.219807, 0.026686, -0.261346, -0.165798, -0.006814, 0.011701, -0.063258, -0.054302, 0.013986, -0.011925, -0.014405, 0.081499, -0.087774, 0.068073, -0.073292, 0.048766, 0.072474, 0.04451], [0.099576, -0.03533, 0.019485, -0.028647, 0.091935, 0.098645, -0.041147, -0.218502, 0.017439, 0.090565, -0.105502, -0.014806, -0.016132, 0.077861, 0.010507, -0.116195, -0.00688, -0.020649, -0.003184, 0.041059, 0.044893, -0.024308, 0.032153, 0.073983, -0.055974, 0.055587, 0.056151, 0.057746, 0.079103, -0.066307, 0.055187, 0.090436, -0.106973, 0.072085, -0.033819, -0.05839, -0.061145, -0.015758, 0.147495, 0.141378, -0.057066, 0.022133, 0.028566, 0.115966, -0.134281, -0.037547, -0.005496, 0.050028, 0.02176, 0.094277, -0.170715, -0.078192, 0.05589, 0.165777, -0.069829, -0.023879, -0.037944, -0.064193, -0.103367, 0.056438, 0.061604, -0.00093, 0.01025, 0.015231, -6.4e-05, 0.025684, -0.050253, -0.022787, 0.032744, 0.003136, 0.003343, 0.105003, -0.157886, -0.015745, 0.045604, 0.049709, -0.053343, -0.007817, -0.075081], [0.01284, 0.14034, 0.09057, 0.041009, -0.005315, -0.038541, 0.027479, 0.039631, 0.06846, -0.039223, -0.085642, 0.020735, -0.081, -0.036592, 0.007279, -0.014481, 0.032825, -0.045848, -0.028831, -0.070764, 0.073808, 0.006449, 0.078272, 0.012452, -0.048512, -0.007523, 0.126457, -0.092185, 0.010227, -0.090613, -0.122073, 0.00524, 0.074923, -0.036042, 0.016555, -0.015584, -0.034765, 0.082165, 0.097631, 0.048303, 0.132541, -0.102624, -0.076706, -0.126352, -0.015093, 0.003126, 0.055031, -0.100447, 0.104359, -0.04871, 0.054093, -0.145478, -0.044273, -0.153096, -0.067297, -0.028374, 0.160653, -0.091207, 0.020162, -0.284202, -0.012821, 0.091841, -0.012659, -0.039842, 0.024327, -0.074444, 0.001831, 0.035774, 0.031398, 0.071547, 0.03901, 0.005113, 0.048792, -0.061658, 0.048407, -0.037249, 0.030793, -0.087676, 0.050546], [-0.068318, 0.134756, 0.052298, 0.029652, 0.088505, -0.085409, -0.047661, -0.034607, -0.011436, 0.066682, 0.006484, -0.044853, -0.070429, -0.058317, 0.081199, 0.019106, 0.033761, -0.074146, -0.021573, -0.003529, -0.083908, 0.041858, -0.096417, -0.030728, 0.053333, -0.015309, 0.006876, -0.019099, -0.017797, 0.07293, -0.025201, -0.032008, 0.014867, -0.053814, 0.038406, -0.040133, 0.087102, 0.073375, 0.093307, -0.015958, 0.021168, -0.119396, 0.017788, 0.025738, 0.026187, -0.036168, 0.057406, -0.01261, -0.04109, -0.03039, 0.034164, 0.220134, 0.065053, -0.077084, 0.125411, -0.061492, 0.023738, 0.084514, 0.09914, -0.178203, -0.341462, 0.030826, -0.010899, 0.000886, -0.015806, -0.042991, 0.127482, -0.002139, -0.019753, -0.014986, -0.094796, 0.001985, 0.043098, 0.014079, 0.058695, 0.066539, 0.024753, -0.032481, -0.000132], [-0.001318, -0.102747, -0.01444, -0.041936, -0.014649, 0.069816, 0.032119, -0.01967, 0.003217, -0.013951, -0.077661, -0.019674, 0.040057, -0.017861, 0.02102, 0.032383, 0.049479, -0.046667, -0.040501, 0.026447, 0.129997, 0.006902, 0.047706, -0.103317, 0.005512, 0.029055, 0.020431, -0.005298, 0.020526, 0.044451, -0.036084, -0.041262, 0.060763, -0.022847, -0.049752, 0.033061, -0.07301, -0.117486, -0.124073, -0.032963, 0.096202, -0.103228, 0.001456, -0.031229, 0.092768, 0.003387, -0.036193, -0.007194, 0.016612, -0.083344, 0.065026, 0.00346, 0.105151, -0.052839, 0.033138, 0.0498, 0.099233, 0.110131, 0.107247, -0.002805, -0.105381, 0.08294, 0.049901, -0.062824, 0.011195, 0.024065, -0.049168, 0.02092, -0.039783, 0.054453, 0.047352, -0.028406, 0.023473, 0.013974, -0.079155, -0.041287, 0.022445, -0.018035, -0.027593], [-0.021322, -0.003447, -0.137035, -0.012218, -0.075045, 0.047718, 0.041961, -0.01386, 0.007509, -0.017059, 0.048298, -0.094661, -0.046121, 0.141988, 0.138968, 0.001729, -0.086737, -0.071756, 0.028105, -0.031406, -0.084796, 0.053419, -0.036895, 0.017085, -0.018392, 0.079326, -0.085148, 0.046227, -0.086707, -0.02619, 0.053912, 0.004045, 0.037681, 0.086667, -0.001431, 0.042871, -0.009849, -0.124953, 0.054713, -0.018131, -0.037067, 0.136331, 0.033687, 0.10881, 0.034183, -0.012854, -0.0392, 0.084355, -0.028413, 0.136774, -0.051259, -0.072343, -0.033126, 0.045036, -0.143315, 0.06786, -0.036676, -0.065854, -0.002049, 0.094839, 0.122369, -0.049203, -0.052892, 0.040047, -0.090155, 0.044949, 0.065905, 0.000172, -0.024588, 0.029917, -0.063196, -0.056082, -0.112851, -0.046716, -0.065763, 0.08376, -0.084017, 0.0176, 0.062639], [-0.020859, -0.033134, -0.054646, 0.071901, 0.024403, -0.018354, -0.066657, 0.085834, -0.013513, 0.018513, -0.09925, 0.042429, -0.042039, 0.012154, 0.030879, -0.04309, -0.047135, 0.043005, 0.065923, -0.051904, 0.023035, 0.096135, 0.03832, -0.070819, -0.026638, 0.064227, 0.042771, 0.070588, 0.212869, -0.009393, 0.019198, -0.020292, -0.019115, -0.033763, -0.02519, 0.093153, -0.015131, -0.029129, 0.001662, 0.045173, -0.111595, -0.071096, 0.029044, 0.127318, -0.022712, 0.048218, -0.020984, -0.067912, -0.113162, -0.041951, 0.029702, 0.090042, 0.040226, -0.044346, 0.019052, -0.104125, 0.018095, -0.043587, 0.058668, 0.070834, -0.008462, 0.116626, 0.060227, -0.20379, -0.010522, -0.019657, -0.047073, 0.014061, -0.034157, 0.057222, -0.000311, 0.031683, -0.063123, 0.004378, -0.069348, -0.115522, 0.070372, 0.022237, 0.010257], [-0.00045, 0.00865, 0.026185, -0.100432, 0.005901, 0.054919, 0.086151, 0.027918, -0.022648, -0.086194, 0.012899, 0.04207, 0.069944, -0.032838, -0.072655, 0.064673, -0.031965, 0.050048, 0.104311, -0.042566, -0.00931, 0.069077, -0.152161, 0.096584, 0.116801, -0.042917, 0.123142, 0.097122, -0.173932, -0.027016, -0.003286, -0.087845, 0.149701, 0.058534, -0.053461, -0.093277, -0.032246, 0.09707, 0.15778, 0.032724, 0.01173, -0.063727, -0.010271, -0.032994, -0.091772, 0.002108, -0.090639, -0.067606, 0.084118, 0.016167, 0.188961, 0.115264, 0.079932, 0.066982, -0.029599, -0.042575, 0.062522, 0.084, 0.038547, -0.144374, -0.049873, -0.012045, -0.003202, -0.123598, -0.038605, -0.008672, 0.040882, -0.017099, -0.086372, 0.088583, -0.098444, -0.005064, 0.07636, -0.011871, -0.071467, 0.099816, -0.002601, -0.006378, 0.02064], [0.05468, 0.04777, 0.029677, 0.123309, -0.096136, 0.080663, -0.005534, 0.040526, 0.058377, 0.002679, 0.003465, -0.007099, -0.085544, -0.061192, -0.053162, 0.008287, -0.038931, 0.00293, 0.075502, 0.064798, 0.083055, 0.045389, 0.025603, -0.009879, 0.003019, -0.042903, -0.009526, 0.050233, -0.083326, -0.059529, -0.037357, 0.130099, -0.06267, 0.039157, -0.025459, -0.010201, -0.014256, 0.074263, 0.009306, 0.148453, -0.122701, 0.075231, 0.039788, 0.103614, -0.153293, -0.029828, -0.024913, -0.004549, 0.070108, 0.003554, -0.020586, 0.029558, -0.098183, 0.103641, 0.053778, 0.002875, 0.021599, -0.029406, -0.020973, -0.080164, -0.104174, 0.051595, 0.038364, -0.173229, -0.012562, 0.015441, -0.009566, -0.012413, -0.001233, 0.008307, -0.054022, 0.045873, -0.054094, 0.049876, -0.041012, 0.06865, -0.025541, 0.093965, -0.057313]], 'w2': [[-0.014178, 0.12991, 0.02683, 0.0142, -0.004428, 0.058404, -0.089187, -0.036824, -0.084826, -0.055035, -0.019068, -0.063543, -0.000654, -0.017147, 0.020469, -0.008931, 0.038468, 0.087738, 0.023954, -0.035505, -0.031647, -0.035328, -0.026029, 0.077677, -0.025171], [0.021336, -0.12045, -0.021362, -0.017338, 0.025851, -0.046581, 0.078227, 0.032671, 0.07643, 0.054747, 0.011391, 0.070708, 0.003386, 0.026767, -0.026596, 0.01481, -0.03987, -0.094876, -0.01959, 0.02959, 0.023048, 0.025862, 0.033259, -0.080703, -0.122287]], 'hist_par': {'USDCHF-OTC': '01100111001001101110', 'SP500-OTC': '10010000001101101101', 'ONDOUSD-OTC': '11101010011111101110', 'EURGBP-OTC': '11100100010010101111', 'RENDERUSD-OTC': '01101111010011111111', 'SUIUSD-OTC': '10101001000010101011', 'HBARUSD-OTC': '00011100101000001110', 'RAYDIUMUSD-OTC': '10101001011011110111', 'GBPUSD-OTC': '10100101111111011110', 'PENGUUSD-OTC': '00001000101001010000', 'DYDXUSD-OTC': '10011100010101111011', 'EURUSD-OTC': '01100011100100000000', 'EURJPY-OTC': '11100100001100101111', 'FETUSD-OTC': '11100110011111110110', 'AMAZON-OTC': '11000011111110000010', 'Gold/BRL': '01111101101011001001', 'NZDCAD-OTC': '00001100111110001111', 'LINKUSD-OTC': '10110011011010100111', 'AUDJPY-OTC': '11011111000100011001', 'SANDUSD-OTC': '10100100011001111111', 'GBPCHF-OTC': '01011110010011100110', 'XNGUSD-OTC': '11110011111110101010', 'INJUSD-OTC': '01111101010101111111', 'NEARUSD-OTC': '10101000100000001011', 'FARTCOINUSD-OTC': '11001101100001100111', 'AUDCAD-OTC': '11101011111010111110', 'NZDUSD-OTC': '11110111011101110111', 'USOUSD-op': '11110110000101111001', 'DIA': '10000000010000011001', 'FR40-OTC': '10101010111101110110', 'EURCHF-OTC': '10000101110111111110', 'XAUUSD-OTC': '10101000001001010011', 'Crude Oil Brent/BRL': '11001101000011010000', 'IWM': '11010111100110100110', 'SQQQ': '11111111111110001111', 'XLK': '11110101111111110001', 'SMH': '00010101001110011101', 'EURTHB-op': '11111111111111111111', 'UKOUSD-OTC': '00011110101110100110', 'ATOMUSD-OTC': '11011011010011101110', 'MELANIAUSD-OTC': '11000011010111000000', 'JPM-OTC': '10001011011101100010', 'AIRLINES-OTC': '01101001010110110110', 'WIFUSD-OTC': '00011101010110000010', 'USDJPY-OTC': '11000011111001101101', 'IMXUSD-OTC': '11000010011000111100', 'FWONA-OTC': '10011111101100001001', 'DASHUSD-OTC': '11110101001011110101', 'GDX': '11000111010101110010', 'PEPEUSD-OTC': '00011010111001001111', 'SPY': '01011100001000110101', 'WLDUSD-OTC': '10001000110001010000', 'USDTHB-OTC': '00111011110001001100', 'JP225-OTC': '00000111110010100011', 'USNDAQ100:N': '10001111100101110111', 'USSPX500:N': '01001101101001100010', 'ARBUSD-OTC': '10000000111111010010', 'PENUSD-OTC': '01011001100011100100', 'AUS200-OTC': '11001111100100100110', 'GBPCAD-OTC': '01000111100100111001', 'EURTHB-OTC': '00010101101110010101', 'CHFNOK-OTC': '11010100100110111101', 'MCDON-OTC': '11010001110000010111', 'US30:N': '01000000100011101110', 'JPYTHB-OTC': '11001100110000111011', 'GRTUSD-OTC': '01000111111011101100', 'AUDCHF-OTC': '00010101000101100011', 'SOLUSD-OTC': '11011001100000010111', 'USOUSD-OTC': '01101001000101010000', 'COKE-OTC': '11110100100001000010', 'OpenAI-OTC': '00111101011000110011', 'SHIBUSD-OTC': '01001110001110111101', 'MAGNIFICENT7-OTC': '01111111010110000111', 'USNDAQ100-OTC': '00111110110000111101', 'USDDOP-OTC': '00011100100111011100', 'EURAUD-OTC': '00001101100000010100', 'JAPAN225:N': '01001010001000110101', 'GERMANY30:N': '01101110100101100011', 'FRANCE40:N': '11010001001001110001', 'XRPUSD-OTC': '10100000101110000101', 'JUPUSD-OTC': '00100000110100001110', 'GBPJPY-OTC': '00110000110110010000', 'USDSEK-OTC': '01011111000100111001', 'USDBRL-OTC': '00010010100000100000', 'APPLE-OTC': '01010110010001011101', 'US2000-OTC': '00110010101011110100', 'CADJPY-OTC': '00100111101101111101', 'EOSUSD-OTC': '00010011011000010001', 'AI Power & Datacenter': '11111111111000111101', 'FB-OTC': '00111101011111110010', 'US30-OTC': '11101100010011111110', 'Bitcoin/Gold-op': '01110001001000001111', 'US AI Semiconductors': '01000110010111000100', 'AUDNZD-OTC': '00100111101101010111', 'PLTR-OTC': '10001100010001100011', 'AUS200:N': '11111111011010111000', 'XAGUSD-OTC': '00010111110110011001', 'CADCHF-OTC': '00000101111000110111', 'USDCAD-OTC': '00000100001011100101', 'SNAP-OTC': '01011100001010111001', 'BTCUSD-OTC-op': '11111011111111010000', 'IOTAUSD-OTC': '10111001001110011110', 'MATICUSD-OTC': '10101111010110011010', 'USDPLN-OTC': '00000011001100111001', 'USDSGD-OTC': '00111001000100100011', 'CHFJPY-OTC': '11001000011100110000', 'NZDJPY-OTC': '00100101110100110011', 'USDZAR-OTC': '10010100110001101111', 'KLARNA-OTC': '01000010000100110001', 'HK33-OTC': '11000110001000101001', 'US2000:N': '11111011010111110010', 'HONGKONG33:N': '01101011110100010110', 'USDNOK-OTC': '00101111011100100111', 'Anthropic-OTC': '01001011101101101111', 'UK100-OTC': '11000010100001001100', 'USDCOP-OTC': '10010110001100100110', 'CASINOS-OTC': '01000100111110100001', 'EURCAD-OTC': '11111110111010010000', 'EU50-OTC': '11100010111001011111', 'SATSUSD-OTC': '00011001000110100001', 'URANIUM-OTC': '01000011111011101100', 'BONKUSD-OTC': '10001111110110001001', 'CANNABIS-OTC': '00011000010100011110', 'MSFT-OTC': '01100111101111100001', 'MORSTAN-OTC': '01100111101001000010', 'ETHUSD-OTC': '11010010111101011101', 'AUDUSD-OTC': '10010001100100001111', 'USDARS-OTC': '11111110000011100011', 'TRON-OTC': '10011011000001000000', 'GER30-OTC': '01101100011011111011', 'GBPNZD-OTC': '11010110000110010100', 'GOOGLE-OTC': '10110001010011101101', 'TIAUSD-OTC': '01100110001100011000', 'UK100:N': '00010100111000101000', 'Magnificent7-op': '11001011001011001100', 'GS-OTC': '10110001011110000001', 'GBPAUD-OTC': '01111000001110000001', 'TESLA-OTC': '01001111010100111110', 'LABUBUUSD-OTC': '11010000011001110010', 'USDTRY-OTC': '00000011100110110011', 'DOTUSD-OTC': '10100010010100110010', 'ALIBABA-OTC': '11101111111011001000', 'TRUMPUSD-OTC': '10111111001111001100', 'PYTHUSD-OTC': '10011001110010011010', 'EURNZD-OTC': '01000010100110110010', 'LTCUSD-OTC': '01100000010000000010', 'GER30/UK100-OTC': '00001001000111100101', 'COTTON-OTC': '01100001011101111111', 'US30/JP225-OTC': '01110010111000111001', 'EURJPY-op': '10111101101101111011', 'TESLA/FORD-OTC': '00111110100100000010', 'NVDA/AMD-OTC': '11101011010001111011', 'XAU/XAG-OTC': '10110011111111011110', 'GOOGLE/MSFT-OTC': '01001001001010110111', 'META/GOOGLE-OTC': '00000101000100100011', 'LUNA-OTC': '11000010010111110011', 'USDAED-OTC': '00110111111101001000', 'US100/JP225-OTC': '00011001011011010100', 'MSFT/AAPL-OTC': '00110001110011001011', 'AMZN/EBAY-OTC': '11000011010010101100', 'NVDA-OTC': '00011101011101000010', 'EURUSD-op': '11000000001110011000', 'EURGBP-op': '000001101011001000', 'USDTHB-op': '11010110110010001111', 'USDMYR-OTC': '10111001101000100100', 'AMZN/ALIBABA-OTC': '01011010011111101011', 'USDVND-OTC': '10101111000000010111', 'COCOA-OTC': '11101111111100101101', 'USDBOB-OTC': '00011011100001111111', 'ICPUSD-OTC': '11010001000101001010', 'USDIDR-OTC': '10001100001000100110', 'XPDUSD-OTC': '00000000101010011110', 'USDHKD-OTC': '10101010100001110110', 'WDC-OTC': '00010100101001110100', 'COFFEE-OTC': '11000000000010111101', 'USDPHP-OTC': '01010110000011011011', 'USDJPY-op': '11101011000011100110', 'XPTUSD-OTC': '10111010011011101001', 'SUGAR-OTC': '00110110000000111101', 'GBPJPY-op': '10100111101100000000', 'USDNGN-OTC': '10110101011000100111', 'INTEL/IBM-OTC': '01011000001101100110', 'SEIUSD-OTC': '10100101010110100101', 'USDSAR-OTC': '01111111000000101110', 'RONINUSD-OTC': '00011000100010111101', 'HYPE-OTC': '00011100110011110001', 'NIKE-OTC': '00101011101100101101', 'MU-OTC': '10010000100001001001', 'GEV-OTC': '11001110100010110101', 'USDBDT-OTC': '10011011100101111011', 'NFLX/AMZN-OTC': '00101001010010010000', 'GBPUSD-op': '10011100100010000100', 'USDCLP-OTC': '11000100001010011111', 'XAUUSD-op': '11111111011111000110', 'SpaceX-OTC': '00001100111000100101', 'SpaceX-op': '00111111001001111100'}, 'hist_ctx': {'otc20': '00100001111011111001100110111110110101011100010111', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '01001111000100001010100011100001000100100000101111', 'otc1': '11001110011011001101111111000101101111100101011111', 'otc2': '00101010100001111011010000010111000001111111011100', 'otc3': '00100111111110011000000001011111110011110000010100', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '10010011100010000110000000010010110110110110101010', 'otc13': '10011101000001111111010110100000111111010011101011', 'otc14': '11111000001010010101001000001011100000000100000001', 'otc15': '10010001100011100100001000001110010011001011010001', 'otc16': '10011110100010011101011010010001011011101000111110', 'otc18': '00100111011101010010001101111100010101000100000000', 'otc19': '01001110010110001010101111001000001110100011110001', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '01000001000110110110011001101110000010100111001001', 'real17': '10011010001000111001101111001011010111111111111111', 'real12': '01000100000110011001010001010110111110001010000110', 'real13': '11111000001001010000100001110111101010100110111011', 'real14': '01000111011111111000100101001001110010000001111111', 'real15': '00100001101001110000000110001011010111111111111111', 'real16': '11001101101110100111100101001100111110111111111111', 'real18': '01101001101011011001100100010100111111101111110111', 'real19': '00001111010010001000101001100000001000101001100010', 'real20': '11100011001110010000110111111111111000000010100001', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '00111100101110101101110000101100000110111100100100', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5788414, 'preentreno': True, 'sombra': '01111010000000100100010110001101101111100100101001100000000101001010100011101101010001000110010111011100111100000010010100000110010111110111110110010101111111001100001111011111111011010101010000100010111001100101110100001100000001101111010101010111111110000111110000101110110001011001000111111111110101', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1303, 'activa': False, 'ev_prom': 0.04414768212606878, 'ultima_senal': 1793413338.8675692, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1793413589}}
_CRIPTO = ("BTC", "ETH", "SOL", "XRP", "LTC", "DOT", "ADA", "CARDANO", "DOGE", "SHIB", "PEPE", "BONK", "TRON", "TRX",
           "SUI", "ARB", "HBAR", "FET", "ONDO", "TAO", "WIF", "WLD", "SEI", "JUP", "DYDX", "EOS", "DASH", "ATOM",
           "LUNA", "TRUMP", "RAYDIUM", "RENDER", "PENGU", "PEN", "SATS", "HYPE", "FARTCOIN", "MELANIA", "FLOKI",
           "LINK", "NEAR", "MATIC", "IMX", "INJ", "ORDI", "PYTH", "STX", "GRT", "SAND", "MANA", "ICP", "IOTA", "RONIN",
           "BCH", "LABUBU")
_DIVISAS = ("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "THB", "MXN", "BRL", "COP", "ZAR", "TRY", "INR",
            "IDR", "PHP", "PLN", "SGD", "HKD", "NOK", "SEK", "ARS", "CLP", "DOP", "BOB", "BDT", "NGN", "VND", "MYR",
            "AED", "SAR", "EGP", "PKR")


def ia_tipo_par(par):
    """(es_otc, es_divisa, es_cripto) a partir del nombre del par."""
    p = str(par).upper().replace("-OTC", "").replace("-OP", "")
    otc = "OTC" in str(par).upper()
    cripto = any(p.startswith(c) for c in _CRIPTO)
    divisa = (not cripto) and len(p) == 6 and p[:3] in _DIVISAS and p[3:] in _DIVISAS
    return otc, divisa, cripto


def _ia_lim(x, a=3.0):
    return a if x > a else (-a if x < -a else x)


def ia_rasgos(velas, par, pago, t, tf=1, digital=False, propio=(0.0, 0.0, 0.0, 0.0)):
    """Lo que 've' la IA autónoma: velas crudas y contexto. Nada de indicadores ni estrategias hechas.
    velas: dicts o,h,l,c (la última es la vela de señal). Devuelve IA_ENTRADAS números o None."""
    n = len(velas)
    if n < 40:
        return None
    c = [v["c"] for v in velas]
    tr = [max(velas[i]["h"], c[i - 1]) - min(velas[i]["l"], c[i - 1]) for i in range(n - 14, n)]
    atr = sum(tr) / 14.0                               # tamaño normal de una vela ahora (para comparar)
    if atr <= 0:
        atr = abs(c[-1]) * 1e-5 or 1e-9
    tr50 = [velas[i]["h"] - velas[i]["l"] for i in range(max(1, n - 50), n)]
    atr50 = (sum(tr50) / len(tr50)) or atr
    f = []
    for v in velas[-IA_VELAS_VE:]:                     # las últimas 20 velas tal cual: cuerpo y mechas
        f.append(_ia_lim((v["c"] - v["o"]) / atr))
        f.append(_ia_lim((v["h"] - max(v["o"], v["c"])) / atr))
        f.append(_ia_lim((min(v["o"], v["c"]) - v["l"]) / atr))
    f.append(_ia_lim((c[-1] - c[-4]) / atr / 2))      # cuánto se ha movido el precio (corto, medio, largo)
    f.append(_ia_lim((c[-1] - c[-11]) / atr / 3))
    f.append(_ia_lim((c[-1] - c[-31]) / atr / 5))
    alto = max(v["h"] for v in velas[-30:]); bajo = min(v["l"] for v in velas[-30:])
    f.append(_ia_lim(((c[-1] - bajo) / ((alto - bajo) or 1e-12)) * 2 - 1))   # dónde está dentro del rango reciente
    f.append(_ia_lim(atr / atr50 - 1.0))              # ¿más agitado o más quieto que de costumbre?
    h = (t % 86400) / 86400.0 * 2 * math.pi           # hora del día (UTC), día y fin de semana
    f.append(math.sin(h)); f.append(math.cos(h))
    dia = int(t // 86400 + 4) % 7                      # 0 = domingo
    f.append(math.sin(dia / 7 * 2 * math.pi)); f.append(math.cos(dia / 7 * 2 * math.pi))
    f.append(1.0 if dia in (0, 6) else 0.0)
    otc, divisa, cripto = ia_tipo_par(par)
    f.append(1.0 if otc else 0.0); f.append(1.0 if divisa else 0.0); f.append(1.0 if cripto else 0.0)
    f.append(1.0 if digital else 0.0)
    f.append((tf - 1) / 4.0)                           # temporalidad: 0 = M1 … 1 = M5
    f.append(_ia_lim(((pago or 0.85) - 0.85) * 10))    # payout del par
    f.extend(propio)                                   # cómo le viene yendo en ese par y en ese mercado a esa hora
    f.append(1.0)                                      # sesgo
    return f


def ia_migrar_pesos(w1):
    """Versiones anteriores tenían menos entradas: las nuevas se agregan en cero (no se pierde lo aprendido)."""
    return [fila + [0.0] * (IA_ENTRADAS - len(fila)) if len(fila) < IA_ENTRADAS else fila for fila in w1]


class IARefuerzo:
    """Red pequeña que estima cuánto se gana por dólar con CALL y con PUT, y aprende en línea."""

    def __init__(self, ruta):
        self.ruta = ruta
        self.lock = threading.Lock()
        rnd = __import__("random").Random(7)
        e = 1.0 / math.sqrt(IA_ENTRADAS)
        self.w1 = [[rnd.uniform(-e, e) for _ in range(IA_ENTRADAS)] for _ in range(IA_OCULTAS)]
        self.w2 = [[rnd.uniform(-0.1, 0.1) for _ in range(IA_OCULTAS + 1)] for _ in range(2)]
        self.lr = 0.004
        self.aprendidas = 0                # ejemplos con los que ha aprendido
        self.preentreno = False            # ¿ya hizo el primer entrenamiento con el historial?
        self.tfs_entrenadas = []           # temporalidades con primer entrenamiento hecho
        self.velas_tf = {}                 # temporalidad -> velas M1 por par con las que se entrenó
        self.hist_hecho = []               # temporalidades ya entrenadas con el historial grande (20.000 velas)
        self.sombra = deque(maxlen=IA_SENALES_VENTANA)    # últimas señales evaluadas (True gana / False pierde)
        self.sombra_t = deque(maxlen=IA_SENALES_VENTANA)  # hora de cada una
        self.mejor = {}                                    # cierre -> (lo que esperaba, par, tf): la que cuenta ese minuto
        self.hist_par = {}                                 # par -> últimas 20 decisiones propias (gana / pierde)
        self.hist_ctx = {}                                 # mercado+hora -> últimas 50 decisiones propias
        self.total_senales = 0
        self.activa = False                # False = modo sombra · True = opera
        self.fase = "Esperando"
        self.base_publicado = 0            # de qué publicación del autor viene lo aprendido
        self.ev_prom = None                # lo que espera ganar por dólar en promedio (su mejor opción), últimos cierres
        self.ultima_senal = 0.0            # hora de su última señal
        self.senales_t = deque(maxlen=500) # horas de las señales (para "señales en la última hora")
        self.revisados = 0                 # pares revisados en el último cierre
        self._cierre = None
        self._cuenta = 0
        self.cargar()
        self.tomar_publicada()

    # --- red ---
    def _adelante(self, x):
        oc = []
        for fila in self.w1:
            s = 0.0
            for wi, xi in zip(fila, x):
                s += wi * xi
            oc.append(math.tanh(s))
        oc.append(1.0)
        q = [sum(w * o for w, o in zip(fila, oc)) for fila in self.w2]
        return oc, q

    def q(self, x):
        with self.lock:
            return self._adelante(x)[1]

    def aprender(self, x, r_call, r_put):
        """Un paso: acerca lo que espera ganar a lo que de verdad habría ganado con CALL y con PUT."""
        with self.lock:
            oc, q = self._adelante(x)
            errs = (q[0] - r_call, q[1] - r_put)
            lr = self.lr
            grad_oc = [0.0] * IA_OCULTAS
            for k in range(2):
                e = errs[k]
                fila = self.w2[k]
                for j in range(IA_OCULTAS):
                    grad_oc[j] += e * fila[j]
                for j in range(IA_OCULTAS + 1):
                    fila[j] -= lr * (e * oc[j] + 1e-4 * fila[j])
            for j in range(IA_OCULTAS):
                g = grad_oc[j] * (1 - oc[j] * oc[j])
                if g == 0.0:
                    continue
                fila = self.w1[j]
                for i in range(IA_ENTRADAS):
                    fila[i] -= lr * g * x[i]
            self.aprendidas += 1

    def decidir(self, x):
        """('call'/'put' o None, lo que espera ganar por dólar)."""
        q = self.q(x)
        k = 0 if q[0] >= q[1] else 1
        if q[k] < IA_UMBRAL:
            return None, q[k]
        return ("call" if k == 0 else "put"), q[k]

    # --- modo sombra ---
    def anotar_senal(self, gano, cuando=None):
        """Una señal resuelta (máximo una por minuto). Se activa solo si el acierto está sobre el
        equilibrio con 95 % de seguridad, con 300 señales o más repartidas en al menos 2 horas."""
        with self.lock:
            self.sombra.append(bool(gano))
            self.sombra_t.append(float(cuando or time.time()))
            self.total_senales += 1
            r = self._medida()
            if not self.activa and r["listo"]:
                self.activa = True
                return "activa"
            ult = list(self.sombra)[-IA_SENALES_MIN:]
            if self.activa and len(ult) >= IA_SENALES_MIN and sum(ult) / len(ult) < IA_ACIERTO_APAGAR:
                self.activa = False
                return "sombra"
        return None

    def _medida(self):
        n = len(self.sombra)
        g = sum(self.sombra)
        horas = (self.sombra_t[-1] - self.sombra_t[0]) / 3600.0 if n > 1 else 0.0
        nec = ia_acierto_necesario(n)
        listo = n >= IA_SENALES_MIN and horas >= IA_HORAS_MIN and ia_limite_inferior(g, n) >= IA_EQUILIBRIO
        return {"n": n, "g": g, "horas": horas, "necesita": nec, "listo": listo}

    @staticmethod
    def _ctx(par, t):
        return ("otc" if "OTC" in str(par).upper() else "real") + str(int(t % 86400 // 3600))

    def propio(self, par, t):
        """Su propio historial: cómo le viene yendo en este par y en este mercado a esta hora."""
        hp = self.hist_par.get(par) or ()
        hc = self.hist_ctx.get(self._ctx(par, t)) or ()
        fp = (2 * sum(hp) - len(hp)) / len(hp) if hp else 0.0
        fc = (2 * sum(hc) - len(hc)) / len(hc) if hc else 0.0
        return (fp, len(hp) / 20.0, fc, len(hc) / 50.0)

    def registrar(self, par, t, gano):
        with self.lock:
            self.hist_par.setdefault(par, deque(maxlen=20)).append(bool(gano))
            self.hist_ctx.setdefault(self._ctx(par, t), deque(maxlen=50)).append(bool(gano))

    def mirar(self, cierre, q_mejor, senal):
        """Anota cada revisión (para mostrar qué opina del mercado aunque no marque señales)."""
        with self.lock:
            if cierre != self._cierre:
                if self._cierre is not None:
                    self.revisados = self._cuenta
                self._cierre, self._cuenta = cierre, 0
            self._cuenta += 1
            self.ev_prom = q_mejor if self.ev_prom is None else self.ev_prom * 0.998 + q_mejor * 0.002
            if senal:
                ahora = time.time()
                self.ultima_senal = ahora
                self.senales_t.append(ahora)

    def resumen(self):
        n = len(self.sombra)
        hora = time.time() - 3600
        m = self._medida()
        return {"activa": self.activa, "senales": n, "total": self.total_senales,
                "necesita": round(100 * m["necesita"], 1), "horas": round(m["horas"], 2), "horas_min": IA_HORAS_MIN,
                "acierto": round(100 * sum(self.sombra) / n, 1) if n else None,
                "necesarias": IA_SENALES_MIN, "aprendidas": self.aprendidas,
                "preentreno": self.preentreno, "fase": self.fase, "velas": max(self.velas_tf.values() or [0]),
                "ev": round(self.ev_prom * 100, 1) if self.ev_prom is not None else None,
                "revisados": self.revisados or self._cuenta,
                "ultima_senal": int(self.ultima_senal) or None,
                "senales_hora": sum(1 for t in self.senales_t if t >= hora)}

    # --- guardar / cargar ---
    def guardar(self):
        with self.lock:
            d = {"v": IA_VERSION, "w1": self.w1, "w2": self.w2,
                 "hist_par": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_par.items()},
                 "hist_ctx": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_ctx.items()}, "aprendidas": self.aprendidas, "preentreno": self.preentreno,
                 "sombra": "".join("1" if x else "0" for x in self.sombra), "sombra_t": [int(t) for t in self.sombra_t],
                 "regla": 2, "velas_tf": {str(k): v for k, v in self.velas_tf.items()}, "hist_hecho": self.hist_hecho,
                 "total": self.total_senales,
                 "activa": self.activa, "base_publicado": self.base_publicado,
                 "ev_prom": self.ev_prom, "ultima_senal": self.ultima_senal, "tfs_entrenadas": self.tfs_entrenadas}
        tmp = self.ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        os.replace(tmp, self.ruta)

    def cargar(self):
        try:
            with open(self.ruta, encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                self.total_senales = int(d.get("total", 0) or 0)
                return                                 # IA de otra versión: la autónoma aprende desde cero
            self.w1, self.w2 = d["w1"], d["w2"]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            if d.get("regla") == 2:                    # medición nueva: una por minuto, con su hora
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:                                      # la medición vieja se reinicia (contaba señales repetidas)
                self.activa = False
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = int(d.get("base_publicado", 0) or 0)
            vt = d.get("velas_tf")
            self.velas_tf = {int(k): int(v) for k, v in vt.items()} if isinstance(vt, dict) else (
                {1: 5000} if d.get("preentreno") else {})
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            self.ev_prom = d.get("ev_prom")
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.ultima_senal = float(d.get("ultima_senal") or 0)
        except Exception:
            pass

    def tomar_publicada(self):
        """Si la actualización trae una IA más nueva (entrenada en el PC del autor), se usa esa."""
        try:
            d = (IA_BASE or {}).get(BROKER) or {}
            pub = int(d.get("publicado", 0) or 0)
            if not pub or pub <= self.base_publicado:
                return False
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                return False
            self.w1, self.w2 = d["w1"], d["w2"]
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.sombra.clear(); self.sombra_t.clear()
            if d.get("regla") == 2:
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:
                self.activa = False
            vt = d.get("velas_tf")
            if isinstance(vt, dict):
                self.velas_tf = {int(k): int(v) for k, v in vt.items()}
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = pub
            try:
                self.guardar()
            except Exception:
                pass
            return True
        except Exception:
            return False


def ia_agrupar(m1, tf):
    """Velas M1 -> velas de tf minutos (solo las completas)."""
    if tf == 1:
        return m1
    out, grupo, ini = [], [], None
    for v in m1:
        g = v["t"] - v["t"] % (tf * 60)
        if g != ini:
            if len(grupo) == tf:
                out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                            "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
            grupo, ini = [], g
        grupo.append(v)
    if len(grupo) == tf:
        out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                    "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
    return out


def ia_estado_guardado():
    """Para la pantalla de Configuración (sin bot andando): el estado de la IA del autor."""
    ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
    return ia.resumen()


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = bool(cfg.get("tf_auto"))      # Auto (solo el autor): M1, M2, M3 y M5 a la vez
        # Auto: vigila M1, M2, M3 y M5 a la vez · manual: las temporalidades elegidas
        self.tfs = list(TFS_AUTO) if self.tf_auto else (sorted(set(cfg["temporalidades"]))[:1] or [1])
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal e IA)
        self.ia = None           # IA del autor (solo con estrategia "ia")
        self.ia_pend = {}        # (par, tf) -> decisiones por resolver cuando cierre la vela operada
        self.ia_cola = deque(maxlen=20000)     # ejemplos nuevos para aprender
        self.ia_repaso = deque(maxlen=20000)   # memoria de repaso (refuerzo con repetición de experiencias)
        self.ia_ev = {}                        # (par, tf) -> lo que la IA espera ganar por dólar en este cierre
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.hist = {}           # (par, tf) -> velas
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.prox_cierre = None
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None
        self.estirado_hecho = set()   # bot Bollinger: (par, tf, inicio de vela) ya tomados al estirarse

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más."""
        if self.stop_alcanzado():
            if not self.detener:
                self.detener = True
                self.avisar_stop()
            return True
        return self.detener

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que conviene operar ese par: binaria/turbo o digital, el que mejor pague
        entre los mercados elegidos. (None, None) si no se puede operar."""
        cfg = self.cfg
        tipo = "turbo" if tf <= 5 else "binary"
        opciones = []
        if (cfg["incluir_otc"] if es_otc else cfg["incluir_mercado_real"]) and pays.get(tipo) is not None:
            opciones.append((pays[tipo], tipo))
        if cfg.get("incluir_digital") and tf in (1, 5, 15) and pays.get("digital"):
            opciones.append((pays["digital"], "digital"))
        if not opciones:
            return None, None
        pago, t = max(opciones)
        return t, pago

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=bool(cfg.get("incluir_digital")))
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        if cfg.get("incluir_digital"):
            self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception as e:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre."""
        limite = prox - self.adelanto_analisis() - 1.5
        for par in list(self.seleccion):
            for tf in tfs_c:
                if self.detener or not self.b.conectado or self.b.ahora() > limite:
                    return
                if par in self.pares_en_uso:
                    continue
                k = (par, tf)
                try:
                    hist = self.hist.get(k) or []
                    if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                        self.fase = f"Leyendo {par} M{tf}"
                        velas = self.b.velas(par, tf, HISTORIA_VELAS)
                        if len(velas) < 30:
                            self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); continue
                        self.hist[k] = velas
                        self.hist_t[k] = time.time()
                        if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                                and velas[-1]["t"] >= self.b.ahora() - 180):
                            try:
                                self.vivo_pend[par] = time.time()
                                if not self.b.suscribir_vivo(par, velas):
                                    self.vivo_pend.pop(par, None)
                            except Exception:
                                self.vivo_pend.pop(par, None)
                    elif hist[-1]["t"] < prox - 2 * tf * 60:
                        nuevas = self.b.velas(par, tf, 4)
                        por_t = {v["t"]: v for v in hist}
                        for v in nuevas: por_t[v["t"]] = v
                        self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
                    self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
                except Exception as e:
                    self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def al_estirarse(self):
        """Entrada "al estirarse" (solo Bollinger; para todos)."""
        return self.cfg.get("estrategia", "bollinger") == "bollinger" and self.cfg.get("entrada") == "estirado"

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        if self.al_estirarse():
            return cands, revisados             # "al estirarse": solo entra a mitad de vela (hilo_estirado)
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                if cfg.get("estrategia") == "ia":
                    d, det = self.ia_analizar(par, tf, cerradas, actual, pago, prox, inst)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg)
                    if self.ia is not None:
                        d, det = self.ia_filtrar(par, tf, cerradas, actual, pago, prox, d, det, inst)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre, "detalle": det,
                              "ev": self.ia_ev.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def hilo_estirado(self):
        """Bot Bollinger 'al estirarse': durante la vela mira el precio cada segundo. Si el precio sale de la banda
        y se estira lo pedido, entra YA (mejor precio = margen por si se devuelve) y vence al cierre de la vela
        siguiente, a la misma hora que la entrada normal (máximo 5 minutos, lo que permite el broker)."""
        while not self.detener and not self.terminado:
            time.sleep(1.0)
            try:
                cfg = self.cfg
                if not self.al_estirarse():
                    time.sleep(4); continue
                if not self.b.conectado or self.pausado or self.plan or self.abiertas or self.pares_en_uso:
                    continue                                   # una operación a la vez
                if self.frenar_por_stop():
                    continue
                ahora = self.b.ahora()
                self.entrar_estirado(ahora)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] estirado\n{traceback.format_exc()}")

    def entrar_estirado(self, ahora):
        cfg = self.cfg
        mejores = []
        for par in list(self.seleccion):
            if par in self.pares_en_uso or not self.b.vivo.get(par):
                continue
            if self.descanso.get(par, 0) > time.time():
                continue
            if self.nivel > 0 and par == self.par_perdio:
                continue                                       # el nivel va en otro par
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            pays = self.pares.get(par, {}).get("pays", {})
            ok_m = cfg["incluir_otc"] if par.endswith("-OTC") else cfg["incluir_mercado_real"]
            pago = pays.get("turbo") if ok_m else None
            if pago is None or pago < cfg["payout_minimo"]:
                continue
            for tf in self.tfs:
                inicio = int(ahora) // (tf * 60) * tf * 60
                cierre = inicio + tf * 60
                if cierre - ahora < 2.0 or ahora - inicio < 1.0:
                    continue                                   # pegado al cierre: lo resuelve el ciclo normal
                if (par, tf, inicio) in self.estirado_hecho:
                    continue
                partes = [v for v in m1 if inicio <= v["t"] < cierre]
                if not partes:
                    continue
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get((par, 1), [])}
                    for v in m1:
                        if v["t"] < inicio: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)]
                else:
                    cerradas = [v for v in self.hist.get((par, tf), []) if v["t"] < inicio]
                    if cerradas and cerradas[-1]["t"] == inicio - 2 * tf * 60:
                        ult = self.vela_en_formacion(m1, tf, inicio)     # la vela que acaba de cerrar, con las M1 en vivo
                        if ult:
                            cerradas = cerradas + [ult]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    continue
                d, det = senal([v["c"] for v in cerradas] + [partes[-1]["c"]], cfg, float(cfg.get("estiro", 20) or 0))
                if d:
                    mejores.append((pago, par, tf, inicio, cierre, d, det))
        if not mejores:
            return
        mejores.sort(reverse=True)                             # primero el que más paga
        pago, par, tf, inicio, cierre, d, det = mejores[0]
        expira = cierre + tf * 60
        while expira - ahora > 300:
            expira -= 60                                       # el broker no deja más de 5 minutos
        nivel, ciclo = self.nivel, self.ciclo_perdida
        if nivel > int(cfg["rec_max"]) or cfg["recuperacion"] == "ninguna":
            nivel, ciclo = 0, 0.0
        monto = self.monto_recuperacion(nivel, ciclo, pago)
        if nivel > 0 and not self.puede_arriesgar(monto):
            if not self.puede_arriesgar(self.monto_recuperacion(0, 0.0, pago)):
                return
            self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                     f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
            with self.lock:
                self.nivel, self.ciclo_perdida = 0, 0.0
                self.ciclo_n += 1
            nivel, ciclo = 0, 0.0
            monto = self.monto_recuperacion(0, 0.0, pago)
        if not self.puede_arriesgar(monto):
            return
        self.estirado_hecho.add((par, tf, inicio))
        if len(self.estirado_hecho) > 5000:
            self.estirado_hecho = {k for k in self.estirado_hecho if k[2] > ahora - 3600}
        s = {"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre_estrategia(cfg, True), "inst": "turbo", "inicio_vela": cierre, "disparo": None, "detalle": det,
             "expira": expira, "exp_min": max(1, int(round((expira - ahora) / 60))), "monto": monto,
             "etiqueta": f"NIVEL {nivel}" if nivel else "ENTRADA", "ciclo_n": self.ciclo_n,
             "nivel_usado": nivel, "ciclo_antes": ciclo}
        self.estado(par, f"SEÑAL {d.upper()} M{tf} al estirarse · {det}", "bold green" if d == "call" else "bold red", 1)
        self.lanzar(s)



    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # IA: primero la que más dinero espera (acierto × payout) · Bollinger/RSI: la que más paga
        cands = sorted(cands, key=lambda c: (c.get("ev") if c.get("ev") is not None else -9.0, c.get("payout") or 0.0), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        if self.frenar_por_stop() or self.pausado:
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            elegida = otros[0] if otros else None
            etiqueta = f"NIVEL {nivel}"
        else:
            elegida = lista[0] if lista else None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        self.lanzar(elegida)

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        cfg = self.cfg
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            t_envio = self.b.ahora()
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.avisar_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    self.prox_cierre = prox
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_estirado):
            threading.Thread(target=objetivo, daemon=True).start()
        if self.autor:      # la IA del autor aprende siempre (con IA, Bollinger o RSI) y filtra cuando ya demostró acierto
            threading.Thread(target=self.hilo_ia, daemon=True).start()

    # ---------- IA del autor (refuerzo en línea) ----------
    def ia_segundos(self):
        """(segundos desde el último cierre, segundos hasta el próximo) de la temporalidad elegida."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return t, per - t

    def ia_sin_operar(self):
        """Mientras la IA entrena con estrategia IA, el bot no opera: puede descargar y aprender a toda velocidad."""
        return self.cfg.get("estrategia") == "ia" and getattr(self, "ia_entrenando", False)

    def ia_esperar_ventana(self, margen=8):
        """La IA solo trabaja lejos del cierre: nunca le quita tiempo al análisis ni a las órdenes.
        Si el bot no está operando (IA entrenando), no espera nada."""
        if self.ia_sin_operar():
            return
        while not self.terminado:
            desde, hasta = self.ia_segundos()
            if desde > 5 and hasta > margen:
                return
            time.sleep(0.4)

    @staticmethod
    def ia_recompensas(mov, pago):
        """(premio CALL, premio PUT) por dólar según cómo se movió la vela operada."""
        if mov > 0:
            return pago, -1.0
        if mov < 0:
            return -1.0, pago
        return 0.0, 0.0

    def ia_pago(self, par):
        pays = (self.pares.get(par, {}) or {}).get("pays") or {}
        vals = [v for v in pays.values() if isinstance(v, (int, float)) and v > 0]
        return max(vals) if vals else 0.85

    def ia_descargar(self, par, carpeta):
        """Hasta 20.000 velas M1 del par. Se guardan en ia_velas: solo se baja lo que falta (lo nuevo y lo más viejo)."""
        ruta = os.path.join(carpeta, "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in par) + ".csv")
        velas = {}
        try:
            with open(ruta, encoding="utf-8") as fh:
                for ln in fh:
                    t, o, h, l, c = ln.strip().split(",")
                    velas[int(float(t))] = {"t": int(float(t)), "o": float(o), "h": float(h), "l": float(l), "c": float(c)}
        except Exception:
            velas = {}
        n0 = len(velas)

        def bajar(hasta, falta):
            while falta > 0 and not self.terminado:
                self.ia_esperar_ventana(15)
                bloque = self.b.velas_hasta_t(par, min(1000, falta), hasta)
                if not bloque:
                    return False
                nuevas = 0
                for v in bloque:
                    if int(v["t"]) not in velas:
                        nuevas += 1
                    velas[int(v["t"])] = {"t": int(v["t"]), "o": v["o"], "h": v["h"], "l": v["l"], "c": v["c"]}
                falta -= len(bloque)
                hasta = bloque[0]["t"] - 1
                time.sleep(0.08 if self.ia_sin_operar() else 0.25)
                if nuevas == 0:
                    return False
            return True

        ahora = self.b.ahora()
        if velas:
            ult = max(velas)
            if ahora - ult > 120:                                   # lo nuevo desde la última vez
                bajar(ahora, min(IA_VELAS_DESCARGA, int((ahora - ult) / 60) + 5))
            if len(velas) < IA_VELAS_DESCARGA * 0.95:               # lo más viejo, hasta completar
                bajar(min(velas) - 1, IA_VELAS_DESCARGA - len(velas))
        else:
            bajar(ahora, IA_VELAS_DESCARGA)
        if len(velas) != n0:
            lista = [velas[t] for t in sorted(velas)][-(IA_VELAS_DESCARGA + 1000):]
            try:
                with open(ruta, "w", encoding="utf-8") as fh:
                    fh.write("".join(f"{v['t']},{v['o']},{v['h']},{v['l']},{v['c']}\n" for v in lista))
            except Exception:
                pass
        return [velas[t] for t in sorted(velas)][-IA_VELAS_DESCARGA:]

    def ia_preentrenar(self, tf=None):
        """Entrenamiento con el historial de una temporalidad: baja hasta 20.000 velas M1 de cada par y aprende."""
        ia = self.ia
        self.ia_entrenando = True                 # con estrategia IA: no opera hasta terminar (descarga rápida)
        try:
            return self._ia_preentrenar(tf)
        finally:
            self.ia_entrenando = False

    def _ia_preentrenar(self, tf=None):
        ia = self.ia
        carpeta = os.path.join(DATOS_BROKER, IA_CARPETA_VELAS)
        os.makedirs(carpeta, exist_ok=True)
        ia.fase = "Esperando la lista de pares"
        while not self.terminado and not self.seleccion:
            time.sleep(2)
        tf = tf or (self.tfs[0] if self.tfs else 1)
        pares = list(self.seleccion)
        self.log(f"🤖 IA: entrenamiento M{tf} con hasta {IA_VELAS_DESCARGA:,} velas M1 de {len(pares)} pares (en segundo plano).", "bold")
        ejemplos = 0
        velas_max = 0
        for i, par in enumerate(pares):
            if self.terminado:
                return
            ia.fase = f"M{tf}: descargando y aprendiendo {i + 1}/{len(pares)}"
            try:
                m1 = self.ia_descargar(par, carpeta)
                velas_max = max(velas_max, len(m1))
                velas = ia_agrupar(m1, tf)
            except Exception:
                continue
            pago = self.ia_pago(par)
            for j in range(60, len(velas) - 1):
                if j % 150 == 0:
                    self.ia_esperar_ventana()
                    if self.terminado:
                        return
                if velas[j + 1]["t"] - velas[j]["t"] != tf * 60:
                    continue
                tramo = velas[j - 59 if j >= 59 else 0: j + 1]
                t_ = velas[j]["t"] + tf * 60
                x = ia_rasgos(tramo, par, pago, t_, tf, False, ia.propio(par, t_))
                if x is None:
                    continue
                mov = velas[j + 1]["c"] - velas[j]["c"]
                q_ = ia.q(x)
                k_ = 0 if q_[0] >= q_[1] else 1
                if q_[k_] >= IA_UMBRAL and mov != 0:           # su propio historial, como en vivo
                    ia.registrar(par, t_, (mov > 0) == (k_ == 0))
                rc, rp = self.ia_recompensas(mov, pago)
                ia.aprender(x, rc, rp)
                ejemplos += 1
        ia.preentreno = True
        if tf not in ia.tfs_entrenadas:
            ia.tfs_entrenadas.append(tf)
        ia.velas_tf[tf] = velas_max or ia.velas_tf.get(tf, 0)
        if tf not in ia.hist_hecho:
            ia.hist_hecho.append(tf)           # hecho hasta donde el bróker deja: no se repite en cada inicio
        ia.fase = "Aprendiendo en vivo"
        ia.guardar()
        self.log(f"🤖 IA: entrenamiento M{tf} listo ({ejemplos:,} ejemplos). Sigue aprendiendo en vivo.", "bold")

    def hilo_ia(self):
        try:
            self.ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
        except Exception as e:
            self.log(f"🤖 IA: no se pudo iniciar ({e}).", "red")
            return
        ia = self.ia
        estado = "opera" if ia.activa else "modo sombra"
        self.log(f"🤖 IA lista ({estado} · {ia.aprendidas:,} ejemplos aprendidos).", "bold")
        for tf_ in list(self.tfs):                       # cada temporalidad: entrenamiento con el historial (una vez)
            if tf_ in ia.hist_hecho or self.terminado:
                continue
            try:
                self.ia_preentrenar(tf_)
            except Exception as e:
                self.log(f"🤖 IA: el primer entrenamiento M{tf_} se cortó ({str(e)[:60]}); sigue aprendiendo en vivo.", "yellow")
        ia.fase = "Aprendiendo en vivo"
        rnd = __import__("random").Random()
        guardado = time.time()
        while not self.terminado:
            hechos = 0
            while self.ia_cola and hechos < 300:
                desde, hasta = self.ia_segundos()
                if hasta < 8 or desde < 4:
                    break
                x, rc, rp = self.ia_cola.popleft()
                ia.aprender(x, rc, rp)
                self.ia_repaso.append((x, rc, rp))
                if len(self.ia_repaso) > 200:                 # repasa una experiencia vieja al azar
                    ia.aprender(*self.ia_repaso[rnd.randrange(len(self.ia_repaso))])
                hechos += 1
            if time.time() - guardado > 300:
                try: ia.guardar()
                except Exception: pass
                guardado = time.time()
            time.sleep(0.2 if hechos else 1.0)
        try: ia.guardar()
        except Exception: pass

    def ia_procesar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """En cada cierre: resuelve lo pendiente (aprende de lo que pasó) y da la opinión de la IA.
        Devuelve (dirección de la IA o None, lo que espera ganar, [espera con CALL, espera con PUT])."""
        ia = self.ia
        pago = pago or self.ia_pago(par)
        pend = self.ia_pend.setdefault((par, tf), deque(maxlen=3))
        if pend:
            por_t = {v["t"]: v for v in cerradas[-4:]}
            for p_ in list(pend):
                v = por_t.get(p_["t_op"])
                if v is None:
                    continue
                pend.remove(p_)
                mov = v["c"] - p_["precio"]
                self.ia_cola.append((p_["x"],) + self.ia_recompensas(mov, p_["pago"]))
                if p_["d"] and mov != 0:
                    ia.registrar(par, p_["t_op"], (mov > 0) == (p_["d"] == "call"))
                m_ = ia.mejor.get(p_["t_op"])
                if p_["d"] and mov != 0 and m_ and m_[1] == par and m_[2] == tf:     # una sola por minuto
                    cambio = ia.anotar_senal((mov > 0) == (p_["d"] == "call"), p_["t_op"])
                    r = ia.resumen()
                    if cambio == "activa":
                        self.log(f"🤖 IA: acierto real {r['acierto']} % en {r['senales']} señales y {r['horas']:.1f} h "
                                 f"(necesitaba {r['necesita']} %) → "
                                 + ("EMPIEZA A OPERAR." if self.cfg.get("estrategia") == "ia" else "empieza a FILTRAR las señales."), "bold green")
                    elif cambio == "sombra":
                        self.log(f"🤖 IA: el acierto bajó a {r['acierto']} % → vuelve a modo sombra.", "bold yellow")
        x = ia_rasgos(cerradas[-59:] + [actual], par, pago, prox, tf, inst == "digital", ia.propio(par, prox))
        if x is None:
            return None, 0.0, None
        q = ia.q(x)
        k = 0 if q[0] >= q[1] else 1
        d = ("call" if k == 0 else "put") if q[k] >= IA_UMBRAL else None
        ia.mirar(prox, q[k], d)
        if d:
            with ia.lock:
                if q[k] > ia.mejor.get(prox, (-9.0,))[0]:
                    ia.mejor[prox] = (q[k], par, tf)
                if len(ia.mejor) > 30:
                    for k_ in sorted(ia.mejor)[:-10]:
                        ia.mejor.pop(k_, None)
        pend.append({"x": x, "precio": actual["c"], "t_op": prox, "pago": pago, "d": d})
        return d, q[k], q

    def ia_analizar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """Estrategia IA: la decisión es de la IA. En modo sombra no opera."""
        if self.ia is None:
            return None, ""
        d, ev, _ = self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        self.ia_ev[(par, tf)] = ev
        if not d:
            return None, ""
        det = f"IA espera +{ev * 100:.0f}¢ por dólar"
        forzar = bool(self.cfg.get("ia_forzar")) and self.autor          # decisión del autor: opera sin el umbral
        if getattr(self, "ia_entrenando", False) or not (self.ia.activa or forzar):     # entrenando o en sombra: no opera
            self.estado(par, f"IA (sombra) {d.upper()} M{tf} · {det}", "yellow", 2)
            return None, ""
        return d, det

    def ia_filtrar(self, par, tf, cerradas, actual, pago, prox, d, det, inst=None):
        """Bollinger/RSI del autor: la IA aprende de cada señal y, cuando ya demostró acierto, la filtra."""
        try:
            _, _, q = self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        except Exception:
            return d, det
        if not d or q is None or not self.ia.activa:
            return d, det
        qd = q[0] if d == "call" else q[1]
        if qd <= 0:
            self.log(f"🤖 IA filtró la señal {d.upper()} de {par} M{tf}: espera {qd * 100:+.0f}¢ por dólar.", "yellow")
            self.estado(par, f"M{tf}: señal filtrada por la IA", "dim", 3)
            return None, ""
        return d, det + f" · IA de acuerdo (+{qd * 100:.0f}¢)"

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bollinger")},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "ia": dict(self.ia.resumen(), forzar=bool(cfg.get("ia_forzar")) and self.autor) if self.ia else None,
        }

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [1]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = bool(cfg.get("tf_auto"))    # Auto solo lo puede usar el autor (app_gui lo revisa al iniciar)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    if cfg.get("estrategia") not in ("bollinger", "rsi", "ia"):
        cfg["estrategia"] = "bollinger"
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

