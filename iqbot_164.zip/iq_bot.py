# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "1.0"
BUILD_BOT = 164

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": False,      # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT 3.0",
    "subtitulo": "Más simple, más liviano y tú eliges la estrategia",
    "items": [
        ["📊", "Bandas de Bollinger", "Son dos líneas alrededor del precio (promedio de 20 velas ± 2 desviaciones). Cuando el precio sale por arriba, el bot entra PUT; cuando sale por abajo, CALL, esperando que regrese."],
        ["📈", "RSI", "Mide la fuerza del movimiento de 0 a 100. Con periodo 2 y niveles 60/40: si cruza hacia arriba el 60 la señal es CALL; si cruza hacia abajo el 40, PUT. Si quieres apostar a que el precio se devuelve, cámbialo a dirección invertida: al cruzar el 60 entra PUT y al cruzar el 40 entra CALL."],
        ["⚙️", "Cómo usarlas", "En Configuración → Estrategia elige Bollinger o RSI. Si no estás seguro, deja los valores que trae. Prueba primero en DEMO y usa pocas recuperaciones."],
        ["🪜", "Recuperación por niveles", "Si una entrada pierde, el bot espera la siguiente señal en otro par. Ya no hace gale ni cambia de dirección."],
        ["🎯", "Bollinger al estirarse", "Con Bollinger puedes elegir la entrada: al cierre de la vela o al estirarse (entra apenas el precio se sale de la banda el % que pongas, sin esperar el cierre)."],
        ["⏱️", "Temporalidad en minutos", "Ahora es un solo campo: pones de 1 a 5 minutos con los botones − y +. Viene en 1 minuto."],
        ["🌎", "Todos los pares", "Vigila OTC, digital y mercado real, y solo entra en pares que paguen 80 % o más."],
    ],
    "aviso": "Operar tiene riesgo alto de pérdida. Ninguna estrategia gana siempre ni garantiza resultados.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [1],           # manual: las que elija (1, 2, 3 y/o 5 minutos)
    "tf_auto": False,                # 3.0: ya no hay Auto; una sola temporalidad de 1 a 5 minutos
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "incluir_digital": True,         # también opciones digitales (se usa la que mejor pague)
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 5,                   # 3.0: estrategia única · 4: RSI normal · 5: temporalidad en minutos
    # estrategia (3.0)
    "estrategia": "bollinger",       # "bollinger" o "rsi"
    "bb_periodo": 20,
    "bb_desv": 2.0,
    "rsi_periodo": 2,
    "rsi_alto": 60.0,
    "rsi_bajo": 40.0,
    "rsi_direccion": "normal",       # "normal" o "invertida" (el cliente la invierte si quiere)
    "entrada": "cierre",             # "cierre" o "estirado" (al estirarse, solo Bollinger)
    "ia_forzar": False,              # solo el autor: la IA opera aunque no pase el umbral (DEMO o REAL, decisión del autor)
    "estiro": 20.0,                  # al estirarse: % del ancho de las bandas que el precio debe pasar la banda
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        respuestas[c] = r
        if r == "VALID":
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas (la librería tiene un solo buzón para velas)
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        try:
            ok, motivo = con_timeout(api.connect, 60)
        except TimeoutError:
            return None, ("IQ Option no respondió. Revisa tu internet; si estás en una red que "
                          "bloquea IQ Option (trabajo, universidad, operador), prueba otra red.")
        except json.JSONDecodeError as e:
            crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
            return None, ("IQ Option devolvió una respuesta inesperada al iniciar sesión "
                          "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                          "navegador para confirmar que tu cuenta abre bien."
                          + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
        except Exception as e:
            if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                return None, ("No se pudo verificar la conexión segura con IQ Option (certificado no válido). "
                              "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                              "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
            libreria_conecto(False, culpa_de_libreria=True)
            return None, f"Error de conexión: {e}"
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        if not getattr(self, "_campos_saldo_vistos", False):     # una vez: deja anotados los campos que manda IQ Option
            self._campos_saldo_vistos = True
            try:
                for bal in raw.get("msg", []):
                    if bal.get("type") == 1:
                        campos = {k: v for k, v in bal.items() if isinstance(v, (int, float)) and k not in ("id", "user_id", "type", "tournament_id")}
                        with open(os.path.join(DATOS, "campos_saldo.log"), "w", encoding="utf-8") as f:
                            f.write(json.dumps(campos, ensure_ascii=False))
            except Exception:
                pass
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def campos_saldo(self):
        """Campos numéricos que manda IQ Option de cada cuenta (para el diagnóstico)."""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05) or {}
        out = []
        for bal in raw.get("msg", []):
            out.append({k: v for k, v in bal.items() if k not in ("id", "user_id") and not isinstance(v, (dict, list))})
        return out

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock:                       # la librería tiene un solo "buzón" para velas
            inner.candles.candles_data = None
            inner.getcandles(aid, tf_min * 60, cantidad + 1, time.time())
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def velas_rapidas(self, par, cantidad, hasta):
        """Como velas_hasta_t pero con número de pedido propio: se pueden pedir 2 pares a la vez."""
        if getattr(self, "_rid_ok", None) is False:
            return self.velas_hasta_t(par, cantidad, hasta)
        aid = self._id(par)
        if aid is None:
            return []
        inner = self.inner
        buzon = getattr(inner, "_iqbot_velas", None)
        if buzon is None:
            buzon = inner._iqbot_velas = {}
        with self.lock:
            self._rid_n = getattr(self, "_rid_n", 0) + 1
            rid = f"iqv{self._rid_n}"
        datos = {"name": "get-candles", "version": "2.0",
                 "body": {"active_id": int(aid), "split_normalization": True, "size": 60,
                          "to": int(hasta), "count": int(cantidad), "": int(aid)}}
        inner.send_websocket_request("sendMessage", datos, request_id=rid)
        raw = _esperar(lambda: buzon.get(rid), 6)
        buzon.pop(rid, None)
        if raw is None:
            if getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: modo normal
                return self.velas_hasta_t(par, cantidad, hasta)
            return []
        self._rid_ok = True
        ahora = self.ahora()
        return [{"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]}
                for v in raw if v["from"] + 60 <= ahora]

    def velas_hasta_t(self, par, cantidad, hasta):
        """v3: velas M1 CERRADAS que terminan en 'hasta' (para completar la memoria hacia atrás o hacia adelante)."""
        aid = self._id(par)
        if aid is None:
            return []
        inner = self.inner
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, int(cantidad), float(hasta))
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if not raw:
            return []
        ahora = self.ahora()
        return [{"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]}
                for v in raw if v["from"] + 60 <= ahora]

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos (un solo campo de 1 a 5)
TFS_AUTO = (1, 2, 3, 4, 5)                   # temporalidad Auto (solo el autor, en pruebas): M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real)."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


def senal(cierres, cfg, estiro=None):
    """(dirección o None, texto). 'cierres' termina con el precio de la vela de señal.
    estiro: solo Bollinger "al estirarse" (% del ancho de las bandas que el precio debe pasar la banda)."""
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres[-(per * 12 + 2):], per)
        if len(serie) < 2:
            return None, ""
        antes, ahora = serie[-2], serie[-1]
        alto, bajo = float(cfg.get("rsi_alto", 60)), float(cfg.get("rsi_bajo", 40))
        d, txt = None, ""
        if antes < alto <= ahora:
            d, txt = "call", f"RSI cruzó hacia arriba {alto:g}"
        elif antes > bajo >= ahora:
            d, txt = "put", f"RSI cruzó hacia abajo {bajo:g}"
        if d and cfg.get("rsi_direccion") == "invertida":
            d = "call" if d == "put" else "put"
            txt += " (invertida)"
        return d, txt
    per = max(2, int(cfg.get("bb_periodo") or 20))
    k = float(cfg.get("bb_desv") or 2)
    b = bandas(cierres, per, k)
    if not b:
        return None, ""
    arriba, _m, abajo = b
    extra = 0.0 if estiro is None else (arriba - abajo) * float(estiro) / 100.0
    c = cierres[-1]
    if c > arriba + extra:
        return "put", (f"estirado {100 * (c - arriba) / (arriba - abajo):.0f}% sobre la banda de arriba"
                       if estiro is not None else "sobre la banda de arriba")
    if c < abajo - extra:
        return "call", (f"estirado {100 * (abajo - c) / (arriba - abajo):.0f}% bajo la banda de abajo"
                        if estiro is not None else "bajo la banda de abajo")
    return None, ""


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "ia":
        return "IA (aprende sola)"
    if cfg.get("estrategia") == "rsi":
        inv = " invertida" if cfg.get("rsi_direccion") == "invertida" else ""
        return f"RSI {int(cfg.get('rsi_periodo') or 2)} ({cfg.get('rsi_alto', 60):g}/{cfg.get('rsi_bajo', 40):g}){inv}"
    t = f" al estirarse {float(cfg.get('estiro', 20)):g}%" if cfg.get("entrada") == "estirado" else ""
    return f"Bollinger {int(cfg.get('bb_periodo') or 20)},{float(cfg.get('bb_desv') or 2):g}{t}"


def indicador_grafico(velas, cfg):
    """Para dibujar la estrategia en el gráfico de la operación: valores alineados con 'velas' (las previas)."""
    cierres = [v["c"] for v in velas]
    n = len(cierres)
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres, per)
        vals = [None] * (n - len(serie)) + [round(x, 1) for x in serie]
        return {"tipo": "rsi", "vals": vals, "alto": float(cfg.get("rsi_alto", 60)), "bajo": float(cfg.get("rsi_bajo", 40))}
    per = max(2, int(cfg.get("bb_periodo") or 20)); k = float(cfg.get("bb_desv") or 2)
    sup, med, inf = [], [], []
    for i in range(n):
        b = bandas(cierres[:i + 1], per, k)
        sup.append(round(b[0], 6) if b else None); med.append(round(b[1], 6) if b else None)
        inf.append(round(b[2], 6) if b else None)
    return {"tipo": "bb", "sup": sup, "med": med, "inf": inf}



# =====================================================================
#  IA DEL AUTOR (3.0): aprendizaje por refuerzo EN LÍNEA, en código propio (sin librerías: PC y celular).
#  En binarias cada decisión dura una vela: al cerrar se sabe cuánto habría pagado CALL y cuánto PUT,
#  así que aprende de TODOS los pares en cada cierre, opere o no (premio = pago del par, castigo = −1).
#  Red pequeña: ~34 datos de entrada -> 16 neuronas -> 2 salidas (lo que espera ganar con CALL y con PUT).
#  Empieza en MODO SOMBRA (decide sin operar) y solo opera cuando su acierto real pasa del 55 % en 300 señales.
#  Solo la ven y la usan las cuentas del autor.
# =====================================================================
IA_ARCHIVO = "ia_refuerzo.json"
IA_CARPETA_VELAS = "ia_velas"
IA_VELAS_DESCARGA = 20000         # velas M1 por par para el primer entrenamiento (≈ 2 semanas)
IA_SENALES_MIN = 300              # señales en sombra antes de poder operar (máximo una por minuto)
IA_SENALES_VENTANA = 1000         # se mide con las últimas 1.000 señales
IA_HORAS_MIN = 2.0                # y repartidas en al menos 2 horas
IA_EQUILIBRIO = 1 / 1.85          # acierto que no pierde ni gana con pago de 85 % (≈ 54 %)
IA_Z = 1.645                      # 95 % de seguridad (una cola)
IA_ACIERTO_APAGAR = 0.53          # si opera y baja de esto en las últimas 300, vuelve a modo sombra


def ia_limite_inferior(g, n, z=IA_Z):
    """Límite inferior de Wilson: el acierto mínimo que se puede asegurar con 95 % de confianza."""
    if n <= 0:
        return 0.0
    p = g / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - r) / d


def ia_acierto_necesario(n):
    """Con n señales, qué acierto hace falta para estar sobre el equilibrio con 95 % de seguridad."""
    n = max(int(n), IA_SENALES_MIN)
    for k in range(int(n * IA_EQUILIBRIO), n + 1):
        if ia_limite_inferior(k, n) >= IA_EQUILIBRIO:
            return k / n
    return 1.0
IA_UMBRAL = 0.04                  # entra solo si espera ganar más de 4 centavos por dólar
IA_VERSION = 2                    # 2 = IA autónoma: solo velas crudas y contexto (sin indicadores ni estrategias)
IA_OCULTAS = 24
IA_VELAS_VE = 20                  # velas que ve completas (cuerpo y mechas)
IA_ENTRADAS = IA_VELAS_VE * 3 + 19
# Lo aprendido en el PC del autor viaja con cada actualización (lo escribe PUBLICAR_ACTUALIZACION en la línea de abajo).
# Al abrir, el equipo del autor toma esta IA si es más nueva que la suya. (Para los clientes la IA está apagada.)
IA_BASE = {'exnova': {'v': 2, 'w1': [[-0.023025, -0.020982, -0.0184, -0.030048, 0.026212, -0.022771, 0.049342, -0.016033, -0.020733, 0.011233, 0.065211, -0.01151, 0.052515, -0.062783, 0.040025, 0.112794, 0.161333, -0.010108, -0.027106, -0.02339, -0.08929, -0.043056, 0.04386, 0.03037, -0.080252, -0.027599, -0.081759, 0.067923, -0.09933, 0.027582, 0.048601, -0.019363, 0.027298, 0.05748, 0.027702, 0.019747, -0.008386, -0.010071, -0.022003, -0.042192, -0.075571, 0.033811, 0.005278, 0.185702, 0.036013, -0.036173, -0.086196, 0.066127, -0.002748, -0.051613, 0.018121, 0.007265, 0.049211, 0.000572, -0.108346, 0.12655, -0.186048, -0.018756, -0.046854, 0.042252, 0.119252, -0.111742, -0.077994, 0.211944, 0.040269, 0.022084, 0.033241, -0.002407, -0.02119, -0.017836, -0.005442, -0.029875, 0.039582, 0.110955, 0.052454, -0.054618, 0.043445, -0.029337, -0.009299], [-0.0071, 0.030315, -0.003238, 0.043079, -0.033777, -0.096754, 0.011538, -0.014982, 0.076724, 0.009632, -0.014985, 0.051074, -0.081957, 0.080567, 0.009028, -0.054529, 0.073923, -0.032857, 0.010086, 0.083348, -0.024498, 0.060667, -0.099265, 0.009062, -0.00726, 0.021171, -0.050466, -0.085478, -0.033248, -0.062378, 0.060359, 0.055247, 0.039372, 0.058254, 0.092941, 0.057796, -0.021447, 0.033052, 0.108107, 0.07024, 0.108642, -0.04655, 0.040417, 0.056431, -0.125952, -0.080819, -0.034543, -0.031951, -0.071899, 0.052379, -0.052291, -0.162099, -0.067872, 0.123293, -0.08272, -0.096076, -0.02493, -0.094571, -0.049242, -0.080648, 0.160716, 0.039283, -0.1212, 0.094112, 0.055214, -0.046333, -0.008724, 0.001627, 0.023256, 0.017215, -0.01064, 0.074171, -0.030269, -0.107312, 0.100709, 0.008627, -0.056827, -0.040617, -0.075029], [-0.01715, 0.061655, 0.089717, 0.048267, 0.004158, 0.001563, 0.085869, -0.118061, 0.04308, -0.020769, 0.072705, 0.017895, 0.058434, 0.035981, -0.043229, -0.018911, -0.00442, 0.149669, 0.032066, -0.003304, -0.056376, 0.05427, -0.133856, -0.013289, 0.06943, 0.101675, 0.059085, -0.000724, 0.089295, -0.064962, 0.033258, -0.108578, 0.034429, -0.05698, -0.036337, -0.017256, 0.084806, 0.085322, 0.044292, 0.019174, 0.095068, -0.129434, -0.099823, 0.070412, -0.044909, 0.067734, 0.044873, 0.032097, -0.027296, 0.048336, -0.043833, -0.143993, -0.062671, 0.133641, -0.101428, 0.035361, 0.044471, 0.00825, -0.181725, -0.079328, 0.071705, -0.089013, -0.0523, 0.174481, 0.086373, 0.029113, 0.036696, -0.009104, -0.02343, -0.066185, 0.020344, 0.002054, -0.017514, 0.097573, -0.051292, 0.059069, -0.070891, -0.050723, 0.005459], [0.0234, 0.062704, -0.007356, 0.026582, 0.005979, -0.00817, -0.01121, -0.09077, -0.007595, 0.008251, 0.118285, 0.028123, 0.028758, -0.062174, 0.010834, -0.015992, -0.03522, 0.020725, 0.055789, -0.137274, -0.022216, -0.126171, -0.010961, 0.051251, -0.04557, 0.017237, 0.0573, 0.073058, -0.066596, -0.100775, 0.060331, 0.037771, 0.000222, 0.080362, -0.065667, -0.04029, -0.002483, 0.079796, -0.031758, 0.0958, -0.011124, 0.023486, 0.020614, 0.11226, -0.059967, 0.018447, -0.040453, 0.070571, 0.007487, 0.009228, 0.024219, -0.099171, 0.145804, 0.123052, -0.051664, 0.004686, -0.011771, -0.033286, -0.240392, 0.235216, 0.199005, -0.044236, -0.101137, 0.117995, 0.004705, 0.014098, 0.004483, 0.007873, -0.044644, -0.017972, 0.028908, 0.057224, -0.08636, 0.11023, 0.024315, -0.093816, -0.038053, -0.018332, -0.00269], [0.028771, -0.069801, -0.032671, 0.006189, -0.020278, 0.027265, -0.001752, 0.127628, -0.114937, -0.027603, -0.013925, 0.037498, 0.028844, 0.049626, -0.035968, -0.08833, 0.008694, 0.046737, -0.013305, 0.016259, -0.01511, -0.089144, 0.131113, 0.039313, -0.062004, 0.162567, 0.018657, -0.027868, -0.113773, 0.006065, 0.054903, -0.024206, -0.082156, -0.045299, -0.077924, 0.102674, 0.011479, 0.110943, -0.162135, 0.076789, -0.074676, 0.002237, -0.033461, 0.014076, -0.024746, 0.007926, -0.020642, -0.068988, -0.029026, 0.004523, -0.067865, -0.066306, 0.026839, -0.031737, -0.028121, -0.026277, 0.072765, -0.005656, -0.095701, 0.041431, 0.068808, -0.067657, 0.093407, -0.051904, 0.031848, -0.060675, -0.010661, 0.017046, 0.042428, 0.001232, 0.034569, 0.036037, 0.037342, 0.001504, 0.000151, 0.125497, 0.009581, 0.037805, -0.045915], [-0.002466, 0.05475, 0.186263, 0.060257, -0.063755, 0.087043, -0.015267, -0.03415, -0.011942, -0.007611, 0.052719, 0.108537, -0.035174, -0.03278, 0.109382, -0.023845, 0.048274, 0.065332, 0.090286, -0.038244, 0.143925, 0.003341, 0.031768, -0.160197, -0.007573, 0.006994, 0.023123, -0.002849, 0.045857, -0.037107, 0.012318, 0.088731, -0.043156, 0.05235, -0.086119, -0.056164, -0.008827, -0.083743, -0.040042, 0.029036, -0.02066, 0.008457, 0.055089, -0.059421, 0.017241, -0.021852, 0.006266, -0.066276, -0.063665, 0.011666, 0.030104, 0.047637, 0.124919, -0.126387, 0.066909, -0.05496, 0.095126, 0.059607, 0.053417, -0.199615, -0.057447, 0.002416, -0.041957, 0.026417, 0.037191, -0.004059, 0.010083, -0.012509, 0.002135, -0.023749, -0.035724, 0.051753, -0.085491, -0.088901, 0.045245, 0.003843, 0.008228, -0.003705, 0.072437], [-0.048971, -0.188827, 0.011784, 0.018059, -0.026983, 0.061358, 0.005972, 0.027199, -0.019971, -0.004388, 0.011402, 0.049624, 0.05128, 0.02099, -0.038859, 0.002999, -0.018017, -0.006404, 0.034079, 0.127501, 0.002891, -0.116783, 0.037825, 0.123598, 0.011719, 0.075293, -0.024, -0.007854, 0.070958, 0.035059, 0.070173, -0.012064, -0.098028, 0.014899, 0.019548, -0.012772, 0.126594, 0.028013, 0.027784, 0.022505, -0.106829, 0.06089, -0.03389, 0.044809, -0.104333, 0.064564, -0.004918, 0.139752, 0.014293, -0.024757, -0.024111, -0.107837, -0.013717, 0.034255, -0.240395, 0.036148, -0.112948, -0.094637, -0.001087, 0.0, 0.309577, -0.142573, 0.036721, 0.052009, 0.0046, 0.052078, -0.039741, -0.007008, -0.029671, 0.012496, 0.028193, -0.01118, -0.050695, 0.076558, -0.103594, 0.052876, -0.01647, -0.006406, 0.133508], [-0.012955, 0.016559, -0.061685, 0.014396, 0.039821, -0.030397, -0.051822, 0.08154, -0.038745, -0.016108, -0.111135, 0.024013, 0.016071, -0.022303, 0.073295, -0.070859, 0.042758, -0.019541, 0.003589, -0.065939, 0.063286, -0.032736, 0.05425, -0.085965, 0.000277, 0.014698, -0.035363, -0.067069, -0.015911, 0.028473, 0.043313, 0.159916, 0.084024, -0.09212, -0.060642, -0.151746, -0.059391, -0.004352, 0.032258, 0.065361, 0.111696, -0.065037, -0.006264, 0.011887, -0.059732, -0.082274, 0.038439, -0.095684, -0.169963, 0.008765, 0.041448, 2e-06, 0.18934, 0.043126, 0.070196, -0.17198, 0.041715, 0.105115, 0.010413, 0.044715, -0.178703, 0.10311, 0.024164, 0.007191, -0.008464, -0.018502, 0.007596, 0.0385, 0.008446, 0.014935, -0.006053, 0.058821, -0.105593, 0.105237, -0.136011, -0.012964, -0.063693, 0.049946, -0.044614], [0.023828, -0.110478, -0.034576, -0.076382, 0.043081, 0.019902, -0.030323, -0.074205, -0.132602, -0.064321, 0.095526, -0.025819, 0.097889, 0.070491, -0.063638, -0.006177, 0.012948, 0.044739, 0.033585, -0.050145, -0.016305, -0.0324, 0.053896, -0.024628, 0.027608, -0.06815, -0.071072, 0.100042, -0.008018, 0.117329, 0.028776, 0.049821, 0.072836, -0.014513, -0.002302, -0.051087, -0.085023, -0.108202, -0.031011, -0.077709, 0.034587, -0.130024, -0.035002, 0.084811, 0.044249, -0.035132, 0.036511, -0.080148, -0.024694, -0.053862, 0.159817, 0.073917, 0.117761, -0.019079, -0.002786, -0.037054, 0.0887, 0.10588, 0.046751, -0.155417, -0.124639, 0.084544, 0.06538, -0.042117, 0.03033, 0.026547, -0.041866, -0.034133, -0.00467, -0.046029, 0.00919, 0.046318, 0.000733, 0.053808, 0.025207, -0.057847, 0.068116, 0.050464, 0.050464], [0.023217, 0.074639, -0.097306, -0.008513, 0.084347, -0.004557, -0.034876, 0.120802, -0.015782, -0.061712, 0.019419, 0.068034, -0.028191, 0.042937, 0.080111, 0.047299, -0.075115, -0.154277, -0.039595, 0.037169, 0.074713, 0.071397, 0.110375, -0.0283, -0.062973, -0.066484, 0.050749, 0.092463, -0.074734, 0.061656, 0.058241, 0.113813, 0.00792, 0.008966, -0.068018, -0.053285, -0.111563, 0.004296, -0.013275, -0.083469, 0.010249, 0.077578, 0.038774, 0.097235, 0.104757, -0.039634, -0.030942, 0.099161, -0.051079, -0.05672, -0.102464, -0.059369, 0.005128, -0.024941, -0.043144, 0.076705, -0.115489, -0.028456, -0.149684, 0.242032, 0.014784, -0.018684, 0.005001, 0.139402, -0.038914, -0.008078, 0.055477, 0.005969, -0.010892, 0.003591, -0.072816, 0.000857, -0.185082, 0.093711, 0.030163, 0.081178, -0.125748, 0.010095, -0.067197], [-0.042458, 0.048869, -0.010676, -0.01969, -0.059106, 0.043223, -0.007386, -0.016565, 0.01226, -0.048054, 0.0636, 0.024674, 0.048376, 0.00367, -0.032252, -0.009873, 0.066718, 0.050227, -0.034637, 0.022355, 0.045598, -0.014214, 0.074854, -0.004706, -0.046081, 0.139826, 0.02107, -0.059972, -0.031819, -0.09753, 0.080683, 0.022833, 0.044034, 0.012745, -0.027623, -0.008223, 0.039703, -0.151688, -0.069631, -0.012339, -0.103516, -0.06112, -0.013829, 0.039168, 0.051913, -0.003475, 0.040313, -0.046088, 0.048754, 0.039486, -0.149077, -0.109014, -0.08882, -0.022722, -0.151872, 0.042736, -0.070299, -0.17851, 0.044944, -0.039159, 0.300201, -0.121552, 0.031817, 0.139881, 0.041247, 0.024383, 0.043717, -0.011986, 0.036974, -0.030689, -0.031112, -0.013421, -0.022313, -0.028749, 0.061416, -0.018657, 0.040715, -0.00145, 0.102973], [-0.053016, 0.021556, -0.102145, -0.025025, 0.015089, -0.022697, 0.032148, 0.028197, 0.006838, -0.044269, -0.020786, -0.010252, 0.101627, -0.07079, -0.024202, 0.109865, -0.007916, 0.108021, -0.069535, -0.002795, -0.027544, -0.051195, 0.159838, -0.07578, -0.014033, 0.048525, 0.22903, -0.021226, 0.053008, -0.089499, 0.045504, -0.013619, 0.036842, 0.096093, 0.076384, 0.144235, 0.01295, -0.172134, -0.068905, -0.003631, -0.161713, 0.056472, 0.008516, 0.023664, 0.072876, 0.0484, -0.073124, 0.145376, 0.078722, 0.012776, -0.096526, -0.138296, -0.048484, 0.071484, -0.273567, -0.000683, -0.032559, -0.205928, -0.098121, 0.108563, 0.441097, -0.193492, -0.012186, 0.173769, -0.005469, -0.018722, -0.048515, 0.049321, 0.053531, -0.014858, 0.024267, -0.02885, -0.053014, 0.090957, -0.015074, 0.063947, 0.024614, -0.033166, 0.050221], [0.006342, 0.053144, -0.043978, 0.035772, -0.049899, 0.048798, -0.010413, -0.010946, 0.119829, 0.069227, -0.032668, -0.124413, -0.025703, -0.099924, 0.0776, -0.069258, 0.061195, 0.038964, 0.048379, -0.011504, 0.091775, -0.056627, 0.060169, -0.034088, -0.064753, 0.025881, 0.205598, 0.045945, 0.138951, 0.124, -0.056384, 0.032704, -0.067597, 0.039974, 0.001748, -0.116641, 0.061172, -0.102028, -0.034083, 0.059986, -0.003373, -0.003227, -0.032689, 0.019809, 0.128044, 0.051783, 0.002043, -0.072115, 0.088021, -0.023584, 0.025967, 0.000366, 0.049123, -0.169967, 0.083038, 0.101498, 0.016678, 0.005815, -0.0825, 0.109443, -0.255629, -0.006761, 0.090578, -0.048836, 0.045048, 0.02862, -0.061549, 0.022151, 0.033042, -0.009471, 0.028516, 0.055848, -0.175827, -0.080202, -0.037639, 0.059715, -0.03635, -0.089049, 0.01031], [-0.019003, -0.066094, 0.021629, -0.095666, 0.104899, -0.04874, -0.045336, -0.04421, 0.028898, 0.015893, -0.064402, -0.048359, -0.07035, 0.043321, -0.095829, -0.004919, -0.041384, -0.055984, 0.018606, 0.049098, -0.033941, -0.010661, 0.022059, -0.00592, 0.013979, -0.029717, 0.040551, -0.017843, 0.041867, 0.027675, 0.003581, 0.010209, -0.021816, 0.012523, 0.075046, 0.000101, -0.021566, -0.131442, 0.048112, -0.056288, 0.104261, -0.016962, 0.022062, 0.121431, 0.10338, -0.050834, 0.087901, -0.01729, 0.003583, -0.0844, -0.049622, 0.034423, 0.039252, -0.00121, -0.040887, -0.087559, 0.061231, 0.0096, 0.107762, -0.146909, -0.019788, 0.101257, 0.031918, -0.167085, 0.026332, 0.021709, -0.057736, -0.042406, 0.030342, -0.016792, -0.054795, 0.015161, -0.058232, 0.032763, 0.047069, 0.094549, 0.101715, 0.036161, -0.00998], [-0.005203, 0.021564, -0.00424, 0.025423, -0.055815, -0.023584, -0.031503, -0.033486, 0.013634, 0.075267, -0.114719, -0.06554, -0.017554, -0.005275, 0.075437, 0.058357, -0.022648, -0.069806, -0.058543, 0.019498, 0.016109, -0.040173, 0.050011, 0.084054, -0.021602, 0.011789, -0.008797, 0.009498, -0.032526, 0.027942, -0.103772, -0.0957, -0.072853, 0.055915, 0.119814, 0.054336, -0.040606, -0.08211, -0.002412, -0.068097, 0.042012, -0.079329, 0.013529, -0.027133, 0.014426, -0.071007, -0.013537, -0.023178, -0.058938, -0.069897, 0.205553, -0.00297, 0.034576, -0.070461, -0.007112, -0.073833, 0.002104, 0.024992, 0.198176, -0.14887, 0.062338, 0.120138, -0.025144, -0.058245, -0.047149, -0.036943, -0.035277, 0.032862, -0.012339, 0.057779, 0.003844, -0.015949, 0.053941, 0.092435, -0.06218, -0.113001, 0.03933, 0.048716, -0.098735], [0.030954, -0.040058, 0.008769, -0.039011, -0.046627, 0.005744, -0.044465, -0.094248, 0.015148, -0.045245, 0.048656, -0.036879, 0.065932, -0.000456, -0.067575, 0.052907, -0.023106, 0.044794, 0.015031, 0.011867, -0.03078, 0.037945, 0.051787, 0.019897, -0.043111, -0.004495, -0.035574, 0.053837, -0.112268, -0.112982, -0.023068, -0.063245, -0.018348, -0.010522, -0.106859, -0.061528, -0.111365, 0.001824, 0.071798, -0.052842, 0.021274, -0.017911, 0.0136, -0.085398, -0.037137, 0.05869, 0.0951, -0.040507, 0.027566, -0.082575, -0.015239, 0.160908, -0.019828, -0.029377, 0.040262, -0.01671, 0.086088, 0.001471, 0.133968, -0.108181, -0.041767, 0.222021, 0.029599, -0.2891, -0.17095, -0.010537, 0.014769, -0.063204, -0.054345, 0.013916, -0.011995, 0.008009, 0.097453, -0.087774, 0.101238, -0.073262, 0.091053, 0.072404, 0.05625], [0.054221, -0.029726, 0.017932, -0.057986, 0.097912, 0.109098, -0.027714, -0.214308, 0.015332, 0.05462, -0.114226, 0.000217, -0.01698, 0.073451, 0.016121, -0.118458, -0.011143, -0.022775, 0.028798, 0.025131, 0.037429, -0.02163, 0.01967, 0.062824, -0.048297, 0.049317, 0.060004, 0.043253, 0.075344, -0.059584, 0.059197, 0.089681, -0.100059, 0.072573, -0.046828, -0.059622, -0.069259, -0.006682, 0.140706, 0.126843, -0.043344, 0.009267, 0.040266, 0.107345, -0.131556, -0.015238, -0.009346, 0.0493, 0.016588, 0.096297, -0.160907, -0.078995, 0.068054, 0.173827, -0.060974, -0.031955, -0.029029, -0.067395, -0.116414, 0.065232, 0.061797, 0.004264, -0.006778, 0.015996, 0.003513, 0.025381, -0.052491, -0.021284, 0.031545, 0.001213, 0.00142, 0.107541, -0.185739, -0.015745, 0.046073, 0.053421, -0.067583, -0.00974, -0.078472], [-0.031963, 0.144563, 0.093367, -0.028404, 0.000816, -0.029709, 0.019493, 0.047009, 0.058274, -0.062993, -0.109621, 0.035439, -0.093791, -0.042398, 0.01519, -0.017878, 0.025849, -0.051107, 0.029045, -0.091347, 0.065853, 0.037873, 0.05682, -0.005959, -0.032167, -0.025477, 0.134086, -0.086792, -0.002235, -0.083119, -0.091572, -0.004209, 0.088348, -0.027789, -0.002264, -0.026727, -0.05954, 0.093187, 0.08442, 0.018402, 0.144905, -0.11044, -0.048495, -0.143903, -0.021092, 0.009832, 0.045265, -0.107662, 0.099763, -0.034952, 0.051536, -0.125854, -0.03089, -0.152485, -0.034245, -0.043356, 0.159335, -0.085091, 0.001531, -0.276775, 0.012531, 0.118329, -0.030429, -0.019316, 0.027708, -0.084241, -0.009446, 0.047527, 0.022025, 0.056514, 0.023977, 0.022236, -0.008032, -0.061658, 0.051922, -0.029596, 0.036676, -0.102709, 0.057483], [-0.060727, 0.132722, 0.058833, 0.020036, 0.091822, -0.076781, -0.043836, -0.025095, -0.00905, 0.055244, 0.004134, -0.037047, -0.073041, -0.051029, 0.085023, 0.017839, 0.03618, -0.073544, -0.018724, -0.003683, -0.09106, 0.04854, -0.101744, -0.034047, 0.056383, -0.017352, 0.008813, -0.017765, -0.018968, 0.077716, -0.009165, -0.034754, 0.02446, -0.063221, 0.040059, -0.039772, 0.071655, 0.076533, 0.093191, -0.00554, 0.026754, -0.120753, 0.015158, 0.025429, 0.026077, -0.039263, 0.056659, -0.01093, -0.066721, -0.023895, 0.035668, 0.208699, 0.074792, -0.074006, 0.127181, -0.066602, 0.02893, 0.093549, 0.092761, -0.168241, -0.342837, 0.021295, -0.025908, -0.003793, -0.013955, -0.036691, 0.133817, -0.009095, -0.014206, -0.006089, -0.085899, 0.00383, 0.032176, 0.014079, 0.046795, 0.06582, 0.0102, -0.023584, -0.003697], [0.016222, -0.107217, -0.01465, -0.018389, -0.013258, 0.068709, 0.023252, -0.021187, 0.000969, 0.011873, -0.068183, -0.022933, 0.039912, -0.016449, 0.014578, 0.039151, 0.049913, -0.050703, -0.051804, 0.028273, 0.129708, 0.007534, 0.049738, -0.102742, 0.015207, 0.03218, 0.016053, -0.006694, 0.019386, 0.039612, -0.044205, -0.046432, 0.061506, -0.028551, -0.048404, 0.033102, -0.062177, -0.121224, -0.121295, -0.014198, 0.088595, -0.101859, -0.004775, -0.027642, 0.087111, -0.019528, -0.034389, -0.005892, 0.010931, -0.087587, 0.064791, -0.012676, 0.100189, -0.05226, 0.03344, 0.054288, 0.098977, 0.110274, 0.111719, -0.004247, -0.113135, 0.069693, 0.055623, -0.058971, 0.011411, 0.020525, -0.055492, 0.026468, -0.044207, 0.047357, 0.040256, -0.043436, 0.038334, 0.013974, -0.089425, -0.041907, 0.018073, -0.025131, -0.029974], [-0.006072, -0.00949, -0.135164, 0.005455, -0.063904, 0.062457, 0.032677, -0.011174, 0.016879, -0.03405, 0.055874, -0.084517, -0.053626, 0.146723, 0.130516, 0.006715, -0.084989, -0.075959, 0.017664, -0.035656, -0.087033, 0.054909, -0.037048, 0.019567, 0.011983, 0.079674, -0.083074, 0.011888, -0.093157, -0.020075, 0.052238, 0.0004, 0.045018, 0.066805, -0.007229, 0.048659, 0.007544, -0.126885, 0.059002, 0.015774, -0.03491, 0.131692, 0.040537, 0.111868, 0.034947, -0.009342, -0.035897, 0.088327, -0.038878, 0.125495, -0.038899, -0.101015, -0.029772, 0.055181, -0.141874, 0.073564, -0.025542, -0.054035, 0.001588, 0.110901, 0.114026, -0.045254, -0.043477, 0.059422, -0.088335, 0.049566, 0.066481, -0.002513, -0.022447, 0.033352, -0.059761, -0.070329, -0.114832, -0.046716, -0.082363, 0.082918, -0.108367, 0.021035, 0.055845], [-0.008417, -0.035903, -0.059077, 0.067059, 0.02424, -0.017437, -0.056162, 0.084029, -0.007497, 0.011562, -0.095682, 0.038971, -0.043915, 0.015223, 0.032243, -0.041906, -0.047584, 0.046718, 0.053773, -0.050585, 0.023009, 0.080826, 0.044677, -0.065041, -0.017973, 0.061512, 0.042322, 0.061539, 0.209036, -0.005095, 0.013492, -0.020055, -0.023285, -0.037073, -0.024566, 0.096038, -0.015179, -0.032788, 0.003426, 0.038213, -0.112218, -0.068374, 0.013477, 0.126405, -0.016392, 0.065463, -0.018156, -0.067279, -0.100699, -0.047172, 0.032394, 0.088023, 0.036357, -0.044758, 0.007976, -0.103823, 0.015461, -0.045767, 0.058171, 0.070128, -0.015014, 0.111188, 0.068225, -0.207017, -0.010392, -0.015594, -0.041272, 0.008545, -0.029758, 0.064277, 0.006744, 0.033491, -0.061842, 0.004378, -0.071726, -0.118248, 0.070897, 0.029292, 0.011667], [0.020164, -0.006538, 0.044276, -0.090178, 0.025049, 0.074268, 0.05725, 0.049068, -0.020366, -0.074944, 0.023921, 0.056415, 0.039832, -0.01272, -0.089221, 0.089891, -0.03415, 0.036809, 0.074431, -0.049173, -0.015584, 0.125289, -0.170432, 0.095175, 0.165537, -0.049168, 0.119804, 0.064918, -0.181327, -0.010743, 0.000505, -0.106886, 0.175565, 0.030622, -0.055421, -0.086055, -0.038714, 0.103175, 0.16016, 0.081445, 0.012464, -0.068032, 0.016337, -0.036339, -0.102309, 0.008795, -0.088607, -0.071357, 0.04411, 0.018632, 0.207865, 0.090547, 0.091832, 0.079193, -0.030409, -0.043383, 0.069264, 0.109081, 0.037316, -0.119878, -0.053638, -0.008376, 0.005271, -0.078471, -0.032648, -0.006671, 0.036656, -0.015564, -0.087596, 0.08662, -0.100407, -0.056578, 0.059722, -0.011871, -0.10257, 0.099459, -0.041261, -0.008341, 0.011383], [0.016978, 0.05627, 0.02858, 0.086041, -0.095568, 0.083062, -0.000855, 0.043577, 0.05119, -0.023713, -0.011548, 0.000449, -0.07955, -0.069903, -0.042186, -0.011426, -0.040286, 0.004232, 0.111662, 0.056856, 0.074961, 0.034161, 0.0168, -0.019325, 0.000301, -0.05294, -0.002715, 0.034942, -0.086969, -0.056374, -0.019728, 0.132375, -0.061615, 0.042829, -0.035388, -0.011352, -0.021995, 0.077516, 0.000756, 0.132598, -0.108337, 0.068415, 0.052911, 0.094854, -0.152072, -0.019511, -0.031744, -6.8e-05, 0.060999, 0.00886, -0.018195, 0.033461, -0.087552, 0.10501, 0.063388, -0.005432, 0.022047, -0.025189, -0.032101, -0.074822, -0.096886, 0.062397, 0.013094, -0.182269, -0.013366, 0.013677, -0.011817, -0.010161, -0.003029, 0.005426, -0.056903, 0.060043, -0.074505, 0.049876, -0.029916, 0.072444, -0.023062, 0.091084, -0.055766]], 'w2': [[0.004421, 0.048432, 0.058479, 0.031789, 0.046963, 0.010819, 0.018803, 0.067804, -0.034156, -0.019767, -0.027066, -0.009102, -0.01382, -0.045087, -0.008617, -0.087267, -0.00613, -0.039413, 0.00578, 0.033843, 0.025288, -0.036732, 0.017563, 0.003429, -0.071582], [-0.000579, -0.041221, -0.054114, -0.037967, -0.027765, 0.000467, -0.027444, -0.075253, 0.026612, 0.020954, 0.018692, 0.016612, 0.019587, 0.055983, 0.001907, 0.092107, 0.005116, 0.029201, -0.000416, -0.039471, -0.032924, 0.026347, -0.010404, -0.004984, -0.078399]], 'hist_par': {'USDCHF-OTC': '10010011011101110010', 'SP500-OTC': '10110110111110110110', 'ONDOUSD-OTC': '01011010111110001111', 'EURGBP-OTC': '00101011111111000000', 'RENDERUSD-OTC': '11111111110111001001', 'SUIUSD-OTC': '10101100010010110010', 'HBARUSD-OTC': '00000111000111000011', 'RAYDIUMUSD-OTC': '10111111111100110001', 'GBPUSD-OTC': '11101111000010100010', 'PENGUUSD-OTC': '10100101000001100011', 'DYDXUSD-OTC': '01011110111110100001', 'EURUSD-OTC': '11001000000001000110', 'EURJPY-OTC': '11001011110110011000', 'FETUSD-OTC': '11011011010101101111', 'AMAZON-OTC': '00001000001011000011', 'Gold/BRL': '01111101101011001001', 'NZDCAD-OTC': '01111100011110010010', 'LINKUSD-OTC': '01101101010011110111', 'AUDJPY-OTC': '01111100010001100111', 'SANDUSD-OTC': '01100111111100111001', 'GBPCHF-OTC': '00100111001100100100', 'XNGUSD-OTC': '01111111010101000000', 'INJUSD-OTC': '10101011111111011011', 'NEARUSD-OTC': '00010000000101101110', 'FARTCOINUSD-OTC': '11111111011000111101', 'AUDCAD-OTC': '10101111100101101011', 'NZDUSD-OTC': '01110111011100001111', 'USOUSD-op': '11110110000101111001', 'DIA': '10000000010000011001', 'FR40-OTC': '01111011101100000000', 'EURCHF-OTC': '11111111001100010101', 'XAUUSD-OTC': '01001010011000111000', 'Crude Oil Brent/BRL': '11001101000011010000', 'IWM': '11010111100110100110', 'SQQQ': '11111111111110001111', 'XLK': '11110101111111110001', 'SMH': '00010101001110011101', 'EURTHB-op': '11111111111111111111', 'UKOUSD-OTC': '10101110100110100001', 'ATOMUSD-OTC': '00111011100011111000', 'MELANIAUSD-OTC': '11010111000000101001', 'JPM-OTC': '10110111011000100001', 'AIRLINES-OTC': '10101101101100000100', 'WIFUSD-OTC': '10110000010000001100', 'USDJPY-OTC': '00001111100110110110', 'IMXUSD-OTC': '11001101101010111100', 'FWONA-OTC': '10110000100110100000', 'DASHUSD-OTC': '11110101111111011000', 'GDX': '11000111010101110010', 'PEPEUSD-OTC': '01111100101100010110', 'SPY': '01011100001000110101', 'WLDUSD-OTC': '11000101000001110100', 'USDTHB-OTC': '11100010011000010000', 'JP225-OTC': '11100101000111000101', 'USNDAQ100:N': '10001111100101110111', 'USSPX500:N': '01001101101001100010', 'ARBUSD-OTC': '11111101001001100000', 'PENUSD-OTC': '00111001001011110101', 'AUS200-OTC': '11001001001101111100', 'GBPCAD-OTC': '10010011100100011111', 'EURTHB-OTC': '01110010101000101001', 'CHFNOK-OTC': '10011011110100101010', 'MCDON-OTC': '01110000010111000011', 'US30:N': '01000000100011101110', 'JPYTHB-OTC': '00111011100100100111', 'GRTUSD-OTC': '11111011101100001100', 'AUDCHF-OTC': '10001011000111111110', 'SOLUSD-OTC': '11000000101111001011', 'USOUSD-OTC': '00100010101000010110', 'COKE-OTC': '10000100001010010010', 'OpenAI-OTC': '10110001100111110100', 'SHIBUSD-OTC': '11000111011110100000', 'MAGNIFICENT7-OTC': '01100001111110001110', 'USNDAQ100-OTC': '00111110110000111101', 'USDDOP-OTC': '11001001110111001000', 'EURAUD-OTC': '00110110000001010011', 'JAPAN225:N': '01001010001000110101', 'GERMANY30:N': '01101110100101100011', 'FRANCE40:N': '11010001001001110001', 'XRPUSD-OTC': '00001011100001011100', 'JUPUSD-OTC': '11010000111011011001', 'GBPJPY-OTC': '11000011011001000001', 'USDSEK-OTC': '00010011100100000001', 'USDBRL-OTC': '00001000001000111000', 'APPLE-OTC': '10001011101110001101', 'US2000-OTC': '01010101111010010100', 'CADJPY-OTC': '11011011111011010010', 'EOSUSD-OTC': '10000100011110001010', 'AI Power & Datacenter': '11111111111000111101', 'FB-OTC': '11110101111111001000', 'US30-OTC': '00010011111110010110', 'Bitcoin/Gold-op': '01110001001000001111', 'US AI Semiconductors': '01000110010111000100', 'AUDNZD-OTC': '11110110101011111100', 'PLTR-OTC': '00011000110110001000', 'AUS200:N': '11111111011010111000', 'XAGUSD-OTC': '11110110011001000110', 'CADCHF-OTC': '11000110111100001010', 'USDCAD-OTC': '00101110010111010111', 'SNAP-OTC': '01110000101011100100', 'BTCUSD-OTC-op': '11101000010101000100', 'IOTAUSD-OTC': '00111001111011010000', 'MATICUSD-OTC': '01011001101010010110', 'USDPLN-OTC': '01100111001100110000', 'USDSGD-OTC': '10010001001000111011', 'CHFJPY-OTC': '00100001110011000010', 'NZDJPY-OTC': '01110100110011111001', 'USDZAR-OTC': '01100011011111100000', 'KLARNA-OTC': '00010011000110111110', 'HK33-OTC': '00011000100010100100', 'US2000:N': '11111011010111110010', 'HONGKONG33:N': '01101011110100010110', 'USDNOK-OTC': '11001001110101111111', 'Anthropic-OTC': '11101101101111101111', 'UK100-OTC': '01000010011000100000', 'USDCOP-OTC': '01100100110110000001', 'CASINOS-OTC': '00100111110100001001', 'EURCAD-OTC': '01001000000100000101', 'EU50-OTC': '01110010111110010001', 'SATSUSD-OTC': '00011010000111001000', 'URANIUM-OTC': '01111101110110011001', 'BONKUSD-OTC': '11110110001001001100', 'CANNABIS-OTC': '00010100011110100111', 'MSFT-OTC': '00111101111100001000', 'MORSTAN-OTC': '01001000010110001101', 'ETHUSD-OTC': '11101011101111100101', 'AUDUSD-OTC': '00100001111000001101', 'USDARS-OTC': '11100000111000110111', 'TRON-OTC': '00000100000010000010', 'GER30-OTC': '01101111101101111110', 'GBPNZD-OTC': '10110000110010100000', 'GOOGLE-OTC': '00101001110110111101', 'TIAUSD-OTC': '00110001100000110001', 'UK100:N': '00010100111000101000', 'Magnificent7-op': '11001011001011001100', 'GS-OTC': '11000101111000000111', 'GBPAUD-OTC': '10000011100000010110', 'TESLA-OTC': '11110101001111100010', 'LABUBUUSD-OTC': '01100111001001000111', 'USDTRY-OTC': '11100110110011100111', 'DOTUSD-OTC': '01001010011001011010', 'ALIBABA-OTC': '11111011001000111010', 'TRUMPUSD-OTC': '11001111001100100100', 'PYTHUSD-OTC': '10010011010101010101', 'EURNZD-OTC': '00001010011011001000', 'LTCUSD-OTC': '00000001010110011111', 'GER30/UK100-OTC': '01001000111100101100', 'COTTON-OTC': '00101110111111111000', 'US30/JP225-OTC': '11100101110001110010', 'EURJPY-op': '10111101101101111011', 'TESLA/FORD-OTC': '11101001000000100010', 'NVDA/AMD-OTC': '10110100011110111001', 'XAU/XAG-OTC': '01100111111110111100', 'GOOGLE/MSFT-OTC': '01001001010110111001', 'META/GOOGLE-OTC': '00001010001001000111', 'LUNA-OTC': '00101111100110111010', 'USDAED-OTC': '10111111101001000010', 'US100/JP225-OTC': '01100101101101010001', 'MSFT/AAPL-OTC': '00011100110010110101', 'AMZN/EBAY-OTC': '00001101001010110011', 'NVDA-OTC': '11010111010000101110', 'EURUSD-op': '11000000001110011000', 'EURGBP-op': '000001101011001000', 'USDTHB-op': '11010110110010001111', 'USDMYR-OTC': '01101000100100101111', 'AMZN/ALIBABA-OTC': '10100111111010111101', 'USDVND-OTC': '01111000000010111111', 'COCOA-OTC': '11111111001011010101', 'USDBOB-OTC': '01101110000111111111', 'ICPUSD-OTC': '01000100010100101011', 'USDIDR-OTC': '00011000010001001101', 'XPDUSD-OTC': '00001010100111100000', 'USDHKD-OTC': '01010100001110110110', 'WDC-OTC': '10100101001110100110', 'COFFEE-OTC': '00000000101111011010', 'USDPHP-OTC': '11000001101101100100', 'USDJPY-op': '11101011000011100110', 'XPTUSD-OTC': '01001101110100110010', 'SUGAR-OTC': '11000000011110100110', 'GBPJPY-op': '10100111101100000000', 'USDNGN-OTC': '10110101011000100111', 'INTEL/IBM-OTC': '11000001101100110011', 'SEIUSD-OTC': '10101101001010011110', 'USDSAR-OTC': '11100000010111000100', 'RONINUSD-OTC': '11000100010111101011', 'HYPE-OTC': '11001100111100010000', 'NIKE-OTC': '10101110110010110101', 'MU-OTC': '00100001001001010110', 'GEV-OTC': '01110100010110101101', 'USDBDT-OTC': '10111001011110111001', 'NFLX/AMZN-OTC': '01001010010010000100', 'GBPUSD-op': '10011100100010000100', 'USDCLP-OTC': '00001010011111111010', 'XAUUSD-op': '11111111011111000110', 'SpaceX-OTC': '01110001001011111011', 'SpaceX-op': '00111111001001111100'}, 'hist_ctx': {'otc20': '00100001111011111001100110111110110101011100010111', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '01001111000100001010100011100001000100100000101111', 'otc1': '11001110011011001101111111000101101111100101011111', 'otc2': '00101110110101000010001011011111110000011100100011', 'otc3': '10000000010111111100111100000101000001001110011110', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '10010011100010000110000000010010110110110110101010', 'otc13': '10011101000001111111010110100000111111010011101011', 'otc14': '11111000001010010101001000001011100000000100000001', 'otc15': '10010001100011100100001000001110010011001011010001', 'otc16': '10011110100010011101011010010001011011101000111110', 'otc18': '00100111011101010010001101111100010101000100000000', 'otc19': '01001110010110001010101111001000001110100011110001', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '01000001000110110110011001101110000010100111001001', 'real17': '10011010001000111001101111001011010111111111111111', 'real12': '01000100000110011001010001010110111110001010000110', 'real13': '11111000001001010000100001110111101010100110111011', 'real14': '01000111011111111000100101001001110010000001111111', 'real15': '00100001101001110000000110001011010111111111111111', 'real16': '11001101101110100111100101001100111110111111111111', 'real18': '01101001101011011001100100010100111111101111110111', 'real19': '00001111010010001000101001100000001000101001100010', 'real20': '11100011001110010000110111111111111000000010100001', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '00111100101110101101110000101100000110111100100100', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5803718, 'preentreno': True, 'sombra': '011110100000001001000101100011011011111001001010011000000001010010101000111011010100010001100101110111001111000000100101000001100101111101111101100101011111110011000011110111111110110101010100001000101110011001011101000011000000011011110101010101111111100001111100001011101100010110010001111111111101011100000110001010100001010001', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960, 1793413740, 1793413860, 1793413920, 1793413980, 1793414040, 1793414220, 1793413800, 1793414280, 1793414340, 1793414160, 1793414460, 1793414520, 1793414580, 1793414100, 1793414760, 1793414820, 1793414700, 1793414940, 1793414640, 1793415000, 1793414400, 1793415180, 1793415120, 1793415060, 1793415480, 1793415540, 1793415600, 1793415240], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1331, 'activa': False, 'ev_prom': -0.018018410373336756, 'ultima_senal': 1793415798.7003915, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1793449568}}
_CRIPTO = ("BTC", "ETH", "SOL", "XRP", "LTC", "DOT", "ADA", "CARDANO", "DOGE", "SHIB", "PEPE", "BONK", "TRON", "TRX",
           "SUI", "ARB", "HBAR", "FET", "ONDO", "TAO", "WIF", "WLD", "SEI", "JUP", "DYDX", "EOS", "DASH", "ATOM",
           "LUNA", "TRUMP", "RAYDIUM", "RENDER", "PENGU", "PEN", "SATS", "HYPE", "FARTCOIN", "MELANIA", "FLOKI",
           "LINK", "NEAR", "MATIC", "IMX", "INJ", "ORDI", "PYTH", "STX", "GRT", "SAND", "MANA", "ICP", "IOTA", "RONIN",
           "BCH", "LABUBU")
_DIVISAS = ("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "THB", "MXN", "BRL", "COP", "ZAR", "TRY", "INR",
            "IDR", "PHP", "PLN", "SGD", "HKD", "NOK", "SEK", "ARS", "CLP", "DOP", "BOB", "BDT", "NGN", "VND", "MYR",
            "AED", "SAR", "EGP", "PKR")


def ia_tipo_par(par):
    """(es_otc, es_divisa, es_cripto) a partir del nombre del par."""
    p = str(par).upper().replace("-OTC", "").replace("-OP", "")
    otc = "OTC" in str(par).upper()
    cripto = any(p.startswith(c) for c in _CRIPTO)
    divisa = (not cripto) and len(p) == 6 and p[:3] in _DIVISAS and p[3:] in _DIVISAS
    return otc, divisa, cripto


def _ia_lim(x, a=3.0):
    return a if x > a else (-a if x < -a else x)


def ia_rasgos(velas, par, pago, t, tf=1, digital=False, propio=(0.0, 0.0, 0.0, 0.0)):
    """Lo que 've' la IA autónoma: velas crudas y contexto. Nada de indicadores ni estrategias hechas.
    velas: dicts o,h,l,c (la última es la vela de señal). Devuelve IA_ENTRADAS números o None."""
    n = len(velas)
    if n < 40:
        return None
    c = [v["c"] for v in velas]
    tr = [max(velas[i]["h"], c[i - 1]) - min(velas[i]["l"], c[i - 1]) for i in range(n - 14, n)]
    atr = sum(tr) / 14.0                               # tamaño normal de una vela ahora (para comparar)
    if atr <= 0:
        atr = abs(c[-1]) * 1e-5 or 1e-9
    tr50 = [velas[i]["h"] - velas[i]["l"] for i in range(max(1, n - 50), n)]
    atr50 = (sum(tr50) / len(tr50)) or atr
    f = []
    for v in velas[-IA_VELAS_VE:]:                     # las últimas 20 velas tal cual: cuerpo y mechas
        f.append(_ia_lim((v["c"] - v["o"]) / atr))
        f.append(_ia_lim((v["h"] - max(v["o"], v["c"])) / atr))
        f.append(_ia_lim((min(v["o"], v["c"]) - v["l"]) / atr))
    f.append(_ia_lim((c[-1] - c[-4]) / atr / 2))      # cuánto se ha movido el precio (corto, medio, largo)
    f.append(_ia_lim((c[-1] - c[-11]) / atr / 3))
    f.append(_ia_lim((c[-1] - c[-31]) / atr / 5))
    alto = max(v["h"] for v in velas[-30:]); bajo = min(v["l"] for v in velas[-30:])
    f.append(_ia_lim(((c[-1] - bajo) / ((alto - bajo) or 1e-12)) * 2 - 1))   # dónde está dentro del rango reciente
    f.append(_ia_lim(atr / atr50 - 1.0))              # ¿más agitado o más quieto que de costumbre?
    h = (t % 86400) / 86400.0 * 2 * math.pi           # hora del día (UTC), día y fin de semana
    f.append(math.sin(h)); f.append(math.cos(h))
    dia = int(t // 86400 + 4) % 7                      # 0 = domingo
    f.append(math.sin(dia / 7 * 2 * math.pi)); f.append(math.cos(dia / 7 * 2 * math.pi))
    f.append(1.0 if dia in (0, 6) else 0.0)
    otc, divisa, cripto = ia_tipo_par(par)
    f.append(1.0 if otc else 0.0); f.append(1.0 if divisa else 0.0); f.append(1.0 if cripto else 0.0)
    f.append(1.0 if digital else 0.0)
    f.append((tf - 1) / 4.0)                           # temporalidad: 0 = M1 … 1 = M5
    f.append(_ia_lim(((pago or 0.85) - 0.85) * 10))    # payout del par
    f.extend(propio)                                   # cómo le viene yendo en ese par y en ese mercado a esa hora
    f.append(1.0)                                      # sesgo
    return f


def ia_migrar_pesos(w1):
    """Versiones anteriores tenían menos entradas: las nuevas se agregan en cero (no se pierde lo aprendido)."""
    return [fila + [0.0] * (IA_ENTRADAS - len(fila)) if len(fila) < IA_ENTRADAS else fila for fila in w1]


class IARefuerzo:
    """Red pequeña que estima cuánto se gana por dólar con CALL y con PUT, y aprende en línea."""

    def __init__(self, ruta):
        self.ruta = ruta
        self.lock = threading.Lock()
        rnd = __import__("random").Random(7)
        e = 1.0 / math.sqrt(IA_ENTRADAS)
        self.w1 = [[rnd.uniform(-e, e) for _ in range(IA_ENTRADAS)] for _ in range(IA_OCULTAS)]
        self.w2 = [[rnd.uniform(-0.1, 0.1) for _ in range(IA_OCULTAS + 1)] for _ in range(2)]
        self.lr = 0.004
        self.aprendidas = 0                # ejemplos con los que ha aprendido
        self.preentreno = False            # ¿ya hizo el primer entrenamiento con el historial?
        self.tfs_entrenadas = []           # temporalidades con primer entrenamiento hecho
        self.velas_tf = {}                 # temporalidad -> velas M1 por par con las que se entrenó
        self.hist_hecho = []               # temporalidades ya entrenadas con el historial grande (20.000 velas)
        self.sombra = deque(maxlen=IA_SENALES_VENTANA)    # últimas señales evaluadas (True gana / False pierde)
        self.sombra_t = deque(maxlen=IA_SENALES_VENTANA)  # hora de cada una
        self.mejor = {}                                    # cierre -> (lo que esperaba, par, tf): la que cuenta ese minuto
        self.hist_par = {}                                 # par -> últimas 20 decisiones propias (gana / pierde)
        self.hist_ctx = {}                                 # mercado+hora -> últimas 50 decisiones propias
        self.total_senales = 0
        self.activa = False                # False = modo sombra · True = opera
        self.fase = "Esperando"
        self.base_publicado = 0            # de qué publicación del autor viene lo aprendido
        self.ev_prom = None                # lo que espera ganar por dólar en promedio (su mejor opción), últimos cierres
        self.ultima_senal = 0.0            # hora de su última señal
        self.senales_t = deque(maxlen=500) # horas de las señales (para "señales en la última hora")
        self.revisados = 0                 # pares revisados en el último cierre
        self._cierre = None
        self._cuenta = 0
        self.cargar()
        self.tomar_publicada()

    # --- red ---
    def _adelante(self, x):
        oc = []
        for fila in self.w1:
            s = 0.0
            for wi, xi in zip(fila, x):
                s += wi * xi
            oc.append(math.tanh(s))
        oc.append(1.0)
        q = [sum(w * o for w, o in zip(fila, oc)) for fila in self.w2]
        return oc, q

    def q(self, x):
        with self.lock:
            return self._adelante(x)[1]

    def aprender(self, x, r_call, r_put):
        """Un paso: acerca lo que espera ganar a lo que de verdad habría ganado con CALL y con PUT."""
        with self.lock:
            oc, q = self._adelante(x)
            errs = (q[0] - r_call, q[1] - r_put)
            lr = self.lr
            grad_oc = [0.0] * IA_OCULTAS
            for k in range(2):
                e = errs[k]
                fila = self.w2[k]
                for j in range(IA_OCULTAS):
                    grad_oc[j] += e * fila[j]
                for j in range(IA_OCULTAS + 1):
                    fila[j] -= lr * (e * oc[j] + 1e-4 * fila[j])
            for j in range(IA_OCULTAS):
                g = grad_oc[j] * (1 - oc[j] * oc[j])
                if g == 0.0:
                    continue
                fila = self.w1[j]
                for i in range(IA_ENTRADAS):
                    fila[i] -= lr * g * x[i]
            self.aprendidas += 1

    def decidir(self, x):
        """('call'/'put' o None, lo que espera ganar por dólar)."""
        q = self.q(x)
        k = 0 if q[0] >= q[1] else 1
        if q[k] < IA_UMBRAL:
            return None, q[k]
        return ("call" if k == 0 else "put"), q[k]

    # --- modo sombra ---
    def anotar_senal(self, gano, cuando=None):
        """Una señal resuelta (máximo una por minuto). Se activa solo si el acierto está sobre el
        equilibrio con 95 % de seguridad, con 300 señales o más repartidas en al menos 2 horas."""
        with self.lock:
            self.sombra.append(bool(gano))
            self.sombra_t.append(float(cuando or time.time()))
            self.total_senales += 1
            r = self._medida()
            if not self.activa and r["listo"]:
                self.activa = True
                return "activa"
            ult = list(self.sombra)[-IA_SENALES_MIN:]
            if self.activa and len(ult) >= IA_SENALES_MIN and sum(ult) / len(ult) < IA_ACIERTO_APAGAR:
                self.activa = False
                return "sombra"
        return None

    def _medida(self):
        n = len(self.sombra)
        g = sum(self.sombra)
        horas = (self.sombra_t[-1] - self.sombra_t[0]) / 3600.0 if n > 1 else 0.0
        nec = ia_acierto_necesario(n)
        listo = n >= IA_SENALES_MIN and horas >= IA_HORAS_MIN and ia_limite_inferior(g, n) >= IA_EQUILIBRIO
        return {"n": n, "g": g, "horas": horas, "necesita": nec, "listo": listo}

    @staticmethod
    def _ctx(par, t):
        return ("otc" if "OTC" in str(par).upper() else "real") + str(int(t % 86400 // 3600))

    def propio(self, par, t):
        """Su propio historial: cómo le viene yendo en este par y en este mercado a esta hora."""
        hp = self.hist_par.get(par) or ()
        hc = self.hist_ctx.get(self._ctx(par, t)) or ()
        fp = (2 * sum(hp) - len(hp)) / len(hp) if hp else 0.0
        fc = (2 * sum(hc) - len(hc)) / len(hc) if hc else 0.0
        return (fp, len(hp) / 20.0, fc, len(hc) / 50.0)

    def registrar(self, par, t, gano):
        with self.lock:
            self.hist_par.setdefault(par, deque(maxlen=20)).append(bool(gano))
            self.hist_ctx.setdefault(self._ctx(par, t), deque(maxlen=50)).append(bool(gano))

    def mirar(self, cierre, q_mejor, senal):
        """Anota cada revisión (para mostrar qué opina del mercado aunque no marque señales)."""
        with self.lock:
            if cierre != self._cierre:
                if self._cierre is not None:
                    self.revisados = self._cuenta
                self._cierre, self._cuenta = cierre, 0
            self._cuenta += 1
            self.ev_prom = q_mejor if self.ev_prom is None else self.ev_prom * 0.998 + q_mejor * 0.002
            if senal:
                ahora = time.time()
                self.ultima_senal = ahora
                self.senales_t.append(ahora)

    def resumen(self):
        n = len(self.sombra)
        hora = time.time() - 3600
        m = self._medida()
        return {"activa": self.activa, "senales": n, "total": self.total_senales,
                "necesita": round(100 * m["necesita"], 1), "horas": round(m["horas"], 2), "horas_min": IA_HORAS_MIN,
                "acierto": round(100 * sum(self.sombra) / n, 1) if n else None,
                "necesarias": IA_SENALES_MIN, "aprendidas": self.aprendidas,
                "preentreno": self.preentreno, "fase": self.fase, "velas": max(self.velas_tf.values() or [0]),
                "ev": round(self.ev_prom * 100, 1) if self.ev_prom is not None else None,
                "revisados": self.revisados or self._cuenta,
                "ultima_senal": int(self.ultima_senal) or None,
                "senales_hora": sum(1 for t in self.senales_t if t >= hora)}

    # --- guardar / cargar ---
    def guardar(self):
        with self.lock:
            d = {"v": IA_VERSION, "w1": self.w1, "w2": self.w2,
                 "hist_par": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_par.items()},
                 "hist_ctx": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_ctx.items()}, "aprendidas": self.aprendidas, "preentreno": self.preentreno,
                 "sombra": "".join("1" if x else "0" for x in self.sombra), "sombra_t": [int(t) for t in self.sombra_t],
                 "regla": 2, "velas_tf": {str(k): v for k, v in self.velas_tf.items()}, "hist_hecho": self.hist_hecho,
                 "total": self.total_senales,
                 "activa": self.activa, "base_publicado": self.base_publicado,
                 "ev_prom": self.ev_prom, "ultima_senal": self.ultima_senal, "tfs_entrenadas": self.tfs_entrenadas}
        tmp = self.ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        os.replace(tmp, self.ruta)

    def cargar(self):
        try:
            with open(self.ruta, encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                self.total_senales = int(d.get("total", 0) or 0)
                return                                 # IA de otra versión: la autónoma aprende desde cero
            self.w1, self.w2 = d["w1"], d["w2"]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            if d.get("regla") == 2:                    # medición nueva: una por minuto, con su hora
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:                                      # la medición vieja se reinicia (contaba señales repetidas)
                self.activa = False
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = int(d.get("base_publicado", 0) or 0)
            vt = d.get("velas_tf")
            self.velas_tf = {int(k): int(v) for k, v in vt.items()} if isinstance(vt, dict) else (
                {1: 5000} if d.get("preentreno") else {})
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            self.ev_prom = d.get("ev_prom")
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.ultima_senal = float(d.get("ultima_senal") or 0)
        except Exception:
            pass

    def tomar_publicada(self):
        """Si la actualización trae una IA más nueva (entrenada en el PC del autor), se usa esa."""
        try:
            d = (IA_BASE or {}).get(BROKER) or {}
            pub = int(d.get("publicado", 0) or 0)
            if not pub or pub <= self.base_publicado:
                return False
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                return False
            self.w1, self.w2 = d["w1"], d["w2"]
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.sombra.clear(); self.sombra_t.clear()
            if d.get("regla") == 2:
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:
                self.activa = False
            vt = d.get("velas_tf")
            if isinstance(vt, dict):
                self.velas_tf = {int(k): int(v) for k, v in vt.items()}
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = pub
            try:
                self.guardar()
            except Exception:
                pass
            return True
        except Exception:
            return False


def ia_agrupar(m1, tf):
    """Velas M1 -> velas de tf minutos (solo las completas)."""
    if tf == 1:
        return m1
    out, grupo, ini = [], [], None
    for v in m1:
        g = v["t"] - v["t"] % (tf * 60)
        if g != ini:
            if len(grupo) == tf:
                out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                            "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
            grupo, ini = [], g
        grupo.append(v)
    if len(grupo) == tf:
        out.append({"t": ini, "o": grupo[0]["o"], "c": grupo[-1]["c"],
                    "h": max(x["h"] for x in grupo), "l": min(x["l"] for x in grupo)})
    return out


def ia_estado_guardado():
    """Para la pantalla de Configuración (sin bot andando): el estado de la IA del autor."""
    ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
    return ia.resumen()


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = bool(cfg.get("tf_auto"))      # Auto (solo el autor): M1, M2, M3 y M5 a la vez
        # Auto: vigila M1, M2, M3 y M5 a la vez · manual: las temporalidades elegidas
        self.tfs = list(TFS_AUTO) if self.tf_auto else (sorted(set(cfg["temporalidades"]))[:1] or [1])
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal e IA)
        self.ia = None           # IA del autor (solo con estrategia "ia")
        self.ia_pend = {}        # (par, tf) -> decisiones por resolver cuando cierre la vela operada
        self.ia_cola = deque(maxlen=20000)     # ejemplos nuevos para aprender
        self.ia_repaso = deque(maxlen=20000)   # memoria de repaso (refuerzo con repetición de experiencias)
        self.ia_ev = {}                        # (par, tf) -> lo que la IA espera ganar por dólar en este cierre
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.hist = {}           # (par, tf) -> velas
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.prox_cierre = None
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None
        self.estirado_hecho = set()   # bot Bollinger: (par, tf, inicio de vela) ya tomados al estirarse

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más."""
        if self.stop_alcanzado():
            if not self.detener:
                self.detener = True
                self.avisar_stop()
            return True
        return self.detener

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que conviene operar ese par: binaria/turbo o digital, el que mejor pague
        entre los mercados elegidos. (None, None) si no se puede operar."""
        cfg = self.cfg
        tipo = "turbo" if tf <= 5 else "binary"
        opciones = []
        if (cfg["incluir_otc"] if es_otc else cfg["incluir_mercado_real"]) and pays.get(tipo) is not None:
            opciones.append((pays[tipo], tipo))
        if cfg.get("incluir_digital") and tf in (1, 5, 15) and pays.get("digital"):
            opciones.append((pays["digital"], "digital"))
        if not opciones:
            return None, None
        pago, t = max(opciones)
        return t, pago

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=bool(cfg.get("incluir_digital")))
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        if cfg.get("incluir_digital"):
            self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception as e:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre."""
        limite = prox - self.adelanto_analisis() - 1.5
        for par in list(self.seleccion):
            for tf in tfs_c:
                if self.detener or not self.b.conectado or self.b.ahora() > limite:
                    return
                if par in self.pares_en_uso:
                    continue
                k = (par, tf)
                try:
                    hist = self.hist.get(k) or []
                    if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                        self.fase = f"Leyendo {par} M{tf}"
                        velas = self.b.velas(par, tf, HISTORIA_VELAS)
                        if len(velas) < 30:
                            self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); continue
                        self.hist[k] = velas
                        self.hist_t[k] = time.time()
                        if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                                and velas[-1]["t"] >= self.b.ahora() - 180):
                            try:
                                self.vivo_pend[par] = time.time()
                                if not self.b.suscribir_vivo(par, velas):
                                    self.vivo_pend.pop(par, None)
                            except Exception:
                                self.vivo_pend.pop(par, None)
                    elif hist[-1]["t"] < prox - 2 * tf * 60:
                        nuevas = self.b.velas(par, tf, 4)
                        por_t = {v["t"]: v for v in hist}
                        for v in nuevas: por_t[v["t"]] = v
                        self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
                    self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
                except Exception as e:
                    self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def al_estirarse(self):
        """Entrada "al estirarse" (solo Bollinger; para todos)."""
        return self.cfg.get("estrategia", "bollinger") == "bollinger" and self.cfg.get("entrada") == "estirado"

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        if self.al_estirarse():
            return cands, revisados             # "al estirarse": solo entra a mitad de vela (hilo_estirado)
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                if cfg.get("estrategia") == "ia":
                    d, det = self.ia_analizar(par, tf, cerradas, actual, pago, prox, inst)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg)
                    if self.ia is not None:
                        d, det = self.ia_filtrar(par, tf, cerradas, actual, pago, prox, d, det, inst)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre, "detalle": det,
                              "ev": self.ia_ev.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def hilo_estirado(self):
        """Bot Bollinger 'al estirarse': durante la vela mira el precio cada segundo. Si el precio sale de la banda
        y se estira lo pedido, entra YA (mejor precio = margen por si se devuelve) y vence al cierre de la vela
        siguiente, a la misma hora que la entrada normal (máximo 5 minutos, lo que permite el broker)."""
        while not self.detener and not self.terminado:
            time.sleep(1.0)
            try:
                cfg = self.cfg
                if not self.al_estirarse():
                    time.sleep(4); continue
                if not self.b.conectado or self.pausado or self.plan or self.abiertas or self.pares_en_uso:
                    continue                                   # una operación a la vez
                if self.frenar_por_stop():
                    continue
                ahora = self.b.ahora()
                self.entrar_estirado(ahora)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] estirado\n{traceback.format_exc()}")

    def entrar_estirado(self, ahora):
        cfg = self.cfg
        mejores = []
        for par in list(self.seleccion):
            if par in self.pares_en_uso or not self.b.vivo.get(par):
                continue
            if self.descanso.get(par, 0) > time.time():
                continue
            if self.nivel > 0 and par == self.par_perdio:
                continue                                       # el nivel va en otro par
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            pays = self.pares.get(par, {}).get("pays", {})
            ok_m = cfg["incluir_otc"] if par.endswith("-OTC") else cfg["incluir_mercado_real"]
            pago = pays.get("turbo") if ok_m else None
            if pago is None or pago < cfg["payout_minimo"]:
                continue
            for tf in self.tfs:
                inicio = int(ahora) // (tf * 60) * tf * 60
                cierre = inicio + tf * 60
                if cierre - ahora < 2.0 or ahora - inicio < 1.0:
                    continue                                   # pegado al cierre: lo resuelve el ciclo normal
                if (par, tf, inicio) in self.estirado_hecho:
                    continue
                partes = [v for v in m1 if inicio <= v["t"] < cierre]
                if not partes:
                    continue
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get((par, 1), [])}
                    for v in m1:
                        if v["t"] < inicio: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)]
                else:
                    cerradas = [v for v in self.hist.get((par, tf), []) if v["t"] < inicio]
                    if cerradas and cerradas[-1]["t"] == inicio - 2 * tf * 60:
                        ult = self.vela_en_formacion(m1, tf, inicio)     # la vela que acaba de cerrar, con las M1 en vivo
                        if ult:
                            cerradas = cerradas + [ult]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    continue
                d, det = senal([v["c"] for v in cerradas] + [partes[-1]["c"]], cfg, float(cfg.get("estiro", 20) or 0))
                if d:
                    mejores.append((pago, par, tf, inicio, cierre, d, det))
        if not mejores:
            return
        mejores.sort(reverse=True)                             # primero el que más paga
        pago, par, tf, inicio, cierre, d, det = mejores[0]
        expira = cierre + tf * 60
        while expira - ahora > 300:
            expira -= 60                                       # el broker no deja más de 5 minutos
        nivel, ciclo = self.nivel, self.ciclo_perdida
        if nivel > int(cfg["rec_max"]) or cfg["recuperacion"] == "ninguna":
            nivel, ciclo = 0, 0.0
        monto = self.monto_recuperacion(nivel, ciclo, pago)
        if nivel > 0 and not self.puede_arriesgar(monto):
            if not self.puede_arriesgar(self.monto_recuperacion(0, 0.0, pago)):
                return
            self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                     f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
            with self.lock:
                self.nivel, self.ciclo_perdida = 0, 0.0
                self.ciclo_n += 1
            nivel, ciclo = 0, 0.0
            monto = self.monto_recuperacion(0, 0.0, pago)
        if not self.puede_arriesgar(monto):
            return
        self.estirado_hecho.add((par, tf, inicio))
        if len(self.estirado_hecho) > 5000:
            self.estirado_hecho = {k for k in self.estirado_hecho if k[2] > ahora - 3600}
        s = {"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre_estrategia(cfg, True), "inst": "turbo", "inicio_vela": cierre, "disparo": None, "detalle": det,
             "expira": expira, "exp_min": max(1, int(round((expira - ahora) / 60))), "monto": monto,
             "etiqueta": f"NIVEL {nivel}" if nivel else "ENTRADA", "ciclo_n": self.ciclo_n,
             "nivel_usado": nivel, "ciclo_antes": ciclo}
        self.estado(par, f"SEÑAL {d.upper()} M{tf} al estirarse · {det}", "bold green" if d == "call" else "bold red", 1)
        self.lanzar(s)



    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # IA: primero la que más dinero espera (acierto × payout) · Bollinger/RSI: la que más paga
        cands = sorted(cands, key=lambda c: (c.get("ev") if c.get("ev") is not None else -9.0, c.get("payout") or 0.0), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        if self.frenar_por_stop() or self.pausado:
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            elegida = otros[0] if otros else None
            etiqueta = f"NIVEL {nivel}"
        else:
            elegida = lista[0] if lista else None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        self.lanzar(elegida)

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        cfg = self.cfg
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            t_envio = self.b.ahora()
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.avisar_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    self.prox_cierre = prox
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_estirado):
            threading.Thread(target=objetivo, daemon=True).start()
        if self.autor:      # la IA del autor aprende siempre (con IA, Bollinger o RSI) y filtra cuando ya demostró acierto
            threading.Thread(target=self.hilo_ia, daemon=True).start()

    # ---------- IA del autor (refuerzo en línea) ----------
    def ia_segundos(self):
        """(segundos desde el último cierre, segundos hasta el próximo) de la temporalidad elegida."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return t, per - t

    def ia_sin_operar(self):
        """Mientras la IA entrena con estrategia IA, el bot no opera: puede descargar y aprender a toda velocidad."""
        return self.cfg.get("estrategia") == "ia" and getattr(self, "ia_entrenando", False)

    def ia_esperar_ventana(self, margen=8):
        """La IA solo trabaja lejos del cierre: nunca le quita tiempo al análisis ni a las órdenes.
        Si el bot no está operando (IA entrenando), no espera nada."""
        if self.ia_sin_operar():
            return
        while not self.terminado:
            desde, hasta = self.ia_segundos()
            if desde > 5 and hasta > margen:
                return
            time.sleep(0.4)

    @staticmethod
    def ia_recompensas(mov, pago):
        """(premio CALL, premio PUT) por dólar según cómo se movió la vela operada."""
        if mov > 0:
            return pago, -1.0
        if mov < 0:
            return -1.0, pago
        return 0.0, 0.0

    def ia_pago(self, par):
        pays = (self.pares.get(par, {}) or {}).get("pays") or {}
        vals = [v for v in pays.values() if isinstance(v, (int, float)) and v > 0]
        return max(vals) if vals else 0.85

    def ia_descargar(self, par, carpeta):
        """Hasta 20.000 velas M1 del par. Se guardan en ia_velas: solo se baja lo que falta (lo nuevo y lo más viejo)."""
        ruta = os.path.join(carpeta, "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in par) + ".csv")
        velas = {}
        try:
            with open(ruta, encoding="utf-8") as fh:
                for ln in fh:
                    t, o, h, l, c = ln.strip().split(",")
                    velas[int(float(t))] = {"t": int(float(t)), "o": float(o), "h": float(h), "l": float(l), "c": float(c)}
        except Exception:
            velas = {}
        n0 = len(velas)

        def bajar(hasta, falta):
            while falta > 0 and not self.terminado:
                self.ia_esperar_ventana(15)
                bloque = self.b.velas_hasta_t(par, min(1000, falta), hasta)
                if not bloque:
                    return False
                nuevas = 0
                for v in bloque:
                    if int(v["t"]) not in velas:
                        nuevas += 1
                    velas[int(v["t"])] = {"t": int(v["t"]), "o": v["o"], "h": v["h"], "l": v["l"], "c": v["c"]}
                falta -= len(bloque)
                hasta = bloque[0]["t"] - 1
                time.sleep(0.08 if self.ia_sin_operar() else 0.25)
                if nuevas == 0:
                    return False
            return True

        ahora = self.b.ahora()
        if velas:
            ult = max(velas)
            if ahora - ult > 120:                                   # lo nuevo desde la última vez
                bajar(ahora, min(IA_VELAS_DESCARGA, int((ahora - ult) / 60) + 5))
            if len(velas) < IA_VELAS_DESCARGA * 0.95:               # lo más viejo, hasta completar
                bajar(min(velas) - 1, IA_VELAS_DESCARGA - len(velas))
        else:
            bajar(ahora, IA_VELAS_DESCARGA)
        if len(velas) != n0:
            lista = [velas[t] for t in sorted(velas)][-(IA_VELAS_DESCARGA + 1000):]
            try:
                with open(ruta, "w", encoding="utf-8") as fh:
                    fh.write("".join(f"{v['t']},{v['o']},{v['h']},{v['l']},{v['c']}\n" for v in lista))
            except Exception:
                pass
        return [velas[t] for t in sorted(velas)][-IA_VELAS_DESCARGA:]

    def ia_preentrenar(self, tf=None):
        """Entrenamiento con el historial de una temporalidad: baja hasta 20.000 velas M1 de cada par y aprende."""
        ia = self.ia
        self.ia_entrenando = True                 # con estrategia IA: no opera hasta terminar (descarga rápida)
        try:
            return self._ia_preentrenar(tf)
        finally:
            self.ia_entrenando = False

    def _ia_preentrenar(self, tf=None):
        ia = self.ia
        carpeta = os.path.join(DATOS_BROKER, IA_CARPETA_VELAS)
        os.makedirs(carpeta, exist_ok=True)
        ia.fase = "Esperando la lista de pares"
        while not self.terminado and not self.seleccion:
            time.sleep(2)
        tf = tf or (self.tfs[0] if self.tfs else 1)
        pares = list(self.seleccion)
        self.log(f"🤖 IA: entrenamiento M{tf} con hasta {IA_VELAS_DESCARGA:,} velas M1 de {len(pares)} pares (en segundo plano).", "bold")
        ejemplos = 0
        velas_max = 0
        for i, par in enumerate(pares):
            if self.terminado:
                return
            ia.fase = f"M{tf}: descargando y aprendiendo {i + 1}/{len(pares)}"
            try:
                m1 = self.ia_descargar(par, carpeta)
                velas_max = max(velas_max, len(m1))
                velas = ia_agrupar(m1, tf)
            except Exception:
                continue
            pago = self.ia_pago(par)
            for j in range(60, len(velas) - 1):
                if j % 150 == 0:
                    self.ia_esperar_ventana()
                    if self.terminado:
                        return
                if velas[j + 1]["t"] - velas[j]["t"] != tf * 60:
                    continue
                tramo = velas[j - 59 if j >= 59 else 0: j + 1]
                t_ = velas[j]["t"] + tf * 60
                x = ia_rasgos(tramo, par, pago, t_, tf, False, ia.propio(par, t_))
                if x is None:
                    continue
                mov = velas[j + 1]["c"] - velas[j]["c"]
                q_ = ia.q(x)
                k_ = 0 if q_[0] >= q_[1] else 1
                if q_[k_] >= IA_UMBRAL and mov != 0:           # su propio historial, como en vivo
                    ia.registrar(par, t_, (mov > 0) == (k_ == 0))
                rc, rp = self.ia_recompensas(mov, pago)
                ia.aprender(x, rc, rp)
                ejemplos += 1
        ia.preentreno = True
        if tf not in ia.tfs_entrenadas:
            ia.tfs_entrenadas.append(tf)
        ia.velas_tf[tf] = velas_max or ia.velas_tf.get(tf, 0)
        if tf not in ia.hist_hecho:
            ia.hist_hecho.append(tf)           # hecho hasta donde el bróker deja: no se repite en cada inicio
        ia.fase = "Aprendiendo en vivo"
        ia.guardar()
        self.log(f"🤖 IA: entrenamiento M{tf} listo ({ejemplos:,} ejemplos). Sigue aprendiendo en vivo.", "bold")

    def hilo_ia(self):
        try:
            self.ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
        except Exception as e:
            self.log(f"🤖 IA: no se pudo iniciar ({e}).", "red")
            return
        ia = self.ia
        estado = "opera" if ia.activa else "modo sombra"
        self.log(f"🤖 IA lista ({estado} · {ia.aprendidas:,} ejemplos aprendidos).", "bold")
        for tf_ in list(self.tfs):                       # cada temporalidad: entrenamiento con el historial (una vez)
            if self.cfg.get("estrategia") != "ia":       # con Bollinger/RSI no se hace: no le quita fuerza al bot
                break
            if tf_ in ia.hist_hecho or self.terminado:
                continue
            try:
                self.ia_preentrenar(tf_)
            except Exception as e:
                self.log(f"🤖 IA: el primer entrenamiento M{tf_} se cortó ({str(e)[:60]}); sigue aprendiendo en vivo.", "yellow")
        ia.fase = "Aprendiendo en vivo"
        rnd = __import__("random").Random()
        guardado = time.time()
        while not self.terminado:
            hechos = 0
            while self.ia_cola and hechos < 300:
                desde, hasta = self.ia_segundos()
                if hasta < 8 or desde < 4:
                    break
                x, rc, rp = self.ia_cola.popleft()
                ia.aprender(x, rc, rp)
                self.ia_repaso.append((x, rc, rp))
                if len(self.ia_repaso) > 200:                 # repasa una experiencia vieja al azar
                    ia.aprender(*self.ia_repaso[rnd.randrange(len(self.ia_repaso))])
                hechos += 1
            if time.time() - guardado > 300:
                try: ia.guardar()
                except Exception: pass
                guardado = time.time()
            time.sleep(0.2 if hechos else 1.0)
        try: ia.guardar()
        except Exception: pass

    def ia_procesar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """En cada cierre: resuelve lo pendiente (aprende de lo que pasó) y da la opinión de la IA.
        Devuelve (dirección de la IA o None, lo que espera ganar, [espera con CALL, espera con PUT])."""
        ia = self.ia
        pago = pago or self.ia_pago(par)
        pend = self.ia_pend.setdefault((par, tf), deque(maxlen=3))
        if pend:
            por_t = {v["t"]: v for v in cerradas[-4:]}
            for p_ in list(pend):
                v = por_t.get(p_["t_op"])
                if v is None:
                    continue
                pend.remove(p_)
                mov = v["c"] - p_["precio"]
                self.ia_cola.append((p_["x"],) + self.ia_recompensas(mov, p_["pago"]))
                if p_["d"] and mov != 0:
                    ia.registrar(par, p_["t_op"], (mov > 0) == (p_["d"] == "call"))
                m_ = ia.mejor.get(p_["t_op"])
                if p_["d"] and mov != 0 and m_ and m_[1] == par and m_[2] == tf:     # una sola por minuto
                    cambio = ia.anotar_senal((mov > 0) == (p_["d"] == "call"), p_["t_op"])
                    r = ia.resumen()
                    if cambio == "activa":
                        self.log(f"🤖 IA: acierto real {r['acierto']} % en {r['senales']} señales y {r['horas']:.1f} h "
                                 f"(necesitaba {r['necesita']} %) → "
                                 + ("EMPIEZA A OPERAR." if self.cfg.get("estrategia") == "ia" else "ya podría operar con la estrategia IA."), "bold green")
                    elif cambio == "sombra":
                        self.log(f"🤖 IA: el acierto bajó a {r['acierto']} % → vuelve a modo sombra.", "bold yellow")
        x = ia_rasgos(cerradas[-59:] + [actual], par, pago, prox, tf, inst == "digital", ia.propio(par, prox))
        if x is None:
            return None, 0.0, None
        q = ia.q(x)
        k = 0 if q[0] >= q[1] else 1
        d = ("call" if k == 0 else "put") if q[k] >= IA_UMBRAL else None
        ia.mirar(prox, q[k], d)
        if d:
            with ia.lock:
                if q[k] > ia.mejor.get(prox, (-9.0,))[0]:
                    ia.mejor[prox] = (q[k], par, tf)
                if len(ia.mejor) > 30:
                    for k_ in sorted(ia.mejor)[:-10]:
                        ia.mejor.pop(k_, None)
        pend.append({"x": x, "precio": actual["c"], "t_op": prox, "pago": pago, "d": d})
        return d, q[k], q

    def ia_analizar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """Estrategia IA: la decisión es de la IA. En modo sombra no opera."""
        if self.ia is None:
            return None, ""
        d, ev, _ = self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        self.ia_ev[(par, tf)] = ev
        if not d:
            return None, ""
        det = f"IA espera +{ev * 100:.0f}¢ por dólar"
        forzar = bool(self.cfg.get("ia_forzar")) and self.autor          # decisión del autor: opera sin el umbral
        if getattr(self, "ia_entrenando", False) or not (self.ia.activa or forzar):     # entrenando o en sombra: no opera
            self.estado(par, f"IA (sombra) {d.upper()} M{tf} · {det}", "yellow", 2)
            return None, ""
        return d, det

    def ia_filtrar(self, par, tf, cerradas, actual, pago, prox, d, det, inst=None):
        """Bollinger/RSI del autor: la IA solo aprende en segundo plano. NO decide ni bloquea ninguna señal."""
        try:
            self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        except Exception:
            pass
        return d, det

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bollinger")},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "ia": dict(self.ia.resumen(), forzar=bool(cfg.get("ia_forzar")) and self.autor) if self.ia else None,
        }

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [1]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = bool(cfg.get("tf_auto"))    # Auto solo lo puede usar el autor (app_gui lo revisa al iniciar)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    if cfg.get("estrategia") not in ("bollinger", "rsi", "ia"):
        cfg["estrategia"] = "bollinger"
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

