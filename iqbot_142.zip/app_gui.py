# -*- coding: utf-8 -*-
"""
IQ Bot Escáner - aplicación con ventana.
La interfaz (interfaz.html) se muestra con el motor de Edge (WebView2) mediante pywebview,
y habla con el bot (iq_bot.py) a través de la clase Api.
"""
import json, os, sys, threading, time, traceback

if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")

import iq_bot as nucleo


REINICIAR = None      # Android pone aquí su forma de recargar la app tras una actualización
ABRIR_ENLACE = None   # Android pone aquí su forma de abrir el navegador del celular
ENLACE_REGISTRO = "https://iqoption.net/lp/mobile-partner-pwa/es/?aff=838529&aff_model=revenue"   # afiliado de Leiner Serpa


def ruta_recurso(nombre):
    """Ruta de un archivo de esta versión (la descargada por actualización, la del .exe o junto al script)."""
    junto = os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)
    if os.path.isfile(junto):
        return junto
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, nombre)


def _arranque():
    """El módulo que verifica actualizaciones (solo existe si el programa se abrió con arranque.py)."""
    return sys.modules.get("arranque")


def reiniciar_programa():
    """Vuelve a abrir el programa para usar la versión recién descargada."""
    if REINICIAR:
        REINICIAR()
        return
    import subprocess
    env = dict(os.environ, PYINSTALLER_RESET_ENVIRONMENT="1")
    if getattr(sys, "frozen", False):
        comando = [sys.executable] + sys.argv[1:]
    else:
        comando = [sys.executable, os.path.abspath(sys.argv[0])] + sys.argv[1:]
    subprocess.Popen(comando, env=env, close_fds=True)
    os._exit(0)


_TECLADO = []   # se guarda la referencia para que Android no la descarte antes de usarla


def ajustar_teclado_android():
    """Android: al abrir el teclado, la pantalla se DESPLAZA hacia arriba en vez de encogerse.
    Encoger la ventana es lo que dejaba la mitad de la app en negro al escribir el correo o la clave."""
    try:
        from java import jclass, dynamic_proxy
    except ImportError:
        return False                      # PC: no aplica
    try:
        actividad = jclass("org.beeware.android.MainActivity").singletonThis
        modo = jclass("android.view.WindowManager$LayoutParams").SOFT_INPUT_ADJUST_PAN
        Runnable = jclass("java.lang.Runnable")

        class Aplicar(dynamic_proxy(Runnable)):
            def run(self):
                try:
                    actividad.getWindow().setSoftInputMode(modo)
                except Exception:
                    pass

        tarea = Aplicar()
        _TECLADO.append(tarea)
        actividad.runOnUiThread(tarea)
        return True
    except Exception:
        return False


# =====================================================================
#  NOTIFICACIONES (PC: avisos de Windows · celular: notificaciones de Android)
#  y funcionamiento en segundo plano en el celular (servicio en primer plano)
# =====================================================================
_NOTIF_N = [100]


def _es_android():
    try:
        import java  # noqa: F401
        return True
    except ImportError:
        return False


def _actividad():
    from java import jclass
    return jclass("org.beeware.android.MainActivity").singletonThis


def _en_ui(fn):
    """Ejecuta fn en el hilo de la pantalla de Android."""
    from java import jclass, dynamic_proxy
    Runnable = jclass("java.lang.Runnable")

    class Tarea(dynamic_proxy(Runnable)):
        def run(self):
            try:
                fn()
            except Exception:
                pass
    t = Tarea()
    _TECLADO.append(t)
    _actividad().runOnUiThread(t)


# ---------- Android: tarjetas de notificación del bot ----------
_API = []                       # la Api activa (para el botón "Operar de todos modos" de la notificación)
_ESTILO = {  # tipo: (color inicio del degradado, color final, acento)
    "fija": ("#0D1626", "#1C2D52", "#34D27F"),
    "ganada": ("#063A25", "#12804F", "#5CF2A6"),
    "stopwin": ("#05331F", "#0F7A49", "#5CF2A6"),
    "stoploss": ("#3A0B12", "#9B2431", "#FF8A8A"),
    "mercado_malo": ("#3A2204", "#B0650F", "#FFC266"),        # naranja: el bot está en pausa
    "mercado_aviso": ("#2A1E08", "#7A5410", "#FFD27A"),       # dorado: errático, se pausará al terminar
    "mercado_ok": ("#063A25", "#12804F", "#5CF2A6"),
    "error": ("#3A0B12", "#9B2431", "#FF8A8A"),               # rojo: IQ Option rechazó algo / sin conexión
}
_PAIS = {"EUR": "EU", "USD": "US", "GBP": "GB", "JPY": "JP", "CHF": "CH", "AUD": "AU", "CAD": "CA", "NZD": "NZ",
         "COP": "CO", "BRL": "BR", "MXN": "MX", "PEN": "PE", "CLP": "CL", "ARS": "AR", "TRY": "TR", "ZAR": "ZA",
         "SGD": "SG", "INR": "IN", "HKD": "HK", "CNY": "CN", "CNH": "CN", "NOK": "NO", "SEK": "SE", "DKK": "DK",
         "PLN": "PL", "HUF": "HU", "CZK": "CZ", "RUB": "RU", "THB": "TH", "IDR": "ID", "KRW": "KR", "ILS": "IL",
         "AED": "AE", "SAR": "SA", "EGP": "EG", "NGN": "NG", "KES": "KE", "PHP": "PH", "MYR": "MY", "VND": "VN"}
_ERRORES_NOTI = set()


def _res(ctx, nombre, tipo):
    return ctx.getResources().getIdentifier(nombre, tipo, ctx.getPackageName())


def _color(hexa):
    from java import jclass, jint
    return jint(jclass("android.graphics.Color").parseColor(hexa))     # jint: elige setColor(int), no (long)


def _argb(a, r, g, b):
    from java import jint
    return jint(((a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255)) - (1 << 32 if a >= 128 else 0))


def _ctx():
    """Contexto para notificar: la app aunque la pantalla esté apagada o la ventana cerrada."""
    s = _SERVICIO.get("ctx")
    if s is not None:
        return s
    return _actividad().getApplicationContext()


def _icono_chico(ctx):
    """LS con la línea (silueta del APK); Android lo pinta dentro del círculo amarillo."""
    return _res(ctx, "ic_noti", "drawable") or ctx.getApplicationInfo().icon


def _bandera(cod):
    p = _PAIS.get(cod)
    return "".join(chr(0x1F1E6 + ord(c) - 65) for c in p) if p else None


def _par_bonito(par):
    """'EURUSD-OTC' -> ('EUR/USD OTC', '🇪🇺🇺🇸')."""
    base, _, resto = (par or "").partition("-")
    base = base.upper()
    a, b = base[:3], base[3:6]
    nombre = f"{a}/{b}" if len(base) == 6 else base
    if resto:
        nombre += " " + resto.upper().replace("OP", "").strip()
    fa, fb = _bandera(a), _bandera(b)
    return nombre.strip(), (fa + fb if fa and fb else None), a


def _ajustar(p, texto, ancho):
    if p.measureText(texto) <= ancho:
        return texto
    while texto and p.measureText(texto + "…") > ancho:
        texto = texto[:-1]
    return texto + "…"


def _dibujar_tarjeta(ctx, tema, izq, titulo, sub="", etiqueta="", monto="", chip="", punto=None, compacta=False,
                     pildoras=None):
    """Dibuja la tarjeta 'premium en degradado' como imagen (así no hace falta cambiar el APK).
    izq: ('logo',) · ('banderas', '🇬🇧🇯🇵', 'GBP') · ('check',)"""
    from java import jclass
    Bitmap = jclass("android.graphics.Bitmap")
    Config = jclass("android.graphics.Bitmap$Config")
    Canvas = jclass("android.graphics.Canvas")
    Paint = jclass("android.graphics.Paint")
    PaintStyle = jclass("android.graphics.Paint$Style")
    Align = jclass("android.graphics.Paint$Align")
    RectF = jclass("android.graphics.RectF")
    Path = jclass("android.graphics.Path")
    Direction = jclass("android.graphics.Path$Direction")
    LinearGradient = jclass("android.graphics.LinearGradient")
    TileMode = jclass("android.graphics.Shader$TileMode")
    Typeface = jclass("android.graphics.Typeface")
    Color = jclass("android.graphics.Color")
    BitmapFactory = jclass("android.graphics.BitmapFactory")
    m = ctx.getResources().getDisplayMetrics()
    d = min(m.density, 2.0)                 # imagen liviana (Android limita el tamaño de una notificación)
    dp = lambda v: v * d
    W = int(max(dp(260), (m.widthPixels / m.density - 84) * d))
    H = int(dp(52 if compacta else 88))
    a, b, acento = _ESTILO.get(tema, _ESTILO["fija"])
    bmp = Bitmap.createBitmap(W, H, Config.ARGB_8888)
    c = Canvas(bmp)
    rect = RectF(0.0, 0.0, float(W), float(H))
    rad = dp(14)
    forma = Path()
    forma.addRoundRect(rect, rad, rad, Direction.CW)
    c.save()
    c.clipPath(forma)
    p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.setShader(LinearGradient(0.0, 0.0, float(W), float(H), _color(a), _color(b), TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(LinearGradient(0.0, 0.0, 0.0, H * 0.5, _argb(26, 255, 255, 255), _argb(0, 255, 255, 255),
                               TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(None)
    # línea de gráfico de fondo
    linea = Path()
    pts = [(0, .83), (.15, .70), (.27, .77), (.40, .50), (.52, .57), (.65, .30), (.80, .37), (1, .10)]
    x0, ancho_l = W * 0.38, W * 0.62
    for i, (px, py) in enumerate(pts):
        x, y = x0 + px * ancho_l, H * 0.3 + py * H * 0.7
        (linea.moveTo if i == 0 else linea.lineTo)(float(x), float(y))
    p.setStyle(PaintStyle.STROKE)
    p.setStrokeWidth(dp(2.2))
    p.setColor(_color(acento))
    p.setAlpha(70)
    c.drawPath(linea, p)
    p.setStyle(PaintStyle.FILL)
    p.setAlpha(255)
    # izquierda: logo, banderas o ✓
    pad = dp(12)
    s = dp(34 if compacta else 46)
    cy = H / 2.0
    caja = RectF(pad, cy - s / 2, pad + s, cy + s / 2)
    if izq[0] == "logo":
        logo = BitmapFactory.decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))
        if logo is None:
            logo = BitmapFactory.decodeResource(ctx.getResources(), ctx.getApplicationInfo().icon)
        if logo is not None:
            c.drawBitmap(logo, None, caja, Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG))
    elif izq[0] == "banderas":
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if izq[1]:
            tp.setTextSize(s * 0.38)
            tp.setTextAlign(Align.CENTER)
            tp.setShadowLayer(dp(3), 0.0, dp(1.5), _argb(110, 0, 0, 0))
            c.drawText(izq[1], pad + s / 2, cy + s * 0.16, tp)
        else:                                            # cripto, acciones…: círculo con sus letras
            tp.setColor(_argb(46, 255, 255, 255))
            c.drawCircle(pad + s / 2, cy, s * 0.42, tp)
            tp.setColor(_argb(255, 255, 255, 255))
            tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
            tp.setTextSize(s * 0.26)
            tp.setTextAlign(Align.CENTER)
            c.drawText((izq[2] or "?")[:4], pad + s / 2, cy + s * 0.09, tp)
    else:
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.setColor(_argb(40, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.STROKE)
        tp.setStrokeWidth(dp(2))
        tp.setColor(_argb(115, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.FILL)
        tp.setColor(_argb(255, 255, 255, 255))
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
        tp.setTextSize(s * 0.48)
        tp.setTextAlign(Align.CENTER)
        c.drawText("✓", pad + s / 2, cy + s * 0.17, tp)
    # derecha: etiqueta + monto (+ cuenta y temporalidad debajo)
    negrita = Typeface.create("sans-serif", Typeface.BOLD)
    pm = Paint(Paint.ANTI_ALIAS_FLAG)
    pm.setTypeface(negrita)
    pm.setColor(_argb(255, 255, 255, 255))
    pm.setTextAlign(Align.RIGHT)
    pm.setTextSize(dp(18 if compacta else 21))
    pm.setShadowLayer(dp(4), 0.0, dp(1.5), _argb(60, 0, 0, 0))
    pe = Paint(Paint.ANTI_ALIAS_FLAG)
    pe.setTypeface(negrita)
    pe.setColor(_color(acento))
    pe.setTextAlign(Align.RIGHT)
    pe.setTextSize(dp(8.5))
    pc = Paint(Paint.ANTI_ALIAS_FLAG)
    pc.setTypeface(negrita)
    pc.setTextSize(dp(9))
    try:
        pe.setLetterSpacing(0.12)
        pc.setLetterSpacing(0.05)
    except Exception:
        pass
    derecha = W - pad
    ancho_der = ancho_etq = ancho_chip = 0
    chip_txt = chip if not compacta else ""
    if monto:
        ancho_der = pm.measureText(monto)
        if compacta:
            c.drawText(monto, derecha, cy + dp(6), pm)
        else:
            y_m = cy + (dp(5) if chip_txt else dp(13))
            c.drawText(monto, derecha, y_m, pm)
            if etiqueta:
                c.drawText(etiqueta, derecha, y_m - dp(23), pe)
                ancho_etq = pe.measureText(etiqueta)
            if chip_txt:
                cw = pc.measureText(chip_txt) + dp(12)
                fondo = Paint(Paint.ANTI_ALIAS_FLAG)
                fondo.setColor(_argb(40, 255, 255, 255))
                c.drawRoundRect(RectF(derecha - cw, y_m + dp(7), derecha, y_m + dp(23)), dp(5), dp(5), fondo)
                pc.setColor(_argb(225, 255, 255, 255))
                pc.setTextAlign(Align.CENTER)
                c.drawText(chip_txt, derecha - cw / 2, y_m + dp(18.5), pc)
                ancho_chip = cw
    # centro: punto + título / par / píldoras de dirección y nivel
    x = pad + s + dp(10 if not compacta else 11)
    limite = derecha - ancho_der - dp(10) - x                     # fila del par: al lado del monto
    limite_t = derecha - max(ancho_etq, 0 if (sub or pildoras) else ancho_der) - dp(10) - x   # título: arriba
    limite_p = derecha - (ancho_chip or ancho_der) - dp(8) - x    # píldoras: al lado de la cuenta
    pt = Paint(Paint.ANTI_ALIAS_FLAG)
    pt.setTypeface(negrita)
    pt.setColor(_argb(255, 255, 255, 255))
    pt.setTextSize(dp(15 if compacta else 15.5))
    ps = Paint(Paint.ANTI_ALIAS_FLAG)
    ps.setColor(_argb(205, 255, 255, 255))
    ps.setTextSize(dp(12.5))
    filas = 1 + (1 if (sub and not compacta) else 0) + (1 if (pildoras and not compacta) else 0)
    if compacta or filas == 1:
        y_t = cy + dp(5)
    elif filas == 2:
        y_t = cy - dp(4)
    else:
        y_t = cy - dp(12)
    xt = x
    if punto:
        pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.setColor(_color(punto))
        pp.setShadowLayer(dp(4), 0.0, 0.0, _color(punto))
        r = dp(4.5)
        c.drawCircle(xt + r, y_t - pt.getTextSize() * 0.36, r, pp)
        xt += r * 2 + dp(7)
    c.drawText(_ajustar(pt, titulo, max(dp(40), (limite if compacta else limite_t) - (xt - x))), xt, y_t, pt)
    y = y_t
    if sub and not compacta:
        y += dp(18)
        c.drawText(_ajustar(ps, sub, limite), x, y, ps)
    if pildoras and not compacta:
        y += dp(8)
        px = x
        oscuro = tema != "fija"                     # sobre verde o rojo, píldora con fondo oscuro para que resalte
        for texto, col in pildoras:
            pc.setTextAlign(Align.LEFT)
            w = pc.measureText(texto) + dp(12)
            if px + w > x + limite_p:
                break
            caja_p = RectF(px, y, px + w, y + dp(16))
            f = Paint(Paint.ANTI_ALIAS_FLAG)
            if oscuro:
                f.setColor(_argb(110, 0, 0, 0))
            else:
                f.setColor(_color(col))
                f.setAlpha(40)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            f.setStyle(PaintStyle.STROKE)
            f.setStrokeWidth(dp(1))
            f.setColor(_color(col))
            f.setAlpha(120)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            pc.setColor(_color(col))
            c.drawText(texto, px + dp(6), y + dp(11.8), pc)
            px += w + dp(5)
    c.restore()
    return bmp


def _vista_imagen(ctx, bmp, boton=None):
    """Mete la tarjeta dibujada en el diseño que ya trae el APK (Android 12+). Devuelve la vista o None."""
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 31 or not _res(ctx, "noti_tarjeta", "layout"):
        return None
    RemoteViews = jclass("android.widget.RemoteViews")
    TypedValue = jclass("android.util.TypedValue")
    v = RemoteViews(ctx.getPackageName(), _res(ctx, "noti_tarjeta", "layout"))
    for nombre in ("barra", "banderas", "titulo", "detalle", "insignia", "monto"):
        v.setViewVisibility(_res(ctx, nombre, "id"), 8)                  # GONE
    img = _res(ctx, "logo", "id")
    v.setImageViewBitmap(img, bmp)
    v.setViewLayoutWidth(img, -1.0, TypedValue.COMPLEX_UNIT_PX)          # todo el ancho
    v.setViewLayoutHeight(img, 88.0, TypedValue.COMPLEX_UNIT_DIP)
    v.setViewLayoutMargin(img, RemoteViews.MARGIN_START, 0.0, TypedValue.COMPLEX_UNIT_PX)
    v.setViewOutlinePreferredRadius(img, 14.0, TypedValue.COMPLEX_UNIT_DIP)
    if boton:
        texto, color_txt, fondo, pi = boton
        bid = _res(ctx, "boton", "id")
        v.setTextViewText(bid, texto)
        v.setTextColor(bid, _color(color_txt))
        if fondo.startswith("#"):                  # color directo, con esquinas redondeadas
            v.setInt(bid, "setBackgroundColor", _color(fondo))
            v.setViewOutlinePreferredRadius(bid, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        else:
            f = _res(ctx, fondo, "drawable")
            if f:
                v.setInt(bid, "setBackgroundResource", f)
        v.setViewLayoutMargin(bid, RemoteViews.MARGIN_TOP, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        v.setViewVisibility(bid, 0)
        v.setOnClickPendingIntent(bid, pi)
    return v


def jclass_bitmap_logo(ctx):
    from java import jclass
    return jclass("android.graphics.BitmapFactory").decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))


def _pi_abrir(ctx):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    abrir = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName())
    return PendingIntent.getActivity(ctx, 0, abrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _pi_servicio(ctx, accion, n):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    i = jclass("android.content.Intent")(accion)
    i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
    return PendingIntent.getService(ctx, n, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _canal(ctx, cid, nombre, importancia, publico=True, alerta=False):
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 26:
        return
    NotificationChannel = jclass("android.app.NotificationChannel")
    Notification = jclass("android.app.Notification")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    c = NotificationChannel(cid, nombre, importancia)
    if publico:
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC)
    if alerta:
        c.enableVibration(True)
        from java import jarray, jlong
        c.setVibrationPattern(jarray(jlong)([0, 250, 120, 250]))
        c.enableLights(True)
    nm.createNotificationChannel(c)


def _builder(ctx, cid):
    from java import jclass
    B = jclass("android.app.Notification$Builder")
    return B(ctx, cid) if jclass("android.os.Build$VERSION").SDK_INT >= 26 else B(ctx)


def _pildoras(direccion, intento):
    """▲ CALL verde / ▼ PUT rojo + ENTRADA (gris) o NIVEL/GALE (ámbar)."""
    d = ("▲ CALL", "#34D27F") if direccion == "call" else ("▼ PUT", "#FF5A5A")
    t = (intento or "Entrada").upper()
    return [d, (t, "#AEB6C4" if t.startswith("ENTRADA") else "#FFB547")]


def _datos_tarjeta(tipo, titulo, texto, par=None, dir=None, op=None, monto=None, **_):
    """Qué va en cada tarjeta: (izq, título, subtítulo, etiqueta, monto, botón, píldoras)."""
    dinero = (lambda v: nucleo.texto_dinero(v)) if monto is not None else (lambda v: "")
    if tipo == "ganada":
        nombre, flags, cod = _par_bonito(par)
        return ("banderas", flags, cod), nombre, "", "GANADA", dinero(monto), None, _pildoras(dir, op)
    if tipo == "stopwin":
        return ("logo",), "Stop Win", "Meta cumplida", "HOY", dinero(monto), None, None
    if tipo == "stoploss":
        return ("logo",), "Stop Loss", "Saldo protegido", "HOY", dinero(monto), None, None
    if tipo == "mercado_malo":
        return ("logo",), "Mercado errático", "El bot está en pausa", "", "", \
            ("Operar de todos modos", "#FFC266", "#3A2410", "iqbot.OPERAR_IGUAL", 7), None
    if tipo == "mercado_aviso":
        return ("logo",), "Mercado errático", texto, "", "", None, None
    if tipo == "mercado_ok":
        return ("check",), "Mercado óptimo", "¿Sigues operando?", "", "", \
            ("Seguir operando", "#BFF5D6", "boton_verde", "iqbot.SEGUIR", 8), None
    return ("logo",), titulo, texto, "", "", None, None


def _notificar_android(titulo, texto, tipo="ganada", **datos):
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado", NotificationManager.IMPORTANCE_HIGH,
           alerta=True)
    izq, t1, t2, etq, mto, boton, pild = _datos_tarjeta(tipo, titulo, texto, **datos)
    a, b, acento = _ESTILO.get(tipo, _ESTILO["ganada"])
    linea = f"{t1} · {mto}" if mto else t1
    if pild and not t2:
        t2 = " · ".join(p[0] for p in pild)
    b_ = _builder(ctx, "iqbot_alertas")
    b_.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(linea).setContentText(t2) \
      .setAutoCancel(True).setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
      .setShowWhen(True).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    pi_boton = None
    if boton:
        pi_boton = _pi_servicio(ctx, boton[3], boton[4])
    hecho = False
    try:
        grande = _dibujar_tarjeta(ctx, tipo, izq, t1, "" if pild else t2, etq, mto, pildoras=pild)
        vista = _vista_imagen(ctx, grande, (boton[0], boton[1], boton[2], pi_boton) if boton else None)
        if vista:
            b_.setCustomBigContentView(vista)            # cerrada: título y texto normales; abierta: la tarjeta
            b_.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
            hecho = True
        else:
            b_.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("tarjeta", e)
    if boton and not hecho:
        b_.addAction(_icono_chico(ctx), boton[0], pi_boton)
    _NOTIF_N[0] += 1
    nm.notify(77 if tipo.startswith("mercado") else _NOTIF_N[0], b_.build())


def _aviso_error(donde, e):
    clave = f"{donde}:{type(e).__name__}"
    if clave in _ERRORES_NOTI:
        return
    _ERRORES_NOTI.add(clave)
    try:
        bot = _bot_activo()
        if bot:
            bot.log(f"⚠ Notificación ({donde}): {type(e).__name__}: {e}", "yellow")
    except Exception:
        pass


def _app_visible():
    """True si la app está en pantalla (para esconder la tarjeta fija mientras la usas)."""
    try:
        from java import jclass
        RAP = jclass("android.app.ActivityManager$RunningAppProcessInfo")
        info = RAP()
        jclass("android.app.ActivityManager").getMyMemoryState(info)
        return info.importance <= RAP.IMPORTANCE_FOREGROUND
    except Exception:
        return False


def _estado_fija(bot, texto):
    """(punto, título, chip, subtítulo, monto, píldoras) de la tarjeta fija."""
    if not bot:
        return "#F5A524", "IQ Bot", "", texto, "", None
    cfg = bot.cfg
    chip = f"{'REAL' if cfg.get('cuenta') == 'REAL' else 'DEMO'} · M{(cfg.get('temporalidades') or [1])[0]}"
    g = bot.pnl
    monto = nucleo.texto_dinero(g)
    if getattr(bot, "espera_decision", False):
        return "#5CF2A6", "En pausa", chip, "Mercado óptimo · ¿sigues operando?", monto, None
    if bot.pausa_mercado():
        return "#FFA53D", "En pausa", chip, "Mercado errático", monto, None
    ult = None
    try:
        abiertas = list(bot.abiertas.values())
        ult = abiertas[-1] if abiertas else getattr(bot, "ultima_entrada", None)
    except Exception:
        pass
    if ult and ult.get("par"):
        nombre, flags, _ = _par_bonito(ult["par"])
        sub = f"{flags + ' ' if flags else ''}{nombre}"
        return "#34D27F", "Operando", chip, sub, monto, _pildoras(ult.get("dir"), ult.get("intento"))
    return "#34D27F", "Operando", chip, "Buscando señales", monto, None


def _noti_trabajando(ctx, texto, bot=None):
    """Tarjeta fija del servicio. Con la app abierta va en modo mínimo (no se ve);
    al salir o bloquear aparece como la de la música."""
    from java import jclass
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    visible_app = _app_visible()
    _canal(ctx, "iqbot_fija", "Bot trabajando", NotificationManager.IMPORTANCE_DEFAULT)
    _canal(ctx, "iqbot_fija_min", "Bot trabajando (app abierta)", NotificationManager.IMPORTANCE_MIN, publico=False)
    cid = "iqbot_fija_min" if visible_app else "iqbot_fija"
    punto, titulo, chip, sub, monto, pild = _estado_fija(bot, texto)
    b = _builder(ctx, cid)
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")) \
     .setContentTitle(f"{titulo} · {chip}" if chip else titulo) \
     .setContentText(f"{sub} {' '.join(p[0] for p in pild) if pild else ''}  {monto}".strip()) \
     .setOngoing(True).setOnlyAlertOnce(True) \
     .setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
     .setCategory(Notification.CATEGORY_SERVICE)
    try:
        grande = _dibujar_tarjeta(ctx, "fija", ("logo",), titulo, sub, "GANANCIA" if monto else "", monto, chip, punto,
                                  pildoras=pild)
        vista = _vista_imagen(ctx, grande)
        if vista:
            b.setCustomBigContentView(vista)
            b.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
        else:
            b.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("fija", e)
    return b.build()


# ---------- Notificaciones de Windows: tarjetas como las del celular ----------
# Cada tipo trae su imagen premium (degradado + logo LS) y el texto con el par, el monto y la sesión.
_IMG_NOTI = {
    "ganada": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQAAAwADAQEBAQAAAAAAAAAAAAECAwcIBgQFCf/EAF0QAAEDBAADAgcHDgsE"
        "BwgDAAEAAgMEBQYRBxIhEzEIFCJBUWGBFRYyVnF1kRgjN1JicoKSlKGxsrPSFyc0OEJTlaLR0+IkdKS0M0RVY6XD4SU2Q0Vmc3aT"
        "hMHj/8QAGwEBAQADAQEBAAAAAAAAAAAAAAECAwYFBAf/xABBEQACAQIDAwgFCwQCAgMAAAAAAQIDEQQFIRIxQQYTUWFxgbHRFZGh"
        "wfAUFiIyNDVCU1RykiMzUnPh8SVDY9Li/9oADAMBAAIRAxEAPwDmdMFSCmtRxpSEIQDBTUpgoQoFNSmChGNCEIQpMFSCmgKTBUgp"
        "oCkJApoQAqUpgoQoFNSmChCgU1KYKgGgHSEIQpMFSCmhCkJApoQFSlAOkIWCmpTBQg0IQgGCmpVIQpMFIIUIUmCpCaosZAqCgHom"
        "hCwmkE1CFgqh3qB3JgoRlqge5SmFDFmVMKFQQjLCpp6qQmEIZEwVIKaEZkCpQ3qEwhCwqCgd6od6hCwVQUKmlCMpUpQjIUmCkhQF"
        "JgqQUwhiUqClCEKQhCAYKalMFCDQhCApAOlKpCFISBTQAmCkhDEpUpQDpAUhCFEBgpqUwVQxoQhCFJgqQU0IUhIFChDTioHagFNb"
        "zoylSlMFQDQhCBjBTUqgdoQpClUhATBSQhCkwVIKaApUpQEBSEIQgwU1KYKEZQKalUhBgpqVSgBMFJCEKVA7UApoQpCEIQYKalMF"
        "CMoFNSqB2hAQDpCEBkHchSCqUIMJpBNAUFSgJhUxLadFWsYVgqAoFMKVQKELBTSCahiZFQ8yxgqx3IYlpgqQU0IzIqUAqghC29FQ"
        "UBUChCx3qlKYKAoFMd6lUDtQxMiFKpCDBTUqggBUCpQO9QhkQhCEAFUpTBQg0IQgGCmpVIQEwUkIQpMFSCmgKQkCmhGCpSmChCgU"
        "1KYKgGhCFQUhSqQgJgpIQFISBQhiacVKUBbTpSgVSlMFUxKBTUpgqAaEIQhSYKgHSpAUhIFNDEFQO1KEBSpSmCgKBTUpgoRjQhCg"
        "KCApVKmJSAkCmgKQkCmoAVKUBDEoFUpTBQMaEIQgwU1KpCFIUg6VIQoJgqQU0BSoHagFNCFKlKYKEZTT1VrGFYKEKCalUoQyA7VL"
        "GPMsiMjGO5W0qB3KgoYstMKQVQQhaoKAqCGJkCakKkBTT0VKAqBQhaB0KAhCGRMFQCqWJCkwpBTVIUhIFNQhQKpYwqBQFIQhDFjB"
        "TUqgdoAQEIQFISBTQgJgpIQhSpSEBAUhCEIMFNSmChCgU1KpQAmCkhUFISBTQgIQhAadQhC2nRjBTUpgoRlApqVQKpCghTvSN7UB"
        "SYKjekcyCxe0w5Yw5PmQWMm01iBCe0JYyJgrHtAchLGXaeysXMnzoLGUFPaxc6fMEJYyo2sQcq5kJYybTDljDk9oSxl2mCsYKYKE"
        "MiEgdpqEGCmpTBQhQKalUChGCAhCApMFSCmhiUmCpBTQFKlIQEFiwmkE1CDBVrGrB2FTEoFUFA71YUIyh3KwVAVjuUIWFQUNPVUh"
        "GUrCxgqwhClQUqghCwUwdKVQQxZYTUNPVWhC2naagHRVqAYVAqQmjMSkwVIKagKVKQgKmJSYSQO9QFgpqUwUINCEIQpCkHSpACYK"
        "SEIUhIFNACpSmChCgU1KYKAaEIQhQQFKpCFISBTUAJgpIVBSEBChDTYOlSlMFbzpGNCEKEGCjaSEFh7RtSSoLkCRlLlPOsRcvYYd"
        "w0yHNyJKClEVCDp1ZUHkiHqB73H1AFaq+IpYeDqVpKKXFn0UMLVxE1Toxcm+CPKc6XOukbP4OtjoYRLebpVVbm9XdlywRD2nZ/OF"
        "+g7A+EtD9bmltYeOh7W6nf668CXKrBbWzSjKfYvNo6KnyRxzjeo4w7X5JnL3Onzrp/3ocIP66yf2qf8AMR70OEH9dZf7VP8AmLH5"
        "0Ufyan8V5mfzQxH5sPW/I5hD0c/rXT3vQ4Qf11k/tU/5iPejwg/rrJ/ap/zE+dFH8mp/FeY+Z+J/Oh635HMQkT5/WunPejwg/r7J"
        "/ap/zE/elwg/r7J/ap/zE+dFH8mp/FeZPmfifzYet+RzHzp866b96XCD+vsn9qn/ADEe9LhB/X2T+1T/AJifOij+TU/ivMfM/E/m"
        "0/W/I5l5wmHrpn3p8IR/8ey/2qf8xZGcNuGF4+t0UlGZD0Hil0276C4/oT504daypTS/avMj5HYp/Vqwfe/I5j51Yet75B4OTAx0"
        "liuzxIBsQVzeh+R7e72haXyHGbvilaaO70UtNKerS7qyQelrh0cPkXqYHN8JjtKE7vo3P1P3HjY/JMZgNa8LLpWq9a958QcrB2vm"
        "a9ZGuXpHktH0AqwVhB2rafMhg0ZEJApqGLGCmpVIQpCkHSpCAmCkhAUmCpBTQxKVKUwgKB0rWNWChGNMJJhQhYKoLGrB6KkZappU"
        "phQhYVgrGCrCELHeqCgFUCoQoKwoVBUxLBVBQqChClYKhMIYlqgVAKoKMFqlAKoIQaYKSEBYTUqghGMFNSmChiUCmpTBUBYQpVIQ"
        "EwUkIQpCQKaAFSlCEKQhCAYKalMFCFApqVSAEwUkIYlJgqQU0BSEgU1ACEIVBpwFNSmCtx0hQKalPaEsG0iUiVJKFSAuWMuSc7S9"
        "dwxw45xl1Lb5A4UMQM9U4eaJutjfpcSG+1acRXhh6Uq1R2jFXZ9GGw88RVjRpq7k7I93we4PjImxX6/RO9yt7pqU7BqiD8J3n5N/"
        "jfJ3+n4j8eqHFHPseKwU9VXU47J0+v8AZqbXTla0fDI9A00evuRx74jnErXBi1jeKeuq4R2rofJ8Wp/ghrddxdrQ9DQfSFytsDpr"
        "oudyzLJ51P0jmH1PwQ4W6X8a9lkd3Vq08op/I8H9f8UuN+hfGnbdn72Q5jfsrndLebtVVhJ2GPeRG35GDTR9C/DDWjua0exTtG12"
        "9OnClFQppJLgtEeFOcpvam7vrK0PQPoRoegfQp2ja2GJWh6B9CND0D6FO0bS4K0PQPoRoegfQp2jaArQ9A+hGh6B9CnaNoCtD0D6"
        "EcrQQeUbHn0p2jaXB7bE+K2V4dJGKG6SzUjdbo6smWIj0AE7b8rSF0liWeYvxps8tpuNGyOva3mloJnbI/7yF/edekaI840uN9r6"
        "rdc6u0V9NX0FQ+nrKZ4kimjOnMcPP/6edc9m3J7D45c5TWxVWqktNeu2/t3nqYLNKtD+nU+nTeji9dOr4sbN4j8PKzALqGFzqi11"
        "JJpqkjW9d7Hehw/P3heOa/a6nx+6W7jjw2kjqmxxVrh2M7R18WqWjbXt+5O9j1EhctV1FUWq4VNDVMMdTTSOikYfM5p0f0L4MlzC"
        "riFPDYpWq03aXX1/HbxPGz/KoYSca+H1pVNV1dXx7jI1yzA7XyMcs7HL3Dmmj6GlWFhBWRpUNZSEIQhSYKkFNCFISBTQgKlKoIRg"
        "DpWFCbT1QhaYSTCAoFMd6lUChClTSpTHeoQyDuTUtKpCFK2nYWMFUDooYmQKgoBVAqEZYKoKE2lCMyhMKQmEMWZAhSqQjKCpQFQQ"
        "haoFQCqCgLQkCmqAB0qBUpgrExLQkCmqQYKalUEIUgFSntQWLQkCmhATBSQhCkIQgGCmpTBQg0IQgKB2hSqQhSEgU0AJgpIQxKVK"
        "QdoQFIQhQGm0KQdKlvOkGCglJCACVjcVRKxuKGSRjeV0z4N1mjocWud6mAa+tqOzDz5oohs/ncfoXMT3Lq7h87xDgE6aPo8UFdLs"
        "fbbk6/mC5rlXKXyKNKP45JeL9x1fJOmnjXUf4It+C95y1mWRy5ZlN2vMziTWTuewE/BjB0xvsaAvw9rGw6Y0egBVtdnSpxpQVOCs"
        "krLsRpnKU5Oct71K2janaNrMxsVtG1O0bQWK2janaNoLFbRtTtG0Fito2p6o2gsVtG1O0bQWK2janaNoLG5PBvyR9qzt1qc8+K3i"
        "B0ZaT07VgLmH5dBw9q/T8IOyttucMro26judO2Zx9MjTyO/Q0+1a14XTup+JGKSNOj7oxN9hOj+YreHhORtAxiXXlf7Qzfq8gri8"
        "dHmOUFKcP/ZBp91/JHq1lz2SVFL8Ek132XvZoeNy+lhXxMK+qMrojg5o+pp2FkCwtKyhDSzICmpCoKGIJgr22DcIcz4jbfj1jnqK"
        "Vp5XVchEUDT5xzuIBI9A2fUtqReBbxDkiD3V+Oxu1/0b6qXm/NER+dLM3Qwtaorwi2jnZMFbTzPwdeIeDUktbXWQ1dBENvqbfIJ2"
        "sA7yWjygPWW6Wq0NVSlOm7TVikx3JL9GxWS4ZJeKK0WqnNTca2UQwQhwbzuPcNkgD5SQENdm9EfAhbf+pc4sfFT/AMQpf81fjZVw"
        "G4hYVY6m933HjSWumLRLOKuCTk5nBo8ljye8gd3nSzNrw1aKu4O3YzXgKakL7bRa6u+XShtdBF21dXTspoIuYN55HuDWjZIA2SBs"
        "kBDSlfRHzA7Qtu/UvcV/ir/4hS/5q+W5+DhxOs1trLjW4wY6OjhfPM8V1M8tY1pc48rZCToA9ACVbM3PC10ruD9TNXjuTUNOitqW"
        "nwdOJd8tdDdKDGu2oa6BlTBL49TN543tDmu0ZARsEHRAKljVClOppCLfYawCsFfRdrVV2K61truEPY11DM+nni5g7kkY4tcNgkHR"
        "B6gkL5goa2mnZlKgV7vD+C+c57aPdbH7Eay39o6HtTVQxbc3WwA94J7x11pfv/Ux8Vfit/4hS/5qtmbVha0ltRg2uxmpwVYPRfpZ"
        "JjV1w+91VlvVIaS50paJYS9r+XmaHDq0kHYcD0PnX5bToqM0Si07PeZAU1sy1eDzxIvdsornQ4521DXQsqIJPHaZvPG9oc06MgI2"
        "COhG19v1M/FL4r/8fS/5qWZu+SV2rqm/UzVLSrW0ZPBs4owtLnYs4gfa1tM4/QJF4rIsKyLEZGsvtkrrfzHTX1ELmscfuXdx9hSz"
        "NdTD1aavODS60z8QJgqQVSxNBQVBfrYril4zS8RWixUZrLhK1z2xB7WdGjZPM4gDp6SvfjwbOKHxY/4+m/zFlZs2Qw9aorwg2upN"
        "mrEwV7PL+EuY4DbobhkNmNFRzSiBkvjEUoLyCQNMeSOjT3+heLWNuBhOnOm9mas+ssFUCoBVAoYFIQDtCEYwVQKhMFQhaFIKpUhS"
        "EgU0ICoOUoUBk2hSDtG0IUFSlMFCWGhLae0AwU1KoIQEAoQhCkwVIKaApCQKaEYKlKAdIQsFCSEBptMFJC3HSFIKW0HuQpJWFxWV"
        "ywvQyRhkK6uwv+bzJ811v6ZVye/zrrDC/wCbzJ81136ZVzHKn+zR/wBkfBnXck/tFX9j8UcdNPkt+QJ7UNPkj5Antdvc+Qra2LwS"
        "xm15dnsNsvNKKqhdSzyGPnc3ymgaO2kHzrXG1tvwbT/GjT/7jU/qheZnNSdPL684OzUXZrfuPsy+MZ4qnGSum0dBfwDcPvi838qm"
        "/eXOfHfFLRhuZU9vslGKSkfQxzGMPc/by54J24k9wC7TXInhP/ZDpPm2L9eRcBySzDF18xUK1WUlsvRybXDpZ1Oe4WhSwm1Tgk7r"
        "ckjTG0bU7RsDv7l+pXOKPVYLgV44g3f3PtUbQ2MB09TLsRQN9Lj6T5gOp+krpvG/Bxw+zwsNzZUXmq15T6h5ji36o2EdPlJX73BT"
        "GIMY4dWdrI2iquETa2pfrq98g2N/I3lAXsb7e6PG7PXXa4SGOioojLK4DZ0PMB5yToAekr8pzzlJjMVipYbCScYp2Wzvk929a6vc"
        "kdxluUYejRVWuk5NX13I883hPgzY+QYnaOX1wbP09685f/B6wi8wuFLQy2qoI8mWilOgfWx22n8y8HUeFfGKsinxVzqQHoZazlkI"
        "+QNIB9pW6sFzm18QbEy62wyNaHmKaCUAPhkABLTroehBBHQhfDiKOeZZFYirKcV07V/Xq/afRSqZbjG6UFFvst6tF7DjriPwxu/D"
        "e4RxVhbU2+oJ8WrYmkMk13tI/ouHo9oJXiNrvniNi8GYYVeLXKwOkfA6WBxHVkzAXMcPaNfISuAwdgHu2N6X6ByZzqeZ4Zur9eDs"
        "+u+5+PqOWzjL44Kstj6st3kXtG1O0bXSXPIPV8NT/GHivzlB+uFvrwnv5PjP39R+iNaD4aH+MTFfnKD9cLffhP8A8nxn7+o/RGuO"
        "zb79wn7ZeDPWX3Nie2Pijn+Mr6oz3L4419ca6E4SZ9LCswWBizDuUZ87Mg7lt/wdeEzOK2cdhXh/uDbGCpreU6Mg3pkWx3cx37Gu"
        "110tPtK7o8CC2xRYFkdyDR21RdPF3O85bHExw/PK76VVqz6cDRVWuoy3G+7/AJBjnDDFTW3CSntdkoGNjjjjZoD7WNjG95PmAXPd"
        "Z4cOPx1hZSYtc5qQHQllnjjeR6eQcw/OvIeHBkFTJk2M2DtHCjgo3VxYD0c973MBPyCM6++PpXKaspNbj78bmFSnVdOlokf1H4Yc"
        "X8a4s22aqsU8rKmm0KiiqWhs0O+4kAkEHR0QSPkPRcs+FxweosUrqTMbHTMp7fc5jBW08bdMjqCC4PaB3B4Dtju2PulqvgHxFpeG"
        "PEeivVxknbaXQzQVYgbzOcxzCWjl2N+W1h9i3jx18IvA+I3DO62G1+6Rucz4ZKft6YNYHNlaXbPMdeRzfSl7rUTxVPFYV860pL49"
        "pyGF0D4H+M+7fFgXJ7Nw2WkkqNnu7R/1to+XT3H8Fc/LuXwKcZ9z8Ivd/kZqW6VghYSO+OFvQj8J7x+CsY6s8/L6XOYiPVr6ja3G"
        "Pig3hZZ7JXlkEnj90go5Gy78mEkmV40R1DWnR7tkbBXoOIuNjMMEyKx8oc+vopY4t+aTlJYfY4NPsXJvht5J41lGN4+x+2UNI+rk"
        "A+3ldygH1gR7/CXUvCPJPfdwzxa8F/PLUUMbZXemVg5JP77XLO93Y96nXVWvUoPcl/2fy30WuLSCCOhB8y9hwn+yng/z3Q/t2L7O"
        "NmM+9HirlNsazkhFY6eEa6COXUjQPkDwPYvi4T9eKeD/AD3Q/t2LXxOYjBwrKL4P3n9N8pvfvaxi9XrsPGPcyimq+x5+TtOzYX8v"
        "No63rW9HXoRbK2kyzGqOtDA6hu1GyXkJ3uOVgOvocvyeKX2Ms0+Zq39g9eK8GDIffBwasYc/mmtxkoZPVyOJYPxHMW3ide6n9ZU3"
        "xV/afz6yC0S4/f7paZ99tb6qWmfv0seWn9C/pvwo+xbhHzJRfsGLhjwocf8Ae/xlvbms5YLkyKuj9fO3Tj+O167n4UfYtwj5kov2"
        "DFjHeeRlVPm8RUh0eZ/Ovi39lPNvnms/bOXkGlev4tfZTzb55rP2z18XD/HDl2b4/Yw0llfWxRSa80fMOc+xuz7FgeJUi5VXFb2/"
        "ef0S4J4170+FeL21zOSbxRtRKD3iSXcjgfWC/XsWHhnxNbn93zWhDIW+4F0dSRGLf1yHqGvdsnZLmSdRoa10XqcuvkeKYneby4ND"
        "LbRy1DW+YljCQ32kALjPwQcnfRcTq+2zylwvdG/vPV80Z5wfxe0+lbG7NI6ipWWHq0aC3PT3L2n2+GTjfufm9nvsbNRXSjMTz6ZI"
        "naJ/Fewexc3ru/wucb92OFoubGbms1XHOSO/s3/W3D6XMP4K4OafMsJbzwM1pc3iZdevx3nbXCvwl8TNrwrDvc+9+6fYUVp7XsYu"
        "x7XlZFzb7TfLzdd63rzeZdCXu7U9gs1xu1WHmlt9PJUyiMbdyMaXHQ850Cv5o8K/sn4V89UX7di/olxO+xtmPzPWfsHrOLuj2Mtx"
        "dSrRk5/h3eo1pTeFrw8nlayQ3aBpPV8lICB+K4n8y2parxjfEfHnTUU9FeLNVAxyNLQ9h9LXscNg93QgFfy7C374JWT1Vr4lGytk"
        "d4leKaRr4t+T2kbS9rtekBrh+EsVPXU+TB5tUqVVSqpNPQ/N8IThDFwyyGCqtbX+9+6czoGuJcaeQfCjJ846ggnrrY662dOArvLw"
        "qrVHX8Ia6pe0F9uqqeoYfQS8R/okK4LBWMlZnnZph40MQ4w3PU6i8DfHO2vORZBIzyaaBlHE4+cvPM7XrAY38Zb9zfiQ3Ec0wiwF"
        "kLmZBUyQzOfvmjaAAwt66BMjmjrvoD8q854MWO+4PCa3TPZyz3WWStfsddE8rP7jGn2rnvwl8vml4ytdSSadj8cEcRHcJAe1J+Xb"
        "wPwVl9WJ66qPA4CDW9te138NDprwgcd98nCfIIms5p6KMV0fqMR5nf3Oce1fz1BX9RaKppMnx+nqQ0SUN0pWyBp7nRyM3r6HL+Zm"
        "RWeXHb/dLRPvtrfUyUzifOWOLd+3SlRcT5M+pLahWXFW+PWfnBUpBTBWs58sFUCsaoFAUhIFNGQpAOlIVKEKTBUgpqkZSEtp7QgK"
        "lKAdKAsFNSmChBoQhCMoHaFKpAMFNSmChBpgpIQhSEgU0ABUpTBQg0IQhDTgKalUDtbzpQQhIqAT1gcVmcVgf50M4mB66wwv+bxJ"
        "81136ZVye9dYYZ/N3k+aq79Mq5jlT/Zo/wCyPgzruSn2ir+x+KON2nyR8gRtQ0+S35AntdsfIVtbd8Gw/wAaVP8A7jU/qhag2tu+"
        "DWf40qf/AHGp/VC8rPfu2v8Atl4H25b9rpfuXidmLkPwofsiUfzZF+vIuvFyD4UR/jFpPmyL9eRfm/Iz7zX7X7jruUP2N9qNLbRv"
        "fT0qdo2v104Q7x4QZDBknDmwVEL2mSnp20k7QerJIwGkH2AH5CF6q82eiyC1VlruMImoayMxSxkkczT6x3Hz79S4W4e8S71w4uT6"
        "m2uZNST68Zopt9nMB3Hp1a4eZw/OF0zjfhH4XeYmC4Tz2aqI8plVGXR79UjARr5QF+TZ1ybxuFxMq+Fi5QbunHeuO5a6dKO5y7N8"
        "PWoqlWaUkrO+5+7XoPG33wVGOke+x5GWMJ8mGvg5ternZ3/iry7uEXFjA4Kn3Bq5X08hD5BaK3lc8gaBLDyknXo2un7Rltgv+vcq"
        "926tJ7mwVLHO/F3v8y/ZI8xH0rTHlRmdH+liUpronH/r2mx5Lg6n06N4vpi/+zgut4h59b6mWlrMkv8AT1EZ5XwzzvY9vytPVeN2"
        "u8OJXDW2cRrLLT1EUbLrGw+J1uvLif5gT52E9CD6djquEJ4ZKWeWCZhZNE90b2n+i4HRH0hd7yezXDZhSlKlTUJK20lbufC639hz"
        "GbYGthZpVJuUXub9pO09qNo2uiPJPWcMz/GJinzlB+uFv3woP5PjH39R+iNaA4Zn+MXFPnOD9cLf3hQfyfGPv6j9Ea4/NfvzCftl"
        "4M9Vfc2J7Y+KOfYz3L6o18ka+uJdCcLM+piytWFnRZmqHzMsLvbwJPsVXj58m/5enXBIK7t8CGtjk4dX+jDh2sN3dK4egPhiA/Zl"
        "ZR3n35X9oXYzVXht/ZQsvzLH+3nX4PBDwcf4Y8br7x75fcrxSsNJ2PiPb82mMdzc3aN18PWteZeu8OC0zxZpjV2LD4rU240rX66c"
        "8crnEfRK1a64TeEPfeENirLRa7XbauCqqjVOfVB/MHFjW6HK4DWmBHa+pa3NLGS59aG5PqFf/r7/AMH/AP8AdeQ4o+Cb/Btgl2yj"
        "33+P+54iPi3ub2Xac8rI/hdq7Wuffce5bK4K+E5lPFDiFbsdq7JaoKGaOaWeanEnPG1kbiCNuI6u5R3edbJ8KH7BWW/e03/MxJZW"
        "PreGwlWhOrSjuT6d9u0/m0Cv6l8HMZ95/C/FrQ5nJNDRMkmb6JZPrjx+M8r+cHC/GffjxDxqxlnPFWVsbZh/3QPNJ/ca5f1XSC4m"
        "GTU/rVO749h/Mfj5kvvq4vZXWtfzQxVRpIiD05YQI9j1EsJ9q6l8C/JPdLh3c7K9+5bRXEtb9rFKOYf32yLcsnCrA5pHySYTjT5H"
        "kuc51qgJcT3knkX6tixHHsXdO6x2K12t1QAJTQ0kcBk1vXNyAb1s636Sqlrc+nD4GpSrus5Xvf2nHnhr4z4lluP5BGzUdxpHU0hA"
        "/pxO3s+stkA/BWjeE32U8H+e6H9uxdreFzjPu7wjqK6NnNPZaqKrBA68hPZuHyaeCfvVxTwm+yng/wA90P7dixktTy8fT2MYn02Z"
        "/SLil9jHNPmat/YPXOXgRZDzU2V4+9/wHxV0TfTsFjz/AHY10ZxS+xjmnzNW/sHrhzwU8h9wuMdrhc/lhusE1E8+bq3nb9Lo2j2r"
        "J70eli6nN4uk+716G0PDcx7UuKZAxnwmy0Mrvk0+MfnkXSPCj7FuD/MlD+wYvC+FTj3u9wcusrWc01rmirmD5Hcjj7GPcfYvdcKP"
        "sW4P8yUP7BicTdSp7GMm+lJ+4/nVxb+ypm3zzWftnLafge437r8TZ7s9m4bNRvka70SyfW2j8UyfQtV8Wjvipm/zzWftnrrXwNMa"
        "9zeH1zvcjNS3etLWu18KKIco/vukWK3niYKlzmM7G36v+T93ws8j9xOEtRRMfqa8VUVIAD15Qe0cfk1Hr8JcW8Msj96fEHG7yX8k"
        "VJWxmU/90Tyv/uly/phe8YsmTRwx3uzW65xwkujbXUzJgwnvIDgdexfjfwVYH8Sca/sqD9xVxbdz1cXl9SvWVWMkrWsfoZtjzMsx"
        "C+WR4H/tCjlgaT/Rc5pDT7Do+xfyxkjfDI6N7S17CWuaR1BHeF/WtrQxoa0ANA0AO4L+a3HXG/erxYyehazlglqTVRADpySgSAD1"
        "DmI9iTPmzyleMKncfl8KjvifhXz1Rft2L+inE77G2ZfM9Z+wev508Kvsn4T89UX7di/otxO+xrmXzPWfsHpHcTKP7FT44H8wwVt7"
        "wZPs2Y397U/8tKtPgre3gnWKoufFaC4xsJprTTTTSv10BewxtG/Secn8ErBbzxsEnLEU7dK8Tpnwl/sJZR//ABf+aiX8/wC30c1y"
        "rqWip289RUythjb6XOIAH0ld5+FLcI6Pg1d4XuAdWz08DB6SJWyfojK5Y8HHHPfJxcsTXs5oLe51fJ6uzG2H8csVnqz082p87jIU"
        "1xSXtZ33Z7dTY3YKG3xuDKS20rIGuPQBkbANn2BfzNyy+vybKLzeX75rhVy1AB8wc4kD2Agexf1BmhjqYZIZo2SQyNLHse0Frmka"
        "IIPeCF5b+C7BviZjn9lwfurOUbnp5hgJYqMYwdkjyXg25D7v8I7MHP5p7cX0Mnq5Dto/EcxczeFFjvuFxWq6pjOWC7U8dY3Xdza5"
        "He3bCfwl3DZsftGO076ez2uht1PI/tHxUdOyFrnaA5iGgAnQA36lzx4YuO+M47j9/jZt1FUvpZCPtZG8wJ9QMevwlJL6JozHDS+Q"
        "qMtXC3s08Dj9UCsYKoFajkSwU1AKYOlAZAUwVAKpAUmCoT2ljEtMFSCmoCkJApqkKQpB0qUAwU1KYKEZQKalUDtCAgHSEIQpClCE"
        "MgQoBTQFKlKAdILFIQhCDBQkhCWNOoQhbzpBnuSQhAS5YX+dZXFYXqGcTA9dYYZ/N3k+aq79Mq5Pf511hhn83aX5qrv0yrmOVP8A"
        "Zo/7I+DOu5KfaKv7H4o4zafJHyBPaxtPkj5AntdqfIXtbe8Go74p0/8AuNT+q1ae2tv+DSd8VKf/AHGp/VC8rPPu6v8Atfgfdlv2"
        "ul2rxOz1zB4Q+DZNkudUtZZ7FX19K23xRmWni5mhwe8kb9PUfSun0ui/H8qzKpluI+UU4puzWvWd9jsHHGUuam7LfocD/wAEud/F"
        "K7//AKP/AFUycK83p43zTYndmwxAveTB0DR1Pn9AXfXT1L4b3r3Fufd/JZv2bl1EOXGKlJJ0o+3zPFlyboJN7b9nka7ouBHDiuo6"
        "aqisZdFURMlY4Vk2iHNBB+F614vixwBtdNi/jmF2eRtzpZRJLCyZ8j5odEENDidkHR0Op0Vn8Hvi9Q3Gx0GJ3mpZT3OjjEVHJK7T"
        "amIfBZs/0292vONa67XQB6HR6FeZisdmmU47Zq1JPZeibbUl69z9naj7KOGwWOw21CCV1wSumfzYfDNBUdm+KSOoYdcrmFr2n5O8"
        "FdkeDu7Kn4fUnIzVmm7Zvuea3fa9ny+V8LyuTetb9eui24Yo3Sdo6Nhk+3LQXfT3qydnqdkrbnXKj0nh+Y5lR3a3u+7RW8jDLsl+"
        "R1ed5y/Va3r1Y2/Cb8oX88M2niqMzyKaAgwyXGocwju12jl15xj4t0GA2apoaSojlyWpjLIKdp2afY12r/RrvAPUnXm2uOLJjl4y"
        "epfBabdU10zBt/ZN3y787nHoPaV7nInA1KUKmLqK0ZWSvxtvfZ0d55XKfG0ls03JfRu2+CPzdo2v0r7jd4xmobT3i21NFK8bYJma"
        "Dx6j3H2FflbXfJp6o5eE41IqUHdPij1vDI/xi4p85wfrhdAeFB/J8Y+/qP0Rrn3hkf4xcT+c6f8AXC6C8KH+T4x9/UfojXIZr9+Y"
        "T9svBnsL7mxPbHxRz5H3L6o18ka+uNdEzhJn0sWZp6rAw9yzhQ+dlre/gscVaXhznE1DdpxDZL6xkE0zjpsMrSeze4+ZvlOaT5ub"
        "Z6BaHCaJ2ZlSqypTU470f1a4j8OLHxUxmSy3qNxiJEsFTCQJIJNdHtPd3EjR6EFcq1vgO35lY5tFlVtlo99HzwSMk196OYfnWt+G"
        "vhOZtw5o4ba2aC72eEBsdLXguMTfQyQEOA9AOwPMAtru8OqpMHK3BoRPr4ZuZLd/e9lv86zunvPXniMFiPpVVZ9/uNycHeCeO8DY"
        "zPU3aKrv92c2kFXPywhxO3CGJpJPXl2epJ5d9NL6fCh+wVlv3tN/zMS4zyHwjMvybObLlNb4ofcSYzUVua1wpoz3Ekc3M4kd5J36"
        "NDov2M/8KfKuImI3HGrjabLBRV4jEklNHKJG8kjXjRdIR3sHm7lLqxPl+HVGdKCsrNL1HoPAvxj3U4j3G9yM3FZqI8rvtZZTyt/u"
        "CVdC+FRm1bhfCuV1srqihudxq4aWGoppTHLGATI4tc0gjpGWnX23rXHPCrjxkHCCguNJYrdZ5xcJWyyy10Ur3+SNBoLZGjQ2T3ec"
        "rHxW455JxggtcF8prbTQ250j42UEcjA9zw0bdzvdvQb01rvKidlY0UsZTpYR04/Wfv8A+D8McWs/+POT/wBrT/vr03DzjTmFsznH"
        "aq6Zdfqu2R10XjUNVcZpI3xFwD9tc4g+SSeq1QqB2sbnmqtUi09p6H9asssMWU4vebJNrs7jSS0xJ/o87CAfYTv2L+ZnC6nlpOLm"
        "GU8zCyaK/Ucb2Hva4VDAR9K2pR+Gfn9JSQU/uZjsvYxtZ2ktPOXv0NbOpgNnz9Fpr361oz5uZx0tHHcm3MXUQMY7sBKJe01y83Ny"
        "8w7ubevOspNM9DHYujXlCcOG8/pfxT+xjmvzLW/sHr+Y2J3x+M5PZrzHvnt1ZFUgDz8jw7Xt1pbmv3he5vkdiulmqrVjrKW5UstJ"
        "K6KnnD2skYWktJmI3onWwVoFJO5hmOLhXnGVPgf1lyK0wZbit0tfO11NdaKSAP7xyyMIDvz7WLCLLUY1heOWWrfE+qtlup6SV8RJ"
        "Y58cTWOLSQCRsHWwPkXEFj8MDOrFZbdaordj80VBTx0zJZ6eYyPaxoaC4iUAkgddAL9D6tTPv+yMZ/Jp/wDOWW0j0lmmGvtu97dB"
        "qXi2dcVc3+eaz9s9f0Z4W417z+HeNWUs5JaWij7ZvolcOaT++5y/mdc8nqbxl1XktVT0rqurrnV8sHK7sS90nOW63vl2da3vXnW8"
        "/q0s9P8A8oxr8mn/AM5YxaR52AxVGjUnUnx3Hn+M3F/K6jijk7bPlN6obbT1bqWGCjr5YomiICMkNa4DqWk+va8MOK2e/HfJf7Vn"
        "/fXkp55KqeWeZ5fLK4ve497nE7JUArFu551TEVJTctp6ne3gm5zcMvwi6Ut4uNVcLlba3rNVTOlkMUjQW7c4knymv+ha08NLG/F7"
        "/jmQxs8msp30cpH20buZu/WRIfxVpbhbxgv3CSquNRZIKCf3QYxk0dbG97PJJLSOV7Tscx8/nX7PEvwgcj4q2KC0Xq22WGCCobUx"
        "y0cMrZGuDXN1t0jhohx2NehZbWlj0Z42nUwfMzf0l5+RuvhV4LlJ2WE5r75Zu15aK7+KeKDW/Il7Pm5+7zb17F05kVmZkWP3azyy"
        "uiiuNJLSOkaNlgkYWkj1ja4cx/ws80xyw2uzUtrx99LbaWKkidLBMXuZGwNBcRKBvQG9AL9H6szPP+yca/Jp/wDOVTSPpw+OwVGG"
        "zFNX37zZtN4F+NMlaajI7tJFvq2NkbCfaQf0LeGEYBj3DezG3WGjbTU5PPNK93NJK4D4T3Hv/QPMAuQZPDIz2RhDbbjsZP8ASbTT"
        "bH0yla/zLjjnOd08lJdb5I2gk6OpKVohicPQ4N6uHqcSm0luMI4/A4f6VGGvxxZsPwoOLdHnF5pMfstQ2ez2l7nyVDDtlRORrbT5"
        "2tGwD5y53m0V7LwMcc6ZNkcjP6ughd/fkH7NckgrbvDzwh8l4aY42xWe22SSlEr5nSVUMrpHudrZJbI0dwA7u4LFPW7Pgw+Mi8X8"
        "or/HBHQHhZ53c8WsePW6zXOrt9dXVL53zUc7opOzjbrlLmkHRMgOvufUuVRxSzn46ZH/AGpP+8s3EvijeuKt3pLleYqOCSlg8Xji"
        "o2ObGBzFxOnOcdnfp8wXiwVJO7NWOxjrVnODduBvfgPxVyU8UrFS3nJLvX2+ue6lfDWVskrOZ7SGHlc4jfPy9fWuruNWOe+nhdk1"
        "A1nNM2lNTEB388REgA9Z5de1fzntVyntFyorhSuDamjmZPE4+Z7XBw/OFvl3hg5vI1zH2jG3NcNEGmn0R/8AuVjLSzPrwOYU4UJ0"
        "a7evfvRoAFND3B73ODQ0Ek8re4eobSBWB4VigVQKhPaELTDlIO00BkQoB0q2gGqDlKFCGQFUsYTB0oQtG0to2qQraNpbQgLDtp7W"
        "NUhC9gprGCqQhSFKEIUntSCmoCgVW1AKaEKBVLGmChC0KUIDT4QpVLcdIwQhIoCHLE9ZXLC9UzRgeuscM/m6y/NVd+mVcmvXWOG/"
        "zdZfmqu/TKuX5U/2aP8Asj4M67kp9oq/sfiji9p8kfIE9qGnyR8gT2u0ufIVtfsYzlN1w+6tulmqvFq5sbohJ2bX+S7vGnAjzL8X"
        "aNrCpCNSLhNXT3pmUZSg1KLs0bP+qD4i/GD/AISH91H1QfEX4wf8JD+6tYbS2AN76L4fRGA/Ih/FeR9Py/Ffmy9bNofVB8RfjB/w"
        "kP7qxz8fOINTBLDLf+aOVjmOHisPUEaI+D6CtZhwPcQfkT2iynALdQh/FeQePxXGrL1sY0AB5gve4/xoznGYWU9Ff55KZg02Gsa2"
        "oa0egc4JHsK8DtG19VfDUcRHZrwUl1pPxNFKtUpPapyafU7G6GeE/nTWBrhZ3H7Y0Z3+Zy/BvfHrPr3E+KS+uo4XDq2hibB0++Hl"
        "fnWDEODGUZZ2c5pvc23v6+M1oLS4elrPhO/MPWt94hwTxjFjHPNAbpcG9e3rGgtafuY/gj27PrXlPL8soS2o0Y37EeVmXLKOFThK"
        "s5y6E/F7vf1HPGLcM8pzmXxmmpJGU0ruZ9fWuLWOPnOz5Tz8gK6rwXEafCcapLRC5kkjNvnnazl7aQ97tfQB6gsGWcR8bwphbc7g"
        "zxoDyaOD65MfVyj4I+XQWm63wma83PmorFSi2gEdnUSu7V3rLm9B8mj8q+iTq4hWSsji8TUzXPo/Qp7NNarhfve/u0Nq8YrdR1/D"
        "m+OrGs/2WHxiF572StI5SPl3r17XGpPVe/z/AIv3nPaZlDLFDQ2xrg808BLu0cO4vce/XmHQLX219eGpypwtI6fk9l1fAYZ0671b"
        "vbo3HreGJ/jGxP5zp/1wug/Ch/k+Mff1H/lrnrhif4x8T+c6f9cLoXwof5PjH39R/wCWuZzT78wn7ZeDOzX3Nie2PijnyNfXH5l8"
        "cfevrj8y6E4WZ9LfMszVgYsw7kPnZkCalpVIYAqUoCEKB0qUpgoQYOlSlMFQDQhCEKVBQE0MSlSlMIBqlKYKEY1SlMFCGQFNQCqB"
        "QFhUCoBTB0oQyAqljCoFDFlBWCoQChDKCqBWMFUChDKChSCmChCwVYKxKg5QjMioFQCmhjYsFNQCmChCt6Vh21G0IQyJgqAU9oC1"
        "QO1AO00BSpRtNSxCwU1G0w5CFJ7U7TQhSApVICkwVCEJYyIUAp7QhSe0ghCWHtVtQmCoCgU1KYKEKBQkhBY0+mCoB0qW86QZ7kto"
        "30SKgE7uKwvKynuKwuVMkfO/vXWWG/zdJfmqu/TKuTXrrThWw3vgS6hj6yupq6l190efX6wXL8qtMPSk9ynHwZ13JT7TUj0wfiji"
        "hp8kfIE9qG7DWg9DobCe12dz5CtptBc5rWglzjpoA2SfQAto8MeDFVnlELtV1wobT2jo28jOaWYt+Fy76NAPTZ38i6MxXhxjWFsD"
        "7ZboxUtHlVc/1yY+vnPwfZoL5quKhB2WrOdzLlLhcFJ0o/TmuC3Ltflc5uxLgblOS9nPUwNtNC7r2tYCHuH3MY8o+3S3riXBLFsX"
        "Mc0lMbpXt6ietAcAfuY/gj27PrSy7jdiuLGSGOqN0r29DBREOAP3UnwR7Nn1LRGW8dMpybtIaacWmhd07KjJD3D7qQ+UfZpfP/Xr"
        "dSPF/wDNZx/8VN93/wCn4HTeQcP8ZyZmrpZaSV+tCZjOzkHyPborU+ReDTSy88tgvEkDu8U9c3nb8ge3RHtBWkbDneSYzJz2u81k"
        "DSdmMyc8bvlY7YK2vjvhMV8HJHf7RDVM7jPRO7J/ylh20+whXma1L6juZeiM5y7XB1duPR/xLT1O5+XZfBzyasuD4rpUUdBRxnRn"
        "ZJ2zpB9w0a/vaW8MQ4TYxhxjlpKHxq4N/wCuVepJN/cjub7B7V5a5eEditPbhPQwV9ZWOHSmdF2XKfunnY18m1pTMOMuUZf2kLqv"
        "3Pt7+nitESwEehz/AITvpA9SmzXraS0Ri8PnebfQrPm4ceHs3vv0OkMw4vYvh5kinrfHbg3/AKpRkSPB+6d8FvtO/UtBZfx4ybJO"
        "0goXiz0DunJSuJlcPupO/wDF0tWb9CNr6KeGpw13s93L+TWDwdpSW3LpfuW7xfWW55e5z3OLnOO3OJ2SfST50tqdo2voue/YraNq"
        "do2lynruGB/jHxL5zp/1wuh/Ci/k+Mff1H6I1oLg3RPuPFPE4WAktrmSu9TWAvJ+hq3n4UNUHVGMUoPlNjnlI9RLQP1SuRzN3z3C"
        "pcIy8JHqbsmxDfFrxiaFjX1M8y+SPzL62eZdGcLM+lncFmb3LBGszVD52WF99qtVbfK+Ggt9NJU1k55WRRjZP+A9Z7l8AW5+BHLb"
        "7bnF8jY01ttt4MLnDettkcfzxtWMnsq58+IqulTc18X0Phj8HzK3RNL6i0xzuGxTvqT2n5mkfnWvshxu6YtcX2+7Uj6apaOYB2iH"
        "N+2aR0I9YXx1Fwq6ytfWz1MstY9/O6ZzyXl3p337W4eIdTJkPBnDr7XO7W5NqDTGZ3Vzm6kBJPnJ7Jp+VYttNXNG3VpTiqjTUnbd"
        "azNLApreeV8H8Mw+shqLtkdZSWqWPTIiBJUyy7PNrlZoNA5fMepPUdN+dyfhlaDi8uTYdeJLnbKY6qIp26li7tnuHdsbBA6deqqq"
        "JiOMpTs1ez4209Zq8FNexwPAzlxrq2srmW2yW1ofVVjxvW+5rR5z09nr2AfXUnD3A8qe+34tlVW688pdFFXREMmIGyB5DfR6z59K"
        "uSRlPEwg2nfTfpu7TUIKa2Dwz4e02V5fcrFe3VdK6hp5HvFO5rXtkZIxhBJBGvKKx5VjuG2S2Opbdfaq4ZJDI2OVrGap9704A8vX"
        "Xp5lNpXsX5RDb5tavzPBKgtuP4dYRjNPRw5ZlFQy6VMYl7K3t52Rg+khrtj19N+heW4iYF7yKyhfTVorbVcou2pajWi4dNg+buc0"
        "7HftFJPQxhiac5bK47tN/YeMBVLZOL8NLdLjbcmyu7m1WiV3LAyNvNLN39R0PoOgASQCegX113DXH73Yq66YTfJ699vbzz0dUzUv"
        "L1Ox5LfMDrp11376KbaMXiqalbuvbS/aeTsmB3a/Y3dL/SeL+I23m7UPk093K0OdyjXmBB6kera8yticPsbZfcQzWoluNxp226l7"
        "dtPTT8kUzgyRwEjdHmG2D0edfnYBgEmZyVlRPWMoLPQN56mreN8vQnQ9egST3AewFtWvcc8oue29F8d58VRhNfRYlTZJVVFJBSVT"
        "+Sngke7t5uuttby610J2SOnyjfm1ugYliGbuhtNoze6VNzpoyykiuPM6LQHwWAtboaA6A9w7jpec4fcOIcgzO549fXVNM+hgke4U"
        "z2h3O17G95aQRpxP0Ip6amuOJioyc+Gu62hrsFUCtr0GBYJDVMs13yqobf3O7N7aZv1iKQ9OQuLCCQehOx19C8PmmJ1OFZBPaqmQ"
        "S8gD4pgNCRh7jrzecH1gqqSbsbIV4Tlsrf2H4QKoFKGN80jI42l0jyGtaO8k9wW26nhtieJ0dNHl+RVEF2qGB/i9GzmEY9fkuJHr"
        "6b0dI5JFq1Y07J72anBVArZ9dwxtdFgV4yKK5yVpgmb4lNC5oimhLo27cwjmDgXPBGx1b9PxYxgtjfjbMhyi9uoqGaQxww0wDpXH"
        "r39DruPTXd1U2lvNfymm4uS6bd5r8FNbDynh/aYMY982MXWWvtUcgimbO3UkZJA9A85A1od4PVY+G2A0ucUGQummnjq6GJhpgx7W"
        "sc9wk1z7aem2ju1502la5HiIbDnwR4EHSoHa2tacCwS8VDbRS5XUy3twLWvbFqB7wOobtvX8br5l4ynwqufmRxmWWGGqbMY3yvdp"
        "gaBvm69+x1A8+wikiRrwlfhbXXoPPAq1tiLAsBnuXuHHlFa69F/Yh3ZjsjJ3cvwdd/3Xq2td33H6vH7/AFVlmAkqYJBGOQfD3otI"
        "+UEH2opJiFaM3Ze0/MBXoaLD66uxSvySOWmFDRSiGSNzndoT5HcNa15Y8/pXtKjh3iuLUtMzLL/UQ3Sdgf4vRt5uzHr8l2x6+m9H"
        "S/eqbHSWLg3kLKC4x3CgqqhlRBOwaJaXwt04eZwLSP8ADuGLn0GmeKTtscWlu0NHgqgV7zG8Isj8eZf8lvLqOilkMcUNMA6Vx69/"
        "Q67j013dVeTYJaoMb98mNXSWutccgimbO3T4ySB6B5yOmh3gq7SvY2c/Da2e7queC2gKAVQKyNpaYKgFPaELBVKAU9oQpUCo2mCh"
        "C9pqUwVAUCmpT2hLFApqNqg7aEL2gFRtNCGRCgFNAUqBWNG0IZEbU7TBUIWhShUFI2pTBUIWChShAahTBUgpredGM9yN9Eb6JICX"
        "LE5ZXLC5DOJgf0XRngwZMwwXjHpHjtGuFdA0n4Q6NePZph+lc6P86/TxLJ6vDsioLzRHctLJzFhPSRh6OYfUQSF5mb4H5dg50Fve"
        "q7Vu8j18oxvyLFwrPct/Y9/mPjDhz8Iz+7UAjLaKeQ1dI7XQxSEkAfenbfwV4Ta7c4h4ba+O2B0Vzss0YuMTDLQTvOtE/Dgk9GyN"
        "H0EA93fxXdLZW2S4VNvuNNLS11M8slglbpzHev8Ax7j5ljkGaLG4dU6mlWGkk9+ml+/j1nv5ng+Yq7cNYS1T4a8PjgbD4f8AGq7Y"
        "FZ5bVHQ01dSc7pIRM9zDE53f1He0nrr86/Ey3ihk+Zl7LjcXso3HpR031uEfKB1d+ESvGbRte2qcFLatqc/HLcJGs8Qqa23x+N3c"
        "VvXyJ7Ub9aNrM+0vaNqNo2gL2jajaNoC9o2o2jfrQF7RtRtG0Be0bUbXqsAwC78Rb9Ha7VHpg06pqnj63TR/bOPp9De8n2la61an"
        "Rg6tV2it7M6dOVSShBXbNxeCnh0lXe7llM8Z8XoYzSUxI+FK/XOR96zp+GvyOOWSMyLiHWiB4fTW5raKNwOwSzfOfxy76Fu7Mb5a"
        "uCHDqls1m0yudE6GiYSC9zz8Od/tJO/tiB3BckhxkeXuJc5x2STskrkco2sxxtXNZq0fqw7Fx+OLZ9mfVY4XDQy6DvL60u3gvjoR"
        "9Ea+qNfLGvrZ5l1BxUz6GLK09FhYszVD52WtycB6mnrW5ZjckzIam9UPJCXHvLWvaQPSdSb16AVpoLLBPLSzRzQSPimjcHMexxa5"
        "pHcQR3FSSurGivS52m4XselqeHeV0dxdQPx+4unDuUdnA5zHesOA0R696WxeKEIxXhhiOI1UjDdY5DVzRtcD2Y+udD7ZSN+flK8Z"
        "FxjziKmEDcgnMetbdFG5/wCMW83514+uuFXdKuSrramWpqZTt8szy5zj6yVjZtq5o5qtUlF1bWjrpfVm/vCFxC9Xa52y62+iqKyk"
        "jp+we2Bhe6NwcTstHXRDu/1fIvzsIs9dhnCzN6++wSUcVzp+wpoKgcr3OLHtB5T1Gy8evyd9y+rjjll6xTO6CezXCWkkktrA8M0W"
        "v1LJrbSCD7QtP5Hml+y10ZvNzmq2xnbGHTWNPpDWgDfr0sIxbilwPkw1KrUoQg2tnR9e+5t/gjdqgYHktvs8NLUX6CbxqKmqRtsr"
        "S1g1rY38Ajv6Eja/RxzMeJV7uZpYcStFC+MOLqiroZoWMIHdzF/ee7pvv9C58tl0rbNWR1lvqpqWqj+DLE4tcP8A09S9PdOKmYXq"
        "hfRVl8ndTPHK9rGMjLh6CWtBI9qrhdtmyrgm5ykknfpvp5myOC9yqbxxZyKtrG07aqajmMopjuLm7aIHlOzsdO/ZWnLTRxXPIaGj"
        "qJeyhqqtkUku/gNc8Au9gO1eN5VdsRrpK2zVfitVJEYXP7Nj9sJBI04Ed7R9C/KLi4lxPU9Vko2bN8KLjOUluaSXdc6PyOCjw+7R"
        "WSz8LYLtThjeSslp+17QkdfKLHd3n2foC/M4+UdRLjeITx0DYYKeJ4lZTN5oabbYgGhwGg3fQd29dFrNnFTMWW33OF+qvFuXk6hp"
        "k1/9zXN+dfFLnmQz4373Zbk+Sz8rW+LujYdBrg5o5tcwAIHn82u5YKDTTPlp4SpGcZu111vU2fllqrM04UYdV2KF9Y21xdhU08A5"
        "nhwY1pPKOp0W/LpwPcvMYnw9yD3JvV1qq6sxygpoCXySsfGagd/JrbSR9PXQXjsfyy9YtK+Sz3GekMnw2sILXfK07B9oX15BnmR5"
        "VE2K7XWapgadiLTWM36S1oAJV2WtEbVQqwWxFrZv3779hsDhF/7h8Svm/wD8qZZ+GkDsi4W5djlA5vuu+UVDI+bRkZpnQe2Mj8Ie"
        "lautGVXew0FzobfV9jS3OPsqpnZsd2jdOGtkEjo53drvXx226VlnrI6ygqpaaqj+DLE4tcP/AERxvck8NKTm772mu7pPfcOcEyOT"
        "NrTJJa62khoqlk08s8Lo2tax2yNkdSda0PStk4Xcqa7cd8qqqN7XwGhMYe07DiwwMJHtaVp648U8vu1G6kqr5UGB45XNjayMuHoJ"
        "aAT9K/IxzKLriddJW2eq8WqZIzC5/ZsfthIJGnAjvaPoUcW73MKmHqVVJytdqyPidI51cZC4l5l5i7fXe+9bU8Inpm1B83R/tZVq"
        "MPPPzb8re9+tfr5Fk91yytjrbxVeM1McYha/s2M0wEkDTQB3uP0rNrVM3ypN1IzW5X9ticarYbdkVorKj/oKarhlk+9a8E/mC2dx"
        "nxK9VuWvu9FRVFdb62KMxSUzDKG6aBo8u9b1seY7WnFu/Dcf4ntx2imst5gittRGHwxzSNeWNPmAcw8vyBYy0dzViHzclVTS4an2"
        "x49cMc4DXuC5xPhqKiZs4hf0dG0yRAAjzHySdetVRWe2Yng1hudHh7MlrLlGJJ5ZI+1ERIB1rldrqeXoB3dTtZshtt0xjhJkVPk1"
        "fFPdrlWtlY7tS8ydYhrqB3CMnQ7gFqWw5/kmM0ppbXdZYKYkkRFrXtaT36DgdexYpOS7z5adOdWMnF3+l1pPRdBu+7RVd04RXtsW"
        "MRWipmkY4W+jj8ogPjPM5jWghxA7iN6AXjeD73MxPiG9pIc2haQR5j2c68TbOJGU2iorJ6W8TNlrH9pM6RrZOd2tb04HXQAdPMB6"
        "F+dZ8outho7jSW+q7GnuUfZVLOzY7tG6cNbIJHRzu7XersOzRsWFmqcoaatPj1X8D7cDJGa49o6/2+D9cLatTjduyfjreKS5t56a"
        "KGOcQ70JXCKIBp18pPsWkaCunttbT1tLJ2dTTSNljfoHlc07B0eh6jzr76vKLvW3118lrpBdSWuNRGBG7YaGjo0ADoAFXFt3Rtq0"
        "ZTm5RdtGjd9juLpcnp6KLhlR0EMNQ0GtmgawwgO6PDywDm840ep1oryXEZzrTxeiuVXDIyibU0sokcw8r2sbHzaPn1rrpePuvEXK"
        "L3BFBW3id8UT2yNaxrY/KadgnlA3ojfXzr5cgzG9ZWKUXitNUKXmEW42M5ebW/ggb+CO/wBCkYtM008NOM9p23Wer95sHjBi14rM"
        "qfdqOjqK231sUZikpmGQN00DXk71vWx6dr9eOw3DH+Bt5huMT4Z55mziF/R0bTJEACPMfJJ161rSz8RMnsNG2joLvNHTNGmxua2Q"
        "NHoHMDofIsU+b3+rttdbqi5STUlfIJqhsjWuL3Dl0eYjmHwG9AQOibMtEOYq7MYNq0WvYbTorRbcWwqx3KkxJmRVlxjEk8j2dqIi"
        "QDrXK7XU66Ad3Ur9m6xVVz4UXlsWNxWmplkY4UFJH5RHPGeZzA0EO0O4jegFpex55kWOUppbbdJYKckkRlrXtbvv0HA69izW3iJk"
        "1pnq56W7zCWrf2kxka2TndrW9OB100OnmA9Cjg95hLC1G73Td772ecQCpBT2th91i0wVIKe0IUqBUbTBQhYKalMFCFA6VbUJgoQy"
        "ByaxpgoC0KUbQhe0w5RtNCF7VAhYwU1AXtNSDtCEKB0ntTtG1CFhye1CYKAvaFKe1SFAoU7QgNRJgpIW46IpCEICXLE4LMViIQyR"
        "gcF87wvqcFgeEN0We24Y8Urlw4uTjG01VoqHA1NGXa5vu2H+i8D2HuPq6Ju2OYFx/srKuKUOrYmabVQaZV0v3L2nvbvzHY9BXHTg"
        "vot9yrbRVx1lvq56SqjPkywPLHD2heFmOSRxNRYrDzdOquK49vx23Ohy3Op4aHMVo7dN8Hw7Pj1Gw8p8F/MrNK99nNLe6TfkmF4i"
        "m162POt/I4rwc/CbO6Z5bJiF6BH2tK5w+kbW0LD4SeX2tjYrgyiusbf6VRGWSH8Jmt+0Fesh8K3yR2uKDm8/Z1x1+di+dYrlBQ+j"
        "KlCp1p2968D01Uyar9JVJQ6mr+5+Jz9/Bfm3xRvn5E//AAR/Bfm3xRvn5E//AAXQv1VsXxVf+Xf6E/qrIvis/wDLv9CvpPPP0i/k"
        "vMuxlH6h/wAX5HPP8F+b/FG+fkT/APBH8F+b/FG+fkT/APBdDfVWRfFZ/wCXf6EfVWRfFaT8u/0J6Tzz9Iv5LzGxlH6h/wAX5HPP"
        "8F+bfFG+fkT/APBH8F+b/FG+fkT/APBdD/VVxfFaT8u/0I+qri+Kz/y7/QnpPPP0i/kvMbGUfqH/ABfkc8fwX5t8Ub5+RP8A8Efw"
        "X5t8Ub5+RP8A8F0P9VXF8Vn/AJd/oR9VXF8Vn/l3+hPSeefpF/JeY2co/UP+L8jnj+C/NvijfPyJ/wDgvtoeDef3B4ZDiV1bv+lN"
        "F2TR7XkBb6+qri+K0n5d/oXzVXhUzuYRS4vC1/mdNVucPoDR+lPSWevRYWK7ZL/7Etk61eIb7n5H4OGeCldayWKfK7jFQ03Qmkon"
        "CWZ3qL/gt9nMts37MsM4H2IWWz0sBrWDbLfTu28v18OZ/Uj2+UfMNLRGS8d8zyON8Ar2W2leNGOgZ2ZI9b9l351rgl0j3Pe4uc47"
        "JJ2SVq9EY3MJqeaVPor8Ed3f8N9Zqq55hsJFwy6H0n+KW/uX/XYfs5Lk9zzC8z3W6zmaqm6aA02No7mtHmaPR/8A2vzowsbWr6GN"
        "XTU6cacVCCsluRyVWpKpJzm7tmZgX0sWGML6GhZHySZmYsrVib3LIFDQylSlAKGJYKalMFAUCmpTBQjGhCFAUmCpBTVMSkwVIKaA"
        "pMFSCmoQpCQKaEZSoHaxg6VIQpMFJCApAKQKaGJSsFYwU0BkTBUg7TQhYOlYO1jTB0oQyApqAdqgUIUCmDpSmChDIDtNY1YKELTB"
        "UAqlCFJgqQU0IXtMFSDtCELB0q2oTBQhkBTWNMFAWjaW0bQhYKe1AVbUIUhTtPapLD2qBUApoLF7Ke1G0ByhDJtNRtMOQFbT2VO0"
        "bQhYO09rHtVtCFbQp2hCGpkJAprcdGAVKUwUIBUOCyKShkYXBYnNX0OCxlqGaZ8rmrGWr6nNUFiGxSPm5UuVfQWFLkQy2jByp8qz"
        "ciORBtGHkT5Vm5PUnyepBtGDlRyr6ORHIhNowBqfKs3InyINowcqfKs/J6kwxCbRhDdrI1iyBitrEMXITGLOxqGsWZrVDXKRTW6W"
        "ZoUNCygKGiTLA0rHVSqHRDWyl0twHyrD7RiT6eatorbeBKTWPq5WxGo6u7Mtc4+U0N6aHcdnXlbdzShYzjtKx8uKw6xENhux3T7/"
        "ALFPjPZPy+L95Hv9xT4z2X8vi/eXCyYK1cwuk870ND/JndHv9xT4z2X8vi/eR7/cU+M9l/L4v3lwwqCcwukehof5M7l9/mKfGay/"
        "l8X7yfv8xX4zWX8vi/eXDIVJzC6Sehof5M7k9/mK/Gay/l8X7yPf5ivxmsv5fF+8uG0JzC6R6Hh/kzuT3+Yr8ZrL+XRfvI9/eK/G"
        "ay/l0X7y4cBTTmF0k9Dw/wAmdxe/vFfjNZfy6L95Hv7xX4zWX8ui/eXD6E5hdI9Dw/yZ2xX51hzqGpFVkFmmpTE7tYvGY5edmjtv"
        "ICS7Y2OUA77tLja6y0U11rpLdE+G3vne6nikO3MiLjytPU9QNDvPylfEhZQhsn14XBxw99l3uUmCpBTWw+tlKlAKaEKTBSQgKTBU"
        "gpoYlKwdqAdoQGQKlAKoFCFAqgVCYKEMgO01jB0rB2oQraYKlCEMioOWMFUhDJtCgFPahCwVQIKx7TBQljICntQmChC9pgqEwUIZ"
        "Np7UbTQF7RtSCntCWHtMOUoQhe09qQdoQlitp7SQgLBRtSCmoCwUbUKghLFIB0pCpCD2hJCEsanTBUgprcdGUhCEIMFBCSYKBC0o"
        "LVkIRraFMJbtSWrMWo5ULcwciXIs/KjkQu0YOT1J8izBifIg2jByJ8izcqfKhNowcifZrPyJhqDaMAYn2az8iA1CbRhDB6E+zWbl"
        "TDUJtGIMVBiyhqYaoRyJa1ZGhMNVgIzBsYGlYCQVAKGDGqUoB0hiWCmpTBQjGhCEIMFNSqQFJgqQU0BSEgU0ICoKUKEKCpSmCqQa"
        "pSmCoBqgVKEIykwVIKaGJSoFShAUmCpBTQhSpSgHSELBTUpgoGZAU1jVByEKVAqUKEMgKe1jB0q2hC1QK9LgV3xizXeefLMelvtu"
        "dTuZHSx1T6csl5mkP5mkE6aHDX3XqW4/CCsXDfAYo7DZcOlpr3caCCvp7iLjO9sAdKQ5pje8hxLY3Df3XqS2hvhh9qm6m0tOGt/D"
        "ic8AqgdroEYjw24ZYRh1yzOzXK/XTKKcVn+z1LoWUsRDXDQa5uzp7eh3s77ui8Lxy4d0XDPNxbbZUSzWutpY66l7U7exjy5vKT59"
        "Fjuvo0rYVMJOnDbbWlrrir7rmuUKQVuHwccNx/OMyu9Fklu8foaW0y1bYRNJF9cbJEAdscD3OcO/XVS1zVRpOrNU472ahB0q2ugY"
        "sV4ccTcBy+74vYK/GrpjVN424SVj6iGdvK53KS8nqQxw6a6kd/UL8/FcOwfFOE9uzzM7ZW3yS81j6WkoaeoMDI2sL2lznNIO9xu8"
        "/naNd5TZN3yKTekla1762tu6L7+o0gCmt359iGEYJesIyuG1VlxwvI6OSqNomqXRyscIxpvaNOwAZYz3nq0jZBXr7hQ8H6Dhbas8"
        "PDqodT3GvdQtpBd6gOYQJPKLufRH1o9NedXZKsDK8ouSTjrx3aa6LrOYUwV9V4qKOqu9fPbaV1HbpZ5H01M55eYYi4ljC49XaGhs"
        "9+l8e1ifC1ZmTaNrpDIrVwt4e4dgVZd8FnutdfrTFVyyxXOeL652cZcSOfXUv300AtaW+z47xM4o2e0Y7bZces9wkZE6F9Q6dzNA"
        "l7g55PUgHQ7t6VaPqqYRwahtJydtNePdb2mu0Lom527glSZRdMMuFnu9lmonSU/u9LVPf9cZvyjHsjlJHQhvXY6Da8lwj4d4/f5s"
        "xvWQ1E9Zj2KU5nfHRksdWb5+XROiARG466HqOo6pYPBS21CMk278d1t9zUa/dxXEr1m11FrsNC+srSx0hY17WBrG97nOcQ1o9ZI6"
        "kDzr32Y0nDK/4PJfsUZLYL5SVAifZqqqMxqYyQOdhcSenNvv/ou6dxWxfB2wSzXHCqyrvUtdBNkda+1Uppq6ana8Nge88zY3tDwd"
        "P6OBHk686qWtjKjgnUrKndNPW6f/ABp0ao5mqIH0lRLBIWGSJ5Y4xvD27B0dOaSCPWCQVG1sjg/hlDfeL9rxjIqPxikMtVDU0/aO"
        "Zt0cMh1zNII05g7j5lty1cFcTdx4qLHNbDPitZaPdGip/GJRyHbGEc4dzEhwf0J84UUbmNHA1K0VKNrN7Px1HLaoFbz4bY5hFPwZ"
        "veZ5Rjb7zU0N18Ua1lZLAeQsh0PJcB0Mjj3bXg86yDB7zSUjMUxGexVEchdNLJXyVHat10GnE66pY1Tw3NwU5SWqvbW/hb2niEbX"
        "SN9s/CvA8UwGpvmGVVdU5Ba4amoqqe4TMcx3Zxl7uTn5SSXk6GgtZcauHtLw3zV1st9RJNbaqnZWUxlO3tY8uHK4+fRafZpNmxlW"
        "wU6UXK6drXtwvquBr1MFRvSNrE+MyIUAoVJY1UqB2pQtp0ZSpSmChiNCEIGUhSqQXBCE9IQSNJhPSAWkwEwmhLi5UaTTCguACNJp"
        "hBcWk9JoQgtJ6T0npCXFpUBpA2mhATCAmoYsYCsKAU0BSEIQgwU1KYKEKBTUqgdoRggHSEIQpMFSCmgKTBUgpoCkIQhABVKUwUIy"
        "gU1KYKEKBTUpgqAaYKSEIygqUAqgUMRqgdqUIClSlMFCFApqUwUIUCmpVA7QFAp7UKkIUmCoT2oQ+mmpKiskMdNBLM8DmLY2FxA9"
        "Oh8q6B8LejqHZrj1QKeUwR2Cma6QMPK09tN0J7geo+laawrPMg4e3Sa543cPEa6aA075exjl3GXNcRp7XDvY071vovR5Px34gZlY"
        "6qyXu/8Ajdrq+TtYfE6ePm5Xh7fKZGCNOaD0PmWXA+qnUpRozhJu7tw007zZXG6zXG/cO+DE9qoKmuhFlZTF1NE6TUvZwjkPKDo7"
        "aRr1H0L4fC4c0cRLJBzAy01ip4pWg75HdpMdH2EH2rxnC7jfk/Datt9PT3KeXHY6gPqLa8Ne1zCfLDOYbYTsnySOvf518fGe4WO8"
        "cQ7tdsevct3t1ycKkSzMla+Jzu+I9oASG66a6BpaPMj3G6tWhUoylHe9m67Fw6fceCB0ugvBCkdFxCv72tD3MsM7g1w2DqaDoQuf"
        "F6PC87yDh9dJrnjlf4jXTQmnfL2Mcu4y5riNPaR3sad630UT1PkwtVUqsaktyOkKLILjxS4M5+292CDGYbRCKunmtcUlJBVSAOd2"
        "b2EkP6saPP8ACHcdb8tkNvq7z4KuCC3U01WaK6VAnbAwvMW5KjXMB3fCb+MPStY5dxkznOrf7n37IJ6qhLg50DI44WPI6jmEbW82"
        "j167XyYbxQy7AGTx45e56GGc80kQaySNzta5uR4Ld6111voFbn1SxdOTtK7TjZvS+++69vabV8ICCW38OeDluqo3Q11Na5TNBINP"
        "j22DXMO8dWkewrHkf80rEP8A8gf+ipWmclyq85hdH3O+3GevrngN7WY9zR3NAHRo6noAB1K+ipza+1eJUeJzV3NYKOoNVDS9kwck"
        "p5tu5w3mPw3dCddfkUuapYqDqVJW0cbL2b/UfhpgqA5VtQ8868zrPrrhfD7hXHbcYs16bU2GBz3XGgfUmLlhh0Glrhre+vyBaGhq"
        "Mkz3ijS1NsoaOy5JWSxvpoKRnikMT44xylocTyk9nvv6k+tfZafCG4kWW2UVsocj7KhooWU8EfiVM7kjY0NaNmMk6AHUna8lkecZ"
        "Bll/Zf7tcpJrwwMDKqNjYXN5PgkdmGgEekdVWz0cTioVbNN6W0sluXB39x0/it3vHE3LZ8H4mYFSVNRHHLHJeYaUxSwFjTp/ad2n"
        "EaBaQDsdCF4/g1bAMT442K3PNbUCjEVM2Mcz6hrPGG7aB3723u9IWtq/jxxFulpfa6nKat1I9nI4MZGyRze4gyNaHn6V5LG8ovGI"
        "XRlzsdwnoK5gLe1hPe097SD0cOg6EEdEuZyxtPbjLV2vdu17NWt126z9o8M8hiwmry+ppW0lppp20+qkmOWRxLR5DCPKHld/qd6F"
        "0t4pjmFYxwkt95zCLH6yzBl4kpH0UkxqnSHmcC5pHJ8KRmzvv9S5lzDidluetp2ZFep66KndzRxFjI4w708jAGk+sjfVfDlua3zO"
        "rnHcsgrvHK2OFsDZOyZGGxtJIaGsaB3uPm86JpbjTSxNGhtOnFtu2/tu9z04HR9Hj3vd8MimaxvLBcHT18Z9PaUkpcfx+dbD4QTs"
        "yW9Vda4g1+M3O6Wx/wBsYJphKwn1BzS0LkWTi1mM2R2nI5LxzXq005paSqNNDuOMtc3lI5NO6Pd1cCeqnGuK+X4hcbtcLNeDS1d3"
        "k7Wsf4vE8Su5nO3yuaQOr3dwHeqpI+qjmNGlO9nZyb4cbW49K9RunhNkFXjHg45LcqK10V0qIr7ytpa2nM8T9spwSWAgnW9961Fx"
        "Hzi65o22uuWNWmytozIGG3UL6btefl3zczjza5Ono2fSsGHcX8ywC2S23Hbz4lRSzGofH4tDJuQta0nb2E9zW9N66LFmXFXLeIVL"
        "S02R3bx6CleZIm+LxRcriNE7Y0E9PSo3ofJVxUJ0I01JqyStZW39N7+w6lFxxEUnBKz5Rj1PcHXO0QMpq2eQ8tM/sYuVpj1pwc4t"
        "HU9PWubuN9zv1x4mX0ZGGNr6WXxdjImkRthb/wBHyg9dFpDuv2y83es5v+Q01jprjcHSxWKFtPQBsbIzAxoaAAWgE65G9Ts9FOW5"
        "les6ugul+rG1deI2xdsII4iWjethjQCeveev0I3cuKxsa8HBK2q6Oi2vfu3n4iYKkFNYnm2HtCSFAatQgIW46EAVSlMFCMoFNSmC"
        "hBpgpIQhSYKkFNAUmCpBTQFISBTUICpSmCqQaAdIQoQpCQKaAoIClUgKQkCmoYgmCkhAUqUhAVMSgVSlMFQDQhCBjBTUqkIUhSDp"
        "UhATBSQhClQO1AKaApUpTBQDQhChBgpqVQO1SMoIUqkIUEKVSgBMFJCGJYKakFMFCDBVKUwUIUCmpRtCFgpqVSApMFQntAWhIFNC"
        "B3Kw7ahChiZAVSxph2lQZAU1O0wVAVtPalCEZkCFAOlW0MbDTBU7TUBSoFQCmqYl7KYKkICAvaNpIUDKDk9qEwUIWDtClUhB7QHJ"
        "IQhe0w5QCmhC9oUgoQGrlSlMLadExoQhCDBTUqkIyghSFSEBMFJCEKTBSQgKVKUBQFIQhUxGCmpVDuQAmCkhQhSYKSFAUmCpCapC"
        "kICFCAqUphCMoFNSmFSFApqVSgBAQhCFJgqQmgKQkE0MQVKUBAUDpUpTCAoFNSqHchGCEIUBSYKkJqmJSYKkJoCkJBNQAqUphDEt"
        "ClUEIMFNSqQjBUCpQhDIhQCrQArB2oQgMiFIKpQgA6VKUwhGUCmDpSqHcqQsO2ntY1SgKTBU7TChCkwVITVIUjaAhQgwSFW1CYQh"
        "Qcq2oTCAraalMIQraA5JCEZe0bUhNCWHtVtQmEIVtCSEB//Z"
    ),
    "stopwin": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQAAAwACAwEBAAAAAAAAAAAAAAECAwcEBggFCf/EAF8QAAEDAwEEBAcHDA0K"
        "BQUBAAEAAgMEBREGBxIhMQgTQVEUIjJhcYGRFVZydZShsRYYIyc3UmKSsrPS0xczNDhCU1V0laLD0eMkNkaChJOkwcLEJkRFc+El"
        "KFRjduL/xAAbAQEBAAMBAQEAAAAAAAAAAAAAAQIDBgQFB//EAEERAAIBAgMDBwgJAwQDAQAAAAABAgMRBAUhEjFBBhNRYXGx0RQV"
        "IoGRocHwFjI0NUJSU3KSM1TxI0Nz4SVj0uL/2gAMAwEAAhEDEQA/APLqEIWo5JjBTUpgoQoFNSqQgwU1KYKhBpgpIQFKlIOUIYlI"
        "QhAMFNSmChCgU1KoIAVA5UoQhSYKSEIUhAQgAFUpTBQhQKalMFCMaEIQhSYKkFNQhSYKkFNQFIQEKkKBVKQmCoQoJqUwUIWEBSqV"
        "RCwqCxhWCoQpWCoVIQpUFKYQjMgKoc1CodiGLLCsLGrByFDEtNpwVIVBGQtWCsYKsIQoKlAKoFQMoKgoHNWChGMKlKpDFjBTUqgc"
        "oQEwUkBCFKgpQgKVA5UoUBSpSmChBoQhCDBTUqghCkKQqQAhCEAKgcqUKmJQVKUwVANCEIRjBTUqkIUhSDhUhAQhCA04CmpTBW46"
        "YaEIQjKBygKVSApCQKaGJSFKpQAqUoBwgLBTUpgoYjQhCAoIUqkIUhIFNAAOFSlMFCDVKUAoQpCEIRjBTUqgcqApClUqYgmCkhQF"
        "JgqQU0IUqUpgqEKBTUpgoQoFNSqCApAKQ5JoQsc1QWNp4rIFWRlAqgoVBQhYVBSFQKGLKCsdixjmrBQjLVBSmFDEyNVBY2nBVhCM"
        "pWCoVBDFlDmqHNSCqUBSpSmCqQoFUCoTBUDLQhCGJSApBwqCEKQhCEAFUpTBQDBwqUpgqAoFNSmChGNCEIQpMFSCmhCkJApoAQhC"
        "EAFUpTBVIUCmpTBUA0IQhCkwVIKaEKQkChCGmwU1KYK3HTsoFNSqByhAQChChCkwVIKapCkwVIKaEKQkCmoBgpqUwUIygU1KoIQE"
        "wUkIGUmCpBTQhSEgU0AwU1KYKEKBTUpgoQaEIQhSYKgHCpQhSEgU1SAqClCgKCpSmChCwhAQoQYKakKkIWE1DTgq0ADmsjSsapDE"
        "yJhIHKEIZAVSxhWChGWOxUoCoFCMyApqQqUMWUOasHioCpGQyJhSCmhiUrHJQFQKgKBVKUwqQtMJBMIQYVKUwVCDTBSQhDIEKQVS"
        "EBCEIQYKalUDlAMFNSmCoCwhSqQgJgpIQhSYKkFNCFIQhACEIQgwU1KoHKEKQpVIATBSQhCkJAoQhpxCELcdOMFNSqQhSFIOFSEB"
        "MFLKEJYrKe8oRnCCxeVWViynvISxkBTWPKe8oLF5TyVj3lW8hLF5Tyse8nnzoSxkByjKxhye8gsZMlMFY95PeQljJlPKxgpgoQy5"
        "QoyqBQliwcoUgqkICYKSEIUmCpBTUIUhAQqQYKalMFQhkaeCagKgVCDVKVQVQGFQKgKlCFKlAKtVkKVKQmFCMoclagKgUMS2lUoH"
        "NWEDLByFQWNvBWFDFlhUCpCaEZkCpY2lZAhixhUFA5qghCwqCkJhCMsJqQqQFIUqlDEYKalMFANU0qUxzQhaEIQgIQhCFIUg4VIC"
        "kAqQqUBSEgU0MQVA5UoQFKlKYKEGhCEAIQhCMpMFQDhUhCkJApoAQhCGJpsHCpSmCtx040IQgKRlShCWKylvJZUFyFsZN5LeWIuX"
        "cdGbMdRa5Ikt9KIqEHDqyoO5EPMDzcfM0Faq+IpYeDqVpKKXFm6hhquImqdGLk3wR1LfwjfXpazdG+xUMImvN1q6tzeLuq3YIh6z"
        "k/OF9I7P9kdD9jmktYeOB627He/LXPy5VYPa2aUZT7F4tHQ0+SWNavUcYdr8EzyuHp7/AJ16m+ozY7/G2T+lT+sR9Rux7+Nsn9Kn"
        "9Yp9KKP6NT+K8TP6I4j9WHtfgeWt9PfXqT6jdj38bZP6VP6xH1G7Hv42yf0qf1ifSij+jU/ivEfRHEfqw9r8Dy3vJh69R/Udse/j"
        "bJ/Sp/WJ/Udse/jrJ/Sp/WJ9KKP6NT+K8R9EcR+rD2vwPLm+mHr1F9R+x/8AjrJ/Sp/WI+o/Y/8Ax1k/pU/rE+lFH9Gp/FeJPohi"
        "P1Ye1+B5e30b69Q/Ufsf/jrJ/Sp/WK2bMdlt4+x0T6Myu4DwS6Zd7C4/Qo+VOHWsqU0v2rxI+SGKf1asH634Hl0PVB635qHo2s3H"
        "yWG7vEmMinr28D6HtHD1tWlNRaYu+k640d3opaWU8Wl3Fkg72uHBw9C+pgc3wmO0oTu+jc/Y/gfGx+S4zA614WXTvXtXxOCHZVAr"
        "jByytevpHymjOCqBWJpVoYtGRCkFUhiwTBSQoQpUpTBVINCEIQppVLGOayA5UZGUgFSFShCkwVIKaBlK2nIWMFUChC1QUpg4QhkC"
        "alMFDFlhWFjCsFCMsc1QKhUoQyJgqGnsVDmqYljmsjTlYlYPFQhapSmEMSgVaxqmlQMsFUCoVBCFJgqQU0IUhIFNCFIUqkBQOFSg"
        "FUChiNCEIGCYKSEIUmCpBTUBSYKkFNAUhAOUIYgDhUpTBQMoFNSmChBoQhACYKSFSFJgqQU1CFIQEIDTQKalUDlbjpWMFNSnlANT"
        "lGexSShbCc5QXJOK7hsu0YddavpLfIHCgiBnq3DsibjIz3uJDfWtOIrww9KVao7KKuz0YbDzxFWNKmruTsjvmxvY2NRtiv8Af4ne"
        "5Wc01Kcg1RB8p3aGZ/G9HPtu0fb1QaUL7HpWCmqq2nHVOnwPBqbHDda0eWR3DDR5+SNve0c6StcGlbG9tPXVUI610Pi+DU/khrcc"
        "i7GB3NHnC8rZA4Y4LnsryyedT84Zh9T8EOFul/OvZZHb1qtPKKfkeD+v+KXG/QvnTtuz72odY37Vc7pbzdqqsJOQx7yI2+hgw0ex"
        "fDDWjk1o9SnKMrt6dOFKKhTSSXBaI+FOcpvam7vrKwO4exGB3D2KcoythiVgdw9iMDuHsU5RlLgrA7h7EYHcPYpyjKArA7h7EYHc"
        "PYpyjKArA7h7EbrQQd0ZHbhTlGUuDu2k9q2q9HSRihuks1I3GaOrJliI7gCct9LSF6R0nrvS+2qzTWi5UbI69rN6Wgmdkj/9kL+Z"
        "x3jBHaMLxxlcq3XOrtFfTV9BUPp6ymeJIpozhzHDt/8AjtXPZtyew+OXOU1sVVqpLTXrtv7d59TBZpVw/wDp1PTpvfF66dXzY2Nt"
        "K2c1mz67Bhc6otVSSaWqIxvY5sd3OHz8x5umNcvV9hudu257NZYqpscVa4dTO0cfBqloy2Rv4JzkeYkLynX0VRarhVUFWwx1NLI6"
        "KRh7HNOD9C8GS5hVxCnhsUrVabtLr6/nt4nyc+yqnhZxr4fWlU1XV1fPwLY5ZmlcNjlyGOX2zm2rGYFWCsYKoIa2WhIFNCAFSlMF"
        "QhQKalMFUjGqClUFGYspMFQDhUoCkwpBVBCDVAqUDgqQyBUpVKEZTSqUBUChDIE1AKtCFg5VBY2lWChiWOaoFQqChGZAmFLSmFSM"
        "yAqgoCoFRGLLQEgmhDIDlCgFWoQpUoBTQFJgpIQhSYKQQhCkwVIKaEZYKaxqw7KEGhCEICYKSEBSYKSEBSpSgHChCkIQhBgpqUwU"
        "IywhSqQAhCEAJgpIVMSkIQoDTaFIOFS3HTFJZ4pA4QgsBUOcqJWJxQyRDyvT/RqssdDpW6XqYBr62o6sPPZFEMn+s4+xeXXFetNn"
        "TvANgBmj4PFBXS5H32ZOPzBc1yqlLyKNKP45Jd7+B1PJSmnjHUf4It9y+J5c1lqOXVmqbteZnEmsnc9gJ8mMHDG+poC+HlY2HDGj"
        "uAVZXaUqcaUFTgrJKy7EeecpTk5y3vUrKMqcoyszGxWUZU5RlBYrKMqcoygsVlGVOUZQWKyjKnijKCxWUZU5RlBYrKMqcoygsbk6"
        "N+pH2rXbrU558FvEDoy0nh1rAXMPpwHD1rndIeyNtmumV8bcR3SmbM498jfEd9DT61rrZdO6n2kaUkacH3Rib6icH5it2dKCIAaX"
        "lx43+UMz5vsZXF46KocoKU4f7kGn6r+CPq1Vz2SVFL8Ek167L4s0Gxy5DCuHG5clhXRHDTRyWrI1YWHgsoUNTLVKQgIYFIW29F9G"
        "vaNrekiraSyeBUEo3mVFxkEAeOwhp8cjz7uF3Kp6FO0WCEyMrdPTuA/a46uUOP40QHzq2ZvWErSV1BnnMFNdu1xst1ds4mazUljq"
        "aKN7t2Oo4PhkPcJGktJ82c+Zdeslpq9QXi32mgYJK64VEdLAwuDQ6R7g1oyeA4kcSoaXCUXstanEByhbu+tJ2q/yJS/L4f0k/rSt"
        "qn8iUvy+H9JLM2eSV/yP2GkkwVu0dEraoP8A0Sl+Xw/pI+tL2qfyJS/L4f0lNlk8kr/kfsNJqmlfZ1dpO66G1FWWC9wNgulHudbG"
        "yRrwN9jXt8ZpIPiuC5Oj9Aam19WupNN2aquErMb7om4jjzy3nnDW+shOo07EnLYtqdfQvQ1D0M9otXCHzVFho3kcY56t5cPxI3D5"
        "18fUXRQ2l2CnfPFbaS6xsGXe51QHux5mODXH0AEq7LN0sHXSu4M0m0qwqqqSooKmWlqoJYKmJxZJFKwtexw5gg8QVDTxWJ5SlS3T"
        "9ahtR/kWl+XQ/pJjoo7Uf5Fpfl0P6Suyzf5HX/I/YzS4KsHIW3a3ou7UqKF0v1Otna0ZIgrIXO9m/k+pauutnuOn6+WgutDU0NbF"
        "wfBUxmN7fUUs0aqlGpT+vFrtRxArBUKgoaSwVQX3tF6Gv+0G6S2vTlAK2uihNQ6Lro4sRhzWk5e5oPFw4ZzxX39XbFtdaEtBu+oL"
        "GaO3iRsRl8Kgkw52cDDHk9ncljNUajjtqLt020Ohg4WTmsa2zB0atqM8McselyY5GhzSa+mGQRkcDIiTZIUalT6kW7dCuasBVLZt"
        "x6Ou0u02+ruFZpox0lJE+eZ4raZ26xoLnHAkJPAHgBlaxBRqxjUpVKf14tdqsUCrXftMbDte6xslNerJYTVWyp3uqm8Lgj3t1xaf"
        "Fe8Hymkcuxda1TpK8aJvElnv1GKS4xsa90PWskwHDI4sJHLzo095JUakYqcotJ8baHxlQK2t9bTtR96//H0v6xaoILSQeY4KNNEq"
        "UalO3ORa7VYtMFbKtXR92j3q2UVyodO9dRVsLKiCTw2nbvxvaHNODICMgjgRlcz62rah72P+Ppf1iuy+gzWExDV1TfsZqsFNcq62"
        "ursdzrLZcITBXUUroJ4iQdx7TgjIyDxHMcF2vR2yPWWvrZLctPWfw2iimNO+TwmGPEga1xGHvB5ObxxjipY1RpTnLYjFt9B0pUvv"
        "6w0PftA3KG3ahoPAqyaETsj66OTLC4tByxxHNp4c+C6+ChjOEovZkrMaYKSFDApCAhCMoFPKgKkIVlClGUIUFSlMFANUpTBUBQKa"
        "lMFCMaEIQhSYKgKkIUhIFNACEIQgBCEKkNNpgpIW06YpIlAKR5oBFYnFZHFYnKmaMTyvWmiP3u7/AIrrvplXkl5XrbRH73Z/xXXf"
        "TKuY5U/0aP8AyR7mdbyV/r1f2PvR48afFb6AnlQ0+KPQE8rt7nhKyti7EtM2vV2vYbZeaUVVC6lnkMe+5vjNAwctIPatcZW2+jaf"
        "to0/8xqfyQvmZzUnTy+vODs1F2a37j2ZfGM8VTjJXTaPQX7A2z73vN+VTfpLznt30paNG6yp7fZKMUlI+hjmMYe5+XlzwTlxJ5AL"
        "2mvInSf+6HSfFsX5ci4DklmGLr5ioVqspLZejk2uHSzqc9wtClhNqnBJ3W5JGmMoypyjIHPkv1K5xR2rQugrxtBu/ufao2hsYDp6"
        "mXIigb3uPeewDifaV6b030cdH2eFhubKi81WPGfUPMcWfNGwjh6SV97YppiDTGzqztZG0VVwibW1L8cXvkGRn0N3QF3G+3uj03Z6"
        "67XCQx0VFEZZXAZOB2AdpJwAO8r8pzzlJjMVipYbCScYp2Wzvk929a6vckdxluUYejRVWuk5NX13I683ZPoZse4NJ2jd88GT7ea6"
        "5f8Ao9aIvMLhS0MtqqCPFlopTgHzsdlp+ZdDqOlfGKsin0q51IDwMtZuyEegNIB9ZW6tC65te0GxMutsMjWh5imglAD4ZAAS044H"
        "gQQRwIXhxFHPMsisRVlOK6dq/t1fvPRSqZbjG6UFFvst7NF7jx1tH2Y3fZvcI4qwtqbfUE+DVsTSGSY5tI/guHd6wSukZXvnaNpe"
        "DWGirxa5WB0j4HSwOI4smYC5jh6xj0ErwGDkA8sjOF+gcmc6nmeGbq/Xg7Prvuff7Dls4y+OCrLY+rLd4F5RlTlGV0lz5B2vZqft"
        "h6V+MoPywt7dKL9z6Y+HUfRGtD7ND9sTSvxlB+WFvjpR/ufS/wAOo+iNcdm335hP2y7mfWj9zYntj3o88sK5UZXEYuUxdAcPM5LF"
        "lBWFhWUKHnZkBXqDodbKaDVt8uOq7zTsqaOyvZHSQSDLH1BG9vkdu4MEDvcD2Ly8F7t6DVyp5dAajtzXDwqnunXvb2hkkLGtPtif"
        "7FY7z15fCM66Ujbu1rbZpvY9RUsl48IqK6s3vB6KlaDI8Dm4kkBrQSOJ9QOCtN27pzadmq2sr9LXOmpScGWGdkrgO/dO79KXS72M"
        "6l1tXWrVGnKOS5GipTSVNFDxlDQ9z2vY3+F5ZBA48BwPHHiaut9Zaql9LX0k9JUs8qKeMxvb6QRlZSbTPZjMZiKVVpaLs3n6wU1R"
        "prapo1kzBT3fTl3hPB7cte3kQQeLXAjzFpHYQvzx1RpqHYVt4ooKrwiotVlulLcYnMAMstMJGyADJALgAW9gLmnkFtfo1dIHSWzT"
        "Z/VWTUtXWMq/dGWeFsNO6RoidHHjiOXjB/Ba16TO0XT20/XlBedOSTSUkdtjppXTRGM9Y2WV3I8/Fe3ijd1cxxlenWoxqJrbR6S+"
        "vd2ffyPqj5NT/r1svZLtv0/tk92PcKjulN7ldT13h8UbN7rN/d3dx7s/tZznHMc1+Xa9kdBD/T//AGD/ALhFJtlwePrVa0YS3O/c"
        "b92s7bNP7HG2h19o7nUi6GUQ+ARRv3er3N7e33tx5YxjPatafXubP/5H1P8AJqf9euo9O39q0H8Ku/sF43UlJpkxuPrUa0oQ3K3c"
        "b2rqKn6S/SGqZbIyspLTdDDLM+pY0SwQRQRskcQ0uGSWYbxPFzcr3hbLXpvZhpLwelZS2mwWyIve9x3WtAHF7ncy49pPEleUOgvb"
        "YprzrO5Fo66mp6ana7tDZHSOPzxN9i7Z03tRVVBpPTdkhkcynulVLNOGnG+IQ3DT5syA+loVWiubMLJUsPLFSV5O/f4nIvvTZ0rQ"
        "1r4bRYblcoGHHhD3tga/ztBycekA+Zd42YdJjSG0u4x2ljam1XmX9qpqzd3Zj3MeDgnzHBPYCvzgBXIpKqahqoaqmlfFUQPbJHIw"
        "4cxwOQQe8ELHbZ4oZtXUry1XQfoX0jtidDtE0xWXq30rI9VW2EyxSxtw6qY0ZMTvvjgHdPYcDkSvzyX6zaQu79Q6SsN3lAElxoIK"
        "pwHIF8bXH6V+XWvbbFZtdaotsLQ2GiudVTsaOQayVzQPYFZribc3oxvGtHifq+vOTumloFri02jU2QcfuaD9cvRq/IaX9tf8Iqyb"
        "W49uZYuph9nm+N/gfoVpLpWbPtWXWC29bcbVPUODIn3KFrI3OPIbzHuDfS7A867Xth2UWvarpaooqiGJl3gY51BW4w+GTHBpP3hP"
        "Aj18wF+ZI4r9XNENrWaL04247/ugLdTCo3/K63qm72fPnKRe1ozDA4mWMjOnWV0flXPBLSzywTMdHNE4sex3NrgcEH1pBdl2luiO"
        "0fWBgx1Bu9YY8ct3rn4+ZdYBWo5qcdmTRu3op3PwDbNaoc4FdT1FOf8Adl4+eML1X0nKDw/YtqIgZfTmCdvqmZn+qSvEexe5+5O1"
        "fR1TndHulDE49wkduH5nL9Bdr1v909lusabGXG11D2jvc1hcPnaFsj9Vn3ct9PB1Kfb70fmzpm2G9ajs9sAya6rhp8d++8N/5r9N"
        "9e6jfo/RN/vkLInTW6ilmhZIDuOkDTuAgEHBdgcCF+fmwC2e6+2LSNPu5EdX4T6OqY6T/oXsTpQXT3N2M3xgdh9ZJBTNPpla4/1W"
        "uSGibMMrfN4arV+dF/2bGttTHrDR1HUyBohvFvZI4N5bssYJx+Mvy5ngfSzywSjdlicWOHcQcFfozsAunuvsd0lPvZMdKaY+bqnu"
        "j/6F4P2qWz3G2l6tog3dbHcqgsHcxzy5vzEJPcmTOPTo0qvzqkz3tsJoPc3ZDpGHGN+ibP8A7wl//UvFvSGuXuntk1TKDlsUzKce"
        "bq42MPztK99aNoPcrSGn6DGPBKCnhx3bsbR/yX5q66uXuzrbUlwByKu41EwPmdI4j5ik9EjLN/Qw1Kn86I/UVflFL+2v+EV+rq/K"
        "GXjI/wCEVKnAmf8A+36/gfplsu+5lov4movzDFydIauh1bHejHB1L7VdKm2SN397LonY3uQxvAg47M4yea42y77mWi/iai/MMWp9"
        "hF/xtT2t2F7ud2mrYm+iZ7Hn541nfcfVVXY5qPCWnuuaJ6Tth9xNrdyma3diucMVYwelu47+sxx9a3x0PeOzO6/HMv5iBdX6Zdhz"
        "Bpe/Mb5LpaKV3pAewfNIu0dD37md1+OZfzECwStM+Vh6fN5nJdr9upq3pg/dGtHxRH+emXnteg+mF90e0fFEf56ZefAsJbz5GZfa"
        "p9owU1KYKxPCxqlKAUIUmCkhCFISBTQgwU1KYKEGDhUpTBQFApqUwVCMaEIVRATBSQgKTBUgpoQpCAcoQgwUJISwuadCFKpbTpmC"
        "EJHkgJcsTu1ZSsL1TOJhevW2iP3ur/iuu+mVeSXr1toj97q/4qrvplXMcqf6FH/kj3M6zkr/AF6v7H3o8ctPij0BGVDT4rfQE8rt"
        "jxFZW3ejYftpU/8AMan8kLUGVt3o1n7aVP8AzGp/JC+Vnv3bX/bLuPblv2ul+5d57MXkPpQ/dEo/iyL8uRevF5B6UR+2LSfFkX5c"
        "i/N+Rn3mv2v4HXcofsb7UaWyjOeHepyjK/XThD3jsg1DBqTZzYKiF7TJT07aSdoPFkkYDSD6gD6CF2q82ei1Baqy13GETUNZGYpY"
        "ySN5p845Htz5l4W2e7S71s4uT6m2uZNST48Jops9XMByPDi1w7HD5wvTOm+kfou8xMFwnns1UR4zKqMujz5pGAjHpAX5NnXJvG4X"
        "Eyr4WLlBu6cd647lrp0o7nLs3w9aiqVZpSSs77n8Neg6bfeiox0j32PUZYwnxYa+Dex5t9nP8VdXdsi2saDgqfcGrlfTyEPkFord"
        "1zyBgEsO6Scd2V6ftGrbBf8AHuVe7dWk8mwVLHO/Fzn5l9kjsI9q0x5UZnR/0sSlNdE4/wCPebHkuDqenRvF9MX/AJPBdbtD19b6"
        "mWlrNSX+nqIzuvhnnex7fS08V03K94bStmts2jWWWnqIo2XWNh8DrcePE/sBPawngQe/I4rwhPDJSzywTMLJonuje0/wXA4I9oXe"
        "8ns1w2YUpSpU1CSttJW9T4XW/sOYzbA1sLNKpNyi9zfvJynlRlGV0R8k7ZszP2xNKfGUH5YW+elH+59MfDqPojWhNmZ+2LpT4zg/"
        "LC330pP3Npj4dR9Ea47NvvzCftl3M+tH7nxPbHvR54Z2LkxlcVnYuVGuhOHmclvNZgsDFmCh52WF3zZPtVvGyPVDLzag2aGRvVVd"
        "HISGVMec4J7COYd2HvBIPQxyXsjYT0adCbRtl1l1Fdjczc6p07ZxBUhjAWTPa3A3TjxWtVSu9DdhqVSpU/0nZrU3ToLpN7PNcwxN"
        "N4js9xcBvUd0cIcHubIfEdx5YOfMFs6vtVl1TQNjr6KgutDIMtbPEyeNwPdkEFfmXt50HQbNdp110/aW1AtkMcEkBqH773B0TS45"
        "wM+NvD1LqOntX3/SdQKixXqvtsuck0s7ow70gHB9BWW10n0fOcoN060b200Pdu0bogaM1RTz1Gm2u09diCWCIl9M93c6M+SPgEY7"
        "ivCur9JXbQ2oa6w3umNPcaN+69uctcDxDmntaRgg+de9eiztivW1XT14ptQbk1zsr4mmsYwM8IZIH7u80cN4GN2SMAgjh36n6dVp"
        "poLzoy6sY0VdXBU08jhzc2N0bm/PK5Gla6McZQpVKHlFJW+bHkdex+gf/p//ALB/3C8cL2P0D/8AT/8A2D/uFjHeePLvtMfX3My9"
        "O39q0H8Ku/sF43Xsfp2n7FoL4Vd/YLxwkt5jmX2mXq7kexegj/p//sH/AHCydOz9p0H8Ku+iBcLoKVsbLhrijJHWzRUkrR3hhlB/"
        "OBfc6ctpqJ7BpC6sYTTUlTUU8jgODXStYW5/3TlfwnuWuW6fPpHikHCyDisauMOe4MaC5zjgAcyVgz4R+rGyv7mGifiWi/MMX5t7"
        "Wfuqa5+PK78+9fpjoW1zWTRGmrZUNLaihttNTyNPY5kTWke0L8xNpFbHctomrqyIh0VTdquVhHaHTPI+lbJbj7ua6Uaafzofq2vP"
        "ruhxs7c4uM98yTn91s/Vr0Evzif0o9rAkeBqvgCcf/T6X9UrJpbz2Y+rQp7PPxvvseudJ9GDZ5pG6w3OGgqa+qp3B8XuhP1jI3Dk"
        "7dAAJHnBX09tm2S17KtN1DvCIpdRVMZbQ0QILt48BI4djG8+PPGAvE9f0k9qVxgdDNq6oaxwwTBTwQu/GYwEe1a2ra+qulVLV1tT"
        "NVVUx3pJp5C97z3lx4lY7a4Hzp5nThBxw0LXMckz55Xyyvc+V7i5znHJcTzJQFjVArWfDZz7TXutd0oa5md+lnZM3He1wP8AyX6t"
        "XOlZebNWUrSHRVlO+MHsIe0j/mvyYX6n7N7n7s7PdK15OXVNsppHfCMTc/PlbIH3MklrOD6jxr0QbSazaxNUPYR7nW6aXiOTi5ke"
        "PY8+xbb6aF06jRGn7aHYNXcTMR3iONw+mQLi9FzTfuXr3anK5m74DXeAM9UspcP6rV1PprXTrdR6Vte9+5qOWpx/7jw3+yTdEKPM"
        "5bLrfxt8DZ3RAunh2yqalLvGoLjNEB3Nc1jx873exaE6ROnS7b7U0rW4bd30j2gdu+1kZ/rNK2N0JrpvQawtbneS6nqWD0h7XfQ1"
        "fW24ac8M6Q2yyr3MtqpImO/C6ifrD8z03xRZx5/AU+prvsejb5Xts9juVfwDaOmkn8wDGE/8l+VRcXEuJyTxJPav0n23XL3J2Saw"
        "qM4LqCSAH/3Psf8A1r81QVKhqz2Xpwj1P59x+tC/J+Q4lf8ACK/WBfk9L+2v+EVanAzz/wD2/X8D9Ndlv3MtF/E1F+YYvK2z6/8A"
        "uF0rL21zt2G43W4UT/PvSPLR+O1i9U7LfuY6L+JqL8wxeCtb3aSw7a9QXWHPXUGoZ6lmO9lQXD6Ek7WNuY1Oap0J9DXcex+kpYfd"
        "3ZFenNbvTW50dbH5tx2HH8Rz11boecdmd1+OZfzEC3dc6Om1Tpuso94Po7rRvi3uwskYRn2OWluiLSy0Wzy+U07dyaC+Txvaexwh"
        "gBHtCrXpXPXUp2x0Ki4xfu/yan6YZxtHtHxRH+emXnteg+mH90e0fFEf56ZeewVqlvOYzL7VPtLQpBTyoeIrKalCEsWCmoBVAqEG"
        "mCkhCFIQEIQYKalMFCWKBTUoQGQIWNUoSxSEgU1bkBUpQlwUqUoBUIUhCFbkNNpgpIW06cpLPBAKSAkrE7kspWFypkjC/tXrbRH7"
        "3ST4qrvplXkl/avW2iP3ucnxVXfTKuY5U/0KP/JHuZ1nJX+vV/Y+9HjVp8UegJ5WNp8UegJ5XaniLytvdGo52p0/8xqfyWrT2Vt/"
        "o0nO1Sn/AJjU/khfKzz7ur/tfce7LftdLtXeez15g6Q+htTal11S1lnsVfX0rbfFGZaeLeaHB7yRnv4j2r0+lwX4/lWZVMtxHlFO"
        "Kbs1r1nfY7BxxlLmpuy36Hgf9iXXfvSu/wDuP/lTJsr1vTxvmm0ndmwxAveTBwDRxPb3Be+uHmXBvePcW58v3LN+bcuohy4xUpJO"
        "lH3+J8WXJugk3tv3eBrui2EbOK6jpqqKxl0VREyVjhWTYIc0EHyvOul7WNgNrptL+GaLs8jbnSyiSWFkz5HzQ4IIaHE5IODgcTgr"
        "P0e9r1DcbHQaTvNSynudHGIqOSV2G1MQ8lmT/Dbyx2jGOOV6APA4PAr5mKx2aZTjtmrUk9l6JttSXt3P3dqPZRw2Cx2G2oQSuuCV"
        "0z82HwzQVHVvikjqGHG65ha9p9HMFeyOju7VT9H1J1Gas03XN9zzW563q93xvK8bczjGfPjgtuGKN0nWOjYZPvy0F3t5qycnickr"
        "bnXKjznh+Y5lR3a3u/VoreBhl2S+R1ed5y/Va3t1Y2+U30hfnhraeKo1nqKaAgwyXGocwjljrHL15tj2t0GgbNU0NJURy6lqYyyC"
        "nacmnyMda/uxzAPEnHZleOLJpy8anqXwWm3VNdMwZf1Tc7ue1zjwHrK+5yJwNSlCpi6itGVkr8bb32dHrPlcp8bSWzTcl6N23wR8"
        "3KMr6V903eNM1Dae8W2popXjLBMzAePMeR9RXysrvk09UcvCcakVKDunxR23Zkfti6U+M4Pywt+9KT9z6X+HU/RGtAbMj9sXSfxn"
        "T/lhb/6Un7n0v8Op+iNchmv35hP2y7mfZj9z4ntj3o87s7Fyo1xI+xcpi6E4aZyWLKOSwsWZqhoZbV7I6F21aipIazQN0qGwzTTG"
        "qtr5DgSFwAfEPP4ocB25d5l42CyRSvhkZJG9zJGEOa5pwWkciCidjPD13QqKaP0v23dHuy7ZWU1Y+rfbL9SR9VFWxxiRr2ZJDJGZ"
        "GQCSQQQRk8+S8+w9BfUhqg2bVVpZS54yMhkc/HwTgf1l1XQ/TC15pWlioro2k1BSxgNa+tBbUADs61p4+lwcfOu/ydPGoMOI9CRN"
        "mx5TroS32dSPpWd4s+nOrgaz256P1/A9H7I9ktn2PaZdabZLJUTzv66rrZgA+d+Mch5LQOQ7OPEkkrxR0rtp1FtC2gxUlpnbUWix"
        "ROpY52HLJpS7Mjmntbwa0Ht3MjgQvm7R+lBrraLRzW19RBaLRMC2SltwLDK3ufISXEd4BAPaFphRy4I8+LxkJwVGirRKXsfoH/6f"
        "/wCwf9wvG4K7/s02xan2Te6n1Ny0sfun1XX9fAJM9Xv7uM8v2xyidmeXCVY0a0Zy3LwPRnTv/adBfCrvogXjgHIXfNpe2TVG1hts"
        "bqOWlkFtMhg6iAR46zd3s45+Q1dBBUk7u5jjKsa1aU47n4GzthG0sbLNolBeKjeNrnaaSuawZPUvIy4DtLXBrsdu7jtX6OXyyaf2"
        "maRloKwQ3KxXWEOa+J+Q5p4texw5EHBBC/JgLY+zbbnrPZb9hslxbJbS7edb6xvWwE9pAyC0n8EjParGVj0YLHKinTqK8Wbyv3Qc"
        "uLa15sOqqR9E45a2vhcyRg7iWZDvTgehd82TdES1aJvVLfNR3Nt5r6Rwkp6aOLcp43jk45JLyDxHIeYrolB06q6OECu0TTTzY4ug"
        "uLomk+gxu+lfI1H029U3CnfFZLBbbU5wx10z3VL2eccGtz6QfQsrxPTGeXwe2t/rPSu3fazRbLNF1c7ahnu9XRuht1OD4xeRjrCP"
        "vWZyT34HavzOJJJJJJPEkr6WotT3jV92mut8uNRX3Cbypp3ZOOwAcgB2AYAXywVhKV2fPxuLeJnfcluP2FX5BS/tr/hFby+u/wBp"
        "n/5Vs+RN/vWit7fJJ5k5Vk7m7McXTxOzscL/AAKTacKQU1gfLMiYKlpymhCwV+j/AEabn7p7FdMOJy+BktO7zbkrwP6u6vzfBW4N"
        "m/SO1Xsw02LDaaKz1FGJnzh1bDK54LsZGWyNGOGeXaVlF2Z78uxMMPVcp7mj3JoPRD9I3HWNXI+F5vt3kuEfVE5bG5jAGuyB428H"
        "nhkcRxXjHpY3X3Q2yV9PvZFvpKemHmyzrP7RfY+vR17/ACRpr5NP+uWktYarrtcamuOoLk2FlbcJOskbACGNwAAGgknGAOZKspJq"
        "yPRj8bRq0VSo9N+83d0OLp4HtNr6JzsMrrZI0Dve17HD5t5ettVaJfqHWuiL818Ij09NVSSNeTvPbLCWDd4YyHhp444BfnNoHXFy"
        "2dapo9RWqOnlraUPa2Opa50bg9haQ4NIPJ2eY4gLc315uvP5J018mn/XJGSSsxgcdRp0OardN+595vjpX3LwDY7XQZx4fV09P6cP"
        "6z+zXgMFbQ2m7fdTbVrNS2m80dqp6WmqBUt8CikY5zw1zRnekdww4rVoKkndnizHERxFbbhutY/Wxfk5Kfsr/hFegR0y9dn/ANJ0"
        "38nn/XLz25xc4uPacpNpm/NcZSxOxzfC/wAD9Odlv3MdF/E1F+YYvz52rH7Z+s/jir/POWwrB0r9Z6dsVrs9LbLA+lttLFSROlgm"
        "L3MjYGguIlAzgDOAFp7UF7qNSX653mqZEyquNTJVSsiBDGue4uIaCScZPDJKSkmiZjjKVejCEN68D9DNg9/+qPZLpeqc7elhpvBH"
        "55gxEx8fSGg+tfW0Fo2TR0mqgXwugu96nukIjJyxsjIwWuyBg7zXcsjGPQPEWzfpA6o2Y2CSy2mktVTSPqHVANbFI9zXODQQC2Ro"
        "x4ueXMldw+vG11/JOnPk8/65ZKase+jmuHUIc5faiugydMU42kWf4nj/AD0y895Xb9pW0u7bU73TXe8U9DBU09M2la2jY9rC0Oc7"
        "JDnOOcvPb3LpwK1yd3c+BjKsa1eVSO5lp5UKgVDylAp5UKkBSYKkFNQhSMpZTQgwcKsqEwUIVlNSmChCgU1KEIUmCpBTQFJgqQU1"
        "AUhShCWKVZUoQhYKFCFbEsaeBTUpgradMNGUKTzQCcsTllKwuVM0YXL1von97nJ8VV30yryO/kvW+iv3uUnxVXfTKuY5U/0KP/JH"
        "uZ1nJb7RV/Y+9HjFp8UegJ5UNPij0BPK7S54isr7GmdU3XR91bdLNVeDVzY3RCTq2v8AFdzGHAjsXxcoysKkI1IuE1dPemZRlKDU"
        "ouzRs/64PaL74P8AhIf0UfXB7RffB/wkP6K1hlLIAzngvD5owH6EP4rwPT5fiv1Ze1m0Prg9ovvg/wCEh/RWOfb5tBqYJYZb/vRy"
        "scxw8Fh4gjBHk9xWsw4HkQfQnlFlOAW6hD+K8A8fiuNWXtYxgADsC77p/bRrnTMLKeiv88lMwYbDWNbUNaO4b4JHqK6DlGV6q+Go"
        "4iOzXgpLrSfeaKVapSe1Tk0+p2N0M6T+umsDXCzuP3xozn5nL4N729a+vcT4pL66jhcOLaGJsHD4Q8b51g0hsY1Rqzq5zTe5tvfx"
        "8JrQWlw72s8p3zDzrfekNiemNLGOeaA3S4N49fWNBa0/gx+SPXk+dfKeX5ZQltRoxv2I+VmXLKOFThKs5y6E+97vj1HnjS2zPVOu"
        "ZfCaakkZTSu3n19a4tY49pyfGefQCvVehdI0+idNUlohcySRmXzztZu9dIebsewDzBYNWbR9N6KYW3O4M8KA8Wjg+yTHzbo8kenA"
        "Wm63pM15ue9RWKlFtAI6uold1rvOXN4D0YPpXok6uIVkrI4vE1M1z6PoU9mmtVwv63v9WhtXbFbqOv2c3x1Y1n+Sw+EQvPNkrSN0"
        "j05x58rxqTxXf9f7X7zr2mZQyxQ0Nsa4PNPAS7rHDkXuPPHYOAWvsr14anKnC0jp+T2XV8BhnTrvVu9ujcdt2Yn7Y2k/jOn/ACwv"
        "QHSl/c+l/h1H0Rrz7sxP2x9J/GdP+WF6C6Uv7n0v8Op+iNczmv35hP2y7mdpH7nxPbHvR52jXLYuJGuUxdCcPM5DFmaVhYsoUZ52"
        "ZAU1KYKGDKBTUpgoBpgpIQhSYKQOUIQpCQKaAoFUoCoFQxY1SlMIQaoFSmCjDLTBwoCpEYmRMFY2nCtQFKwcrGCqBwhC1QKlAOEI"
        "zImCoBVIYssFUCsYKsFCFgqgVjBVAoQtW05WMFNCGRUCoBTQjRYKtYgVQOFDEtPKWUIQrKYKhUgMg4oBwoBwqyoQrKajKoFUDyqB"
        "UoUIXlNSmChCgU1KEJYrKeVCpCFJ5UIyhCwVWVARlAXlNSDlCApGVKYKEsUChJChDT6EgU1uOmGCkhBQElYnLKVhd2qmaML+S9b6"
        "K/e5S/FVd9Mq8kPXrnZQw3vYO6hj4yupq6lx+Ed/H5QXMcqtMPSk9ynHuZ1fJX7TUXTB96PFTT4o9ATyobkNaDwOBkJ5XZ3PEVlN"
        "oLnNa0EuccNAGST3ALaOzHYxVa8ohdquuFDaesdG3cZvSzFvlbueDQDwyc+hejNK7ONNaLYH2y3RipaPGq5/skx8++fJ9WAvNVxU"
        "IOy1ZzuZcpcLgpOlH05rgty7X4XPN2kthuqdS9XPUwNtNC7j1tYCHuH4MY8Y+vC3rpLYlpbS5jmkpjdK9vET1oDgD+DH5I9eT50t"
        "XbbtK6WMkMdUbpXt4GCiIcAfwpPJHqyfMtEat26ap1N1kNNOLTQu4dVRkh7h+FIfGPqwvP8A69bqR8X/AM1nH/qpv1f/AKfcem9Q"
        "bP8ATOpmYullpJX4wJmM6uQeh7cFan1F0aaWXflsF4kgdzFPXN32+gPbgj1grSNh13qTTMm/a7zWQNJyYzJvxu9LHZBW19O9Jivg"
        "3I7/AGiGqZyM9E7qn+ksOWn1EK8zWpfUdzLzRnOXa4Ortx6P+paex3Pl2Xo56mrLg+K6VFHQUcZwZ2Sdc6QfgNGP62FvDSGybTGj"
        "jHLSUPhVwb/5yrxJJn8Ecm+oetdWuXSO0rT24T0MFfWVjhwpnRdVun8J5yMejK0prDbLqjV/WQuq/c+3v4eC0RLAR3Of5TvaB5lN"
        "mvW0lojF4fO829Cs+bhx4e7e/XoekNYbXtL6PMkU9b4bcG/+UoyJHg/hO8lvrOfMtBav28am1J1kFC8Wegdw3KVxMrh+FJz/ABcL"
        "Vme5GV6KeGpw13s+7l/JrB4O0pLbl0v4Ld3vrLc8vc57nFznHLnE5JPeT2pZU5Rlei59+xWUZU5RlLlO3bMD9sfSXxnT/lhehOlL"
        "+59L/DqPojWhdjdE+47U9JwsBJbXMld5msBeT7GreHSkqg6o0xSg+M2OeUjzFzAPySuRzN7We4VLhGXdI+qtMmxDfFrvRoCNclnJ"
        "caNclnYuiOImchnNZgsLFlBUPPIsLuegtml12hi4m2VNDAKDq+tNW97c7+9jG6133hznHYumBbr2JOLNF7TnNJDhbmkEdn2KoWM3"
        "ZXR48XUlTpOUN+nvaRrbWOkLhoe9vtFydA+oaxsgfA4ljmuHAgkA945di+zoXZXetoFJV1VtnoYIaWRsTnVb3t3nEZwN1rvN7Qu5"
        "bc2i/WLRmrowCa6kEMxHY7AeB7TJ7F2fR/8A4V2caHpfJqdQ3ynmeO0s60OB/Fjj9qwc3s34nkliqnk8ZL6zdvZv7jROq9NVej7/"
        "AFdlrpIJKql3N90DiWHeY14wSAeTh2L4y2dtdtdVets10t1FH1lXVSU0UbM4yTBH29g86+pU7P8AZ1puf3L1Fq+s92WYEwooSYoX"
        "HsPiOzj0g+YLJS0Vz0RxSVODlq2k9Fc06vqzadulPZKe9y0UrbVUPMcVSR4j3AuGB+K72Lud62d2vSGqLS2+XSWbSVyjdNFcaJo3"
        "3N3CQAMOGd4s7CCHZ9G2LrQaBdshscFTdbq3S7atxpqlrR175N6bIcNzlkv/AII5D1xztaxrq41R2HBNpvo7ffpuPMKoLvto0Pad"
        "Ya6qLVp+6vjsMbBKKyuwJNwNbveLhuTvEgDA4DPYu12/Zts91RUyWnTurK2S9hrjH4RF9ilLRk48RuR6CeHHiq5pGyeLpw+tfpej"
        "07eg0uqCz3ChmtlfVUNS3dqKWV0Mje5zSQR7QslntVVfLpSW2iZv1VXI2KNucDJPaewLJm9tW2uBxQV2es0PcKLRdBqySalNurpj"
        "BHG1zutDgXjJG7jH2M9p5hd+ueznZ7pWRls1Bq2sbet0GQUsW9HESO0Bjj84OOOAvr7RrI3TuxCwW6OthrYY7hvx1MPkysf172uH"
        "+q4evvWvb3WPDLFqTgocXxW9dRoUFNbI01s6tA07BqPV95fa7ZVOLaWGFm9NPj+EOBwOHce/hwzybxs3sNy09XXzRV7muMNuG/VU"
        "lSzdlYzid4cG9gJ5ccHB4YWW2ja8VTUtn1XtpftNXgrs9Xoi4UWjKDVck1KbdXTGCONrndaHAvGSN3GPsZ7e5dXW5b9+920v8Yv/"
        "AC6hJO1hXm4OFuLt3mnlTT2LY2ldA2B+mWaj1XfXUNBNIYoYKUB8riM8+Dscjwxy45V6t2dWen0t9VOlLvLcLRHKIp2VDcSREkDP"
        "IdpaMYHMHim0txPKYbWz123aX6LmuFSgHK2JoHZ/bb9Y7nqK/XOShslA/qnmFu9I52AT2HHlNHI5JRu28zq1I047UjX4OFa2LqXQ"
        "mmzpmbUGlL8+rpaZ4jmp6zDJcnHk8G55g4xyzx4YXyNCaGOq/DqysrmW6yW5ofU1bxnGeTWjtPD1esAtpWua1iIODnusdSBTBW2a"
        "XZ/obVD3UGmdUVTrxul0UdbFhkxAyQPEb/zPbhfC0Ns4OorleYrtVOt1HZATWEDL2kF2QOzhuO48eXLiptIx8pp2belulHRV2fSG"
        "hrrrXw/3M6j/ACJgfJ1z93Oc4aOB4ndPcOHNdprtB6Ru1kuNfpPUU01Rb2dZLT14DN8cfJJa3icHHPjw4ZXC2P6dZqi+3CgluNxo"
        "ofA3PcaGbq3SeO0bruBy3DjwRy0uYTrp05SjpbpXwOgLslv0ZXV2mKzUT6ikpbdTP6sGoc4Omd96wBpyeIHZ8xwtD6NrNb3jwGmk"
        "bDDG3rJ6h4yImd+O09wWwW6c0Rdmwabp9c3SSeN+7AyUl1IJD963dDeJJ5O455nKSlYlauovZXr0voaeBVArvFn2dvbtHp9KXp8j"
        "GPLyZaZwBe0Rue1zSQeB3R2d4X3qrQeh9P3Spt9/1JVRVJlcIoqdu91UZPidY4MI3i3BPLGUckWWIgnbfpfTXQ1UqBXatf6Ik0Rc"
        "4ImVIqqCrj62nnAxvDtB84yOXMELqYKqd9TZCanFSjuMmULZdv2c2W0WSju2sbzLQCtbvQUtO3MpbgHJ4HsI7OGRk9i42otn9tGn"
        "pNQ6Wur7lbIHbs8crcSxcuJ4DvHYOHHiFNpGnyiDdvVfh7TX4cryu5XHR1DSbNLTqZktSa+sqXQvjc5vVBodIOAxnPiDt709l+kK"
        "HWt7qqGvlqYooqYzA07mtcSHNHaDw8Yo5K1w60VFz4I6blC71s70PR6yt+oZaiolhqKCJjoC17WxlzhJ5eWnxcsHLHDK+zQ7OtNa"
        "kt1XDpy/z1t7pI990cke5HL8EEAgE8M5OMjKm0loYzxEItxfA1dlMFbTs2zrSd3lfZ4tSTP1Gxh3gyP7Bvjyg3LfGx5nccZXVNJ6"
        "UjuuuYdO3N8sTRLNFMYHAODo2PPAkEc29ybSIq0Gm+jU6wmCto12h9E6duM9DfNSVTKjrCY4qdm8YoyfE6xwYRvYwTwHPu4rruud"
        "DHSZo6ukq21torhvQVDfRnBxw5HIPaikmIYiEmkuO44F90jXaetlnuFVLTvhusXXQtic4uaN1rvGyBg4eOWe1ZLtoy52awW691PU"
        "+B3DHVhj8vbvNLm7wx2gE8M+fC7htP8A8zNn/wDMf7KJfIvNgZDsxsN6NfXyyzVLoRTyzb0EQzJ5DccD4g7e9YqWiNcKsnGLb3tr"
        "vOjAr72k9KVusbjLQ0EtPHNHCZiZ3ODd0OaOwHj4wXY9O6Atp08zUGp7o+326Y7sDIhmSTnx5Hng4AB4cV3vZhp+xU19qbpp68Or"
        "aTwZ0EsM7N2aNxewg8hkENPZ7exKVtxK2JUYy2d66tDQrhuuI7QcJLtejtIw6mqq+atuEdDbqFpknlJBcRx8keo8ezh3rssWgNL6"
        "lpatulL3VVFxpYzJ1FUzAkHm8VuOPDPHmMrJySNkq8IuzNYApqcpg5VNo8pgpIQhSYKkFNCFIypyqQgwU1KMoCwUKEJYljUKYKkF"
        "Nbjpiks5CAUlAIrE/tWUrE7tVMkYHL0j0W9Ts6i86dleBI14roGk+UODZB6sMPrK83uX1dI6oq9G6koL1RHM1LJvFhOBIw8HMPmI"
        "JC+bm+B8uwc6C3vVdq3eB9bKMb5FioVnu49j3+Jn2w6OfojX92oBGW0U8hq6R2OBikJIA+Cct/1V0TK9t7QtHWrbvoOiullmjFxi"
        "YZaCd5xgny4JO7JGD3EA8ufiy6WytslwqbfcaaWlrqZ5ZLBK3DmO8/8AfyPYscgzRY3DqnU0qw0knv00v6+PWfczPB8xV24awlqn"
        "w14fPA2Hs/21XbQVnltUdDTV1JvukhEz3MMTnc+I5tJ44+dfE1btQ1PrMvZcbi9lG48KOm+xwj0gcXf6xK6ZlGV9tU4KW1bU5+OW"
        "4SNZ4hU1tvj87vUVnHoTyoz50ZWZ7S8oyoyjKAvKMqMoygLyjKjKM+dAXlGVGUZQF5RlRldq0BoC77Rb9Ha7VHhgw6pqnj7HTR/f"
        "OPf3N5k+srXWrU6MHVqu0VvZnTpyqSUIK7ZuLop6Okq73ctUzxnwehjNJTEjypX43yPgs4f66+Ht01KzUe0SubA8Pprc1tFG4HgS"
        "zJefxy72LeWs77ath2zqls1mwyudE6ChYcF7nny6h/oJJz2uIHILyHvOkeXucXOcckk5JK5HKNrMcbVzSatH6sOxcfni2e3PascJ"
        "hoZdB3l9aXbwXz0Izx9i5Ua4sa5TF05xsjOxZgsTeSyBQ87LaVuvYp/mTtP+LW/mqhaTC+7Y9XXjTtDdKK2VnUU10j6mrZ1THdaz"
        "DhjLgSOD3csc1jJXR5cVSdWm4R6vc0zbmmqKbXuwmqs1Owy3Gz1zTAwcThzgc+yST2L620GsipNqOzfTdM7/ACazvpQAOwuka0D8"
        "WNvtWldLa71BosVQsdwNIKrd60dUyQO3c48tpx5R5LBWauvNw1IzUVTWmS8skjlbUGNgw5mN07oG7w3RwxhYbDueTyOfOyldbOrX"
        "a1/k29erpS2bpL+F1r2sp2zQxue44DS+lawEnsALhxXZda6x2gWHU1VRUej7fXUT5CaapZQSymRh5bzmvxvd/L2LznfL9cNS3Wou"
        "l0qPCK6o3esl3Gs3t1oaODQAOAA4Bdjte1nWdmomUdJfqhtOxu61sjGSlo7gXtJA9aOG4xlgpNQdk2opa3tp0HattN31TNDZLfqa"
        "ls1O7qzUwx2/e348gAteC44xy4cDg4JwvqXShqrh0dNMR0dNNUSMuD3ObCwvIHWVAyQOziPatNXK6Vt5rZa24VUtVVynL5ZXFzj6"
        "12DTm0nVOkqI0Vou0lPSlxf1RiZI0E88b7Tj1K7LsrGyWGkqcIwteLv0Lj29J3LYro23Xm4X+e8259bU2mBskNtk8UyvO9zB5+SB"
        "g8PG4rZWzu7SXPU0A/YzobBFFv8A+XupxFIw7rvFaTG0uceRA7MrztFrK+wagmv8Nyliu87i6SoiAZv55gtA3SOA4Ywvo3Hafq67"
        "VtFV1d7qHT0L+sgLGtY1jsYzutABOCRxB4EjtUlBs118JUrSk21qul6acOkW0qkqKPXuofCIJYeurppY+sYW77DI7DhnmD3rl7Jb"
        "lTWnaJYaqre1kAldGXOOA0vY5gJ9bgvhal1Vd9X10ddeqvwqqjiELX9WxmGAkgYaAObj7V8cFZ20sz1qm3R5ufRY2ftO0FqRmurt"
        "NHaa6sgrql00E1PC6RrmuOQ3IBwRnGD3dy7ftDslZpzYVpq23AbtZDWtMjc53C4TODfUHAepa1odrOs7dQNoae/1Ap2t3Wh7WPc0"
        "dwc4Fw9q+ZcNa327WOGy11xfUW6GZ1Q2ORjS7rCXEuL8bxJL3cyeaw2ZaXPLzFd7Ck1aL69Tf8Op71Hss0vcNKWqiuwpYG01ZBLC"
        "6aSNzGhpIa1wPMEnnwIPJfJdrLaFU6RvV0qdP2K226KIxyipp5YJJWuBB3AX8cZHPmTgZ5LSWntXXzSkr5LPcp6QyeW1hBY70tOQ"
        "fYuTqLXeotWsZHeLrNVRMO82LDWMz37rQBnz4UUNTUsC1Lcmr3vrc+AtyX7h0ddLfGL/AMuoWmgV9qo1Xd6rTtLp6Wr3rPSyGWKn"
        "6tg3XEuOd7G8eL3cz2rZJXseutSc3C3B37zdFDZbXo/QWn7pRaMZqetucbZKiWSPrRCS0HGN12OJ3eAHI5OV928Q1d22N31kWlYr"
        "NVTSMc220cXjkB8R3nMa0EOIHIjOACtE6f2ian0tSGktV3mp6UkkRFrZGtJ54DgcepZrXtN1ZZqitqKS9TtmrX9ZO6RrJd92MZw8"
        "EDgAOHYAOxa3B3PFLB1XLaum077307uhHVQcLbuzil1PR6Put2sZorpQul6upss0JmMmMZO7w7D2HiO/C1EF9aw6mu+mKl1TaK+a"
        "klcMO6s8HjztPA+sLZJXWh7a9N1IbMbes29Jpa26s0Xf7vWaUdpm4WyIyxSs3o46ghpJaI3AdwH+sOPYuTsWutQNDakoLRDS1F9h"
        "m8KipqkZbK0taMYyM+QRz4EjK1Zf9oeptUUvg10u809NkExNa2NrscshgAPrXxbZdK2z1kdXQVUtNVR+TLE4tcP/AIWGy7WZ5XhZ"
        "ypuMnxut7S9upv3Tur9o96uZpotKWmhfGHF09XRTQsZgct4v5nlwzz7l1zRj9VXe+6rv1oqraLjGT4VbmgvjqufBoyQRkHB3u3zr"
        "pNz2oauvFE+irL3O6meN1zWMZGXDuJaASF8G0XqvsVYyst1XNS1LRgSROwcdx7x5iooEjhZKMtEm/X7Tdun9N0W0CO40950V9T1R"
        "BCXtuFOx8EYfnluOAHn7eAPLgvjdHf8AzwuPxe785Gul3babqy+UT6OuvUz6Z43XsYxke8O4loBI8xXy9O6ou2k6ySss9X4NUSRm"
        "Jz+rY/LSQcYcCOYCbLs0R4ao6c4N79yu7L2mx9h80VVHquytmbFX3Oi3adzjjiGvBx+OD6j3LqVu2d6oqL5FbxaK2CYSAOmfERHG"
        "M+Vv8sDnkHj2LqlLVTUdRHUU00kM8RDmSRuLXNPeCOS7fJtX1jNSmmffagRkYy1rGv8AxwN751lZ3ujOVKpGcpU7el0m2rjcqav6"
        "QNkjp3te6jpXwSlvHx+qmcR6g4LTWvHufrbUJcSSK6Yce4PIC+VaL5cLFdYrpQVBir4i4tmLQ8guBB4OBByCefesFdX1Fzraitqp"
        "OsqamR0sj8AbznHJOBwHE9ikY2ZKWHdOSd9Ere82vtcOdJbPCeJNA7J7/scC1KvqXbVF1v1HbqS4VXXU9uj6qmb1bW9W3DRjIAJ4"
        "NbzzyXysqxVlYzoU3Tgovr7zdm1yz12qorFqCzU0tbbZKQM3adpeYjkni0ce3B7i3iurU+iLzbdE3O7V9wqbRS7wa2hlDmmrPIZb"
        "kd+BkHtPJdbsGtb/AKZY6O1XOaniccmPg9me/dcCM+pYr7qu86mkY+7XCaq6vyGuwGt84aMAH1LFJrQ0wo1YJQTWyvabObb6nUmw"
        "6201sifVVNvrHulhiG8/ypDwA4k4kaV9DYZpe522619yrqSakifTmCNs7Cx0hLmkkA8cDA4+daisOqrxpiV8tpr5aV0nlhuC13pa"
        "QQfYvqs2l6qbdDcxd5DWGIw7zo2OaGEgkBpbujJaOQ7EcXZpGupQqOMoRas9TuGyU/8AhTaCRwIoW/m5lGwL/PGu+L3/AJyNa+tG"
        "p7pYqS4UlBVdTT3GPqqlvVtd1jcOGMkEjg53LHNGn9S3TS9Y+stNV4PUSRmJz+ra/LSQSMOBHNo9iOLd+szqUJSVS34rdx2rZM4n"
        "aTasnJLp/wAy9fc0wft7T/z6t/IlWtLPe62xXKK40E/U1sO9uSbjXY3gQeBBHInsXc9l1bPctqNurKmTrKmokqJZH4A3nGKQk4HA"
        "ce5JLe+oxr02tufDZt3l7QtF35msLnLHbauqhrJ3SwywROe1wccgZA4EcsHuX3NeU77Bsw0xYq8gXQTGd0ecljfHJHq6xo9RXwr7"
        "rzUendUagpbbdJYabw+ciMta9rcyHOA4HHqXS7ndq681j6u4VUtTUv4F8jsnHcO4eYKJN2uSFOclDatZeBsvah/mXs+/mP8AZQp6"
        "g+4fpn+fH6Z1r66amul6orfR11T1tNbo+qpmdW1vVtwBjIAJ4NHPPJOfU1zqrHS2Sap3rXSydZFD1bRuu8bjvAZPlu5ntV2dEWNC"
        "SjGPQ79/ibO1PbKvVezbSlVZ4n1TbfF1M8MI3nhwa1pO6OJwWn8bPJczYlpi7W6519yraSelpXQdSxszCwyOLmnIB44Abz861TYt"
        "V3jTT3utVwlphJxc0Yc1x7y0gjPqX1GbSdUtuPh/uvIarqzEHOjYWhpIJAaW7oyWjiBngo4u1ka50Kmw6cWrM7bs5sFum0/e77Pa"
        "fdmvpJTHFQnjkYBzu8c5yew+TwXfNnlc+4V9RI7RtLYWCIhs7YhHJL4wy0DdBLe0nlnC0DZdR3XTtS+otlbJTSyDD93BDvS08D6w"
        "voybQNSy3WK6Pu0xrYmljH7rd1rTzG5jd44HZ2DuRwbJVw05uWu/tPh1tNNR1csFRDJDMx3jRyNLXDt4g+ZYFzLtd62+3Ga4XCbr"
        "qubG/JuhucANHAADkAuFlZnsSdtS0KQ5PKAaoHKjKAUJYtUoymHIQpCWUAoLFAoSQlxY1CmCkhbjpCkIBykUAFYnBZTyWNyGSMLl"
        "geOK5LgsLhkKm1M7vsw2qXLZtcnGNpqrRUuBqaMuxvdm+w/wXj2HkfN6PuundBdICysrIpQ6thZhtTBhlXS/gyNPNuew5HcV4zc1"
        "ci3XOts9ZHWW+rnpKqPyZoJCxw9YXwsxySOIqrFYebp1VxXHt+e259/Ls6lhocxWjt03wfDs+fYbK1T0X9ZWaV77OaW90mfFMLxF"
        "NjzsecZ9Diuhz7Jtd0zy2TSF6BH3tK5w9oytmWHpLawtbGxXBlFdY2/wqiMskP8ArMIz6wV22HpY+KOu0oN7t6uuOPnYvNHF5/Q9"
        "GVKFTrTt8V3H0tvJ6vpKpKHU1f4PvNA/sX6296N8+RP/ALkfsX6296N8+RP/ALl6D+uxi96r/l3+Gj67CL3qyfLv/wDCy8555/aL"
        "+S8S83lH9w/4vwPPn7F+t/ejfPkT/wC5H7F+t/ejfPkT/wC5eg/rsIveq/5d/ho+uwi96r/l3+GnnPPP7RfyXiObyj+4f8X4Hnz9"
        "i/W3vRvnyJ/9yP2L9b+9G+fIn/3L0H9dhF71X/Lv8NH12EXvVf8ALv8ADTznnn9ov5LxJsZR/cP+L8Dz5+xfrb3o3z5E/wDuR+xf"
        "rb3o3z5E/wDuXoP66+L3qyfLv8NP66+L3qv+Xf4aec88/tF/JeI2Mo/uH/F+B57/AGL9be9G+fIn/wBy5tDsb1/cHhkOkrq3P8Ka"
        "Lqmj1vIC3v8AXXRe9V/y7/DXGqulZO5hFLpaFr+x09Y5w9gaPpTzlnr0WFiu2S/+hs5OtXiG/U/A+JozopXWslin1XcYqGm4E0lE"
        "4SzO8xf5LfVvLa9/1povYbYhZbPSwOrmDLLfTuy8vx5c7+JHr8Y9gxy0Lqbb1rTUkb4BXsttK8YMVvZ1ZI878l3zrWxLpHue9xc5"
        "xySTkkrV5oxuYTU80q+ivwR3ev5b6zVVzvDYSLhl8PSf4pb/AFL/AB2H2dTaouesbzUXa7T9dVzcOAw2No5MaOxo7v8AmvnMCxsC"
        "zsaumhCNOKhBWS3I5OrUlUk5Td2zMwLkMWFgWdgVPLJmZvJZRyWMLICoamUE1KYKGDLCFKpCAmCkhCMpMFSCmgKQgIQgwU1KpAMF"
        "NSqByhCkA4UqliQpMFSCmqYlJgqQU0BSpQCqBUIUDhWsaYKpDICmpBTBUBYKpYwVWUIUmCkChDEyBypYgVYKEKVgrHlUDhCFp5UA"
        "pgoQyA5TWNUCoQyJgqAVSEKTBUJ5QheVQUByeUIUFWVGUZQhkBTWMOVZ86AvKN5RnzqgcqEsVlPKjKYKoKyqDlCFCWLympByhCF5"
        "RlTlAKEsWCnlQnlAXlCkFCCxqVCQKa3HSAnzCSAcIQEiEyhCoxEZWJzVyCFBGUM0zjOblYy1cktUFipmmcctS3Ss+4luIZbRh3U9"
        "1ZdxPc8yDaMO6nurLueZPcQbRhwnurNuJhiE2jDuo3Vm3U91BtGHdT3Fl3FW55kJtGIMVtasgYrDFDFyJa1Z2NSaxZWtQ1SkU0LO"
        "0KGhZWjChqbKbzWQKAqHBDWyl6b2B6r0bZ9ISU81bQ2y8iUmtfWStiNR4zurLXOPjNDeGByOTgb2XeZELCUdpWPLisMsTT5tux7y"
        "/ZA0l76LJ8vi/SR9X+kvfRZPl8X6S8GhUtXMrpPmeZIfnZ7w+r/Sfvosny+L9JH1f6T99Fk+XxfpLwgCmrzK6R5kp/nZ7u+r/Sfv"
        "osny+L9JH1f6T99Fk+XxfpLwihTmV0k8yw/Oz3d9X2k/fRZPl8X6SPq+0n757J8vi/SXhNAKcyukeZYfnZ7t+r7Sfvnsny+L9JH1"
        "faT989k+XxfpLwohOZXSPMsPzM91/V9pP3z2T5fF+kj6vtKe+eyfL4v0l4VBTTmV0k8yw/Mz3DX680Y6hqhVahss9KYnCWLwqOXr"
        "GYO83cBJdkZG6Ac8sLxbdpaKa7V8lthfDbnzyOpopDlzIi47jTxPEDA5n0lcAHCpZwgonswmCjhr2bdykwVIKayPWUqCgFNUhSYK"
        "SEBYKagFUCoQoFUCoVKkKVAqAU1CGRMFQHd6pCFKgVjVAoQvKeVKYKEsVlVlQmChDIDlMLGqBQhkTBwseU8oLGXKMrGCqyhiy08q"
        "AjKhDIHKsrGmCqQtMFQmCgLQFOVShCkwVGU8oSxaFIcnlAPKrKkIUIWCjKnKAUIWgHClMFBYrKEkILGp1QOVAKa3HRlIQhANJCfN"
        "CCUlqpPmhUzEWqd1ZsJYBQtzCWI3Vm3EbiF2jDuI3Fm3U91BtGHcRuLNuphqE2jDuJ7nmWbdRupcm0YgxG4swYnuoNoxbie6su6n"
        "uqE2jFuKw1ZA1MNQxciQ1ZGtTAVBDFsYCtIBNDBlNVKUwUMWUCmpTBUINMFJCApMFSCmhCkIByhCACqUpgoQoFNSmCgGmCkhCFJg"
        "qQU0IUmCpBTUBSpQCmFDFlKgVKFSFJg4UgpoCwcphYwcKwcqELQkCmqQoFUCsaYKWIZcoUA5VZUIUDhVlQmChDJlPK7NoG76Xst4"
        "nn1bp2W/W11O5kdLFVvpyyXeaQ/eYQThocMfheZbm6Qth2a7P4Y7BZNGS018uNBBX09xFxne2AOmIc0xveQ4lsbhn8LzK20ub44f"
        "apuptLTtv3cTzplMFehRpDZpsw0No25a0styv901TTCt/wAnqnQspISGuGA1zcnEjeBzkg8uC6Lt12cUWzHXIttrqJZrXW0kdfS9"
        "ccvZG8ubuk9uCx2D3YRqwqYWVOG02uF1xV9xrZMFQCtydG3Rentc6zu9FqW3e6FBSWiarZCJpIvsjZYgDljgeTnDnjiiVzVSpOrN"
        "QjvZp9PK9CRaV2bbT9n+sbxpXT9fpm66YpvC3CSsfUQzt3XO3SXk8SGOHDHEjnxC4GlNG6G0nsltuvdaWuuvsl6rH0tJQU9Q6Bkb"
        "WF7S5zmkHOY3dva0Y5lNk3eRyb0krWvfhbd0X39RosFUt5a/0bobQd60PqyG01ly0VqSjkqjZ5ql0crHCMYb1rTvAAyxnmeLSMkF"
        "dwuFBsdt+yu069OziofT3GvdQtoxd6gOYQJPGLt/BH2I8MdqbIWCleUXJJx147tNdF1nl1GVzLzUUVVd7hPbaR1HbpaiR9NTOeXm"
        "GIuJYwuPF2G4GTzwuFlQ8TVmWHJ5XpTUdp2V7O9GaArbxoOe7V9/tMNXLNFdJ4vsnVxlxI38cS8ngAAtZW6z6c2nbU7PZ9OWyXTt"
        "muEjInQvqHTuZgEvcHPJOSAcA8M4VaPTUwjg1DaTk7aa8fVb3muQU8r0Zc7dsPo9U3XRVws14sk1C+Sm93pap7/srAfGMeSN0kcC"
        "G8cjgM8OpbINnWndQS6yvWoaias07pOnM746MljqzO/u4JwQCI3cOByRxHFLB4OW2oRkne/Hdbfc1CvuaU0he9b3UWqw0D62uLHS"
        "ljXNYGsbzc5ziGtHLiSOJA5lbB1lSbL7/oWS/aTZLp++UdQIn2WqqjMamMkDfYXEnhvZ5/wXcORWxujnoKy3HRFbV3uWugm1JXSW"
        "mkNNXT07XhsD3nebG9oeDh/BwI8XHaijrYyo4J1Kyp3TT1un/wBadGqPMVTA+kqJYJCwyRPLHGN7XtyDg4c0kEecEgqAQtk7HNF0"
        "F+2xWvS+o6PwikMtVDU0/WPZl0cMpxvNIcMOYOR7Ft+1bEtJO2+VFimtZn0pWWj3RoqfwiUbhyxhG+HbxIcH8Ce0KKLZjRwNStFS"
        "jxeyeWMoyt77NNN6Gp9i181pqnTL71U0N28Ea2OtlgO4WQ4HiOA4GRx5ZXQdeah0NeaSkj0lpCew1EchdNLJXyVAlbjg3DycceOU"
        "aNc8NsQU5SWqvbW/db3nRwUZXpS+2bZRoLSWz+pvui6qvqdQ2qGqqKunuEzHMd1cZe7c390kl5OBgLWG27Z5SbNNbutdvqJJ7bVU"
        "zK2lMpy9sby4brj24LHerCONi1sHKlFybTta9uF9VwNd5QpRlQ8ljIhQChCGqlSlC2nSFA4VKUwUINCEIiMfNGMJKkAIQE8IAwjC"
        "aYGVCXJwmBlPCeEFxYRuqsICEuIBPCaYCEuThMBPCaAMICYTwhLi3VQCYQhAVBIBMcEIxgJoQhGMFNSmChCwhSqQxGCmpVA5UAJg"
        "pIQFKlKAUMSkIQgGCmpVA5QhQOUKVSAFSlCEKTBSQhCkwUkKAsFNQCqBQxY0wUkIQpAKQKaAsFUCsYKahDIhIHKaEAHCsFQmCqQy"
        "AprGqDlAcmlpKiteY6aCWaQDeLYmFxA78D0r0J0vKOpOttPVAp5TBHp+ma+UMO609dNwJ5A8R7VpjRWvdQ7O7rNdNNXDwGumgNM+"
        "XqY5cxlzXFuHtcObGnOM8F2TVG3raFrSxVdjvmoPC7XV7nXQeB08e9uvD2+MyMOGHNB4HsVTVj005040ZQbd3bhpp6zZm3Gy3LUG"
        "znYtUWqgqq6EWVlMXUsTpMS9XCNw7oODlrhjzHuXA6Xr2jaNY4N4GWmsNPFK0HO47rJjg+og+tdK2WbctUbNK2309Pcp5dOR1AfU"
        "W14a9jmE+OGbwywnJPikceeeK4e2q4WK87Rbtd9O3uW7225OFSJZmStfC53OI9Y0EhuOGMgNLR2KtqxtrVoTpSlHe9m67Fw6fgdB"
        "yvQvQ9kMW0TUD2tD3MsFQ4NcMg4mg4ELzwuyaK17qDZ5dZrnpu4eA100Bpny9THLmMua4tw9rhzY05xngonZnlw1VUqsZy3I9KUW"
        "oLjtU2LbQG3ywQaYhs8IrKea1QyUdPVyNa53VPYSQ/ixo7fKHI4z1XUVvq710UNBe51NNVmiutQKhsDC8xZkqMbwHLym/jDvWr9X"
        "7Z9da8t/udf9Qz1VCXBzoGRRwseRxG8I2t3sHjxzxXE0ZtS1ds+ZPHpu+T0MM53pIQ1kkbnYxvbjwWg4xxxngFdo9UsXTk7Su042"
        "b0vvvu3e82v0hIJbds42M26qjdDX01qlM1PIMPjyynxvDmOLSPUVj1If/tF0f/8A0L/oqlpfU2q7zrK6Pul9uM9fXPAb1sx5NHJo"
        "A4NHE8AAOJXIqdbX2s0hR6Smrt7T9HUGrhpeqYNyU72Xb4bvHy3cCccfQlzTLEwc5yto1Ze7wPhAprGCqysTw2PYOu9oF20Vs82U"
        "R23S9mvbaqwwOe65UD6kxbsMOA0tcN3OePoC0FDUal1/tUpam10NFZNS1ksb6aCkYaSGJ8cY3S0OJ3Serzz4uPnXMtXSK2lWS10N"
        "soNSdTQ0MDKeCLwGmduRsaGtGTGScAAZJJXUtSa61Bq7UDNQXe5STXlgYGVUbGwuZueSR1YaAR3jism7nvxOJhVs03pbSyW5cHf4"
        "HqPSl4vO0/V0+hdp2gKSpqI45YpLzDSGKWAsacP6zlhxGAWkA5HAhdN2L2sN0lt1sNtea6o8DEVM2Ibz6hrPCG5aBzzlvLvC1pcN"
        "ve0e6Wl9rqtV1jqN7NxwYyNkjm8iDI1oefauoaa1XedHXRlzsVxnoK5gLethPNp5tIPBw4DgQRwTaM5Y2ntxlq7Xu3a9mreu3Wfd"
        "OzDUUWiKvWFTStpLRTTtp8VJMcsriWjxGEeMPG5/gu7l6a8E05onS+yG3XrWUWnq2zBl5ko30Uk5qnSHec0uaRueVIzJzz8y8waw"
        "2pau1+Kdmo73PXRU7t+OIsZHGHcs7jAGk47SM8SuDq/W9915dI7nqGu8MrY4WwMk6pkYbG0khoaxoHNx7O1LpbjVSxFKhtc2m723"
        "9t3uenA9KUenfqc6ZtK1jN2C4OqK+M/fdZSSlx/H31sTY7UM1Ne6ytc4Gv0xdLra3/fGnnmErCfMHMLR615Ak2vaxn1JadRyXjev"
        "dopzS0lUaaHMcRa5u6RuYdwe7i4E8VOmdrWsNHXK73Gy3h1LV3eTrax/g8TxK/ec7O65pA4vdyA5opI9NHMKVOd7Ozk3w42tx6V7"
        "DdeyTUNXpbo2anudDaqK61MV+3W0lbTmeJ+WUwJLAQTjORxWoNpOubrrVttdctM2iyNozIGG20D6YTb+7nf3nHexucO7J71g0btg"
        "1ps/tcts05efAaGaY1D4/BYZcyFrWk5ewnkxoxnHBYtabV9X7Q6WlptSXfw6CleZIm+DQxbriME5YxpPDvUbujy1cTCdGNNNqyta"
        "ytv6b39x6pFy0gKPYfZtU6dpri66WiBlLWzyndpniGLdaY8YeHuLRxPDuK81bcrnf7ltPvw1II219LL4OxkTSI2wt/a90HjgtIdx"
        "++XWr3rrUGoqWxU1yuLpYbDC2nt4bGyMwMaGgAFrQTjcbxJJ4c1OrdaXvXd1F01BWNq7gI2w9cII4iWjOMhjWgnjzPH2I3dDFYyN"
        "aDgtNV0dFtfgfDyhSqWJ84eUJIQljVqEIW06QYKalMFCMoFNSmChBoBwhCEKTBUgpoCkJApqEKQpBwqQgwU1KYKEGgHCEIQpAOEg"
        "U0BSAkCmhCkJApoAVKUwUIUCmpTBQg0IQoRlIBUhUqCkJApoYlIUg4VKAFSlMFCFApqUwUINCEICkA4Ug4VIQpCQKaAYKalMFCDC"
        "pSmChBoBwhCEZYOU1j5LIDkKEBMFJCEKTBUgpoQpUCpByhAZEKU8qEKBTUpgoQsFPKhUqQpMHChPKhDJlNQCmgsWCmoBVZQhQOFW"
        "VCeUIVlPKjKaELBTUApqWIZEKAU8qkKTypyjKAoFVlQE8oQsOTyoTBUIUCmpTyhCsoDlOU0BeUKQUIQ1cqUphbWdIxoQhCDBTUqk"
        "IykJDmmhATBSQhClQOVIQEBSYKSFCMpCQTQgwU1KpCMEwUkIQpMFJCApMFJCEKQgIQDBTUqhyQjGCmpVIQEwUkKEKTBUhNUhSYKS"
        "EIUhIJqAYKalUEIxgpqVSEBMFJCEZSYKkJoCkIQhBgpqVSAYKalUEICYOEkKEZk5oUBWEMQTBSQoClSlMIYlApqUwhSgU1KoIQoI"
        "ClUhCkJBNCWBUCpQqQvKoHKhMJYFoyllMKEGCmpVICkAqQqQxKTyoRlAXlMHKkIQxKTykhBYoFPKgKlGQoOTyoVIQpGVIVIQeUJI"
        "QH//2Q=="
    ),
    "stoploss": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQAAAwADAQEBAQAAAAAAAAAAAAECAwcIBgUJBP/EAF4QAAEDAwICBQUHDQsJ"
        "BwQDAAEAAgMEBREGBxIhCBMxQVEUImFxgRUyVnWRlLEWGCczUmJykpWhstLTFyM0NzhCVYKz0eMkR1NzdIW0wcQ2RJOipMPhJjVF"
        "RlRjdv/EABsBAQEBAAMBAQAAAAAAAAAAAAEAAgMEBgUH/8QAQxEAAgECAwMHCAcHAwUAAAAAAAECAxEEBSESMUETUWFxkbHBBhQV"
        "IoGh0fAyNFJTcpLhFjM1QlRz8SMkQyVjgtLi/9oADAMBAAIRAxEAPwDklMFJC6h7MpCAcoUKKQpCpQjBTUqgcqFAqUpgqIaYKSEG"
        "ikAoByhQopCQKaBBUpQFCigqUpgqIaEIUIwUwpTBUJaEgU0CCYKSFMUUFSgFUCoRoQhQjBTClMFQloSBTQIwU1KYKjRQTSCaCKTC"
        "QTChKBVBQqaVCZFQUAphAlKmlSmFM0ZGnBVhY2nmrB5qItMFJAQaRYVgrGrByoS1SgKwgRjtVAqB2qlCWFQUAqwVCNCEKEoFUsY7"
        "VkQxBUFKAgilQUoSaKQhCiKCFKpAjBTUpgqEaEIQIwU1KYKhGqUpgqIaYKSFCUhIFNQlISBTUIwU1KYKCGhCFGigcoUoSRp8HCpS"
        "mCu4eUGqUoBQJSYKSFCUhIFNQlIUgqlCMFNSmCoRqlKAUCUmCkhQlIQDlCBGCmpTBUJQKalMFRDQhCjQwVQKhUoSkJApoIEwUkKN"
        "FgpqUwVENCEKEYKoFQqUJSEIWTSGCqBUhNIlgpgqUwUCWmFIKoKIoKx3LGrByhiWmFIKoKNIodqsFYx2qhyUJlBTClUCgUUqHJSm"
        "OxQmQKgVjCtAlDtVKQVShAdqyLGFQUJYKalMFQjVKVQQJSAkCmgSkJAprQgCqUpgoEaAUIUSKQkCmgRgpqVShBCEIFFIUg4VKEYK"
        "alMFRDTBSQoSkwUghQlISBTUJQOUKVSBBCEJE0+hIFNdw8mMFNSmChiUCmpTBUI0wUkKNFJgpIURSEgU1CUEKVShGCmpTBQxGqUo"
        "BwoSkIQgRgpqVShKQpVKIEBCFGilSgFNDEpCEJEAqUpgoEtClUogQEIUaLBTUhMFAlBNSFSCGEx2pBMJNFDtVjtUKkCilQUg5TCh"
        "LVtWMFU04KGJYVKVShRY7VQUDuVAoNIyJhSCqCiKCoKB2qlCUrHYsYKsFAlKlKYUaKBTUpgqEsJhQrCiGmCkhDNFKgoBTURSEISI"
        "wU1KoHKBBMFJCiKQgHKECUhIFNQgmCkhAopCQKahKCFKpRAqUpgqNDVBShRFIBwhChKQkChAmnlQOVKF3TyZSEIUaKQpCpBFA5Qp"
        "RlQ3KVKMoDlDctPKjiRxKK5YKYKx8SeVDcyoWMOT4lDcvKYKjiRlA3MoKaw5VByrDcyIUZRlQ3MgKoFY8oyobmXKFAOUwUCmUmCk"
        "hRosFNQCqBQI0IQkRgqgVCYKBLQkCmoRhNSqUaRSpYwcKwUENMFJCBRYKoFQqSxLCoKAqCBRSbTzSQoUZQrCxtKsFAlBUCpCajRY"
        "VhQ0qgUCWqUqgogVtOQoTBwUGjICqChMHmokWhCFGikwcFIIUJkQpaVSiBUFKEGiwU1KYKiQ0IQo0UhSDhUogVKUA4QJSYKSFEUh"
        "IFNTEEwUkINFJgpIURSEgU1EMFNSmCo0MFUpTBUSGhCFCaeBTUqgu4eUAHCpSmCoUNMFTlBKiLykXKCUsoK5eUsqOJe00TtXqTXh"
        "EtupBFQA4dW1J4Ih4gHtcfQ0FcdevSoQdSrJRS4so3k7RVzxwenxrqCydGawUEImvd2q6x7ebup4aeIe05P5wvqnbjaCh/e5nWsP"
        "HI9ddjxf2i+DLynwe1alGU+pfFo7Dw00ryaXWzkriRxLrT6htm/9JZPysf2iX1DbNf6SyflY/tFn9paP3NT8q+Icivtx7TkziVB6"
        "6y+obZv7uyflY/tEfUPs3/pLJ+VT+0V+0tH7mp+VfEuRX249pydxo411j9Q+zf3dk/Kx/aI+ofZv7uyflU/tFftLR+5qflXxHkV9"
        "uPacn8SOJdY/URs393ZPyqf2iPqI2b/0lk/Kx/aK/aWl9zU/KviXJL7ce05QD0+NdXfURs3/AKSyflY/tFTdqtqrz+90TqTrTyBp"
        "Lrl3yFx+hD8pqC1lSml+FfEVRvoprtOUOJUHeldDaj6McfA+TT95eJMZFPcG8j6pGjl7WrRupdKXnSFeaK80EtLKclhcMskHi1w5"
        "OHqX08FmuExulCd3zbn2PwCdOdP6SPmgqgV/OHLIHL6JlSMwKpYwVQKDaZSpShRtMsFNSqCBBCEJFFJgqFSBKQEBChRSoKAU1Giw"
        "U1KpDJFDsTCkJoEsFUCoVBQlhNSFShRQVgrGFYKjRkCpQDyVg5WSGDgq1jVApNIyAqwsYVNOCgS0IQpiigVSgKgUCZGnITUAqwcq"
        "FDCalUoUMKgVCoFQlIQDlChQAqlKYKBKBTUqgcqQoEwUkKEpCQKaiGCmpTBQI1QUoUJSEIQxAKlKYKhGmCkhRFIQDlChRQOUKVSh"
        "GChJCiuafQhC7h5RFISBTUIJZTKglQXAnCkuSJXtNqdEnXusqS3ShwoIQaircO6JpGRnxcSGj1+hcVetChSlWqOyirsEnOSiuJsD"
        "ZXZUambFqHUMLvcjOaakOQaog++d38GfxvV2+13G35oNJl9i0pBTVNbTDqnT8I8mpscuFrR78jwGGj09iN+9xzpK10+lbG9tNXVU"
        "I610Pm+S0/vQxuOwuxgeDR6QuV8gcscl8HK8rlnMvSGYfQ/khwtzv516rI6eZ5n5p/tsM/W4vwXzp1n3tQ6xv2q53S3m7VVYSchj"
        "3kRt9TBho+RfDDWjsa0exTlGV7inThSioU0klwWiPKznKb2pu76SsDwHyIwPAfIpyjK5DJWB4D5EYHgPkU5RlVyKwPAfIjA8B8in"
        "KMqIrA8B8iMDwHyKcoyoisDwHyI4Wgg8IyO/CnKMquR7bSe62q9HSRihuks1I3GaOrJliI8ACct9bSF0hpXXOlt7bLNZ7nRRsrg3"
        "iloJnZI//shf28vEYI7xhcc5X9VuudXaK+mr6CofT1lM8SRTRnDmOHf/APHevPZt5PYfHLlKa2Kq1Ulpr0239e9H1sBm9bCyUZPa"
        "hxT8ObuPc7n7a1u3V3bGXOqLTUkmlqiMZx2sd4OH5xzHo8O1y6/slwtu+22csNW2OKtcOqnAGfJqpoy2RvoOcj0Ehci3GgqLRcaq"
        "gq2GOppZXQyMPc5pwfoXzMnx9Wup4bFK1Wm7Pp6fnr4nqp7No1abvGWqG1yyAr+Zrlma5fZYxZmBTUAq0HImMFNSmCo0WhSCqQIJ"
        "gpIUxRSpQCqChQ0wUkx2qNFAqgoTBUSMgTUgqkWEYKoKFQQaLCsLGqBURYVAqFSjRYOFYKxgqwhiWmFITChLBVrGrachRpGRpTUB"
        "UCghhUpTCjRQKsFY1TSgjImFAKpQlICQKahRSpQCmCoSkIQoRgpqVQOUCUhSDhUoQTBSQpiUhCFEMFNSqQIwU1KYKhGhCECMFNSm"
        "CoRqlKAcKIpAOEIUJSEgUKE1AhIFNdw8mCEIUIEqHFMlQ4pMtkuK6p6MNjjoNJ3W9zANfXVPVB57oohk/wDmcfkXKbj2rsDbQ+Qd"
        "Hzro+Txb66XI+6zJz/MF5zyolLzONKP88ku9+Bz4NpVHJ8E2cway1HLqzVN2vMziTWTuewE+9jBwxvsaAvh5WNhwxo8AFWV7alTj"
        "SgqcFZJWXUjwk5SnJzlvepWUZU5RlbM2KyjKnKMqKxWUZU5RlRWKyjKnKMqKxWUZU80ZUVisoypyjKisVlGVOUZUVjcnRv1I+1a7"
        "danPPkt4gdGW55dawFzD68Bw9qydI+xNtevGXCNnDHdaZszj4yN8x30NPtXhNrp3U+5GlJGnB90Ym+wnB/MVuXpUxNA0rLjzv8pZ"
        "n0fvZXiswiqGf0pw/wCSDT9l/gj12Tzc8BKL/lentt+pzywrO0r+VhWdhX3TvQZ/Q0qwcLEFkByEHOi0ICEGxgqgVt3RHRj3K11S"
        "RV1HY/IbfKA6OpuUggDwewhpy8j08OCvbVPQf3JghMjK7Tk7wPtcdXKHH8aID861sN8DryxlCL2ZTVzm1C9jrranWO2szI9TWKpo"
        "Y5HcMdRykhkPgJGktJ9Gc+hedslnq9Q3q3WigjElfcaiOlgY5waHSSODWjJ5DmRzKz0M54zjKO1F6H8CoFbz+tA3Z/oKl/KEH6yY"
        "6IG7I/8AwVL+UIP1k7EuY4ljcP8AbXajRqFvMdEHdn+gqX8oQ/rJ/Whbsf0FS/lCD9ZWxLmHz3D/AHi7UaNQO1fc1jpC7aD1HW6e"
        "vkDILpRcHXRskbIG8bGvb5zSQfNcCv6tGbeao3BrXUemrLVXGVmON0TQI489nE92Gt9pCzZ7jn5SOzt305zzYVgroqg6E+5NZCJJ"
        "qnT9G8j7XPVyFw/EjcPzr4+o+iNufp6nfPFbKS7RRjLvc2pD3Y9DHhrneoAla2JcxwLHYduymu00cmFkqqSooKmWlq4JaephcWSQ"
        "zMLHscO0EHmCsYXGztp3KBVBbu+tG3W/oOl+fw/rKvrR91v6Epfn8P6y3sS5jr+e4f7xdqNIhUFuSt6Km61DC6b6m2ztaMkQVsDn"
        "ewceT7Fqm72W5aeuEtvu1BU0FdFyfBUxGN7fYRlZcWt6OanXpVf3ck+pn8QVhQqBQcxkaVS/rsVnqtQ3u22ihDTW3GpjpYA93C0v"
        "kcGtye4ZIW3710V9xLBZrjdq2mtwo7fTyVUxZVhxDGNLnYGOZwCpRb3HHUxFKk1GckmzS4TBwVITQcxkBVArGCsjGue5rWguc44A"
        "AySUGikLbulejLuPqmnjqWWZttpZBlslylEJI/A5vHtavU1HQ13BhiL2Vun53Afa46qUOP40QH51tU5PgdSWYYaD2XUXac9oXr9a"
        "7W6u28e0aislRSQvPCypGJIXHwEjSW59BOfQvILDTW87UJxqLag7roLByqBWMHC2vo/o67g60pY6yls3kVDKMsqLhIIQ4dxDT55H"
        "p4cKSb3BVrU6K2qkkl0mrVQK6An6HO4EMJeyssE7gPtcdVIHH8aMD861TrPbPVe30zWahs1RRseeFk/J8Lz4CRpLSfRnPoS4SW9H"
        "HSxtCs9mnNNnlUwUsqo43yyNjja573kNa1oyST2ABZO0MFNbe0x0YtxtS00dSbXDbIJBlpuU3VOI9LAC8e0BfereiBuDSQl8U9jq"
        "3Afa4Kp4cfx2NH51vk5cx1JZhhYy2XUV+s0Ghff1VonUGiK4UWoLTU2+d2eDrW+bIB2lrxlrh6iV8BYaO5CcZrai7opMFQDhUsmi"
        "soUpgpuNxhUpTBQI0BCEkikJApoEYKalUDlQghCECikKVShGCmpTBUQ0IQoTT4OUwVCpdw8oUkexGeSXcoriKxkq1jclGZGNy7B0"
        "H/JzPxVXfTKuPXFdg6D/AJOZ+Kq76ZV5ryn/AHNH+5HuZzYTfP8ACzkBp81vqCeVDT5o9QTyvdXPClZWxdktM2vV2vYbZeaUVVC6"
        "lnkMfG5vnNAwctIPetcZW2+jafso0/8AsNT+iF8zOak6eX15wdmouzW/cdzL4xniqcZK6bR0F+4Nt98Hm/Opv1lznvvpS0aN1lT2"
        "+yUYpKR9DHMYw9z8vLngnLiT2ALtNcidJ/8AjDpPi2L9OReA8kswxdfMVCtVlJbL0cm1w52epz3C0KWE2qcEndbkkaYyjKnKMgdv"
        "Yv1K54o9VoXQV43Bu/ufao2hsYDp6mXIigb4uPie4DmflK6b030cdH2eFhubKi81WPOfUPMcWfRGwjl6yV97ZTTEGmNurO1kbRVX"
        "CJtbUvxze+QZGfU3hAXsb7e6PTdnrrtcJDHRUURllcBk4HcB3knAA8SvynPPKTGYrFSw2Ek4xTstnfJ7t611e5I9xluUYejRVWuk"
        "5NX13I883afQzY+AaTtHD6YMn5e1ecv/AEetEXmFwpaGW1VBHmy0UpwD6WOy0/mXg6jpXxirIp9KudSA8jLWcMhHqDSAfaVurQuu"
        "bXuDYmXW2GRrQ8xTQSgB8MgAJaccjyIII5ELo4ijnmWRWIqynFc+1ft1fvOxSqZbjG6UFFvqt2aL3HHW4+2N323uEcVYW1NvqCfJ"
        "q2JpDJMdrSP5rh4e0ErxGV3zuNpeDWGirxa5WB0j4HSwOI5smYC5jh7Rj1ErgMHIB7MjOF+geTOdTzPDN1fpwdn033Pv7Dy2cZfH"
        "BVlsfRlu+BeUZU5RlekufIPV7an7IelfjKD9MLd/Sq/g2lvw6n6I1o7bQ/ZE0r8ZQfphbw6Vf8G0r/rKn6I143N/45hPwy7mepyX"
        "6nV614HOTCs7Cv52L+hnavuM78DO1ZGrE1ZAsnYiZAuqOhhtJb9X365atvVMyporI9kVJBI3LH1JHFxkd/AMEDxcD3LlZd89A+50"
        "8u3upba1zfK6e7eUPb3hkkMbWn5Yn/ItU1eR1MynKGHk4m4d398tM7M0NLJevKKmvreLyahpGgySAdriSQGtBIGT7AcFaVtvTy03"
        "NWNjuGk7pTUpODNDPHK4Dx4Tw/SjpibKan1zX2nVWm6OS5mhpDR1NFBzma0Pc9r2N/n+/IIHPkOR544buFtrbTVPpa+kqKSpZ76G"
        "ojMb2+tpGVuc5JnRwOBw1ainLWXHXcfrnS1OmN2NFMmjFNeNN3iA8nty17ewgg82uBHoLSO4hfnHqrTEOwu/1DBV+UVFpsl1pLlE"
        "5gBllpRI2UAZIBcAC3tALmnsC210YukRo/bDbyrsWp6ytZV+6Us8DIad0jRC6OPHMdnnB/Jay6UG5Ond0tf2+96aknkpIrZHSyum"
        "hMZMjZZXdh7fNe3mqbTinxNYLD1aFedJp7DudNfX0bd/0Nqr5rT/ALdbO2h3007vT7s+4FFdab3J6nrvdCKNnF1vHw8PA92ftbs5"
        "x2jtX5WrtDoCf5wv93/9SqFRt2YY7LqFGhKpC91bvR0Ju7vlp7Zdtndf6O6VIuplEPufFG/h6vg4uLje3H2wYxnvWsPr59u/6G1T"
        "81p/268d0+ftOgPwq/6KdcWqnUkpWQ4DLaFahGpO93fj0m/a6ip+k90jaqWxsrKO0XUwyzPqWNEsEEMEbJHENc4ZJZhvM83Nz3rv"
        "u12rTO1mkPJ6WOls+n7XEXve4hrWgDm97jzc495PMlcj9Au2RTXvW1zLR11NTU1O13eGyOkcR8sTfkXr+nTqSqoNI6ZsUMjmU91q"
        "pZpw044xCGYafEZkB9bQmDtFzOLFxdbEwwcXaMbL3X7j+i/9OXSdBXPgs9gudzp2HHlMj207X+loOXY9YB9C91tZ0odG7n3OKzsb"
        "U2i9S/aqat4eGc+DHg4J9BwT3Ar80lno6uehqoKqmlfDUwPbJFIw4cxzTkEHuIIXGqsrn0J5Nh3C0bp89z9GuktsdQbj6WrL3bqR"
        "kerLZCZYZY24dVsaMmF33RwDwnuOB2Er85F+vOjby/UekNP3iUASXK309W4DsBkja4/Svyp3AtkVk17qq2QNDYaG6VVOxo7A1krm"
        "gfIE1orRo4clrTalRl/LuP1xXNTum9t81xabPqjIOP4NT/t10qvxwl+2yfhH6VurNxtY6GVYOlitvlOFvE/RrSHS2261ddoLZ1ty"
        "tM9Q4Mifc4GMjc49g42PcG+t2B6V63ebaO1bs6UqaGogiZeYI3Pt9bjD4ZMZDSfuHHkR7e0Ar8twv1w0I2tZojTTbnx+6LbbTCp6"
        "z33W9U3jz6eLKqc9tNSOTMMJHAyhVoNpn5MzwS0s8tPOx0c0Lix7HdrXA4IPtUBeo3PdE7cvWZp8dQbzWdXjs4evfj8y8suq1Z2P"
        "UwltRT5z2e0h+yrob48of+IYv0q3U/iw1t8S1v8AYPX5q7Sfxq6F+PKH/iGL9Kd1f4r9bfEtb/YPXYo/RZ57OfrFL54n5Vg5VBYw"
        "VQK6x6YoLt/opbK0NrsFJrm9UrJ7vXjrKBkrcilh7BIAf57u0HubjHaVxAv1ysltis1mt1thaGw0VPHTsaOwNY0NA+QLnoRTd2fD"
        "z3ESp0o04u213L/Jr7dHfnSm1L2UlzknrLtI3jbQUYDpGtPY55JAaD6Tk9wK1Xb+m1p6arayu0zc6amJwZYpmSuA8eE8P0rkHWOo"
        "qrVmq7ze6yRz6ivqpJiSc4BPmtHoAwB6AF8ZEq8r6G6GR4dU0ql3LrP1XtF403ubpUVVG+mu1iuDCx7Hs4muHex7T2EeB5hcBb/b"
        "Ut2q1qaWj43WS4sNRQuecljc4dGT3lpx7C3vW0OhNqGpZqLUmnzI40c1I2uDCeTXse1hI9YkGfwR4L2vTXtscuhtO3ItHXU9z8na"
        "7vDZInuI+WJvyLcrTp7XE6WEUsDj/N07xl8NPaa56I+11Dqq9XDVF3p2VFJZ3sjpYZBljqgjPER38AwQPFwPcunt1N5dO7SUdNJd"
        "+vqK2rz5PR0wBkeB2uJJAa0EjmfYDgrVHQpuMEuhNQ29rh5VBc+ve3vDHxMa0/LG5fz9K/aDUWs6216l0/SSXE0dKaWoo4ecoaHu"
        "c17G/wA73xBA58hyPPDG8ad4nHidjEZk6eJlaK093iVb+mtp+arayu0zcqemJwZYpmSuA8eE8P0rftNUad3O0g2Vgp7rp+7Qnk5u"
        "Wvb2EEHm1wI9BBHcQvy2raCstlS6mrqWelqGe+injLHj1g810/0dN+dK7daEqbNqKrq2VXuhJNC2KB0jRE5kfePvg/ksU6zbtM7O"
        "YZRCFNVMKndPhqaS3a0G7bbXt1sAe6SlhcJaWR3a+F44m59Izwn0tK6L6IW2FC+2T65uNOyasdM6nt4eMiJreT5B98SS0HuDT4rT"
        "vSN3AsO5Ot6G76ekmkpY7dHTyOliMZ6xskh7D6HN5rqjoqXCCt2XtEELgZKKepgmA7nGV0gz/VkainGPKOxzZlXrLL4uWknZP56T"
        "6W62/wBpvamqit9XFU3C7yxiUUlLgdW09he4nDc4OAMn0YXgLH0zdM1tbHDdbFcbdA848oY9s7WelwABx6gT6F43pQbNaouOsqnV"
        "1mt890t9ZDGJo6VpfLTvYwM94OZaQ0HIzg5zjlnl2eCWlmfDPE+KVhw5kjS1zT6QU1Ks4yM4DK8FiMPGW+TWuu59R+oeptNWDc7S"
        "b6GubFW2q4RCWCeMgluRlksbu4jOQfpBIX5qas05U6R1NdbFWEOqLdUPgc4DAfg8nD0EYI9a6n2a6RujNH7aWGx3ysrhc6JkrJAy"
        "mc9oBleWAHv8wtXPm9WqrVrXcy+X6yukdbq3qTGZGcDiWwsa7l+E0orSjKKa3m8no18NWqUZp7Gtnw0fijwaYKnKMrrM9GWhIFNB"
        "DBTUpgqFDVKUAqIpCEKEYKalMFQoaEIUIKlKFCilSlAKhKQhCBuafQChC7h5MpCnKYKiJPYsblkKxuSYkYnLsLQf8nI/FVd9Mq48"
        "cuwtB/ycXfFVd9Mq835T/uaP9yPcznwm+f4WcetPmj1BGVDT5rfUE8r3B4crK270bD9lKn/2Gp/RC1Blbd6NZ+ylT/7DU/ohfKz3"
        "+G1/wy7ju5b9bpfiXedmLkPpQ/xiUfxZF+nIuvFyD0oj9kWk+LIv05F+b+Rn8TX4X4HrvKH6m+tGlsoznl4qcoyv108Id47Qahg1"
        "JtzYKiF7TJT07aSdoPNkkYDSD7AD6iF6q82ei1Baqy13GETUNZGYpYySOJp9I7D359C4W293LvW3FyfU21zJqSfHlNFNnq5gOw8u"
        "bXDucPzhdM6b6R+i7zEwXCeezVRHnMqoy6PPokYCMesBfk2deTeNwuJlXwsXKDd0471x3LXTnR7nLs3w9aiqVZpSSs77n4a8x42+"
        "9FRjpHvseoyxhPmw18HFj0cbO38VeXdtFuxoOCp9wauV9PIQ+QWit4XPIGASw8JJx4ZXT9o1bYL/AI9yr3bq0nsbBUsc78XOfzL7"
        "JHcR8q4Y+VGZ0f8ASxKU1zTj/j3nI8lwdT16N4vni/8AJwXW7h6+t9TLS1mpL/T1EZ4XwzzvY9vraea8bld4blba2zcayy09RFGy"
        "6xsPkdbjz4n9wJ72E8iD45HNcITwyUs8sEzCyaJ7o3tP81wOCPlC975PZrhswpSlSpqElbaSt7Hwut/UeYzbA1sLNKpNyi9zfvJy"
        "nlRlGV6I+Ses2zP2RNKfGUH6YW8ulZ/BtK/6yp+iNaL2zP2RdKfGcH6YW9Olb/BtK/6yp+iNeOzf+OYT8Mu5nqMl+p1eteBzgxf0"
        "MX8zF/Qwr7jO9A/ob2LIFiasoWWdiLKC9/tFuzetntVMvdpDZ4ZG9VV0UhIZUxZzwk9xHaHdx8QSDr8HC7T2D6MWgdydqrHqS7uu"
        "hudW6ds/k9UGMBZO9jcDhOPNa1MU29DixdalSp3qq6ehu7QHSj2515BCx15jstycBxUd1cIcHwbIfMdz7MHPoC2lcLRZNV0DY7hQ"
        "2+7UEgy1tREyeNwPhkEFfl5v/oC37ZbpXbTtpbUC1wxwSU5qH8b3B8TS45wM+fxD2Lx2ndY6h0jUiosN7uFsmzkmkqHRh3rAOD6i"
        "uTlWtGj5byqFSKqUJWvrqd87ldDbROq6aep0y12nLuQXMEJL6V7vB0ZPmj8AjHgVwTrHSF30FqOu0/faU01xon8L25y1wPMOae9p"
        "GCD6V+gXRQ3nve7OnLzTai4JrpZJIWmtYwM8oZIH8PE0cuIGN2SMAgjl251F097PTQXrRN2Yxoq6unqqaVw7XMidG5vyGV/yqnFO"
        "O0jWBxFaliPNazv/AIv3HHwOF2l0BP8AOF/u/wD6lcWArtLoB/5wv93/APUrFP6SO9mn1Wfs70ZOn19p0B+FX/RTri0FdpdPr7Tt"
        "/wDhV/0U64sRV+kxyr6rD297O0egL/nC/wB3/wDUrL09/tWgPwq//p1/B0CK6Nlw11RFw66aKjmaPEMMwP8AaBfe6eNoqJ9P6Nuz"
        "GE0tHVVFPI4Dk10rWFuf/CcuT/iPnvTNbv59U4gQkCqa1z3BrQXOccAAZJK4D0R+tO038Veh/iSh/sGL8y93T9lnXnx7X/8AEPX6"
        "h6CtU9i0Lpi11LS2ooLZTU0jT3OZE1pHyhfljuZWx3PcjWNbC4OiqbxWTMI7w6Z5H0rnq7keeyfWvUa+dT9b1zs7oW7bucXGe/ZJ"
        "z/C2fs10SvzSk6Vm7rZHgat5Akf/AG6k/ZLdRxX0kdHLqOIq7Xm89m1r+/oOxNIdFfbjR12gukNvqrhV07g+E3GfrGRuHY7gADSR"
        "6QV9PfLem1bS6ZqHeURS6kqoy2gogQXcR5CR47mN7efbjA9HDlf0m917nA6GbWFSxjhgmnpoIHexzGAj5VrCuuFXdauWsrqqeqq5"
        "jxSTzyF73nxLjzJXE6qStFH1KeU1alRTxU9q3WRLNJPK+WV7nyyOLnOcclxPMkpAqAVQK4D757TaP+NbQvx5Q/8AEMX6V7q/xX62"
        "+Ja3+wevzT2jP2VtC/HlD/xDF+lm6v8AFfrb4lrf7B67FH6LPO5z9YpfPE/KcFUCsYVgrrHpTICv2BX4+Ar9erdWR3G30lZEQ6Kp"
        "iZKwjvDgCPpXYw/E835Q/wDH7fA/IyU/vsn4RQCv7tQ2mosN/ulrqmFlTQ1MkEjSOYc1xB+hfPBXXaPSxaaTR0r0K/4zbz8TSf28"
        "K2500v4rbR8dw/2E61h0JbVUS6z1HdQw+S09uFM5+OXHJK1wHyROWxemtWxx7eWGjJHWzXZsrR4hkMoP6YXYj+6Z5vEO+bRt0dxy"
        "rtbufd9qdSsvFsDZopG9VVUkhwyojznBPcR2h3cfEEg9y6G6SOgdawxNN2jtFwcBxUlzIiIPgHnzHejBz6AtO7IdHPRG4O2dm1Bd"
        "TcjcaoztmEFSGsBZM9owOE480NWit8tDUO3W5N0sNrbOLbDHDJAZ38TyHRNLjnAz53EPYsxc6cb8Ds16eEzGvKlqpxvr1ae0/SCu"
        "tdn1NQtZXUdDc6KQZDZ4mTRuHoyCFpLcHom6Q1LTzVGnmusF1wS3qiX0z3eDoz70fgkY8CuILBqy+6WqBPZbxXW6XOSaWd0Yd6wD"
        "g+orurox7uXjc+wXanv3BLcrO+Jpq2MDOvZIHcPEBy4gWHOMDBHLx3GcamjR0a+BxOXR5ajU0Xs925nDeq9LXTROoK2x3mmNPX0j"
        "uF7c5a4doc097SMEFe42Y3oue0d3mfHD5bZa0jyuiLuEkjsew9zh8hHI9xG2em3aqeG76PujGtFVVQVNPI7vLY3Rub+eVy9ZoHov"
        "aB1LofTd5qXXU1Vwt9PUTdXVAN6x0bS7A4eQ4ieS4lTkptR4H1J5hQng4zxK0np7UbU0bvxoLW0UfkV+p6WreOdHcHCCUHwHEcOP"
        "4JK9jedM2LVNMI7vaqC5QOHLymBkox6CQcesL8y9wtPw6U11qOyU7ZG01BXTQQiU5d1YeeAk9/m4OVGmde6n0dM2WxX2voOE56uK"
        "Y9W78Jh813tBW1X4SR1JZCpJVMPUtfVX+KOudyeiNYbtSz1ujZHWq5NBc2jlkL6aU+AJy5hPjkj0BcY3O21dluNVb6+nfT1tLI6K"
        "aGQYcxwOCCv0T2C3Irt0NAMu1zhjZcaWpfRzvjHC2VzWtdxgd2Q8ZHZkHGOxcu9L6109v3Yjnga1slwtsNRNjveHSR5/FjairCOz"
        "txOTKsZXVeWExDvbwNCoSBTXXPRgqBUoUaLympTBQRWU1KFWEsFNY1SBKQpQoSwU1KYKhGhCFEMFNSmCo0UChJCiNQoSBTXcPJgh"
        "CECIrG7tVEqCkwzE7sXYWg/5OLviqu+mVceOXYehP5ODviqu+mVeb8p/3NH+5HuZz4PfP8LOOGnzR6gnlY2nzR6gnle3PDl5W3uj"
        "Uc7p0/8AsNT+i1aeytv9Gk53Up/9hqf0QvlZ5/Dq/wCF9x3st+t0utd52euYOkPobU2pddUtZZ7FX19K23xRmWni4mhwe8kZ8eY+"
        "VdPpcl+P5VmVTLcR5xTim7Na9J77HYOOMpclN2W/Q4H/AHJdd/BK7/8Agf8Aypk2r1vTxvmm0ndmwxAveTByDRzPf4Bd9cvQv4b3"
        "j3FufZ/BZv7Ny9RDy4xUpJOlH3/E+LLyboJN7b93wNd0WxG3FdR01VFYy6KoiZKxwrJsEOaCD770rxe7GwNrptL+WaLs8jbnSyiS"
        "WFkz5HzQ4IIaHE5IODgczgrP0e93qG42Og0neallPc6OMRUckrsNqYh71mT/AD29mO8YxzyugDyODyK+ZisdmmU47Zq1JPZeibbU"
        "l27n7utHco4bBY7DbUIJXXBK6Z+bD4ZoKjq3xSR1DDjhcwte0+rtBXZHR3dqp+j6k6jNWabrm+55rc9b1fD53vvO4M4xn045Lbhi"
        "jdJ1jo2GT7stBd8varJyeZySuXOvKj0nh+Q5FR3a3u/ZorfAxl2S+Z1eV5S/Ra3bqxt9831hfnhraeKo1nqKaAgwyXGocwjsx1jl"
        "15vHu3QaBs1TQ0lRHLqWpjLIKdpyafIx1r/DHaAeZOO7K44smnLxqepfBabdU10zBl/VNzw573OPIe0r7nkTgalKFTF1FaMrJX42"
        "3vq5vafK8p8bSWzTcl6t23wR83KMr6V903eNM1Dae8W2popXjLBMzAePQew+wr5WV75NPVHl4TjUipQd0+KPW7ZH7IulPjOD9MLe"
        "vSt/g2lfw6n/ANtaI2yP2RdJ/GdP+mFvfpW/wbSv4dT/AO2vH5t/HMJ+GXcz1WTfU6vWvA5vYv6GL+di/oYvus7sD+hhWRqwtWZi"
        "ydiJS7R6Ee7dDRwVu311qGQzzTmrtj5DgSFwAkhB8fNDgO/LvQuLlUUr4ZGSxPcyRhDmvacFpHYQe4pjLZdzGIoRxFN05H6f76dH"
        "Wyb1Mpqx9Y+16gpI+qiro4xI18eSQyRmRkAkkEEEZPb2LneHoGamNUGzastDKXP2xkMrn4/BOB/5l5LQnTN1/pOkiorq2k1DSxAN"
        "a+tDm1AA7utafO9bg4+lbDk6ftSYcR6BibNj3zrqS3Pq6kfSuVuEtWfKhRzCguTp6r2eJ0ts/tDZdmtMOtFrlkqZ539dWVswAfO/"
        "GOwe9aB2N5458ySSeHelvulRbi7iRUdonbUWewROpY52HLJpi7Mr2nvbya0Hv4MjkQvmbldKfXu5NFNbX1MFns8wLZKW2hzDK3wf"
        "ISXEeIBAPeFpNZnNNWR2cFgZwqOvXd5MF2n0Ajn90P8A3f8A9SuLFsLbDejVO0Pur9TUtJH7qdV5R5RAJM9Xx8OM9n2xyxB2d2dz"
        "G0ZVqEqcN7t3nSvT6+07f/hV/wBFOuLFsDc7enVW7rbWNSzUkgthlMHk8Ajx1nDxZx2+8atfAom7yuhwNGVChGnPer95tDYHc9u0"
        "+5FBeqnjNqna6jr2sGT1LyMuA7y1zWux38OO9fpZfbHp3dDR8tBWtgudgu0Ic2SJ+WuaebXscOwg4II8F+Qi2Xtlvzrbaj94sdyb"
        "LbC7idbq1vW05PeQMgtJ7+EjPflahPZ0e462PwDrtVaTtJG+dQdBC5NrpDYNWUklC45Y24QOZIweBLMhx9OG+pe/2i6Hlq0NeqW+"
        "6kujb1cKRwkp6aOHgp4pBzDjkkvIPMdgz3FeCoOntXxwgV+hqaebHN8FxdE0n1GN30r42pOnPqu4074rFp+2WlzxjrppHVT2elvJ"
        "rc+sEehbvTWp1ZU8zqLk5bufTw1OnN/t3qHafRFXO2oZ9UFfG6G204PnmQjHWEfcszknxwO9fl9xFxJJJJ55K+pqTVN51jd5rtfr"
        "jUXC4ze+mndk47gB2NA7gMAL5K45z2mfTwGDWFha9295+zS/G2U/vsn4RW+fryd0P/5dr+ZN/vWgi4ucSe0nKak1K1jgyvBVMLt8"
        "pbW3iWCqBWMFUCuE+sWqByoBTUaPa7RH7K2hfjyh/wCIYv1F1RZG6m0zebI+YwNudHNRmUN4jGJGFnFjvxxZwvyZ05fKjTOoLTe6"
        "RkT6u11cVZEyYEsc+N4e0OAIJGWjOCPWuhB03dwf6H0v82qP265qc1FNM+NmmCrYipGdLgbA+sXt/wANar8nt/aJjoMW/wCGtV+T"
        "2/tF4D69zcD+h9MfNqj9un9e3uB/Q+mPm1R+3TelzHFyWa/bXu+B5ffzYyn2W+p7qL1Lc/dbyjPWU4i6vqur8HHOes/MunOituzR"
        "6x0TSaZrKhrdQWOIQCJ5wZ6dvJj2+PCMNPhgHvXIW7G92oN4/cj3do7XTe5XXdT5BFIzi6zg4uLje7P2sYxjtK8Ha7pW2avp6+3V"
        "c1JXU7uOKeB5Y9h8QRzCwpqMrx3HcqYKpisKqeIfrrj89B+gm8vRls26Fxde6CtNnvz2gTSiLrIqnAwC9uQQ7AA4geztBWoLd0IL"
        "4+raLhqq3RUmebqeB8jyPU7hH518PSnTO1lZ6eOnvdut96awY645p5nesty0/iheqqOnNUvhIp9Dwxy45OkuZe35BEPpW3Kk9WdG"
        "FLNaEeShql1eOp0xt7t7YtrNMss9njLKdhMs9TM4dZM/HN7zyHYPQAAuIuk7utS7j61hpLTMJrHZGOgglactnlcR1kg+981rR4hu"
        "e9fE3G6ReuNyKaWgrKyK32mTk+it7TGyQeD3Elzh6CcehaoBWalRNbMdx28uy2dKo8RiHeTOvuh3ujR0kNXoW5zthmmmNVbnPOBI"
        "SAHxD08g4Dvy70Lcm8+wln3eZT1b6p9tvlKzqoqxjONr2ZJDHtyMgEkgggjJ7exfnFFK+GRkkb3MkYQ5rmnBBHYQVvvRXS31xpil"
        "io7m2lv1NGMB9YC2cDw6xvb63An0qhUWzszMYzLayr+c4R2lzfPieoi6EuojUhsup7Uymz9sZFI5+PweQ/Oumtqdq7RtJpx1rt0k"
        "lRNM/rqqsmADpn4x2D3rQOwd3PmSSVzy/pw1BixHoiJsuPfOuZLfk6ofStV7h9JXW+4NJNb31ENqtUoLZKa3gtMrfB7yS4jxAIB7"
        "wtKVOGsTgqYXMsXanXaUfZ4H0elFuTR6+17FS2qds9qskRpmTMOWyyk5kc0945Nbnv4cjkQt79EzdCjv2kItH1k7WXm0cXUMeec9"
        "OSXAt8S0ktI8OE+OOFV/XbrjV2qtgraGpmpayBwfFPC8sexw7CCOYK4o1WpbR9WvltOphVhk7W3Pp/U753k6Ndr3Pubr5QXA2m+v"
        "aGzPMfWRVGBgFwyCHAADI7gOS1Lb+hTfX1TRX6otsVLnznU8L5H49R4R+dfD0p0xNY2amjp7zQUF6YwY65+YJnetzctP4uV6mp6b"
        "tU+Eim0VDHNjk6W4l7fkEY+lcjdKWrPlwo5tQjyVOzS3bvHU6X0bpGybXaQhtNC8QW2hY6WapqHgFx7XyPdyH/IAY7Avz/3y1/Fu"
        "PuPc7vSEm2xhtLRlwwXRM/nf1nFzvRxLJuNvxrLcyJ1Jc62OltROfIKFpjidjs4skuf7SRnsAWs8rFSopLZjuO/lmWzw83Xru82Z"
        "EwVAcqXCfZKQllGVGkxhUpTBQJQKMpIUiuUmCpBTUNykJApoG4wU1KFCWCmsYKpQlIQhRDBQkhFxuahTBUA4VLunkykJdyM8lESV"
        "jcVZWNyTLMbl2HoT+Tg74qrvplXHjl2FoX+Te/4prvplXmvKf9zR/uR7mc+D3z/CzjRp80eoJ5UNPmj1BPK9tc8SVlfY0zqm66Pu"
        "rbpZqryaubG6ISdW1/mu7RhwI7l8XKMrFSEakXCaunvTNRlKDUouzRs/64PcX4Qf+kh/VR9cHuL8IP8A0kP6q1hlLIAznkuj6IwH"
        "3EPyr4HZ8/xX3su1m0Prg9xfhB/6SH9VY59/NwamCWGW/wDFHKxzHDyWHmCMEe98CtZhwPYQfUnlSynALdQh+VfAnj8Vxqy7WMYA"
        "A7gve6f3o1zpmFlPRX+eSmYMNhrGtqGtHgOMEj2FeByjK7VfDUcRHZrwUl0pPvOClWqUntU5NPodjdDOk/rprA1ws7j90aM5/M5f"
        "Bve/Wvr3E+KS+uo4XDm2hibBy/CHnfnWDSGzGqNWdXOab3Nt7+flNaC0uHi1nvnfmHpW+9IbJ6Y0sY55oDdLg3n19Y0FrT97H70e"
        "3J9K+U8vyyhLajRjfqR8rMvLKOFThKs5y5k+97vHoOeNLbZ6p1zL5TTUkjKaV3E+vrXFrHHvOT5zz6gV1XoXSNPonTVJaIXMkkZl"
        "887WcPXSHtdj5APQFg1ZuPpvRTC253BnlQHm0cH75MfRwj3o9eAtN1vSZrzc+KisVKLaAR1dRK7rXekubyHqwfWuxJ1cQrJWR4vE"
        "1M1z6PqU9mmtVwv7Xv8AZobV3it1HX7c3x1Y1n+Sw+UQvPayVpHCR6849OVxqTzXv9f7v3nXtMyhlihobY1weaeAl3WOHYXuPbju"
        "HILX2V28NTlThaR6fyey6vgMM6dd6t3tzbj1u2J+yNpP4zp/0wt89K3+DaV/1lT9Ea0Jtifsj6T+M6f9MLffSt/g2lf9ZU/RGvMZ"
        "t/HML+GXcz9Fyb6lV614HN7OxZ2L+dnYv6GL7rO5Azt7lkYsbe5ZGoOzEyISBTWTYJgpIUKKVKUBQlIQhQgDhUpTBUJaEgmg0MFM"
        "HClMFQlqlAKoFRFApqUwVGi1QKgFNAmQKljBVA4QSKBwqClMFRpFgqgVjBVAqEyJgqQU1CZAVQKxAqwUWEyAoUpgqEtp7lSxqg5Q"
        "oyB3iqWNUCgSkIyhQ3GCqBUJgoEyg5QsYOFeVCNMFTlNQlZVKAU1CXlPKjKahRWUZUpgoYlp5UIyorl5TDlIQoS8oykEKG4wU8qV"
        "QQJQKMqVShDKEIURqFMFJC7p5RFISzyQCghHvWNyyFY3JMMxOXYehP5Nz/imv+mVceOXYm0TDfNgzQx85TTV1Jj74l5H6QXmfKnT"
        "D0pPcpx7mdnBayml9lnFzT5o9QTyobkNaDyOBkJ5XtrniCsptBc5rWglzjhoAySfABbR2x2YqteUQu1XXChtPWOjbwM4pZi333Dn"
        "k0A8snPqXRmlduNNaLYH2y3RipaPOq5/3yY+njPvfZgLrVcVCDstWedzLylwuCk6UfXmuC3Lrfwuc3aS2N1TqXq56mBtpoXc+trA"
        "Q9w+9jHnH24W9dJbJaW0uY5pKY3SvbzE9aA4A/ex+9HtyfSlq7e7SuljJDHVG6V7eRgoiHAH76T3o9mT6FojVu+mqdTdZDTTi00L"
        "uXVUZIe4ffSHzj7MLr/69boR8X/rWcf9qm/Z/wDT7jpvUG3+mdTMxdLLSSvxgTMZ1cg9T24K1PqLo00svHLYLxJA7tFPXN42+oPb"
        "gj2grSNh13qTTMnHa7zWQNJyYzJxxu9bHZBW19O9Jivg4I7/AGiGqZ2Geid1T/WWHLT7CE8jWpfQdzXojOcu1wdXbjzfpLTsdz5d"
        "l6Oepqy4PiulRR0FHGcGdknXOkH3jRj/AM2FvDSG02mNHGOWkofKrg3/AL5V4kkz96OxvsHtXlrl0jtK09uE9DBX1lY4cqZ0XVcJ"
        "++ecjHqytKaw3l1Rq/rIXVfufb38vJaIlgI8HP8AfO+UD0I2a9bSWiMvD53m3qVnycOPD3b37dDpDWG72l9HmSKet8tuDf8AulGR"
        "I8H753vW+059C0Fq/fjU2pOsgoXiz0DuXBSuJlcPvpO38XC1ZnwRldinhqcNd7Pu5f5NYPB2lJbcud+C3d76S3PL3Oe5xc5xy5xO"
        "ST4k96WVOUZXYuffsVlGVOUZVcT122B+yPpL4zp/0wt+9K7+DaV/1lT/AO2tGbN0T7junpOFgJLa5krvQ1gLyfkat09K2qBqNLUo"
        "PnNjqJnD0FzAP0SvIZo757hUuEZd0j0+Tq2CqvpXgc7sPYv6WL+Zncv6GL77O3Azt7FkCxNWULJ2IlBfY03pq6aruTLdaaV1RUuH"
        "EQCA1je9zieQC+OFt/Yq8UFK/UloqK9lvr7tTNipKt54eB4DxyPjl7SB38PqWJtxTaOxRipzUWfy1ewGraamklifbauWMZdT09Qe"
        "sHo85oGfatYzwSU00kM0bo5o3Fj2PGHNcORBHcVtig241zt7qSjvcdvlroKWYPlfb5Q8zR589vD77mM9y87dGjc/cqbyGFts90pW"
        "8TalwHVFrAHk9mSS0nHaScLEZPi7o5alNWVk0+Y8KFS3PFtztxPdRp+LVte6+l/UBwiHUmXs4R5uO3lji9GVq3U+n6nSl/rrPVlr"
        "p6R/CXN7HAgFrh6wQfatRmnoYnSlBXZ9HW2iLhoK5wW+5TUss00Ina6mc5zQ0uc3nxNHPLSvNrcnSMifPri1RRtL5H0DGtaBzJMs"
        "mApqdsdH6Po6WPWepKmC71DBJ5NQsDurB8fNcSPTyzg4WY1PVTfE5J0XtyUdyPBUOiLhcNG3HVUU1KLfQTCCSNzndaXeZzA4cY/f"
        "B2kdhXml0JV6eo9PbGamZbbpHc7bV1TKmnqGAtJYXwtw4dzgWEH/AJdg1ht9t7LrWWsqJ6xlvs1vbx1VXIM8PInA9OAST2AewGjO"
        "6bYzotOMVvaPFgqgVt6i280BqiZ1t03qyrN4wTE2sixHKQM4HmN+knvwVqy62yqslzqrdWx9XV0shjkbnOCPA94WlJS0MSpuKuz+"
        "VC93tPou3671FVW64zVMUEVI6oDqZzWu4g9jcec0jGHHuXoI9C7e2yq9yr3q6oF4a7glNKz/ACeJ/wByXFhzjsJyPThZc0nY1GlJ"
        "ra4Gpgcpgr1Ov9DVWg7y2jlmbUUs7Otp6howJGekdxH93itj6o2s0Jo2uiN41BcYKWeIdVA0NfO54J4nZEeA3HDjl255qc1p0mlS"
        "k79BpEFNe20Tt+NY11ynFcKKwW4l01bMOYZzIGOQzgZJ7B8gXp6Pb/QWp5nW7Tuqqs3fBMTauLEcpA7B5jfpJ78FTmkUaUmrmpF9"
        "O82C56dqWU10o5aSd7OsayQcy3JGflB+RehsNh01b7ld7frasuFBVUcjY4m0YDuI+dx58x3L3uOztW3d26HQ9VqCkfqe53OlrhSt"
        "EbKRoLTHxvwT5jueeLvQ52aRuNK8W7nOIKoFe20boOlvFpqb/frmLXYKd/VdaG8Ukz/Bo9vgfV24+9+51pfU9HVnRd+qKu5UsZld"
        "R1jOF0rR9yeFv/PmRnGUuaQKlJq6NWgpr0uhNFVWt7yaGGQU8ELesqJ3DIjZnHZ3k+H9y9RcNG6HqnPt1g1RNNeweGJlS3EE7/uG"
        "v4QAT2A5IQ5JOxRg2rmu6CjmuNbTUcADp6mRsUYJwC5xAHP1lfW1ZpO4aMuot1xMLpnRtla6Fxc0tJI7wD2g93cvu7naNodDaioa"
        "G2z1T45ads5fO9peHF7hyLWj7kL6G5WipKLXNus9BWV9xqq+njcJK+YSSFxe9uOLA80Bo9XNG1exvYaTT3o1wCvR1Wjq+j0jQ6nf"
        "LTGgrJjCyNrndaHAvHMYxjzD3+C9rcdA6E0y9tuvuqKtt34QZBTxZjiJHeA0n84PfgL62vrO2wbO2Ogjq4qyKOu4o6iL3sjH9c9p"
        "HscEOd7WNKk0nfgaUVA5XttF6Aivlsqr5ebiLbYaV3C6bGXSO5ZDflA78k4AK+7Dt3pbVMFQzSGoJ57lAwv8mrWcPWAeB4W49fPu"
        "zhLmkCpyaNXNKpTJG+GR8cjS2RhLXNPaCO0IBWjBYKalChMgKYKxgq0GjIE8rGCqyoi8oUoyoUZMpgrHlUDlQloSyjKBHlUHKUKE"
        "vKalMFQl5QoymoUZELGDhVlBFKljTBUJaMqcpgqErKalChuUmDhSCmgSsoSBQoTUiEgU13TyYIQhRCJUOVFQ7tUZZjcumOinqhnU"
        "XrTcrwJWvFfTtJ98OTZB7MMPtK5nK+xo/VNZovUtvvdEczUknEWE4EjDycw+ggke1fOzbA+fYSdBb3u61u+A4etyNVT4H094dHP0"
        "Rr+7UAjLaKeQ1dI7HIxSEkAfgnLf6q8Jldtbg6PtW/OgqG62SeMXCNhloJ3nGCffwSeHMYPgQD2dvFt0tlbZLhU2+400tLXUzyyW"
        "CVuHMd6f7+w9ycgzRY3DqnU0qw0knv00v7ePSfFzXAvDVnKP0Jap+HzwNh7f71XbQVnltUdDTV1JxukhEz3MMTndvMdrSeePzr4m"
        "rd0NT6zL2XG4vZRuPKjpv3uEesDm7+sSvGZRlfbVOCltW1PPRy3CRrPEKmtt8fnd7Cs49SeVGfSjK2d0vKMqMoyoi8oyoyjKiLyj"
        "KjKM+lRF5RlRlGVEXlGVGV6rQGgLvuLfo7Xao8MGHVNU8fvdNH904+Pg3tJ9pXHWrU6MHVqu0VvZunTlUkoQV2zcXRT0dJV3u5ap"
        "njPk9DGaSmJHvpX44yPwWcv668zv3qdmpNx68QPD6W2tbQxuB5EsyXn8cu+Rb51vqC1bGbcUtmspDK90ToKFhILy8+/qH+oknPe4"
        "gdgXHHG6R7nuJc5xySTkk+K8dlTlmONqZpNWj9GHUuPzxbPX8ksJh44Vb976zMzuWdqwMWdq9MygZ2LI3sWJvJZW81k50UCto6B0"
        "Pa9a6J1Cymi6zVlI8SUzTMW8Ufm8g3ODzDxk9hcPQtXL+u23Sts9ZHV0FVNS1UfvZYXlrh7QsyTa0OenJRd5K6Nh6Mp9yrPeqSjt"
        "lNeoA2VrXQzxyCnAzz4g4cIGO/5FsW8aX07qzfWSjqGxvihoBPUwsdgTVAOOE4+9c0n8H1rU0+8Ot6mmNO/UE4jIxmOONj/xmtDv"
        "zryVJdK2guDLhTVc0Vcx5kE7HkP4j2nPp/OuLYk3fcdhVoRSirtX4nRdgubptV01DFtTRW6CCpaDXz07WGABww8PMYHF2EYPM4we"
        "9a133o6iHca5VEkErIKhsXVSOYQ2ThiYDwnsODyOF8G8bm6sv1PDBX3ueSKJ7ZGtY1sfnNOWk8IGSCAefeF/FqXW191g2kbeq81Y"
        "ow4Q5iYwt4scXvQM54R257FRg1K41K0ZQcdfcbb3rrYbbuvpWtqP4PTRU80n4Lah5P5gvl73aPvddrB95oaGpr7bXQxGKWlYZQ3D"
        "QMHhzjOMjuOVrLUuq7vq+tirLzV+VVMUYia/q2Mw0EnGGgDtJX1LJuZqzT1C2it16nipWjDY3NZIGDwbxA4HqUoNJW4DKtCbknez"
        "1NqR6cuWmuj7fYLpC+CoqJ2VDYZOTo2mSIAEdx80nHpXy9s4Haj2r1fpu3ub7sPlFQyPiwZGYZyHtjI/rDPatcVOvtSVlruFsqbr"
        "LPRXGUTVLJWtc6R44cHiI4h7xvIEDkvkWy6VtnrI6y31U1LVR+9licWuH/wrYdnfnuDrR2k0tLWPe7baC1JJri0ySWqtpIaGqZPP"
        "NPC6NrWsdkjJHMnGMDxXy92bnTXfcO+VVG9r4DIyMPachxYxrCR482lRct1dY3ajdR1V9qDTvHC5sbWRlw8CWgE/KvHLSi77TMyn"
        "HZ2IdZuHo4/9t6/4tk/tYl5O77capptQVFv9x66omdM4Mmjic6OQE8ncfZg9vM8u/C9X0cP+3Fw+LZP7WJeToN0dXWak8go73Oyk"
        "jy1jHMY8sHgC4EgeorGu27HL6vJR2uk9lvk9lDQ6MsUkrZbjbKHhqC055lsbR8pjcU+kaT9WNtHd7nt/tJFqOtram41UtVVzyT1M"
        "p4nyyuLnOPpJX0dR6qu+rayOsvNX5VUxRiJr+rYzDQScYaAO0lMYWt0BKqpKXTb3G0NtIHai2u1dpygc33XfIKhkfFgyMwzkPawj"
        "+sPFfB240JqOTW1pkktVbSQ0VSyaeWeF0bWtY7JGSOZOMYHivA2y6VlnrI6ygqpaaqj97LE4tcF6a47p6vu1G6kqr5UGneOFzY2s"
        "jLh4EtAJ+VTjLW3EVUg7bW9GbdW5U123AvdVSPa+AyNjD2nIcWMawke1pXuOkDba2r1Tb6ino6iaBtA0GSONzmgiR5PMDHYR8q0o"
        "CvZxbrawit3ueL091J1fVcL4Y3ktxjHEWk9npU4tWtwJVE9pS4m1NB3u4t2ijGnKKkuF1tlQ8T0k7C8ua57nZDQQScOGPHBHMqrF"
        "rHcO5Q11UzTllt0NHE6R81bTSwNdjtaCX9uMnwGOZC0TZb/c9O1flVrrZqSfGC6N2OIeBHYR6Cvr3zcTU+pKTyS5XeaamPbE1rY2"
        "u9YaBn2rLp6nIq+i36Hvtl6tt1k1lbOsjguF3pCYMcgDh4OPUZAfUF4y3bdaoqL5FbvcitgmEga6Z8REcYz77j7MDtyDz7l8XS9F"
        "cblf6CltM5guUkmIZA8s4XYJzxDs7Fum4aQ3Zu9C6grL5SupZBwPDZWsLm94JawEj2ql6r37yituK0enMfE6QB/+tLX/ALCz+1kX"
        "qdaXCnte+Glqmqc1kAo2sLncgC90zQT7XBeM39rYKjWlI2CZj309ExknCc8DuN5wfTgg+1eA1Dqe66qrY6y71XlNTHGImv6trMNB"
        "JAw0Adrj8qzGN4o1Oooyl1o9juNojUDNaXSWO2VlVDW1DpoZYInSNcHHIGQORGcYPgvV67s9XYNl9PW+uGKuGraXtznh4hK4N9gI"
        "HsWvKLc/V1BRNo4L3UCna3haHta9wHgHOBI+VfOrtX3q6WaK0Vle+egimM7WPa0u6wlxLi/HETl7u0961sydr8DO3BXtfU2XbqKf"
        "VmykVutLTNX2yrMk9Oz37xxPIwO/k8EePCcc1/Js/pS8UerIrtWUdRQ2+hjkdLLUsMTTlhbjzsZxnJ8MLW1mvtysFV5VbK2alnxg"
        "ujdjiHgR2Eegr6953C1LqClNLcLvNLTu5OjaGxtd6w0DPtU4vVLiKnHRvej+DUldDcdRXesp/tFTVyyx/gueSPzFfNBWNMFbRx3v"
        "qZQUwVjBVgqIpMHCWUKG5YKoFYwU8oNGRPKkFNRFZTBUIyoTJlMHKgFPKhLQllAKLjcoEhVlQmCoSgcqgVCeVCVlMFQCmoS8hPKg"
        "FNAlgoypygFIlhyeVCYKCKymHKUKFF5QpBQgTUyoKAU13TyZSEIUJLlBVlSVGWYndqxu7VlIWNwSjikj3m1m7Fz2zubjG01VnqXA"
        "1VE52OLu42H+a8Dv7D2Hux0vc9P6B6QVkZWQzB1bCzDamAhlXS/eyNPa3PccjwK4ocF/TbbpXWasjrLdWT0lXH72aCQscPaF8TMM"
        "ljiKqxWHm6dVcVx6/nruc1LE7MHSqx2oPgza2qei/rKzSvfZzS3ukz5pheIpseljzjPqcV4OfabXdM8tk0hegR9zSucPlGVsTT/S"
        "c1lao2xXFlDdo2/z6iMskP8AWYRn2gr18PS380ddpIB3f1decfnYuvHGZ/Q9WVKFTpTt4ruOCWX5fUd4zlHo3+D7zQ/7l+tvgjfP"
        "mT/7kfuX62+CN8+ZP/uW/frt4fgnJ8//AMNH128PwTk+f/4a16Uzz+lX5l8TPovA/fPs/Q0F+5frf4I3z5k/+5H7l+t/gjfPmT/7"
        "lv367eH4JyfP/wDDR9dvD8E5Pn/+Gr0pnn9KvzL4l6KwP3z7P0NBfuX62+CN8+ZP/uR+5frf4I3z5k/+5b++u2hP/wCpyfP/APDR"
        "9drF8E5Pn/8Ahq9KZ5/Sr8y+JeisD98+z9DQP7l+tvgjfPmT/wC5H7l+tvgjfPmT/wC5b++u1i+Ccnz/APw0fXaxfBST5/8A4avS"
        "mef0q/MviXorA/fPs/Q0D+5frb4I3z5k/wDuX9tDs3r+4PDIdJXVuf500XVNHteQFvH67WL4JyfP/wDDX81X0s6hzCKTSsLX9zp6"
        "xzh8gaPpV6Tz16LCxX/kv/YVlWB41X2fofK0Z0UrrVyxT6ruMVDTciaSicJZnegv9632cS2rqLXGiti7D7i2elgdXsGWW6nfl5fj"
        "387+ZHt849wx2c/6n3+1tqaN8Ar2WyleMGK3s6skel+S7861k5zpHue9xc5xySTkk+K4XlONzCanmlT1V/JHRe35b6TtUpYfCq2F"
        "jrzvefa1Tqq6azvdRd7vUGarm5YAw2No7GNHc0eH/NfLYFjaFmYML0kIRpxUIKyW5HEryd2ZWBZ2jsWJoWZoUdiCMgWRvJQ1WCg5"
        "0WhIFNRoYKalUDlAgDhUpTBUI0IQgSkKVShKQkCmoQTBSQoSwU1AKoFAjVA5UoUJYKoFQmCoS0wVIKahKVAqAU1CZAcpgqAVSBKB"
        "VAqAU8oEyApgqAU8qEyZTUApqEsFUDhY8qsqNGQFVlYgVYKCLTBUJ5UaLBTyseVQKiuXlPKkFNAlZTBUJgqEtVlQCmqwlZTyoTyg"
        "Sw5PKhMFQlZVB2VCFCXlPKlChLynlSEKErKeSoVKEoHKMqUwUEPKEIVYbmp0wUkLuHkywUHxUgqh4KECoVJEKAhwUELKoIUZaMRC"
        "gtysxCRHoSjjcTBwlGCsvCjhSZ2THj0I4Vk4U+FRbJi4UcKy8KOFFx2TGGp8KvhVcKi2TFwp8KycKfCq47Ji4SmGrJwp8KrjskBq"
        "oNVhvoVhqDSiS1qzNak1qytai5yxiNowszRhQArbzQzmijIByVBSOxMHCDkRS6W2H1Vo+06SfTzVtFbbwJSax9XK2I1HN3VlrnHz"
        "mhvLA7Dk487LuaULE4basdijVdKW0lc7p+r3Snwnsvz+L9ZH1e6U+E9l+fxfrLhcFNcPmy5zt+kZfZO5/q90p8J7L8/i/WR9XulP"
        "hPZfn8X6y4YBwqR5sucfSEvsncv1eaU+E1l+fxfrJ/V5pX4TWX5/F+suGUwVebLnHz+XMdy/V5pX4TWX5/F+sj6vNK/Cay/P4v1l"
        "w2hXm65y8/lzHcn1eaV+E1l+fRfrI+rzSvwmsvz6L9ZcOApq83XOPn8uY7i+rvSvwmsvz6L9ZH1d6V+E1l+fRfrLh4FNXm65y8/l"
        "zHbFfrrRzqGpFVqCyzUpid1sXlMcvGzBy3gBJdkZHCAc9mFxrdZaKa610ltifDb3zvdTxSHLmRFx4WnmeYGB2n1lfwoXJTpqBw1q"
        "7q2ujIEKQVS2cIKlKAcKNFgqgVCpRFJgqQU1CUqBUApqEyIBUgqkMSkwVIKaBuWCqBUJgqEtGUsp5UaTHlWCsaM4UJmBTysYdlUD"
        "lBFoUoyoTIHKg5YsqgQVCZUKAU8oEpUCoyjKhMmUZUg5TyoSk8qMp5UaLQpBTyoigcJ5UZTDkCVlVlRlAcqwlp5U5RlQloBwpDk8"
        "qEtCkOQgjVaEA5Qu4eTQKlKFCUhCFCIhJX2pYUBGEsKy1GFFYx4RwrLhGPQozsmLhQGrLwo4VDskcCOErJwp8Kh2THwo4Vl4UcKL"
        "lsmMNT4fQsnCmGpHZMXD6E+FZeFPhRcdkxhqoNVhqYGFGlEQCsDCAFYCDaQAKgEJhRtFApqVQQbGCmpTBUKGqBypQoikwUkKFFIS"
        "BTQaRSFIOFSBBMFJCiRSoKQhQlIQhQoAqBUpgqEtCQKaDQwU1KYKhLVBQCmoikwUkKG5SoFQCqBUaLCMqQqRYigU8qEwUGi8qljy"
        "qBURYKa9Vt9eNKWS8z1GsNOS6gtjqdzI6WKrfTFkvE0h/EwgnDQ4Y7PO9C3X0jNP7Y7eQxaeseiZqa+3K3wXCmuYuU7204dMQ5pj"
        "e8hxLY3DP33oWlG6vc4J4nYqxpbLd+OlunjwOalS6OGjdr9rNB6Kuet7Hc9Q3XVdMK3/ACaqdCykhIY4cIa5vEeGRvI5yQewYXgN"
        "/NtKHa3XgtdqqJZ7TXUkdfSdccvZG8ubwk9+HMdg+GFODSuFLGQqT2Enrez4O2+xrIOTyoC3V0ZdEac17ra8UWp7b7oW+ks81YyE"
        "TyRYkbLEAeJjmnsc4YzjmsqN3Y5q1ZUYOpLcjTKF0dFpLbHdTbvWl50np24aXu2lqbyxwlrX1ENQ3he7hJeTzIjcOWOZHbzC+dpL"
        "RWgtIbP2zcHW9qrr9Le619JR0FPUugZG1jntLnOaQc5id3ntaMdpWthnD59C2sXe9raXu1fntu6TQgKoFb53D0ZoPb6+aE1dDaK2"
        "56G1PRSVZs01U6OVjhGMN61p4gAZYz2nm0jJBXtLjQbL27aa0bgnbSpfT3K4OoG0YvNSHsIEp4i7jwR+9HljvVyb3XB4+KUZKDal"
        "pw366ata6dRynlGV/beqihq7xcai2UjqK2zVEj6aldIZDBEXEsYXHm7hbgZPbhfwrB307q5QKpdOams+0u2+idva287fz3ev1DZ4"
        "ayaaK61EP751UZeSA/HMvJwAAFq222XTW6e7FlsumrXLpuyXKRkLoH1Lqh7MAl7g55JyQDgHlnC04W0udWljI1Iuey1FX1drae2/"
        "uNapgrpW6WzYij1ZdtD3GyXmxzUD5ab6oJauR/76wHzjHkjhJHIhvPI5DPLx+ze2um9RTa2vmpKiet03pCnM8kdESx1bnrOHBOCG"
        "kROOORyRzHNXJu9kwWOjsOpKLSVt6333WNNr72kdG3zXV3Fp0/b311cY3SljXtYGsb2uc5xDWjs5kjmQO0rYmtaTavUOgpdQaQZN"
        "p2/UVSIZLJVVZnNTGS0cbC4k8uIHt/mu5dhWyujTt/ZLnoWtq77NX082p6+S0Uhpq+enbIGU73nibG9oeDiQYcCPNx3qjC7sFfHK"
        "nQdXZaadrNce3Xn0Zy1U076Spmp5CwyQvLHGN7XtyDg4c0kOHpBIKxLZ2yuiaDUG9Fq0pqWi8oozLVQ1VN1j48ujhlOOJpDhh7Ae"
        "R7luW07GaQd0hKiwT2o1Gka2ze6VDT+UzDgOWMI4w8OJDw/kT3jKlTb1RqtmFOhJwle6jtezt3nJoKeVv7bDTOg6bY++641ZpeS9"
        "1VBd/I2tjrpqc9W5kGB5jgOTpHHOM81r3cDUegr3R0cekNGT2CpjkLp5ZbhJUiVuOTcPJxz55WXGyvc5aeK26jhGD0dm9Ld9/ceE"
        "BTXTl/sm0e32kNu6m/6Iq6+p1HaYaqoq6a5Tscx/Vxl7uDj4SSXk4GAtWb6bcUm1+unWq3VMk9sq6aOupTKcvZG8uHC49+Cx3Pww"
        "mUGlczQx0K0lFRave17a2dnubNbJgqMoysHeMmUKAUKE1cqUApgruHkikIQgRgpqUwVGiseCakFUogRhCFCACeElQQQsIATVKEnh"
        "VAIQobD4UYTQoRYTAVIUIsJ4QqQNhYTAQmAoQAwqCSFCUmCkhBpFIQhQopCQKahGCmpVKEAcKlKYKiGmCkhBopMFJChRSEgU0CCp"
        "SmCoSgU1KYKiGhCFCMFUCoTBUaLQkCmgUMFUCoVKEsFNQCqBUQ0wUkKNJlZVAqcoChMiFIKpBDBTUpgqE/qpaSorZDHSwSzyAcRb"
        "EwuIHjgetdF9MajqXa605UCnmNPHp2ma+UMPA09dNyJ7AeY+VaR0PuDqPbe7TXXTFx8gr5oDTPl6mOXMZc1xbiRrh2sac4zyXptV"
        "dIHcXW9gq7DftReWWqs4Oug8ip4+Phe17fOZGHDDmg8j3LSaSaOrUp1ZV4TilZX4u+tujxNob72S56h212QqLRb6qvhFjjpS6lid"
        "IBL1UA4Dwg4OWuGPQfBfP6ZD2jcmxU/EDNS2CmilaDksf1sxwfYQfavEbT78ar2vrrdT09znm01HUB9TbHhr2OjJ88M4gSwnJPmk"
        "c+3PNfxb4XGwXvcm73jTd9lvNsubhVCWZkrXwud76I9a0EhuOWMgNLRnklyTTOChQqU60Yy3R2rPrfHm8TXoK6O6GUjodx9QyNa1"
        "7maeqHBrhkEiaDkQub16fQ+4GotuLrNdNM3HyCvmgNM+XqY5cxlzXFuJGuHaxpzjPJZi7NM7mKoutRlTjvZ05RaiuW7WyG4jb9p6"
        "DS0FmgFZTzWmGSjp6uRrXO6p8ZJD+bGjv9+3sIGfJakt1Ze+iNt97m0s1YaG7VIqG07C8xZlqMcQHYPOb+MPFar1jvbr3X9u9zdQ"
        "6jqKugLg51OyKOFjyOY4hG1vFg8+eea/j0TutrHblk8emb7UUENQ7ikhDWSRudjHFwPBaDjAzjPILW2jqQwdWMbxsmpbSWtt1t9r"
        "9O4230jKeW3bZ7J22rjdBcKa0zGankHC+PLKcDiaeYOWkc/AqNTfyOtGf/6OT6KpaQ1Rq2961uz7rf7lPcK97Q3rZj71o7GtA5NH"
        "M8gAOZX9NVrq/wBZo6i0hPX8enaKpNXBSdTGOCU8eXcYbxn7Y/kTjn2cghzTbOaGFmqdON1eMrv37u0+ADhPKgFMFcZ9BHZuv9xL"
        "xofbjaOO16Usl9bVafgc91zt76oxFsMOA0tcOHOTnxwFz1DU6o3C3ZpKm1UFFY9T1s0clLBRsNHDDJHGOEsDieEnq88zzcfSv77R"
        "0kdzrFaqG12/U3U0FBAymp4vIKZ3BGxoa1uTGScAAZJJXjdTa91HrDUTNQ3i6STXqMMDKuNjIXM4PekdWGgEeI5rklNM+bhcJUo3"
        "TjHW+t297vqrLvOrdI3q97qaxqNA7p7eUdTURxyxS3uGkdDLAWNOH9Z2YcQACwgHibyIXitkbUBo/fzT9sea6oFEIqVsQ4n1DWeU"
        "t4mgduct7PugtX3HpB7mXW0PtVVq2tdRSM6t4YyNkjm4wQZGtDzn18147S+rL3oy6sutguU9vr2At62E++ae1rgeThyHIgjkEuau"
        "jMcBU2Jx0V7WSva6d79F+g+8drNSQ6FrNZ1VK2js9LUNpsVRMcsryWjzGEecPO7fvXeC6j8k0zobSuzluvmtIdOVtkDL3JRSUMk5"
        "qnSnic0uaRwe+lZk57fRz5X1nutrHcJtOzUt8nr4qd3HHCWMjja7s4uBjQ0nHLJGeZX8GstdX/cC6x3TUdf5bXRwtp2SdUyMNjaS"
        "Q0NY0Dtce7vWVKMdxzVcLWxGyqskkm3p1WW9a8b6HTlFpsaa6bNI1jeGnuLqi4RH7rraOUvP/ica2TsvUR6ovlbXOcHXDS11u1qf"
        "90aeeYTRuPoDmOaPauM5d49az6ns+ppL1xXyz05paOrNLDmOItc3hI4MO5PdzcCeanS+7+tNF3O8XKx3o0lZeZOtrX+TwvEz+Jzs"
        "8L2EDm93YB2raqRTOrWyytVp2utpRS48L34cU+03ns/qOs0p0ZNU3SgtNDdqmLUHC2krqYzxP4mUwJLAQTgHI59y01ubr2765ba3"
        "XPS1nsbaIyhhtlvfSibj4c8fE48WOAY8MnxX8+id5tb7d2qa16avfkNDNOal8XksEuZC1rS7L2OPYxoxnHJYtcbuay3HpaWl1NeP"
        "L4KR5khb5NDFwuIwTmNjSeXisSknGx26OEnDESqOKabbvd3WnNa3vOsxc9Gii2IsmrNN01yddLNTspa6olPDSyCGHhaY8YeHuLRz"
        "PLwK5h35uuobnunqAamEbbhSS+TMjiaRG2Fv2vgB58JaQ7n90SvMXzX+otSUtgprncnTQ6fgbT24NiZGaeNoaAA5jQSQGN5uJPLt"
        "Uax1xfdf3YXbUNY2suAibD1wgjiJa3OARG1oJ5nmefyBU5qSsGDwMqFRTbvo76vS7vp1rfu3HwwUZUApgriPqlZQkhRGr0wUkLtn"
        "lCwU1ITBSQ0IQg0MFUCoVBQlISBTUIJgpIUJYKakJgoIaEIUaGCqBUKggikJApqEEwUkKNFICAhRFISBTUIwU1KYKmIwqUpgoEaY"
        "KSFCUgJApqEpCQKahGCmpTBQIwqUpgqEaYKSFCUhCECMFNSmCoSgU1KoHKiBCEKNFBMFQqUJSAgHKECikA4SBTUJYKagFPKhKTyk"
        "hQlAqljVgoErKalCBKVBRlMFIlgp5Up5QNysp5U5QoSwVQKx5VAoItPKjKYKhKympQo0WCmpVA5UKDKeUkIEriTBUKlCWCjKQOUK"
        "FD4lWVCYKiKyjKSFWEpPKkFNQl5QoyhAms0IQu4zyYKlKYQJYOUKVShBCEKEpUCoCahKQhChBUpTChLBQpVIIEIQg0UmCpCahKQh"
        "ChBUpTChGmCkhRFIQEKRoYKalUhkMFNSqChBUDlSgKNFJgpIURSEBChKQkE1CMFNSqCGIBUpTChGhCECUDlCkKlCUhIJqEEwUkKE"
        "pUoCoIYjTBSQoSkwUghRopPKQQoikwVCpQlZVKAqCCGmCkhBooFVlQE0iUmCpBTQRSYKSFGrlKlAVBQlZRlJCBRQKoFY0wVCZMoB"
        "UhNRIpMFRlPKDRaeVAKYKiKygHKSFCWCmoymCoSk8qMp5UJQKEkKE//Z"
    ),
    "mercado_malo": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQABAAIDAQEBAQAAAAAAAAAAAgEDAAcIBgQFCf/EAGMQAAEDAwEEBAcHDA4H"
        "BQcFAAEAAgMEBREGBxIhMQgTQVEUIjJhcYGRFRZWdZShsxcYIyc3UmJykrGy0iQzOEJUdIKVosPR0+LjJjRGVYS0xERTpKXBJSg2"
        "Y2WT4UNFg8Lx/8QAGwEBAQADAQEBAAAAAAAAAAAAAQACAwQGBQf/xABBEQACAQMBBAMNBwQCAQUAAAAAAQIDBBEhBRIxQVFxwQYT"
        "FBUyYYGRobHR4fAzNEJSU3LxIiM1kiRUsiVDY4Li/9oADAMBAAIRAxEAPwDm8JIqQV5I9GIFSipBQI1iIOEkCIFJVhIFBCSBRWIE"
        "sBypBQBSQIlIKIKlAiUgogqUCJIHKIOViBGCpRUgoZCBSBQUgoYjUgogqUEMFSgCkCgyECpRSQKEsCISQQlIKIKlQoQOEkAUgViJ"
        "ISBRUgoIaSIWKMhjmmgFIKMFkYKQQSaVizIYKQQSaUMiwFJVpg5QJY05TBVTeaaCLEwqwmEGQwkCgCkgSxpTBVbSmCsSGOSTSi05"
        "CkIEsSQBSCGImnCarHNMFBCBTVaYKGJISRUgoFCBUopIYiBSQBSBUJIOEgUVIKxIawKAVKiEpBRBUoESxYFiDIxJFSCoRAqUVIKx"
        "IYKQVaQKCEkDlFYoRKQVCxBDBUogpIIkFSikECYsWLFGWTngFSipBXqzzaECpRUgoYiBSBQSUIlIKIKlDEYKlAFIFAkgpAoqQUEN"
        "SCiCpQxQkgcog5WLERJIrAVCIFJFSCgRrEQcJIIQKQVaQKGIkgUViBLAcrAiCkgRKQUQVKBEpBRBUoISkFEFSgRgqUQpBQIwkgEg"
        "UCJp4poBIFQiBSCCTSsRGCkOaCTUCWBIKtWDkhkMJAqtpwU0CWJBAFIFYiWBNVtKYKBE3grAqwkDgoEsCYVYKQKCLEgipBwUMRpI"
        "qQViIgUwq02nIUSECpRSRgyEsCISQIlIKhYghgqUQUgcoEkFIFBIFBCUgogqVEJJAFIFAolYsWIMkSCpRUgqYiBSBQSBysWQgUkA"
        "UgUCSDhJFSCoiQkCipBQQ1igFSgRLFAKxBHO4KlFSCvWHnRAqUUkCJYikghKQUQVKjISkFQsQQwVKIKQQJIKQKCQKxISSAKkFDFC"
        "BSRUgoEQKlFSCoRApAoJAoESkFEFSgRgqUAUgViRIKQKKkFQoakFEFSgRKQUQVKBEkisQIkkVIKBGkiFgWLEYKYVYSBUQwUhzQSB"
        "QJYCpBwUAUggSxIFAFILERhMFVg8U0EMckgi08EggRjmmFWEwUCWDmkEAcpAoEsBSCCTSsRLGngkgEgVEWAqUAUgViIgUggm0oEa"
        "wHCISUIlIKIKlDESSAKQKBJSBRUgoIaxEFJAiBSVYSBQQkgisUQwVKKkFYmRKxYsUIgcrEUkCJSCgCkghgqUQUgcoEkFSipBUQgU"
        "gUFIKCGsUArEYE53BUoApAr1h5waxFJDESkFEFSgRKQUQVmUYEYU5QzlZnCsEWAqcqsOWb2EYLJblIFU7yneVgcl2Sp3lUHedTvI"
        "wOS0OS3lTvBSHedY4HJcHKcqreU76sFkuDsrMqoOS3kYHJaCkHKkOSyjA5LVIKrDkwVi0ORgqUAUwsRJBSBQSBUKEkgCpCBEEkVI"
        "KBECpRUgoEYKSASBWIiBSBQSCBGFKAKaiQgcJgoBJYiixJp7FWCmFCNMFVgphYiMJtOVW0pDgUCWJhBILEUMJqsFMFRDBTHNVhML"
        "ERgpgqsFIKEsBUgohSFiyGCkDgohSgyLFIKAKSCEpBRBUqESkFEFShihgqUVIKBECkCgpBQQ1IKIKlDEYKlAFIFBCBUoqQUMRhYi"
        "kgTFgKxYoRKQUQVKBEkCgCpBQRYsRBSQIliISUQgViKxBHO6QKKxesPODBSBQBSQIlmUcrMowIlm8gXIlycFks3lm+qC9eu0fs21"
        "BrUiSgpRHRA4dWVB3Ih5gebj5gCsKtSFKO/UeF5xhGU3uxWWeX3+KzrF0VaOjzZKKES3i6VVW5vF3VYgiHrOT84X6DtD7J6H7HNN"
        "aw8cD1t14/pr5T23bt4pxlLqX8HZ4BUSzNqPWzmYSedTvrpb3qbIv4RZf50/zFnvU2Rfwiy/zp/mK8bx/Rn6vmXgT/Uj6zmoSKd9"
        "dKe9TZF/CLL/ADp/mLPersi/hFl/nT/MR43j+lP/AF+ZeBv9SPrObBIp6xdJ+9XZH/CLL/On+Ys962yP+EWX+dP8xXjeP6U/V8x8"
        "Df54+s5tEikSLpH3rbI/4TZf50/zFnvX2R/wmy/zp/mI8bR/Sn6vmXgb/PH1nOAk86QkXR3vX2Sfwmy/zp/mKyPZ3syu/wBjopaN"
        "0h4DwS6bzvYXH8yHtemtZUppdXzFWcnopxfpObxImHrd1+6PTAx0ljurw/GRBXN4H0Pby9YWnr/py7aWrTSXWjkppebS7i1472uH"
        "Aj0Lqtr63udKUtejmaqtCpR8tHyhybXL5GyedWteupxNSZ9IKsBVDXZTBWDRmmXLEQUlgIgUlWDhIFQjBUoqQUCIFSipBQxECmCq"
        "wksRQwUggCkCgRJgoJBDFDBSBVYSCBLAUwVUCmECWJtOQqwcpA4KGIxwKsVaQKGRYCmCqxySBWIlgKQVYTaUCixpTBVYKQKGIwUw"
        "cKsFIKEtBSVbSmCsSGCkgCkChihBIFBJYsRKQUQVKiEkisChEkipBQIwsRCSxYiBSBVaQKiEpBULECMFSiCkgiQVIKKQQxEsUAqU"
        "CYpBULFCJIFEFYgRgpAoKQViQ1IKIKlQiWKAVisEc7ApIApAr1Z5wkJAorFEIlQSoQc5WCJc7CrLlDnL1mzLR51vq2loJA4UMQM9"
        "U4dkbeY9LiQ31oq1I0oOpPgtRhFzkoR4s91sh2QjULYr9fYne5ec01KeBqSD5Tu3cz+V6Ofo9o+3qh0o59j0rBT1VdTjqnT4/Y1N"
        "jhutaPLI7hho8/JZt72kHSdrg0tZHinrquEdc+HxfBqfyQ1uORdjA7mg94XK2QOGOC0bG2M9qtX9+v6PwQ5Y6X9a9WEG0do+Bf8A"
        "FtfK/FLsX1p1n72odY37Vc7pbzdqqsJOQx7yI2+hgw0exfhhrRya0epHKzK97TpwpRUKaSS5LRHl5zlN703l+cWB3D2LMDuHsRys"
        "ythiLA7h7FmB3D2I5WZVkhYHcPYswO4exHKzKiFgdw9izA7h7EcrMqIWB3D2LN1oIO6MjtwjlZlWSPbaT2rar0dJGKG6SzUjcZo6"
        "smWIjuAJy30tIXSekNfaY2z2iW03CkZFcGt3paCV2SP/AJkL+Zx3jBHaMLjbK+q3XOrtFfTV9BUPp6ymeJIpozhzHDt//HavO7X7"
        "nba/i501uVVwktNfPjj7z61htatavdk96HNPs+sG19omgKvQd0DC509sqCTTVJGM45td3OHz8wvJMeum9O3a37b9nEjKlscVaR1N"
        "Q0cfBqloy17fwTnI8xIXMlbRz2uvqaKqYY6mmkdFI09jmnBXlLGvUnv29wsVIPD+P118z0FeEEo1aTzCWqL2OV7XZXxMdlfQxy7J"
        "I1Jn0tKsBVLSrAVraM0NSCiCpWIjBUoApAoMhAqUUggkIJKtWDkgTAcJAoqQgyGCkCgCkEEMFIFAFIHCBGOaYQBykCgSwJAqsFIF"
        "DEsBwmEByUg4WLEtaUlWEwUEMJIBIFDEsByEwVUCmChiWApBAJBAjCYKrCQQJYCkCqwUgUEWApBVgpAoYoaSAKlYiJJFSCohAqUV"
        "IKhECkCgpBWIjWA4UAqUMRApIApAqEkJAoqQViQ1igFSohKQUAUkCJYsBysQJiSKwHCjIQOEkVIKxIYKkFBIFBCWLFihOdVIKIKl"
        "esZ5wYKzKgFQSoiSVW4pEqpxWSQMD3YXS3Rys8dDpe53mYBrqyo6vfPZFGMn53H2LmV7l1ToBxodgj5o+DxQV0uR99mTj8y+Pt7L"
        "to01+KSXb2HZs7HfXN/hTZyzrLUcurNU3a8zOJNZO57AT5MYOGN9TQF+HlVsOGNHcAllfpNKnGlBU4LCSwupHjZylOTnLi9RZWZR"
        "ysyszHAsrMo5WZUWBZWZRysyosCysyjlZlRYFlZlHisyosCysyjlZlRYFlZlHKzKiwbk6N+pH2rXbrU558FvEDoy0nh1rAXsPpwH"
        "D1r9vb7Zm23WzK6NuI7lTtmce97TuO/MD61q3ZdO6n2kaUkacH3Rib6icH5it7dJWMAaalx437IZnzeIV4HbVNUdt05x/wDcjr6M"
        "/BHqtmTc9nTi/wAMtPTj4s0dG5fWxy+CIr64ys5oziz7GFWhUNKtaVpaNqLQUgcqtew0Nsw1XtI8P97Fq8P8A6vwj9kRRbm/vbv7"
        "Y5uc7juWeSxjCU3iKyxlJRWZPCPJqQVtv62Har8Ff/MKX+9U/Ww7Vvgr/wCYUv8Aerb4LX/I/UzX4RS/MvWjUoKlba+ti2q/Bb/z"
        "Cl/vVrz3sXX30e9nwX/254b7neDdYz/WOs6vc3s7vlcM5x58LXOjUh5UWs+YzjVhLyZJn5STStsDox7Vfgt/5hS/3q+a5dHXaXZ7"
        "dWXGt00Y6OjhfPM8VtO4tY0FzjutkJPAHgASsna1ktYP1MFcUnpvL1o1ksUAraFq6PG0m92uiudDpzrqGuhZUQSeHUzd+N7Q5pwZ"
        "ARkEHBAK1QpzqaQTfUbJVIw1k8GskmlfTdbXV2O6Vtrr4uprqKZ9PPFvB25IwlrhkEg4IPEHC+RYNY0ZmnksSBygDlbA0PsZ1ftE"
        "tU100/QQ1FHDOaZ731DIyHhrXEYcQeT28VQpyqPdgssJzjBZk8HhAUgVuAdF7aX/ALnpvlsP6yw9F/aW0EizU58wrYf1lt8DuPyP"
        "1M1+FUfzr1moQUwV6bVezbVmhwHX+xVdFETuiYgPiJ7usaS3PmyvMBaJwlF4ksM3RkpLMXksaUl9Vls9dqG60drttOaivrJBFDEH"
        "Bu848hkkAeknC2UOjftO+DP/AI+m/vEwoVKizCLfUinVhB4lJLrZq0FML3WpNiuutIWaovF5sRprdTlokmFVDJu7zg0cGPJ5kDl2"
        "rwjSsKlOdN4mmn5xhUjNZg8lgKS/R03py56tvVNZ7NTeFXKq3uqh6xrN7daXHxnEAeK0niexet1FsV11pSzVN4vFj8Gt1Lu9bL4X"
        "A/d3nBo4NeSeLgOA7VRo1Jxc4xbS54J1YRajKSTZ4MFIFAJBaTYWApgrYds2DbQrtb6S4Uen+to6yJk8MnhlO3eY4BzTgyAjII4H"
        "ivC3K3VNnuVZbq2PqqyjmfBNHvB249ji1wyCQcEHiOC2To1IJOcWk+lGMKsJvEZJlASBX1Wiz3C/V0VBbKOesrJfIhgYXOPnwOzz"
        "rbdr6MOvK+Fsk7LbQFwzuVVSS4f/AG2uCaVtVrfZxbCpXp0vLkkacBSBW3bv0aNeWuF0sNPQ3ANGS2jqPG9QeG59S1VX2+rtNZLR"
        "19LNS1cJ3ZIZmFj2nzg8UVrerR+0i0NOtTq+RJMpBSBVYKQK0G0sBSBWwqPYPtBrqSnq6fT5dBURtljcauBpLXDIOC/I4HkeKvd0"
        "f9ozGlx06cAZOKynJ9nWLf4FcPXvcvUzT4VR/OvWjW4KlH86kFcp0CBUoqQVEIFSikgRBTlBJBkJSCgCkghgqUAUsoIQKQKGVIKB"
        "GpBRBUqISSAKkHCBQlixYgyRIKlFSCpiIFSDhFSCsWQwVigFYgjnZSCiCpXrTzglnNYEVEY4qp5VjlS44WSBlLyuqtG/ue5Piut/"
        "PKuU39q6r0b+56k+K6788q+Rtz7Oj++Padmz/KqftfYcdNPit9AU5QafFHoCnK/ScnjRZWxdiWmbXq7XsNsvNKKqhdSzyGPfc3xm"
        "gYOWkHtWuMrbfRtP20af+I1P6IXzNs1J09n15weGovDXHgdmz4xndU4yWU2joL6g2z74PN+VTfrLnPbvpS0aN1lT2+yUYpKR9DHM"
        "Yw9z8vLngnLiTyAXaa5E6T/3Q6T4ti/TkXgO5LaF3X2ioVqspLdejk2uXSz1O3bWhStN6nBJ5XBJGmMrMo5WZA58l+pZPFHqtC6C"
        "vG0G7+59qjaGxgOnqZciKBve4957AOJ9pXTem+jjo+zwsNzZUXmqx4z6h5jiz5o2EcPSSv3timmINMbOrO1kbRVXCJtbUvxxe+QZ"
        "GfQ3dAXsb7e6PTdnrrtcJDHRUURllcBk4HYB2knAA7yvynbndJeXV1K2tJOMU8Ld4yfDitdXwSPcbN2Rb0aKq10nJrOvBHnm7J9D"
        "Nj3BpO0bvngyfbzXnL/0etEXmFwpaGW1VBHiy0UpwD52Oy0/MvB1HSvjFWRT6Vc6kB4GWs3ZCPQGkA+srdWhdc2vaDYmXW2GRrQ8"
        "xTQSgB8MgAJaccDwIII4ELhuKO3NmRVxVlOK6d7Pr1ftOilU2beN0oKLfVj1aL2HHW0fZjd9m9wjirC2pt9QT4NWxNIZJjm0j964"
        "d3rBK8Rld87RtLwaw0VeLXKwOkfA6WBxHFkzAXMcPWMeglcBg5APLIzhfoHcztqe07Zur5cHh+fPB+/1HltsbPjZVlueTLh8B5WZ"
        "RysyvSZPkHq9mp+2HpX4yg/TC3/0mP2jTX49R/Vrn7ZoftiaV+MoP0wugOkz+0aa/HqPzRrw3dB/l7b9su09Nsj7jW612GhYivtj"
        "K+CIr7Iyspo2RPtYVcF87Cr2ngudm5Fg4rrzoO/7ef8AA/8AULkMFdedB3/bz/gf+oXXs77zH0+5nPe/YS9HvN+bTdsGntk7bW6/"
        "MrnC5GUQ+CxB/wC17u9nLhjyx861/wDXh7PP+4vnyVn668P04P2rQ341b/ULkMFdl5tCtRrShHGF8DltrOnUpKcuJ3p9eFs8/wC5"
        "vnyVn665asN5p9Q9IW2XijDxSXHVcdVCJBh25JWBzcjsOCFrFev2Un7aGifjqi+nYuGd5UuJRU+TOuFtCjGThzR/S7VF697emrze"
        "eo8I9zaOar6nf3Os6thdu72DjOMZwfQstlbSar03SVgYHUN2o2ShhOcxyMBx7HL8nah9zTWfxNWfQPXjOjLqD3f2O2QOfvTW4yUM"
        "nm3HEtH5DmL0bqf3lTfNZPhqH9rfXJnAl/tMtgvtztM2euoKmWmfnvY4tP5l/SzZX9zDRXxLRfQMXEHSbsHuDthvTmt3Ybk2Ouj8"
        "++3Dj+W167f2V/cw0V8S0X0DF8nZlPvdepDo+J9G/nv0YS6T+em1f7qOtPjir+mcvIg5Xrtq/wB1HWnxxV/TOXj18Wr9pLrZ9Wl5"
        "C6hhdwdDn7mV2+OZfoIFw8Cu4Ohx9zG7fHMv0EC7tk/eV1M5do/Yek9ptL29ab2WXumtF4ortPU1FMKprqOKNzA0uc3BLpGnOWHs"
        "7l5GHpgaElka11v1BE0ni99NFgenEpPzLUvTH+6RZ/ieP6aZc8Arfd7Sr0q0oRxheY029hSqUoylxZ/UKzXvT+0TTYq6CWmulmrW"
        "mN7Xsy13ex7HDge8ELhPbts2i2aa4lo6IO9yK6Pwqj3jksaSQ6PPbukH1ELdnQxbWe4eq3P3/ADUwCLPk9Zuu38efHV59S/L6Z5i"
        "8K0YBjrtyrLu/dzFj595bbxq5slXksNfHBrtU6F26MXlfLJ4zop6d92NpwuD2ZhtFLJPk8t932No9j3H+Sup9rG0duzW1WetLIX+"
        "G3KGlkEufFhOTI4YI4hoODyyRwK1j0P9O+A6OvF7kZiS5VYhYT2xxN5/lPePUvF9MPUPhOpNP2Jj8toqZ9VIB99I7AB84Ef9JVGT"
        "tdn764vt+RVIq4vNx8F9e86f15p8aq0XfrNuhz62kkjjz2SbuWH1OAK/mkQWkgggjmCv6Q7LdQe+nZ3pu6l+/LPRsbK7vkYNx/8A"
        "Sa5cJ7X9Pe9faXqW2tZuxCrdNEOwRyfZGgegOA9S1bZipwp148+3VGzZcnGU6T+uTPQdHA52zaa/4n/lpV1V0ifuN6m9FP8A8xGu"
        "U+jf92fTP/E/8tKurOkV9xvU34tP/wAxGnZ33Cr/APb/AMUF798p+j3nA6kFBpSXnT7Z/SLZz9z3SXxTSfQtXBm0k/bG1gP/AKvW"
        "fTPXeezj7nmkvimk+hauCtpf3R9YfG9Z9M9eh2x93pfXI+Lsz7ap9cztPYrs6o9BaPoj1DfdiviZPWTkeNvOGRHn71ucY78ntXl9"
        "Y9JzTmmrtU2yhoKq6zUzzHLLG9scW8DghrjkuweGcY7iVuW1V0N0tdFXUzg6nqoWTRkci1zQR8xXCG0PZDqfRN2rDJbamqtfWOdD"
        "XQMMjHMJ4bxHknHMHHmyOK6r6pVtKEFbLTpxn6yc9pCnc1ZOu9TpfQnSO01rK6wWqemqbVXVLgyHry10UjjyaHjkT2ZAzyzlfftz"
        "2bUet9J1lbFA1t8tkLpqeZo8aRrRl0R7wRnHccefPDcE8lNPHNE4slicHtcOYIOQV2s7pL7PpGuY6qri1wwQaR3ELmtL+F1SnSu2"
        "l7PrBvuLOVvUjUtk/r4nFQK/c0fY3al1VZrQ0Eitqo4nY7Glw3j6hk+pfhHGTjl2LdfRgsPuptEfcHtzFaqV8oPZvv8AEaPY559S"
        "+Ba0e/VoU+ln2Lip3ulKfQjrbUt3i0xpm6XQtaI7fSyTNYeAO60kN9ZAC+PQOpjrHRtmvjmxtlrIA6Vsed1sgJa8DJJxvA8yV4Hp"
        "LX33J2aTUjXYlulTHTDHPdB33foAetfk9Fe++HaKuFqe7Mltqy5o7o5Bkf0mvXsHdYvVb8t32/weaVvm1dbnn2fyc6bUbD72doOo"
        "bcG7sTKp0kQ7o3+O0fkuAXkgVvzpVWHwPVNovLG4ZcKYwvI7Xxnn+S9o9S0EvH31HvNxOHn+Z6S0qd9oxn5hgqUAUgcrkOkYWIpK"
        "ESwFQCpQxEpBRBUoESkFEFSghJIg5WKISSKwHCxEQOEkVIKGIgVKKkFAiBUoqQUMhAqUUlGQliIWLEjndIIhYvXHmxLFijKBCSqn"
        "lWuVL1mjFlDyurNG/ueZPiqu/PKuUXrq3Rv7nmX4qrvzyr5G3fs6P749p27O8qp+19hxu0+KPQFmUGnxW+gKcr9HPHCytu9Gw/bS"
        "p/4jU/ohagytu9Gs/bSp/wCI1P6IXytu/wCNr/tl7jt2b97pfuXvOzFyH0ofuiUfxZF+nIuvFyD0oj9sWk+LIv05F+b9xn+TX7X2"
        "Hru6H7m+tGlsrM54d6OVmV+unhDvHZBqGDUmzmwVEL2mSnp20k7QeLJIwGkH1AH0EL1V5s9FqC1VlruMImoayMxSxkkbzT5xyPbn"
        "zLhbZ7tLvWzi5Pqba5k1JPjwmimz1cwHI8OLXDscPnC6Z030j9F3mJguE89mqiPGZVRl0efNIwEY9IC/Jttdzd7a3Mq9rFyg3lOP"
        "Fc+C106Ue52dte3rUVSrNKSWHng+zXoPG33oqMdI99j1GWMJ8WGvg3sebfZz/JXl3bItrGg4Kn3Bq5X08hD5BaK3dc8gYBLDuknH"
        "dldP2jVtgv8Aj3KvdurSeTYKljnfk5z8y/ZI7CPatMe6jadH+1cpTXROP8e02PYtnU/ro5i+mL/k4LrdoevrfUy0tZqS/wBPURnd"
        "fDPO9j2+lp4rxuV3htK2a2zaNZZaeoijZdY2HwOtx48T+wE9rCeBB78jiuEJ4ZKWeWCZhZNE90b2n964HBHtC973PbVttoUpSpU1"
        "CSxvJY9D5ZXHqPMbWsa1rNKpNyi+DftDlTlDKzK9EfJPWbMz9sTSnxlB+mF0D0mv2jTX49R/VrnzZmfti6U+M4P0wug+k1+0aa/H"
        "qP6teH7oP8vbftl2npdk/ca3Wuw0FEV9sXYvhiX3RFZzM4n1sVwVDFe3iFzs3IsHJde9Bz/bz/gf+oXIIXX3Qc/28/4D/qF1bO+8"
        "x9PuZz3v2EvR7zqu66ftF9EQutroa/qc9X4XTsl3M4zjeBxnA9gX5v1P9JfBax/zfF+quaunD+1aG/Grf6hcgr6V1tCNGq4OGcfX"
        "QcNvZurTU1PH11n9Kdpuh9L0mzbWNRT6bs8M8NnrHxyR0MTXMcIXkEENyCDxyuCNlP3UdE/HVF9OxePBXsNlJ+2hon46ovp2L5la"
        "5VxVg1HGPid9Kg6NOScs5P6M7UPuaaz+Jqz6B6536FOoN6n1Vp97/IfFXRN9ILHn+jGuiNqH3NNZ/E1Z9A9cRdFfUPuHtgtkLn7s"
        "V0hlonns4t32+10bR619W6qbl3Sfo9Z8+3hv29RfWhs/pqafxNpa/sb5TZaGV3ow9g+eRdGbK/uYaK+JaL6Bi8N0o9P+7mx+6StZ"
        "vTWuaKtYPQ7ccfUx7j6l7nZX9zDRPxLRfQMW2lT3Lub6Uma6k962iuhs/nltY+6jrT44rPpnLyK9dtY+6jrX44rPpnLx4K8vV+0l"
        "1s+/S8hdQgV3F0N/uY3b46l+ggXDq7h6G33Mbt8dS/QQLu2T94XUzk2j9g+s95tE2GaY2nXmnut7kuDaqCnFM0U0zWN3A5zhkFp4"
        "5eV5SHok7PopWvc68StB4sfVDB9OGA/OvIdJba9rPZ/re223Tt58BoprayofH4NDLmQyytJy9hPJreGccFpk9Jbai9padUHj3UNM"
        "P6td1xc2cKslUp5fUviclChdSppwnhdb+B3VSUem9m2mOqgbSWexUDC4lzt1jR2kk8XOPecknvXBW2zaUNp2t57lTh7LVSsFNRMe"
        "MExgkl5HYXEk+YYHYvKal1zqTWcrZL9eq24bhyxk0hLGHvaweKPUF9ezXTvvt17p2zFm/FV1kbZR/wDKB3n/ANEOXDd3zut2jSWI"
        "nZbWit81ZvLP6B7JtO+9TZvpq1OZuSxUbJJW90j/AB3j8pxXDe2/UPvl2qamrGv3ooqk0seOW7EBHw8xLSfWv6Lry0mzPRMsjpJN"
        "H6efI8lznOtsJJJ5kndX2LyylXpRpQeEj5drdqlUlUkstmpeiLqH3R0FcbQ9+ZbXWEtH3sco3h/SEi1/0v8AT3geqbHfY2YZX0rq"
        "eQj7+J2cnzlsgH8ldW2XS1i026Z1mstttrpwBKaKlZD1mM43t0DOMnn3rVXSk077tbLZ61jMzWipjqgQOO6T1bh6PHB/krXc2slY"
        "ulJ5cV7vkbKFwnd98Wifb8zm7o38ds+mf+J/5aVdV9Ir7jWpvRT/APMRLk3o61DKfbLphzzhpfOwZ73U8jR85C646QVLLV7HtURx"
        "NLnNiikIH3rJmOcfUGkrk2d9xqr93/ijovfvdN9XvP5/ApgqoFMFecPtn9JdnH3PNJfFNJ9CxcE7Sj9sfWHxvWfTPXfeg6WWi0Np"
        "mmmaWzQWymje08w4RNBHtC4WulLR6h211tLUud7n3HUb45XMdg9XJVEEg9nAr0e14t0aUefyPibNeKtSRsLYz0hnaKoYbBqKGaqs"
        "0RxT1EXGWmBPkkHymfOPPwA6j03tC0vq6NjrNfKKqe7/APREgbKPTG7Dh7FqPVHRm0bbdM3qtoW3N1dTUc00DXVAIMjWEtBG7x4g"
        "Lj1pwVq8LutnKNOslJcv5Nng1vetzptpn9HtQ7PtL6rY8XexUNU9/OUxBsvqkbhw9q5v2sdG52naCpvelZpqmigaZJ6GbxpI2DiX"
        "Md++A7jxwOZWrdIbXtX6LqIX0F4qJqRhGaOqeZYXDu3T5PpbgrvWw3RmoLBbLoIjGy4UsVSI3cS0PYHYPtXVTdttOMk44kvrjzOe"
        "ar2Ek97MWfzXBXX3RTsHgOjbneHsxJcqrcae+OIYB/Kc/wBi5c1pb4bRrLUNvpgBT0lwqIIwOxrZHAD2Bd67NLB72NA6ftZbuSwU"
        "jHSt7pHeO/8ApOK+fsWh/wAmUn+H38Pidu1K39hJfiOeuljfvCNQWKyMd4tJTuqXgffSOwM+cCP+kvy+i3fvc/XlXbHuxHc6Rwa3"
        "vkjO8P6O+uqLnozTd6q3Vdy0/aa2qcADNU0ccjyByG85pKFBojTFqq4qyg05Z6SriyWT09FFG9mRg4cG5HAketfSls2q7vwreXH2"
        "cPccCvqatu8bvL2muekvYfdbZw+uY3MtqqY58jnuO8Rw/pA/yVxkCv6N6osrNR6bu1pfjFdTSQAnsLmkA+o4PqX85JI3wSvikaWy"
        "McWuaeYI5hfM29S3a0anSvcd+x6mabh0P3krAcIgpA5XwT64wVIKAKlA5LFIKrDksqEanKIOVKxInKWUFIKjIeUsqtSCgiwFSgCk"
        "CgUIFSipBQQgVKKkFGByIFSikgRLAiEkCJYisUJzukipBXrTzYgVCxQCggk8FVIrXKl6yRiyh66t0d+54l+Kq788q5ReurtHfueJ"
        "fiqu/PKvkbd+zo/vj2nds7yqn7X2HGTT4o9AU5VbT4o9AU5X6MeOHlbe6NRztTp/4jU/otWnsrb/AEaTnapT/wARqf0Qvlbc/wAd"
        "X/a/cd2zfvdLrXvOz1zB0h9Dam1LrqlrLPYq+vpW2+KMy08W80OD3kjPfxHtXT6jgvx/ZW0qmzbjwinFN4a18576+s43lLvU3hcd"
        "Dgf6kuu/gld//sf/AJRk2V63p43zTaTuzYYgXvJg4Bo4nt7gu+uHmXw3vHuLc+X+qzfRuXqId3F1KSTpR9vxPiy7m6CTe+/Z8DXd"
        "FsI2cV1HTVUVjLoqiJkrHCsmwQ5oIPledeL2sbAbXTaX8M0XZ5G3OllEksLJnyPmhwQQ0OJyQcHA4nBV/R72vUNxsdBpO81LKe50"
        "cYio5JXYbUxDyWZP79vLHaMY45XQB4HB4FfMur7amyb7dq1JPdeibbUl6+D9nWjso21lfW29CCWVySymfzYfDNBUdW+KSOoYcbrm"
        "Fr2n0cwV2R0d3aqfo+pOozVmm65vuea3PW9Xu+N5XjbmcYz58cFtwxRuk6x0bDJ9+Wgu9vNMnJ4nJK27a7qPGdv3jvKjw1zl+jRY"
        "+Bhs7YvgdXvvfM+bGPXqyW+U30hfzw1tPFUaz1FNAQYZLjUOYRyx1jl15tj2t0GgbNU0NJURy6lqYyyCnacmnyMda/uxzAPEnHZl"
        "ccWTTl41PUvgtNuqa6Zgy/qm53c9rnHgPWV9zuJsalKFS7qLEZYSzzxxfV0ek+V3T3tJbtNyX9OW3yR+blZlfpX3Td40zUNp7xba"
        "mileMsEzMB48x5H1FflZXvk09UeXhONSKlB5T5o9bsyP2xdKfGcH6YXQnSb/ANX01+PUfmjXPOzI/bF0n8Z0/wCmF0N0m/8AV9M/"
        "j1H5o14nb/8Al7b9su09Rsn7jW612Ggol9ka+KNfbEs5mUT62K5pVEavbyWhm5Fo5Lr3oN/7ef8AAf8AULkAFbJ2U7ar/sf91/cO"
        "ktlR7qdV13h0cj93q9/d3dx7cfthznPYt1pVjSrRnLgvgarmm6lJwjxO3dtWxKDbI2yNnvMtt9yzMR1cAl6zrNzvcMY6v51qb6yG"
        "g+GVT8gb+uvBDpp6+/3Rpn5NP/fKfr0te/7o0z8mn/vl9GpXsaknOay/ScMKN3CO7F6eg959ZFQfDKp+QN/XWgdLWRumdvllsjJj"
        "Oy16phoxKW7pkEdWGb2OzO7nC2H9ejr3/dGmvk0/98tLe/Wv9/vvz6mm91PdT3W6rdd1PXdb1u7jezu73DG9nHb2rjuJ2uYuisYe"
        "vE6qMLj+pVXyP6UbUPuZ6z+Jqz6B6/mfpW9v01qazXmPO/bquKpAHbuPDsevGFuK/dLjWuorHc7PVWvTzKa400tLK6KnmD2skYWk"
        "tJlIzgnGQVoZW0LqFacZU+QWdvKlGUZ8z+rWobVBqvS1ztm+11PdKOSAP7N2RhAd8+VVoqzVGnNG6ds1W+J9VbbfT0kroiSxz442"
        "tJaSAcZBxkBcTWTpda4sVmt1rit1gmioaeOnZLPBMZHtY0NBcRKASQOOAF+gOmbrw/8A7Tpr5NP/AHy+ktp2+d55ycXgFfG6uBqr"
        "awfto61+OKz6Zy8gv0NQ3uo1LfrpeqtkTKq5VMlVK2EEMa97i4hoJJxk8Mkr84FecqNSk2j7kFiKTECu4uht9zG7fHUv0EC4cWyN"
        "n+2/VmzWzT2mwzUjKSaodVOE0Ae7fLWtPHuwwLpsa8aFXfnwNF3RlWp7keJsXpk/dJs/xPH9NMudwV6nX20S97S7vBdL9JA+rgpx"
        "TMMMQjG4HOcOHfl5XlVpuqkatWU48GbbeDp04wlxRYCuh+iFpz3S2gV95ezMVoozuu7pZTuj+gJFzsCtmbMdtt92U0NfS2W32mcV"
        "0jZJZKyKRz/FGAAWyNGBk9naVWk4U60Z1OCC5jOdJxhxZ1t0l9YVekNmkjrdWz0dxuFVFTRT08hjlYMl7i1wORwYR/KXGI2o65+G"
        "eo/5zn/WX6207bTqHavDbYbzT2+nioHPextFG9geXADLt57s43eGMcyteA5W6/vHWq71NvBqs7ZUqe7Nam0NB7XtV27Wdhqblqq9"
        "1VuZWRCphqa+WSN0RcA7LXOIPAnmu99UWSPUmm7tZ5cblwpZack9m80gH1E5X8ugVv6k6XOuKWlgg9zrBL1TGs6ySCYufgYycSji"
        "Vv2ffwpRlCu20/T1mq8s5VJRlSWqNO2W6VukdSUVwhbuV9rqmyhjvv2OyWnzcMFf0c0xqSzbRtKQ3GjMdTbbhCY5oX4O7kYfE8d4"
        "yQR/6Ffzcvt4l1Be7jdpoYIJ6+d9RJHACI2ue4uIaCSQMk9pX7WiNouo9ntc6qsNxfT9ZjrYHDfilx98w8D6eY7CtFjfK1k4vWLN"
        "t3aO4imtJI6G1T0QjLcJZtN32KGjkcS2lrmOJi8we3OR6RnzlfqaB6KNLZbrT3HU10juLad4eyip4y2Jzgcjfc7i4fg4Ge044LzN"
        "s6Y10ihaLlpajqZccXU1U6EH1Oa/86pvHTBvlTC5lq07Q0UjhgSVEzp93zgAMGfSuzf2Wpd8S16Nf4OVxv2tz26HQ+1XaHR7ONJV"
        "dymkZ7oSNdFQwE8ZZiOHD70cye4d5C/npFWTxVbKtkrhUskEokzxDwc59OV9+p9XXrWdzfcr5cJq2rIwHPOGsb961o4NHmAC/IBX"
        "ztoXzuqiaWEuB3WdoreDT1b4n9Gtm2vrftH0rS3WlezwjdEdZTZ4wy48ZpHceYPaFpvWvRQp7jcp63TN2joYZnF5oqmMuZGT2NeO"
        "Ib5iDjvXM2ltX3vRdybcbFcJaOpxhxZxbIO5zTwcPMQt6WfpeXqnhay66doayQDBkp5nQb3nIIfx9C+hG/tbqmoXa1XP+NTidncU"
        "JuVs9Hy/k/Y0v0SXw18U2or7DLRxuDnU1FG4GUdxe7G6PQM+hb81fqm1bO9Kz3OrMcVLRxiOCBpwZHAYZGwd5xjzDJ5Bc5XPpfXS"
        "aFzbbpijppSODqipdMB6g1n51pLV+vb/AK8rxWX24SVLmZEcQG7HED2NYOA9PM9pKnf2lpBq0WW+evaKtLm5mncPCX1yP09EW6bX"
        "m0u1U9SOsfcrh11Tw8pu8ZJP6Icu+NS3hmntO3W7SY3aGlkqMHt3WkgevGF/PjQmtq7Z/qCO926mo6isjjfGwVbHOY3eGCQGuac4"
        "yOfaV7rVvSM1VrLTtdY6yjtEFLWtDZJKaKVsgAcHYBdIRxxg8ORK5tn31K2oz3vKf0vabr20qV6kceSjxp2l60cSTq6/5PdcZh//"
        "AGUjaTrP4XX/APnKb9ZeUBSBXye/VPzP1n0lSh+Veo/ops6vx1PoawXVzy+WppGda4nOZAN1/wDSBXF22iw+9zabqCla3dhmn8Kj"
        "xy3ZRv8ADzAuI9S/R0Pt91NoLT8Njt9La56OF73sdVRSOe3eOSMte0YySeXavN7QNoNx2j3eC6XSloaeqigFP+w2Pa1zQ4kZ3nO4"
        "+MV9W/vqNzbQj+NY92p860tKlCvKX4Xn5HlgkCqwUgV8PB9UsUgoApIMhKQUQVKCEkCiDlYoR5UorAcIEsBWIpIYkgpAoKQUEWAq"
        "VWkCgcjBUogpA5QRIKkFFYjAosysBQBUqEsWIArEYHJzyCpRUgr1rPNiBULFmUDkJKperXKl6yRiyh66u0d+53l+Kq788q5Qeur9"
        "Hfudpfiqu/PKvj7d+zo/vj2nds7yqn7X2HFzT4o9AU5QafFHoCnK/RcnjxZX7GmdU3XR91bdLNVeDVzY3RCTq2v8V3MYcCOxfi5W"
        "ZWFSEakXCaynxTMoylBqUXho2f8AXB7RfhB/4SH9VZ9cHtF+EH/hIf1VrDKjIAznguHxRYfoQ/1XwOnw+6/Vl62bQ+uD2i/CD/wk"
        "P6qrn2+bQamCWGW/70crHMcPBYeIIwR5PcVrMOB5EH0KcqWybBcKEP8AVfAnf3XOrL1skYAA7Ave6f20a50zCynor/PJTMGGw1jW"
        "1DWjuG+CR6ivA5WZXVXtqNxHdrwUl50n7zRSrVKT3qcmn5ng3QzpP66awNcLO4/fGjOfmcvwb3t619e4nxSX11HC4cW0MTYOH4w8"
        "b51RpDYxqjVnVzmm9zbe/j4TWgtLh3tZ5TvmHnW+9IbE9MaWMc80Bulwbx6+saC1p/Bj8kevJ86+U9n7MoS3o0Y56kfK2l3ZRtU4"
        "SrOcuhP3vh2+Y540tsz1TrmXwmmpJGU0rt59fWuLWOPacnxnn0ArqvQukafROmqS0QuZJIzL552s3eukPN2PYB5gqNWbR9N6KYW3"
        "O4M8KA8Wjg+yTHzbo8kenAWm63pM15ue9RWKlFtAI6uold1rvOXN4D0YPpXRJ1bhYSwjxdzU2rt6P9FPdprVcs+l8fRobV2xW6jr"
        "9nN8dWNZ+xYfCIXnmyVpG6R6c48+VxqTxXv9f7X7zr2mZQyxQ0Nsa4PNPAS7rHDkXuPPHYOAWvsrrtqcqcMSPT9z2zq9hbOnXere"
        "cdHA9bsxP2xtJ/GdP+mF0P0m/wBo0z+PUf1a522Yn7Y+k/jOn/TC6J6Tf7Rpn8eo/q15Hb3+Xtv2y7T9C2V9wrda7DQMa+2Mr4ol"
        "9kfJbZmUT62K9pXzsV7TwXOzciwckgUQpWBmJSCiCpQIwVKIUgoZCBSBQUgoEakHCIKlBFgKSraexMFBkIFSikCgRApKtIFBDBSB"
        "wgpBQxLVIOFWDhNAlgKQKqaUwViJYCkCqwUgVCWAqwHKpBTBwhiWApgqsKQViJaCkq0mlBFgKkFBSCgS0FIFVApgrESwKQUAUlCM"
        "FIFVgpZQJYCkCqwUsoIaQcgDlShoR5UoAqUYEeSEsoLAcIIsDlOQgpBUIwUlWpBQxLMqUAVKBHlSCgCkCghgqcoKQUMSzKzKAKSC"
        "EpBQCSBEsUArECc8gqUVIK9cebFngoWLEEFxVLirXKl6yQMpeurtHfudpvimu/PKuUHLrLZbGb3sKfQx8ZXUtdS4/CO/j9IL4233"
        "u0aUnwU12nds3Wc10xfYcTtPij0BTlBuQ1oPA4GQpyv0TJ5AWVLQXOa1oJc44aAMknuAW0dmOxiq15RC7VdcKG09Y6Nu4zelmLfK"
        "3c8GgHhk59C6M0rs401otgfbLdGKlo8arn+yTHz758n1YC5qt1CDwtWed2l3S2tlJ0o/1zXJcF1v4ZObtJbDdU6l6uepgbaaF3Hr"
        "awEPcPwYx4x9eFvXSWxLS2lzHNJTG6V7eInrQHAH8GPyR68nzqNXbbtK6WMkMdUbpXt4GCiIcAfwpPJHqyfMtEat26ap1N1kNNOL"
        "TQu4dVRkh7h+FIfGPqwuf+/W8yPi/wDrW2P/AIqb9H/6fuOm9QbP9M6mZi6WWklfjAmYzq5B6HtwVqfUXRppZd+WwXiSB3MU9c3f"
        "b6A9uCPWCtI2HXepNMyb9rvNZA0nJjMm/G70sdkFbX070mK+Dcjv9ohqmcjPRO6p/pLDlp9RCe81qXkPJl4o2zs7Wzq78ej5S09T"
        "yfl2Xo56mrLg+K6VFHQUcZwZ2Sdc6QfgNGP6WFvDSGybTGjjHLSUPhVwb/2yrxJJn8Ecm+oeteWuXSO0rT24T0MFfWVjhwpnRdVu"
        "n8J5yMejK0prDbLqjV/WQuq/c+3v4eC0RLAR3Of5TvaB5kbtetpLRGLt9t7W/orPvcOfL2cX6dDpDWG17S+jzJFPW+G3Bv8A2SjI"
        "keD+E7yW+s58y0Fq/bxqbUnWQULxZ6B3DcpXEyuH4UnP8nC1ZnuWZXRTtqcNeLPu7P7mrOzxKS35dL7Fw97843PL3Oe5xc5xy5xO"
        "ST3k9qjKOVmV0ZPv4FlZlHKzKsieu2YH7Y+kvjOn/TC6L6Tn7Rpn8eo/q1z9sbon3HanpOFgJLa5krvM1gLyfY1b46TdUDUaZpgf"
        "GbHPKR5i5oH6JXituPO2LZLlF9p6TZaxYVX512GiY+xfZGV8Ua+yPkt0yifWxXtXzsVwXOzei4L2mgdml22iC4m2VNDALf1fWmre"
        "9ud/exjda77w5zjsXim8lu3Yg4s0VtPc0kOFuaQR2fYqhc1eThBuPHT3m2mk5YZrXWWj7hoa+PtNydA+oaxsgfA4ljmuHAgkA945"
        "di/a0JsrvW0Gkq6q2z0MENLI2Jzqt727ziM4G613m9oXstujRf7DovV0YBNdRiGYjsdgPA9pk9i9Po7/AEU2b6HpPJqtQ32nmeO0"
        "s60OB/Jjj/KWiVeXek15T0+JsUFvtcjRGq9M1ejtQVdlrpIJKql3N98DiWHeY14wSAeTh2L8dbO2vWuqve2a6W6ij6yrqpKaKNvL"
        "LjBH7B51+pU7PtnOmp/cvUWsKw3lmBMKKEmKFx7D4juXpB8wWyNZKMW+LXIxcNXg0+DlYvYbQdAy6HrKN0VYyvtNxj66jrIxgSN4"
        "cCO8Ag9xBHoGydV7JtAaKr4TetR3OCkniHVQNDZJ3PBO87LY8BuN3GRzzxU60FhrXJKD18xocFIFe60Ls5Gtrhc5m1wodPW4l81d"
        "MOIZxIGOAzujJPAD2BeqotnWzzVFQ616b1dWG8kHqhVxfY5SBnA8Rv5ye3BVKtGLx9IVBvU04mDlex0vs6rL7rGo07W1MVukoi/w"
        "qWUg7oacHdGRvE9nm4r2tv2b7PtT1Mlp07qytfew1xj8Ii+xSFo448RuR6CeHHiidaMSjBs02CpX6cGnbhU6iFgjiBuXhJpOrzwE"
        "gdunj3Ag8VtG57Otn2lpG2y/6srG3rdBkFLFvRxEjtAY4/ODjjgKlUjHCFRbPBVeiLhR6LoNVyTUpt1dMYI42ud1ocC8cRu4x9jP"
        "b3LzQOFvnaLZW6d2I2C3R1kNbDHcN+Oph8mVj+ve1w/kuHr715HS+zS2yaaZqbVt4da7RM7dp2RN3pZufEcD3HAweAJ4Ba4Vk4uU"
        "ukycNcI1uDlStqVuzKwXyx1t10PfJrg6gbvz0dUzdl3eJyODewHHDjg8c8FqtZxmpcAaaPTUOibhcNHXHVMU1KLfQTCCSNzndaXe"
        "JyG7jH2QcyO1edaexbe0z+591Z8YN/PTrzmh9C2y92quvt/vDbdZqNwY7q8Ole7hyHHA4gDgcn0LWqmN5y5My3eGDwy+61WysvVd"
        "FQ0FO+oq5c7kTObsAk/MCVsS57OtOXXTVxvejb3U1rbY3fqaerZh4bjJIO63HAE8sHB48F+rsWo9I+7FjqPD7h76/s/7G3R1HkyD"
        "nuf93x8rn7ESqrdclyFR1wajqqWegqpqWpjdFUQPMckbubXA4IPrVYK2htLotDsq9QT0dzub9S+FPLqd7R1IkMv2QZ3BwA3seN2D"
        "mq6DZ7p+y2ihuGtL5NQy17OtgoqVm9KGdhcd12PZ688Ed9W6mx3dTWoKkFe+1ToC3Uun/fHpi6uudlZIIphI3dlgccYzwHaR2DmO"
        "YK/XsmzfTtVoG16mut3qaBkkj/CTwc3dD3sDY2hud4lre09vBTqxxkt15NWg49Ca9vb9GWbVGsPczT10kbZ2QiWSqrcB4x5QAw3J"
        "yeHrPYvR0GgNC6iqJLXYdTVj7uGuLOvj+xSEDjjxBkegnhx4olUiuIqLNeaZsFTqm90tpo3wsqane3XTEhg3WlxyQCeTT2Ki626W"
        "z3Ost87mOmpJnwvdGSWlzSQcZA4cF7HZXRzW7apbqOobuz00lRFI3uc2KQEe0Lz+uD/ppqH+Pz/plG83PHmLlk/EDkl7HZhpCh1r"
        "f6mgr5aiKGKldOHU7mtdvB7G9oPDDivIBo67c443sfOneTbRecwKQcL2O03SNDou/U9BQS1EsMtK2cmoc1zt4veOwDhhoXjo2Ole"
        "2NjS57iA1o5knsQmmsoeGgwVIK2U/QeldNRww6rv88N0lYHupqJm91QPY47rs/N5u9fiax0TFYaKju9rrxcbHWktinDcOa7j4rh6"
        "j3cjkBYqom8Dg8llIFbUl2daWttgsV5ut4rKWnraZkkrBh73yOY1wEYDeAGXZznsX5GjNH2PVusLlbYqqtNphgdNBK0tbI7DmAb2"
        "W4/fHsHYse+LGRweDX7WmdOVuqrm2goerEm46R0kpIYxo7SQD5hy7V+xqOx6WtFvdTUN4qK6/RyCORrW4gznxsHd4478r0tPpjTu"
        "kaeOG86srqWuroQZYra47m4exxaHbw588Z7kOegpGsaqEU1TNC2aOYRvLesiJLH4PMZAOPUvshs1wqLXPdI6WR1vgfuSTgeK13Dg"
        "fyh7V6HVGi6XS15tPXVzp7DcC2RtTGPH6rI3scwSGuBB7cjgtkWqk0e3ZzeIqa4XB1hdUg1E7mjrWvzHwA3OXBnYeZQ6mEmhwaYs"
        "dnqdQXWmttHueEVBIaXuw0YBJJPoBSvdnqbBdam21m54TTkB247LTkAgg+ghfueAWOTWNlpNPXC4Oop5ImPqHncmje55B3TujGBj"
        "BxzR1bpuSn13VWWhkqauZ8kbWPqXh0j3PY1xLnYHa48e5W9qR5YHCS2TVaJ0fp17KK/aiqRcsAvZSx5bHnv8V3/ofMvP6u0XLpuW"
        "ilpKgV9tuAzTTsHFx+9IHbxGO9G+mWDy4KnK2PJoTTum6enbqq9zQXCdgf4NSN3jGPOd12fTw7cZX5Gq9EQ2i2095tFeLhZah26J"
        "cYdGe4+zHZx4YUppieQBUqtIHKyIYKnKrSysRLFmUQViGIwSkCqwUgVCPKkFEFSghJAoAqUCLKxQCsQWTnoFJAFIFeuPNizwWZ4q"
        "FiMCFyqerHKt6yQMoeuiujDqVnU3jT0jwJGvFdA0nyhwa8erDD7Vzq5fp6T1NV6O1HQXmiOZaWTeLCcCRh4OYfMQSFy7RtPC7WdF"
        "ceXWjba1+8VlN8OZG2HRz9Ea/u1AIy2inkNXSOxwMUhJAH4py3+SvCZXbm0PRtr266EornZZoxcYmGWgnecYJ8uCTuyRg9xAPLnx"
        "XdLZW2S4VNvuNNLS11M8slglbhzHef8At5HsX1O5/aqvrdU6jxVhpJc9NM+nn5z521bF21Vyj5EtU+z65Gw9n+2q7aCs8tqjoaau"
        "pN90kIme5hic7nxHNpPHHzr8TVu1DU+sy9lxuL2Ubjwo6b7HCPSBxd/KJXjMrMr7apwUt7Gp56OzbSNZ3CprffP64egWcehTlDPn"
        "WZWZ2jysyhlZlRDysyhlZlRDysyhlZnzqIeVmUMrMqIeVmUMr1WgNAXfaLfo7Xao8MGHVNU8fY6aP75x7+5vMn1la61anRg6tV4i"
        "uLM6dOVSShBZbNxdFPR0lXe7lqmeM+D0MZpKYkeVK/G+R+Kzh/LX5227UbNQ7QK5sDw+mt7W0THA8CW53z+WXexbq1derVsR2eUt"
        "ms2GVpiMNEw4L3PPlzu9ZJ/GIHILk4OdI4ucS5zjkknJJXgrSpLaN7U2jJYj5Mepc/rm2eqqwVpbwtE9eMuv67D6o+xfZEvjjX1x"
        "r6czmifUxXNVLFc3ktDNyLAt27EeOiNqPxa36KoWkmngv3LHq686corpRWys6ilusfU1bOqY7rWYcMZcCRwe7ljmuetBzhurze82"
        "05bryzb2maKbXuweqs1Owy3Gz17TAwcThzgc+yST2L9faFVxUm1LZvpumP7Gs76UADsLpGtA/Jjb7VpTSuvNQaKFV7hXA0gqt3rR"
        "1Ucgdu5x5bTjyjyXz1mr7zcNSM1HU1pkvLJI5W1BjYMOZjdO6Bu8N0cMYXP4PLfb5a462bO+LdS5m4L1daWzdJnwute1lM2aGNz3"
        "HAaX0jWAk9gBcOK9NrbWW0Cwamq6Kj0fbq+ifITS1LLfLKZGHlvOa/G92Hl7Fzjfb7cNTXWoul0qPCK+o3esl3Gs3t1oaODQAOAA"
        "5L0dq2tazs1EyipL/UNpmDda2RjJS0dgBe0kD1olbNqL0eFjUyVVanq9tN31VNDY7fqals1M7qzUwx2/e348gAteC44weHDgcHBO"
        "F93SXJ9+tsHZ7nN4f/yyLT9zulbea2WtuFVLVVcpy+WVxc4+tfoal1beNY1sVbe6zwqpijELH9UxmGAk4w0Ac3FZxouLi+jPtMXP"
        "KfnNr7LoHal2Uay0zb3t92XyCpZGXAOkZhnAeuMjzbwzzXj9G7M9WXTUtNTR0VytBifl9fJA+PwfHaDwye4A5Xi7Xda2zVkdZb6q"
        "alqo/JlheWuHrHYvVXLa1rS7UT6Oqv8AUGneN1wjYyMuHcXNaCfah05xb3MYYqUWlnke82caKtd01Xq6S6S++SayszCwuP7Mf42T"
        "xJ3sFoaMkjxh5l7bZ5dpLnqaBv1M6GwRRb/7PdTiKRh3XeK0mNpc48iB2ZXNVkvty05XsrrXWS0lU0YEkRxkdxHIjzFfv3Hafq27"
        "VtFWVd7qHz0L+sgLGtY1jsYzutABOCRxB4EjtWupQlJvUyjUSPZ2+Yae6QD6m5xPpoJbnUFjpmloLZDI1jxn97lw48l8G03QWpI9"
        "c3aaK1VtZBXVDpoJqeF0jXNcchuQDgjOMHu7l4jUmqrvq+ujrrzV+FVUcQha/q2MwwEkDDQBzcfav3KHazrO3UDaKnv1QKdrd1oe"
        "1j3NHcHOBcPanvc01JYzjAb0XlM2VtCslZp3YZpu23AbtZDWtMjc53C4TODfUHAepUautVZrTZRoyssUL6xtri6ipp4BvPa4Ma0n"
        "dHE4LD58OB5LVNw1pfbrZIbNW3B9RbopnVDY5GNLusJcS4vxvEkvdzJ5o6f1be9Kyvks9ynpDJ5bWEFjvS05B9ixVGSWc6pti5r0"
        "G29iljuGkn33Ut7ppqC1Q0ToyKlhjMh3mu4NPE+Tjzl2AtHB3E8ML9/UGvNR6rjbFd7rPUwtORFhrGZ791oAJ9S88tkINNylxYNp"
        "rCNy6Z/c+6s+MG/np192iLBa7Ts2j1M3TLdSXWed0bqdzd8QtDi3ycHsAPLPjDsWp6TVd2o9PVen4avctFXJ1s0HVsO87xeO8RvD"
        "yG8j2L6NO62v+kxKLPc5aVkpy+MBr2E9+64EZ8+FrlSk00nxeTJTWh0Np6Wou2itWFujabT8s1FIyKCnhDJan7HIASwNBxk4GRxy"
        "cLT+xuN8G1CzxTMdHLG6dj2PGC1whkBBB5HK/Gptpeq6W71F1jvU/h1QwRyPc1rg5o4gbpBaAMnGB2nvX4wvtxben3ptU9lzfO6o"
        "M7MNPWOJJOBw4knhyWMaMkpLpFzTx5j9/aHbK6n1hqGplo6iOnfXzFsr4nBpBeSCDjHFb11lq6/wW6z3fTFlobtaaunBc51O+aSJ"
        "3cQ1wwOzlwIOVoe+7SNTantxt91ufhFIXB/V9RG3iORy1oPzr59P651DpaN0Vpuk1NC45MWA9me/dcCM+pEqUpJZxlCpJN4Npap1"
        "LrabQFVU3a0Wa3W2teIHQ9VJFUHOCHBpf5vTwzjHFfBezjo/6a89e/8ATnWtr9qq86omZLd7hNVOj8gPwGt78NGAPUFM2qLrU6fp"
        "rBLV71ppZDLFB1bBuuJcc72N48Xu5ntUqTSXXkt491sc0zbL9VXmruNJ4e+3QNkgos465x3uzt8kDjw8ZbF0HdJLjqKEfU8o7HFH"
        "v/s10Ajew7p8VpLGkk8iB2ZXPVnvVwsFa2sttXLS1LRgPjOMjuI5EeYr9uv2jaoulXR1VVeJ3T0b+shLWtYGOxjO60AE4JHEcie9"
        "FSlKTbGMkj3mnaWel2+PE8MkXW1lZIzfaW77CyXDhnmD3rwOuT/ppqH+Pz/plTPr/UVVfqW+y3DeutJGYop+pjG607wxu7u6fLdz"
        "Havxa6unudbUVtVJ1lTUSOlkfgDec45JwOA49yYwaeX0E3obL2DVcVPraWOR4a6oopI4wf3zt5jsexp9i/Ah2e6hfqH3OfbKmMNm"
        "w+ofGRE1gPF+/wAt3HHOV5uxU9ZWXmgpqCUxV00zGQyB5buvJwDkcuK3XW6Q2pXajFDXXqmfRuw17RIGlze4lrASPSVhN7ss5Wor"
        "VH4G33/4xofi9n0ki17p+tit9+tdXOPsNPVRSv8AxWvBPzBe627VsFVrSBsMrJDBRMjk3TnddvvOD58OHtWs00l/bSKT1Ojtdan1"
        "TZ7oyS02GhudqqY2vhqW0r5nHI4glrvWOHIheO2h3nVUmlKCK+UFpo6Wuk32QwNeyeNzc82lxxwPqzg4K8PZdf6k0/TClt92mip2"
        "+TG5rZGt9AcDj1L8y7Xu4X6rNVcquWpnIwHSHkO4DkB5gsI0t1rgZOWTZO0840Xs/HZ4CPookdg5/wBL63+IP+kjXgLpqW6Xqit9"
        "FXVPXU1uj6qmZ1bW9W3AGMgAng0c88llg1Jc9MVj6u1VPg9Q+MxOduNflpIJGHAjm0J3HubpZ1yZbKWO4XukpJ5OriqKlkT5PvQ5"
        "wBPzrdF9ipdL3OO02vZ3DcoQxu7VSQ9Z1hI4+MWnl25K0NvlxJPMr1Ldo+qW0HgIvNR4Pu7nENL8fj43vnVODbRJmwts1NO+xaYm"
        "ZRNihhieJG043ooMtjAaCOAGeA9C/P0xBLVbGdRxQRPllNaCGRtLnH9pPIeYFeDk1nfJrD7hyV7n2vDW9S5jTgBwcBvY3sAgdqiw"
        "avvWmRK21V76dspBe3da9pPfhwIysVTajgc6n16Sp5qXWdijnikik8NhO7I0tPljsK93dLhT2zbn4RVOayASRsLnHAaXU7Wgn1kL"
        "XFZqi63C9Q3ipqt+5QuY5k3VsGC3yfFAxw9C+e63esvlwmr7hN11XNjfk3Q3OAAOAAHIBTi28voLJ7LXukL4zVtxlZb6uphq5nSx"
        "SwxOeHBxyBkDgRyx5ldcbJVaNfpWou90fLieOc25xJ8HY1wJxxI83ADjnuX4Vv2h6ntlK2mprvMIWjda17Wybo7gXAkL8KvuVXda"
        "p9VW1ElRUP5ySOyf/wDEKMuDE2TtU03dKzUjrpR0s1ZQVkUZikp2GQDDQMcPRnz5X01NHNpjZDU0V0aYay41QfDA/wAto3mHiOzg"
        "wn1heGtGudQ2KmFNQXSaKAeTG4Ne1voDgcepfnXS93C+VPhFxq5ambGAZD5I7gOQHoRuvRPkOT5AVKGSpyswHlSChlSCgSzKnIVe"
        "VIQZFikFAFTlBDykCqwVOUEWZUobykFQiWLFiBOewcqQUEl6082MceCjKwFYoiCq3KwoOGUomUPC+d4X0uCpeFsizWz2uzLalctn"
        "FycWA1VoqHA1NGXYz2b7D+9eB28jyPm6Ju2m9Bbf7KyrilDq2FmG1UGGVdL+C9p5tz2HI7iuO3NV9uuVbZ6uOrt9XPSVUfkywPLH"
        "D1hfMvNlqtUVzbzdOqua59f115OuhebkO9VY70HyfYbC1T0X9ZWaV77OaW90mfFMLxFNjzsecZ9DivBz7Jtd0zy2TSF6BH3tK5w9"
        "oyto2HpJautbGxXBlFdYx++qIyyQ/wApmM+sFesh6VnijrdKjf7errjj52LKG0tuUVuzpRqedPHavcYSstm1HmM5R83HsfvOffqX"
        "62+CN8+RP/sWfUv1t8Eb58if/Yuhvrq4vgtJ8u/wKfrq4vgtJ8u/wLPx1tj/AKq/2XxDxdYfrP1fI54+pfrf4I3z5E/+xZ9S/W/w"
        "RvnyJ/8AYuh/rqovgtJ8u/wKfrqovgtJ8u/wK8dbY/6q/wBl8S8W2H6z9XyOd/qX62+CN8+RP/sWfUv1v8Eb58if/YuiPrqYvgs/"
        "5d/gWfXUxfBaT5d/gV462x/1V/sviXi2w/Wfq+Rzv9S/W3wRvnyJ/wDYs+pfrb4I3z5E/wDsXRP11EXwWk+Xf4Fn11EXwWk+Xf4E"
        "eOtsf9Vf7L4l4tsP1n6vkc7fUv1t8Eb58if/AGL7aHY3r+4PDIdJXVuf300XVNHreQFv366eL4Lv+Xf4F81V0pp3NIpdMQtf99NV"
        "ucPYGj86ntnbL0VtFen5l4u2euNZ+r5HntGdFK61csU+q7jFQ03AmkonCWZ3mL/Jb6t5bavmsNGbELELNZ6WA1rBllvp3ZeX48uZ"
        "/Ej0nxj2DC0XqTbrrLUcb4BXMt1M8YMdAzqyR535LvnWuiXSOc5zi5zjkknJJ71x1LK92hJS2lU/pX4I6L0/TfnOiFe3tU1aQ1/M"
        "+P19YP2NSamuWr7xPdbrOZaqbhwGGsaOTWjsaO7/ANV8MY5KljV9MbV9ZRjCKhFYSOTLk8vifRGF9ca+aML6mBaZG2JexXN5Kpqs"
        "C0s2oYSBQSBWAiBSRUgoEQKlFSCgyECpRSByoRA5UgoJIISkFEFSgRgpAqsFIFYkWApAqsFIFBkNSCiCpQQkwUFgUJYpBRBUoEYO"
        "E1UCkCsRLAUgUAVIKGJYCkCqwcJgoIsBUgoAqcoMslqkHCrBwnnKBLM5Ug4VYKWUYIsykCqwcqc4QJYkCgHZUgrEiwFIFVZSBUJY"
        "CpQykCjAjBSDlWpBQxLMqUQcqQUDkYKnKCkFBFm8pDlWEkCPKkOQBUqEsypBVYKWViQ8qcqsFLKDIeVOUAVOUMhgpKsFSHIEsBWI"
        "5WKI5+WAqAVK9YebEpyiCpUJJRIUrFIipwVThlfQ4KstWSZi0fM5qrLF9RagWrYmYtHzbijdX0FizcTkxwfPuqdxX9WsDFZHBSGq"
        "d1X7incVvFgo3VO6rtxTuI3iwUhpWbivDFO4jeHBRuJBquDFPVo3h3SoMVjWqwRqxsaxchSCxi+ljVDGK5rVrlI2JDY1fSwKtgVr"
        "RhaWzYkWNVjUAkFrZsGun9gGrNGWfR8lNNW0NsvQlJrX1krYjUeM7qy1zj4zQ3hgcjk4G9l3L4KlaK9FVo7reDZTnuPKO9/qg6R+"
        "FNj/AJwi/WWfVA0l8KbH/OEX6y4JBSBXF4uj+Y3+FPoO9PqgaS+FNj/nCL9ZT9UDSXwpsfy+L9ZcFpA5R4uj+YfCX0HeX1QNJfCi"
        "x/L4v1lnv/0l8KLJ8vi/WXBqSvF0fzF4S+g7w9/+kvhRZPl8X6yz3/6T+FFk+XxfrLg8HCSPF8fzD4Q+g7u9/wBpP4UWT5fF+ss9"
        "/wBpP4UWT5fF+suEgVIV4vj+YvCH0Hdvv+0n8J7J8vi/WWe/7Sfwnsny+L9ZcKLEeAR6R8IfQdx1+vNGOoaoVWobJPSmJwli8Kjl"
        "6xmDlu4CS7IyN0A55YXF12loprrXSW2F8NufPI6mikOXMiLjuNPE8QMDmfSV+eCkt1G3VLOGa51HMsBUgoApAreYiCSKkFAiBSBQ"
        "UgqZDUgogqUChgpAoApLERgpAqsFIHKBLQVIKrBSBQJYCkCqwUgUYIsykDlVgqUGRYkHIBykFBFgKQKrUg4QJZlSChlIFBDBSBVY"
        "KQKBLMqcqvKQKBGCkCq8pByBLAVOUA5TkIIsysyhlJAiUgogqUCLKQKAKlQ5LAViGVOViJYCpBVeUg5AjU5QDlOUMhhyxEFYoTQK"
        "kFEFSvWHmxKQUQVKCEsWArFCYiQnhZhWSKi1EtV2FmE5DBRurNxX7vmWbqslgo3FO4rtxIMVvFgo3MqdxX7iQajeHB84YkI1duJb"
        "it4cFHVqdxXBqW4jeLBRuKQxXhincRvDgqDE2sVgamGLFsUgtYrWtWBqsAwsGzNIlowrAiEhwWDMkMKUUliZEgpAoJAoISkFQDlY"
        "hiMFSiCpBQI1gOEQcJIESkFEFSgRKQUQVKBGCpQBSBQyECpBRUgoEaQKAKlAlgKSrBTBQIgVKKkFAiBUgopIIQKQKrSBQZFikHCA"
        "KSCGDlIFVgpZQOSwFIFVg5SygSzKQOVUCkCgSxJei0NdtNWi7TT6psMl7t7oCxlNHVPgLJN5pD95pBOAHDH4XmW3NvFk2eaFijsd"
        "n0jLT3mvoYa2C4eHzPbAHSkOaWOcQSWxuGfwvMt8LffpurvLTlrn3czTKtuzVPdevV8TQQdhLK3wNKbO9nGjNJXHV9nuF8uWpafw"
        "v7BUuiZTRENcMBrhk4e3gc5OeXBeK207P6PZzrMW63TyTWyspY62m605exjy4bpPbgsPqwqraTpw321pjK5rPDJQuIzlupPn6ccT"
        "XwKlV5W2+j3pGxa01ddaPUNB4dRUtqlqmxdc+Lx2yRAHLHA8nOHdxWmjSdWapx4s2Vaipwc3yNVAqQVvaLTOz3aPobVl201Yq3Tt"
        "z05T+FESVb54pm4cd0l5PE7jhwxxI58Qvi0xpLRmmNl1v1vq+21l6ku9W+mpaKCoMLI2tLwXEtIOcxu7e0cOZW7wKWdJLGM51xjO"
        "OjPHzGrwqOODznGOfT1e00wCkCtza50nozRN40bqeK2Vdw0fqCkkqTaZqhzJGODBhvWNOQAZGHmfJPEgr1dfRbJ6HZpa9bnZ/UOg"
        "r600QpRdagOYQJPG3t/B/az2dqVYyblFzScdefDTXRecndrEWot56uPRx8xzgCsyvputRSVN1rprfTGkoJZ3vp6dzy8wxlxLWFx4"
        "nAwMnnhfICuJrDOtPJYCkCugb/bNmmgtJaHq7roqa51t8tcVVLLHcp4vH6uMuON/HEvzwwAtd0FpsG0baVabVYLdJYbTXvZE6J07"
        "p3MwCXuDnE8SBwHeumpaODUN5OTxos519GPaaIXKmnLdaSzrpy9OTwakFb7uNBscpdS3LSFdabrZ5aN0lP7tyVL3fZGZ4mPJGCRw"
        "O7xyOWV5fZXoGxXyXVt3v081XYdMQGZ8dISx1Vnf3cE8QCIz3HiOI4qdlLfUIyTbzz4Y45BXUd1zaaxj054YNWr9rTOlrxrC5i22"
        "SifV1m46QsDmsDWjm4ucQAPSeZA7V7fVlNs5vmjJL3phstjvNLOIn2ipqTMaiM4G+zeJPDezz/eu4civfbAtFWiv0fV1V4lrYZdQ"
        "Vj7ZSmnrJoA8Nhc87wje0PHB/BwI8XHamjZOpWVLKaeuU/lp0aoKt0oUnUw0+Gq+vec71EL6WeWF5YXxOLHFjw9uQccHNJBHnBwU"
        "Mr3+yjSVFe9q1t05f6Tr6XrKmKog33My6OKQ4y0gjDmjkexbUtmyDTB23T2WW3GbTNXavD6ODr5RunLWnxw7eOHB/AntWNGxqVoq"
        "ccYct30+rgZVbuFKTjLksnNuVIK3Ps9sGjYNkd41dqTTz7vUUVz8Fa1lXLCdwthwPFcBwLyeWV4nWt+0bdqWlZpjSs1lnY8maSSt"
        "kn6xuOAw4nHFa6lruU1OUlqs41z7se02Qr783FRejxnTHvz7DyCxdA3m1bM9E6Y0PUXnSNTW1F9tsVTPUwV0zXMd1cZe7c38EkvJ"
        "wMBa62waFptn2sHW6hnfNb6mnZV05k4vaxxI3Se3BafVhNeynSi5Np4xnHLOq5IxpXUakt1JrOcZ544nhQVOVXlIFcR1jBWIrFYI"
        "0GpBRBUr1p5sSQOUQVixESSKwHCBGFKKQURinCxSgjAFOFOFihMAU4WAKcLHImAKcLAEsKEjCkBSFOFjkTN1SAsAUgKyRmFOFIUo"
        "EwDCQCwKQECSOCSwKQVixJHBJFSChiIFSipBQI1igFSgRApKsFIFBCSBRWBAlikFAFJAiUgogqUCJSCiCpQIkkVgQIwVKKSCJBSB"
        "QSBQxEk09iIOViCLQVKrDkwcoMhrEUkCJSCiCpQQwUgVWCpRgSxSCiCpQIwcJZVYKQKBGkCq0gUCfVTU09W8sp4ZJngbxbG0uIHf"
        "gLfHSqpKh2sbDOIJTAyxU7XSBh3WnrZuBPIcx7Vp/R+uL9oG5y3LTtf4FWywmnfJ1McmYy5riMPaRza3jjPBei1Jtv15q+y1VmvV"
        "98KttVu9bD4JAze3XBw8ZrAR4zQeB7F1U6lKNGUJN5eOWmnpNE4VHVjNYwu30GxtstouF80BsgntdDU1sQs7KcupojJiTq4RunA4"
        "HII9R7l8XSre0a/s0G8DLT2SnjlaDncd1kpwfUQfWvH7NNs+pNndZQwQXCaXT8c4fPb3hrmuYT44ZvDLCeJ8Ujjz7V8m1+vst319"
        "dLpYLzJdbfcHCoEsrJWvicecZ6wAkNxwxw3cDsW6tWhOjKUeL3crqXLp7DTSpThVjGXBZw+t8+g8QDlb46KDzFr2+va0Oc2xzkNc"
        "Mg4lh4ELQi9Do/W990Hcpblp+u8CrZYTTvk6pkmYy5riMPaRza3jjPBcdrUVKtGpLgjpuKbqU5QjzOhqO+3DaZsg10282OHTkNqh"
        "FVBLbIn0sFU8Bzurewkh/FjR2+UORxnzN+oaq7dGLRHufTy1Ro7nOJxAwvMeZJ8bwHLym+0d61tqra9rTWtB4BfL9PU0WQ4wMjji"
        "Y4jiN4Ma3ewePHK+fSG0rVWhWTM0/eZ6KKc7z4g1skZdyzuvBGfPjPBdcrunJ4llpxw3pnjnhnHtOeNtOKysJ5zjXHDHE2dt2hko"
        "Nn+yOgqWOhrae2SmWB4w+PLYMZHMcj7CjqA/+6zpQ/8A11/5qlaf1Fqe76tub7le7hNXVrwG9ZKeTRyAA4AcTwAA4r6ajWN6qtK0"
        "ml5a3esVJOamGm6pg3ZDvZdvgbx8t3AnHH0LTO6i6lSWNJRwvZx9RsjbyUIRzweX7fifjZSBVaxcB2HV+tdcXPSGhNmTLfpu0XgV"
        "NkhL3XChdUGLEUWA3DhjOfmWkIp9Q642lU1RbaOks+oKuVj6eGlb4LFE+OMbpaHE4zuZ58SfOvqtm3vaFZ7bR26i1B1VFRwsghj8"
        "Dp3bjGNDWjJjJOABxJyvL6g1pfdU3xl8ulxfNdmBgbUxsbE5u55JG4AAR3jivo3N1CrhpvTGmEuC5PL9xxW9vOnlNLnrrz82DpHT"
        "F1u20bVM2jNouh6WonjZJHJd4qYxSQljTh/WcsEjALSAcjgQvKbI7cBpfbPZLe41k4pBHTtjGXTtZ17ctA55y3l3ha7rtt2v7lbH"
        "22o1NVOpXt3HBrGMe5vaC9rQ4+1eW09qa7aUuTLjZa+airWAt6yI8weYIPAjgOByOCyle09+MtXjOW8Zw1jHnx5zFWk92S0WcaLO"
        "Mp59GT9o7Or9Fo6q1XUUwpbXTzCDFQTHJI4kDxGkeMPG5+Y9y6J8GsGj9ObLKC76sisVXaQy7PpX0j5jUukOXAuaRuc5G5OefmXO"
        "Wq9o+qdcNgbf7xNWxQO3mRFrWRh3fuNAaT5yO1fFqnWF61rcmXG+1vhdXHE2Br+rZGGsBJDQ1gA5uPZ2rTSuaNDedOLbaXHry+D0"
        "5G2pQq1sKbxx4dWFxXWdB0lh9wOlrTNY3dhrnT1sfn6yllLj+Xvr3uymdmobxVVbiDW6duNytr+8wTSiVhPmDmloXKsm1LVk2oLX"
        "f33beu9rgNNS1Jp4sxxlrm7pG7h3B7uLgTxR07tP1XpS4XSvtF2NNVXWTrat/URPErsuOd1zSBxc7kBzXVR2jRpTzh4cm+XPGOfS"
        "vUaKtjVqQxlZwl6s9jNw7Lr7Vac6P2orjR22juU8d6wKasgM0bsspwSWAgnGcrVe0DWVy1eLe64adtdnFJ1gYbfROp+t3t3O9knO"
        "N3h3ZKo0ntV1doa3S26wXbwOjlmM74/BopMvLWtJy9hPJreHLgq9W7TdU67pqan1BdPDIaZ5kib4PFHuuIwTljRnh3rkq3UJ0I01"
        "JppJYwscenOfYdFO3lCs5tLV5zl59WO06VFw0qKXY7adSWGnr3XG1wMp6yaQ7tO/qot1pZjDg5xaOJ4edc/bY7le6/aLehfwxtbT"
        "SdQxkYIY2IeRug8cFpDv5S87eNZ3y/U9mp6+vdLFZYWwUIbGxhgYA0AAtAJxut4nJ4I6o1deNaXIXK+VTaquEYi60QxxktGcZDGg"
        "HnzPFN3exr03Baaro10xr6eHEra1lSmpPXj786dp+TlSCqwUsr5Z3jDliAKxAmhkgcog5WL1p5sSSKwHCGQgUkVIKGIgVIRUgoEY"
        "KSAKQKiECpRSWIiWBEJIESkFEFSgRKQUQVKBEkCgCpQJYDlYiCkgiQUgUEgVCMFSipBQIgVKKkFYihAqUUgcoZCBypBQSUIlIKIK"
        "lDEYKlAFIFAiBSBQUgoIakFEFShihJIrAsREEkVIKhECpRUgoEaxQCpQIgUlWCkCghJAorAgS0HKQKqBwrECJSCiCpWIiUgogqVE"
        "JIFELECWKQUEgUGQ8qQUQpBWIjUgogqcqZDBU5wgCkCgSwOypBVaQKBLFgOEAcJZQQ8qQ5EFSgSwOSyqgUgUEMFIFVqQUCWrAgCl"
        "lBkMFJVByQcgiwFShlSHLERgqUMqQ5AjysyjlSFEMOU7yrCQKmJYCsRBWLETQ6SKkL1rPNkg4SRUhAiBUoqQhiIFSiksWRIKQKCS"
        "hGCpCISCiEpBRClYiJSCiFKDJCUgqAsQQkgisCBEDhIFFSECNYFAUoIQKSASCGIgVKKSGIgcrEQkgRLAcKApQIkggFIUIkgUVixI"
        "YKlFJQkgpAoJLEhBJFSEMUIFSipCDIQKlFIKYkgpAoJIISkFQOSxAjBUoBILEhApA4QUhQotUgqsFMLERJBFYECJTlQsUIgUggEg"
        "hiNSDlEKUMhgqUAU0CIFIFVpIEsWA4QB4poESkFEKViIlIKIUqIeUg5ALECWgqVWkEYEYKQKCnJQI1IKGSpBRgSwFShlSCghgqUM"
        "pZWIjCxAFLKBGpBQBWZUJaCsQBKxGCP/2Q=="
    ),
    "mercado_aviso": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQAAAgICAwEAAAAAAAAAAAAAAQIAAwcIBAYJBf/EAFkQAAEDBAADAggFDgsG"
        "BAYDAAEAAgMEBQYRBxIhEzEIFCJBUWFxgRUyVnWRFhcYIydicpKUlaGxstI0NzhCUlOCs9HT4yREdKK0wygzY6QlJlV2g+GTpcH/"
        "xAAbAQEBAAMBAQEAAAAAAAAAAAABAAIDBAYFB//EAEARAAIBAgMDBQ4FBAEFAAAAAAABAgMRBAUhEjFBE1FhccEGFBUiMlNygZGh"
        "sdHh8CMzNUKSNFJU8eIlQ2OCwv/aAAwDAQACEQMRAD8A1ZRBQUXnz6YygKAKKiGUQBRQIyiUJkEEFFKmQIQUUqIKBCCmSogoIKZK"
        "oDpRDIgoKKEZEFBRBDIgpQUUCMogCighlEoOkyGQwO1EqZAhBRSogqYjAopUQUEMCiClTKIZRAFFAjA6TJQiChkMEUqYIIYJgUgK"
        "YIEcFMkCYIEsBTBIEwQI4ThVhOEEWAp1WnBQQwKtHUKoJwUMRwnaUgTBAjpwUgTBAjjvTApGlMghwikaeqdAjBMkB0U6CGB2olTI"
        "JDBEFImChHBRSogoIKZKiCggqKKIEiIKCihHBRSogoIKgKiiiGRBSgoqIZRRRYiEFEHSVMFEMogCihiQJkqIKBCoooohlEAVEEYM"
        "TJUQV6M+UFMEqiiGRBQUUQyIKAKixEZRAFFQjKIAooIYKJUyGIQUUqYHaCCCilRBUQQmSogqIKYJVECMiCgogRkQUFEEMoDpAFFB"
        "DKIAooEYKJUyBCCiEqYHaiGRBSgoqIYJkqIKxEYFFKiCoh0zSkHcmHegR04VYKZp0UMSwdyYd6UFELFkWIhKEwUJamHmVYKsBQQ4"
        "ThVp2nYWJDtKcKsJ2lRkMDpOO5ImBQxHHenVYTBBDBOCkCYLERk4KREIZDqA6QBRUQyIKUFEKEsUShMsSCCilTBRBBRSogoYhUUU"
        "QJAdJkqIKiGBRSpggSIgoKKAZMlB2iCogqKKLERkQUoKKhGUQBRQQQUUqIKBCoooojBgKKVEFejZ8oYFFKiCgggpkqIKiCmSqA6U"
        "QyIKCixEZEFBRQjKAoAooIZRAFFAjKJQdJkEEFFKmUQQUUqIKGIwKKVEFRBCZKiCgQogoKIIZEFBRBDIgpQUUGQyiAKKCGRBSA6T"
        "KIsCiAPRFBBBRShMgR2ojvSNOinCGQyYJUQdIEsCcJAmCBHTNKUIhBFg7k7Sq2nonChLUQlaUwWJDhMEgOk6BRYDtEJAnCBGHcnC"
        "QJggh0wShEFQjohAKArEhkwO0qIWIhRBQUSRYEQUgKZBDKIAooEZRAFFRDA7USpkCRRRRAhBRSogoZDqJQUyhImSqA6UA4KKVEFB"
        "BRBQUQIyZICiFCMoooghlEqiBMGAopUQV6Q+SMCilTLERgolTKIIKKVHmUQwKm0m0QVWIfekdqvam0WEs2jtJzKcyrEWbRDknMpz"
        "IsNyzaIcqw5TmRYrlu1OZIHKcyLCWgqbVYcm5lWIsBR2qg5NsIsJYCiqwU4cghgUUqIKGIQmSogoIKZKoEEMiCgogyGRBQB2ogiw"
        "Jgq2lMohkyVEFAjBMCkTIIcFFKEyGI7TpOqwnBQyQ4KYJAnCBHCdpSBEd6GJaO5O0pGohBFiYFKER3IEtCYFVtKsCCGBTJAUwWIl"
        "jTtFIDopwdqEdpRSA6KcIZBBRCVEFYiOogEVEROCkRHeoR0QUFEAMiCgFECMoDpAFFRDKIAorESKKKKEZEFIEyCGUQBRUQQUUqIK"
        "iHCiVMgSJgdpVEEOCilRBUIVFFEEYLUUUXpGfKCCiEqYIEZTekAUCUWIYlDaXaXmURZzIcyqLl3PC+GOR50RJb6QRUIOnVlQeSIe"
        "oHvcfU0FYVatOjHbqySXSZU4SqS2YK7Oo86nMtmLN4N1ioYRNerrV1jm9XCHlgiHvOz+kL6TuH3CKh+1zPtYeOh7a7Hf7a+M8/wr"
        "dqUZT6l87H0FlVa15tR62arc6POtp/qL4O/1tk/Op/zFPqM4O/1tl/Op/wAxXh2n5mf8fqXgyXnI+36GrAejzrab6jOD39bZPzqf"
        "8xT6jOD39bZfzqf8xHhyn5mf8fqPgyXnI+36GrXOiHraT6jOD39dZfzqf8xH6jeD39dZfzqf8xXhyn5mf8fqXgyXnI+36GrXOiHr"
        "aT6juD39dZfzqf8AMU+o7g9/XWX86n/MR4ch5mf8fqXgyXnI+36GrnOiHraP6juD/wDXWX86n/MTN4YcLbx9ron0hld0Hil05nfQ"
        "XH9SHntJaypTS6vqKyyb3Ti/X9DVzmTB6z9kPg2MDHSWG7vEgGxT17eh9j2jp72rCeR4vd8SrjR3ihlppTstLhtkg9LXDo4exd2E"
        "zDDYvSlLXm3M5q+ErUPzI6c/A4AcmDlx2vVgcuxo50y8FMCqWuVgKxEsCiUFMsRCCilRBUQwKKVEFYigpkqgKhHCYFIEyCHBRSog"
        "qIYFMCkTIYlg7kQkaUyCHCdI0pgUCh2lOFUO9WNKxEcFMCkTBDItaeqdVBWAoEcFOCqwmB0UCWDvTtPmVaYIIsTBICmCBHTApAmC"
        "GQ4TApAmChHUQBRWJDNKZVpwdqEKiiiCHBRSApgUEFMlRBUSCmB2lUQIyIKCiiGUQBRWIkRBQUUIyYHaQFFBDKKKKIIKYFImUQyi"
        "AKKGJAUyVEFBDAqIKKEwWmSgogr0Z8oKiiiCCShtQlI4qsQXOVZdtBztruPC3CzneYUlvkDhQRA1FW4eaJutjfpcSG+9YVqsKNOV"
        "We5K5lThKpJQjvZ33gzwaGSNiyDIInfBO901Kdg1RB+M7z8m/wAb2d/buI/HqgxMvseKwU1VW047J0/KPFqbXTla0fHI9A00evuR"
        "498RziVrgxWxvbTV1VCO1dD5Pi1P8UNbruLtaHoaD6QtVtgdNdFwZRlEs3l4QzBeJ+yHC3O/vXqsjqx+PWAXeuF8r90uxfenWfey"
        "HMb9lc7pbzdqqsJOwx7yI2+xg00fQvhhrR3NaPcl2pte7p04UoqFNJJcFojzM5ym9qbu+kbQ9A+hTQ9A+hLtTa2GI2h6B9Cmh6B9"
        "CXam1XIbQ9A+hTQ9A+hLtTaiG0PQPoU0PQPoS7U2ohtD0D6FOVoIPKNjz6S7U2q5HdsT4rZXh0kYobpLNSN1ujqyZYiPQATtvtaQ"
        "tkcTzvF+NVmmtFyo2R17Wc0tBM7ZH/qQv7zr0jRHnGlpxtcq3XOrtFfTV9BUPp6ymeJIpozpzHDz/wD68687m3c7hsfFzprYqrdJ"
        "aa9Nt/XvPrYHNq2GezJ7UOKfZ92Mi8SuHNZw+uwYXOqLVUkmlqiNb13sd6HD9PePV0xj1thYblbuOfDWWKqbHFWuHYztA34tUtG2"
        "yN+9O9j1EhapV9DUWm4VVDVMMdTSyuikafM5p0f1Lz2W4qpU28PiVarTdn09P318T6uMoQhs1aLvCWq+QzXK1rlxmO2rmlfRaONM"
        "uCcFVtO0wWBkOogCisRGUSpkMggopUyBCCnVacHohiEHSZKiCohgUwSJ2naCGCYFIEyBHB0U6rCcFTIYJwddUgTBYiWohICnCBHB"
        "Tg7CrCZp0UEWtPVMq04O0MSwFMFWE4KCLAUwSBMCgUOmBSBEIEsTAqsFMgixEFICmQIyIOkoKKBLAdqJAdJ1AREFBRAjg7RVfcnD"
        "tqIYFFKiChiEFMlRBQQUyVQIIZRRRAkRBQUUIwOkyUIgoIKgUUUQyIKUFFRDKKA7UQIQVEFEEYLTJAUQdL0h8ocFQoKbQICUjiiT"
        "pI4psAjitovBoskdBit0vcwDX1tR2QefNFENn/mcfoWrTitt+HLjQeD+Zo+jxb66XY/pbk6/oC+H3RN96xpr98ku3sPpZSly7m/2"
        "ps1dzLI5csym7XmZxJrJ3PYCfixg6Y33NAXw9qth0xo9ACba/QqVONKCpwVklZdSPKzlKcnOW96jbU2l2ptZmNhtqbS7U2orDbU2"
        "l2ptRWG2ptLtTaisNtTaXqptRWG2ptLtTaisNtTaXam1FYzJ4N+SPtWdutTnnxW8QOjLSenasBew+3QcPeub4RFkbbM6ZXxt1HdK"
        "Zszj6ZG+Q79TT71jvhdO6n4kYpI06PwjE33E6P6Cs1+FDEAMXl15X+0M36vtZXhM3gqOeUpx/wC5B39V/kj02Bk6mWTjL9ktPXb5"
        "swExy5LCuHGVyGFd0kcyOS0qxpVTSnHetTM0WIgoKLERkQV2jBeHGT8Sq6posXtZuFTSxdtK3to4gxmwN7kc0d57t7Xe/sVOLnyS"
        "/wD7Gk/zVnGlOSvGLfqMXOK0bMOqLuGd8LMu4ZOoG5VaDbzXh5pz28Uok5OXm6xudrXM3v8ASur0FHJca+lo4nMbLUytia6R3K0F"
        "xABJ8w6rXKLi7NaimmropRCz19h5xPH+62v8tb/gsESRPglfFI0skYS1zT3gjvCZ0pw8pWKM4y3MgKiVZI4ccEMu4qW+sr8ep6V9"
        "LSSiCR884j8sjehvv6EfSFjGEpu0Vdi5KKuzHQKYHRXfOJPB3JuFDbacjZRxm4mQQNgnEhPJy8xIHcPKH0r7Fo8G3iffbTQ3Wgxn"
        "tqCvgjqaeXx+mbzxvaHNdoyAjYIOiAVlyNS+zsu4bcbXuYuTLk3e1Vlgu1darjD2NfQzPp6iLmDuSRji1w20kHRB6gkJaChqrnVw"
        "0dFTTVNXO4MjhhYXve4+YNHUla7a2M0+JQnaVnCweCVxKvdOyeajoLU142G3Cp07XrawOI9h0VzLp4HnEi2wukp/ge4uA32dJVkO"
        "Ps7RrB+lbe9a1r7LMOWhuuYGTAr6V/xq74pcZLbe7bU2+uZ1MNRGWkj0j0j1jovlrnaadmbL3LWlMCkja572tY0uc46AA2SVl/Fv"
        "Bn4jZTTx1LLM23U0g22S5SiEkfgdXj3tWUKc5u0FcnOMVeTMTAplsBP4HHECCEvZW2CdwH/lx1UocfxowP0rF2acL8t4fPaMhstR"
        "SQuPKyoGpIXn0CRpLd+onfqWU8PVgryi0EasJOyZ1MFMFWEwK0GwtBTAqsFOCsSLQUwVYKYFBDgp1WmaVGQ4KYFIiChkOnB2qwUw"
        "OkEOmB2lB2ogUMmaUqiBLFEoKZREUUUQQyO0oKKhHBRSAoosQ4KKUFHaCGBRSbTAhDEKiiiBImSogqIYFFKiCgQogoKKAZMkBRB0"
        "ohlFFFiJglMEqi9KfJHBQUQJQIHFVuKcqtyUBU8rbfB/5O7vmuu/XKtRnFbc4P8AydnfNVd+uVfD7oPyqPpx7T6eVeXU9F9hp60+"
        "S32BHaRp8kewI7X6Hc8oNtZF4JYza8uz2G2XmlFVQupZ5DHzub5TQNHbSD51jjay34Np+6jT/wDA1P7IXzM5qTp5fXnB2ai7Nb9x"
        "2ZfGM8VTjJXTaNgvrDcPvk838qm/eWufHfFLRhuZU9vslGKSkfQxzGMPc/by54J24k9wC3TWonhP/wAYdJ82xftyLwHclmGLr5io"
        "VqspLZejk2uHOz1Oe4WhSwm1Tgk7rckjDG1NpdqbA7+5fqVzxR2rBcCvHEG7/B9qjaGxgOnqZdiKBvpcfSfMB1P0lbN434OOH2eF"
        "hubKi81WvKfUPMcW/VGwjp7SV97gpjEGMcOrO1kbRVXCJtbUv11e+QbG/Y3lAXcb7e6PG7PXXa4SGOioojLK4DZ0PMB5yToAekr8"
        "pzzukxmKxUsNhJOMU7LZ3ye7etdXuSPcZblGHo0VVrpOTV9dyOvN4T4M2PkGJ2jl9cGz9PeuuX/wesIvMLhS0MtqqCPJlopToH1s"
        "dtp/Quh1HhXxirIp8Vc6kB6GWs5ZCPYGkA+8rNWC5za+INiZdbYZGtDzFNBKAHwyAAlp10PQggjoQuHEUc8yyKxFWU4rn2r+3V+8"
        "6KVTLcY3Sgot9VvZovcadcR+GN34b3COKsLam31BPi1bE0hkmu9pH81w9HvBK6Rtb88RsXgzDCrxa5WB0j4HSwOI6smYC5jh7xr2"
        "ErQMHYB7tjel+gdzOdTzPDN1fLg7Ppvufx9h5bOMvjgqy2PJlu+Q+1NpdqbXpLnyDtfDU/dDxX5yg/bCzr4Uf8Gxj8Op/wC2sEcN"
        "D90TFfnKD9sLO3hSfwfF/wAOp/7a8Tnv6zhfRl2no8t/T63Wuw15jPcuUwrhxlcuMrrkcyOSwq0Khquaei1M2IcFMlCIKxE3r8B3"
        "F/EcMyDIZGakudY2mjJHfHC3ex6i6Rw/srL1fxUbRcbrVw95IDFW2qSsMvXtBOHEtZvetdnG8ka31b19PL4IYv8AUdwnxO0uZyTM"
        "omTzN11Esv2x4Psc8j3LSXLuJnZeFPLlQm/2O3XqOmLgeni8REL9eotDj/aX2HPkKUF1fU4VHlZyZsd4Z2L/AAzwqhu8bNzWStjl"
        "c7XURSfa3D8Z0Z9y8/GuIIIJBHcQvWriDjTcxwbIbCQC640UsMe/NIWnkPudo+5eSr2uje5rmlrmnRBGiCuXMIWmpc5uwsrxa5j1"
        "n4cZKMwwLHL7zB0lfQxSykeaTlAePc4OHuXnBx5xz6lOMGW28M5IXVjqqIDuDJgJQB6hz69y278DHJvhjhTLaZH7mstdJC1u+6OT"
        "7Y0/jOkHuWIvDgxvxLNcev7GajuVE6neQO+SF29n18sjR/ZW3Ffi4eNQ10fEquJq6vSHwVMb+p7gvZnvZyz3WSWvkGu/mdysP4jG"
        "LzkoaSa41lPR07OeoqJGxRtH85zjoD6SvXLH7RBjmP2u0wECnt1LFTMPcOVjA0foC05bC83LmNmLl4qRoj4ZWS/C/FWK1MfuGy0U"
        "cTm77pJPtjj+K6Me5bn8JP4qsF+Y6H/p2LzO4i5KcvzzI75zF0dfXSyxE+aPmIYPc0NHuXpjwk/iqwX5jof+nYtuDnt15yMK8dmn"
        "FHm/xeP3V85+eqz++etyfBO4V0GMYPSZXVU7JL9e2GRkrxswU+9Ma30cwHMT59geZaacXjrixnPz1Wf3z16K8ELjT3ThDhU9M4Oj"
        "Za4ICR/TjaI3j8ZhWvBRTryb4fMyxEmqaSOmcUfChxfhte5rGyjq7tdqfXbx05ayOEkb5XPP87RHQA68530XwsP8MfEcgukFBd7b"
        "W2Tt3BjamR7ZYGk93O4aLR69EDz6Cwb4Q3A/LbRnV9yGitdVc7JdKl9Y2opIzKYS88zmvaNluiTo9xGuu9gYAc1zHFr2lrmnRBGi"
        "Csa2Mr06jT0RlChTlFNHqHxY4Y2viridTbKuOMVzGOfQ1mvKgl10O/6J6Bw849YBHmNVU0tFUzU1QwxzwPdHIw97XA6I+kLePCvC"
        "rwC1YbjtBc664G5Ulvp4Kkikc4GVsbQ/r5/KB6rTbOrrR3zN8kuduLjQV1xqamn5m8p7N8rnN2PN0I6LHMJU6mzOD14jhlON4y3G"
        "3ngqcFqG12Gkzi80rJrtXjtKBkrdimh7hIB/Td3g+Zutd5WUeKHHfFOFT2Ulylmq7tI3nbQUYDpGtPc55JAaD6zs+YFZAsttis1m"
        "t1thaGw0VPHTsaO4NY0NA+gLyxzHIarK8rvF7rJHPnr6mSYknegT5LR6gNAeoBdNep3nSjCmtWaaceXm5S3G3lv8NbHpqtrK7Gbl"
        "TUxOjLFMyVwHp5Ty/rWfbReMc4mYsKqjfTXaxXBhY9j2czXDzse09xHoPULytBW1HgU5BUsyHJLAZHGjmpG1wYT0a9j2sJHtEg3+"
        "CPQtOEx06k1CpqmbK+HjGO1HgYy498KxwszQ01HzuslwYaiic87LBvToyfOWn9Bb51i1bq+Gjbo5cHx64lo7anuRga7zhskT3EfT"
        "EPoWlIK4cbSVKs4x3HRQm5wTZY07TAqruVgO1yG8sBTAqtpTgoIcFMkBTAoEsB2iqwdKwHahCCmBSJgViQ4KcFVhEFRDgpkgKYFD"
        "EKYFKoEEPtFKogRkQUFFEMiClBRUIyZICiCghlFFECggopUyiCCilRBQyCCmSogoEKZKoDpBDJkqiiHBUQUURgtRAFFejPlBBQUU"
        "UQHKpyscqndyURS9bc4P/J1f81V365VqK5bdYP8AydH/ADVXfrlXwu6H8qj6ce0+llXl1PRfYadNPkj2BTaRp8lvsCO1+hHlhtrL"
        "vg2H7qVP/wADU/shYg2su+DWfupU/wDwNT+yF8rPf02v6MvgduW/1dL0l8Tcxah+FD/GJR/NkX7ci28WoPhRH7otJ82RftyL837j"
        "P1Nei+w9d3Q/0b60YW2pvfT0pdqbX66eEN8eEGQwZJw5sFRC9pkp6dtJO0HqySMBpB9wB9hC7VebPRZBaqy13GETUNZGYpYySOZp"
        "9Y7j59+paLcPeJd64cXJ9TbXMmpJ9eM0U2+zmA7j06tcPM4fpC2Zxvwj8LvMTBcJ57NVEeUyqjLo9+qRgI17QF+TZ13N43C4mVfC"
        "xcoN3TjvXHctdOdHucuzfD1qKpVmlJKzvufZrzHTb74KjHSPfY8jLGE+TDXwc2vVzs7/AMVdXdwi4sYHBU/ANXK+nkIfILRW8rnk"
        "DQJYeUk69G1s/aMtsF/18FXu3VpPc2CpY534u9/oX2SPMR9K0x7qMzo/hYlKa5px/wBe82PJcHU8ejeL54v/AGaF1vEPPrfUy0tZ"
        "kl/p6iM8r4Z53se32tPVdN2t8OJXDW2cRrLLT1EUbLrGw+J1uvLif5gT52E9CD6djqtEJ4ZKWeWCZhZNE90b2n+a4HRH0he97ns1"
        "w2YUpSpU1CSttJW9T4XW/qPMZtga2FmlUm5Re5v3i7R2k2pteiPknbOGZ+6JinzlB+2FnjwpP4Pi/wCHU/qjWBeGZ+6LinznB+2F"
        "nnwpf4Ni/wCHU/8AbXic8/WcL6Mu09Flv6fW612GvEa5UfmXEjXKjXbI5kclitCpYVaO5aWbEWA7C7Zwzxg5nxBxqw8nNHXV0Uco"
        "/wDS5tyH3MDiupBbK+BTi/wvxPrb1IzcNkoXua7+jLKeRv8Aydr9Czow26iiYzlsxbN5Myv8eJYhfL4/lDLZRS1IB7iWMJA95AHv"
        "XkbNNJUSySyvL5ZHFznHvcT1JXsLcrZRXmhmobjR09ZRTjllp6mJskcg79Oa4EEe1dX+tFw9+QmL/min/cX1cThpVmrO1jio1VTv"
        "dCcIcm+rDhjit5L+eWpoY2zO9MrBySf87XLzq484v9SHF3K7a1nJA6rdVQgDoI5QJGgeoc+vcvTy0Wa22CgjoLTb6S30MRJZTUkL"
        "Yo2knZ01oAGySfetLPDjxfxTKcbyONmmV9K+klIH8+J3MCfWWya/srDG026Kb3oyw8lyj6Tg+BDk3wfnl7sMj9RXahErBvvlhdsD"
        "8V7z7lmbwzMb+F+E8d0Yzctlropi7XURv3G4fjPYfctNeCmTfUhxWxO7OfyQx1zIpnb7opPtbz+K8lelPEvG/qv4f5LYwzmkrqGW"
        "OIf+pyksPucGla8L+Jh5UzKt4lVSPPDwb8b+qfjNi1O5nNDSVBrpD5gIWl7d/wBprR71v7xqyb6keFWV3Vr+SaOifDC7fdJJ9rYf"
        "c54K1h8BrGu3v+U5FIzpSU0dFG4jvMjud2vWBG38Zd68NvJvg/BLHYY36lutaZnjffHC3qPxpGH3Iw/4WFlPn/0NXx6yiaKr1Z4S"
        "fxU4L8x0P/TsXlMvVnhJ/FTgvzHQ/wDTsWvLPLkZYvyUebnF/wDjYzn56rP756yDwE8Iqs4TF9pudPJcMYqJO0MUZHa0zz3uj30I"
        "PnaSOvUEdd4+4v8A8bGc/PVZ/fPW6EXgd8NJomSMdeSx7Q5pFYOoP9haaFOrKpKVJ6o2VJwUEp8TJGH8ZsFzmOM2fI6J1Q//AHWd"
        "/Yzg+jkfon2jY9a+3keCYxl8TmX2w264cw1zzwNc8ex+uYe4heUVXTvoquoppWlskMjo3NPeCDoj9C7dh/FfMsFmifY8hrqeGMg+"
        "LOkMkDvUY3bb+ja3xzFPSrH76jW8LxgzZfi14H1IyhqbtgMkzKiIF7rRO8vbIB5onnqD6A4nfpC09cx0T3Me1zXtOi1w0QR5iF6k"
        "8KM1l4icPbFks9O2nqK+J3axM3yh7HuY4t310SwkeohaCeEbaqazca8upqVrWROnjqNN/pSxMkd/zPK146hCMVVp6JmWHqSbcJcD"
        "0tXkTL/5sn4RXrbb6yO40FLWREOiqYmSsI84cAR+teUGQWqosV+udrqmFlTRVMkEjT3hzXEH9S2ZpqoPr7DDB75HABWyPgXH7pl5"
        "+ZpP7+Fa2graDwKLVPLmeR3UMPitPbhTOfrpzySNcB9ETlwYNfjxsdVd/hsyd4Zp1wvtHz1F/cTrRtbteGlWRx8PrDRkjtZrq2Vo"
        "9IZDID+2FpG0+Zbcy/PfqMMJ+WOCmB0UiYL550lidp2qmnzJgdIEtBTAqsHacFBDgpgdJAUwO0CWKJAU6BGBTJAUQVWIcFMCkRBQ"
        "JYDtFVpw7aLEMCilUQIyZJtEORYhkwSqIIZHaCiiuOCilB2ogRlEAUVDcZRKooiwKJVFiI4KKrTA7UQ4KKrRBQRYCokUURg1EFKC"
        "ivRnyhlCoENqIUlVOVjlW5ZIGUuW3OD/AMnR/wA1V365VqK5bdYR/Jzf81V365V8Luh/Ko+nHtPp5T5dT0X2GmzT5I9gR2q2nyR7"
        "AjtfoB5Yfay94NR3xTp/+Bqf2WrD21l/waTvipT/APA1P7IXys8/Tq/ov4Hdlv8AV0utfE3PWsHhD4Nk2S51S1lnsVfX0rbfFGZa"
        "eLmaHB7yRv09R9K2fQ6L8fyrMqmW4jvinFN2a16T32OwccZS5Kbst+hoP9aXO/kld/8A+D/9pZOFeb08b5psTuzYYgXvJg6Bo6nz"
        "+gLfrp6lwb3r4Fufd/BZv7ty9RDu4xUpJOlH3/M+LLuboJN7b93yMd0XAjhxXUdNVRWMuiqImSscKybRDmgg/G9a6XxY4A2umxfx"
        "zC7PI250soklhZM+R80OiCGhxOyDo6HU6Kv8Hvi9Q3Gx0GJ3mpZT3OjjEVHJK7TamIfFZs/z292vONa67WwB6HR6FfMxWOzTKcds"
        "1aknsvRNtqS9u5+7rR2UcNgsdhtqEErrgldM82HwzQVHZvikjqGHXK5ha9p9neCtyPB3dlT8PqTkZqzTds34PNbvtez5fK+N5XJv"
        "Wt+vXRZcMUbpO0dGwyf0y0F3096cnZ6nZK2513UeE8PyHIqO7W936tFb5GGXZL3nV5XlL9Fre3Vhb8ZvtC88M2niqMzyKaAgwyXG"
        "ocwju12jlt5xj4t0GA2apoaSojlyWpjLIKdp2afY12r/AEa7wD1J15trTiyY5eMnqXwWm3VNdMwbf2Td8u/O5x6D3lfc7icDUpQq"
        "YuorRlZK/G299XN6z5XdPjaS2abkvFu2+CPm7U2vpX3G7xjNQ2nvFtqaKV42wTM0Hj1HuPuK+Vte+TT1R5eE41IqUHdPijtvDI/d"
        "FxT5zg/bCz34Uv8ABsX/AA6n/trAXDI/dFxP5zp/2ws++FN/BsX/AA6n/trxeefrOF9GXaeky39Prda7DXZi5Ua4sfmXKjXbI5kc"
        "hqtaeiqYrB3LUzYi0Lf/AMCbF/gnhncL5IzU16rncjtfGiiHI3/nMq8/2rPmGeFtmWCYta8ctdnxw0Fui7KN01POXu6klziJgCSS"
        "SdAd634WpCnPamaq0ZSjaJlHwyuJ9+x/KsdsWP365Wp0NG+qqTb6t8BkMj+VocWEb0IyQD/S9a1o+u7xC+XeUfneo/fXF4i8Qbrx"
        "OyyryS8spo62pbGwxUrXNijaxoaA0Oc4ju2dk9SV1ZYVqznNyT0MqcFGKTRtl4IvFbIrtxKqbJkORXW6QXChkNOyvrJJ+SWMh3k8"
        "5OvID969AWafC9xf6oODlbWMZzVFlqYq1uh15d9m/wB3LJzH8FaB4RmFxwHKrZkdqELq+3SGSNs7SY3baWkOAIJBDiOhHesz5D4Y"
        "mb5PYbnZa+y4yaK5U0lLNyU04dyPaWkgmY6PXofSt9LER5F057zVOk+UUomvrXEEEHRHoXrRw3yUZjgON33m5pK+hillPok5QHj3"
        "ODh7l5KrN/DzwpMy4bYpR43a6GyVNBRueYn1sMr5AHvLyNtlaNbcfN51rwleNGT2tzM69NzSsbxcJeGkfDK236jY+F4uV3qa9nZ7"
        "8iJ5AjYdgdQxo35tkrT3wzMm+GOK0dqY/cNloo4XN30Ekn2xx/Fcwe5cn7N/iD/9Hxf8mqP89YFyzKa7NcmumQXPsxXXKZ08jYgQ"
        "xpPc1oJJAA0BsnoO9bMTiKcqSp0zGjSkp7Uj44Ol6t8JP4qcF+Y6H/p2LykWwWOeGDnGM4/abJSWrHH0lspIqOJ81POXuZGwMaXE"
        "TAE6aN6A9i1YOvCjJuZniKcqiSiYz4wfxsZz89Vv989b4+DdxUouIuAUFJJUN+H7NCylrIHHy3Bo5WSj0hwA2fM7Y9G/O7JL7U5R"
        "kN1vlYyKOrudVLVyshBDGvkcXENBJIGz02Spj2R3bFLrBdbLXz0FwgO2TwO5XD0g+kHzg9CsKGJ5Ko5LcxqUtuCXFG8HFrwR7fm9"
        "9q7/AI9dW2mvrXmWpppoi+CSQ9S8EHbCT1PQgk+ZdFsPgP3N1bGb7lNGyia4F7aCFz5Hj0Av0Gn16PsK+PjXhtZVb6dkN8sVuuzm"
        "DXbRPdTSP9btBzd+xo9i+xcPDnuMkJFvwulp5tdHVFe6ZoPsDGfrXU5YKT23v9ZpSxEVZG1bRj3C3CmNdJHbsfslMG8z3fFY0fS5"
        "xPvJPpK8yeIOWyZ3m18yKRhj+Eal0rI3dSyPuY0+sNDR7l9TiJxjy7ilMx1/uO6SN3NFQ07ezp4z6Q3zn1uJPrXRQVzYvEqtaMVZ"
        "I3UKOxdy3s9AvBZ4sUeY4VSY1WVDW3+xxCERPOjPTt6Me308o00+jQPnXL4x+DPZuJ9xfe6GtNnvz2gTSiLtIqnQ0C9uwQ7QA5ge"
        "7vBXn/a7pW2Wvp6+3Vc1JW07ueKeB5Y9jvSCOoWw+K+GXmNop46e9W633prBrtjunmd7S3bf+ULdSxdOdPkq6Nc6E4y2qbPt27wJ"
        "L4+raLhlNuipN9XU8D5HkeoHlH6VtJw+4fWLhdjTLRZ2FlOwmWeomcO0mfrq956DuHqAAWtFR4cdS6IinwiKOXXR0lyL2/QIh+tY"
        "i4ieETm3EemloKysit9pk6Pore0xskHoe4kucPVvXqWUa+FoeNSV3985i6dappPRH2/Ca4qU3EbNIaW1TCayWVroIZWnyZpHEdpI"
        "PvfJaB6Q3fnWEwUgKIOl8urUdSTnLezthFQioouB2iqwU4O1qMx07TtVgooItB0nBVQO0wOkCWgpgVWCmBQRYmBVYKYFAjgpgVWD"
        "tNtAjogpNogqEt71EgOk20EOCjtIptBFm1Em04O0CEFHaVEFBDB2k20iIKiH2jtIiCgR9ogpFFWIsUSqIEcFFICigrjKIAooEZRK"
        "DpMoggqIKIIwaiClBRXoz5QyiAKm0kKVW5WFVOSgZU5bdYR/Jzk+aq79cq1Dctu8I/k5SfNNd+uVfC7ofyqPpx7T6eU+XU9F9hpk"
        "0+SPYEdpGnyR7Ajte/ueXG2vsYzlN1w+6tulmqvFq5sbohJ2bX+S7vGnAjzL4u1NrCpCNSLhNXT3pmUZSg1KLs0ZP+yD4i/KD/2k"
        "P7qn2QfEX5Qf+0h/dWMNobAG99Fw+CMB5iH8V8jp7/xXnZe1mUPsg+Ivyg/9pD+6q5+PnEGpglhlv/NHKxzHDxWHqCNEfF9BWMw4"
        "HuIPsR2pZTgFuoQ/ivkTx+K41Ze1hGgAPMF33H+NGc4zCynor/PJTMGmw1jW1DWj0DnBI9xXQdqbXVXw1HER2a8FJdKT+JopVqlJ"
        "7VOTT6HYzQzwn86awNcLO4/0jRnf6HL4N749Z9e4nxSX11HC4dW0MTYOn4Q8r9KoxDgxlGWdnOab4Nt7+vjNaC0uHpaz4zv0D1rP"
        "eIcE8YxYxzzQG6XBvXt6xoLWn72P4o9+z618p5fllCW1GjG/Uj5WZd2UcKnCVZzlzJ/F7u3oNeMW4Z5TnMvjNNSSMppXcz6+tcWs"
        "cfOdnynn2AravBcRp8JxqktELmSSM2+edrOXtpD3u19AHqCoyziPjeFMLbncGeNAeTRwfbJj6uUfFHt0Fhut8JmvNz5qKxUotoBH"
        "Z1Eru1d6y5vQezR9q6JOriFZKyPF4mpmufR8Sns01quF/W9/q0Mq8YrdR1/Dm+OrGs/2WHxiF572StI5SPbvXr2tNSeq7/n/ABfv"
        "Oe0zKGWKGhtjXB5p4CXdo4dxe49+vMOgWPtrrw1OVOFpHp+57Lq+Awzp13q3e3NuO28MT90bE/nOn/bCz/4U38Gxf8Op/VGtfuGJ"
        "+6PifznT/thbA+FN/BsX/Dqf1Rrymd/rOF9GXafoGW/p9brXYa6sXKjXEj8y5ca7pHKjkMVo7lSxWtK0szRYEwO0oUWIjIgoKKEZ"
        "EFKCighlAdIAoqEZRAFFYkODtFIDpOgUEFFKiCgRgdJ1WmaVMhwdJ1WmaUEhwU4KrTAoEsRBSApkEWAplWCmBQI4KsB0qkwKCLkQ"
        "VWDpOgRu5ODtVgog6QJaCnBVQKYFDItBTAqoFMCgiwFOFUCmB0iwjpgUgO0UCWBEFICjtBDogpNo7UI6iAciixDbR2lBRQI4dtHa"
        "rTIIcFFVpgdqIcFFVogoK44TKtEFFhHR2kU2oRwU20im0ENtEFAHaiBG2ogCoojByIKCi9GfKGUUB2h51IiFUuVpVTlkgKXLbvCf"
        "5OMnzTXfrlWojitveEzDe+AzqGPrK6mrqTX3xL9ftBfB7o/FoUpPcpr4M+nlGtSa54vsNK2nyR7AjtI3Ya0HodDYR2vfXPLjbRaC"
        "5zWtBLnHTQBsk+gBZR4Y8GKrPKIXarrhQ2ntHRt5Gc0sxb8bl30aAemzv2LYzFeHGNYWwPtlujFS0eVVz/bJj6+c/F92guarioQd"
        "lqzzuZd0uFwUnSj481wW5db+VzW7EuBuU5L2c9TA200Luva1gIe4fexjyj79LOuJcEsWxcxzSUxule3qJ60BwB+9j+KPfs+tDLuN"
        "2K4sZIY6o3Svb0MFEQ4A/fSfFHu2fUsEZbx0ynJu0hppxaaF3TsqMkPcPvpD5R92lz/j1uhHxf8ArWcf+Km/V/yfwNm8g4f4zkzN"
        "XSy0kr9aEzGdnIPY9uisT5F4NNLLzy2C8SQO7xT1zedvsD26I94KwjYc7yTGZOe13msgaTsxmTnjd7WO2Csr474TFfByR3+0Q1TO"
        "4z0Tuyf7Sw7afcQnka1LyHcy8EZzl2uDq7ceb6S09jufLsvg55NWXB8V0qKOgo4zozsk7Z0g+8aNf82lnDEOE2MYcY5aSh8auDf9"
        "8q9SSb+9Hc33D3rq1y8I7Fae3Cehgr6yscOlM6LsuU/fPOxr2bWFMw4y5Rl/aQuq/g+3v6eK0RLAR6HP+M76QPUjZr1tJaIxeHzv"
        "NvErPk4ceHu3v16GyGYcXsXw8yRT1vjtwb/ulGRI8H753xW+879SwFl/HjJsk7SCheLPQO6clK4mVw++k7/xdLFm/QptdFPDU4a7"
        "2fdy/uaweDtKS25c77Fu+L6R3PL3Oe5xc5x25xOyT6SfOhtLtTa6Ln37DbU2l2ptVxO3cMD90fEvnOn/AGwtgvCm/g2L/h1P6o1g"
        "fg3RPuPFPE4WAktrmSu9TWAvJ+hqzf4U1UDUYvSg+U2OeYj1FzAP2SvGZy751hkuEX/9Hocv0y6s+ldhr8xcpi4ka5Ua75HIjksV"
        "g7lU1WhambEWArvvDfhNeuKAuhtFXbqcW3szKa2R7N8/PrXKx39A73rzLoIWwHg+PczAeLrmkhzbW0gjvB7KpXNiZyhTco79Piba"
        "UVKSTMT53g9z4eZDJZLq+nkqWRslElM5zo3tcOhBcAfSO7vBX3+HXBu/8TaKtrLVUW+np6SRsTnVsj2c7iN6bysd3dO/XeF3vwiW"
        "jJMcwLNowCbjQiCocP5r9B4b9LpR7l27Bf8A5M4VcPKL4lXk+RUs0jfOWds1wP4sUX4y5pYifIxkvKens3/A2KnHbae41xzPEq3B"
        "clrrBcZaeWso+TnfTOc6M87GvGi4A9zh5u9fDWXeOFnrMg483i12+Lta2slpIYmb1txp4h1PmHrX2KvhlwsxOp+CMoziuN+j0JxQ"
        "QEwwOI7j9rdvXtB9IC3RrrYi5atq+iMHTe00tyMFIgrvXE3htNw9rqF8NdHcrLdIu3oa+MaErOhII2eoDmnp0IIPqGVcz4K8M+H9"
        "ygN+ym7U1FUwjsaZgbJUveHHmcS2LQZrlA2Op318yXiIJJrW+4lTk79BriiCsj8OuFg4g3K71Dbi234vai589wqANhnUtGjob5Rs"
        "k6A+gHuNBws4X5hUvs+KZtXm/FruxbXQ6imIGyG/a2+jzEnXXRVPEQi7Phv03dZRpyauYITArvmH8LK/Is6qsWuFVBa5KAv8cllc"
        "DyBh0eQEjmJ2Nerr3LIFs4UcMMvq5bJi+aXCTIAxxj8Zh+0ylo2eXyG7HTzOPTr10sZ14R3jGnJmBVF9imxa51WUjGY4Absas0XZ"
        "76CQO5Ts+gEHZ9AWYbvwr4Y4bKy05Nmte2/8oMopIeaKEkbHMAxx8/ncDrrobTOtGLS335tSjBsxrW8PLpQYDbc0knoza7hUGnii"
        "a93bNcDINuHLy6+1O7nHvC6ktk+KmPsxbwesatcVfBcIIbpzxVcHxJo3moexw/svG+/rvqe9dHw7hJaZMSjy7Nr66zWOd3JTRws5"
        "pp+/qOh1vR0ACSAT0HVaqeITi5S52kZypu9lzGJ2naKzNceEONZFjtwvPDvIqi5vtre0qaCsj5ZuXROx5LeugddNHR0d9FhgHa2w"
        "qRnuNcouO8sBRXeeG/Dg5sbjX19xjtWPWpgfWV0g3y77mtHnJ17uneSAe7UXDHhxmMj7Zh+Y1rr9yOdDFcIS2OcgEkDyGkdB6yBs"
        "6KwlXhF2fD3GapuSuYSBTgrLPC7hDSZk3M6W9VNTbrjYgyNnK9rY2SHtQ7tNtO2gxjuI6b6rrudWrBLXSUceKXy4XSuEhbUvnj5I"
        "tAd7ByA9/rKuVi57C3hsNLaOkp29dAedbBZfwd4c4JcITfMmutPR1EQ7GnYGyVD3gnmcS2PQZrlA2Op31XS8D4e2a7Ut1yW7ZE61"
        "Y7bKjkikjINS87HKQANt726IaSTvQ6LBYiEo7S3dRk6bTsdbzDBLjgzbY261FH43XwCo8Uie4ywNPd2gLQAd7HQn4pXxrPZ66/3G"
        "G32ymkqq2bfZwx/Gdppcde4E+5Zcyjh/Y8vx275XimV3O91FsYH1sd1JfMWBvfzFrT0aCRsEENI30XP4BUWEfDmPVPwlc/qy/wBo"
        "/wBk5R4t8SQd/J/V9fjd/wBCw5e1Ny3tdBlsXlbgYQraOottZUUdXE6Gqp5HRSxu72OB0QfYV2i+cO71jmK2jJK3xb4OuvL2Ijk2"
        "9vM0ubzDXTbQT0J9el3Li1b+Hkdbk9RQXa7yZYax5dSyMHYCQzfbBvsx0A5teV5h3r52RYtHT8FsXyN10uk89RWOpxSTVHNTQt3N"
        "sxs1tp+1t8/nKlV2lF7rsNi10Y0RBWUcQ4WWyXFmZXmN6daLJM7lp2RN5pp+/qOh9B0ACSAT0HVc24cLMbv+P3C74Ff6i4vtre0q"
        "KGrZyy8uidjyW+YHXTro9d9EutC9v9EoOxiMFMCu7cN+HEudS11TUVsdusltZz1dbIN8o0TobIG9Akk9APcD3Kh4b8Osrnfa8YzC"
        "sN60TE2ti1HMQN6HkN/WT59FUq0Yuz4EoNmGQdo70uVd7VV2G6Vdtro+zq6SQxSM3sAj0Hzj1riA7WfSgLAdoqtMCoiwFPtVIgoI"
        "t2jtV7TAoEfaIKREHShHTApNqbQQ+0wclB2ogh9ogpAUUCWbUSAoqIsUVYOk20MhwUVXtNtBDbTKtMCoRtqbSogoEO020qgOlENt"
        "RTaiBMIqJUy9GfJIoVFECAlVOVjlW5ZIxZS5bJ+Czk7DBeccleO1a8V0DSfjDQbIPdph95Wtrl9bEcoq8MySgvVEdzUknMWE6EjD"
        "0cw+ogkLjzPB9+4WdFb+HWjpwWI73rxqPdx6jl8YcOfhGf3agEZbRTyGrpHa6GKQkgD8E7b/AGV0Ta3b4hYdauO+B0V0ss0YuMbD"
        "LQTvOtE/Hgk9HUaPoIB7u/Sy6WytslwqbfcaaWlrqZ5ZLBK3TmO9f+PcfMuzufzVY3DqnU0qw0knv00v6+PSc+aYJ4ertx8iWqfZ"
        "98DIfD/jVdsCs8tqjoaaupOd0kIme5hic7v6jvaT11+lfEy3ihk+Zl7LjcXso3HpR032uEe0Dq7+0SumbU2vtqnBS2ranno5bhI1"
        "niFTW2+P3u9Q29exHaTfrU2sztH2ptJtTaiH2ptJtTaiH2ptJtTfrUQ+1NpNqbUQ+1NpNrtWAYBd+It+jtdqj0wadU1Tx9rpo/6T"
        "j6fQ3vJ95WutWp0YOrVdorezOnTlUkoQV2zMXgp4dJV3u5ZTPGfF6GM0lMSPjSv1zkfgs6f218HjtkzMj4i1zYHh9Nbmtoo3A9CW"
        "b5z+OXfQs55pfrVwO4c0tms2mVzonQULCQXuefj1D/YSTvzuIHcFqDzukeXucXOcdkk7JK8PgJyzHG1MykrR8mHUuP3xbPSYqKwm"
        "Hhg4vXfLr++wvj7lyo1xo1yWeZfakfORyGqwKpitWlmaHHcs/wDg/fxf8X/mpv8Ac1K1/B0uw4/m19xa33igtNd4tSXmIQVsfZMf"
        "2rNObrbmkt6Pd8XXf7Fz16bqQ2V0fE205KMrszfiVvn4k+DlWWKmYZrpYri000YGzpzwd/iyyj+yvtcTq2Gi4wcKsUpHf7JYpKMA"
        "DzF0rGgH+zG0+9YAw7iPk2ACsGO3M0QrOTth2Mcgfy75fjtOvjHu9K49dm9+ueVR5TVV5lvscsczakxMGnxgBh5AOXpyjprXRc/e"
        "0uUbvprbrZt5VbKXHT3GcL/eKOxeFr47XvbHStngjc9501pfRsY0k+YAuB2u28QM74mY3ltZQUGDWu40EkpNJVR2yaYysPdzOa/X"
        "MO49B1G9aWq+R5Hc8svNTeLxU+M3Gp5e1m5Gs5uVoaOjQAPJaB0HmXarNxqz2xW9lBQ5JVNpY28rGysjlLW+YBz2kgD1FYywjtF6"
        "NpW1FVlrwu7ncuPt8zKeDHrZltHYaV3ZGrgitnP2kXMACx4c860enToSDonS+h4WhP1fWgb6fBbOn/5pVg67Xivv1wmr7nWTVlbM"
        "dvmmeXOd7z5vV5l9PLM2vudXCGvv9d45VwxCBknZMj0wEnWmNA73H6Vthh3Fweml/eYSqJqXTYzNwep3ZZwYzvErY9nw9JKKqOIu"
        "DXSs1H0G/SYy30DnG+9dGwThJml5yukpY6C62R0MnNJcZKeSLxXX84E8u3egA7P6V0K03i4WGvir7ZWT0dZF8SaB5a4erY83qXcL"
        "rxrz29UD6CsySqdSvbyubEyOIuHnBcxoJHvQ6VSLlybVnz8CU4tLa4GR+FXD+zXfNM2kvE31V1FgYDAwvOq6TytnqTzaLA0bJHlA"
        "9eiyDwvvUt3y6nb9aS341DD2n/xF1KIZYzyOHKwmNpc49QQD3bK1OsGRXXFriy42avmoqxgLRJE7Wwe8EdxHqPRdjunF7Nr1X2+u"
        "rcgqX1Nvk7WnLGsjax+tc3K1oaTokdQehI85Wqrhpzb1vddOnqWhnCrGKR362VAxfwmX1d3hfS0813qix87CwObKZGMeCf5u3Dr3"
        "dF8zi7w2yuPiLep4rLcK6nuNU+op56aB0rXNedhu2g6I3rR9HoWPsszO95xcYrjfq3xysihEDJOyZHpgc5wGmADvc7r39V2G3cas"
        "9tdtZb6XJaoUrG8jQ9jJHtHoD3NLh9Kz5KpFqUbXtZhtxaafPcyxxQx6vxbwdMTtNzHLXQV7DKze+QuE7w3fqDgPcuNm9lr8/wCC"
        "uBV2OU8lcyzQ+LVdNTDnka8MYwu5B1Oiw+vTwe5YYuef5He8egsFwuklTa4J3VTIpWMLu1cXkuMmudxJkeepPf7FXjGb5Dhk0kti"
        "utRRGT47WEFj/RthBafeFhGhNK91dNvo1F1It9FjN/g+47dMIkyPLchpKi22Wnt7oiKthjMp5mu2Gu0ToN16y7Q31WunN1J1oHzL"
        "s+T8ScqzSJsN8vVRVwNPMIdNjj36SxgAJ9el1dbaVOSk5z3vsMZSTSS4Gy/g+3qqHDjLLbY4KOqySnn8chpKsbZMwtYNa2N/EcO8"
        "aLm7719PFs64sZBdzRwYVZLc+IOc+prbfUQRxkA9OYv7z3aG+/0bK1ks95r7DXxV1srJ6Ori+LNC8tcPT1Hm9S7deOMec363Pt9d"
        "kVS+kkbyvZGxkRe3zguY0Eg+glaKmGbk2knfnNkatkk+Blrhrd6u92vjdca1tMytnpC6XxQ7i5xHUglh2djY3vZWuIK+1YMzveM0"
        "F2oLVW+L0t3iENYzsmP7VmnDW3NJHR7u7Xf7F8RbqdNwlJ89vgYSltJGd/CoJ+rq1DfT4MZ/eyr6PD7G7PZeFEeXMxJuV3mpqHRv"
        "pXt7QQND3N+Jp3QBoJ6E+UO4LCuU5le82r4q6/VvjdVFEIWP7JkemAk60wAd7j9K5WK8QMlwsStsd2mo45jzPjAa9jj6eVwI369b"
        "WrkJqlGCeqMuUW25Gz+MTVN6wDNS3BKXGZp7fIyKnpYQyaq3FIASwMa7Wzpux1JdpYN4ERSU3GCxQzsdFLG6pY9jxyua4QSggg9x"
        "35l8Kk4s5nR3upvMV+qPhGpYIpZHtY9rmAkgcjgWgDZ1odNn0lfBbkd0bf335lZJHd31Dqo1MYDXdo4kudoDQ2SemtddLGNCSU1z"
        "i6ibT5jsvE+03ClznJ6qegqoqV9ynLZnxODHAyOIIcRrqF37Kz/4acM+c3frqVjzI+KuXZdbDbLzd/GqEva8x+LxM8odx21oP6V8"
        "uqzG9V2M0WNz1vPZaKXtoKbsmDkf5XXmA5j8d3efP7Flyc2o3tow2km7cTNGZWeuzvg5g9bj0Ela20Q+L1VNTjmka8Ma0nlHU6LD"
        "69PB7l1PDeGuSGy328VdfXYvb6WnJfLMx8ZqQOvJy7aSOnr2dAA+bo2NZnfsRmfLZLpUUTpPjtYQWP8Aa07B94XMyXiJlGXxNhvN"
        "4nqoGnmEOmxx79JawAE+0LFU6kfFTVveO1F6veZS4VwOyfhHmmL25zfhp8oqWRcwDpGaj6D2mMj+0N9665wv4eZRJn1mlktFfRwU"
        "FUyeomqIXRta1jtluyBsnWtD0+hY4tV3rrJWx1tuq5qSrj+LLC8tcPVseb1Ltdz4vZteaF9FV5BUupnjlc2NjIi4eguY0Ej3qlTm"
        "nJRtZkpR0vwL+MF2pL1xJv8AVUT2vp+1ZEHtOw4sjaxxB8420rpAOlWmBW2MdmKjzGLd3ctBRBVYKZIFiO1WHaT7QQ4O0VWmBQJY"
        "HI7Ve0wO0COCmVaIOlWIcJtpNohyBuPsohyXagKCH2iHJVECPtEFKDtRRD7U2l2ptFiHR2kDkdqEdRJzJtoIfaiTabaCGBUS7UUJ"
        "hREFImXoz5QyiAKJQQpVblYeqQpIpcqnBXuCqcFmmYM7zwv4q3LhrcnGNpqrPUuHjVEXa5vNzsP814Hn7j3H1bI3XHsB8IGyMrIZ"
        "g6thZptTBplXS/eyNPe3fmOx6CtMHBci3XOus1ZHWW+rnpKqP4s0EhY4e8L5OOyhV6ixOHm6dVcVx6/vrud+Gx7pw5GrHbg+D7DJ"
        "2U+C/mVmle+zmlvdJvyTC8RTa9bHnW/Y4roc/CbO6Z5bJiF6BH9Glc4fSNrJVg8JjMLWxsVwZQ3aMfzqiMskP9phG/eCu2w+Fl5I"
        "7bExzefs646/SxYxx+e0FszpRqdKdu1fAXhcsqPajOUOjf2P4mA/rX5t8kb5+RP/AMFPrX5t8kb5+RP/AMFsD9llF8lJPy//AE1P"
        "ssovkpJ+X/6az8L51/ir+S+Yd4Zd59+z6Gv31r83+SN8/In/AOCn1r83+SN8/In/AOC2B+yyi+Skn5f/AKan2WMXyUk/L/8ATV4X"
        "zr/FX8l8x7wy7z79n0NfvrX5t8kb5+RP/wAFPrX5v8kb5+RP/wAFsD9ljF8lJPy7/TR+yxi+Ssn5f/po8MZ1/ir+S+Zd4Zd59+z6"
        "Gvv1r82+SN8/In/4KfWvzb5I3z8if/gtgvssYvkrJ+X/AOmj9lhF8lX/AJf/AKavDGdf4q/kvmXeGXeffs+hr59a/NvkjfPyJ/8A"
        "gubQ8G8/uDwyHErq3f8AOmi7Jo97yAs7fZXxfJV/5f8A6a41V4V07mkUmLQtf5nT1jnD6A0frU83zt6LDRX/ALf8i7xy5b6z9n0P"
        "i4Z4KV1q5Yp8ruMVDTdCaSicJZneov8Ait93Msr5BmuF8DbELLZqWB1cwbZbqd23l+vjzv6ke0+UfMNLAeTce81ySN8Ar2W2leNG"
        "K3s7Mket+y79KxqXOke5z3Fz3HZJOyT6Vyzy/G5hJSzOp4q/ZHRev7b6TdHF4fCxawcNX+57/v7sfaybKLnmN6nu12qO2qpunQab"
        "G0dzGjzNHo//ANXzWBVtar2BfcjCMIqEFZI+Y5OTcpPUuYFyWKhgXIaFrkzJFrQrAUjU4WtmaHHciCgFFiIygOkAUUCMogCighlE"
        "oTKIIKKVMgQgopUQVEMCmBSIgoYjpkgKIWJDIgoKIEZM0+ZKooSxMCq2lMgixEFI0+ZMoRwUwKQFEFBFgKKQFODtYkMCmDvSq0QU"
        "CWhMCqwUwKBLAUQUiO1EWApw5UgptrES5EFVhyO1EW7UBSh20UEWKJAUdoEsBR2kDk20EMCm2q0QVCWAoqtEFBFgOkdqvfrRDkCW"
        "bIR5km1NoEfmRBCRRRD7TAhIoixD7RDtJAUUEPtHmSAoqEfaiXaiLEYWRBSgor0Z8oZEFKCioSJSEyhURURtVuCuISkbSmDOOQkL"
        "VeWpS1ZpmNijlU5VcWocqblYq5UeVWcqIaq5WKuVEN2reRTkRtFYq5UQ1W8inIq5WKuVEBXcinIi5WKuVTlVwYjyIuNioNThqsDE"
        "4YhsbAa1XNao1qtY1YNmSQzAr2hI0K1q1tmSGHROEicLBmQVt14NeaYJY8HkpZ7hb7TfhMTXyV0zIXVO3O7NzXOd5TQzydDXKeY6"
        "HNt2oqIK58RQVeGw3Y20qjpy2kekH1zMJ+WGPfnKH95T65mFfLDHvzlD+8vOBRcHgqH9zOjvyXMej/1y8K+WGPfnKH95T65eFfLD"
        "HvzlD+8vOJRHguH9zLvt8x6PfXLwr5YY/wDnKH95T65eFfLDH/zlD+8vOIFFXguH9zHvuXMejn1ysK+V+P8A5yh/eU+uVhXyvx/8"
        "5Q/vLzkBRV4Lh/cy77lzHo19crC/lfj/AOcof3lPrlYX8r8f/OUP7y85gUUeC4f3Mu+3zHox9crC/lfj/wCcof3lPrlYX8r8f/OU"
        "P7y850yvBcP7mXfb5j0MuXEjAnW6sFbk+P1FGYXiaHxyKbtGcp5m9mCS/Y2OUAk92itBb3Nb571cZbVBJT2uSokdSQynb44S4ljT"
        "1PUN0D1PtK+amBXTh8KqF7O9zVVqupa6HBRSApgV0GoKZKiCgyCnBSKKIsTNPmSAooIsRBSAplCMmBSAorEi4HairDk4KLEOCm2q"
        "0doEtDvSmVW0wO0CWApgVXtEFRFgKYFVbTA6QJZtMHKvaIKCLdogqvaO0WIfaYFIHbR2oR9og+tICisSLdqbVYKKhLFEmym2gRgU"
        "Um0Q7aiHBRSbRDliI4KO0m1A5RD7Tb2k2pzKIdEFLtTaCHUShyiCMMpkqi9GfLQyIKCiCGUUCihIQk0nU1tRFZahyqzShaq4FXKh"
        "yK4NU5U3KxUGo8qt5FOVFysVBqPKreVHlVcbFPKm5FbpHlRcrFIYjyK3lRDUXKxVyIhqt5UeVVxsV8icNThqcNWNxsI1qtDUA1OA"
        "sWxSGATDogEwCGIwRShMsWIQUUqZBBBRSogoEIOkyVEFAhTJVAghkQUFFEMiCgoohlAUAUUCMogCioRkwKQFFYtEOCilBTIEIKKV"
        "EFAhBTApUQVEOCmBVaYFBFgKIKREFQjogoKIIsBTKoFMDpBFgKKUHaIKxsKHBTbXZsBu+L2W8Tz5bj0t+trqdzI6WKqfTlkvM0h/"
        "MwgnTQ4a++9SzL4Qtg4bYBDHYLJhktNe7jQQV9PchcZ3tgDpSHNMb3kOJbG4b++9S2xo7UHO606/kYOpaSjbea6gorYVuIcNeGOD"
        "4bcs0styv90ymn8d/wBnqXQspYSGuGg1zdnT29DvZB7ui6Lx14c0XDLOBbbZUSzWutpI66l7U7eyN5c3lJ8+ix2j6NKnh5QjtN83"
        "qvuKNVSdkY2DkdpFmTwbsLx/Oczu9Fktu8foKW0TVbIRNJF9sbLEAdscD3OcO/XVa6dN1JKC4mc5bCcmYgDtJtrYKLFOG3E7AMxv"
        "GLY/X4zdcZpvGyJax9RDO3lc7lJeT1IY4dNdSO/qFwMUw7BsT4TW3Pc0tddfJLzWPpaShp6h0DI2sL2lznNIO9xu8/naNd5W3vaV"
        "96ta9+HzMOWXNqYN2mWcc/w7B8DvWEZXDaqy44VklHJVGzzVLo5WOEY03tGnmABljPeerSNkFdvuFBwet/Cu056eHFQ+nuNe6hbS"
        "C71AcwgSeUXc+iPtR6a86lhHdpySt17ufd0hyysmk9TV9MCuVeKiiqrvcJ7bSOo7dLUSPpqZzy8wxFxLGFx6u0NDZ79LhbXK0bkW"
        "bRDlsjkdq4WcPMNwGtu+CT3Wuv8AaYquWaK6TxfbOzjLiRz66l++mgFjO32fHeJvFKz2fHLZLj1muEjInQvqHTuZoEvcHPJOyAdD"
        "u3pb54dxajdNu2mvH1GuNW6vbQx3tEOWxVzt3BCkym64XcLNeLLNQvkp/h6Wqe/7azflGPZHKSOhDeux0G+nUuEXDrHsglzK9ZDU"
        "T1mPYpTmd8dGSx1Zvn5dE6IBEbunQ9R1HVTwstpQTT7LCqytdpmI9hfcxTEb1m11FrsNA+trSx0pY1zWBrG97nOcQ1o9ZI6kDvK7"
        "9mVLwxv+DSX7FGy2C+UdQIn2aqqjMamMkDnYXEnpzA9/813TuKyN4OmB2a44TW1d7mroJskrpLTSGmrp6drw2B7zzNje0PHR/RwI"
        "8nXnTSwu3VVO9+On32BOtswcrGs1TC6lqJYJCwyRPLHGN7Xt2Do6c0kEesEgqvayPwdwyhvvGC14vkVH4xSGWqhqaftHM26OGU65"
        "mkEacwdx8yy9auCmJu49VFimthnxSstHwjRU/jEo5DtjCOcO5iQ4P6E+cLGnhJ1IqUeewyrxg7PmuatghTazrw1xzB6bgxe80ynG"
        "n3mpobt4o1sdbLAeQsh0PJcB0Mjj3bXQs7yDBrzSUjMTxCexVEchM0slfJUdq3XRunE669VhKhsQUnJaq9tb/C3vMo1LyaSZ0kEK"
        "bWyN9s3CrAsTwCpvuF1VdU5Ba4aqoqqe4TMcx3Zxl7uTn5SSXk6GgsZcbOHtJw2zZ1st9RJNbaqmZWUxlO3tY8uHK4+fRafdpNXD"
        "Spx2rp2tfovuCFZSdrGPAUdpFNrmNxZtRVqIsRh4FFKiCvRnyhgUUqIKGIUyVQFBDhTSCIKBCooogiIgBQdUdKuJNKaR0iFEDlRA"
        "RARQQNI6UR0ogAI8qbSICBAAiAjpFAg0mA2gEw6IIgCYDagUWIjIgoKKIZEFKCiohlEAUUCMogCigRgdqJUyCCCilRBQIwKKVEFB"
        "BTJUQVEFMEqihGRBQUQQyIKAO1ECMmBSAooIsUSh2u9MgUMFEqZYiEFFKmB2ohg70plWiCoi0FHaQFMgRkwO0m0QUEODpNtIiChk"
        "cmlpaitkMdNBLO8DmLYmFxA9Oh7VsJ4XdJUnNseqBTymnjx+ma+UMPK09tN0J7geo+lYXwrPch4d3Wa6Y1cPEa6aA0z5exjl3GXN"
        "cW6e1w72NO9b6LsmUceuIWaWKrsd8yDxu11fJ20HidPHzcrw9vlMjDhpzQeh8y3wnBUpRd7vs9ZrkpOaa3Iybxwstxv/AA64LVFq"
        "oKmuhFlZTF1LE6TUvZwjkPKDo7a4a9R9C4HhePaOItkp+YGWmsVPFK0HZY7tJjo+4g+9dK4Wccso4a1tvp6e5Ty45HUB9RbXhr2O"
        "YT5YZzDbCdk+SR1799Vw+NNxsV54i3a747e5bvbbk4VIlmZK18Lnd8R7RoJDddNbAbyjzLZVqwnTk1vdrrqXAxhBqaT3K50JbCeB"
        "9I6LiJkEjWh7mWCocGuGwdTQdCFryCuy4XnmQcPLpNc8buHiNdNAaZ8vYxy7jLmuI09rh3sad630XPQmqdRTfA21IuUXFGyVFkNx"
        "4qcFuIDb5YIMYhs8IrKea1QyUcFXIGud2T2EkP6saPP8Zvcdb6tkVvq7z4KOBfB1NNVmiutQKhsDC8xbkqNcwHd8Zv4w9Kxdl3Gb"
        "Os7t/wAH3/IZ6qhLg50DI44WPI6jmEbW82j1676riYZxRy7h8yePG75PQwznmkhDWSRl2tc3I8FoOtddb6LoliIN2d7WtfS+++41"
        "KlJLTnuZY8IOCW38OODVuq43Q19NapTNTyDT49sp9cw7x1aR7ikyQ/8AhHw//wC4H/qqlhXJcrvWY3V90v1xnr654De1mPxWjuaA"
        "OjR1PQADqVyanN77WYjR4nNXc+P0dQaqGl7Jg5JTzbdzhvMfju6E66+xa5V4uc5W3q3w+RmqbUYrmdz4YKZVogrkZuNwM7z+7YVw"
        "94Ux23F7Ne21Vhgc91yoH1Ji5YYdBpa4cu99fYFgOGoyXPuKdLU2yhorLklZLG+mgpGGkhifHGOUtDieUns99/Vx9a5tq8IjiVZL"
        "XRWygyTsaGhgZTwR+I0zuSNjQ1o2YyToADZJK6jkedZBluQMv93uUk14YGBlVGxsLmcnxSOzDQCPSOq7K+IjUs03w00+NzRTpSjf"
        "RG0WKXi88TsunwbibgNJU1EccsUl5hpTFLAWNOn9p3acRoFpAOx0IXTuDFsAxPjnYba81tR4mIqZsQ5n1DWeMN20Dv3tvd6QsaXD"
        "j1xGulpfa6nKqx1G9nI4MZGyRze4gyNaHnftXUcayq84fdGXOx3CegrmAt7WE97T3tIPRw6DoQR0S8VDai9Xa+rtezVvXYFRlZrd"
        "uPunhjkUWEVeX1NK2ktFNO2n1UkxyyuJaPIYR5Q8rv8AvXehbMeKY5hWMcIrdesxix6tswZeZKN9FJOap0h5nAuaRyfGkZs77/Ut"
        "Ysw4oZbnzaduRXqeuip3c0cRayOMO7ubkYA0nXTZG+pXBy7Nr7nl0jueQV3jlbHC2BknZMjDY2kkNDWNA73Hzeda4V6dK+wr7t/X"
        "fg+ozlTnO20zZGjx0Y74ZVK1jeWC4OqK+M/0u0pJS4/j86yJweqGZLeqytcQa/GbpdLW/wDpGnmmErCfUHNc0LUGTi5mM+SWnI5L"
        "xzXq005paSqNNDuOMtc3lI5NO6Pd1cCeqGM8Wcww+43a4WW8Opau7ydrWP8AF4niV/M52+VzSB1e7uA71vp42nCV7O12/h2o1zw8"
        "5LfrZIzXwlyGrxfwb8mudDaqK6VEV95W0tbTmeJ+2U4JLAQTre+9Yh4j5zdc0FtdcsZtNlbRmQMNtoX03a8/Lvm5nHm1ydPRs+lc"
        "fDeMGZ4BbJbZjt58SoZpjUPj8Vhk3IWtaTt7Ce5jem9dFXmfFbLuIVLS02SXbx6CleZIm+LRRcriNE7YxpPT0rnqV4ypKCb0VrWV"
        "vbc2RpuM3KyNpxcsQFHwRs2U47TXB1ztEDKatnkPLTPEMXK0x604PcWjqenrWtnHC53648Tr6MjDG19LL4uxkTSI2wt/8vlB66LS"
        "Hdf6S63es6v+RU1iprjcXSxWKFtPbw2NkZgY0NAALQCdcjep2eneky7M73nV1F0v9Y2rrxG2HthBHES0b1sMaAT17z1+gJxGKjVj"
        "sro+FtewqVFwd396nxNhHarTLhOkfaiQHSiCMQqIAor0R8oZRKmUQQUUqYIEIKKVEFBDg7USpkCRMlUCBHBRSogoIYFFKmUREQUF"
        "FEMDpMlRBWIjAopUwUJEQUFEEMEyUHaIKBCDpMlRBQQUyVQKIZEFBRRDIgoKLERlAUAUVCMogCighlEoOkyGIQUUqZBBBRSogqII"
        "KZKiCoQpkqgOkEMmCVRAjIgoKIIsRBVYKdDEZRAFFYiMolB0mUQQUwdpImURYokBTbQQwdpP3qtEFAjpkm0QVCMmBSqLEiwOTAqt"
        "EHSBLNogpNog7UJYjtVgptosQwcm2Cq9ogqItBRVaYFFiG2iCk2iCgR9o7S7U2ixDcybmSKAoG4+0Q5KooR9ohyQFFBD7UDkoKKi"
        "H2olBUQRiJEFBReiPljIgoBRBDKIBFRDKIBFYiMDtQHSVMohlEAigQgopUQhiMCiEqZBDKIBFRETJUQohgUUqYLEUMogEVCRMlRC"
        "CGBRSpghiEFFKmQQQUUqIUQUyVEIZBTBKoECMiCgopiMiCgogRlEAighlEAighgolCZRBBRSpkMQgopUQoggpkqIQxCmBSqBBFiI"
        "KRMFixGRBQUQIygQCKiGRBShFRDbTJUQgRgUUqZBDAptpAighkyQFMEGQwKIKVQKsRYptLvSYIIO0QUqI70EPtEHSRMO5Qj7U2kC"
        "ZBDhym0gTIEYOR2kTBBDByO0iIUI2020iIKCG2m5tpFAgR9qIKKK5//Z"
    ),
    "mercado_ok": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsb"
        "HR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwc"
        "HBwcHBwcHBz/wAARCAEsAtgDASIAAhEBAxEB/8QAHQAAAwADAQEBAQAAAAAAAAAAAAECAwcIBgQFCf/EAGIQAAEDAwEEBAYJDA0J"
        "BgcBAAEAAgMEBREGBxIhMQgTQVEUFSJhcZEWMjdWdYGUsrMXGCMnUmJygpKhsdIkNDhCU3SEk5W00dPiJjNERlV2oqTDJTVmpcHj"
        "Q1Rjc6PE4fD/xAAbAQEBAAMBAQEAAAAAAAAAAAAAAQIDBgQFB//EAEQRAAIBAwEEBQYMBgEDBQAAAAABAgMEESEFEjFBUWFxsdEG"
        "E4GhwfAUFRYiMjQ1U3KRkuEjM0JSVPFzJUPSRGJjguL/2gAMAwEAAhEDEQA/AOZ0wVIKa1HGlIQhAMFNSmChCgU1KYKEY0IQhCkw"
        "VIKaApMFSCmgKQkCmhACpSmChCgU1KYKEKBTUpgqAaAcIQhCkwVIKaEKQkCmhAVKUA4QhYKalMFCDQhCAYKalUhCkwUghQhSYKkJ"
        "qjBkCoKAeCaELCaQTUIWCqHNQOSYKEZaoHkpTChizKmFCoIRlhU08VITCEMiYKkFNCMyBUobxCYQhYVBQOaoc1CFgqgoVNKEZSpS"
        "hGQpMFJCgKTBUgphDEpUFKEIUhCEAwU1KYKEGhCEBSAcKVSEKQkCmgBMFJCGJSpSgHCApCEKIDBTUpgqhjQhCEKTBUgpoQpCQKFC"
        "GnFQOVAKa3nRlKlKYKgGhCEDGCmpVA5QhSFKpCAmCkhCFJgqQU0BSpSgICkIQhBgpqUwUIygU1KpCDBTUqlACYKSEIUqByoBTQhS"
        "EIQgwU1KYKEZQKalUDlCAgHCEIDIOSFIKpQgwmkE0BQVKAmFTEtpwVaxhWCoCgUwpVAoQsFNIJqGJkVDsWMFWOSGJaYKkFNCMyKl"
        "AKoIQtvBUFAVAoQsc1SlMFAUCmOalUDlQxMiFKpCDBTUqggBUCpQOahDIhCEIAKpSmChBoQhAMFNSqQgJgpIQhSYKkFNAUhIFNCM"
        "FSlMFCFApqUwVANCEKgpClUhATBSQgKQkChDE04qUoC2nSlAqlKYKpiUCmpTBUA0IQhCkwVAOFSApCQKaGIKgcqUIClSlMFAUCmp"
        "TBQjGhCFAUEBSqVMSkBIFNAUhIFNQAqUoCGJQKpSmCgY0IQhBgpqVSEKQpBwqQhQTBUgpoClQOVAKaEKVKUwUIymnirWMKwUIUE1"
        "KpQhkByqWMdiyIyMY5K2lQOSoKGLLTCkFUEIWqCgKghiZAmpCpAU08FSgKgUIWgcCgIQhkTBUAqliQpMKQU1SFISBTUIUCqWMKgU"
        "BSEIQxYwU1KoHKAEBCEBSEgU0ICYKSEIUqUhAQFIQhCDBTUpgoQoFNSqUAJgpIVBSEgU0ICEIQGnUIQtp0YwU1KYKEZQKalUCqQo"
        "IU5wjOVAUmCozhG8gwXlMOWMOT3kGDJlNYgQnlCYMiYKx5QHITBlynkrFvJ76DBlBTysW+nvBCYMqMrEHKt5CYMmUw5Yw5PKEwZc"
        "pgrGCmChDIhIHKahBgpqUwUIUCmpVAoRggIQgKTBUgpoYlJgqQU0BSpSEBBgsJpBNQgwVaxqwchUxKBVBQOasKEZQ5KwVAVjkoQs"
        "KgoaeKpCMpWFjBVhCFKgpVBCFgpg4UqghiywmoaeKtCFtOU1AOCrUAwqBUhNGYlJgqQU1AUqUhAVMSkwkgc1AWCmpTBQg0IQhCkK"
        "QcKkAJgpIQhSEgU0AKlKYKEKBTUpgoBoQhCFBAUqkIUhIFNQAmCkhUFIQEKENNg4VKUwVvOkY0IQoQYKMpIQYHlGVJKguQJGUuU7"
        "6xFy9ho7ZpqHW5ElBSiKhBw6sqDuRDzA83HzAFaq9xSt4OpWkopc2eiha1biap0YuTfJHlN9LfXSNn6OtjoYRLebpVVbm8XdVuwR"
        "D4zk/nC/QdoPZLQ/Y5pbWHjgetupz89fAl5VWW9u0oyn2LxaOip+SN845qOMO1+CZy9vp766f9iGyD+Gsn9Kn+8R7ENkH8NZf6VP"
        "94sflRR+5qfpXiZ/JC4+9h+b8DmEPRv+ddPexDZB/DWT+lT/AHiPYjsg/hrJ/Sp/vE+VFH7mp+leI+R9z99D834HMQkT3/OunPYj"
        "sg/h7J/Sp/vE/Ylsg/h7J/Sp/vE+VFH7mp+leJPkfc/ew/N+BzHvp766b9iWyD+Hsn9Kn+8R7EtkH8PZP6VP94nyoo/c1P0rxHyP"
        "ufvaf5vwOZd8Jh66Z9ieyEf/AB7L/Sp/vFkZs22YXj7HRSUZkPAeCXTLvUXH9CfKm3WsqU0vwrxI/I66f0asH6X4HMe+rD1vfUHR"
        "yYGOksV2eJAMiCubwPoe3l8YWl9Q6Zu+lK00d3opaaU8Wl3Fkg72uHBw9C+pY7XtL7ShPL6OD/J+w+Nf7EvLDWvDC6VqvzXtPiDl"
        "YOV8zXrI1y+kfJaPoBVgrCDlW09iGDRkQkCmoYsYKalUhCkKQcKkICYKSEBSYKkFNDEpUpTCAoHCtY1YKEY0wkmFCFgqgsasHgqR"
        "lqmlSmFCFhWCsYKsIQsc1QUAqgVCFBWFCoKmJYKoKFQUIUrBUJhDEtUCoBVBRgtUoBVBCDTBSQgLCalUEIxgpqUwUMSgU1KYKgLC"
        "FKpCAmCkhCFISBTQAqUoQhSEIQDBTUpgoQoFNSqQAmCkhDEpMFSCmgKQkCmoAQhCoNOApqUwVuOkKBTUp5QmAykSkSpJQqQFyxly"
        "TnYXrtmOjjrjV1Lb5A4UMQM9U4dkTcZGe9xIb8a03FeFvSlWqPEYrLPRbW87irGjTWXJ4R7vY9sfGomxX6/RO8VZzTUpyDVEH2zu"
        "3cz+V6Ofp9o+3qh0o59j0rBT1VdTjqnT4/Y1NjhutaPbkdww0efkjb3tHOkrXBpaxvFPXVcI610Pk+DU/tQ1uORdjA7mg94XK2QO"
        "GOC53ZmzJ7an8Y7Q+h/RDljpfvr2YR3dWrT2RT+B2f0/6pc89C99O3LP3tQ6xv2q53S3m7VVYSchj3kRt9DBho9S/DDWjk1o+JTl"
        "GV29OnClFQppJLktEfCnOU3vTeX1lYHcPUjA7h6lOUZWwxKwO4epGB3D1KcoymQVgdw9SMDuHqU5RlAVgdw9SMDuHqU5RlAVgdw9"
        "SN1oIO6MjtwpyjKZB7bSe1bVejpIxQ3SWakbjNHVkyxEdwBOW+lpC6S0lrzS+2mzy2m40bI69rd6Wgmdkj/6kL+Zx3jBHaMLjfK+"
        "q3XOrtFfTV9BUPp6ymeJIpozhzHDt/8A52rntreT1vfLzlNblVaqS0168ce3ifUstqVaH8Op8+m9HF66dXvg2btH2eVmgLqGFzqi"
        "11JJpqkjGcc2O7nD8/MLxzX5XU+n7pbtuOzaSOqbHFWuHUztHHwapaMte3705yPMSFy1XUVRarhU0NUwx1NNI6KRh7HNOD+heDYu"
        "0Ktwp210sVabxLr6/ft5nxtv7KhaTjXt9aVTVdXV7+wyNcswOV8jHLOxy+4c00fQ0qwsIKyNKhrKQhCEKTBUgpoQpCQKaEBUpVBC"
        "MAcKwoTaeKELTCSYQFApjmpVAoQpU0qUxzUIZByTUtKpCFK2nIWMFUDgoYmQKgoBVAqEZYKoKE2lCMyhMKQmEMWZAhSqQjKCpQFQ"
        "QhaoFQCqCgLQkCmqABwqBUpgrExLQkCmqQYKalUEIUgFSnlQYLQkCmhATBSQhCkIQgGCmpTBQg0IQgKByhSqQhSEgU0AJgpIQxKV"
        "KQcoQFIQhQGm0KQcKlvOkGCglJCACVjcVRKxuKGSRjeV0z0brNHQ6Wud6mAa+tqOrDz2RRDJ/O4+pcxPcurtnzvANgTpo+DxQV0u"
        "R91mTj+YLmvKuUvgUaUf65Jd79h1fknTTvXUf9EW+5e05a1lqOXVmqbteZnEmsnc9gJ9rGDhjfiaAvw8rGw4Y0dwCrK7OlTjSgqc"
        "FhJYXYjTOUpyc5cXqVlGVOUZWZjgrKMqcoygwVlGVOUZQYKyjKnKMoMFZRlTxRlBgrKMqcoygwVlGVOUZQYNydG/Uj7Vrt1qc8+C"
        "3iB0ZaTw61gLmH04Dh8a/T6QdlbbdcMro24judO2Zx75Gncd+hp+Na12XTup9pGlJGnB8YxN+InB/MVvDpORtA0xLjyv2QzPm8gr"
        "i76PmPKClOH/AHINP0Z8EfVrLz2xKil/RJNenC9rNDxuX0sK+JhX1RldEcHNH1NOQsgWFpWUIaWZAU1IVBQxBMFJCEKTBUgpoQpM"
        "ckkA4QjKQhCGJYKakJgoCwcoUqkDLHJNQ04KtCFBWCsYKsKGJSoFSDlCEZkBVg8FjBVNOCjIZAU1KoKELaVaxA4KsFCMsJgqQVSh"
        "iUFQUAqgVTEtMFSCmoCwVQKgFfo2Oy1+o7tSWq10zqm4VbxHDC0gFzvScADtyeAHNCpNvCPiQvfaj2K650jaJ7terMyjt8GA+V9b"
        "TniTgAASEk+YAleBVaMqlKdN4nFp9egwVQKhMFYmotCkFUqQpCQKaEBUHKUKAyZQpByjKEKCpSmChMDQllPKAYKalUEICAUIQhSY"
        "KkFNAUhIFNCMFSlAOEIWChJCA02mCkhbjpCkFLKDyQpJWFxWVywvQyRhkK6u0X+55k+C639Mq5Pf2rrDRf7nmT4Lrv0yrmPKn+TR"
        "/wCSPczrvJP6xV/A+9HHTT5LfQE8qGnyR6Anldvk8hWVsXYlpm16u17DbLzSiqoXUs8hj33N8poGDlpB7VrjK230bT9tGn/iNT80"
        "L5m2ak6ez684PDUXhrjwPZs+MZ3VOMllNo6C+oNs+97zflU36y5z276UtGjdZU9vslGKSkfQxzGMPc/Ly54Jy4k8gF2muROk/wC6"
        "HSfBsXz5FwHkltC7r7RUK1WUluvRybXLpZ1O3bWhStN6nBJ5XBJGmMoypyjIHPkv1LJxR6rQugrxtBu/i+1RtDYwHT1MuRFA3vce"
        "89gHE+srpvTfRx0fZ4WG5sqLzVY8p9Q8xxZ80bCOHpJX72xTTEGmNnVnayNoqrhE2tqX44vfIMjPobugL2N9vdHpuz112uEhjoqK"
        "IyyuAycDsA7STgAd5X5TtzykvLq6lbWknGKeFu8ZPhxWur4JHcbN2Rb0aKq10nJrOvBHnm7J9DNj3BpO0bvngyfXzXnL/wBHrRF5"
        "hcKWhltVQR5MtFKcA+djstP5l4Oo6V8YqyKfSrnUgPAy1m7IR6A0gH4yt1aF1za9oNiZdbYZGtDzFNBKAHwyAAlpxwPAggjgQvDc"
        "UdubMirirKcV072fz1frPRSqbNvG6UFFvsx+Wi9Rx1tH2Y3fZvcI4qwtqbfUE+DVsTSGSY5tI/euHd8YJXiMrvnaNpeDWGirxa5W"
        "B0j4HSwOI4smYC5jh8Yx6CVwGDkA8sjOF+geTO2p7Ttm6v04PD688H3/AJHLbY2fGyrLc+jLh4F5RlTlGV0mT5B6vZqfth6V+EoP"
        "nhb66T37X0z+HUfojWg9mh+2JpX4Sg+eFvvpP/tfTP4dR+iNcdtb7dtPwy7mfWX2Nc9se9HP8ZX1RnkvjjX1xroThJn0sKzBYGLM"
        "OSjPOzIOSalpXe3Ql9yq8fDk39Xp0SybrW3+EVPN5wcGoX9Y6e427XNov1DGJOoZNU2mpbIBneblj+RPAg5HmPYv5SV1HLbq2po5"
        "27s9NI6J47nNJB/OEawbLyz+DqLUspnzqgu3+hFYvBdGakvTm4dX17acE9rYmZz65XepdG6c1DR6ptZuNCJPBvCKimBkABc6GZ8L"
        "iME8C6MkeYjIHJVRyb7fZfnacZueG+WP3P5JhUveaA923S/+8lL/AFpq/o/rnXtj2c2QXnUFRJBQGZsG/HE6Q77gSBhoz2FEsmi1"
        "sVXjKcp7qXV+5/KUFNf0Q+uz2Xf7Yq/kMv6q1V0htveh9oWzeey2G4VE9wfVQyhj6WSMbrSc8XDCNLpLVsqMIOUaybXL3ZyKE13b"
        "0Kvcsu/w3N9BAvaX/pK7PNM3uvs9xulTHX0EzoJmNo5HBr2nBGQMFN3TJlT2dB0o1Z1N3PSv3P5wIBwv6Vab2qbNdsE8tkpaqjud"
        "Q5hcaGvpCDI0c90SNw7h2DJHNcr9J7Ytb9m1zoL1YIzDY7q90bqbJIppgM4aTx3XDJA7N09mFHHma7jZ/m6fnac1KPUc/r7aK2V1"
        "xz4JR1FRu8+pic/HqC6V6MOwK3auojrDVFN4TbRKY6Ghf7SctOHSP72g8AO0g54c98at2/7OtmNabA+Zzqmk8h9Ha6YObT/eniGg"
        "+YHI7Qqo9JaOzt6mqtaainwP53VFNNSSmKeGSKUc2SNLSPiKhpX9IrLqbZz0grHV0rIqa6RQjE1LVw7k9Pnk4Z4t/CafjXEW2zZf"
        "Jso1rNao5HzWupZ4TQzP9s6IkjdceW80gg9/A8M4UccGu6sHRgqsJb0XzNeKl9FroJrvcaOgpm71TVzMgjb3uc4NA9ZX9L9V6ktu"
        "x/Z9DWSQ9ZQWplNRxxB24S3eZGMHB5Ny78VRLJhaWXwiMpSluqPVk/mSDhWu/OlVp0X/AGRVlXG0PmtNRFWsI5ludx3xbshP4q4B"
        "aexVrBrvbR2tTcbzpkytKoLufo/bX9KVmm9JaJhrZjqFtM6IwmneG7zGue7y8Y9q0rZ2vdpunNmsFFNqGqlp461zmQmOF0mS0An2"
        "o4cwru88ntp7Kpzped86sc9OHrP5lqgV/RG06n2Xbao5rfB4ru8wYS6mqqYsna3tc3faHcO9vLvXKvSC2Ls2W3amrrS6STTtyc4R"
        "CQ7zqeQcTGT2jHFpPHAIPLJxccannudmypU/O05KUelGmwV9FLSVFZJ1dNBLM/nuxMLj6gtydHfYtDtMuVTdLyJBp23PDHxsJaaq"
        "UjPV7w5NAwXY48QBzyOpNS7SdnuxaGG0SdRRS7oc23W2nBeG/dOAwBnvcQT50UcrLJbbN85T89VmoxP591dvq6BwbV0s9O48hLGW"
        "E+tYAV/QPS+27Z7tQqPEbZQaip8ltDdKcAT+YZy0nzZye5aL6R2wqh0fTDVemoTDanyCOsoxktp3OPkvZ3MJ4EdhIxwOAcdMoXGz"
        "N2k61GanFcTnIFMFQCqBWJ8koLcWwDV+n9C32uvN0tN5uVwEQhpG26mbKIg727jl7cOIAAx2F3evWdHPYZQ6vpTqrUkJmtbJDHR0"
        "ZyG1DmnDnv72g8AO0g54DB3pqjbXs/2Yz+I3SgVFN5LqG2U4Ig8xxhrT5s58yyjHmz7VjYuCjdVJqC5Z19+o5c267Wa/aPeoYGUt"
        "Zb7FRjNPSVTNyR7yOMjwCRnmBxOB6StTAr+gem9pGz7bLDNaGdRWSlpc633GnAeW9rmg5Bx96SR5lzJ0gdjUWzW5U1zs/WHT9xeW"
        "MY8lxppQM9XntBGS3PHgQeWTZLmY39lNp3UZ76fF9BpdC7S6IfHZtdPhiX6CBetvnSD0Jp28Vtpr7jUR1tFK6GZjaWRwDgcEZAwV"
        "NxYzkU9lU5UY1qlVR3ulfucBIBwv6E2jU+zzbTSVVFAaG79W3MtNVU5bKxp4bwDgD+M3kSOOVyLty2Xt2Y6rZBRue+zXBhnpHPOX"
        "MwcOjJ7S0kce5w7cqOOFk0XezXQpqtCanHpXuzWSYK7r+ub2cf7Vqvkcv9i2Bo7Wln15aDdbJO+aiErod58bmHeABIwePaFkoJ8z"
        "1U9jUar3YV031L9z+aqF3vdukPoKyXWutlZcqllXQzvp5mikkcGvY4tcMgceIK0TrfXVl2g7e9AXOxVEk9JDPQU7nPidGQ8VbnEY"
        "I7nhYuKXM81fZ1GkluVlJ5Sx7s5+VLtnpV+5cz4Rh+a9eJ6HH+uv8i/66bmuBPZe7dxtd/iuOOpvhnq6Tl0FNf00ob5S3C63W2xb"
        "4qbY6NswcBg77A9pHHljhxxxBX88Nodn9j+u9R20N3Y6eumbGPvC4lv/AAkJKODHaGzfgkYzU95NtcMe1nmkLpTog2frb1qS7ub+"
        "16eOla7/AO44uP0Y9a6gtV8pbxU3aCm39611XgcznAYMnVRyHd48QBIBxxxB9JsYZWTbZ7G+E0o1XPdznTGeHpP5mg5QvZ7XvdQ1"
        "Z8IS/OXTex3YVZdJ2OmvmpaSCpvcsYnc2rAMVE3Gcbp4bwHNx5HljGTio5eDx22zqlxWlSg9I8WcfU9puFVF1sFDVSxfdxxOcPWA"
        "vmex0b3Me0te04LXDBC7eufSX2f2qsdSRVVZVtjO6ZaSnzEMdxJGR5wCO5fuPpNA7dNPyTMZTXGIeQZ2M6uppnY7yN5p9PA47Qst"
        "xcme5bHpVMwo11KXR7s4DTBXq9o+havZ3qysslS/rWMxJTz4x10Tvaux38CD5wV5NYHw6lOVOThNYaKQkCmoYAFSlMFCDQhCENOA"
        "pqVQOVvOlBCEioBPWBxWZxWB/ahnEwPXWGi/3PEnwXXfplXJ711hoz9zvJ8FV36ZVzHlT/Jo/wDJHuZ13kp9Yq/gfejjdp8kegIy"
        "oafJb6AnldseQrK270bD9tKn/iNT80LUGVt3o1n7aVP/ABGp+aF8rbv2bX/DLuPbs363S/Eu87MXIfSh90Sj+DIvnyLrxcg9KI/b"
        "FpPgyL58i/N/Iz7TX4X7DrvKH6m+1Glsoznh3qcoyv104Q7x2Qahg1Js5sFRC9pkp6dtJO0HiySMBpB+IA+gheqvNnotQWqstdxh"
        "E1DWRmKWMkjeafOOR7c+ZcLbPdpd62cXJ9TbXMmpJ8eE0U2ermA5Hhxa4djh+cLpnTfSP0XeYmC4Tz2aqI8plVGXR580jARj0gL8"
        "m215N3trcyr2sXKDeU48Vz4LXTpR3Oztr29aiqVZpSSw88H7Neg8bfeiox0j32PUZYwnyYa+Dex5t9nP8leXdsi2saDgqfENXK+n"
        "kIfILRW7rnkDAJYd0k47srp+0atsF/x4qvdurSeTYKljnfk5z+ZfskdhHrWmPlRtOj/CuUpronH/AF6zY9i2dT59HMX0xf8As4Lr"
        "doevrfUy0tZqS/09RGd18M872Pb6WnivG5XeG0rZrbNo1llp6iKNl1jYfA63HlxP7AT2sJ4EHvyOK4QnhkpZ5YJmFk0T3Rvaf3rg"
        "cEesLvfJ7atttClKVKmoSWN5LHofLK49hzG1rGtazSqTcovg36ycp5UZRldEfJPWbMz9sTSnwlB88LfvSg/a+mPw6j9Ea0BszP2x"
        "dKfCcHzwt/dKD9r6Y/DqP0Rrj9q/blp+GXcz6q+xrntj3o59jPJfVGvkjX1xLoThZn1MWVqws4LM1Q8zLC726EnuVXj4cm/q9OuC"
        "QV3t0JPcqvHw5N/V6dZR4nv2X9Y9DPS7Dr71+utr9kc7jSX91W0HulBacfzI9a4w2+2P2O7Y9YUYbuskrXVTR2YmAl4flroPZBff"
        "F3Sx2hW17sR3R9Wxre+RkjXj/hD14zpm6akj2oWWtp4iTeKFkQA/fyse5vzXRhHqjfdfxLXPOMn3/wCjoXYVBHoPo82q4ztA6ugn"
        "u0pPDeDi+UH8jd9S+vowzyVWw/TE8ri6WV1Y97j2k1cxJXybd549CdHm62+ncGiOggtUIHDea4sjI/I3vUs/RZ9wfSf8r/rcyq44"
        "Po0/mVoUuiPtXgcN6A927S/+8lL/AFpq7T6V9huuo9ljKOzWytuVYLjC/qKKB80m6Gvyd1oJxxHHzrizQHu3aX/3kpf601f0P2p7"
        "S6DZTpht+uNHU1dOahlP1dNu7+XAkHyiBjyVI8GfPsIxlQqqbwj+cg2Ta/8AeNqf+iZ/1F+RfdJ3/S/g/jyx3O1eEb3U+HUkkHWb"
        "uN7d3wM43hnHLI712T9e7pP3uXv1xfrLR/SI23WnbJ7G/FdurqPxV4T1nhW55fWdVjG6Ty6s+sLFpHir0LaEHKnUy+g3/wBCn3K7"
        "v8NzfQU65P23e69rT4Tm+cusOhT7ld3+G5voKde01B0ldnemb3X2e43Spjr6CZ0EzG0cjg17TgjIGCssZR9CVCFW0pqc93t90ced"
        "G7S16vm1fT1bbqWfwO3VHhFVVBpEccYByC7ll3tQO3PpXQHTYu9LForTtpc9vhtRcvCmszx6uOJ7XH0ZlattaF25aI2jXV9qsN1d"
        "LcGRmUQTQPiLmjGSC4AHGeXNcZ9JnSWrdO63hrdU3pt58ZRF1JVsj6prWMODEI8kM3d4HAJzvZySSj0WhrqwjbWco0nvKT1fJHYe"
        "z9/sX2A2OrpGta+m082taMcN8wdaT+USv5sTVEtVPLPPI6SaVxe97zkucTkkntOV/SSxeV0c7du8f8koxw/iYX81lJcjTtX6NJdX"
        "gbI2I7RINmG0Cjv1a2rktoilgqoqQNMkjXMO6AHOAOHhh4nsXs+kTtm03tebp59koblTVFtM4ldWxRs3mv3MAbr3ZwWHnjmtM6fs"
        "Nz1Tdae02ejlrLjUb3VQRe2futLjj0BpPxL9XVWz3VGh46aTUNlqrcyqLmwmcAb5bjOMHsyFNcYPBGtWVB00vm89Ozme46NGnPZH"
        "thsQezegtxfXyebqx5B/nCxb56aWofBdLadsTH4dXVb6p4H3MTcAHzEyg/ir8XoT6b4ao1HIz+DoIXY/HkH0SXSa2c672ga+pprJ"
        "p6prLTQ0TII5WSMDXPLnOeQC4H98B+Kr/SfRp05Q2e9xZcn79xvDQ80W03YfbI6h4eLtZzRTvPH7IGGJ5/KaSv5wVNNLRVM1NOws"
        "nhe6N7Tza4HBHrX9A+jPYNS6U2fzWTU1smoJ6WtkdTtkc129E8Ndw3Sf3+/61yL0hNN+xna7qWnazdgq5hWxcOBEoDzj0OLh8SS4"
        "JmO04Snb0qslrwfv6D9DoxnO2/S38q/qsq3T01P+6NIfxio+axaU6MXu4aW/lX9VlW6+mr/3RpD+MVHzWIvomFv9m1e3/wATmDQl"
        "8qdOazsN1pJHRz0tZE/LTjLd4BzT5iCQfMV3B0prfHW7G7tO9uXUM9POw9zjK2PPqkPrXBdkBdebc1oyTURgD8YL+gHSacG7EtTA"
        "nBcaUD5TEkeDGznm1rp9HsZ83RcoY6TYzZZmNAdVzVMzyO1wmezPqYPUuHtaXipv+rr5c6yR0lRVVkr3EnkN44HoAwB5gu6ujMQd"
        "iWmMHl4Vn5VKuBLzkXi4A8CKiT5xUlwRNpaWtBLo9iMVNUS0s8VRBI6KeFwex7DhzXA5BB7CCv6I68d7JthV6qqprXPqbC6tcMcN"
        "8Q9aD+UAv50Ar+it68jo/XDe4f5KvHH+KFIcybH1jWi+GPE/ncDhUCpQCsD4TP6KaDd7GthllqqVrWvprC2saMcN8w9af+Ilfz1n"
        "qJaueWonkdJPK4ve95y5zickk95K/oRZTv8AR/t+7x/yWjHD+KBfzxBWc+R9zbOkKMeWPA/f0ZeKmw6sslypJHMnpquJ7SDz8oZH"
        "oIyD5iu2uk3RR1Wx28zPaC6kmp5mE9jjM1mfU8+tcKWbjd7eBzNRH84LvTpJEDYtqbPb4Nj5TEkeDGzNbS4T6PYzy3RC9zW6/DEv"
        "0EC5j2wn7aervhGb5y6b6IPua3X4Yl+ggXr75cNjsd4rWXlmjzdmyuFT4VTwOl6zPHeJbkn0q4zFHqna/CbGlHeUcdJzL0X6Gvqd"
        "rFBU0rJDSUsE7qt7R5IY6NzWgnzvLeHm8y2R0x5ofB9IQkg1G/UvA7Q3EYPrOPUti1O2bZVoK2Si01ltDT5Qo7NTtzI78QBoPncQ"
        "uP8AaftGrtpuqJrxWM6iBrRDS0wdkQxAkgZ7SSSSe892Ao8KODzXDpWlk7aM1KUnnTlw8Dx67d6KXuWv+EZvmsXEIK7e6KXuWv8A"
        "hGb5rFKfE0bD+tehnJu033SNY/DFZ9M9PZl7pGjvhij+mYltM90jWPwxWfTPRsy90jR3wxR/TMWPM+d/6n/7e0606VfuXM+EYfmv"
        "Xiehx/rr/Iv+uva9Kz3LmfCMPzXrxXQ3/wBdP5F/11sf0zoqv2vDs9jNkabvHUdIPWtpLsCrttJUAHtMbWj9Ev5lz10oLP4s2qVN"
        "SG4bcqWGp82QDGfo/wA62Ld7x4m6W9I5zsRVUUVK/wA+/Bho/K3Vi6YFnzHpe8NbyM1LI707rmD8z1Japmq9/i2lVf2Tff8Auev6"
        "Kln8A2bTVzm+Xca6SQO72MDWD/ia71r9fYBePZBadZXQO3mVmpauVh+9LIt0erC+iw/5A9H+Cb/NzUdkdU45Ylewvx6d9+F5jokc"
        "dnF0+F5foYVktMI9tv8Awp29Doi2/V+5ojUlFHcukPPRytDoqnUUcT2nkQ6doI/Ouk+kvdqi17K61lNI5hraiKmkLTg7hJcR8e7g"
        "+Ylc63QgdJZhJwBqeH+sNW++lSPtXt+EIfmvWK4M+dbaW9010v2nFK3Z0W7tUUW01tFHI4U9fSSslZngd0b7T6Rg+s960itvdGcE"
        "7W7Z5oKj6MrCPFHxtntq6p46Ue+6X9FHHcNJ1gaOtmiqYnO7SGGMgf8A5D61zOun+mIRnRgzx/ZnD+YXLys/pG7bKXw2fo7kUqUo"
        "BwsD5mCkIQhBgoSQhMGnUIQt50gzySQhAS5YX9qyuKwvUM4mB66w0Z+53k+Cq79Mq5Pf2rrDRn7naX4Krv0yrmPKn+TR/wCSPczr"
        "vJT6xV/A+9HGbT5I9ATysbT5I9ATyu1PIXlbe6NRztTp/wCI1PzWrT2Vt/o0nO1Sn/iNT80L5W3Ps6v+F9x7tm/W6Xau87PXMHSH"
        "0NqbUuuqWss9ir6+lbb4ozLTxbzQ4PeSM9/EetdPpcF+P7K2lU2bcfCKcU3hrXrO+vrON5S81N4XHQ4H+pLrv3pXf+Y//qmTZXre"
        "njfNNpO7NhiBe8mDgGjie3uC764eZfDe8eJbny/as30bl1EPLi6lJJ0o+vxPiy8m6CTe+/V4Gu6LYRs4rqOmqorGXRVETJWOFZNg"
        "hzQQfbedeL2sbAbXTaX8M0XZ5G3OllEksLJnyPmhwQQ0OJyQcHA4nBWfo97XqG42Og0neallPc6OMRUckrsNqYh7VmT+/byx2jGO"
        "OV0AeBweBXzLq+2psm+3atST3Xom21Jfnwfq7UeyjbWV9bb0IJZXJLKZ/Nh8M0FR1b4pI6hhxuuYWvafRzBXZHR3dqp+j6k6jNWa"
        "brm+LzW563q93yvbeVuZxjPnxwW3DFG6TrHRsMn3ZaC7181ZOTxOSVt215UfGdv5jzKjw1zl+jRY8DDZ2xfgdXzvnM9WMfnqxt9s"
        "30hfzw1tPFUaz1FNAQYZLjUOYRyx1jl15tj2t0GgbNU0NJURy6lqYyyCnacmnyMda/uxzAPEnHZlccWTTl41PUvgtNuqa6Zgy/qm"
        "53c9rnHgPjK+55E2NSlCpd1FiMsJZ544vs6PSfK8p72kt2m5L5uW3yR+blGV+lfdN3jTNQ2nvFtqaKV4ywTMwHjzHkfiK/Kyu+TT"
        "1Ry8JxqRUoPKfNHrdmR+2LpT4Tg+eF0B0oP2vpj8Oo/RGufdmR+2LpP4Tp/nhdBdKH9r6Y/DqP0RrkNq/blp+GXcz7C+xrntj3o5"
        "8j5L6o18ka+uNdEzhJn0sWZp4rAw8lnCh52Wu9uhH7lN4+HJv6vTrggLfmxHpK/Ub0pWWL2MeNfCa59b1/h/Ubu9HGzd3erdn/N5"
        "znt5cFU8M9VhVhSrb03hH0svvsc6X0tcXbrDqN9O93c2VxicfU8rqbbRs9l1nqjZhXRUz52Wq9h1SWMLgyEt6xxd3NzA1uT2uA7V"
        "/PzV+sJNUa5uuqYac0U1bWurWQiTrOpcXbwG9gZwe3AXTw6dpwM6BBPbi7/+wqmj021zRSqQqvCbyuJ6HpvX3wXRem7M12HV9e6o"
        "IHa2JmMeuVvqWw+iz7g+k/5X/W5lxftx21S7aLtaqw2jxVBboHRNg8J6/ec52XO3txuMgNGMdnNe92WdLH6mmg7Tpb2IeMPF/W/s"
        "rxl1W/vyvk9p1TsY38czyTKzk2U72l8LlVk/m4wuPUau0B7t2l/95KX+tNXb3Se0ffNcbNGWvT9vkr68V8MvUxuaDuBr8nyiB2hc"
        "A6f1N4j1va9S+C9d4Dcorh4N1m7v7kok3N7BxnGM4PoXUf19X/gH/wA4/wDYUi1jU0WdahGlOnVljeNIjo4bUvehV/zsX66/M1Fs"
        "V17pGzVN4vWnKmjtlLu9bO+SMhm84NbwDieLnAfGugfr6v8AwD/5x/7C8ftS6V/1S9B3bS/sR8X+MOq/ZPjLrdzclZJ7Tqm5zuY5"
        "jmmEa6lKyUG4VG3y0/Y3F0Kfcru/w3N9BTrk7bf7r2tPhOf5y9xsT6SX1HtK1li9jPjTwiufWdf4f1G7vRxs3d3q3Z/zec57eXBa"
        "n1xqb2ZavvWoPBfBPGdU+p6jrOs6veOd3ewM+nAUb0MbivTna06cXquJtHom+7XaP4vU/ROW0unN/qF/L/8A9dc67Jdof1LtbUep"
        "PF3jHweOWPwbr+p3t9hbne3XYxnPJep257c/q0+If+wfFPinr/8ATOv63rer+8bjHV+fOezCZ0wKdemrKdFv5zfgdbdGvVVDrfY9"
        "brdI5klRa4jbKyAniGgEM4dzoyOPeHDsXK+0Hoz630pfaqG02eqvNnc8mmqqNvWOLM8A9g4tcBwPDHcVrzQO0TUGza9tu2n6wwTk"
        "bssTxvRTs+5e3tH5x2ELpqz9N+LwZjbxpF/hIHlPo6sbjj3hrm5HrKuU1qblXt7mlGFw92UeZfRh2C6h0zqf2XanonW7waF8dFSy"
        "kda57xuue4D2oDS4YPEk+bj57poatprnqixadppGvktEMk1RunO6+Xdw0+cNYD+OFl1f007tcKKWm0zYIrZK8bvhlVN172edrA0N"
        "B9O8PMuYq24VV0raitraiWpq6h5llmlcXPkcTkkk8zlG1jCNdzcUIUPg9vqnxZ/RTo2aebpfY1YjKBHLXtfcZnHgMSHLT/Nhi1LU"
        "dN6OOolZDogyQtcQyQ3XdLm54HHU8M9y87cel+JtG1WnbdozwFr6B1BBP4z3+oHV7jXbvUjOBg4yOS5iBRy6DZcbR83CFO1lwWun"
        "ijvTZL0n4dp2soNOS6b8VvqIZJIpvDuu3nMG9u7vVt/ehxznsWvemppzqrnpnUUbOE8MlDK4dhYd9nr33+pc5aC1bNoXWFn1FBD1"
        "8lunEph39zrW4Ic3ewcZaSM4PPkts7X+khBta0m2xy6T8AkjqWVMVT4w63cc0EHyeqbnLXEc03srDMHfRr2s6deXzuWngj9Do1bM"
        "9V0u0TSmq5rNMzTxZUSCtL2bu66nlY04zni4gcu1bj6VOgdSa7tumotO2qW4SUk07phG5rdwOazHtiO4rVOgulp7CdH2fT3sQ8L8"
        "XQCHwjxl1fWcSc7vVHHPvK9H9e7/AOBf/Nv/AGFVjGDbRq2UbZ0JVH87V6Pjp1dR+Nsc6MWp2art151bSR262W+ZtQKd0rJJah7T"
        "lrcNJAbkDOTnHDHHI950wNa01BpKh0rFK11fcp21EsYPFkDMkEjsy/GPwXdy8DfumfqGtpnxWbT1BbZXDHXTzOqXM84GGjPpBHmX"
        "PN8v9y1Ndam6XetmrLhUu3pJpTknzeYDkAOAHAKNrGEeerdW9ChKhbZe9xbOy+iFrKmuWiqvTMkrRcLVO6VkZPF0EhzvDvw8uB7s"
        "t71rDbN0cNTUGqbjdtM2590s9fM6oEdPgy07nHJYWcyMk4Izw5rRGnNSXXSd3prtZq2WjuFOcsljPrBHIg9oPArpfTnTOq4aZkV/"
        "0zFUztGDUUVR1Yd+I4H53xKZTWGWlc29xQjQuXhx4M1/s/6N2s9UXmmZd7VUWezteDUVFWNx+52hjD5RcRy4YHaV0z0i9VUOi9lF"
        "dbY3MjqbpGLfSQA8dw4DzjuDMjPeW961heumiDTvbZtKbtQQd2WtqstafOxrcn8oLnHWmur5tAvL7tfq11RUkbrGAbscLPuWN5Af"
        "p5nJTKSwiyuLa1oyp2zcpS5n4IKpQCmCsD4TO/Ojtqmi1nsoobbI5klTa4zb6uAnjuDIYcdxZgZ7w7uXNevujhrHS95qW2i11F4t"
        "Dnk09RSgPfu9jXsHEOHacYPYtd6L1zfNAXhl1sNa6nqAN17CN6OZv3L28iP0cxgro2zdMwCnYy8aVJqAPKko6rDXHzMc3I/KKzTT"
        "WGfbVza3dGNO5bjKPM8vsc6O2pa/VFuuupbdJbLPQTNqHR1GBLUOachgZzAyBknHDktndLXWFNbtG0mmmStNfdJ2yvjB4thjOcnu"
        "y8NA78O7l4/UPTIq5qZ8Vh01HTzuGBPWz9YG/iNA+d8S5w1BqO6aqu1RdbxWS1lfUHL5ZD6gByAHYBwCNpLCMK11bW9vKhatty4s"
        "7G6IHuaXX4Yl+ggXMW2I42qav+EZvnL2Ox/pBfUp01VWb2O+MvCKx9X13hvU7u8xjd3d6t33Gc57VrHWWovZbqq73zwbwbxjUvqO"
        "o39/q945xvYGfTgKNppI03VzSqWdKlF/OXE/HQoBwqysT5Q13B0UDnZY/wCEZvmsXD63hsn6Q/1L9LOsfsb8Y5qH1HX+HdT7YNGN"
        "3q3fc889qsXh6n0dlXFO3r79V4WGa92mn7ZOsfhis+mensy90jR3wxR/TMX4+pr17JNSXm89R1HjKsmq+p397q+seXbu9gZxnGcB"
        "GmL17G9S2a89R1/i2shq+p393rOreHbu9g4zjGcFY8zx78fP7/LOfWdl9K33LmfCMPzXrxPQ2/11/kX/AF14bat0hvqnaWbZPY54"
        "vxUMqOu8N672ocMbvVt+6557F+Jsb2y/Uk8df9ieM/GfU/6V1PV9X1n3js56zzYwtm8t7J9mpfUHtGNdS+alxw+h+k/f293V9j29"
        "G5x536F1HUNxzyxrHf8AouituukZde6Cp6WhjfUTNrqWaPqmlx3XP6tzhjsDZC4nsAJXGe03XX1RtX1WoPAPAOvjjZ1HXdbu7rQ3"
        "O9utznHctzWDpbyWaxWy3TaT8Klo6aOndUeMdzrSxoaXbvVHGcZxkomtcmNveW7nXhVliM3po+s2n0lboyybI6ukixGK6eCjYB2A"
        "HfIH4sZC/I6JHub3T4Xl+hhWi9sG3OXavbrZQiy+LIaOZ0zv2V13WOLcD943GBvd/NfZsi2+/Us03VWf2PeMuvrHVfXeG9Tu7zGN"
        "3d3q3fcZzntTeW9k2PaNB7QVZy+YljOH/s85tIuMlo2yX+4Q466ju7p2Z+6bJvD84XZOqbNbds+zR8NFVNFPdIWVFLUc+qkBy3eA"
        "7iC1w5jiOa4N1fqH2V6pu978H8G8YVD6jqd/f6veOcb2Bn04C9Ts32yaj2ZvdFb5I6q1yO3pKGpyY89rmkcWnzjge0FSMlqeOzv6"
        "dKrUhVWYTyVdNh2v7VXPpX6aragg4EtK3rY3DvDm8h6cFb+6PGxW6aMrqjUeoom09fJCYKak3g50bXEFz3EcATgADPInK/MpumDQ"
        "OhBqdK1LJscRFVtc3PpLQvH606VWoL7SS0dhoI7LFIC11R1plnx967ADfUT3EKrdWpvpfFtrPz0ZuTXBe6R83Sl1dT3/AFzTWqkl"
        "bLFZYTFI5pyBM85eM+YBgPnBHYtGZQ+R0r3Pe4ue45c5xySe9Ja28vJ8W5ru4qyqy5lAqsqAU1DzlAqljTBQhaFKEBp8IUqluOkY"
        "IQkUBDliesrlheqZowPXWOjP3OsvwVXfplXJr11jo39zrL8FV36ZVy/lT/Jo/wDJHuZ13kp9Yq/gfeji9p8kegJ5UNPkj0BPK7TJ"
        "5Csr9jTOqbro+6tulmqvBq5sbohJ1bX+S7mMOBHYvxcoysKkI1IuE1lPimZRlKDUovDRs/64PaL74P8AlIf1UfXB7RffB/ykP6q1"
        "hlLIAzngvD8UWH3EP0rwPT8PuvvZfmzaH1we0X3wf8pD+qsc+3zaDUwSwy3/AHo5WOY4eCw8QRgj2vcVrMOB5EH0J5RbJsFwoQ/S"
        "vAO/uudWX5sYwAB2Be90/to1zpmFlPRX+eSmYMNhrGtqGtHcN8Ej4ivA5RleqvbUbiO7XgpLrSfeaKVapSe9Tk0+p4N0M6T+umsD"
        "XCzuP3Rozn8zl+De9vWvr3E+KS+uo4XDi2hibBw/CHlfnWDSGxjVGrOrnNN4tt7+PhNaC0uHe1ntnfmHnW+9IbE9MaWMc80Bulwb"
        "x6+saC1p+9j9qPjyfOvlPZ+zKEt6NGOexHytpeWUbVOEqznLoT73w9vUc8aW2Z6p1zL4TTUkjKaV28+vrXFrHHtOT5Tz6AV1XoXS"
        "NPonTVJaIXMkkZl887WbvXSHm7HqA8wWDVm0fTeimFtzuDPCgPJo4Pskx826Paj04C03W9JmvNz3qKxUotoBHV1Erutd5y5vAejB"
        "9K9EnVuFhLCOLuam1dvR+ZT3aa1XLPpfH0aG1dsVuo6/ZzfHVjWfsWHwiF55slaRukenOPPlcak8V7/X+1+869pmUMsUNDbGuDzT"
        "wEu6xw5F7jzx2DgFr7K9dtTlThiR0/k9s6vYWzp13q3nHRwPW7MT9sbSfwnT/PC6D6UP7X0x+HUf9Nc9bMT9sfSfwnT/ADwuhelD"
        "+19Mfh1H/TXM7U+3LT8Mu5nZr7Gue2PejnyNfXH2L44+a+uPsXQnCzPpb2LM1YGLMOSHnZkCalpVIYAqUoCEKBwqUpgoQYOFSlMF"
        "QDQhCEKVBQE0MSlSlMIBqlKYKEY1SlMFCGQFNQCqBQFhUCoBTBwoQyAqljCoFDFlBWCoQChDKCqBWMFUChDKChSCmChCwVYKxKg5"
        "QjMioFQCmhjgsFNQCmChCs4Vh2VGUIQyJgqAU8oC1QOVAOU0BSpRlNTBCwU1GUw5CFJ5U5TQhSApVICkwVCEJgyIUAp5QhSeUghC"
        "YHlVlQmCoCgU1KYKEKBQkhBg0+mCoBwqW86QZ5JZRngkVAJ3IrC8rKeRWFypkj53811lo39zpL8FV36ZVya9dabK2G97CXUMfGV1"
        "NXUuPvjv4+cFy/lVpb0pPgpx7mdd5KfWakemD70cUNPkj0BPKhuQ1oPA4GQnldnk8hWU2guc1rQS5xw0AZJPcAto7MdjFVryiF2q"
        "64UNp6x0bdxm9LMW+23c8GgHhk59C6M0rs401otgfbLdGKlo8qrn+yTHz759r8WAvNVuoQeFqzndpeUtrZSdKPz5rkuC7X4ZObtJ"
        "bDdU6l6uepgbaaF3HrawEPcPvYx5R+PC3rpLYlpbS5jmkpjdK9vET1oDgD97H7UfHk+dLV227SuljJDHVG6V7eBgoiHAH76T2o+L"
        "J8y0Rq3bpqnU3WQ004tNC7h1VGSHuH30h8o/Fhef+PW6kfF/61tj/wCKm/R/+n3HTeoNn+mdTMxdLLSSvxgTMZ1cg9D24K1PqLo0"
        "0su/LYLxJA7mKeubvt9Ae3BHxgrSNh13qTTMm/a7zWQNJyYzJvxu9LHZBW19O9Jivg3I7/aIapnIz0Tuqf6Sw5afiIV8zWpfQeTL"
        "4o2zs7Wzq78ej9pafk8n5dl6Oepqy4PiulRR0FHGcGdknXOkH3jRj/iwt4aQ2TaY0cY5aSh8KuDf9Mq8SSZ+9HJvxD415a5dI7St"
        "PbhPQwV9ZWOHCmdF1W6fvnnIx6MrSmsNsuqNX9ZC6r8X29/DwWiJYCO5z/bO9YHmU3a9bSWiMXb7b2t8ys/Nw58vVxfp0OkNYbXt"
        "L6PMkU9b4bcG/wCiUZEjwfvne1b8Zz5loLV+3jU2pOsgoXiz0DuG5SuJlcPvpOf5OFqzPcjK9FO2pw14s+7s/wAmrOzxKS35dL9i"
        "4d76y3PL3Oe5xc5xy5xOST3k9qWVOUZXoyffwVlGVOUZTJT12zA/bH0l8J0/zwuh+lF+19Mfh1H6I1oLY3RPuO1PScLASW1zJXeZ"
        "rAXk+pq3n0oaoOqNMUoPlNjnlI8xLQPmlcjtN527apcoy7pH1OGxrhvm13xNCxr6mdi+SPsX1s7F0Zwsz6WcgszeSwRrM1Q87LC9"
        "loXZzdNoDbi63VNDA2gDDKat7mg7+9jG60/cHOcLxoW7dhlJNX6W2i0lNGZKioomRRsHNznRzgD1lYzeI5R5LupKnSc48dO9H5v1"
        "v9//ANtae+VSf3a8vp3ZzdNTapuenaOpoW1luEpklkkcInBkgYd0hpJyXAjgOC+j6j2t/e/P/OR/rL1vR0hfT6/ukMrd2WO3Ssc0"
        "9hE0QIWDbSbzk8860oUpzVRSaXL/AGaccCxxaeYOEJzf56T8I/pWxNmGz2h11bNTS1VTNBU22FjqYtkayMuc2Q/ZCWnycsHLHDK2"
        "OSSyz11akacN+XA12CmtwW/ZbpTVVrrYNLakqK7UFFF1jopY+rimx9yHNBAJ4ZycZGeayWLZfoy9yvscOqp5NUxsdvNjj/Y++0eU"
        "1uW+WB3h3HGVjvo0O8prOc6cdH+fYacBTX6bNO18mojYI4g+5CpNJuA8OsDt08e7I5rZVToLZ7p2fxZqDVtX44ZgTCjhJiicew+Q"
        "7l6QfMEckjZOvCGFxz0LJqJUFsG87MxY9XacoH1vhljvk8Laetgw0vje9oOOYDgHA9o4g+Zei1Ts70Fo2sraa56huIqXR79JSxAO"
        "e0bvDrHBmOLs4HDhhTfRrd1T0Sy89CNOAql77Q2ziLUNqq79erk216fpHbrpyMukdwyG+sDPHJOACv34NmukdWU9VFozUdTUXWnY"
        "ZPBa5m71oHcd1uPTxxkZwjmkSVzTi2ny46aL0mowU17PQmhY9T1dxfc7jHbLdbGF9U9+Os4ZyA092Dk9nDhxXrIdmukdWUda3Ruo"
        "KypulJGZfB6uPAlA7vIbjJ4Z44yM81XJITuacHh92iNQgpr9jSmmazV19pbTRbrZZiS57vaxtHEuPoC2LcNC7ObdVPtE+r6tl3Ye"
        "rfL1QdAx/ccN4ceflcO0o5JaFqV4QluvV9SyeH1Doq4aZtNkuVXNSvgvEPXwNhc4ua3da7DstABw8cie1edBW6NuFvfadMaEt8j2"
        "SSUlM+Bz4zlri1kTSR5uC/It+zWx2axUV21re5rf4e3fgpKZmZS3AOTwd2EZ4cMjJzwWMZ6ZZppXKdJTnxeeHaawBVArYupNnNtG"
        "nJNSaTu7rna4HbtRHK3dlh5cTwHeMjA4ceIWuVmmmb4VI1FmJYKoFbOtezex1Oz+06mr7tPQiaZwq3vw5gjD5GgMYG7xcS1vaeZK"
        "+us2WWK42qlvenr+99kbIW1s1YBvU7QMudjDSTyG7jJ3h2LDfRpd1Tzh9OOHM1QCmtoV2zvTd00tcbxpO9VNZJbGl9RFUsxloGSQ"
        "N1pHAEjnnGF5HRWkKnWV1dSRTMp6aFhmqKmT2sTBzPnPmWSkmslVeDi5cMcTzwOF+pp+yVWpbvS2ui6vwmpcQ0yOw0YBJJPoBWwa"
        "bRezy61DLZbtV1njSQ9XG+WH7C9/IAeSOZ++9GV5Sh03V2jX9DYqyWamqG1sUDpqZ+68Bzhh7HdmQcgqb2TBV1JNLR45o/Lv1kqt"
        "N3iqtdb1fhNM4BxjdlpyAQQfQQvgXutQaGqKvaXV6cttRUVMhcxxqKyTffgxte5z3ADOMns7hzX7U2i9n1tqzaq3VdX4zYerfIyM"
        "CFj+4+SQOP33DtIU3lhEVxFRWdW1nRGrAU16LWujqvRd2FHPI2eCVvWQVDBgSM9HYe8LYWo9muitJ1kXjW+3CGmmj+xQt3XzOcCd"
        "45DMBuN3s554o5IsriCw1rnhg06CvRz6QraPS9PqCpnpYaWpfuQQPc7rpePMN3cY5nJI4ekZ+7SGhRqysuEwrBR2OgJdLVyjiG8S"
        "B2ccDJ7vzL1g0xpXWLorXatY3GouNOwspo6/edHgD2rAWjA4DgOwcjhHI11K6i8Llx0NTZQF9Fyt9RaLhU0FWzq6mneY3t84/wDR"
        "fMCsjesNZRaYKgFPKAsFUoBTyhClQKjKYKELympTBUBQKalPKEwUCmoyqDsoQvKAVGU0IZEKAU0BSoFY0ZQhkRlTlMFQhaFKFQUj"
        "KlMFQhYKFKEBqFMFSCmt50YzyRngjPBJAS5YnLK5YXIZxMD+C6M6MGpmGC8aekeOsa4V0DSfbDg14+LDD61zo/tX6ektT1ejtRUF"
        "5ojmWlk3iwnhIw8HMPmIJC+Ztex+HWc6C4vVdq4eB9fZF78Cu4VnwXHsfHxHth0c/RGv7tQCMtop5DV0jscDFISQB+Cct/FXhMrt"
        "zaHo217dtB0Vzss0YuMTDLQTvOME+3gk7skYPcQDy58V3S2VtkuFTb7jTS0tdTPLJYJW4cx3n/t5HsWOwNqK9t1TqaVYaST46aZ9"
        "PPrPv7Ts/MVd+GsJap8teXvyNh7P9tV20FZ5bVHQ01dSb7pIRM9zDE53PiObSeOPzr8TVu1DU+sy9lxuL2Ubjwo6b7HCPSBxd+MS"
        "vGZRlfbVOClvY1Ofjs20jWdwqa33z9+HoKzj0J5UZ86MrM9peUZUZRlAXlGVGUZQF5RlRlGfOgLyjKjKMoC8oyoyvVaA0Bd9ot+j"
        "tdqjwwYdU1Tx9jpo/unHv7m8yfjK11q1OjB1arxFcWZ06cqklCCy2bi6KejpKu93LVM8Z8HoYzSUxI9tK/G+R+Czh+OvyNuWpGai"
        "2h1ogeH01ua2ijcDkEszvn8su9S3drG+WrYhs6pbNZsMrnROhomEgvc8+3nf8ZJz90QOQXJIcZHl7iXOcckk5JK5HZG9tG9q7Vms"
        "R+jDsXP35tns29Vja20NnQeZfSl28l79CPojX1Rr5Y19bOxdQcVM+hiytPBYWLM1Q87LW7dhbqhultorqMyirFEwwmHO+H9XPu7u"
        "OOc4xhaRC9FpfXF+0Z4V4jr/AATwvc677DHJvbud327TjG8eXesZrKwjy3VKVWk4R46ce3J+14x2lf8AzWrf5ypXr+ju2Zu0G7Nq"
        "RIKgW+USCXO+HddFnOeOc88rzH1cNef7e/5SD9ReftOuL9ZL7XXugr+puddv9fN1Mbt/feHu8ktIGXAHgAsXFtNGmdCrUpyg1FZX"
        "L/R+HN/nZPwitxbFyRo3aWQcEW9v0c602SXEk8zxX7Fl1Xd9PUVzo7bV9RTXOPqqpnVsd1jcOGMuBI4PdyxzWUo5WDdcUnVpuC6v"
        "U0zZPRuP+XFw+DZPpYl+HsXJO1WzEnJLqj6GReR03qq76QrpK6zVfgtVJEYXP6tj8sJBIw4Ec2j1LFZL7X6eusN0ttR1FfBvFku4"
        "127vNLTwcCORPYo4t56zVUt5SdRr+pYXr8TYtqudLaNvdRV1j2sp23apY57jgNLy9gJPYAXBbA1nq/Xti1JVUdHpK311G+QmmqGU"
        "EspkaeW85r8b3fy9S5yuFwqLpX1NdVydZVVUjpZX7oG85xyTgcBxPYvU2zaprC0UTKOkvtQ2nYN1rZGskLR3AuBIHxrFw4GqraOT"
        "jJJPCxqbI1RdtTzay0BQakpbPTu8PpqmKOg3t+PMjAWvBccY5cOBwcE4XjNuBJ2mXjzNg+hYvGu1Dc5L1Fepa2WW6RStnbUSnfcH"
        "tILTxyOBA4ckXy+1+pLnNcrnUeEVs26HybjWZwA0cGgDkB2KqOGZ0bZ05xlpomtOlvJt22UFRrHYTFbLM3rrha6wyT0zD5bxvPcM"
        "Dt4PBHfukDivMaE2b6muVynl367T0FPC90lfLG+Ld4e1HFpOe3jwGcrxVlv9z05V+F2qumpKjGC6J2N4dxHIjzFfs3vaTqrUdGaS"
        "43meWldwdExrY2uHc7cAz8am61nBi6NWLlGDWG89az6me/2Z6atUun9SaintnsluFDUOigpDk9a0AHf3TnJdvE8QT5JxxWxNmNxk"
        "uVxqZXaFo9ORiEhtQyERSS+U3LQNxpLe0nlkBc1af1ReNLVL6iz18tJK8YfuYLXjsy05B+ML9WTaXqua8Q3d96nNfCwxsfut3WtP"
        "MbmN3BwOzsHcpKDeTTXs6lRy148NXp1Y4HsNicwsW0mWkuUb6apqKeSnYyZpY4PJa8DB5ZDTjvyO9eYu2znVNNqCooPE9bUSulcG"
        "TRxOdHICeDt/lg8+J4duF5+7X+4367S3avqTLcZS0uma0MOWgBpAaABgNHLuXoXbV9ZuojRm/wBT1Jbu53WdZj8PG98eVlh5yjc6"
        "dVT85HGWln0dB73bpQy2zTmhqGd4fPS074ZHA53nNZECfWFW2Sy1+rI7BqOyU01da5KMM3aZpeYjkni0cRzx5i3BWp7vqu73+it1"
        "Fcawz01tj6qmYY2N6tuGjGQATwaOeeS+nT+uNQ6WjdHabpNTQuOTFgPZnv3XAjPxKKLSRqhbVIRi01vRz2amztG2qs0bsx1lXXyF"
        "9HHc4OopoJxuvc4se0HdPHiXjz4aTyWlQV+rf9WXrVEjH3e4zVfV+0a4gMb6GjAHqX5AKyisas30acouUp8Wbhvhx0ftNYPOvf8A"
        "PnT00T9QTVXH/TwPz061vNqm61On6WwS1W9aaWQyxQdWwbriXHO9jePF7uZ7U6bVF2o7BV2GGr3bVVydbNB1bDvO8njvEbw9o3ke"
        "xY7r9Zq+Dy3cf+7Pozk2PshP+SG0X+ID6OdZ9gtxbFU6hoIjD4xq6Zr6Zs/tHuZv8D3jygSB2ArWVn1RdbDR3Gkt9V1NPco+qqWd"
        "Wx3WNw4YyQSODncsc1+fTVU1HPHPTyvhnicHMkjcWuae8EckcM5E7Zz84m/pY9Rvi36u2h1l5jtw0jbIJt/ddLLRStjj4+2L9/GP"
        "OM57MryFTcrjctsFrddm0Ta+C4U8EngRJiJa9o4EknP/APuC/El2qawnpDSvvtR1RG6S1rGvx+GBvfnX6WyzR1zv98o7xTug8Ett"
        "bFJOZXkO4EOOBjjwCxxhNs0+a81GU5pLTGhsSguNPQdIC8MqHtYaumZBEXHA3zFE4D4w0j41qu67P9SwX2eh8U1k8rpSGysiLmSA"
        "ng7f5Y7eJ4dqybVq6Gs2h3ippJmyRh8bWyRuyN5sbGnBHcQfUscO1PWEFKKZt8qDGBjLmsc/8sje/OrFNYaFKnUjGM4Y1S49R6zb"
        "LLHR0uk7I+VstfbaLdqC054lrAPXuE/GO9Xt+P8AlZbx2eAt+ketUVFVNWTyT1Mr5p5DvPkkcXOce8kr9O/6mumqauOru1V4TURx"
        "iJr+razDck4w0AcyVVHGDOFu4OGvDPrNk7PIXX/ZtqmwULm+NXSCdsecF7cM4D8gj8Yd6/E0Boq/v1hbJH22spYqOoZNNLNE5jWt"
        "ackZI4k4xjzrw9uuVXaauOqoqmWnqY/ayROLSF6Kv2l6rudI6lqbzOYHDdcI2tjLh3EtAJRxeuCSpVE5KGMS6TLtMuFPdNc3ippX"
        "tfCZGxhzeIcWsa0kfG0ryYKkFPKyWiwb4Q3IqK5FpgqQU8oUpUCoymChCwU1KYKEKBwqyoTBQhkDk1jTBQFoUoyhC8phyjKaELyq"
        "BCxgpqAvKakHKEIUDhPKnKMqELDk8qEwUBeUKU8qkKBQpyhAaiTBSQtx0RSEIQEuWJwWYrEQhkjA4L53hfU4LA8Ibos9tsx2pXLZ"
        "xcnGNpqrRUOBqaMuxvffsP714HxHkfN0TdtOaC2/2VlXFKHVsTMNqoMMq6X717TzbnsOR3FcdOC+i33KttFXHWW+rnpKqM+TLA8s"
        "cPjC+FtHYkbmorq3m6dVc1z7fftydDs3bU7aHmK0d+m+T5dnv+RsPVPRf1lZpXvs5pb3SZ8kwvEU2POx5xn0OK8HPsm13TPLZNIX"
        "oEfc0rnD1jK2hYeknq+1sbFcGUV1jb++qIyyQ/jMxn4wV6yHpW+SOt0oN7t6uuOPzsXnV15QUPmypQqdaePau4+mqmxqvzlUlDqa"
        "z7H3nP31L9be9G+fIn/2I+pfrb3o3z5E/wDsXQv11sXvVf8ALv8AAn9dZF71n/Lv8Cvxntz/ABF+peJdzZH+Q/0vwOefqX6396N8"
        "+RP/ALEfUv1v70b58if/AGLob66yL3rP+Xf4EfXWRe9aT5d/gT4z25/iL9S8RubI/wAh/pfgc8/Uv1t70b58if8A2I+pfrf3o3z5"
        "E/8AsXQ/11cXvWk+Xf4EfXVxe9Z/y7/Anxntz/EX6l4jc2R/kP8AS/A54+pfrb3o3z5E/wDsR9S/W3vRvnyJ/wDYuh/rq4ves/5d"
        "/gR9dXF71n/Lv8CfGe3P8RfqXiN3ZH+Q/wBL8Dnj6l+tvejfPkT/AOxfbQ7G9f3B4ZDpK6tz++mi6po+N5AW+vrq4vetJ8u/wL5q"
        "rpUzuYRS6Xha/sdNVucPUGj9KfGW3XorWK7ZL/yJjY61dw36H4H4OjOildayWKfVdxioabgTSUThLM7zF/tW/FvLbN+1lozYfYhZ"
        "bPSwGtYMst9O7Ly/Ht5n8SPj8o9gwtEal276z1HG+AV7LbSvGDHQM6sked+S7861wS6R7nvcXOcckk5JK1fFF7tCantSp81f0R4e"
        "n3b6zVV25bWkXDZ0PnP+qXH0L/XYfs6l1Pc9YXme63WczVU3DAGGxtHJrR2NHd/6r86MLG1q+hjV01OnGnFQgsJcEclVqSqSc5vL"
        "ZmYF9LFhjC+hoWR5JMzMWVqxN5LIFDQylSlAKGJYKalMFAUCmpTBQjGhCFAUmCpBTVMSkwVIKaApMFSCmoQpCQKaEZSoHKxg4VIQ"
        "pMFJCApAKQKaGJSsFYwU0BkTBUg5TQhYOFYOVjTBwoQyApqAcqgUIUCmDhSmChDIDlNY1YKELTBUAqlCFJgqQU0IXlMFSDlCELBw"
        "qyoTBQhkBTWNMFAWjKWUZQhYKeVAVZUIUhTlPKpMDyqBUApoMF5KeVGUByhDJlNRlMOQFZTyVOUZQhYOU8rHlVlCFZQpyhCGpkJA"
        "prcdGAVKUwUIBUOCyKShkYXBYnNX0OCxlqGaZ8rmrGWr6nNUFiGxSPm3Ut1fQWFLcQy3jBup7qzbiNxBvGHcT3Vm3PMnueZBvGDd"
        "Rur6NxG4hN4wBqe6s24nuIN4wbqe6s+55kwxCbxhDcrI1iyBitrEMXITGLOxqGsWZrVDXKRTW4WZoUNCygKGiTLAwrHFSqHBDWyl"
        "0tsH1Vo+0aSfTzVtFbbwJSax9XK2I1HF3VlrnHymhvDA5HJx5WXc0oWM47yweW6t1cQ3G8HdPs+0p757J8vi/WR7PdKe+ey/L4v1"
        "lwsmCtXmF0nzviaH9zO6PZ7pT3z2X5fF+sj2e6U989l+XxfrLhhUE8wukfE0P7mdy+zzSnvmsvy+L9ZP2eaV981l+XxfrLhkKk8w"
        "uknxND+5ncns80r75rL8vi/WR7PNK++ay/L4v1lw2hPMLpHxPD+5ncns80r75rL8ui/WR7O9K++ay/Lov1lw4CmnmF0k+J4f3M7i"
        "9nelffNZfl0X6yPZ3pX3zWX5dF+suH0J5hdI+J4f3M7Yr9daOdQ1IqtQWaalMTuti8Jjl32YOW7gJLsjI3QDnlhcbXWWimutdJbo"
        "nw29873U8Uhy5kRcd1p4niBgcz6SviQsoQ3T12tnG3zuvOSkwVIKa2HrZSpQCmhCkwUkICkwVIKaGJSsHKgHKEBkCpQCqBQhQKoF"
        "QmChDIDlNYwcKwcqEKymCpQhDIqDljBVIQyZQoBTyoQsFUCCseUwUJgyAp5UJgoQvKYKhMFCGTKeVGU0BeUZUgp5QmB5TDlKEIXl"
        "PKkHKEJgrKeUkICwUZUgpqAsFGVCoITBSAcKQqQg8oSQhMGp0wVIKa3HRlIQhCDBQQkmCgQsKC1ZCEYyhTCW5UlqzFqN1C5MG4lu"
        "LPuo3ELvGDc8ye4swYnuIN4wbie4s26nuoTeMG4n1az7iYag3jAGJ9Ws+4gNQm8YQwdyfVrNuphqE3jEGKgxZQ1MNUI5EtasjQmG"
        "qwEZg2MDCsBIKgFDBjVKUA4QxLBTUpgoRjQhCEGCmpVICkwVIKaApCQKaEBUFKFCFBUpTBVINUpTBUA1QKlCEZSYKkFNDEpUCpQg"
        "KTBUgpoQpUpQDhCFgpqUwUDMgKaxqg5CFKgVKFCGQFPKxg4VZQhaoFel0Fd9MWa7zz6s09Lfbc6ncyOljqn05ZLvNIfvNIJw0OGP"
        "vvMtx9IKxbN9AxR2Gy6Olpr3caCCvp7iLjO9sAdKQ5pje8hxLY3DP33mTGhvhb71N1N5actc93M54BVA5XQI0js22ZaI0dctZ2a5"
        "X66aopxWfsepdCyliIa4YDXNycPbwOcnPLgvC7ctndFsz1uLbbKiWa11tLHXUvWnL2MeXN3Se3BY7j3YVwKlpOnDfbWmMrms8Mmu"
        "UKQVuHo46N0/rjWV3otSW7w+hpbTLVthE0kX2RskQByxwPJzhzxxUxk1UaTqzVOPFmoQcKsroGLSuzjaboHV930vYK/TV001TeFu"
        "ElY+ohnbuudukvJ4kMcOGOJHPiF+fpXR2h9KbJ7drzWdsrb5Jeax9LSUNPUGBkbWF7S5zmkHOY3dva0Y5lN03fApN6SWMZzrjHDo"
        "zx6jSAKa3fr7SGiNCXrRGq4bVWXHReo6OSqNomqXRyscIxhvWNOQAZYzzPFpGSCvX3Ch2P0Gy21a8OzqodT3GvdQtpBd6gOYQJPK"
        "Lt/BH2I8Mdqu6VWMsyi5JOOvPhprous5hTBX1Xioo6q7189tpXUdulnkfTUznl5hiLiWMLjxdgYGTzwvjysTwtYZkyjK6Q1Fatlu"
        "z3R2gqy76FnutdfrTFVyyxXOeL7J1cZcSN/HEvzwwAtaW+z6d2mbUbPaNO22XT1nuEjInQvqHTuZgEvcHPJ4kA4HLOFWj1VLRwah"
        "vJyeNNefox6zXaF0Tc7dsSpNUXTRlws93ss1E6Sn8fS1T3/ZGZ8ox5I3SRwIbxyOAyvJbI9nen7/ADaxvWoaies09pSnM746Mljq"
        "zO/u4JwQCI3HHA8RxHFMB2Ut9QjJNvPPhjjk1Gv3dK6SvWtrqLXYaF9ZWljpCxr2sDWN5uc5xDWjzkjiQO1e+1jSbMr/AKHkv2lG"
        "S2C+UlQIn2aqqjMamMkDfYXEnhvZ5/vXcORWxejtoSzXHRVZV3qWugm1HWvtVKaaump2vDYHvO82N7Q8HD+DgR5OO1VLXBlRsnUr"
        "KnlNPXKf7adGqOZqiB9JUSwSFhkieWOMbw9uQcHDmkgjzgkFRlbI2P6Mob7tftemNRUfhFIZaqGpp+sczLo4ZDjeaQRhzByPYtuW"
        "rYrpN23iosc1sM+lay0eMaKn8IlG4csYRvh28SHB/AntCijkxo2NStFSjjDe779Ry2qBW89m2nNEU+xm96z1Rpt95qaG6+CNaysl"
        "gO4WQ4HkuA4GRx5ZXg9dag0PeaSkZpTSM9iqI5C6aWSvkqOtbjgMOJxxTBqnbebgpyktVnGue7HrPEIyukb7Z9leg9KaBqb5oyqr"
        "qnUFrhqaiqp7hMxzHdXGXu3N/dJJeTgYC1ltq2e0uzfWrrZb6iSa21VOyspjKcvax5cN1x7cFp+LCbuDKtZTpRcsp4xnHLOq5GvU"
        "wVGcIysTxmRCgFCpMGqlQOVKFtOjKVKUwUMRoQhAykKVSDIIQnhCCRhMJ4QCwmAmE0JkW6jCaYUGQARhNMIMiwnhNCEFhPCeE8IT"
        "IsKgMIGU0ICYQE1DFjAVhQCmgKQhCEGCmpTBQhQKalUDlCMEA4QhCFJgqQU0BSYKkFNAUhCEIAKpSmChGUCmpTBQhQKalMFQDTBS"
        "QhGUFSgFUChiNUDlShAUqUpgoQoFNSmChCgU1KoHKAoFPKhUhCkwVCeVCH001JUVkhjpoJZngbxbGwuIHfgeldA9LejqHa109UCn"
        "lMEdgpmukDDutPXTcCeQPEetaa0VrzUGz26TXPTdw8BrpoDTvl6mOXMZc1xGHtcObGnOM8F6PU+3faBrKx1Vkvd/8LtdXudbD4HT"
        "x7268Pb5TIwRhzQeB7FlyPVTqUo0Zwk3l45aaek2Vtus1xv2zvYxPaqCproRZWUxdTROkxL1cI3Dug4OWkY8x7l8PS4c0bRLJBvA"
        "y01ip4pWg53HdZMcH4iD8a8Zsu236n2bVtvp6e5Ty6djqA+otrw17XMJ8sM3hlhOSfJI48+1fHtnuFjvG0O7XbT17lu9uuThUiWZ"
        "krXxOdziPWAEhuOGOAaWjsR8DdWrQqUZSjxe7ldi5dPsPBA4XQXRCkdFtCv72tD3MsM7g1wyDiaDgQufF6PReu9QbPrpNc9OV/gN"
        "dNCad8vUxy5jLmuIw9pHNjTnGeCiep5LWqqVWNSXBHSFFqC47UtjOv23uwQaZhtEIq6ea1xSUkFVIA53VvYSQ/ixo7fbDkcZ8tqG"
        "31d56KuhBbqaarNFdKgTtgYXmLMlRjeA5e2b+UO9ax1dtk1zrq3+L79qCeqoS4OdAyOOFjyOI3hG1u9g8eOV8mjdqGrtAMnj05e5"
        "6GGc70kQaySNzsY3tx4Lc4xxxngFcnqld05PEstOOG9M8c8M49ZtXpAQS2/Zzsct1VG6GuprXKZoJBh8eWwY3hzHFpHxFY9R/uSt"
        "If7wP/RUrTOpdVXnWF0fc77cZ6+ueA3rZjyaOTQBwaOJ4AAcSvoqdbX2r0lR6Tmrt6wUdQaqGl6pg3JTvZdvhu8fbu4E44+hTJql"
        "dQdSpLGjjherj+R+GmCoDlWVD5515rrX110Xs+2Vx23TFmvTamwwOe640D6kxbsMOA0tcMZzx9AWhoajUmvdqNLU2yho7LqSsljf"
        "TQUjPBIYnxxjdLQ4ndJ6vPPiT519lp6Q20iy2yitlDqPqqGihZTwR+BUztyNjQ1oyYyTgAcScryWo9cag1Zf2X+7XKSa8MDAyqjY"
        "2Fzdz2pHVhoBHeOKrZ9G5uoVcNN6Y0wlwXJ59h0/pW73jabq2fQ+0zQVJU1Eccscl5hpTFLAWNOH9Zyw4jALSAcjgQvH7GrYBpPb"
        "jYrc81tQKMRUzYxvPqGs8IbloHPOW8u8LW1ft42i3S0vtdTqmrdSPZuODGRskc3kQZGtDz615LTeqLxpC6MudjuE9BXMBb1sJ5tP"
        "NpB4OHAcCCOCZM5XtPfjLV4zlvGcNYx146z9o7M9QxaJq9X1NK2ktNNO2nxUkxyyOJaPIYR5Q8rn5ndy6W8E05orTGyS33nWEWn6"
        "yzBl4kpH0UkxqnSHecC5pG57aRmTnn5lzLrDadq3Xradmor1PXRU7t6OIsZHGHd+4wBpPnIzxXw6t1rfNdXOO5agrvDK2OFsDZOq"
        "ZGGxtJIaGsaBzceztRNLgaaVzRobzpxbbxx7cvg9OR0fR6e9jvTIpmsbuwXB09fGe/rKSUuP5e+th7IJ2alvVXWuINfpm53S2P8A"
        "ujBNMJWE+YOaWhciybWtYzajtOo5LxvXq005paSqNNDmOMtc3dI3MO4PdxcCeKnTW1fV+kLjdrhZrwaWru8nW1j/AAeJ4ldvOdnd"
        "c0gcXu5Ac1VJHqo7Ro0p5w8OTfLnjHPpX5G6dk2oKvTHRx1LcqK10V0qIr7utpa2nM8T8spwSWAgnGc81qLaPri660bbXXLTVpsr"
        "aMyBht1C+m63f3c728472Nzh3ZPesGjtr+stAWyW26dvPgVFLMah8fg0MmZC1rScvYTya3hnHBYtZbVdW7QqWlptR3bw6CleZIm+"
        "DxRbriME5Y0E8O9RvQ8lW6hOhGmpNYSWMLHHpzn1HUouOkRSbErPqjT1PcHXO0QMpq2eQ7tM/qYt1pjxhwc4tHE8POubtt9zv1x2"
        "mX0ajDG19LL4OxkTSI2wt/ze6DxwWkO4/dLzd61zf9Q01jprjcHSxWKFtPQBsbIzAxoaAAWgE43G8Tk8FOrdZXrXV0F0v1Y2rrxG"
        "2LrhBHES0ZxkMaATx5nj6kbyW6vY14OCWNV0dGNfTw4n4iYKkFNYnzcDyhJCgNWoQELcdCAKpSmChGUCmpTBQg0wUkIQpMFSCmgK"
        "TBUgpoCkJApqEBUpTBVINAOEIUIUhIFNAUEBSqQFISBTUMQTBSQgKVKQgKmJQKpSmCoBoQhAxgpqVSEKQpBwqQgJgpIQhSoHKgFN"
        "AUqUpgoBoQhQgwU1KoHKpGUEKVSEKCFKpQAmCkhDEsFNSCmChBgqlKYKEKBTUoyhCwU1KpAUmCoTygLQkCmhA5Kw7KhChiZAVSxp"
        "h2FQZAU1OUwVAVlPKlCEZkCFAOFWUMcDTBU5TUBSoFQCmqYl5KYKkICAvKMpIUDKDk8qEwUIWDlClUhB5QHJIQheUw5QCmhC8oUg"
        "oQGrlSlMLadExoQhCDBTUqkIyghSFSEBMFJCEKTBSQgKVKUBQFIQhUxGCmpVDkgBMFJChCkwUkKApMFSE1SFIQEKEBUpTCEZQKal"
        "MKkKBTUqlACAhCEKTBUhNAUhIJoYgqUoCAoHCpSmEBQKalUOSEYIQhQFJgqQmqYlJgqQmgKQkE1ACpSmEMS0KVQQgwU1KpCMFQKl"
        "CEMiFAKtACsHKhCAyIUgqlCADhUpTCEZQKYOFKoclSFh2U8rGqUBSYKnKYUIUmCpCapCkZQEKEGCQqyoTCEKDlWVCYQFZTUphCFZ"
        "QHJIQjLyjKkJoTA8qsqEwhCsoSQgP//Z"
    ),
    "logo": (
        "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAetklEQVR42u2deZBc1ZXmf+e+93KtSlVpQQsCtCIkIWMweLyAJQHd"
        "9rTpNqaNLDCYHm9j93TbeGbCREe4LZiecE/TngkIR7c7YuzpMWIVRl5ggLbNCGGDAWNoFgntCCFAQkstuWe+d8/8cTOrsrKySpmq"
        "wsOiRyjiZJF573vn3Pvdc75z7n0wgUvXYXTTSl9BeJddCqKbVvq6DjORdo5LcaquUxFs/W+FH807zYT+e1CWRapLjMg0azWFEKh9"
        "+1lIATGAUjVGClb1iCey3YMtvmefkzV79o2nj3Yvv5Mvr1uHuX45IkIEkL1zwZkB3qVgL9GqnBWPmwSegAWsgtYepPZAb6erfs9S"
        "/2AEDBAppTKl4h0LnxXP3Fu10U9F9rwAoBvwrt+C3nBD+4Zoe2DqBjxZ4xRfuGP+BZ7xv6aqfxJPeIGtKMWKxYhGMR/1PECQdwww"
        "KaBoFEElRKyKl4wZTEwol6KqMfLTsBrdnPrMnl8362pSDFBvsHDrvNP8mP83glztB0I2Z/E9DZMxDIL050X2HTG8NmA4lBPyZaES"
        "DXeiQ50KWvv0VpTrd6oIMU9Jx5UZXcqcKZZTp1l60qooWqxgw0j87i5DWFVU9ZZcNvzW1C/sfbldI8gxsF64HpEbsNnbFqyN+ea7"
        "sbg3fWAw0rinNpHEHB0UeWSXzy9eDPjtXo/9/YZCRQjtUBtv66sOQYEHyUCZ22M5b17EHyyt8pFFIVMzqqUithyJmZLxpFqxh8LI"
        "/mXqit136ToM16MiYyOwjKt8t7Bo8faFNyWS3tfKJaUc2jCTxn+j3/DDx2Pc+VTAzoMGi5DwlZjv4FJEh0aTNoyst5tcnxmoEClU"
        "QiiFgkFZPNOy9twq13ygwkk9lsE8Ydw3fjwhFIvRzakrd1/bqMe2DVAf+bDSlJa8emui2/t0rj8KPQ8vGVO57YmAG3+eYOcbHumY"
        "koi5tq26G9UGsOEdJou4AQZQqgj5Ciw+yXLdR8tc+f4KxbJoGGG7ezyvlIvuTMw++Woe3mzHmgmmlX/78PUrPbkBWzjdKX+wP6om"
        "YvjlEPni+iRfui3FawOG6V2WmK9EFiLr4EZH9PHOk1UZet6Yr0zvUl4bMHzx1iRfWp+kHCHJON7gQFRNdHtrC6+9eqvcgH34+pVe"
        "q3hp1B9000pfVm8Oc+sX3pzu8b862B9W03GCAwOGq/85yW/2+MzoVqyCte/Ygd6RbABj4I2s8KEFIes/V2RWtyVfoZqZ4gf5/vDm"
        "rs/uvnbTppX+6tWbwzENUF+5s+sXXNHV7d+ezdowEcM/lBUu/V6SFw94TE0p1eiE1lvJgQdHC8LSWRE/+UqRGd1KuULY1W383GB4"
        "Rfdn99zZ7B1JI63A9Wjx7gWnGOs9r9BlI5WqRS77XoonXm5U/gmVt5KHjJAXPjA/4p4vFwgMajxRUc1adEVy7e79dc9y5BrgIly1"
        "ZXNjPCGZSlVtKq5y3cY4j+72mJqyQ8o/cY3tUlZDmJa2/HqXx19tjJOKq1QqauNJM8WG3CiCsvxyGTEDhgKt2xacH4v5vyqUbNSd"
        "Uu/u3wb82Q8TTE3rkF9/Yqi3IQv4xs2EH15T4lPnVckWJEomxCtWogsyn9nz67rODcDddd1auc7zIPBUj2SFv30wRiJQt9jqO9Kp"
        "eXPkmoOSCJRvPxjjSFbwPVXfF0TlG406N7oOs2YNUWnDomVeIB/L5q0mEvjrHw/Y+rqQijmP58TV2WUVUjFl6+vCrY8HJBP42ZzV"
        "wJd/O7h+0bI1a4h0HcawaqUBiKpcEU94vm806ssK6x/3Scecvzs8/E/86+RfZCEdg/VP+PRlBd9oFE94vufpWgBWrTSGVZsjVYwq"
        "l4YVSzKBeWSHx/aDhkSgLrjSYU7nhNyZnAiUbQeER3Z4JBOYsKKoyqW6DsOqzZERQQfuXDTfM5xRqiiAeWCLh1VFOIE9E2KxFQQH"
        "4Q9u9QBMqWIxwtLS6YvniaAGwIv03ETS+AaNBgvC0/sMcd/9UHV4Sp2QO5etQtxXnn7ZkC0IBo2SSeOrtecOxQFGWIoR4gG6v0/Y"
        "3yfEfE4svpO0GMc8eKVfeKVPiAUoRrAiSxsDsYVY8Dx45aiQL4MnOtKvOiEft+wZJV+C/X2C7wEWRFg4ZACrMgOrYJA3siOzWEOJ"
        "XT0hH5dcj5AjR9ZhkFq+fMYwBKGJ+pfzlYY0lp7Q4YT13+AR5cuNJRckhqsiRHxVEIEwGs6ITkZsbmRkJriVrDr5nICIusxci2xX"
        "/TtWa47G74Gm09osQOp5E4JhA7Tyn2g2xMhkS7tysVJzx0Qb7m04ueF7Ssyr3ZRMrC8AT5xcDqFchajBLxcZlo1xi2MiAN/ocEJp"
        "Eu6hUdYmnTZffssSjCaKo2PD15VrYPkcrSllZPJBa8o6UoADA4JvRk7ZTgeZZ1zU3lcE34NTepWls5UF05XZU5R0zBm7WBUOZZ2n"
        "t/2gsP2AcLgA6TgkfGewySbmxnMm/XGjCG1qVduTRZTQClNTyo+/UqE35aafNFggstCdhn94yOM/bvCZltYa7UFHfTkvAwZLQjJQ"
        "1pxrWXue5ZzTLDO7Aa8+42RklZhCoQTbDwr3PWe4/QmPlw4LvSlF6zNFO3/2UfKQQaU9A2jtvwlTgqqjCNTWhm7nf4wtewb6CnD+"
        "Isu3Lws5b7576HIVcuX6OJKWA9Qz8N65ytnzI/79RyK+8y8+/7jZkIq5xLvqZNGkNb22gKG2ShOPA4FGrR9jq1dHfWq3L8e545S3"
        "JiIwkC3UML5evXCM0rN8BWwJpiThxitClp9suPYun8CbNAQa9zJja0dH+lCdslAdkSaNPm977fuiHM3DVf/GcvOVEdUQsiU3qj0z"
        "Eu7GVYC4NSOMYGAQrlll+a+fCMkWqXlwE2TjGn35tg1Q+4HqyGnYrqwwbqfj9ddO+8ZAoQLLZlu+syakVHEhv2daUwF1D2fE5+Z0"
        "Ys0Q2QH48wstf7TCMlB0jkInz94sa2Ng0L4BJqGaWd+8rwtQqsK1F1t6uqFSHS6WalZ+OuYW+5jvlFz/7MnoidrYxLUXRwTe5PBh"
        "x+cFTQr66QRus3X7ApSrwilTlT9YZimXWo98VeiKw1N7hX9+zLDjAJRC6EnB6iXK58+3pGKu1LARrjwDxTKcN085a67yzCtCOqZY"
        "nWi9hLRvgJarvw4HUMeUR1XIHYs319G2GKN9MVCqKstmKzMzDoqaR79VSMbh/ueFz3zfI18WYr4rK7QW7ntWuP954fYvRaRjDv8b"
        "jRBayKThnNMsj+8xdMWb6BnpQB7rGY8FQS1DgjblVpFhuyP/WO1LLYaY06MYf+z13hP43sOGchVmZZSuWA1+EjC3Fx7aInz/EUN6"
        "GmRSDpbq/3rT4HXB2ado07rUmR7a8UX8sWiIiQRibhbIsRFIxtD8eO0PcUzjDxgEFs9U7ntaKMQV3+AKn9QVl01JCz95RjhlqjgY"
        "appBiRg8s09IBGBtm/d2zECs7ThgMrigzvFfx5g92hQniChH8o5XH8u1LFXgm5dYDPCj3wlvZCGMFFd247JUew7Dl25xHIht3k6l"
        "buFOxUdXhRwXF4R2sgZM1rKv7cFbBx6rS/HBttehP+/ItGYFiUAUOcj5zlrL1y6Gp/cJT74EW14T9h0RXh+AgaLrO+5DKjbMJzVC"
        "iLVMeIehjnBHj8cLakUnjie3FQMegwUco33FKX3HQeHRXfDxs2Ew76LiZiOEEVQKMGsKfOIc5RPngobKYBFeH4Ctrwm/3QuP7RKe"
        "3Q+FMmSSrq3INjyLdvDszbJ05AXJ0MRpGUBom7J05gWNxMpjte+exYjy9w8aLl5u8T03UpvXBRG3GFdCFzdoDZ5iPiw+Cc6Yo1z2"
        "fiiVlGf2wZ1PCnc8IQyWIJOAyB7Hs49aS2lB87ZFRdCSrWlHHtKpavvK76B9a52P/9hu+MYGIZV0uD6cTGphCONGthEHWcWq440G"
        "c669Dy6Am69SfvGfLOcvUvoK7jcTzQiPplvadkMn0PVxLSLNlWVjt68ooVV6U8o/bRY+/323VSjT7RQc2pH0QyvnyzQYBRxzOpiF"
        "98yF+65VLjvHGcE3k5Gg107IOB3hlWgDPLQra5sLcEsvqIO+IoWepLL+N7D6RuGWXzm4yXRBdxIC3301ssc2Sp2Uy5Zc29+7Wlk+"
        "R8mXa9T0cehh5ORuDcpmXHWMcE86kTtzRUf012FfkYWpKeWlQ/CF/y2suhG+eTc8tBXeGHTQ1J1uMIo3vMer5aJooFiBnm74zx91"
        "qU0ZMas71InquCGpPy4STCgh08EkaNnf+O07/md45qTjSlcC9h6Gv38QbvoFnJSBedNg8UxYOhtWzIVlc2B2r/tRrtSaxPMNVEqw"
        "egmcMlU5khMCr3FN61An4+hizEBs4qGAvnnfVpcFawUndc8n7kNfHg4MwK921gtlnUt67jz4/AVw8TLHJUmLNqoRzOiGBdPhtb5a"
        "4cCEwiLtxACtH1qkTVkb1Tq5B0bYmiL/+o+hN+U8n+YujMB//znsP+q4n8ZnOJyFHz8N9/xO+cerhM+vhHxxNKOqgO/D9C7X51BI"
        "0Ike2uClx6EihgOqxrqdduROAjGXm1U8I8PxxxjUrghIzd//9PuF2TOBCqPLLVLw6C7lf70Gs2JCOaxR2SL4njI9LgwU4X9uVq75"
        "sGDM2MoyokMJ+k71oKo1Q4ytE3/soKiujOPIBEkDuabja79cVSp56JeGfWjj4KkAYR52HnQQkWvKB1iFeBX+w4XCz55RDueUTLKO"
        "9e6ZihUln4MPLoIgcAn8UTmFGnV9NN/gBR13RqzROZE2uKCmGTByVrQrM+5M8MQtdH94pvDDP3eYfazsk+J4/id2KS+8qnxkmeBV"
        "RirPA8IqvPdU+OlXhb/+sfL0y5CruN8HBqZ3K5/9kLDuUqFcYdQMUJy31JeHl484d9Yqx6mHGoq0PwPG4WjaTsgcOxsm4rZ0njEb"
        "zjy1g9UsCTPScOMD8JWLWpvXGMiX4IML4cGvCy+8BnsPKZHC1DScPstw8lTHmEbRaLy2FmJxeHansvewko5LzQB63AmZjlOS2uxG"
        "dSK36dWIuOlfrLS/AHdFbkZvelF5dq/wnlOdspshxBgX3Qpw1lx472niPlgXrGUL9VNdxnA4DKx/TGsFZXr8u0SPwYuZ8cmxYexS"
        "OpHbD8LqPE3b/8RBQrGifPPH1pU4mtbwVVdwvuIUns1Dtuhm3lilK5UQMhn4+XPKhqeUKUk3S+r+rUqD3BC+j6WTkfjfrgGaotlO"
        "UzIjDPgmXJF1Ue2Dzytfv92OJOPGMESjEWWMCoowgp4psOVl5cu32OGF24CWQqL+IlqqYnNlbH+Ns5D2UlZtB2IjVvJx3Nhx5QYo"
        "bORhZIIhgdXhtiLr8Px7/1cZLFpu/LThpB4ol9woHiJ+peHgvTEmuCeuOFd8uPcp5S9vtRzKuiRNJILmKvgLeply2RL8Bb1oKaL8"
        "+H7yP9uJ2ohamDzWnu1xnZL2vKCOEzLU/HZhahqSXUA0CTGZAnGYknIDJbJCTxpu/Y3ym10h137UcNk5hpk9tbkdOfiI7EiIMsYR"
        "b8Zz36uW4am9yj9tUm5/3OUXnPINmquQ+PApTP3bC/GmJdFKhIiQ+thCEqvmcfSvHkJL4fAi1DIh06kXNMp37TwhI+LKR37wK0s6"
        "XpsBE42CcSXku94Y9uujyEXEr/bDX6y3/I8HLeefLnx4sbD4JGHWFJiSdMn1+tOUqnA4q+w+BP+6T3lku/K7vUq+4mpEBad8wggz"
        "I0Xvuo9g0jHsYVcqp+pcpdRF8wi/ci593/41JhOr1ba3SsiMHRP5x0zrHs9AVTet8yW49nY7qbuN3aYOl5CpP2NkXRyRDBz3c8uj"
        "yg8fVZKB+153ElLB8EgsVKC/4KjnajScE+5NgZXaFq5CBTtYJvOpZfizu7B9JRdEDE0jj6ivRHL1aQz+4BnsQBnxW1eCjMcNH4OK"
        "aAalDg+9E6E3Pflbf7R2DEBjX6gQqhL4MDVwf7cK5VAoDOiIQMpx/0ImWd+cJFgRQqtozrFz8bNn07VmGckLTsVmK6OTzrXRIKkA"
        "0xPHHik48miM7VDHQcbp6IVVtGM5rJ20Ig1/nyxZWwQ+aiGS4QXRiGK8OhQ3JklqG0KMIFaxuTIS90hecArpNctJfnAuEvexucq4"
        "PrQWQucR1bb4NOtBjoEn/niqP94l4PcljwjUx8nh05xuEBDPQDXCDpYx3XFSf7SYrsuXEX/fbMQINldFS/V0mI7eghVa/Gld5O/b"
        "QXQgh2TiaEMBlzbWZ41jgjHIuObKtrfoCUnHUzDrCVQiosEyZmqSrrVn0vWppcSXnYRai+artUI2GfqJ6YoN+bMaOm/CSwSUHt/P"
        "wD/8Fkn4w5Vdzf3W9ThGYVBbEHT8nMRbRK4d9qmlEC1W8eZ0k7nyTNKXLiW2qBetWGy2POw+WgueYDIJtFgl/+Buig/tIX7eHILF"
        "09BSSPnJV8ndvQVbCJH6Ns+2l962MmIyuq03a0DX+zDSmso+3jbFnSmphRAth/jze+m6dAnpS5bgn5JBiyG2v0YYSS3S8w1mShLb"
        "VyJ3z1ZyP9pK+bmDECn5+3e60R4pWg4xXTGnfKtj349MSkbsTT4quFYnouUQLUcQ8zBx3ynP6tBC1u4xw2Lcwf82X4FICc6YTvef"
        "LiX1sUV4M9JooYrtKw4fSW8ViflIKiA6mGfwR1vJbdxKdfsRxPcw6WAIktRaJDBI0ney1XHv7VjRjz9uENa8Z7gx3J4MuZYRt4Uq"
        "Wo2ILZyKv6CX6kt9hHsH0DBCEj4Srx1IbUe2o00rr3iCWobgJH72LLouX07qwvmYKQlsrlJTfI0QsiBJH0n4hPsGyP10G/mfbSd8"
        "uR+J+5gpcacKq42nSNfuoQVX1uIZRcfnxfw2MgGTi8pS4wIii2bLqBFiK2bS9cmlpC6aj5nqpn/52YMUH9lL6Yn9hPsG0NAOG6MO"
        "F/UBZgSNFB0oQ8wj8eFT6P70mSQ+fCom6Y9WfM1/F99Q2XmE3MYXKdy/k/BADpMKMD0J1Coa6YSf91hBaNsQNGGwF0GMoFVLNFjE"
        "pAKSF86n67JlzudOxbD5CpqtIAmf1MrTSF04j+hwkfKzB2rGeJXqKwPQaIzIYgfLSDpG6mOL6F6znPh5JyOecYovl4f3q6piumIo"
        "UHn+INm7t1L45W5sXwmTDjC9CbCKRpN5JrOM40OP5Ya2Kg5tCGQ6ksURQ1oOscUq3ow03ZecTtcnlxJbMRMxYPNVtL84XKQTWhcA"
        "qYOI1Op5pC5aQHQ4T/lfD1DcvJfSk84YpjtO1+XL6b58GfEVM12tf67inrWh6Mdk4mhoKT6xn+xdL1B85GU0X8V0xZzi67StTPB5"
        "m2UZfy744+VjJoRBtYfXGr4HC3pJf/x00pcsIZjfi1YjNF9p8rkFSQVQjdBKNGyMbN0YAakLF5C6eAHRoQKlZ17Hn5MhvuIktBK5"
        "7w0xka58wmQSaKFK4Ze7GbzrBcpP7ker1nkwPXFHoDVWA7wJZ4hq24VZMlZCqz0PRIbwXd1CaIT4ipl0XbaU1EULnAdSrLrQvZXr"
        "ly1TenI//pxugtN6XM+lsMkYZWeMVED64oVoNXJEWav2+kvkNm4lu+EFys8eAASTDpCko6rrUPNmvgii6eirMQ1QrRceBV7rNMK4"
        "GR9RxBg3qgeLSCpGavV80n+6jNSHThnC9yHXr9aXxD0kGRAdypO9dzu5jVspb3kDb1qK+PvmkFp5GolzT8afk3GDo9kYg+Xa2fFN"
        "ruQbzpXMbtxCddthZ5CuWM2NVIiancPJOJimtSwNU8HptobKSrXRAMX6HaXjLVaC8fajCWik2IEi3owU6UuW0H3ZUmIrZjlOJV+p"
        "4XvdA3GjVwKP6ktHyd23g/x926m+1IcEziB2sETh/h3k79+BP7OL+DmzSa2a19oYza7kz7aR+8mLVPf2I3HPuZLW3SOTcPhJp3Ij"
        "o+O2uw5NisKwAZRDbhShJ3W7g+W0FSM3ajek40ZMKqDn351N1x/X8d22wHcwXY6wqjx/gOzGFyk8tJvojTySDDBTEsObsjxBMnGH"
        "KAMl8g/sJP/ATvyZaeLnzBk2xuxuEKGy+yi5e7aQ+z87iF7P1ijimkcT6u9f600jtJ7DOClTK5EwYOHwsAFEX8IIUQVOnSZ0xd32"
        "nNE5XB21UovA9P/2h6Q/ugjbV6zhu4zE40wSLVQobNpD9kdbKD62Dy1UMekYpjc5fIBDYzf1z764bBNgB8rk6zNjVhfx984GgdLj"
        "+4mOFDDpGF5vsgYz9i3CZTnauyvhdBuF4CUEgT1DBhDDi1ilHCKnTTecOk3Y9rqSijH2K+GMoPkKsbNmkfzAXMLXs4gnw4FO3K/h"
        "e4HsvdvIbtxK5fmDqFVMOobURuiYhfojjKHDxpjiMDIaKJH/l51DkOYMaRt8+LfGZYBCFZbOEU6dZihXkVRMUXTbsAGQp0pFG1qL"
        "350W3jff8Ny+kHS8YXdic/VvrSDHDpTQSoRJBmg5bMD3PnL3bSd/77YavhskHTj4szVal84qjdXWQntAPEG6a6BqtVa803n18pst"
        "iwiVqvK+eR7daSFXUK9UtGEUylMARhVJrN31UmTZlog59Xz8LK82kHXsZIcqEveo7u2j76bH3IIYGMovHOTwt37J61duoO+mxwhf"
        "G8RMSSDJwNEF0Win+HiSMqrOjdRIWx5T9FZJGLkKaeXjZ3mg2ERMiCzbpry06yVVxOfhlZ6s3hzmb9Of+HFzZjEf2QuX+mbJ7Aov"
        "HbIkAml59kG96leSAYO3PkvxsX2YTJzKtsPYXBnTFa/h8WhYmNSM2Fs0W6fqPO5iRTljjmH1Mp9iydpk2jOVqv5EbsDqqpW+4eHN"
        "FsCzcke5ZMOqFa93ivBn5/uUy1qrHB7nnHxVpCtG9ZV+ys8dAIPDYw/39kt9974/wBgol5VrzvfpzQhVK165ZEPPcgcAD2+2Rm7A"
        "btiAl7h619ZqqA9k0kZKRQ0/tzJg0WxDoeyqCMZd7K11QVAyGK4TsW//RNpEZCNQKCuL5hg+95GAYkGjTNpIGHJ/4updWzdswJMb"
        "sAbg8trvPPTvwkiphiozeg3fujTmZoE0Za5oPhPNGWHozW6qrb/zrpBrMY+40b/u0hgzeg1hpISRYjz9u0aduzdBryHSDXipq/Y8"
        "Wi5Fd3VnPG8wa8OrL4hx9QUBfYPWhdGNWy4bT9c9IQ/JWqMc+gYtn/1IwFXnxxjM2rA743nlkr0zdcXux3TD5UMvcxuuNtriFmwT"
        "5xvlkg7GAjGFsupNVyc4d6HH0ayrmXyLvazoLXc/gQdHs5ZzF3ncdFWCQlk1FogplXTQWL1OFWHL3doYJzh/9QYsd2NSa/bsq5b1"
        "K4mkMVGkUSYB91ybYvlcQ19Oh8i61ifj/H5l/j/1O5YceNCXU5bPNWz8WoruBESRRomkMWE1+nLqmj37uBsjDa88H1FvJ2uIdNNK"
        "v/uaXbfnc+F3u3t8v1DR6sm9hgevS/OhxR59Axbf1E5FbyzgfRefU28EfCP0DVg+tNjjwevSzOk1FCpa7e7x/exg+N3uq/fcoZtW"
        "+s1v2R5d8Lh6c7Rp3Uq/66o9Xy0MRndlevwgX7LVWRnDA9el+cJFMfpzllKlVuIt704vp55zqh9t0J+zfOGiGA9cl2ZmxpAv2Wqm"
        "xw8Kg9Fdmc/u+aquW+mzevOol0GO/0LnVStN6fVX1ye6vLW5gTA0RrxUUuS2X1f4LxtL7HjVEotDMlarblBF9Z39nkJX4+Wet1hR"
        "KmVYMtfwrU8muPL8GIWiamQ16u7x/UI2ujO1/eSrYewXOrf1SvPC7QtvSia9r5WKSiW0YabL+EcGLT94uMIPNlfY8ZozbBAIcX94"
        "b9Y7Sf1aO52lEkK16v66ZI7H51bG+PyqGNMyhsGcDWOB8RMJoVSKbkpesfvrx/VK8+aZIDdgs7ct+kw8kO8GMekdHLQ28NBkWszR"
        "fiu/fCHk3meqPLUnYn+fJV9WNGqzLuPtcAmIB+m4MLfXcN4Cj0vOCbh4uc/UHqPFvNpqhGQyxlTL2hda/YvUFbtur78iWMZ5IVtb"
        "m1bqb/7sv2XholRc/sYYWet5QjZv8T3CZEIMivTlrLx82LL/qPLGgCVbVqrh21v3gQ/dceGkKYa5U4V50w09XUYRtFhSG0b43WlD"
        "FCnW6p2FQf3rni/u3tX84uYJGaDRCADFOxau8kS+auGSeMILooqlWFE8IYoHqNt7JdJZD2/Ra+icNFUbQbmKRIqXjAlezFAuRVUj"
        "3BtZ/W7yit0PN+tq0gwAQ2/dRsT5sdlbF6wIfHOZKn8CrEjETTBUT28ZdSL62xJ96jSMqX2wSrFsqwLPq/AzD3tPfO2eF2qQ7fRz"
        "A7YDdOv82rAB7/LL0bohAHTjooXliq6wkZyB6OkiMs1aTSEEat9+E0FdphCUqjFSUNUjqOwwnm6Lx+R5uWzX7oa10tx9N7KmzVE/"
        "eTe5DqObVvq8Sy/dtNLXde2dvz3W9f8ANPUW/PhGHJoAAAAASUVORK5CYII="
    )
}
_AUMID = "LS.IQBotEscaner"
_NOTI_PC = {"listo": False, "dir": None, "propio": False}


def _preparar_noti_pc():
    """Una sola vez: guarda las imágenes y registra la app para que Windows muestre 'IQ Bot Escáner' con su logo."""
    if _NOTI_PC["listo"]:
        return
    import base64
    carpeta = os.path.join(nucleo.DATOS, "notificaciones")
    os.makedirs(carpeta, exist_ok=True)
    for k, partes in _IMG_NOTI.items():
        ruta = os.path.join(carpeta, k + (".png" if k == "logo" else ".jpg"))
        if not os.path.exists(ruta):
            with open(ruta, "wb") as f:
                f.write(base64.b64decode("".join(partes)))
    try:
        import winreg
        clave = winreg.CreateKey(winreg.HKEY_CURRENT_USER, "Software\\Classes\\AppUserModelId\\" + _AUMID)
        winreg.SetValueEx(clave, "DisplayName", 0, winreg.REG_SZ, "IQ Bot Escáner")
        winreg.SetValueEx(clave, "IconUri", 0, winreg.REG_SZ, os.path.join(carpeta, "logo.png"))
        winreg.SetValueEx(clave, "IconBackgroundColor", 0, winreg.REG_SZ, "FF0B1122")
        winreg.SetValueEx(clave, "ShowInSettings", 0, winreg.REG_DWORD, 1)
        winreg.CloseKey(clave)
        _NOTI_PC["propio"] = True
    except Exception as e:
        _aviso_error("registro Windows", e)
    _NOTI_PC["dir"] = carpeta
    _NOTI_PC["listo"] = True


def _notificar_windows(titulo, texto, tipo=None):
    import base64, subprocess
    from xml.sax.saxutils import escape
    _preparar_noti_pc()
    carpeta = _NOTI_PC["dir"]
    imagenes = ""
    if tipo in _IMG_NOTI:
        hero = os.path.join(carpeta, tipo + ".jpg").replace("\\", "/")
        imagenes += f"<image placement='hero' src='file:///{escape(hero)}'/>"
    logo = os.path.join(carpeta, "logo.png").replace("\\", "/")
    imagenes += f"<image placement='appLogoOverride' src='file:///{escape(logo)}'/>"
    xml = ("<toast><visual><binding template='ToastGeneric'>" + imagenes + "<text>" + escape(titulo) + "</text><text>"
           + escape(texto) + "</text><text placement='attribution'>IQ Bot Escáner</text></binding></visual>"
           "<audio src='ms-winsoundevent:Notification.Default'/></toast>")
    xml = xml.replace("'", "''")                  # comillas para PowerShell
    def enviar(app_id):
        ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
              "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null;"
              "$x = New-Object Windows.Data.Xml.Dom.XmlDocument; $x.LoadXml('" + xml + "');"
              "$n = [Windows.UI.Notifications.ToastNotification]::new($x);"
              "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('" + app_id + "').Show($n)")
        cod = base64.b64encode(ps.encode("utf-16-le")).decode()
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-EncodedCommand", cod],
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=20,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        return r.returncode == 0 and not r.stderr.strip(), r.stderr.decode("utf-8", "ignore").strip()[:200]
    ok, err = enviar(_AUMID) if _NOTI_PC["propio"] else (False, "")
    if not ok:                                    # respaldo: como notificación de Windows PowerShell
        ok, err2 = enviar("{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe")
        if not ok:
            _aviso_error("Windows", RuntimeError(err2 or err or "Windows no mostró la notificación"))


def _bot_activo():
    try:
        return _API[0]._bot if _API else None
    except Exception:
        return None


def _notificar_simple(titulo, texto):
    """Último recurso: notificación normal de Android, sin diseño."""
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado",
           jclass("android.app.NotificationManager").IMPORTANCE_HIGH, alerta=True)
    b = _builder(ctx, "iqbot_alertas")
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(titulo).setContentText(texto).setAutoCancel(True) \
     .setContentIntent(_pi_abrir(ctx)).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    _NOTIF_N[0] += 1
    ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).notify(_NOTIF_N[0], b.build())


def _ruta_perfil():
    return os.path.join(nucleo.DATOS, "perfil.json")


def _leer_perfil():
    """Datos del usuario que no se cambian (su nombre)."""
    try:
        with open(_ruta_perfil(), encoding="utf-8") as f:
            p = json.load(f)
        return p if isinstance(p, dict) else {}
    except Exception:
        return {}


def _quitar_aviso_mercado():
    """Borra la tarjeta de mercado (errático / óptimo) cuando el bot se detiene."""
    if not _es_android():
        return
    try:
        from java import jclass
        _ctx().getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).cancel(77)
    except Exception:
        pass


def notificar_sistema(titulo, texto, **datos):
    if str(datos.get("tipo", "")).startswith("mercado"):
        b = getattr(nucleo, "BOT_ACTUAL", None)
        if b is None or b.detener or b.terminado:
            return                                       # sin bot trabajando no hay avisos de mercado
    if _es_android():
        try:
            _notificar_android(titulo, texto, **datos)
        except Exception as e:
            _aviso_error("aviso", e)
            try:
                _notificar_simple(titulo, texto)
            except Exception as e2:
                _aviso_error("aviso simple", e2)
        return
    try:
        if False:
            pass
        elif sys.platform.startswith("win"):
            tipo = datos.get("tipo")
            if tipo == "ganada":
                d = datos.get("dir")
                titulo = f"{datos.get('par', '')} {'▲ CALL' if d == 'call' else '▼ PUT'} · {nucleo.texto_dinero(datos.get('monto', 0))}"
                texto = f"{datos.get('op', 'Entrada')} · Sesión {nucleo.texto_dinero(datos.get('sesion', 0))}"
            elif tipo in ("stopwin", "stoploss"):
                titulo = f"{nucleo.texto_dinero(datos.get('monto', 0))} · {'Meta cumplida' if tipo == 'stopwin' else 'Saldo protegido'}"
            _notificar_windows(titulo, texto, tipo)
    except Exception as e:
        _aviso_error("Windows", e)


nucleo.NOTIFICAR = notificar_sistema


def _permisos_android():
    """Pide permiso de notificaciones (Android 13+) y que no se limite la batería."""
    from java import jclass, jarray
    ctx = _actividad()
    Build = jclass("android.os.Build$VERSION")
    if Build.SDK_INT >= 33 and ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0:
        permisos = jarray(jclass("java.lang.String"))(["android.permission.POST_NOTIFICATIONS"])
        _en_ui(lambda: ctx.requestPermissions(permisos, 77))
    Context = jclass("android.content.Context")
    pm = ctx.getSystemService(Context.POWER_SERVICE)
    if Build.SDK_INT >= 23 and not pm.isIgnoringBatteryOptimizations(ctx.getPackageName()):
        Intent = jclass("android.content.Intent")
        Uri = jclass("android.net.Uri")
        i = Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + ctx.getPackageName()))
        _en_ui(lambda: ctx.startActivity(i))


_SERVICIO = {"texto": "Toca para abrir", "activo": False, "error": "", "cerrojos": []}


def servicio_iniciar(servicio, intent):
    """Lo llama el servicio de Android al arrancar (o al tocar un botón de sus notificaciones):
    notificación fija + CPU y wifi despiertos."""
    from java import jclass
    Build = jclass("android.os.Build$VERSION")
    try:
        accion = intent.getAction() if intent is not None else None
        if accion in ("iqbot.OPERAR_IGUAL", "iqbot.SEGUIR"):
            if _API:
                if accion == "iqbot.OPERAR_IGUAL":
                    _API[0].operar_igual()
                else:
                    _API[0].seguir_operando()
            nm = servicio.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
            nm.cancel(77)                                # quita el aviso de mercado
    except Exception:
        pass
    _SERVICIO["ctx"] = servicio.getApplicationContext()
    notif = _noti_trabajando(servicio, _SERVICIO["texto"], _bot_activo())
    if Build.SDK_INT >= 34:
        ServiceInfo = jclass("android.content.pm.ServiceInfo")
        servicio.startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    else:
        servicio.startForeground(1, notif)
    if not _SERVICIO["cerrojos"]:
        Context = jclass("android.content.Context")
        PowerManager = jclass("android.os.PowerManager")
        cpu = servicio.getSystemService(Context.POWER_SERVICE).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "iqbot:operando")
        cpu.acquire()
        _SERVICIO["cerrojos"].append(cpu)
        try:
            WifiManager = jclass("android.net.wifi.WifiManager")
            wifi = servicio.getApplicationContext().getSystemService(Context.WIFI_SERVICE) \
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "iqbot:wifi")
            wifi.acquire()
            _SERVICIO["cerrojos"].append(wifi)
        except Exception:
            pass
    _SERVICIO["activo"] = True


def servicio_detener(servicio=None):
    for c in _SERVICIO["cerrojos"]:
        try:
            if c.isHeld():
                c.release()
        except Exception:
            pass
    _SERVICIO["cerrojos"] = []
    _SERVICIO["activo"] = False
    _quitar_aviso_mercado()
    _SERVICIO["ctx"] = None


def _actualizar_noti(texto):
    """Cambia el texto de la notificación fija (ganancias de la sesión)."""
    _SERVICIO["texto"] = texto
    if not _SERVICIO["activo"]:
        return
    try:
        from java import jclass
        ctx = _ctx()
        nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
        nm.notify(1, _noti_trabajando(ctx, texto, _bot_activo()))
    except Exception:
        pass


def segundo_plano(encender, texto="Toca para abrir"):
    """Celular: enciende o apaga el servicio que mantiene vivo el bot con la app cerrada o bloqueada.
    Devuelve (ok, motivo)."""
    if not _es_android():
        return True, ""
    try:
        from java import jclass
        ctx = _actividad()
        Intent = jclass("android.content.Intent")
        i = Intent()
        i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
        if encender:
            _SERVICIO["texto"] = texto
            try:
                _permisos_android()
            except Exception:
                pass
            if jclass("android.os.Build$VERSION").SDK_INT >= 26:
                r = ctx.startForegroundService(i)
            else:
                r = ctx.startService(i)
            if r is None:
                return False, "este APK no trae el servicio de segundo plano"
            _SERVICIO["activo"] = True
            threading.Thread(target=lambda: (time.sleep(2), _actualizar_noti(texto)), daemon=True).start()
        else:
            ctx.stopService(i)
            servicio_detener()
        return True, ""
    except Exception as e:
        _SERVICIO["error"] = str(e)[:150]
        return False, _SERVICIO["error"]


def _vigilar_fin(bot):
    """Mientras el bot trabaja actualiza la tarjeta fija (y la esconde con la app abierta);
    al terminar apaga el servicio."""
    ultimo = None
    while not bot.terminado:
        try:
            clave = (_app_visible(), round(bot.pnl, 2), bot.stats["ganadas"], bot.pausa_mercado(), getattr(bot, "espera_decision", False),
                     getattr(bot, "ultima_ganada", ""), str((getattr(bot, "ultima_entrada", None) or {}).get("par")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("dir")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("intento")), len(bot.abiertas))
            if clave != ultimo:
                _actualizar_noti("")
                ultimo = clave
        except Exception:
            pass
        time.sleep(2)
    segundo_plano(False)


def anotar_error():
    try:
        with open(nucleo.ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}]\n{traceback.format_exc()}")
    except Exception:
        pass


ETIQUETAS = {
    "MHI_1": "MHI 1", "MHI_2": "MHI 2", "MHI_3": "MHI 3", "MHI_Mayoria_1": "Mayoría 1", "MHI_Mayoria_2": "Mayoría 2",
    "MHI_Mayoria_3": "Mayoría 3", "Torres_Gemelas": "Torres Gemelas", "Tres_Mosqueteros": "Tres Mosqueteros",
    "Tres_Vecinos": "Tres Vecinos", "Padron_23": "Padrón 23", "Mejor_de_3": "Mejor de 3", "Patron_3x1": "Patrón 3x1",
    "Minoria_3_velas": "Minoría 3 velas", "Mayoria_3_velas": "Mayoría 3 velas", "RSI_extremo": "RSI extremo",
    "Bollinger_rechazo": "Bollinger", "Cruce_EMA_9_21": "Cruce EMA 9/21", "Envolvente": "Envolvente", "Pinbar": "Pinbar",
    "Tres_soldados": "Tres soldados", "Estocastico": "Estocástico", "Pullback_EMA": "Pullback EMA",
    "Williams_R": "Williams %R", "CCI_extremo": "CCI extremo", "Cruce_MACD": "Cruce MACD",
    "Agotamiento": "Agotamiento", "Vela_de_fuerza": "Vela de fuerza", "Rechazo_SR": "Rechazo en S/R",
    "Retesteo_ruptura": "Retesteo de ruptura", "Numero_redondo": "Número redondo",
    "Milhao_Maioria": "Milhão Maioria", "Milhao_Minoria": "Milhão Minoria", "Reversao": "Reversão",
    "Heikin_Ashi": "Heikin-Ashi",
    "Tres_dentro": "Tres velas dentro", "Estrella": "Estrella mañana/tarde", "Harami": "Harami", "Pinzas": "Pinzas",
    "Doji_Bollinger": "Doji en Bollinger", "Parabolic_SAR": "Parabolic SAR", "ADX_DI": "ADX + DI",
    "Donchian": "Ruptura Donchian", "Keltner": "Rechazo Keltner", "Cruce_EMA_5_13": "Cruce EMA 5/13",
    "RSI_2": "RSI 2 (Connors)", "Ichimoku": "Ichimoku", "Barra_interna": "Barra interna", "Fractal": "Ruptura fractal",
    "Awesome": "Awesome Oscillator", "Momentum": "Momentum",
}


AUTOR_CORREOS = {"serpaleiner79@gmail.com"}      # solo el autor ve y usa "Exportar datos"
AUTOR_IDS = {"196447152"}


def es_autor(api):
    try:
        if str(api._cfg.get("email", "")).strip().lower() in AUTOR_CORREOS:
            return True
        return bool(api._broker) and str(api._broker.id_iq()).strip() in AUTOR_IDS
    except Exception:
        return False


_EXPORTAR = ("historial.csv", "operaciones.csv", "bot.log", "errores.log", "config_bot.json", "perfil.json",
             "ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_senales.json",
             "campos_saldo.log", "actualizaciones.log", "sombra_catalogo.json")


def _exportar_android(rutas, carpeta):
    """Copia los archivos a Descargas/IQBot/<carpeta> del celular (Android 10+), o a la carpeta de la app en USB."""
    from java import jclass
    ctx = _ctx()
    if jclass("android.os.Build$VERSION").SDK_INT >= 29:
        CV = jclass("android.content.ContentValues")
        Descargas = jclass("android.provider.MediaStore$Downloads")
        cr = ctx.getContentResolver()
        for ruta in rutas:
            v = CV()
            v.put("_display_name", os.path.basename(ruta))
            v.put("mime_type", "application/octet-stream")
            v.put("relative_path", "Download/IQBot/" + carpeta)
            uri = cr.insert(Descargas.EXTERNAL_CONTENT_URI, v)
            if uri is None:
                raise OSError("Android no dejó crear el archivo en Descargas")
            out = cr.openOutputStream(uri)
            try:
                with open(ruta, "rb") as f:
                    while True:
                        trozo = f.read(256 * 1024)
                        if not trozo:
                            break
                        try:
                            out.write(trozo)
                        except Exception:
                            from java import jarray, jbyte
                            out.write(jarray(jbyte)(trozo))
            finally:
                out.close()
        return "Descargas/IQBot/" + carpeta
    import shutil
    base = ctx.getExternalFilesDir(None).getAbsolutePath()
    destino = os.path.join(base, "IQBot", carpeta)
    os.makedirs(destino, exist_ok=True)
    for ruta in rutas:
        shutil.copy2(ruta, destino)
    return destino


def exportar_datos():
    """Copia el historial y la memoria del bot a una carpeta fácil de encontrar. Devuelve dict para la interfaz."""
    import shutil
    rutas = [os.path.join(nucleo.DATOS, n) for n in _EXPORTAR if os.path.isfile(os.path.join(nucleo.DATOS, n))]
    if not rutas:
        return {"ok": False, "mensaje": "Todavía no hay datos para exportar."}
    carpeta = time.strftime("%Y-%m-%d_%H%M")
    try:
        if _es_android():
            donde = _exportar_android(rutas, carpeta)
        else:
            docs = os.path.join(os.path.expanduser("~"), "Documents")
            destino = os.path.join(docs if os.path.isdir(docs) else os.path.expanduser("~"), "IQBot datos", carpeta)
            os.makedirs(destino, exist_ok=True)
            for r in rutas:
                shutil.copy2(r, destino)
            donde = destino
            try:
                os.startfile(destino)
            except Exception:
                pass
    except Exception as e:
        return {"ok": False, "mensaje": f"No se pudo exportar: {e}"}
    return {"ok": True, "mensaje": f"{len(rutas)} archivos copiados en {donde}"}


class Api:
    """Métodos que la ventana puede llamar (window.pywebview.api.*)."""

    def __init__(self):
        _API[:] = [self]
        self._cfg = nucleo.cargar_config()
        self._broker = None
        self._bot = None
        self._nombre = "DEMO"
        self._login = {"fase": "inactivo", "mensaje": ""}
        self._evento_codigo = threading.Event()
        self._codigo = ""
        self._monitor = None   # lee el mercado desde que se inicia sesión (antes de arrancar el bot)
        viejo = getattr(nucleo, "BOT_ACTUAL", None)      # se cerró la ventana con el bot trabajando: se retoma
        if viejo is not None and not viejo.terminado and not viejo.detener:
            self._bot, self._broker, self._nombre = viejo, viejo.b, viejo.cuenta
        ajustar_teclado_android()
        self._prep = {"listo": False, "mensaje": "Revisando la librería de IQ Option…"}
        threading.Thread(target=self._preparar, daemon=True).start()

    # ---------- arranque ----------
    def _preparar(self):
        try:
            if not nucleo.CONGELADO:
                nucleo.asegurar_librerias()
                if self._cfg.get("actualizar_libreria", True):
                    nucleo.actualizar_libreria()
            elif self._cfg.get("actualizar_libreria", True):
                # .exe / Android: busca versión nueva de la librería en GitHub y la usa si es válida
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones de la librería de IQ Option…"}
                cambio, msg = nucleo.actualizar_libreria_embebida()
                if cambio:
                    self._prep = {"listo": True, "mensaje": msg}
            # actualizaciones del bot publicadas por el autor (firmadas)
            arr = _arranque()
            if arr is not None and getattr(arr, "URL_ACTUALIZACIONES", ""):
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones del bot…"}
                nueva = arr.buscar_actualizacion(lambda t: self._prep.update(mensaje=t))
                if nueva:
                    self._prep = {"listo": False, "mensaje": f"Actualización {nueva} instalada. Reiniciando…"}
                    time.sleep(1.5)
                    reiniciar_programa()
                    return
            if self._prep.get("mensaje", "").startswith("Librería de IQ Option actualizada"):
                self._prep = {"listo": True, "mensaje": self._prep["mensaje"]}
            else:
                self._prep = {"listo": True, "mensaje": "Listo para conectar" + self._estado_actualizaciones(arr)}
        except BaseException as e:
            anotar_error()
            self._prep = {"listo": True, "mensaje": f"Aviso al preparar: {str(e)[:80]}"}

    def _estado_actualizaciones(self, arr):
        """Texto corto para la pantalla de inicio: versión y si la revisión de actualizaciones falló."""
        if arr is None or not getattr(arr, "URL_ACTUALIZACIONES", ""):
            return ""                                  # la versión ya se ve abajo a la izquierda
        try:
            with open(os.path.join(arr.DATOS, "actualizaciones.log"), encoding="utf-8") as f:
                ultima = f.read().strip().splitlines()[-1]
            hora = time.mktime(time.strptime(ultima[1:20], "%Y-%m-%d %H:%M:%S"))
            if time.time() - hora < 120 and ("No se pudo" in ultima or "inválida" in ultima or "no coincide" in ultima):
                return " · no se pudo revisar actualizaciones"
        except Exception:
            pass
        return ""

    def preparacion(self):
        return self._prep

    def guardar_nombre(self, nombre):
        """El nombre del usuario se guarda UNA sola vez; después no se puede cambiar."""
        p = _leer_perfil()
        if p.get("nombre"):
            return {"ok": False, "nombre": p["nombre"], "mensaje": "El nombre ya está guardado."}
        limpio = " ".join(str(nombre or "").split())[:24]
        if sum(ch.isalpha() for ch in limpio) < 2:
            return {"ok": False, "mensaje": "Escribe tu nombre (al menos 2 letras)."}
        p["nombre"] = limpio
        try:
            with open(_ruta_perfil(), "w", encoding="utf-8") as f:
                json.dump(p, f, ensure_ascii=False)
        except Exception as e:
            return {"ok": False, "mensaje": f"No se pudo guardar: {e}"}
        return {"ok": True, "nombre": limpio}

    def enviar_diagnostico(self):
        """Manda al autor (Leiner) el diagnóstico del bot: registros recientes, errores, cuenta, moneda y versión.
        Nunca manda la contraseña. Llega a su servidor de licencias (hoja 'Diagnosticos' + correo)."""
        import requests, platform
        def cola(nombre, n):
            try:
                with open(os.path.join(nucleo.DATOS, nombre), encoding="utf-8", errors="ignore") as f:
                    return f.read()[-n:]
            except Exception:
                return ""
        b = self._broker
        try:
            id_iq = str(b.id_iq()) if b else ""
        except Exception:
            id_iq = ""
        cfg = {k: v for k, v in self._cfg.items() if "clave" not in k.lower() and "pass" not in k.lower()}
        bot = self._bot
        datos = {
            "accion": "diagnostico", "key": nucleo.LICENCIA_KEY,
            "correo": self._cfg.get("email", ""), "id_iq": id_iq, "cuenta": self._cfg.get("cuenta", ""),
            "moneda": getattr(b, "moneda", "") if b else "", "tasa": str(getattr(b, "tasa", "")) if b else "",
            "saldo": str(b.saldo()) if b else "", "version": f"{nucleo.VERSION_BOT} build {nucleo.BUILD_BOT}",
            "equipo": ("Android" if _es_android() else platform.platform())[:80],
            "fase": getattr(bot, "fase", "") if bot else "sin bot",
            "aviso": json.dumps(getattr(bot, "aviso_error", None), ensure_ascii=False) if bot else "",
            "config": json.dumps(cfg, ensure_ascii=False)[:2000],
            "registro": cola("bot.log", 12000), "errores": cola("errores.log", 6000),
            "campos_saldo": "",
        }
        try:
            datos["campos_saldo"] = json.dumps(b.campos_saldo(), ensure_ascii=False)[:3000] if b else ""
        except Exception:
            pass
        try:
            r = requests.post(nucleo.LICENCIA_URL, data=datos, timeout=30)
            if r.status_code == 200 and "OK" in (r.text or "")[:40]:
                return {"ok": True, "mensaje": "Diagnóstico enviado. El soporte ya lo tiene."}
            return {"ok": False, "mensaje": "El servidor no recibió el diagnóstico. Intenta más tarde."}
        except Exception:
            return {"ok": False, "mensaje": "No se pudo enviar (revisa tu internet)."}

    def exportar_datos(self):
        if not es_autor(self):
            return {"ok": False, "mensaje": "Opción no disponible."}
        return exportar_datos()

    def inicio(self):
        arr = _arranque()
        if arr is not None:
            try:
                arr.confirmar()        # la ventana abrió bien con esta versión
            except Exception:
                pass
        return {"email": self._cfg.get("email", ""), "cuenta": self._cfg.get("cuenta", "PRACTICE"),
                "version": nucleo.VERSION_BOT, "nombre": _leer_perfil().get("nombre", ""),
                "bot_activo": bool(self._bot and not self._bot.terminado and not self._bot.detener)}

    def crear_cuenta(self):
        """Abre el registro de IQ Option con el enlace de afiliado del autor (en el navegador del equipo)."""
        try:
            if ABRIR_ENLACE:
                ABRIR_ENLACE(ENLACE_REGISTRO)
            else:
                import webbrowser
                webbrowser.open(ENLACE_REGISTRO, new=2)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mensaje": str(e)}

    # ---------- inicio de sesión ----------
    def iniciar_sesion(self, email, clave, cuenta):
        if self._login["fase"] in ("conectando", "codigo", "licencia"):
            return {"ok": False, "mensaje": "Ya se está conectando…"}
        if "@" not in (email or ""):
            return {"ok": False, "mensaje": "Escribe un correo válido."}
        if not clave:
            return {"ok": False, "mensaje": "Escribe tu contraseña."}
        if not self._prep["listo"]:
            return {"ok": False, "mensaje": "Espera un momento: se está preparando la librería de IQ Option."}
        self._login = {"fase": "conectando", "mensaje": ""}
        threading.Thread(target=self._hacer_login, args=(email.strip(), clave, cuenta), daemon=True).start()
        return {"ok": True}

    def _pedir_codigo(self):
        self._evento_codigo.clear()
        self._login = {"fase": "codigo", "mensaje": ""}
        self._evento_codigo.wait(300)
        self._login = {"fase": "conectando", "mensaje": ""}
        return self._codigo

    def enviar_codigo(self, codigo):
        self._codigo = (codigo or "").strip()
        self._evento_codigo.set()
        return {"ok": True}

    def _hacer_login(self, email, clave, cuenta):
        try:
            broker, error = nucleo.BrokerIQ.iniciar_sesion(email, clave, self._pedir_codigo)
            clave = None
            if not broker:
                self._login = {"fase": "error", "mensaje": error}
                return
            self._login = {"fase": "licencia", "mensaje": ""}
            id_iq = broker.id_iq()
            ok, msg = nucleo.verificar_licencia(email, id_iq)
            if not ok:
                self._login = {"fase": "sin_licencia", "mensaje": msg, "id_iq": id_iq}
                return
            cuenta = "REAL" if cuenta == "REAL" else "PRACTICE"
            broker.usar_cuenta(cuenta)
            self._broker = broker
            self._nombre = "REAL" if cuenta == "REAL" else "DEMO"
            self._cfg["email"] = email
            self._cfg["cuenta"] = cuenta
            nucleo.guardar_config(self._cfg)
            self._login = {"fase": "listo", "mensaje": "", "licencia": msg}
            self._vigilar_mercado()
        except Exception as e:
            anotar_error()
            self._login = {"fase": "error", "mensaje": f"Error inesperado al conectar: {e}"}

    # ---------- lectura del mercado ----------
    def _vigilar_mercado(self):
        if self._monitor:
            self._monitor.parar = True
        self._monitor = nucleo.MonitorMercado(self._broker, self._cfg) if self._broker else None

    def _dejar_de_vigilar(self):
        if self._monitor:
            self._monitor.parar = True
            self._monitor = None

    def mercado(self):
        return nucleo.MERCADO.resumen()

    def operar_igual(self):
        """El cliente decide operar aunque el mercado esté malo."""
        nucleo.MERCADO.operar_igual = True
        if self._bot:
            self._bot.log("▶ Operando aunque el mercado está malo, por decisión del usuario.", "yellow")
        return {"ok": True}

    def seguir_operando(self):
        """El mercado mejoró y el cliente decide seguir operando."""
        if self._bot:
            self._bot.seguir_operando()
        return {"ok": True}

    def estado_login(self):
        return self._login

    def cerrar_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "Detén el bot primero."}
        try:
            if self._broker:
                self._broker.api.api.close()
        except Exception:
            pass
        self._dejar_de_vigilar()
        self._broker = None
        self._bot = None
        self._login = {"fase": "inactivo", "mensaje": ""}
        return {"ok": True}

    # ---------- configuración ----------
    def datos_config(self):
        estrategias = []
        for n, fn in nucleo.ESTRATEGIAS.items():
            estrategias.append({"nombre": n, "etiqueta": ETIQUETAS.get(n, n.replace("_", " ")),
                                "grupo": "cuadrante" if n in nucleo.ESTRATEGIAS_CUADRANTE else "indicadores",
                                "descripcion": (fn.__doc__ or "").strip()})
        c = dict(self._cfg)
        c["max_pares"] = nucleo.MAX_PARES
        saldo = self._broker.saldo() if self._broker else None
        return {"cfg": c, "estrategias": estrategias, "email": self._cfg.get("email", ""),
                "cuenta": self._cfg.get("cuenta", "PRACTICE"), "saldo": saldo if isinstance(saldo, (int, float)) else None,
                "moneda": getattr(self._broker, "moneda", "USD") if self._broker else "USD",
                "tasa": getattr(self._broker, "tasa", 1.0) if self._broker else 1.0,
                "autor": es_autor(self)}

    def _mezclar(self, parcial):
        c = dict(self._cfg)
        c.update({k: v for k, v in (parcial or {}).items() if k in nucleo.DEFAULT_CONFIG})
        return c

    def tabla_recuperacion(self, parcial):
        c = self._mezclar(parcial)
        c["recuperacion"] = "niveles"
        if c.get("recuperacion") == "ninguna":
            return {"filas": [], "total": float(c.get("monto_entrada") or 0), "mult_insuficiente": False}
        try:
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            filas = nucleo.tabla_recuperacion(c, 0.85)
        except Exception:
            return {"filas": [], "total": 0, "mult_insuficiente": False}
        return {"filas": [{"paso": e, "monto": m, "perdido": p, "neto": round(n, 2)} for e, m, p, n in filas],
                "total": filas[-1][2] if filas else 0,
                "mult_insuficiente": c["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:])}

    def iniciar_bot(self, parcial):
        if not self._broker:
            return {"ok": False, "mensaje": "No hay sesión iniciada."}
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "El bot ya está funcionando."}
        c = self._mezclar(parcial)
        try:
            c["monto_entrada"] = float(c["monto_entrada"])
            c["max_operaciones_simultaneas"] = 1                       # una operación a la vez
            c["recuperacion"] = "niveles"                              # solo niveles (sin gales)
            c["max_pares"] = nucleo.MAX_PARES                          # siempre todos los pares
            c["payout_minimo"] = float(c["payout_minimo"])
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            c["stop_win"] = float(c["stop_win"]); c["stop_loss"] = float(c["stop_loss"])
            c["winrate_minimo"] = float(c["winrate_minimo"]); c["confluencia_minima"] = max(1, int(c["confluencia_minima"]))
            c["anticipo_ms"] = max(50, min(1500, int(c["anticipo_ms"])))
            c["min_senales_catalogo"] = max(5, min(60, int(c["min_senales_catalogo"])))
            c["winrate_minimo"] = max(0.50, min(0.95, c["winrate_minimo"]))
            tfs = [int(t) for t in (c.get("temporalidades") or []) if int(t) in (1, 5, 15)]
            c["temporalidades"] = tfs[:1]                              # una sola temporalidad
            c["incluir_digital"] = bool(c.get("incluir_digital", False))
        except Exception:
            return {"ok": False, "mensaje": "Revisa los números de la configuración."}
        if c["monto_entrada"] < 1:
            return {"ok": False, "mensaje": "La entrada mínima en IQ Option es $1."}
        if not c["temporalidades"]:
            return {"ok": False, "mensaje": "Elige la temporalidad."}
        if not (c["incluir_mercado_real"] or c["incluir_otc"] or c["incluir_digital"]):
            return {"ok": False, "mensaje": "Elige al menos un mercado: real, OTC o digital."}
        if c["stop_win"] <= 0 or c["stop_loss"] <= 0:
            return {"ok": False, "mensaje": "Los stops deben ser mayores que cero."}
        saldo = self._broker.saldo()
        if isinstance(saldo, (int, float)) and c["stop_loss"] > saldo:
            return {"ok": False, "mensaje": f"El stop loss (${c['stop_loss']:.2f}) es mayor que tu saldo (${saldo:.2f})."}
        self._cfg = c
        nucleo.guardar_config(c)
        nucleo.RECOLECTAR_VELAS = es_autor(self)          # solo el autor junta velas para entrenar el modelo profundo
        try:
            self._bot = nucleo.Bot(self._broker, c, self._nombre)
            self._bot.iniciar_hilos()
            ok_sp, motivo_sp = segundo_plano(True, f"{'REAL' if c.get('cuenta') == 'REAL' else 'DEMO'} · operando")
            if _es_android():
                if ok_sp:
                    self._bot.log("📱 Segundo plano activo: puedes bloquear el celular o usar otras apps.", "green")
                else:
                    self._bot.log(f"⚠ No se pudo activar el segundo plano ({motivo_sp}). Deja la app abierta "
                                  f"y la pantalla encendida.", "bold yellow")
            threading.Thread(target=_vigilar_fin, args=(self._bot,), daemon=True).start()
            self._dejar_de_vigilar()          # con el bot andando, él mismo lee el mercado cada minuto
            if nucleo.MERCADO.pausa:
                self._bot.log("⚠ El mercado está malo: el bot arranca en pausa hasta que mejore.", "bold yellow")
        except Exception as e:
            anotar_error()
            return {"ok": False, "mensaje": f"No se pudo iniciar: {e}"}
        return {"ok": True}

    # ---------- operaciones ----------
    def estado(self):
        if not self._bot:
            return {}
        try:
            r = self._bot.resumen_gui()
            if isinstance(r, dict):
                if not hasattr(self, "_es_autor"):
                    self._es_autor = es_autor(self)
                r["autor"] = self._es_autor              # solo el autor ve "Enviar diagnóstico"
            return r
        except Exception:
            anotar_error()
            return {}

    def pausar(self):
        if self._bot:
            self._bot.pausado = not self._bot.pausado
            self._bot.log("⏸ Bot en pausa: sigue analizando pero no abre operaciones." if self._bot.pausado
                         else "▶ Bot reanudado.", "yellow")
        return {"pausado": bool(self._bot and self._bot.pausado)}

    def detener(self):
        _quitar_aviso_mercado()
        if self._bot and not self._bot.detener:
            self._bot.detener = True
            self._bot.log("Deteniendo por pedido del usuario: se esperan las operaciones abiertas.", "yellow")
        return {"ok": True}

    def nueva_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False}
        self._bot = None
        self._vigilar_mercado()
        return {"ok": True}

    def bot_operando(self):
        """True solo si el bot está trabajando (no detenido). Así la X pregunta solo cuando hace falta."""
        return bool(self._bot and not self._bot.detener and not self._bot.terminado)

    def al_cerrar(self):
        self._dejar_de_vigilar()
        try:
            nucleo.inteligencia().guardar(forzar=True)
        except Exception:
            pass
        if self._bot:
            self._bot.detener = True


def main():
    nucleo.ordenar_archivos()
    import webview
    api = Api()
    with open(ruta_recurso("interfaz.html"), encoding="utf-8") as f:
        html = f.read()
    ventana = webview.create_window("IQ Bot Escáner", html=html, js_api=api, width=1240, height=800,
                                    min_size=(720, 540), background_color="#0B0F14", confirm_close=False)

    def al_intentar_cerrar():
        # pregunta solo si el bot está operando; si ya se detuvo (o no ha empezado) cierra directo
        ventana.confirm_close = api.bot_operando()

    ventana.events.closing += al_intentar_cerrar
    ventana.events.closed += lambda: api.al_cerrar()
    opciones = {"gui": "edgechromium"} if sys.platform == "win32" else {}
    webview.start(**opciones, localization={
        "global.quitConfirmation": "El bot está operando. ¿Cerrarlo? Las operaciones abiertas siguen en IQ Option hasta su vencimiento.",
        "global.ok": "Aceptar", "global.quit": "Cerrar", "global.cancel": "Cancelar"})


def arrancar():
    try:
        main()
    except Exception:
        anotar_error()
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, "No se pudo abrir la ventana de IQ Bot Escáner.\n\n"
                                             "Si la ventana no aparece, instala 'Microsoft Edge WebView2 Runtime' "
                                             "(gratis, de microsoft.com) y vuelve a abrir el programa.\n\n"
                                             "Detalle en errores.log, carpeta: " + nucleo.DATOS, "IQ Bot Escáner", 0x10)
        except Exception:
            raise


if __name__ == "__main__":
    arrancar()
