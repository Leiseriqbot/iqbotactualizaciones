# -*- coding: utf-8 -*-
"""
IQNOVA BOT  -  Opciones binarias / turbo en IQ Option y Exnova
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras estrategia, monto, temporalidades, recuperación y stops.
  5) Confirmas y arranca.

Qué hace:
- Vigila todos los pares abiertos (mercado real, OTC y digitales) en la temporalidad elegida (1 a 5 minutos).
- Opera con UNA estrategia que elige el cliente: Bandas de Bollinger o RSI.
- Una operación a la vez. Recuperación por niveles con la siguiente señal (sin gale). Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, threading, csv, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.

DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"

# ---------- broker: IQ Option o Exnova (la misma plataforma, distinto servidor) ----------
BROKERS = {"iqoption": "IQ Option", "exnova": "Exnova"}
BROKER = "iqoption"          # se elige al iniciar sesión (usar_broker)
DATOS_BROKER = DATOS         # IQ Option usa la carpeta de siempre; Exnova una subcarpeta propia


def nombre_broker(b=None):
    return BROKERS.get(b or BROKER, "IQ Option")


def txt_broker(x):
    """Los textos del bot dicen "IQ Option": con Exnova se muestran con su nombre."""
    if BROKER == "iqoption":
        return x
    if isinstance(x, str):
        return x.replace("IQ Option", nombre_broker())
    if isinstance(x, dict):
        return {k: txt_broker(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return type(x)(txt_broker(v) for v in x)
    return x


def _ruta_broker(nombre):
    return os.path.join(DATOS_BROKER, nombre)
VERSION_BOT = "2.0"
BUILD_BOT = 187

# Lo que se muestra UNA vez al abrir el bot después de actualizar (se cambia en cada versión).
# "especial": pantalla de anuncio propia (dos_brokers); sin "especial" se muestra la lista normal.
NOVEDADES = {
    "mostrar": False,      # lo decide el autor al publicar (PUBLICAR_ACTUALIZACION pregunta s/n)
    "titulo": "IQNOVA BOT 2.0",
    "subtitulo": "Una sola estrategia, ajustada a cada temporalidad",
    "items": [
        ["🎯", "Bollinger + RSI juntos", "Entra solo si coinciden: el precio sale de la banda y el RSI está en su extremo."],
        ["⚙️", "Se ajusta sola", "Al cambiar la temporalidad, toma sola la configuración que mejor resultado dio en ella."],
        ["⏱️", "De M1 a M5", "Elige la temporalidad que prefieras, de M1 a M5."],
        ["🧠", "IA que aprende sola", "Aprende mientras opera. Pruébala en DEMO y pásala a real solo si ves que te da resultado."],
    ],
    "solo_ia": ["IA que aprende sola"],   # estos puntos solo los ven el autor y los clientes con la IA habilitada
    "aviso": "Operar tiene riesgo alto de pérdida. Ninguna estrategia gana siempre ni garantiza resultados.",
}
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [2],           # manual: una temporalidad de 2 a 5 minutos (M1 ya no se usa)
    "tf_auto": False,                # ya no hay temporalidad Auto: una sola, de M1 a M5
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "incluir_digital": True,         # también opciones digitales (se usa la que mejor pague)
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "auto",          # recuperación por niveles con la siguiente señal (sin gale)
    "rec_max": 2,                    # máximo de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "modo_riesgo": "normal",
    "config_v": 6,                   # 3.0: estrategia única · 4: RSI normal · 5: temporalidad en minutos · 6: sin M1
    # estrategia (3.0)
    "estrategia": "bbrsi",           # "bbrsi" (Bollinger + RSI, configuración automática por temporalidad) o "ia"
    "bb_periodo": 20,
    "bb_desv": 2.0,
    "rsi_periodo": 2,
    "rsi_alto": 60.0,
    "rsi_bajo": 40.0,
    "rsi_direccion": "normal",       # "normal" o "invertida" (el cliente la invierte si quiere)
    "entrada": "cierre",             # "cierre" o "estirado" (al estirarse, solo Bollinger)
    "ia_prob_min": 58,               # modo "segura": mínimo de acierto que calcula la IA para entrar (55 a 70 %)
    "ia_modo": "normal",             # solo el autor: "segura" = la IA entra solo con su señal más segura (espera lo necesario)
    "ia_forzar": False,              # solo el autor: la IA opera aunque no pase el umbral (DEMO o REAL, decisión del autor)
    "estiro": 20.0,                  # al estirarse: % del ancho de las bandas que el precio debe pasar la banda
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    if not falta_iq and ws_ok and req_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando

REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def _traer_datos_exnova_viejo():
    """Si en este equipo se usó el "Exnova Bot Escáner" aparte, su aprendizaje se trae una sola vez."""
    import shutil
    viejo = os.path.join(os.path.dirname(DATOS), "ExnovaBotEscaner")
    marca = _ruta_broker(".traido")
    if not os.path.isdir(viejo) or os.path.exists(marca):
        return
    try:
        for n in ("historial.csv",):
            if os.path.isfile(os.path.join(viejo, n)) and not os.path.exists(_ruta_broker(n)):
                shutil.copy2(os.path.join(viejo, n), _ruta_broker(n))
        with open(marca, "w") as f:
            f.write("ok")
    except Exception:
        pass


def usar_broker(b):
    """Elige el broker antes de iniciar sesión. Cada broker guarda su propio historial. La configuración es la misma."""
    global BROKER, DATOS_BROKER, LOG_FILE
    b = b if b in BROKERS else "iqoption"
    if b == BROKER:
        return
    BROKER = b
    DATOS_BROKER = DATOS if b == "iqoption" else os.path.join(DATOS, b)
    os.makedirs(DATOS_BROKER, exist_ok=True)
    if b == "exnova":
        _traer_datos_exnova_viejo()
    LOG_FILE = "historial.csv" if b == "iqoption" else _ruta_broker("historial.csv")


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

LOGIN_INTENTOS = 3                 # al entrar: intentos si la red o el bróker no responden


def _es_fallo_de_red(e):
    """True si el error es de la red o de que el bróker no respondió (no de la librería ni de la cuenta).
    La librería a veces devuelve el error de red como respuesta y falla al leerlo ('ConnectTimeout' object has no
    attribute 'text'): también cuenta como fallo de red."""
    t = (type(e).__name__ + " " + str(e)).lower()
    return any(x in t for x in ("connecttimeout", "readtimeout", "connectionerror", "connection aborted",
                                "connection reset", "max retries", "timed out", "timeout", "newconnectionerror",
                                "nameresolution", "getaddrinfo", "temporarily unavailable", "remote end closed",
                                "proxyerror", "10060", "10054", "10061"))


def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

LICENCIA_IA = False        # el autor marcó "SI" en la columna IA de la hoja de licencias de esta cuenta


def ia_permitida():
    """¿Esta licencia tiene la IA habilitada por el autor (columna IA = SI)?"""
    return bool(LICENCIA_IA)


def ia_ultima_licencia():
    """¿La última licencia verificada (licencia.dat, firmada) tenía la IA habilitada? Sirve antes de iniciar sesión."""
    try:
        d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
        return bool(d.get("ia")) and d.get("ia") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|ia")
    except Exception:
        return False


def _consultar_licencia(cuenta, extra=None):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión.
    extra: nombre y país del perfil del broker, solo para completar la hoja de licencias del autor."""
    import requests
    try:
        datos = {"cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
                 "build": BUILD_BOT, "v": VERSION_BOT, "plataforma": BROKER, "ia": "1"}
        datos.update({k: v for k, v in (extra or {}).items() if v})
        r = requests.get(LICENCIA_URL, timeout=15, params=datos)
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq, perfil=None):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    global LICENCIA_IA
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c, perfil)
        if r is None:
            sin_red = True; continue
        r = r.split("|")
        r, con_ia = r[0], "IA" in r[1:]           # "VALID|IA": el autor le habilitó la IA a esta cuenta
        respuestas[c] = r
        if r == "VALID":
            LICENCIA_IA = con_ia
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}"), "broker": BROKER,
                               "ia": _firma_licencia(f"{c}|{ahora}|ia") if con_ia else ""}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    LICENCIA_IA = False
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("broker", "iqoption") == BROKER
                    and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                LICENCIA_IA = d.get("ia") == _firma_licencia(f"{d['cuenta']}|{d['ok']}|ia")
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, (f"Este correo / ID de {nombre_broker()} NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de {nombre_broker()}: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def reportar_operacion(broker, cuenta, par, tf, resultado, neto, correo=""):
    """SOLO el bot del autor: manda cada resultado a su hoja, para el resumen semanal de Telegram.
    Los bots de los clientes no mandan nada (Bot.autor es False)."""
    import requests
    try:
        requests.post(LICENCIA_URL, timeout=20, data={
            "accion": "operacion", "key": LICENCIA_KEY, "id": str(broker.id_iq()), "correo": correo, "plataforma": BROKER,
            "cuenta": "REAL" if cuenta == "REAL" else "DEMO", "par": par, "tf": f"M{tf}",
            "resultado": resultado, "neto": f"{neto:.2f}", "moneda": getattr(broker, "moneda", "USD")})
    except Exception:
        pass


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        original_c = cliente.candles
        def candles(api, mensaje):
            rid = str(mensaje.get("request_id") or "") if isinstance(mensaje, dict) else ""
            if rid.startswith("iqv"):                  # pedido de la memoria de velas: no toca el buzón común
                try:
                    api._iqbot_velas[rid] = mensaje["msg"]["candles"]
                except Exception:
                    pass
                return
            original_c(api, mensaje)
        cliente.candles = candles
        cliente._iqbot_parche = True
    except Exception:
        pass
    _apuntar_broker()
    _conexion_segura()


# Exnova usa la misma plataforma que IQ Option: la librería sirve igual, solo cambian las direcciones.
EXNOVA_WS = "ws.trade.exnova.com"                 # wss://ws.trade.exnova.com/echo/websocket
EXNOVA_CAMBIOS = (("://auth.iqoption.com/", "://auth.trade.exnova.com/"),
                  ("://event.iqoption.com/", "://event.trade.exnova.com/"),
                  ("://iqoption.com/", "://trade.exnova.com/"))


def _a_exnova(texto):
    for a, b in EXNOVA_CAMBIOS:
        texto = texto.replace(a, b)
    return texto


def _apuntar_broker():
    """La librería está hecha para IQ Option. Con Exnova se cambian sus direcciones (conexión en vivo,
    inicio de sesión, código SMS y cierre de sesión). Con IQ Option queda exactamente como siempre."""
    try:
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_broker", False):
            return
        init_original = api_mod.IQOptionAPI.__init__
        def init_broker(self, host, *a, **kw):
            init_original(self, EXNOVA_WS if BROKER == "exnova" else host, *a, **kw)
        api_mod.IQOptionAPI.__init__ = init_broker
        http_original = api_mod.IQOptionAPI.send_http_request_v2
        def http_broker(self, url, method, data=None, params=None, headers=None):
            if BROKER == "exnova":
                url = _a_exnova(str(url))
                if headers:
                    headers = {k: (_a_exnova(v) if isinstance(v, str) else v) for k, v in dict(headers).items()}
            return http_original(self, url=url, method=method, data=data, params=params, headers=headers)
        api_mod.IQOptionAPI.send_http_request_v2 = http_broker
        api_mod._iqbot_broker = True
    except Exception as e:
        print(f"Aviso: no se pudo preparar la conexión con {nombre_broker()}: {e}")


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class OrdenSinConfirmar(TimeoutError):
    """IQ Option no respondió a tiempo si abrió la orden. Lleva los datos para buscarla después."""
    def __init__(self, texto, **datos):
        super().__init__(texto)
        self.datos = datos


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas por el buzón común (si el bróker no da número de pedido)
        self.lock_rid = threading.Lock()      # contador de números de pedido
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self._memo_velas = {}                 # (id del par, tamaño) -> {hora: cierre} de la última respuesta buena
        self._buzon_sucio = 0.0               # hasta cuándo puede llegar tarde una respuesta vieja al buzón común
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        nb = nombre_broker()
        intento = 0
        while True:                                     # si falla por la red, reintenta solo (3 intentos)
            intento += 1
            try:
                ok, motivo = con_timeout(api.connect, 45)
                if ok or not _es_fallo_de_red(motivo):
                    break                               # entró, o la respuesta no es de red (clave, 2FA…)
            except TimeoutError:
                pass
            except json.JSONDecodeError as e:
                crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
                return None, (f"{nb} devolvió una respuesta inesperada al iniciar sesión "
                              "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                              "navegador para confirmar que tu cuenta abre bien."
                              + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
            except Exception as e:
                if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                    return None, (f"No se pudo verificar la conexión segura con {nb} (certificado no válido). "
                                  "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                                  "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
                if not _es_fallo_de_red(e):
                    libreria_conecto(False, culpa_de_libreria=True)
                    return None, f"Error de conexión: {e}"
            if intento >= LOGIN_INTENTOS:
                return None, (f"{nb} no respondió a tiempo (se intentó {LOGIN_INTENTOS} veces). "
                              f"Puede ser tu internet o que los servidores de {nb} estén lentos en este momento. "
                              "Espera un minuto y vuelve a entrar; si sigue igual, prueba con otra red (por ejemplo, los datos del celular).")
            time.sleep(3 * intento)                     # espera un poco más en cada intento
            try:
                api = IQ_Option(email, clave)           # conexión nueva para el siguiente intento
            except Exception:
                pass
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    def perfil_publico(self):
        """Nombre y país del perfil del broker (para la hoja de licencias del autor). Nunca la contraseña."""
        try:
            p = self.inner.profile.msg or {}
            nombre = str(p.get("name") or "").strip() or " ".join(
                str(p.get(k) or "").strip() for k in ("first_name", "last_name")).strip()
            pais = ""
            for k in ("country_code", "country", "country_iso"):
                v = p.get(k)
                if isinstance(v, str) and 2 <= len(v.strip()) <= 40:
                    pais = v.strip(); break
            return {"nombre": nombre[:60], "pais": pais}
        except Exception:
            return {}

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="digital", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        raw = self._pedir_velas(aid, tf_min * 60, cantidad + 1, time.time())
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _pedir_velas(self, aid, tam, cantidad, hasta):
        """Pide velas con NÚMERO DE PEDIDO propio: la respuesta solo le llega a quien la pidió, así una respuesta
        atrasada de otro par nunca se confunde con esta (antes se mezclaban velas de otros activos).
        Si el bróker no devuelve el número, usa el buzón común con más cuidado. Siempre revisa las velas."""
        inner = self.inner
        raw = None
        if getattr(self, "_rid_ok", None) is not False:
            buzon = getattr(inner, "_iqbot_velas", None)
            if buzon is None:
                buzon = inner._iqbot_velas = {}
            with self.lock_rid:
                self._rid_n = getattr(self, "_rid_n", 0) + 1
                rid = f"iqv{self._rid_n}"
            datos = {"name": "get-candles", "version": "2.0",
                     "body": {"active_id": int(aid), "split_normalization": True, "size": int(tam),
                              "to": int(hasta), "count": int(cantidad), "": int(aid)}}
            try:
                inner.send_websocket_request("sendMessage", datos, request_id=rid)
                raw = _esperar(lambda: buzon.get(rid), 5)
            except Exception:
                raw = None
            buzon.pop(rid, None)
            if raw is not None:
                self._rid_ok = True
            elif getattr(self, "_rid_ok", None) is None:
                self._rid_ok = False                  # este bróker no devuelve el número: buzón común
        if raw is None and getattr(self, "_rid_ok", None) is False:
            with self.lock:                           # buzón común: un pedido a la vez
                espera = self._buzon_sucio - time.time()
                if espera > 0:                        # una respuesta vieja puede llegar todavía: se deja pasar
                    _esperar(lambda: inner.candles.candles_data, min(espera, 3))
                inner.candles.candles_data = None
                inner.getcandles(aid, tam, cantidad, float(hasta))
                raw = _esperar(lambda: inner.candles.candles_data, 5)
                if raw is None:
                    self._buzon_sucio = time.time() + 10
        if not raw:
            return raw
        if not self._velas_buenas(aid, tam, raw, hasta):
            return None
        return raw

    def _velas_buenas(self, aid, tam, raw, hasta):
        """Revisión de seguridad: las velas tienen que ser de ESTE par. Se comparan con las que ya llegaron antes
        (las mismas horas deben tener el mismo cierre) y se descartan saltos imposibles dentro del bloque."""
        try:
            cierres = [float(v["close"]) for v in raw]
            if not cierres or min(cierres) <= 0:
                return False
            orden = sorted(cierres)
            med = orden[len(orden) // 2]
            if any(abs(c / med - 1) > 0.25 for c in cierres):        # dos activos distintos en un mismo bloque
                return False
            memo = self._memo_velas.setdefault((int(aid), int(tam)), {})
            iguales = distintas = 0
            for v in raw[:-1]:                                      # la última puede estar formándose
                previo = memo.get(int(v["from"]))
                if previo is not None:
                    if abs(float(v["close"]) / previo - 1) < 1e-4:
                        iguales += 1
                    else:
                        distintas += 1
            if distintas >= 2 and distintas > iguales:              # las mismas horas con otros precios: es otro par
                return False
            if not iguales and memo:                                # sin horas en común: si son horas cercanas,
                t_ult = int(raw[-1]["from"])                         # el precio debe estar cerca
                cerca = min(memo, key=lambda t: abs(t - t_ult))
                if abs(cerca - t_ult) <= 3 * 3600 and abs(cierres[-1] / memo[cerca] - 1) > 0.25:
                    return False
            for v in raw[:-1]:
                memo[int(v["from"])] = float(v["close"])
            if len(memo) > 3000:
                for t in sorted(memo)[:len(memo) - 2500]:
                    memo.pop(t, None)
            return True
        except Exception:
            return True

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise OrdenSinConfirmar("IQ Option no confirmó la orden (revisa la plataforma)", tipo="binaria", req=req,
                                    aid=aid, dir=direccion, monto=self.a_local(monto), expira=int(expira))
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def rescatar_orden(self, e, hasta):
        """La orden no se confirmó a tiempo: se sigue esperando la confirmación (llega tarde con mala conexión)
        y, cuando ya venció, se busca en el historial de IQ Option. Devuelve el número de la orden o None."""
        d = getattr(e, "datos", {}) or {}
        inner = self.inner
        ult_hist = 0
        while time.time() < hasta:
            try:
                if d.get("tipo") == "digital":
                    r = inner.digital_option_placed_id.get(d.get("req"))
                    if isinstance(r, int):
                        self.digitales.add(int(r))
                        return int(r)
                else:
                    r = inner.buy_multi_option.get(d.get("req")) or {}
                    if r.get("id"):
                        return int(r["id"])
                    if (self.conectado and d.get("expira") and self.ahora() > d["expira"] + 2
                            and time.time() - ult_hist > 4):
                        ult_hist = time.time()
                        oid = self._buscar_en_historial(d)
                        if oid:
                            return oid
            except Exception:
                pass
            time.sleep(0.3)
        return None

    def _buscar_en_historial(self, d):
        """Busca en el historial una orden con el mismo par, dirección, monto y vencimiento."""
        h = self._historial()
        def valor(op, *claves):
            for k in claves:
                if op.get(k) is not None:
                    return op.get(k)
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            try:
                act = valor(op, "active_id", "act", "active")
                if act is not None and str(act) != str(d.get("aid")):
                    continue
                dr = str(valor(op, "dir", "direction") or "").lower()
                if dr and dr != str(d.get("dir")).lower():
                    continue
                exp = valor(op, "expired", "exp", "expiration", "expiration_time")
                if exp is not None and abs(float(exp) - float(d.get("expira") or 0)) > 2:
                    continue
                amt = valor(op, "amount", "sum")
                if amt is not None and abs(float(amt) - float(d.get("monto") or 0)) > 0.02:
                    continue
                if act is None and exp is None:
                    continue                            # sin datos para asegurar que es la misma orden
                ids = op.get("id") or []
                ide = ids[0] if isinstance(ids, list) and ids else ids
                if ide:
                    return int(ide)
            except Exception:
                continue
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 3, 4, 5)             # minutos: una sola temporalidad, de M1 a M5
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 4: 7, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
PREPARAR_A_LA_VEZ = 3                          # pares que se leen a la vez antes del cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)




# =====================================================================
#  ESTRATEGIA (3.0): una sola, la que elige el cliente
#    Bollinger: precio fuera de la banda -> entra a que regrese (arriba PUT, abajo CALL)
#    RSI: cruza hacia arriba el nivel alto -> CALL; hacia abajo el bajo -> PUT (o al revés si es "invertida")
# =====================================================================
def mercado_de(par, inst=None):
    """'otc' (precio generado por el bróker) o 'real' (mercado real)."""
    return "otc" if "OTC" in str(par).upper() else "real"


HISTORIA_VELAS = 300            # velas cerradas que se guardan por par y temporalidad (para las bandas / el RSI)


def _rsi_serie(cierres, periodo):
    """RSI de Wilder: lista de valores (uno por cierre desde 'periodo')."""
    if len(cierres) <= periodo:
        return []
    g = p = 0.0
    for i in range(1, periodo + 1):
        d = cierres[i] - cierres[i - 1]
        g += max(d, 0.0); p += max(-d, 0.0)
    g /= periodo; p /= periodo
    out = [100.0 if p == 0 else 100 - 100 / (1 + g / p)]
    for i in range(periodo + 1, len(cierres)):
        d = cierres[i] - cierres[i - 1]
        g = (g * (periodo - 1) + max(d, 0.0)) / periodo
        p = (p * (periodo - 1) + max(-d, 0.0)) / periodo
        out.append(100.0 if p == 0 else 100 - 100 / (1 + g / p))
    return out


def bandas(cierres, per, k):
    """(arriba, media, abajo) de Bollinger con los últimos 'per' cierres, o None."""
    if len(cierres) < per:
        return None
    w = cierres[-per:]
    m = sum(w) / per
    s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
    return (m + k * s, m, m - k * s) if s > 0 else None


BBRSI_PRESETS = {           # "BB + RSI" (autor): la mejor combinación medida en el historial de Exnova para cada temporalidad
    1: (20, 2.0, 14, 75, 25),  # (periodo Bollinger, desviaciones, periodo RSI, nivel alto, nivel bajo) · M1: ~4 veces más señales, mismo acierto
    2: (20, 2.0, 7, 80, 20),
    3: (20, 2.0, 14, 75, 25),
    4: (20, 2.5, 14, 75, 25),
    5: (20, 2.5, 7, 80, 20),
}


def bbrsi_preset(cfg):
    try:
        tf = int((cfg.get("temporalidades") or [2])[0])
    except (TypeError, ValueError):
        tf = 2
    return tf, BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])


RACHA_N, RACHA_MIN = 20, 10   # acierto "a la primera" de cada par: sus últimas 20 señales de BB + RSI (mínimo 10 para contar)


def resultados_bbrsi(velas, tf, desde_t=0):
    """Señales de Bollinger + RSI en velas ya cerradas (posteriores a 'desde_t') y si ganaron a la primera
    (la vela siguiente cerró a favor): {t: True/False}. Los empates no cuentan."""
    per, k, rp, alto, bajo = BBRSI_PRESETS.get(tf, BBRSI_PRESETS[2])
    c = [float(v["c"]) for v in velas]
    serie = _rsi_serie(c, rp)                       # serie[0] corresponde a c[rp]
    out = {}
    for i in range(max(per - 1, rp), len(c) - 1):
        t = velas[i]["t"]
        if t <= desde_t or velas[i + 1]["t"] - t != tf * 60:
            continue
        w = c[i - per + 1:i + 1]
        m = sum(w) / per
        s = (sum((x - m) ** 2 for x in w) / per) ** 0.5
        r = serie[i - rp]
        d = -1 if (c[i] > m + k * s and r > alto) else (1 if (c[i] < m - k * s and r < bajo) else 0)
        mov = c[i + 1] - c[i]
        if d and mov:
            out[t] = (mov > 0) == (d > 0)
    return out


# señal "clara": mercado lateral (ADX < 20) y par con 60 % o más a la primera. En cada cierre se prefiere una clara;
# si no hay, la del par con mejor acierto (sin esperar). Solo M2 a M4 (en M5 no mejoró en el historial).
CLARA_ADX, CLARA_ACIERTO, CLARA_TFS = 20.0, 0.60, (2, 3, 4)


def niveles_de(dias, horas, ahora):
    """Niveles donde el precio suele rebotar: pivô y Fibonacci (38,2/50/61,8 %) del día anterior, y soportes/
    resistencias de H1 tocados al menos 2 veces en las últimas 48 h. 'dias' y 'horas': velas D1 y H1 del bróker."""
    out = []
    hoy = int(ahora // 86400) * 86400
    prev = next((d for d in dias or [] if int(d["from"]) == hoy - 86400), None)
    if prev:
        ph, pl, pc = float(prev["max"]), float(prev["min"]), float(prev["close"])
        p = (ph + pl + pc) / 3
        out += [p, 2 * p - pl, 2 * p - ph, p + (ph - pl), p - (ph - pl)]
        out += [pl + (ph - pl) * x for x in (0.382, 0.5, 0.618)]
    hs = [h for h in horas or [] if int(h["from"]) + 3600 <= ahora]
    if len(hs) >= 10:
        rangos = sorted(float(h["max"]) - float(h["min"]) for h in hs)
        tol = 0.15 * rangos[len(rangos) // 2]
        sw = []
        for i in range(2, len(hs) - 2):
            if int(hs[i + 2]["from"]) + 3600 <= ahora - 48 * 3600:
                continue
            ven = hs[i - 2:i + 3]
            if float(hs[i]["max"]) >= max(float(v["max"]) for v in ven):
                sw.append(float(hs[i]["max"]))
            if float(hs[i]["min"]) <= min(float(v["min"]) for v in ven):
                sw.append(float(hs[i]["min"]))
        out += [x for x in sw if sum(1 for y in sw if abs(y - x) <= tol) >= 2]
    return out


def rechaza_nivel(vela, d, niveles):
    """¿La vela de la señal tocó un nivel y cerró devolviéndose, a favor de la dirección? (PUT: tocó desde abajo
    y cerró debajo; CALL: tocó desde arriba y cerró encima)."""
    o, c, h, l = float(vela["o"]), float(vela["c"]), float(vela["h"]), float(vela["l"])
    for x in niveles:
        if d == "put" and h >= x > c and o < x:
            return True
        if d == "call" and l <= x < c and o > x:
            return True
    return False


def adx_ultimo(velas, n=14):
    """ADX de Wilder (fuerza de la tendencia, 0-100) en la última vela, o None si faltan velas."""
    v = velas[-(n * 6):]
    if len(v) < 2 * n + 2:
        return None
    tr, pdm, mdm = [], [], []
    for a, b in zip(v, v[1:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0)
        mdm.append(dn if dn > up and dn > 0 else 0.0)
        tr.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    atr, sp, sm = sum(tr[:n]) / n, sum(pdm[:n]) / n, sum(mdm[:n]) / n
    dxs = []
    for i in range(n, len(tr)):
        atr = (atr * (n - 1) + tr[i]) / n
        sp = (sp * (n - 1) + pdm[i]) / n
        sm = (sm * (n - 1) + mdm[i]) / n
        if atr <= 0:
            continue
        pdi, mdi = 100 * sp / atr, 100 * sm / atr
        dxs.append(100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi > 0 else 0.0)
    if len(dxs) < n:
        return None
    adx = sum(dxs[:n]) / n
    for x in dxs[n:]:
        adx = (adx * (n - 1) + x) / n
    return adx


def senal(cierres, cfg, estiro=None):
    """(dirección o None, texto). 'cierres' termina con el precio de la vela de señal.
    estiro: solo Bollinger "al estirarse" (% del ancho de las bandas que el precio debe pasar la banda)."""
    if cfg.get("estrategia") == "bbrsi":          # entra solo si coinciden: fuera de la banda y RSI en su extremo
        _tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
        b = bandas(cierres, per, k)
        serie = _rsi_serie(cierres[-(rp * 12 + 2):], rp)
        if not b or not serie:
            return None, ""
        c, r = cierres[-1], serie[-1]
        if c > b[0] and r > alto:
            return "put", f"sobre la banda y RSI {r:.0f}"
        if c < b[2] and r < bajo:
            return "call", f"bajo la banda y RSI {r:.0f}"
        return None, ""
    if cfg.get("estrategia") == "rsi":
        per = max(2, int(cfg.get("rsi_periodo") or 2))
        serie = _rsi_serie(cierres[-(per * 12 + 2):], per)
        if len(serie) < 2:
            return None, ""
        antes, ahora = serie[-2], serie[-1]
        alto, bajo = float(cfg.get("rsi_alto", 60)), float(cfg.get("rsi_bajo", 40))
        d, txt = None, ""
        if antes < alto <= ahora:
            d, txt = "call", f"RSI cruzó hacia arriba {alto:g}"
        elif antes > bajo >= ahora:
            d, txt = "put", f"RSI cruzó hacia abajo {bajo:g}"
        if d and cfg.get("rsi_direccion") == "invertida":
            d = "call" if d == "put" else "put"
            txt += " (invertida)"
        return d, txt
    per = max(2, int(cfg.get("bb_periodo") or 20))
    k = float(cfg.get("bb_desv") or 2)
    b = bandas(cierres, per, k)
    if not b:
        return None, ""
    arriba, _m, abajo = b
    extra = 0.0 if estiro is None else (arriba - abajo) * float(estiro) / 100.0
    c = cierres[-1]
    if c > arriba + extra:
        return "put", (f"estirado {100 * (c - arriba) / (arriba - abajo):.0f}% sobre la banda de arriba"
                       if estiro is not None else "sobre la banda de arriba")
    if c < abajo - extra:
        return "call", (f"estirado {100 * (abajo - c) / (arriba - abajo):.0f}% bajo la banda de abajo"
                        if estiro is not None else "bajo la banda de abajo")
    return None, ""


def ia_minimo(cfg):
    """Modo "señal más segura": el mínimo de acierto que eligió el autor (55 a 70 %), como fracción."""
    try:
        return max(55, min(70, int(cfg.get("ia_prob_min") or IA_PROB_SEGURA * 100))) / 100.0
    except Exception:
        return IA_PROB_SEGURA


def ia_probabilidad(ev, pago):
    """La IA estima cuánto gana por dólar (gana 'pago' o pierde 1): de ahí sale la probabilidad de acertar."""
    p = float(pago or 0.85)
    return max(0.0, min(1.0, (float(ev) + 1.0) / (p + 1.0)))


def nombre_estrategia(cfg, autor=False):
    if cfg.get("estrategia") == "bbrsi":
        tf, (per, k, rp, alto, bajo) = bbrsi_preset(cfg)
        return f"BB + RSI (M{tf}: BB {per},{k:g} · RSI {rp} {alto}/{bajo})"
    if cfg.get("estrategia") == "ia":
        if autor and cfg.get("ia_modo") == "segura":
            return f"IA (señal más segura {ia_minimo(cfg) * 100:.0f}%)"
        return "IA (aprende sola)"
    if cfg.get("estrategia") == "rsi":
        inv = " invertida" if cfg.get("rsi_direccion") == "invertida" else ""
        return f"RSI {int(cfg.get('rsi_periodo') or 2)} ({cfg.get('rsi_alto', 60):g}/{cfg.get('rsi_bajo', 40):g}){inv}"
    t = f" al estirarse {float(cfg.get('estiro', 20)):g}%" if cfg.get("entrada") == "estirado" else ""
    return f"Bollinger {int(cfg.get('bb_periodo') or 20)},{float(cfg.get('bb_desv') or 2):g}{t}"


# =====================================================================
#  IA DEL AUTOR (3.0): aprendizaje por refuerzo EN LÍNEA, en código propio (sin librerías: PC y celular).
#  En binarias cada decisión dura una vela: al cerrar se sabe cuánto habría pagado CALL y cuánto PUT,
#  así que aprende de TODOS los pares en cada cierre, opere o no (premio = pago del par, castigo = −1).
#  Red pequeña: ~34 datos de entrada -> 16 neuronas -> 2 salidas (lo que espera ganar con CALL y con PUT).
#  Empieza en MODO SOMBRA (decide sin operar) y solo opera cuando su acierto real pasa del 55 % en 300 señales.
#  Solo la ven y la usan las cuentas del autor.
# =====================================================================
IA_ARCHIVO = "ia_refuerzo.json"
IA_SENALES_MIN = 300              # señales en sombra antes de poder operar (máximo una por minuto)
IA_SENALES_VENTANA = 1000         # se mide con las últimas 1.000 señales
IA_HORAS_MIN = 2.0                # y repartidas en al menos 2 horas
IA_EQUILIBRIO = 1 / 1.85          # acierto que no pierde ni gana con pago de 85 % (≈ 54 %)
IA_Z = 1.645                      # 95 % de seguridad (una cola)
IA_ACIERTO_APAGAR = 0.53          # si opera y baja de esto en las últimas 300, vuelve a modo sombra


def ia_limite_inferior(g, n, z=IA_Z):
    """Límite inferior de Wilson: el acierto mínimo que se puede asegurar con 95 % de confianza."""
    if n <= 0:
        return 0.0
    p = g / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - r) / d


def ia_acierto_necesario(n):
    """Con n señales, qué acierto hace falta para estar sobre el equilibrio con 95 % de seguridad."""
    n = max(int(n), IA_SENALES_MIN)
    for k in range(int(n * IA_EQUILIBRIO), n + 1):
        if ia_limite_inferior(k, n) >= IA_EQUILIBRIO:
            return k / n
    return 1.0
IA_PROB_SEGURA = 0.58             # modo "señal más segura" del autor: mínimo por defecto (él lo ajusta de 55 % a 70 %)
IA_PROB_CLIENTES = 0.60           # clientes con IA: siempre la señal más segura, con 60 % o más (fijo)
IA_UMBRAL = 0.04                  # entra solo si espera ganar más de 4 centavos por dólar
IA_VERSION = 2                    # 2 = IA autónoma: solo velas crudas y contexto (sin indicadores ni estrategias)
IA_OCULTAS = 24
IA_VELAS_VE = 20                  # velas que ve completas (cuerpo y mechas)
IA_ENTRADAS = IA_VELAS_VE * 3 + 19
# Lo aprendido en el PC del autor viaja con cada actualización (lo escribe PUBLICAR_ACTUALIZACION en la línea de abajo).
# Al abrir, el equipo del autor toma esta IA si es más nueva que la suya. (Para los clientes la IA está apagada.)
IA_BASE = {'iqoption': {'v': 2, 'w1': [[-0.061093, -0.015378, -0.011424, -0.030877, 0.01997, -0.030459, 0.041794, -0.001444, -0.027145, -0.027493, 0.053543, -0.007486, 0.03467, -0.063819, 0.053124, 0.054862, 0.155334, -0.012804, -0.021767, -0.000328, -0.082197, -0.058959, 0.040182, 0.013185, -0.09158, -0.004403, -0.111074, 0.098593, -0.103397, 0.028681, 0.038275, -0.011753, 0.046347, 0.044823, 0.036255, 0.037089, 0.03133, -0.005816, -0.005545, -0.021683, -0.077173, 0.051284, 0.016035, 0.180917, 0.032109, -0.045047, -0.086956, 0.066596, 0.015225, -0.057762, 0.025627, 0.01471, 0.073259, 0.004764, -0.152807, 0.12992, -0.17538, -0.005201, -0.063577, 0.037677, 0.102215, -0.100442, -0.082283, 0.219901, 0.046438, 0.026984, 0.026881, -0.01028, -0.023266, -0.015648, -0.011561, -0.008155, 0.029251, 0.110955, 0.052006, -0.059108, 0.045475, -0.036343, 0.001432], [0.006703, 0.03354, -0.0452, -0.002676, -0.007915, -0.093636, -0.017099, -0.03737, 0.078063, 0.012016, -0.03712, 0.036761, -0.010909, 0.057821, 0.014608, -0.026837, 0.077396, -0.008404, -0.011724, 0.07134, -0.033404, 0.039233, -0.092464, 0.026223, 0.050547, 0.005988, -0.040886, -0.125105, -0.052413, -0.080516, 0.05135, 0.061003, 0.009915, 0.0715, 0.092886, 0.059271, 0.0068, 0.034428, 0.10083, 0.027539, 0.104134, -0.066113, 0.035712, 0.042968, -0.14706, -0.066735, -0.027786, -0.038483, -0.075225, 0.052091, -0.057058, -0.132642, -0.066417, 0.099015, -0.110033, -0.124874, -0.015639, -0.127692, -0.054297, -0.07663, 0.14659, 0.024471, -0.134203, 0.057899, 0.056558, -0.034479, 0.002289, 0.001898, 0.009546, 0.005331, -0.013054, 0.069076, -0.017691, -0.107312, 0.099235, 0.004444, -0.070845, -0.067838, -0.079375], [-0.020419, 0.029212, 0.115184, 0.069325, 0.025881, 0.004375, 0.009368, -0.087225, 0.008493, 0.000601, 0.063808, 0.0342, 0.042224, 0.01345, -0.02758, 0.077261, 0.010422, 0.119508, -0.020978, -0.003189, -0.078459, 0.058033, -0.143765, 0.001715, 0.127693, 0.129033, 0.05393, -0.013028, 0.10374, -0.101917, 0.006914, -0.145234, 0.027903, -0.009542, -0.04082, -0.044237, 0.101386, 0.071231, 0.030414, -0.058126, 0.104705, -0.125876, -0.163969, 0.072616, -0.046657, -0.011825, 0.024984, 0.006968, -0.058321, 0.036326, -0.022235, -0.15291, -0.069359, 0.140116, -0.06045, 0.020101, 0.034766, -0.016092, -0.154658, -0.068526, 0.105907, -0.136224, -0.035321, 0.143267, 0.066605, 0.016255, 0.032458, -0.015757, -0.013109, -0.052977, 0.053272, 0.028827, -0.038096, 0.097573, -0.050447, 0.068397, -0.073192, -0.045447, 0.000766], [0.008845, 0.065321, -0.015166, 0.007892, 0.00515, -0.007239, -0.048492, -0.096947, -0.004383, 0.009041, 0.115679, 0.058468, 0.02815, -0.098455, 0.032739, 0.034319, -0.050298, -0.008008, 0.027194, -0.124254, -0.006563, -0.165566, -0.008743, 0.032097, -0.023313, 0.042452, 0.015886, 0.05812, -0.07985, -0.114122, 0.042429, 0.029822, 0.030722, 0.109898, -0.077228, -0.039984, 0.09468, 0.076584, -0.007392, 0.028778, -0.002711, 0.022625, -0.040198, 0.103288, -0.07042, 0.017125, -0.029494, 0.055265, 0.01369, -0.022322, 0.049891, -0.092619, 0.13411, 0.116739, -0.131287, 0.003039, 0.00764, -0.034955, -0.251635, 0.242501, 0.152619, -0.083443, -0.13087, 0.070736, 0.008142, 0.008769, 0.007089, 0.009558, -0.040564, -0.015489, 0.070798, 0.096151, -0.10909, 0.11023, 0.028285, -0.104057, -0.058403, -0.030452, -0.009648], [-0.037045, -0.075351, -0.027688, 0.017549, -0.046922, 0.029135, -0.017455, 0.146536, -0.157305, -0.051766, -0.035489, 0.018012, -0.004551, 0.036204, -0.044498, -0.108677, 0.023091, 0.037051, -0.05008, 0.000122, -0.019471, -0.017476, 0.140245, 0.034021, -0.045145, 0.164166, -0.005154, 0.020029, -0.129446, 0.005772, 0.028155, -0.062335, -0.056815, -0.054247, -0.091932, 0.08444, 0.005161, 0.081258, -0.163522, 0.051792, -0.120765, 0.019716, -0.083727, 0.01934, -0.042807, 0.003657, -0.026659, -0.061244, 0.018575, 0.013185, -0.070358, -0.062211, 0.023412, -0.021044, -0.071056, -0.014066, 0.025132, -0.005111, -0.091426, 0.03485, 0.056674, -0.091381, 0.090008, -0.068518, 0.030053, -0.042198, -0.000855, 0.020599, 0.020432, -0.021355, -0.030782, 0.094289, -0.001605, 0.001504, -0.00022, 0.126313, 0.013423, 0.01135, -0.044884], [0.085199, 0.073574, 0.15728, -0.004408, -0.066905, 0.103633, -0.014819, -0.053651, 0.019007, -0.021054, 0.050342, 0.120565, -0.00676, -0.023422, 0.124988, 0.004143, 0.0437, 0.076348, 0.077925, -0.015956, 0.125966, -0.018603, 0.01095, -0.147266, 0.051946, 0.01759, 0.023841, -0.011738, 0.046513, -0.020359, 0.043015, 0.1292, -0.052847, 0.008862, -0.089425, -0.021131, -0.037363, -0.067499, -0.046432, 0.078118, -0.016953, -0.008621, 0.089878, -0.089214, 0.053591, -0.054322, 0.019857, -0.082401, -0.058895, 0.002946, 0.024347, 0.027486, 0.146086, -0.115435, 0.026129, -0.077429, 0.099178, 0.016588, 0.031277, -0.205726, -0.114578, -0.033316, -0.070446, -0.006362, 0.033599, -0.000943, 0.016702, -0.017169, 0.001096, -0.020769, -0.053398, 0.018824, -0.04201, -0.088901, 0.045652, 0.011187, 0.013481, 0.000142, 0.084169], [-0.023017, -0.223765, 0.070736, 0.05244, -0.023357, 0.065055, -0.010328, 0.094668, -0.066926, 0.07935, 0.017397, 0.083676, -0.031734, 0.014018, -0.026763, -0.018238, -0.009785, -0.087461, 0.058538, 0.138666, 0.010739, -0.089345, 0.011245, 0.096495, -0.016952, 0.092068, -0.021, -0.008506, 0.11032, 0.032073, 0.041965, -0.09177, -0.066788, 0.002379, 0.051275, -0.080764, 0.086106, -0.005589, 0.023829, -0.103641, -0.07942, 0.020019, -0.141668, 0.049076, -0.094716, 0.070503, -0.038085, 0.084955, 0.026207, -0.058166, -0.005787, -0.127343, -0.032968, 0.06105, -0.222256, 0.110194, -0.135475, -0.062401, 0.026073, 0.014896, 0.364709, -0.203632, 0.05, 0.050709, -0.025162, 0.051541, -0.040428, -0.00142, -0.033816, 0.003322, 0.015738, 0.020829, -0.147951, 0.076558, -0.09995, 0.052364, 0.008973, 0.001078, 0.135386], [0.032466, 0.049396, -0.118228, -0.058505, 0.051781, -0.008838, -0.050418, 0.040061, -0.002497, 0.02217, -0.130381, 0.030865, 0.071557, -0.053807, 0.096016, -0.018249, 0.016891, -0.020601, -0.031213, -0.035902, 0.046018, -0.127922, 0.02318, -0.079946, 0.053313, 0.031806, -0.062579, -0.071233, -0.0172, 0.019817, 0.088921, 0.193614, 0.053307, -0.113797, -0.069014, -0.131974, -0.007516, -0.00126, 0.0294, 0.099638, 0.113476, -0.063756, 0.044997, -0.034085, -0.048419, -0.039656, 0.066983, -0.110285, -0.132162, -0.003935, 0.038203, 0.073457, 0.20108, 0.033842, -0.026351, -0.181539, 0.072387, 0.046476, -0.035068, 0.024065, -0.230827, 0.146281, -0.007948, -0.018735, 0.017255, -0.004262, 0.015843, 0.03512, -0.005365, 0.005091, -0.009403, 0.045352, -0.055953, 0.105237, -0.134615, -0.022302, -0.088936, -0.002807, -0.046633], [0.011607, -0.112377, -0.026424, -0.100939, 0.011437, 0.015677, -0.042207, -0.061475, -0.162696, -0.103174, 0.084073, -0.015375, 0.093315, 0.054728, -0.053411, -0.067815, 0.0325, 0.033037, 0.02207, -0.044658, -0.022199, 0.038743, 0.052577, -0.024822, -0.021568, -0.057721, -0.090773, 0.108784, -0.006323, 0.102942, 0.009096, 0.038475, 0.123413, -0.043348, 0.003639, -0.0476, -0.042137, -0.101138, -0.023621, -0.097857, 0.017923, -0.128365, -0.12733, 0.089598, 0.039857, -0.086224, 0.021279, -0.087298, 0.006353, -0.079613, 0.156617, 0.070102, 0.13067, -0.011011, -0.038625, -0.002157, 0.073481, 0.093081, 0.022324, -0.139068, -0.144205, 0.023934, 0.077561, -0.07234, 0.022693, 0.030432, -0.02394, -0.039506, -0.006082, -0.041835, 0.003143, 0.087981, 0.009663, 0.053808, 0.024538, -0.054225, 0.079061, 0.038992, 0.060801], [0.060306, 0.1075, -0.143019, -0.076536, 0.098303, -0.02373, 0.011781, 0.077629, 0.020668, -0.07671, 0.015806, 0.065899, 0.031743, 0.054731, 0.089683, 0.065509, -0.08875, -0.123007, -0.033475, 0.079582, 0.048729, 0.001236, 0.072493, -0.031178, -0.064886, -0.064773, 0.031754, 0.041801, -0.075464, 0.062894, 0.11829, 0.150467, -0.0108, -0.031745, -0.069049, -0.01475, -0.089715, 0.027689, -0.017016, 0.014997, 0.02781, 0.075178, 0.134494, 0.076157, 0.124059, -0.02905, -0.019301, 0.101606, -0.047167, -0.053733, -0.110065, -0.009896, 0.043789, -0.029609, -0.074662, 0.045676, -0.082508, -0.036978, -0.203554, 0.214541, -0.003911, 0.049861, -0.009936, 0.165192, -0.019145, 0.010693, 0.066171, -0.013051, -0.019121, 0.010981, -0.086722, -0.052134, -0.117044, 0.093711, 0.025467, 0.070907, -0.121922, -0.013938, -0.06027], [-0.062864, 0.055347, 0.002455, 0.008286, -0.0606, 0.039072, 0.011347, 0.003835, 0.005815, -0.068694, 0.062123, 0.01796, 0.022225, 0.019569, -0.02188, -0.07025, 0.074763, 0.047342, -0.031398, 0.034663, 0.045864, 0.017666, 0.067535, -0.012277, -0.081662, 0.14527, 0.018104, -0.009962, -0.024756, -0.082475, 0.065973, 0.023698, 0.051729, -0.016997, -0.011948, -0.004915, 0.019464, -0.147864, -0.066989, 0.010007, -0.107931, -0.040808, 0.00664, 0.052151, 0.060647, 0.024853, 0.034859, -0.033339, 0.034503, 0.049021, -0.152081, -0.087695, -0.062534, -0.010757, -0.173653, 0.06778, -0.083631, -0.154246, 0.042358, -0.043837, 0.313065, -0.11147, 0.040915, 0.16436, 0.038988, 0.025614, 0.028752, -0.013277, 0.039155, -0.029374, -0.037144, -0.016205, -0.024113, -0.028749, 0.061759, -0.016217, 0.062168, 0.019038, 0.111065], [-0.111732, 0.019491, -0.106897, 0.053289, 0.023543, -0.018286, 0.072315, 0.033075, 0.004276, -0.025545, -0.042001, -0.054426, 0.063541, -0.056838, -0.041276, -0.011965, -0.028082, 0.113726, -0.026886, -0.011783, -0.027292, -0.048389, 0.170867, -0.09453, -0.028379, 0.026236, 0.22165, 0.000513, 0.046413, -0.077619, 0.051821, -0.010794, 0.007168, 0.074531, 0.083975, 0.135455, 0.01868, -0.171378, -0.083078, 0.025556, -0.171486, 0.088879, 0.054489, 0.035831, 0.055199, 0.111935, -0.076051, 0.182267, 0.087183, 0.038881, -0.10752, -0.053308, -0.045556, 0.069833, -0.252211, 0.015678, -0.029088, -0.190798, -0.083493, 0.096469, 0.500428, -0.104377, -0.008942, 0.221716, 0.021909, -0.016356, -0.044281, 0.041599, 0.049929, -0.012962, 0.032297, -0.037595, -0.062751, 0.090957, -0.017686, 0.048593, 0.023606, -0.040641, 0.050647], [-0.046653, 0.090635, -0.054464, 0.030284, -0.048118, 0.022534, -0.046398, -0.013816, 0.146372, 0.064104, 0.006808, -0.100316, 0.018449, -0.09946, 0.066043, 0.039456, 0.046662, 0.065461, -0.018102, -0.004434, 0.108918, -0.0345, 0.057772, -0.055831, -0.162773, 0.020877, 0.170204, 0.045516, 0.105073, 0.140222, -0.071675, 0.04393, -0.041173, 0.108769, -0.024732, -0.107279, 0.103293, -0.103733, 0.024673, 0.041226, 0.019231, 0.00495, -0.035632, 0.029984, 0.113019, 0.072947, 0.0305, -0.048204, 0.112653, 0.015998, 0.051402, -0.03436, 0.031666, -0.188391, 0.116389, 0.082423, 0.028647, 0.074082, -0.123197, 0.112979, -0.263432, 0.036258, 0.040759, -0.027565, 0.064886, 0.0093, -0.069514, 0.041822, 0.044207, -0.013598, 0.039363, 0.055551, -0.19613, -0.080202, -0.03302, 0.04574, -0.072394, -0.05739, -0.009023], [0.057294, -0.058287, 0.013013, -0.129026, 0.099679, -0.037731, -0.011952, -0.070723, 0.041987, 0.028517, -0.056269, -0.038545, -0.028063, 0.04872, -0.101402, -0.015753, -0.035278, -0.030083, 0.056131, 0.053066, -0.044917, -0.003407, 0.010196, 0.004257, 0.002473, -0.037626, 0.06397, -0.032813, 0.054552, 0.037447, -0.003148, 0.045032, -0.034551, -0.020328, 0.071436, 0.016495, -0.041392, -0.111657, 0.03396, 0.013576, 0.113424, -0.038308, 0.057855, 0.107375, 0.123903, -0.033914, 0.093651, -0.024228, 0.008436, -0.087703, -0.06887, 0.015605, 0.053278, -0.008852, -0.019673, -0.087081, 0.077203, 0.002738, 0.096455, -0.14366, -0.023543, 0.115804, 0.040098, -0.154343, 0.023803, 0.015531, -0.048859, -0.041525, 0.033608, -0.013166, -0.044839, -0.038071, 0.003111, 0.032763, 0.046284, 0.1009, 0.107775, 0.03501, -0.003941], [0.024532, 0.01781, 0.00444, -0.005805, -0.047147, -0.001471, -0.00456, -0.011864, 0.016491, 0.058728, -0.128956, -0.051998, -0.01949, 0.000857, 0.086137, 0.013849, -0.037747, -0.09975, -0.02385, 0.0332, 0.031838, -0.118037, 0.025567, 0.067672, -0.015647, 0.027421, 0.003459, 0.04438, -0.005439, 0.034265, -0.079719, -0.086703, -0.078685, -0.008826, 0.147115, 0.042924, -0.083351, -0.092467, -0.010074, -0.041684, 0.041057, -0.106505, 0.037328, -0.053683, 0.021861, -0.091157, -0.021317, -0.055469, -0.062073, -0.090764, 0.190055, 0.045956, 0.03761, -0.064423, -0.052051, -0.04243, 0.005967, 0.03738, 0.191613, -0.157557, 0.08656, 0.11314, -0.037731, -0.055431, -0.053714, -0.026395, -0.030791, 0.036951, -0.023045, 0.045511, -0.013063, -0.034645, 0.045595, 0.092435, -0.063165, -0.112747, 0.033805, 0.03828, -0.08552], [0.016212, -0.038591, 0.03063, -0.031518, -0.090005, -0.009881, 0.007818, -0.11679, 0.024091, -0.060953, 0.077107, -0.04069, 0.051066, 0.005081, -0.08, -0.009869, -0.022219, 0.051364, 0.053789, 0.00115, -0.001819, 0.076484, 0.086883, 0.016634, -0.123527, -0.01826, -0.042504, 0.11639, -0.129963, -0.090962, -0.038519, -0.039563, 0.031212, 0.008466, -0.12121, -0.035897, -0.103819, 0.024047, 0.087875, -0.026507, 0.000887, 0.016513, 0.002968, -0.065332, -0.035544, 0.081544, 0.110896, -0.0063, 0.045929, -0.086731, -0.015888, 0.11276, -0.023541, -0.024115, 0.036223, 0.010869, 0.08742, 0.029155, 0.12366, -0.105226, -0.08121, 0.218191, 0.066199, -0.270321, -0.154733, -0.017289, 0.002817, -0.054697, -0.040499, 0.020669, 0.012645, 0.014703, 0.135236, -0.087774, 0.10391, -0.065956, 0.11074, 0.100095, 0.055638], [0.095525, -0.002529, -0.027521, -0.062334, 0.091972, 0.098619, -0.030242, -0.245098, 0.048956, 0.090498, -0.102524, -0.009402, 0.049097, 0.061591, 0.014918, -0.077951, -0.015897, -0.004295, 0.052563, 0.01683, 0.032135, -0.028187, 0.009294, 0.058966, -0.06709, 0.017919, 0.051262, -0.04051, 0.060545, -0.064459, 0.081379, 0.104138, -0.123536, 0.083426, -0.052224, -0.050238, 0.011696, 0.014825, 0.151734, 0.056466, -0.015225, -0.010547, 0.008027, 0.096645, -0.127809, 0.047126, 0.003854, 0.056129, 0.057323, 0.112142, -0.155886, -0.053157, 0.081002, 0.143227, -0.052646, -0.033237, -0.013077, -0.072939, -0.15266, 0.07359, 0.050936, 0.032521, -0.048289, 0.014438, 0.027494, 0.018876, -0.037386, -0.0177, 0.029419, -0.001837, 0.015603, 0.077381, -0.173517, -0.015745, 0.046374, 0.034803, -0.091025, -0.020472, -0.0833], [-0.08818, 0.15406, 0.085189, -0.040014, -0.02059, -0.050878, -0.035133, 0.0403, 0.051612, -0.107723, -0.092457, 0.039602, -0.032545, -0.065994, 0.007953, -0.033604, 0.034424, -0.029681, -0.030177, -0.11102, 0.086563, 0.122881, 0.077326, -0.017689, -0.148097, -0.031288, 0.102042, -0.030923, -0.041777, -0.079345, -0.104731, -0.008943, 0.134267, -0.003915, -0.022648, -0.018604, -0.018594, 0.083933, 0.115369, -0.010346, 0.122849, -0.099534, -0.085688, -0.128199, -0.050532, 0.032059, 0.058842, -0.085848, 0.083244, -0.022585, 0.060089, -0.137528, -0.038537, -0.165993, -0.072195, -0.044295, 0.142685, -0.057961, -0.033515, -0.268375, -0.023281, 0.097905, -0.026608, -0.034029, 0.040287, -0.079089, -0.013074, 0.065347, 0.012307, 0.034852, 0.005874, 0.069761, -0.016413, -0.061658, 0.053294, -0.030815, 0.023951, -0.106513, 0.042386], [0.048836, 0.122605, 0.051988, -0.014174, 0.116798, -0.059303, -0.025842, -0.043857, 0.015402, 0.103803, 0.00417, -0.012011, -0.034162, -0.076769, 0.098619, 0.081211, 0.026871, -0.090362, -0.016563, 0.020345, -0.097673, -0.049736, -0.128175, -0.005044, 0.123049, -0.000961, 0.027435, -0.039906, 0.014959, 0.054256, 0.009107, -0.022628, -0.001194, -0.042102, 0.049231, -0.048507, 0.063977, 0.081672, 0.082617, -0.003904, 0.061916, -0.124035, 0.023985, -0.006967, 0.049824, -0.00255, 0.073461, -0.035362, -0.093053, -0.0498, 0.042683, 0.214921, 0.069179, -0.077583, 0.112807, -0.076092, 0.058022, 0.052624, 0.08415, -0.166523, -0.356259, 0.023226, -0.012347, -0.017695, -0.009104, -0.042935, 0.10759, -0.018187, -0.00496, 0.005748, -0.037726, -0.019503, 0.082843, 0.014079, 0.048117, 0.068741, 0.0093, -0.037614, -0.010647], [0.018834, -0.085237, -0.019394, -0.06356, -0.02105, 0.087943, 0.007889, -0.01885, 0.012873, -0.008988, -0.077364, -0.003457, 0.045702, -0.006837, 0.031663, 0.057744, 0.044046, -0.039566, -0.076811, 0.05273, 0.115077, -0.034085, 0.012477, -0.099864, 0.028328, 0.069706, 0.000425, 0.067104, 0.040179, 0.051639, -0.036703, -0.008289, 0.043475, -0.086581, -0.064905, 0.066401, -0.053598, -0.122205, -0.119061, 0.083076, 0.083311, -0.093813, 0.049977, -0.061813, 0.118353, -0.077228, -0.011519, -0.012625, 0.045362, -0.077584, 0.053815, 0.012331, 0.116587, -0.039554, -0.000505, 0.047605, 0.107038, 0.098232, 0.076236, -0.032802, -0.124824, 0.097796, 0.034387, -0.050877, 0.023831, 0.01262, -0.050027, 0.027456, -0.038406, 0.052944, 0.01173, -0.054989, 0.06883, 0.013974, -0.088407, -0.038863, -0.003781, -0.027763, -0.020377], [0.03818, -0.001998, -0.164816, 0.024332, -0.03439, 0.046446, 0.041652, -0.009022, 0.037047, 0.02221, 0.047623, -0.097342, -0.022126, 0.161726, 0.134019, -0.006178, -0.078987, -0.052392, 0.007523, -0.033259, -0.088052, 0.033608, -0.041243, 0.027729, 0.030873, 0.050281, -0.064433, -0.058621, -0.086354, -0.020806, 0.076122, -0.006429, 0.010557, 0.076524, 0.0206, 0.05043, 0.009038, -0.110873, 0.058405, -0.065142, -0.002503, 0.109114, 0.052024, 0.106794, 0.032629, 0.024241, -0.031344, 0.101723, 0.001213, 0.145818, -0.034335, -0.04076, -0.008443, 0.047102, -0.130702, 0.0717, -0.005188, -0.071061, 0.002371, 0.114435, 0.139244, -0.015549, -0.049444, 0.078779, -0.078052, 0.049251, 0.054971, -0.006021, -0.018548, 0.038502, -0.064926, -0.082114, -0.123559, -0.046716, -0.082702, 0.065583, -0.12013, 0.026394, 0.05153], [0.008426, -0.018947, -0.077354, 0.10996, 0.019371, -0.014101, 0.029118, 0.064715, 0.021345, 0.044845, -0.08438, -0.005037, -0.047323, 0.06024, -0.012799, -0.082223, -0.051616, 0.088061, 0.123511, -0.061588, 0.006045, 0.097055, 0.051472, -0.083233, -0.042729, 0.029403, 0.048867, 0.04015, 0.197063, 0.035487, 0.026865, 0.004547, -0.066889, -0.079911, -0.021256, 0.110014, -0.067856, -0.012329, -0.018715, 0.126449, -0.112804, -0.048405, 0.142474, 0.139427, 0.012655, 0.120156, -0.018841, -0.023001, -0.06101, -0.001721, 0.006257, 0.094084, 0.046243, -0.04842, 0.06426, -0.119866, 0.020332, -0.02778, 0.072492, 0.058483, 0.004216, 0.204714, 0.078584, -0.133867, 0.006651, -0.013953, -0.031195, 0.018087, -0.033489, 0.056007, -0.00733, -0.040215, -0.026967, 0.004378, -0.07367, -0.123625, 0.087668, 0.039325, 0.014688], [0.042855, -0.010765, 0.054831, -0.072171, 0.024257, 0.093695, 0.046879, 0.059449, -0.030349, -0.085106, -0.003145, 0.057515, 0.040557, -0.012645, -0.06982, 0.061343, -0.014477, 0.033416, 0.063081, -0.048009, -0.032591, 0.10716, -0.180296, 0.114491, 0.24379, -0.017861, 0.118001, 0.099558, -0.147564, -0.03066, 0.008236, -0.096436, 0.166546, -0.008453, -0.038545, -0.070081, -0.051694, 0.113795, 0.147084, 0.079783, 0.004802, -0.054824, -0.006094, -0.047897, -0.080238, -0.027427, -0.079297, -0.08284, 0.051088, 0.014233, 0.202196, 0.13003, 0.119482, 0.096726, -0.036496, -0.036647, 0.066059, 0.077543, 0.051362, -0.111225, -0.021983, -0.021248, 0.018284, -0.076625, -0.034963, -0.013514, 0.023172, -0.032223, -0.071247, 0.112214, -0.078738, -0.031056, 0.076166, -0.011871, -0.101685, 0.108556, -0.036756, 0.004684, 0.026442], [-0.049529, 0.081866, -0.005418, 0.095579, -0.114776, 0.052209, -0.007889, 0.054592, 0.05293, -0.02908, -0.004774, -0.029338, -0.044589, -0.053392, -0.066656, -0.064959, -0.020891, 0.038682, 0.060654, 0.005234, 0.104018, 0.13373, 0.068515, -0.033789, -0.062354, -0.097115, -0.03027, 0.025473, -0.1545, -0.025691, -0.030054, 0.1014, -0.035507, 0.098342, -0.045056, 0.003594, -0.011045, 0.070392, 0.048359, 0.024073, -0.138331, 0.071488, -0.000524, 0.119249, -0.196098, 0.043683, -0.011128, 0.045632, 0.148053, 0.073971, -0.011234, 0.018522, -0.087844, 0.093828, 0.042198, -0.01015, -0.003905, 0.006206, -0.040473, -0.065619, -0.132581, 0.063983, -0.034087, -0.181766, 0.002632, 0.016375, -0.003016, -0.009148, -0.013832, -0.005552, -0.11169, 0.120759, -0.15924, 0.049876, -0.030746, 0.053088, -0.040454, 0.104251, -0.072903]], 'w2': [[-0.050579, -0.01006, 0.003102, -0.014547, -0.033167, 0.034335, -0.042126, -0.023271, -0.053793, -0.010854, -0.046792, -0.015103, -0.002224, 0.028877, 0.026262, 0.024063, -0.019815, -0.044245, 0.037259, 0.003156, -0.002325, 0.004138, 0.018607, -0.016069, -0.045429], [0.049159, 0.012188, 0.000784, 0.003594, 0.054506, -0.030849, 0.042168, 0.021342, 0.04329, 0.012753, 0.03478, 0.021134, 0.010704, -0.018281, -0.026252, -0.006752, 0.017863, 0.029647, -0.033219, -0.008117, 0.000167, -0.017561, -0.013932, 0.016105, -0.117442]], 'hist_par': {'USDCHF-OTC': '11011111011000010011', 'SP500-OTC': '10100010000101101011', 'ONDOUSD-OTC': '11111000101110011100', 'EURGBP-OTC': '11001010111100001011', 'RENDERUSD-OTC': '01101010100110101100', 'SUIUSD-OTC': '00110010110101010111', 'HBARUSD-OTC': '01110111111001010000', 'RAYDIUMUSD-OTC': '01001011111100111001', 'GBPUSD-OTC': '10100100010101101001', 'PENGUUSD-OTC': '11111110000000101111', 'DYDXUSD-OTC': '00110111110100000111', 'EURUSD-OTC': '00011011011010101011', 'EURJPY-OTC': '01100100010100100010', 'FETUSD-OTC': '11011101000110101110', 'AMAZON-OTC': '10110010011011100011', 'Gold/BRL': '01111101101011001001', 'NZDCAD-OTC': '11111101101000001010', 'LINKUSD-OTC': '00110000011111101111', 'AUDJPY-OTC': '10111100000100101111', 'SANDUSD-OTC': '01001010011101010010', 'GBPCHF-OTC': '11000111000100101000', 'XNGUSD-OTC': '00100001101010000110', 'INJUSD-OTC': '00100000001100100001', 'NEARUSD-OTC': '10001100100001001100', 'FARTCOINUSD-OTC': '00000010000010111000', 'AUDCAD-OTC': '00101100100000101110', 'NZDUSD-OTC': '01101101100010111010', 'USOUSD-op': '11110010110011100111', 'DIA': '00000010000011001100', 'FR40-OTC': '10001110100101001100', 'EURCHF-OTC': '10010000111100100100', 'XAUUSD-OTC': '01101111101110111101', 'Crude Oil Brent/BRL': '11001101000011010000', 'IWM': '11001101001101010001', 'SQQQ': '11111111100011110001', 'XLK': '10111111111000110100', 'SMH': '00111001110111011001', 'EURTHB-op': '11111111111000101101', 'UKOUSD-OTC': '01110000111111101011', 'ATOMUSD-OTC': '11011100011001100010', 'MELANIAUSD-OTC': '11001000111010011101', 'JPM-OTC': '10111001011010110010', 'AIRLINES-OTC': '10110110010110010001', 'WIFUSD-OTC': '10001010111111011110', 'USDJPY-OTC': '00111011001011010010', 'IMXUSD-OTC': '01000111010000111010', 'FWONA-OTC': '01010001001111111100', 'DASHUSD-OTC': '10001111010110010100', 'GDX': '11010101110010110101', 'PEPEUSD-OTC': '01011000101100100100', 'SPY': '00100011010111111000', 'WLDUSD-OTC': '00111111011100001010', 'USDTHB-OTC': '11010000110001100100', 'JP225-OTC': '11000101010111100110', 'USNDAQ100:N': '01011101110110101110', 'USSPX500:N': '11010011000100111100', 'ARBUSD-OTC': '01000001010100001100', 'PENUSD-OTC': '10111110011101111111', 'AUS200-OTC': '10011101101010111000', 'GBPCAD-OTC': '00001011101101011010', 'EURTHB-OTC': '11100111011010110001', 'CHFNOK-OTC': '00010010011011111101', 'MCDON-OTC': '00101110001010010000', 'US30:N': '00011101110110010100', 'JPYTHB-OTC': '10001010110100111011', 'GRTUSD-OTC': '10000100001011011010', 'AUDCHF-OTC': '00010101110000111101', 'SOLUSD-OTC': '11101010010011011011', 'USOUSD-OTC': '11101001001000010010', 'COKE-OTC': '11100111000010000111', 'OpenAI-OTC': '01001100001010000001', 'SHIBUSD-OTC': '11101000000101001011', 'MAGNIFICENT7-OTC': '01001110000010011111', 'USNDAQ100-OTC': '00101000110010000110', 'USDDOP-OTC': '01111011100000100101', 'EURAUD-OTC': '10010001000000000011', 'JAPAN225:N': '10100010001101010100', 'GERMANY30:N': '01100011110011110001', 'FRANCE40:N': '00010101110101011001', 'XRPUSD-OTC': '11100010001010010010', 'JUPUSD-OTC': '00111010101000101111', 'GBPJPY-OTC': '01001110011000110110', 'USDSEK-OTC': '10111101000110111010', 'USDBRL-OTC': '11001001011010001110', 'APPLE-OTC': '01000100101000010110', 'US2000-OTC': '10101010100100010010', 'CADJPY-OTC': '11001011000110110010', 'EOSUSD-OTC': '10000010010111101000', 'AI Power & Datacenter': '11111000111101101010', 'FB-OTC': '00111111111111011111', 'US30-OTC': '11100001001011010101', 'Bitcoin/Gold-op': '00000111101101100110', 'US AI Semiconductors': '01011100010011011100', 'AUDNZD-OTC': '11100110111100011110', 'PLTR-OTC': '10000000101111001110', 'AUS200:N': '10111000011000001100', 'XAGUSD-OTC': '10100001011011011110', 'CADCHF-OTC': '10110011001010100010', 'USDCAD-OTC': '10001011100101110010', 'SNAP-OTC': '01011100100000001100', 'BTCUSD-OTC-op': '01001111010110110110', 'IOTAUSD-OTC': '10111110101101110111', 'MATICUSD-OTC': '01010100001001001010', 'USDPLN-OTC': '00011001100111100100', 'USDSGD-OTC': '01100000101111110010', 'CHFJPY-OTC': '11101001111101100010', 'NZDJPY-OTC': '11001100111100110001', 'USDZAR-OTC': '00110111100101000100', 'KLARNA-OTC': '01101010101110001110', 'HK33-OTC': '01001110010000000111', 'US2000:N': '11110010010000100001', 'HONGKONG33:N': '00010110000110101010', 'USDNOK-OTC': '11100110101001001111', 'Anthropic-OTC': '11111100111100000010', 'UK100-OTC': '11101000111111111011', 'USDCOP-OTC': '00010011100011100111', 'CASINOS-OTC': '01001001000110100101', 'EURCAD-OTC': '10011110110000011100', 'EU50-OTC': '10011111100001010010', 'SATSUSD-OTC': '11010000111001000011', 'URANIUM-OTC': '10100000110110011101', 'BONKUSD-OTC': '11111101001111010110', 'CANNABIS-OTC': '01001110011011111110', 'MSFT-OTC': '11111010100111011110', 'MORSTAN-OTC': '00011111000011010010', 'ETHUSD-OTC': '00011011110011000011', 'AUDUSD-OTC': '01000000100010011001', 'USDARS-OTC': '00101010101101011110', 'TRON-OTC': '10000010001000111101', 'GER30-OTC': '11111101000001010100', 'GBPNZD-OTC': '00011111011000011110', 'GOOGLE-OTC': '10100001110011100101', 'TIAUSD-OTC': '11101000110011001100', 'UK100:N': '10100010100000101110', 'Magnificent7-op': '11001100001100111001', 'GS-OTC': '01001111110111100100', 'GBPAUD-OTC': '10110000011100111101', 'TESLA-OTC': '01000001001100001010', 'LABUBUUSD-OTC': '11001101100010010110', 'USDTRY-OTC': '00100010100011000011', 'DOTUSD-OTC': '10110111000100101010', 'ALIBABA-OTC': '01011110000100111010', 'TRUMPUSD-OTC': '11110011001001001101', 'PYTHUSD-OTC': '10001000010011110001', 'EURNZD-OTC': '00111011001000011100', 'LTCUSD-OTC': '00101011000010010111', 'GER30/UK100-OTC': '00011000101010010110', 'COTTON-OTC': '01011001111010101111', 'US30/JP225-OTC': '10010011011001111000', 'EURJPY-op': '11101101101110100000', 'TESLA/FORD-OTC': '01111100111011010111', 'NVDA/AMD-OTC': '10000101011000111011', 'XAU/XAG-OTC': '01001100111111101110', 'GOOGLE/MSFT-OTC': '11000000100000100010', 'META/GOOGLE-OTC': '10110111100101101100', 'LUNA-OTC': '11111110100111110001', 'USDAED-OTC': '10011000100111001000', 'US100/JP225-OTC': '01100100000001111000', 'MSFT/AAPL-OTC': '10100110110100111011', 'AMZN/EBAY-OTC': '01111101110010100001', 'NVDA-OTC': '00101111110110011000', 'EURUSD-op': '10011000010000000111', 'EURGBP-op': '11010110010000100001', 'USDTHB-op': '10001111111000100111', 'USDMYR-OTC': '01010001111111010100', 'AMZN/ALIBABA-OTC': '01011110001101111001', 'USDVND-OTC': '10111011001011010110', 'COCOA-OTC': '00001110110010001111', 'USDBOB-OTC': '01001111001110100111', 'ICPUSD-OTC': '11110010010001110000', 'USDIDR-OTC': '11011010100100001010', 'XPDUSD-OTC': '10001010101000011000', 'USDHKD-OTC': '11101100001010110010', 'WDC-OTC': '00001011101101101011', 'COFFEE-OTC': '01001001101101001110', 'USDPHP-OTC': '11100111000111110000', 'USDJPY-op': '00011100110110101111', 'XPTUSD-OTC': '01001100110110010000', 'SUGAR-OTC': '10101011000100011001', 'GBPJPY-op': '10000000010101111110', 'USDNGN-OTC': '10011001111000111001', 'INTEL/IBM-OTC': '10100001000100000101', 'SEIUSD-OTC': '01101001010011110111', 'USDSAR-OTC': '11011010000001111010', 'RONINUSD-OTC': '00111011001000001110', 'HYPE-OTC': '00101111011000011010', 'NIKE-OTC': '00100010001100100111', 'MU-OTC': '01101010100101100000', 'GEV-OTC': '01110001101001111101', 'USDBDT-OTC': '11101110101101101110', 'NFLX/AMZN-OTC': '11000100011000111000', 'GBPUSD-op': '10000100011100001111', 'USDCLP-OTC': '00111010000110100101', 'XAUUSD-op': '01100001111110110101', 'SpaceX-OTC': '11100100000101100100', 'SpaceX-op': '10000111011011101111', 'ASMLa': '101100', 'NZDCAD-op': '00011', 'European AI': '011000', 'Luxury': '010011101', 'AUDCAD-op': '000010', 'AUDUSD-op': '011101101', 'GBPCAD-op': '0001101101111', 'BTCUSD-op': '01010001100', 'GBPAUD-op': '111110101010', 'AUDNZD-op': '0110', 'GBPNZD-op': '11101110011', 'AUDCHF-op': '0101110000010', 'AUDJPY-op': '11100', 'EURNZD-op': '111110000', 'TAOUSD-OTC': '001101', 'US500/JP225-OTC': '1111110001', 'NOKJPY-OTC': '110001', 'FLOKIUSD-OTC': '1011110000', 'BCHUSD-OTC': '101001', 'CITI-OTC': '0111110', 'AIG-OTC': '111010111', 'USDINR-OTC': '1001111', 'NZDCHF-OTC': '00101111', 'USDMXN-OTC': '0011111', 'INTEL-OTC': '0101011', 'MANAUSD-OTC': '11011011', 'BIDU-OTC': '0110111', 'ORDIUSD-OTC': '010'}, 'hist_ctx': {'otc20': '11100111011101011111101000011110010011111100011111', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '01001111000100001010100011100001000100100000101111', 'otc1': '11001110011011001101111111000101101111100101011111', 'otc2': '00101110110101000010001011011111110000011100100011', 'otc3': '10000000010111111100111100000101000001001110011110', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '10000110100111100110100000111000101011100001001010', 'otc13': '11100000111010110011100011101001111000010100000110', 'otc14': '10111110010001010011001010011110101101100101111100', 'otc15': '00001101110011111100001001111001111011001000011100', 'otc16': '11110010100110101000000000101001101001011011011111', 'otc18': '00100111011101010010001101111100010101000100000000', 'otc19': '10001001011011110000111100000100111100101110000110', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '00111101000101110100001010011000011010101001000101', 'real17': '01110001000100000000010000000010101101011111111111', 'real12': '01000100000110011001010001010110111110001010000110', 'real13': '11011110111101110111111110110010011101011100000000', 'real14': '11101100000110011111111011101111100101011110110111', 'real15': '00100001101001110000000110001011010111111111111111', 'real16': '10011001111101111111111111100100001010011111111100', 'real18': '01101001101011011001100100010100111111101111110111', 'real19': '00001111010010001000101001100000001000101001100010', 'real20': '11100011001110010000110111111111111000000010100001', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '00111100101110101101110000101100000110111100100100', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5851822, 'preentreno': True, 'sombra': '011110100000001001000101100011011011111001001010011000000001010010101000111011010100010001100101110111001111000000100101000001100101111101111101100101011111110011000011110111111110110101010100001000101110011001011101000011000000011011110101010101111111100001111100001011101100010110010001111111111101011100000110001010100001010001111110110000111100110111011100011011101000000001000111000001011101111010101000111001100001100101101000101001011011001000100010100111111101111011101011100100', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960, 1793413740, 1793413860, 1793413920, 1793413980, 1793414040, 1793414220, 1793413800, 1793414280, 1793414340, 1793414160, 1793414460, 1793414520, 1793414580, 1793414100, 1793414760, 1793414820, 1793414700, 1793414940, 1793414640, 1793415000, 1793414400, 1793415180, 1793415120, 1793415060, 1793415480, 1793415540, 1793415600, 1793415240, 1793449860, 1793449920, 1793449980, 1793450040, 1793450100, 1793450160, 1793450220, 1793450280, 1793450340, 1793450400, 1793450460, 1793459520, 1793459580, 1793459640, 1793459700, 1793459760, 1793459820, 1793459880, 1793459940, 1793460000, 1793460060, 1793460120, 1793460180, 1793460240, 1793460300, 1793460360, 1793460780, 1793460840, 1793460900, 1793460960, 1793461020, 1793461080, 1793461140, 1793461200, 1793461260, 1793461320, 1793461380, 1793461440, 1793461500, 1793461560, 1793461620, 1793461680, 1793461740, 1793461800, 1793560080, 1793560140, 1793560200, 1793560260, 1793560380, 1793560440, 1793560500, 1793560560, 1793560620, 1793560680, 1793560740, 1793560800, 1793560860, 1793560920, 1793560980, 1793561040, 1793561100, 1793561160, 1793561220, 1793561280, 1793561340, 1793561400, 1793562360, 1793562480, 1793562600, 1793562720, 1793562840, 1793562960, 1793563080, 1793563200, 1793563320, 1793563440, 1793563560, 1793563680, 1793563800, 1793563920, 1793625840, 1793626080, 1793626200, 1793626320, 1793626440, 1793626560, 1793626680, 1793626800, 1793626920, 1793627040, 1793627280, 1793627400, 1793627760, 1793627880, 1793628000, 1793628120, 1793629680, 1793629800, 1793629920, 1793630040, 1793630160, 1793630280, 1793630400, 1793630520, 1793630640, 1793630760, 1793630880, 1793631000, 1793631120, 1793631240, 1793631360, 1793638080, 1793638200, 1793638320, 1793638800, 1793638920, 1793639040, 1793639160, 1793639280, 1793639400, 1793639520, 1793639640, 1793639760, 1793639880, 1793640240, 1793640360, 1793640480, 1793640600, 1793640720, 1794164580, 1794164640, 1794164700, 1794164760, 1794164820, 1794164880, 1794164940, 1794165000, 1794165060, 1794165120, 1794165180, 1794165240, 1794165300, 1794165360, 1794165420, 1794165480, 1794165540, 1794165600, 1794165660, 1794165720, 1794165780, 1794165840, 1794165900, 1794165960, 1794166020, 1794166080, 1794166140], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1487, 'activa': False, 'ev_prom': -0.019088619287329533, 'ultima_senal': 1794166279.7921941, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1794233974}, 'exnova': {'v': 2, 'w1': [[0.007534, 0.013936, -0.008494, -0.043014, 0.008315, -0.027978, 0.031921, 0.018254, -0.048971, 0.120943, 0.071686, 0.011896, -0.031701, -0.05615, 0.060346, 0.019282, 0.146662, -0.005551, 0.038938, -0.0149, -0.058148, 0.04827, 0.052262, 0.019483, -0.148815, 0.012416, -0.117312, 0.083108, -0.105507, 0.04071, 0.011211, -0.008019, 0.04112, 0.021391, 0.030102, 0.039871, -0.015136, -0.0226, -0.008674, 0.023238, -0.060571, 0.020126, 0.000929, 0.140152, 0.073901, -0.061589, -0.085218, 0.102945, 0.006535, -0.037409, 0.003524, 0.058496, 0.033626, 0.025516, -0.099481, 0.140082, -0.144563, -0.015969, -0.041343, 0.033301, 0.13739, -0.104105, -0.140705, 0.201126, 0.052899, 0.035259, 0.047572, -0.008804, -0.009099, -0.012862, -0.038423, -0.00736, 0.057882, 0.110955, 0.050228, -0.04907, 0.069078, -0.02796, 0.016323], [0.036341, -0.005617, -0.041325, -0.010667, -0.031872, -0.056413, -0.074146, -0.025675, 0.094491, -0.066459, -0.063445, 0.098648, -0.033476, 0.083389, -0.01324, -0.012576, 0.052306, 0.019118, 0.035943, 0.072649, -0.103133, -0.033388, -0.076849, -0.011509, 0.073221, 0.026869, -0.032313, -0.036559, -0.05709, -0.064553, -0.044023, 0.085009, 0.018169, 0.063951, 0.135263, 0.092408, 0.055744, 0.0408, 0.085409, 0.024379, 0.071587, -0.110477, 0.038558, 0.032307, -0.153121, -0.145607, -0.051468, 0.040605, 0.023557, 0.081415, -0.069222, -0.10222, -0.082052, 0.124214, -0.191566, -0.116938, -0.014237, -0.047301, -0.06205, -0.051956, 0.150522, 0.007037, -0.098315, 0.141005, 0.097889, -0.041811, 0.014443, 0.016553, -0.002249, 0.003139, 0.015166, 0.139681, 0.012643, -0.107312, 0.099707, -0.017363, -0.057342, -0.055936, -0.061811], [0.014439, -0.020354, 0.153387, 0.077504, 0.009552, 0.028036, -0.047493, -0.086366, 0.019683, -0.085959, 0.037527, -0.000485, 0.051596, -0.036663, -0.016802, 0.010106, -0.012871, 0.086093, 0.06602, 0.01685, -0.173146, -0.023771, -0.138995, 0.005861, 0.074354, 0.094279, 0.084983, 0.019375, 0.10433, -0.085828, 0.091132, -0.201112, 0.017982, -0.070851, -0.005961, -0.05228, -0.060224, 0.06501, 0.020175, 0.007409, 0.038234, -0.167701, -0.082156, 0.079015, -0.081813, 0.010921, 0.051619, -0.03046, 0.011196, 0.052155, -0.032208, -0.109112, -0.089562, 0.128195, -0.049263, -0.041319, 0.008171, -0.104311, -0.176534, -0.068567, 0.089406, -0.124239, -0.081586, 0.139783, 0.073174, 0.012787, 0.0395, -0.000239, 0.003399, -0.048041, 0.183167, -0.025345, 0.049095, 0.097573, -0.054892, 0.054983, -0.063392, -0.030827, 0.014123], [-0.079799, 0.014765, 0.011101, 0.020985, -0.024167, 0.019152, 0.053832, -0.139093, 0.030492, -0.057716, 0.101001, -0.048404, 0.106385, -0.151205, 0.064573, -0.063049, -0.04759, -0.047632, -0.000934, -0.153655, 0.023153, 0.016455, -0.064615, 0.105567, 0.03, 0.049873, 0.084025, 0.162705, -0.046774, -0.111379, 0.049285, -0.020364, 0.040374, 0.117417, -0.04951, -0.033219, -0.159624, 0.053422, -0.018397, -0.061171, -0.06365, -0.032583, 0.051079, 0.119213, -0.146182, 0.149881, 0.011633, 0.010677, 0.036208, 0.070113, 0.046666, -0.065856, 0.195856, 0.076667, -0.114736, -0.109043, 0.007155, -0.11313, -0.276628, 0.287434, 0.122622, -0.165172, -0.141746, 0.100641, 0.041347, 0.017765, 0.04425, 0.009948, 0.01017, 0.009143, 0.074421, 0.039306, -0.071883, 0.11023, 0.024092, -0.09683, -0.098758, -0.014083, -0.02345], [-0.114189, -0.164454, 0.024912, 0.030845, 0.024272, -0.025224, 0.05726, 0.10242, -0.092027, -0.094929, -0.041827, -0.031236, -0.043753, 0.05985, -0.05668, -0.081248, 0.075227, 0.009078, -0.021247, -0.012528, 0.00237, 0.006754, 0.085044, 0.074044, -0.003591, 0.216119, -0.034771, 0.097394, -0.115149, -0.027181, 0.013172, -0.034103, -0.071861, -0.047628, -0.096763, 0.101985, 0.051413, 0.097199, -0.148159, -0.012683, -0.194648, 0.099086, -0.030425, 0.042745, -0.089024, 0.035739, -0.009913, -0.079283, 0.080647, 0.096507, -0.033059, -0.000438, 0.0485, -0.052681, -0.099823, -0.134884, 0.045498, -0.053623, -0.079476, 0.051244, 0.044125, -0.055374, 0.166242, -0.055623, 0.030228, -0.039715, 0.019472, 0.035404, 0.024354, -0.013208, 0.018877, -0.003402, 0.056914, 0.001504, -0.00192, 0.138024, 0.029856, -0.013209, -0.024769], [0.076091, 0.110898, 0.152747, 0.009346, -0.07087, 0.159029, 0.017811, -0.067783, 0.000376, 0.006579, 0.072045, 0.12847, 0.059219, -0.088229, 0.204534, -0.136464, 0.0381, 0.063332, 0.134298, -0.022252, 0.140392, 0.156772, -0.007513, -0.106852, -0.052398, 0.041897, 0.045828, 0.070098, 0.07778, -0.019977, 0.045212, 0.10777, 0.030826, -0.072891, -0.054202, -0.038726, 0.040268, -0.110653, -0.016883, 0.033428, 0.033708, -0.112953, 0.120148, -0.0584, -0.003417, 0.018801, 0.048122, -0.088874, -0.028079, 0.003158, 0.047656, 0.146116, 0.155233, -0.073066, 0.054579, -0.027203, 0.134719, -0.018752, 0.030842, -0.166798, -0.07151, 0.009922, -0.17486, 0.102952, 0.080319, -0.007018, 0.008963, -0.022183, -0.012251, -0.012697, -0.215116, 0.105415, -0.022076, -0.088901, 0.0445, 0.023228, 0.023239, 0.034573, 0.043396], [-0.009336, -0.253399, 0.11432, 0.050503, -0.008121, 0.075118, 0.080337, 0.042361, -0.048211, 0.036863, 0.068751, 0.03104, -0.018031, 0.001665, 0.006275, 0.033827, 0.003243, -0.117346, 0.025723, 0.134342, 0.032931, -0.101082, 0.005661, 0.121406, 0.04612, 0.092947, -0.020937, -0.049926, 0.124365, 0.000846, 0.075457, -0.073831, -0.110581, 0.005252, 0.020441, -0.096311, 0.006319, -0.018279, -0.004722, -0.01027, -0.093416, 0.069408, -0.079249, 0.046338, -0.105675, 0.125867, 0.008694, 0.037538, 0.049289, -0.059866, -0.017431, -0.141986, -0.038154, 0.026165, -0.143938, 0.074002, -0.165266, -0.123482, 0.054377, 0.011107, 0.3625, -0.136029, -0.000203, 0.020283, -0.079609, 0.034693, -0.003728, 0.008129, 0.005902, 0.018622, 0.042914, -0.057308, -0.101167, 0.076558, -0.104426, 0.050664, 0.023825, -0.002284, 0.128752], [-0.021877, 0.034359, -0.114679, -0.048078, 0.024237, -0.011087, -0.021064, 0.038037, 0.021947, -0.095223, -0.138121, 0.087333, 0.057244, -0.003521, 0.064296, -0.028597, 0.015547, -0.02571, -0.019902, -0.066751, 0.021947, -0.131504, -0.014958, -0.088498, -0.015502, 0.038888, -0.05936, 0.096864, 0.006264, 0.019776, -0.020502, 0.212537, 0.094414, -0.017182, -0.050316, -0.139973, 0.079575, -0.023092, 0.067093, -0.013575, 0.091192, -0.064207, 0.014977, -0.018157, -0.045031, -0.101986, 0.013771, -0.035357, -0.046647, 0.06396, -0.012544, 0.07989, 0.220367, 0.089942, -0.121252, -0.219924, 0.129931, 0.097666, -0.029535, 0.088446, -0.260031, 0.10733, 0.061091, 0.083815, 0.082223, 0.007482, 0.028427, 0.046285, 0.015657, 0.027772, -0.099544, -0.010321, -0.032022, 0.105237, -0.135366, -0.004673, -0.099011, -0.02446, -0.059027], [-0.05377, -0.164809, -0.021417, -0.14077, 0.051154, 0.005753, -0.009013, -0.08258, -0.095721, -0.048431, 0.07878, -0.035539, 0.066805, 0.081556, -0.101658, -0.081159, 0.039527, 0.043435, 0.124429, -0.059285, -0.010322, 0.088656, 0.103483, -0.007834, 0.033629, -0.016713, -0.113526, 0.081066, -0.002974, 0.094582, -0.116404, 0.039776, 0.12211, -0.000399, -0.00522, 0.017484, 0.025638, -0.050603, -0.049891, -0.173917, -0.038368, -0.151589, -0.019395, 0.097158, -0.015028, -0.110482, 0.04422, -0.062985, -0.032986, -0.014294, 0.185385, 0.129841, 0.140216, 0.028057, 0.021272, -0.065195, 0.129646, 0.020433, 0.019113, -0.096609, -0.133963, 0.000871, 0.09081, -0.047593, 0.065323, -0.006316, -0.029217, -0.035602, 0.004672, -0.011428, -0.116681, 0.06582, 0.047497, 0.053808, 0.038508, -0.03658, 0.059541, 0.066761, 0.086088], [0.074658, 0.19299, -0.153737, 0.018334, 0.039108, 0.044394, -0.006373, 0.082253, 0.001985, -0.05219, -0.040881, 0.197351, 0.004382, 0.043391, 0.103164, 0.076301, -0.109275, -0.100209, -0.113615, 0.076865, 0.003378, 0.014051, 0.038334, 0.017258, -0.089507, -0.107387, 0.052508, 0.090707, -0.100763, 0.10617, 0.068378, 0.163344, -0.009732, -0.078997, -0.072775, -0.049438, -0.119854, 0.028679, 0.001736, 0.02567, 0.059356, 0.051119, 0.115514, 0.047446, 0.201747, -0.033612, 0.008769, 0.11193, -0.080199, -0.082596, -0.146971, -0.009894, -0.00289, 0.008508, -0.087048, 0.091126, -0.052673, -0.018342, -0.193392, 0.195102, 0.008526, -0.003327, 0.041209, 0.192209, 0.008674, 0.013948, 0.028664, 0.002304, -0.014039, 0.017584, -0.126871, -0.037125, -0.157718, 0.093711, 0.026296, 0.067153, -0.129622, -0.006381, -0.090074], [-0.038686, 0.079155, 0.012016, 0.049174, -0.065521, 0.040392, -0.032673, 0.001312, 0.021251, -0.097373, 0.038131, 0.036266, -0.012209, 0.008151, -0.027533, -0.095801, 0.124048, 0.005138, -0.081044, 0.02255, 0.025271, 0.045759, 0.035182, 0.016722, -0.148798, 0.118033, 0.039701, 0.024805, -0.036436, -0.025977, 0.0897, 0.046271, 0.086999, 0.02718, -0.012371, -0.009918, -0.017209, -0.127339, -0.063039, 0.010029, -0.112058, -0.053279, 0.000919, 0.023894, 0.082442, 0.015675, 0.0522, -0.029694, 0.037763, 0.075031, -0.121734, -0.137734, -0.068735, 0.021517, -0.157951, 0.02932, -0.040175, -0.189896, 0.059794, -0.038397, 0.276784, -0.14024, 0.04607, 0.119908, 0.074205, 0.022018, 0.013049, 0.000771, 0.034887, -0.020912, -0.077276, -0.112024, 0.003959, -0.028749, 0.05771, -0.019667, 0.058872, 0.019313, 0.086918], [-0.060077, 0.045573, -0.116506, -0.045039, 0.042891, 0.010498, 0.029967, 0.008487, -0.029461, 0.013317, -0.031154, -0.041638, 0.056348, -0.068691, -0.080784, 0.047538, -0.160517, 0.178811, -0.06038, -0.0451, -0.052686, -0.016819, 0.221903, -0.087638, 0.048888, -0.038804, 0.253699, -0.139728, 0.083913, -0.104953, 0.032136, 0.004905, -0.058862, 0.080936, 0.065398, 0.160449, -0.105904, -0.166219, -0.105534, 0.003426, -0.174613, 0.112019, -0.018768, -0.001209, 0.106979, 0.202475, -0.111862, 0.113739, 0.014568, 0.037446, -0.135955, -0.215235, -0.074657, 0.075075, -0.247722, 0.043303, -0.1178, -0.154333, -0.0697, -0.006417, 0.459903, -0.219072, -0.027574, 0.117582, -0.053982, -0.014074, -0.064811, 0.03283, 0.042225, -0.014368, 0.139826, -0.140392, -0.06535, 0.090957, -0.015191, 0.045994, 0.017711, -0.042042, 0.086158], [-0.091741, 0.042699, -0.052853, 0.014931, -0.019023, -0.001567, 0.016473, -0.016324, 0.109735, 0.128072, 0.030585, -0.142489, 0.050914, -0.13644, 0.07814, 0.028728, 0.06517, 0.061925, 0.052371, -0.033136, 0.171123, 0.153798, -0.015973, -0.008482, -0.123936, 0.025391, 0.168534, 0.107553, 0.098562, 0.103983, 0.057132, -0.006674, -0.009393, 0.072567, -0.03979, -0.113208, 0.153572, -0.10654, 0.039795, -0.014398, 0.001767, 0.045815, -0.018506, 0.044303, 0.095448, 0.007161, -0.007882, -0.041597, 0.009857, 0.020038, 0.059408, 0.070086, 0.035394, -0.228892, 0.084844, 0.019947, 0.021219, 0.022811, -0.113504, 0.101341, -0.244589, 0.032125, 0.084455, 0.007864, 0.043141, 0.035988, -0.044887, 0.021536, 0.036163, -0.033521, 0.019392, 0.051153, -0.109876, -0.080202, -0.04108, 0.082955, -0.11045, -0.12025, -0.059778], [0.036795, 0.012688, 0.007678, -0.098652, 0.041224, 0.025986, -0.07985, -0.06642, 0.028682, 0.027091, -0.095093, 0.014292, -0.0539, 0.039424, -0.086026, -0.046582, -0.042057, -0.018078, 0.009732, 0.049369, -0.061217, -0.014756, 0.006553, -0.001746, -0.04723, -0.045236, 0.096479, -0.018697, 0.052496, 0.059448, 0.015084, 0.064884, -0.005965, 0.035149, 0.098498, 0.019292, -0.045497, -0.100542, 0.029753, -0.090233, 0.151137, -0.088787, -0.008617, 0.083934, 0.145092, 0.001282, 0.098506, 0.001459, 0.006226, -0.116759, -0.066695, -0.047681, 0.056154, 0.04093, -0.033084, -0.015309, 0.065113, 0.120062, 0.09597, -0.121385, 0.001806, 0.098282, 0.040953, -0.130161, 0.0312, 0.01435, -0.061047, -0.027546, 0.029589, -0.01083, -0.093586, 0.022114, -0.103865, 0.032763, 0.051421, 0.066123, 0.090199, 0.057008, -0.042641], [0.029504, 0.008401, -0.044885, -0.035243, -0.007646, 0.01726, 0.043307, -0.009086, -0.008081, 0.160259, -0.05326, -0.048282, 0.005021, 0.014827, 0.091465, 0.022585, -0.079774, -0.044001, 0.011701, -0.021594, 0.110479, -0.011328, 0.093159, 0.064736, 0.119439, 0.043004, 0.000213, -0.051617, 0.021656, -0.047535, -0.120297, -0.054218, -0.065116, 0.007568, 0.161894, 0.06982, 0.052394, -0.106825, -0.001836, -0.114357, 0.083275, -0.109275, 0.055104, -0.050085, 0.009744, -0.082804, -0.052573, -0.047264, -0.067218, -0.084875, 0.200583, 0.010579, 0.055278, -0.06547, -0.104259, 0.008148, -0.042191, 0.028377, 0.212529, -0.188987, 0.040192, 0.108812, -0.057224, -0.025668, -0.13857, -0.037924, -0.030882, 0.02964, -0.030517, 0.046357, -0.07428, 0.045608, 0.060275, 0.092435, -0.059667, -0.09722, -0.00318, 0.038624, -0.106697], [0.016031, 0.009875, -0.02345, 0.017639, -0.093645, -0.015644, 0.023407, -0.083302, 0.00339, 0.062605, 0.114696, -0.12559, 0.040092, 0.00955, -0.053736, -0.046791, 0.006485, 0.035021, -0.036515, 0.00261, 0.061032, 0.174424, 0.111432, 0.02933, -0.06497, -0.025232, -0.040868, 0.031462, -0.110874, -0.080001, -0.002395, -0.01221, 0.062466, 0.072397, -0.133742, -0.036479, -0.120852, 0.045609, 0.103131, -0.040633, 0.08058, -0.050314, 0.045848, -0.047681, -0.057784, 0.069823, 0.155543, -0.027281, -0.043032, -0.111618, 0.037501, 0.083801, 0.016659, -0.022036, 0.092698, 0.05234, 0.098433, -0.037308, 0.12164, -0.121184, -0.104521, 0.194013, -0.023271, -0.318751, -0.14439, -0.025084, -0.002921, -0.082234, -0.027094, 0.03585, -0.157126, 0.032638, 0.097154, -0.087774, 0.108974, -0.048666, 0.095324, 0.137923, 0.027577], [0.052441, -0.033285, -0.002891, -0.003266, 0.044136, 0.157772, -0.065873, -0.27824, 0.079059, -0.062047, -0.168186, -0.029876, 0.03206, 0.058403, -0.002604, -0.081204, -0.003147, 0.007324, -0.119904, 0.019691, -0.074642, 0.081947, -0.051714, 0.110707, 0.011156, -0.005531, 0.087478, 0.012342, 0.06414, -0.038377, 0.186078, 0.144556, -0.108991, 0.13138, -0.017463, -0.050643, -0.16835, 0.071614, 0.137503, 0.042144, -0.052026, -0.056332, 0.039217, 0.07904, -0.116158, 0.038106, 0.042266, 0.042643, 0.110381, 0.154212, -0.11242, -0.104381, 0.063845, 0.176554, -0.127401, -0.059537, -0.039722, -0.126045, -0.169864, 0.071176, -0.041786, -0.055589, 0.037826, 0.04921, 0.066993, 0.034359, -0.011518, 0.037134, 0.052831, 0.001833, 0.057476, -0.00931, -0.147526, -0.015745, 0.040392, 0.011604, -0.076275, -0.021664, -0.083456], [-0.074889, 0.157552, 0.037776, -0.117221, 0.056574, -0.081557, -0.060611, 0.050438, 0.053327, 0.018602, -0.078166, -0.002682, 0.061435, -0.06218, -0.027092, -0.043974, 0.005387, 0.026451, 0.023309, -0.106068, 0.076417, 0.152699, 0.138545, -0.051535, 0.100202, -0.075173, 0.120703, -0.128164, -0.05684, -0.086197, 0.032726, -0.001471, 0.106122, 0.025285, -0.028435, 0.078175, 0.017457, 0.145359, 0.097896, 0.047798, 0.126964, -0.068518, -0.061168, -0.119543, -0.056514, -0.059647, 0.051084, -0.108342, -0.055107, -0.062014, 0.127639, -0.14867, -0.055008, -0.17845, -0.035985, -0.011583, 0.077561, -0.067226, -0.020275, -0.361677, 0.010732, 0.125997, 0.028822, -0.028577, -0.026166, -0.087689, -0.025076, 0.049942, -0.020526, 0.020796, 0.08816, 0.158203, 0.009531, -0.061658, 0.05801, -0.023588, 0.001932, -0.096443, 0.035785], [0.036271, 0.133351, 0.02266, -0.07372, 0.100621, -0.040285, 0.042685, -0.046823, -0.009892, 0.034816, 0.059996, -0.018303, 0.007117, -0.099313, 0.085319, 0.11523, -0.053716, -0.084045, -0.001098, 0.01958, -0.089004, -0.136669, -0.087772, -0.041363, 0.085786, -0.048569, 0.050819, -0.108025, 0.043753, 0.012674, 0.01793, -0.037645, 0.036299, 0.009411, 0.034974, -0.046461, 0.042409, 0.057984, 0.105092, -0.06904, 0.074019, -0.130012, 0.010193, 0.03406, 0.058185, 0.034077, 0.030803, -0.03196, -0.055119, -0.080071, 0.027434, 0.184658, 0.097738, -0.081924, 0.163984, -0.056296, 0.074536, 0.030461, 0.082822, -0.152016, -0.356109, 0.033601, -0.070645, 0.014173, -0.016443, -0.059879, 0.068943, -0.022188, 0.01, 0.024835, -0.075872, -0.012404, 0.065891, 0.014079, 0.051377, 0.090689, -0.007196, -0.009697, -0.050142], [-0.048132, -0.078456, -0.012963, -0.100339, 0.006524, 0.04976, 0.057151, -0.021536, 0.03149, 0.025212, -0.105823, 0.071371, 0.097958, 0.036625, -0.007713, -0.001805, 0.021451, -0.019377, -0.044338, 0.048867, 0.103603, -0.027035, 0.02973, -0.091484, -0.056379, 0.072285, -0.041603, 0.139324, 0.038363, 0.056281, -0.088026, -0.019877, 0.052612, -0.088193, -0.102655, 0.033573, 0.067135, -0.126162, -0.106952, 0.019237, 0.077099, -0.065793, 0.003299, -0.063696, 0.161512, -0.104842, -0.031276, 0.017225, 0.004169, -0.040581, -0.00674, 0.041492, 0.099086, -0.001803, -0.020561, 0.034053, 0.174388, 0.071018, 0.062118, 0.030612, -0.146196, 0.055181, 0.117318, -0.018859, 0.095554, 0.022959, -0.059365, 0.015772, -0.038202, 0.057671, -0.032444, -0.120023, 0.105164, 0.013974, -0.083191, -0.018118, -0.012176, -0.048256, 0.012132], [0.009905, -0.028168, -0.171184, -0.045708, -0.051753, 0.088301, 0.083149, -0.056494, 0.02009, -0.05987, 0.065687, -0.070874, 0.008027, 0.159643, 0.097742, 0.163922, -0.153846, -0.020457, 0.047794, -0.023879, -0.066599, -0.021298, -0.02927, 0.061071, 0.092551, 0.05222, -0.079531, -0.103917, -0.075147, -0.041023, -0.126249, -0.009109, 0.009984, 0.058721, -0.057226, 0.028177, 0.122815, -0.106691, 0.025737, -0.012423, -0.00321, 0.138815, 0.079476, 0.142197, 0.037157, 0.018375, -0.040582, 0.118432, -0.011215, 0.120703, -0.102584, -0.062682, -0.017453, 0.032281, -0.008565, 0.100833, 0.031731, -0.167274, -0.011509, 0.174748, 0.122856, -0.03151, -0.071863, 0.097356, -0.015608, 0.027107, 0.035121, -0.024411, -0.012245, 0.054255, -0.138242, -0.125952, -0.085238, -0.046716, -0.07791, 0.095887, -0.107955, 0.034372, 0.080867], [0.017104, -0.062178, -0.069043, 0.053551, -0.027972, 0.039595, -0.06868, 0.06014, -0.015484, -0.008365, -0.115096, -0.040969, -0.104754, 0.068815, -0.013407, 0.033435, -0.043489, 0.106282, 0.022655, -0.083192, 0.009445, 0.052394, 0.00976, -0.037098, -0.060804, 0.077475, 0.037383, -0.028364, 0.227761, 0.010063, -0.033767, 0.03728, -0.035167, -0.016669, -0.02253, 0.100839, -0.045241, -0.019694, 0.006953, 0.055404, -0.105576, -0.089233, 0.081539, 0.175255, -0.019423, 0.162246, -0.046498, -0.024538, 0.053769, 0.011404, 0.042146, 0.03721, 0.039898, -0.048826, -0.032784, -0.091269, -0.020583, -0.021061, 0.084433, 0.073473, -0.078098, 0.167697, 0.0476, -0.184522, 0.012398, 0.017019, -0.009762, -0.005857, -0.044476, 0.056073, -0.053911, -0.099601, -0.069855, 0.004378, -0.080671, -0.129176, 0.091967, 0.027165, 0.011276], [-0.002989, -0.074988, 0.045053, -0.245002, 0.071594, 0.053191, 0.005059, 0.038522, -0.02851, -0.02412, -0.019299, -0.031484, 0.108104, -0.015191, -0.164106, 0.121571, -0.09328, 0.078382, 0.125058, -0.036827, -0.090076, 0.000367, -0.082886, 0.070785, 0.239415, -0.01579, 0.073825, -0.054138, -0.131963, -0.058106, 0.005637, -0.139262, 0.134879, -0.032648, -0.052006, -0.010364, -0.111677, 0.117879, 0.113201, 0.127094, -0.069981, -0.055894, 0.020524, -0.023167, -0.129802, 0.002532, -0.099734, -0.144808, 0.039455, 0.010051, 0.232697, 0.122144, 0.066833, 0.055919, 0.073744, -0.022725, 0.019692, -0.03681, 0.022186, -0.127421, -0.027978, -0.027156, -0.064643, -0.145793, -0.042547, -0.019931, 0.02654, -0.023053, -0.043945, 0.113029, -0.001531, -0.107789, 0.115223, -0.011871, -0.097141, 0.122211, -0.028098, 0.011764, 0.094194], [-0.133136, -0.065173, 0.028961, 0.054673, -0.079781, 0.05619, 0.062139, 0.001866, 0.085795, -0.07436, -0.04379, -0.040665, -0.070628, -0.041303, -0.078592, -0.044562, 0.048647, 0.034003, 0.077619, -0.015071, 0.141431, 0.158272, -0.002388, 0.021015, 0.00372, 0.000325, -0.066073, 0.129562, -0.151826, -0.039178, -0.11971, 0.133848, 0.00308, 0.053666, -0.066283, 0.024831, 0.196725, 0.04698, 0.062673, 0.067861, -0.192415, 0.069156, 0.1104, 0.152755, -0.278016, -0.070894, -0.004345, 0.072129, 0.181435, 0.111669, 0.048818, 0.122101, -0.104162, 0.078643, 0.066281, -0.07977, 0.037909, -0.014907, -0.045582, 0.008677, -0.106673, 0.131456, 0.033004, -0.104905, 0.067444, 0.017542, 0.022451, 0.00158, 0.008401, 0.02293, -0.144579, 0.080375, -0.039807, 0.049876, -0.038374, 0.070999, -0.028835, 0.065996, -0.079418]], 'w2': [[0.045533, -0.001386, 0.013081, -0.093794, 0.006416, 0.022648, 0.017226, -0.023985, -0.00285, -0.026779, 0.016079, -0.030509, -0.000629, 0.011989, -0.009369, 0.001791, -0.049539, -0.029059, -0.009429, 0.02785, -0.025119, 0.00385, -0.058442, 0.014179, -0.090963], [-0.045255, 0.010921, -0.004696, 0.084963, 0.014571, -0.017658, -0.027804, 0.022168, -0.007998, 0.027325, -0.025801, 0.036826, 0.01032, -0.000916, 0.007153, 0.012493, 0.047512, 0.015475, 0.014736, -0.029606, 0.025996, -0.017644, 0.065142, -0.014123, -0.059737]], 'hist_par': {'USDCHF-OTC': '10100101000001111111', 'SP500-OTC': '00101001100001110010', 'ONDOUSD-OTC': '10110011110000101111', 'EURGBP-OTC': '10100110100010001011', 'RENDERUSD-OTC': '00000000000101111101', 'SUIUSD-OTC': '10111101111100001111', 'HBARUSD-OTC': '00001011100010101110', 'RAYDIUMUSD-OTC': '11000101110101000001', 'GBPUSD-OTC': '00111001101100000011', 'PENGUUSD-OTC': '11111001111111010011', 'DYDXUSD-OTC': '11111001011010011010', 'EURUSD-OTC': '10010111000011010011', 'EURJPY-OTC': '01000001000100001100', 'FETUSD-OTC': '10010101010011010001', 'AMAZON-OTC': '01011010100001000000', 'Gold/BRL': '11001110010001110110', 'NZDCAD-OTC': '11001001000110100001', 'LINKUSD-OTC': '10001001011001100110', 'AUDJPY-OTC': '00011101011110000110', 'SANDUSD-OTC': '00010001111010101100', 'GBPCHF-OTC': '01111011111111111000', 'XNGUSD-OTC': '01101001100011111111', 'INJUSD-OTC': '11100001101111100010', 'NEARUSD-OTC': '10100111001010011001', 'FARTCOINUSD-OTC': '00001001100011100001', 'AUDCAD-OTC': '01011001011001000100', 'NZDUSD-OTC': '01011010010100010011', 'USOUSD-op': '01110010110101111011', 'DIA': '11011101111001001001', 'FR40-OTC': '11001111110000100001', 'EURCHF-OTC': '11100010001101101101', 'XAUUSD-OTC': '01010100110011011000', 'Crude Oil Brent/BRL': '10100101101001111011', 'IWM': '11110101111001001011', 'SQQQ': '00000101011110100100', 'XLK': '01101011100110110011', 'SMH': '10101111000110110011', 'EURTHB-op': '00000000111111110000', 'UKOUSD-OTC': '00111000011101001010', 'ATOMUSD-OTC': '10110000100001011000', 'MELANIAUSD-OTC': '11011110001100110010', 'JPM-OTC': '11011101111000010000', 'AIRLINES-OTC': '10110101011101010110', 'WIFUSD-OTC': '00110011010110001011', 'USDJPY-OTC': '00111110100101111110', 'IMXUSD-OTC': '10000010111111110000', 'FWONA-OTC': '00110110101001011010', 'DASHUSD-OTC': '11011110110001100010', 'GDX': '00111111001000111111', 'PEPEUSD-OTC': '00100100101101011011', 'SPY': '10101011110011010011', 'WLDUSD-OTC': '10101001011001010011', 'USDTHB-OTC': '00100110101111110110', 'JP225-OTC': '01010001101111101100', 'USNDAQ100:N': '01011011101001110011', 'USSPX500:N': '11010101111001110011', 'ARBUSD-OTC': '10110001010010101111', 'PENUSD-OTC': '10100000110111110000', 'AUS200-OTC': '10111101011010000111', 'GBPCAD-OTC': '01010011001101001111', 'EURTHB-OTC': '00001111011100010100', 'CHFNOK-OTC': '10100110001011101011', 'MCDON-OTC': '00000010111000101100', 'US30:N': '11011101101001001001', 'JPYTHB-OTC': '00101001100000111100', 'GRTUSD-OTC': '00101111101000001010', 'AUDCHF-OTC': '11000010100111101111', 'SOLUSD-OTC': '00011010010001111101', 'USOUSD-OTC': '11101010011000001101', 'COKE-OTC': '01111010000110101000', 'OpenAI-OTC': '00011001110011000001', 'SHIBUSD-OTC': '00010100101101100100', 'MAGNIFICENT7-OTC': '01111111111100011111', 'USNDAQ100-OTC': '01001010100101111101', 'USDDOP-OTC': '11101110000001100001', 'EURAUD-OTC': '11001001010111110110', 'JAPAN225:N': '10111101010000010011', 'GERMANY30:N': '11111101111001100001', 'FRANCE40:N': '11111001110010100011', 'XRPUSD-OTC': '00001010001001000101', 'JUPUSD-OTC': '00101100100111001111', 'GBPJPY-OTC': '01010100011101010100', 'USDSEK-OTC': '00101000000011000111', 'USDBRL-OTC': '01100000110010110011', 'APPLE-OTC': '01011011101110100100', 'US2000-OTC': '01110010101100011111', 'CADJPY-OTC': '00001000101010111001', 'EOSUSD-OTC': '11001100011001100011', 'AI Power & Datacenter': '01101011101111110111', 'FB-OTC': '00111110111101110001', 'US30-OTC': '01010110000110010011', 'Bitcoin/Gold-op': '11110101001000000011', 'US AI Semiconductors': '01101011100110110011', 'AUDNZD-OTC': '01111010000001111011', 'PLTR-OTC': '11111110011111010100', 'AUS200:N': '11110011110001010001', 'XAGUSD-OTC': '00101011010100110011', 'CADCHF-OTC': '01000001010100011111', 'USDCAD-OTC': '11110101101011000000', 'SNAP-OTC': '01011100100000001100', 'BTCUSD-OTC-op': '01101100010010110111', 'IOTAUSD-OTC': '00010110011110110111', 'MATICUSD-OTC': '00001010001011110010', 'USDPLN-OTC': '11001001100010010100', 'USDSGD-OTC': '00011101100011000100', 'CHFJPY-OTC': '11000001001000010110', 'NZDJPY-OTC': '01110000000110011000', 'USDZAR-OTC': '10100011010111000111', 'KLARNA-OTC': '10001101000010011000', 'HK33-OTC': '01100111111011011100', 'US2000:N': '11110101110010011011', 'HONGKONG33:N': '11111110010110110010', 'USDNOK-OTC': '00100001111110100110', 'Anthropic-OTC': '10011100000110101001', 'UK100-OTC': '11000010011111100110', 'USDCOP-OTC': '01111010110100001010', 'CASINOS-OTC': '00011110111000000100', 'EURCAD-OTC': '11011100110110000001', 'EU50-OTC': '10100111010100011111', 'SATSUSD-OTC': '11010000111001000011', 'URANIUM-OTC': '00100111100101110010', 'BONKUSD-OTC': '11000000001110000001', 'CANNABIS-OTC': '01010001001100100100', 'MSFT-OTC': '11101010010000110110', 'MORSTAN-OTC': '01111001101110100010', 'ETHUSD-OTC': '01110011110011100011', 'AUDUSD-OTC': '00011000000011011000', 'USDARS-OTC': '00110000110001011111', 'TRON-OTC': '11111111000000101001', 'GER30-OTC': '00000010110000010001', 'GBPNZD-OTC': '01100001101011011101', 'GOOGLE-OTC': '01100011000011111101', 'TIAUSD-OTC': '11111011011011011110', 'UK100:N': '11001000110010100101', 'Magnificent7-op': '11101101010010100011', 'GS-OTC': '11000011000010011100', 'GBPAUD-OTC': '00101110000101011111', 'TESLA-OTC': '01000110110001011001', 'LABUBUUSD-OTC': '10000100001010100000', 'USDTRY-OTC': '10011011000011100000', 'DOTUSD-OTC': '10110101111010111111', 'ALIBABA-OTC': '01001101000111010111', 'TRUMPUSD-OTC': '11110011001001001101', 'PYTHUSD-OTC': '00000100010001100100', 'EURNZD-OTC': '00101100100010100110', 'LTCUSD-OTC': '10000100010000100110', 'GER30/UK100-OTC': '00101101100101011110', 'COTTON-OTC': '00111001100000101110', 'US30/JP225-OTC': '11101111011001100100', 'EURJPY-op': '01000110101110110001', 'TESLA/FORD-OTC': '10000011000100110010', 'NVDA/AMD-OTC': '01100011101000011001', 'XAU/XAG-OTC': '11011100010001111111', 'GOOGLE/MSFT-OTC': '10101001000011000000', 'META/GOOGLE-OTC': '01111001100011101010', 'LUNA-OTC': '01111111010100011010', 'USDAED-OTC': '10101100000100010110', 'US100/JP225-OTC': '11010110001000011000', 'MSFT/AAPL-OTC': '00100111000011010001', 'AMZN/EBAY-OTC': '01000100111011011110', 'NVDA-OTC': '00111011010001101100', 'EURUSD-op': '11011000001111111000', 'EURGBP-op': '11010110001000010001', 'USDTHB-op': '11000111000100000001', 'USDMYR-OTC': '00010011100100011110', 'AMZN/ALIBABA-OTC': '11010000001010100100', 'USDVND-OTC': '00101101001000111001', 'COCOA-OTC': '00111010001001110011', 'USDBOB-OTC': '01101010011011000001', 'ICPUSD-OTC': '10110111001010110001', 'USDIDR-OTC': '11101110001001010110', 'XPDUSD-OTC': '00110110110101011001', 'USDHKD-OTC': '11111101110101111101', 'WDC-OTC': '11000001010110101001', 'COFFEE-OTC': '10010001111011010011', 'USDPHP-OTC': '10101001001001100000', 'USDJPY-op': '01101101110100101111', 'XPTUSD-OTC': '01000010011001001100', 'SUGAR-OTC': '10010010100110010011', 'GBPJPY-op': '01011110101000110111', 'USDNGN-OTC': '01000001110000100111', 'INTEL/IBM-OTC': '10110100010011110010', 'SEIUSD-OTC': '11010010100111101110', 'USDSAR-OTC': '10001101101100101000', 'RONINUSD-OTC': '00111010010100010001', 'HYPE-OTC': '10100010011111011101', 'NIKE-OTC': '00010110000110000111', 'MU-OTC': '01010101011001010110', 'GEV-OTC': '10101001111010110111', 'USDBDT-OTC': '10011000100001100001', 'NFLX/AMZN-OTC': '11000101011111100111', 'GBPUSD-op': '11100001111011000001', 'USDCLP-OTC': '10000000111010100110', 'XAUUSD-op': '00111000010100011101', 'SpaceX-OTC': '11100000110100111111', 'SpaceX-op': '11110111101101010101', 'ASMLa': '10101111110011110011', 'NZDCAD-op': '11010011100001010100', 'European AI': '01101011100111110011', 'Luxury': '11011000111101101100', 'AUDCAD-op': '10101101101100000100', 'AUDUSD-op': '01010110100100010001', 'GBPCAD-op': '10110110100100101111', 'BTCUSD-op': '01111110101001001001', 'GBPAUD-op': '10100110001010011001', 'AUDNZD-op': '11110111000010100010', 'GBPNZD-op': '00100001010010101101', 'AUDCHF-op': '11000100011001000011', 'AUDJPY-op': '11001010101011100000', 'EURNZD-op': '10000000110001001000', 'AMAZON-op': '10110110110101010011', 'GOOGLE-op': '11101101100011110001', 'USDMXN-OTC': '01010010110001111101', 'FACEBOOK-op': '11010110000001010000', 'MSFT-op': '01111011001001000101', 'TESLA-op': '11100100111110010011', 'Japanese AI': '1', 'AIG-OTC': '01001110001001101100', 'NOKJPY-OTC': '01010010111000110101'}, 'hist_ctx': {'otc20': '10111111111111100100100001110001110001011001011111', 'otc21': '01000110010111010001001100011110000101100101110111', 'otc22': '11110100011111111000001001001001011000011001101000', 'otc23': '10101011101010010110010000101111001101010000011010', 'otc0': '10111100100001100110010010100010100000011010000010', 'otc1': '01100001011000110010111010111110010110000100101111', 'otc2': '00101110110101000010001011011111110000011100100011', 'otc3': '10000000010111111100111100000101000001001110011110', 'otc4': '00110001110010000111110101011001010100000101000000', 'otc6': '10011101111110100011001101101001001011001000100101', 'otc7': '10110111111001100010110010100110101101100100001100', 'otc8': '11101001000110111011011100001011110100000100011100', 'otc9': '11001001100010000100011010001010110000001010110010', 'otc10': '00011110110011010100100010001001110101111101010101', 'otc11': '00110100100001110001000010000101100010100101011100', 'otc12': '00010000110011100010011100000011011110010110101101', 'otc13': '11100111110001001010011110001101000001100101101111', 'otc14': '10010010000101101111000011111011110100110110010101', 'otc15': '11100110011111001010000000100011100111101001110011', 'otc16': '11101001101100001010100010100011101010000011110010', 'otc18': '00001100100100100000100010101000100100011010000000', 'otc19': '01001001101000011000101100110000010110011001101111', 'otc5': '01110110111111101101010110000111110101100011100000', 'otc17': '00111101000101110100001010011000011010101001000101', 'real17': '01110001000100000000010000000010101101011111111111', 'real12': '00110011001010001010110111110001010000110100111110', 'real13': '11111101100001001000001011101001111010111110000001', 'real14': '01110111111000000000000000000000010000000000000000', 'real15': '11111111101100011100001001000000000000000000000000', 'real16': '00111100110111111111111110111111011111111111111111', 'real18': '10000101111111000000010000000000000000000010010100', 'real19': '00010111011111101101110001111111111111011101100110', 'real20': '01011011111101001000110000010001000111111111111111', 'real22': '00111101011111001010101001001111100101011011100000', 'real23': '00000000001101001001001110100001000110001100101011', 'real0': '01111001001001100011001101111000111011100000111101', 'real1': '10101000001101111110101111101111000001111111011000', 'real2': '01001110000000001100010010000111110100111100010011', 'real3': '01010110111101000011110001010001000100111010001101', 'real4': '00110010111010111111011001001000100100100111011111', 'real5': '00101000111110001111100100010110000101111111010010', 'real6': '10000110111000010000111111011011111101000001000010', 'real7': '00101001111110000000110110101010010100100110101001', 'real8': '00110110000100100001011001001010011010100001010011', 'real9': '00111100101010100000101101000101101011001101001010', 'real10': '11000100010001100011110101110011000011000000100100', 'real11': '11110110001100000100010100101010110011000001111010', 'real21': '11111110001100011010011101001001111011010001010110'}, 'aprendidas': 5941140, 'preentreno': True, 'sombra': '011110100000001001000101100011011011111001001010011000000001010010101000111011010100010001100101110111001111000000100101000001100101111101111101100101011111110011000011110111111110110101010100001000101110011001011101000011000000011011110101010101111111100001111100001011101100010110010001111111111101011100000110001010100001010001111110110000111100110111011100011011101000000001000111000001011101111010101000111001100001100101101000101001011011001000100010100111110101110000001000110010000000111110000110010000110110111000000110111100010000010000010101010101111100000111010011000000101001011100111101011011111111011100100110110100000100000111111011101000000101001100110010000011011010011100110010100000011011000001010000000010001001010000101101011101000110100111000011001011001100011', 'sombra_t': [1793381940, 1793382180, 1793381760, 1793382480, 1793382540, 1793382600, 1793382660, 1793382720, 1793382780, 1793382960, 1793382900, 1793383080, 1793383200, 1793383260, 1793383320, 1793383440, 1793383620, 1793383800, 1793383680, 1793384040, 1793384220, 1793384460, 1793384520, 1793384580, 1793384880, 1793384940, 1793385060, 1793385000, 1793385120, 1793385240, 1793385360, 1793385480, 1793385540, 1793385780, 1793385900, 1793386140, 1793386320, 1793385600, 1793386440, 1793386500, 1793386620, 1793386080, 1793386740, 1793386800, 1793386860, 1793386920, 1793386980, 1793386260, 1793387160, 1793387220, 1793387280, 1793387340, 1793387460, 1793387640, 1793387820, 1793387880, 1793388060, 1793388120, 1793388180, 1793388420, 1793388240, 1793388480, 1793388600, 1793388840, 1793389080, 1793389140, 1793389260, 1793389380, 1793389320, 1793389500, 1793389440, 1793389560, 1793389740, 1793389800, 1793389860, 1793389920, 1793389980, 1793389680, 1793390100, 1793390220, 1793390340, 1793390400, 1793390460, 1793390160, 1793390520, 1793390640, 1793390760, 1793390820, 1793390880, 1793390940, 1793391060, 1793391180, 1793391300, 1793391420, 1793391540, 1793391480, 1793391240, 1793391780, 1793391000, 1793391900, 1793391660, 1793391840, 1793391960, 1793391600, 1793392080, 1793392140, 1793392200, 1793392020, 1793392260, 1793392380, 1793392440, 1793392500, 1793392620, 1793392740, 1793392860, 1793392320, 1793392980, 1793392920, 1793393220, 1793393160, 1793393280, 1793393340, 1793393040, 1793393400, 1793393460, 1793393100, 1793393580, 1793393700, 1793393880, 1793393940, 1793394000, 1793393820, 1793394720, 1793394900, 1793395080, 1793395140, 1793395320, 1793394600, 1793395380, 1793395260, 1793395620, 1793395740, 1793395440, 1793395560, 1793395200, 1793395860, 1793395500, 1793395980, 1793395800, 1793395920, 1793396040, 1793395680, 1793396340, 1793396400, 1793396460, 1793396520, 1793396100, 1793396580, 1793396640, 1793396280, 1793396760, 1793396940, 1793396880, 1793397120, 1793397420, 1793397540, 1793397480, 1793397360, 1793397240, 1793397660, 1793397720, 1793397300, 1793397780, 1793397600, 1793397840, 1793398020, 1793398200, 1793397960, 1793398620, 1793398800, 1793398920, 1793397900, 1793398980, 1793399040, 1793399100, 1793399160, 1793399340, 1793399280, 1793399460, 1793399640, 1793399700, 1793399820, 1793399400, 1793399880, 1793399940, 1793399760, 1793399580, 1793400000, 1793400060, 1793400120, 1793400240, 1793400180, 1793400300, 1793400360, 1793400420, 1793400480, 1793400540, 1793400600, 1793400720, 1793400780, 1793400840, 1793400660, 1793400960, 1793401140, 1793401200, 1793401440, 1793401620, 1793401920, 1793401980, 1793401740, 1793402580, 1793402520, 1793402460, 1793402700, 1793402160, 1793402880, 1793402940, 1793402760, 1793403000, 1793403060, 1793402820, 1793403360, 1793403240, 1793403180, 1793403120, 1793403540, 1793403600, 1793403660, 1793403300, 1793403840, 1793404020, 1793404140, 1793404080, 1793404380, 1793404320, 1793404260, 1793404560, 1793404440, 1793404680, 1793404200, 1793404740, 1793404860, 1793404620, 1793404920, 1793404500, 1793404800, 1793405040, 1793405160, 1793405220, 1793405280, 1793405460, 1793405580, 1793405700, 1793405640, 1793405520, 1793405820, 1793405400, 1793405880, 1793406120, 1793406360, 1793406420, 1793406240, 1793406540, 1793406780, 1793406840, 1793407020, 1793406720, 1793407140, 1793407200, 1793411100, 1793411040, 1793411280, 1793411340, 1793411400, 1793411520, 1793411580, 1793411700, 1793411940, 1793411880, 1793411640, 1793412060, 1793412420, 1793412540, 1793412660, 1793412720, 1793412480, 1793412840, 1793412900, 1793413020, 1793413080, 1793413140, 1793412960, 1793413740, 1793413860, 1793413920, 1793413980, 1793414040, 1793414220, 1793413800, 1793414280, 1793414340, 1793414160, 1793414460, 1793414520, 1793414580, 1793414100, 1793414760, 1793414820, 1793414700, 1793414940, 1793414640, 1793415000, 1793414400, 1793415180, 1793415120, 1793415060, 1793415480, 1793415540, 1793415600, 1793415240, 1793449860, 1793449920, 1793449980, 1793450040, 1793450100, 1793450160, 1793450220, 1793450280, 1793450340, 1793450400, 1793450460, 1793459520, 1793459580, 1793459640, 1793459700, 1793459760, 1793459820, 1793459880, 1793459940, 1793460000, 1793460060, 1793460120, 1793460180, 1793460240, 1793460300, 1793460360, 1793460780, 1793460840, 1793460900, 1793460960, 1793461020, 1793461080, 1793461140, 1793461200, 1793461260, 1793461320, 1793461380, 1793461440, 1793461500, 1793461560, 1793461620, 1793461680, 1793461740, 1793461800, 1793560080, 1793560140, 1793560200, 1793560260, 1793560380, 1793560440, 1793560500, 1793560560, 1793560620, 1793560680, 1793560740, 1793560800, 1793560860, 1793560920, 1793560980, 1793561040, 1793561100, 1793561160, 1793561220, 1793561280, 1793561340, 1793561400, 1793562360, 1793562480, 1793562600, 1793562720, 1793562840, 1793562960, 1793563080, 1793563200, 1793563320, 1793563440, 1793563560, 1793563680, 1793563800, 1793563920, 1793625840, 1793626080, 1793626200, 1793626320, 1793626440, 1793626560, 1793626680, 1793626800, 1793626920, 1793627040, 1793627280, 1793627400, 1793627760, 1793627880, 1793628000, 1793628120, 1793629680, 1793629800, 1793629920, 1793630040, 1793630160, 1793630280, 1793630400, 1793630520, 1793630640, 1793630760, 1793630880, 1793631000, 1793631120, 1793631240, 1793631360, 1793638080, 1793638200, 1793638320, 1793638800, 1793638920, 1793639040, 1793639160, 1793639280, 1793639400, 1793639520, 1793639640, 1793639760, 1793639880, 1793640240, 1793640360, 1793640480, 1793640600, 1793640720, 1793644680, 1793644800, 1793644920, 1793645040, 1793645160, 1793645280, 1793645400, 1793645520, 1793645640, 1793710440, 1793710560, 1793710680, 1793710800, 1793710920, 1793711040, 1793711160, 1793711280, 1793711400, 1793713680, 1793713800, 1793713920, 1793714040, 1793714160, 1793714280, 1793714400, 1793714520, 1793714640, 1793714760, 1793714880, 1793715000, 1793735400, 1793735520, 1793735640, 1793735760, 1793735880, 1793736000, 1793736120, 1793736240, 1793736360, 1793736480, 1793736600, 1793736720, 1793736840, 1793736960, 1793737080, 1793737200, 1793737320, 1793737440, 1793737560, 1793737680, 1793737800, 1793737920, 1793738040, 1793738160, 1793804160, 1793804580, 1793804640, 1793804700, 1793804760, 1793804820, 1793804880, 1793805120, 1793805180, 1793805240, 1793805300, 1793805360, 1793805420, 1793805480, 1793805540, 1793805600, 1793805660, 1793805720, 1793805780, 1793805840, 1793805900, 1793806080, 1793806800, 1793806860, 1793806920, 1793806980, 1793807040, 1793807100, 1793807280, 1793807340, 1793807400, 1793807460, 1793807520, 1793807580, 1793807640, 1793807700, 1793807760, 1793807820, 1793808120, 1793808240, 1793808360, 1793808480, 1793808600, 1793808720, 1793808840, 1793808960, 1793809800, 1793809920, 1793810040, 1793810160, 1793810280, 1793810400, 1793810520, 1793810640, 1793810760, 1793810880, 1793811000, 1793811120, 1793811240, 1793837520, 1793837640, 1793837760, 1793837880, 1793838000, 1793838120, 1793838240, 1793838360, 1793838480, 1793838600, 1793839440, 1793839500, 1793839560, 1793839620, 1793839680, 1793839740, 1793839800, 1793839860, 1793889120, 1793889240, 1793889360, 1793889480, 1793889600, 1793889720, 1793889840, 1793889960, 1793890080, 1793890200, 1793890320, 1793890440, 1793890560, 1793890680, 1793890800, 1793890920, 1793891040, 1793978760, 1793978880, 1793979000, 1793979120, 1793979240, 1793979360, 1793979480, 1793979600, 1793979720, 1793979840, 1793979960, 1793980080, 1793980200, 1793980920, 1793981040, 1793981160, 1793981280, 1793981400, 1793981520, 1793981640, 1793981760, 1793981880, 1793982000, 1793982120, 1794066480, 1794066600, 1794066720, 1794066840, 1794066960, 1794067080, 1794067200, 1794067320, 1794067440, 1794067560, 1794067680, 1794067800, 1794067920, 1794068040, 1794068160, 1794068280, 1794068400, 1794068520, 1794068640, 1794068760, 1794068880, 1794069000, 1794069120, 1794069240, 1794069360, 1794069480, 1794069600, 1794069720, 1794069840, 1794069960, 1794070080, 1794070200, 1794070320, 1794070440, 1794070560, 1794070680, 1794075360, 1794075480, 1794075600, 1794075720, 1794075840, 1794075960, 1794076080, 1794076200, 1794076320, 1794076440, 1794076560, 1794076680, 1794076800, 1794076920, 1794077040, 1794077160, 1794077280, 1794077400, 1794077520, 1794077640, 1794077760, 1794077880, 1794078000, 1794078120, 1794078240, 1794078360, 1794078480, 1794078600, 1794078720, 1794078840, 1794078960, 1794079080, 1794079200, 1794079320, 1794079440, 1794079560, 1794079680, 1794079800, 1794079920, 1794080040, 1794080160, 1794096720, 1794096840, 1794097080, 1794096960, 1794097200, 1794097320, 1794097440, 1794097560, 1794097680, 1794097800, 1794097920, 1794098040, 1794098160, 1794098280, 1794098400, 1794098520, 1794098640, 1794098760, 1794098880, 1794099000, 1794099120, 1794099240, 1794099360, 1794099480, 1794099600, 1794099720, 1794099840, 1794099960, 1794100080, 1794100200, 1794100320, 1794100440, 1794100560, 1794100680, 1794100800, 1794100920, 1794101040, 1794101160, 1794101280, 1794166620, 1794166680, 1794166740, 1794166800, 1794166860, 1794168240, 1794168300, 1794168360, 1794168420, 1794168480, 1794168540, 1794168600, 1794168660, 1794168720, 1794168780, 1794168840, 1794168900, 1794168960, 1794169020, 1794169140, 1794169200, 1794169260, 1794169320, 1794169380, 1794169440, 1794169500, 1794169560, 1794169620, 1794169680, 1794169740, 1794169800, 1794169860, 1794169920, 1794169980, 1794170040, 1794170100], 'regla': 2, 'velas_tf': {'1': 20000, '2': 20000, '3': 20000, '4': 20000, '5': 20000}, 'hist_hecho': [1, 2, 3, 4, 5], 'total': 1784, 'activa': False, 'ev_prom': -0.02433978642975485, 'ultima_senal': 1794170239.7812493, 'tfs_entrenadas': [1, 2, 3, 4, 5], 'publicado': 1794233974}}
_CRIPTO = ("BTC", "ETH", "SOL", "XRP", "LTC", "DOT", "ADA", "CARDANO", "DOGE", "SHIB", "PEPE", "BONK", "TRON", "TRX",
           "SUI", "ARB", "HBAR", "FET", "ONDO", "TAO", "WIF", "WLD", "SEI", "JUP", "DYDX", "EOS", "DASH", "ATOM",
           "LUNA", "TRUMP", "RAYDIUM", "RENDER", "PENGU", "PEN", "SATS", "HYPE", "FARTCOIN", "MELANIA", "FLOKI",
           "LINK", "NEAR", "MATIC", "IMX", "INJ", "ORDI", "PYTH", "STX", "GRT", "SAND", "MANA", "ICP", "IOTA", "RONIN",
           "BCH", "LABUBU")
_DIVISAS = ("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "THB", "MXN", "BRL", "COP", "ZAR", "TRY", "INR",
            "IDR", "PHP", "PLN", "SGD", "HKD", "NOK", "SEK", "ARS", "CLP", "DOP", "BOB", "BDT", "NGN", "VND", "MYR",
            "AED", "SAR", "EGP", "PKR")


def ia_tipo_par(par):
    """(es_otc, es_divisa, es_cripto) a partir del nombre del par."""
    p = str(par).upper().replace("-OTC", "").replace("-OP", "")
    otc = "OTC" in str(par).upper()
    cripto = any(p.startswith(c) for c in _CRIPTO)
    divisa = (not cripto) and len(p) == 6 and p[:3] in _DIVISAS and p[3:] in _DIVISAS
    return otc, divisa, cripto


def _ia_lim(x, a=3.0):
    return a if x > a else (-a if x < -a else x)


def ia_rasgos(velas, par, pago, t, tf=1, digital=False, propio=(0.0, 0.0, 0.0, 0.0)):
    """Lo que 've' la IA autónoma: velas crudas y contexto. Nada de indicadores ni estrategias hechas.
    velas: dicts o,h,l,c (la última es la vela de señal). Devuelve IA_ENTRADAS números o None."""
    n = len(velas)
    if n < 40:
        return None
    c = [v["c"] for v in velas]
    tr = [max(velas[i]["h"], c[i - 1]) - min(velas[i]["l"], c[i - 1]) for i in range(n - 14, n)]
    atr = sum(tr) / 14.0                               # tamaño normal de una vela ahora (para comparar)
    if atr <= 0:
        atr = abs(c[-1]) * 1e-5 or 1e-9
    tr50 = [velas[i]["h"] - velas[i]["l"] for i in range(max(1, n - 50), n)]
    atr50 = (sum(tr50) / len(tr50)) or atr
    f = []
    for v in velas[-IA_VELAS_VE:]:                     # las últimas 20 velas tal cual: cuerpo y mechas
        f.append(_ia_lim((v["c"] - v["o"]) / atr))
        f.append(_ia_lim((v["h"] - max(v["o"], v["c"])) / atr))
        f.append(_ia_lim((min(v["o"], v["c"]) - v["l"]) / atr))
    f.append(_ia_lim((c[-1] - c[-4]) / atr / 2))      # cuánto se ha movido el precio (corto, medio, largo)
    f.append(_ia_lim((c[-1] - c[-11]) / atr / 3))
    f.append(_ia_lim((c[-1] - c[-31]) / atr / 5))
    alto = max(v["h"] for v in velas[-30:]); bajo = min(v["l"] for v in velas[-30:])
    f.append(_ia_lim(((c[-1] - bajo) / ((alto - bajo) or 1e-12)) * 2 - 1))   # dónde está dentro del rango reciente
    f.append(_ia_lim(atr / atr50 - 1.0))              # ¿más agitado o más quieto que de costumbre?
    h = (t % 86400) / 86400.0 * 2 * math.pi           # hora del día (UTC), día y fin de semana
    f.append(math.sin(h)); f.append(math.cos(h))
    dia = int(t // 86400 + 4) % 7                      # 0 = domingo
    f.append(math.sin(dia / 7 * 2 * math.pi)); f.append(math.cos(dia / 7 * 2 * math.pi))
    f.append(1.0 if dia in (0, 6) else 0.0)
    otc, divisa, cripto = ia_tipo_par(par)
    f.append(1.0 if otc else 0.0); f.append(1.0 if divisa else 0.0); f.append(1.0 if cripto else 0.0)
    f.append(1.0 if digital else 0.0)
    f.append((tf - 1) / 4.0)                           # temporalidad: 0 = M1 … 1 = M5
    f.append(_ia_lim(((pago or 0.85) - 0.85) * 10))    # payout del par
    f.extend(propio)                                   # cómo le viene yendo en ese par y en ese mercado a esa hora
    f.append(1.0)                                      # sesgo
    return f


class IARefuerzo:
    """Red pequeña que estima cuánto se gana por dólar con CALL y con PUT, y aprende en línea."""

    def __init__(self, ruta):
        self.ruta = ruta
        self.lock = threading.Lock()
        rnd = __import__("random").Random(7)
        e = 1.0 / math.sqrt(IA_ENTRADAS)
        self.w1 = [[rnd.uniform(-e, e) for _ in range(IA_ENTRADAS)] for _ in range(IA_OCULTAS)]
        self.w2 = [[rnd.uniform(-0.1, 0.1) for _ in range(IA_OCULTAS + 1)] for _ in range(2)]
        self.lr = 0.004
        self.aprendidas = 0                # ejemplos con los que ha aprendido
        self.preentreno = False            # ¿ya hizo el primer entrenamiento con el historial?
        self.tfs_entrenadas = []           # temporalidades con primer entrenamiento hecho
        self.velas_tf = {}                 # temporalidad -> velas M1 por par con las que se entrenó
        self.hist_hecho = []               # temporalidades ya entrenadas con el historial grande (20.000 velas)
        self.sombra = deque(maxlen=IA_SENALES_VENTANA)    # últimas señales evaluadas (True gana / False pierde)
        self.sombra_t = deque(maxlen=IA_SENALES_VENTANA)  # hora de cada una
        self.mejor = {}                                    # cierre -> (lo que esperaba, par, tf): la que cuenta ese minuto
        self.hist_par = {}                                 # par -> últimas 20 decisiones propias (gana / pierde)
        self.hist_ctx = {}                                 # mercado+hora -> últimas 50 decisiones propias
        self.total_senales = 0
        self.activa = False                # False = modo sombra · True = opera
        self.fase = "Esperando"
        self.base_publicado = 0            # de qué publicación del autor viene lo aprendido
        self.ev_prom = None                # lo que espera ganar por dólar en promedio (su mejor opción), últimos cierres
        self.ultima_senal = 0.0            # hora de su última señal
        self.senales_t = deque(maxlen=500) # horas de las señales (para "señales en la última hora")
        self.revisados = 0                 # pares revisados en el último cierre
        self._cierre = None
        self._cuenta = 0
        self.cargar()
        self.tomar_publicada()

    # --- red ---
    def _adelante(self, x):
        oc = []
        for fila in self.w1:
            s = 0.0
            for wi, xi in zip(fila, x):
                s += wi * xi
            oc.append(math.tanh(s))
        oc.append(1.0)
        q = [sum(w * o for w, o in zip(fila, oc)) for fila in self.w2]
        return oc, q

    def q(self, x):
        with self.lock:
            return self._adelante(x)[1]

    def aprender(self, x, r_call, r_put):
        """Un paso: acerca lo que espera ganar a lo que de verdad habría ganado con CALL y con PUT."""
        with self.lock:
            oc, q = self._adelante(x)
            errs = (q[0] - r_call, q[1] - r_put)
            lr = self.lr
            grad_oc = [0.0] * IA_OCULTAS
            for k in range(2):
                e = errs[k]
                fila = self.w2[k]
                for j in range(IA_OCULTAS):
                    grad_oc[j] += e * fila[j]
                for j in range(IA_OCULTAS + 1):
                    fila[j] -= lr * (e * oc[j] + 1e-4 * fila[j])
            for j in range(IA_OCULTAS):
                g = grad_oc[j] * (1 - oc[j] * oc[j])
                if g == 0.0:
                    continue
                fila = self.w1[j]
                for i in range(IA_ENTRADAS):
                    fila[i] -= lr * g * x[i]
            self.aprendidas += 1

    # --- modo sombra ---
    def anotar_senal(self, gano, cuando=None):
        """Una señal resuelta (máximo una por minuto). Se activa solo si el acierto está sobre el
        equilibrio con 95 % de seguridad, con 300 señales o más repartidas en al menos 2 horas."""
        with self.lock:
            self.sombra.append(bool(gano))
            self.sombra_t.append(float(cuando or time.time()))
            self.total_senales += 1
            r = self._medida()
            if not self.activa and r["listo"]:
                self.activa = True
                return "activa"
            ult = list(self.sombra)[-IA_SENALES_MIN:]
            if self.activa and len(ult) >= IA_SENALES_MIN and sum(ult) / len(ult) < IA_ACIERTO_APAGAR:
                self.activa = False
                return "sombra"
        return None

    def _medida(self):
        n = len(self.sombra)
        g = sum(self.sombra)
        horas = (self.sombra_t[-1] - self.sombra_t[0]) / 3600.0 if n > 1 else 0.0
        nec = ia_acierto_necesario(n)
        listo = n >= IA_SENALES_MIN and horas >= IA_HORAS_MIN and ia_limite_inferior(g, n) >= IA_EQUILIBRIO
        return {"n": n, "g": g, "horas": horas, "necesita": nec, "listo": listo}

    @staticmethod
    def _ctx(par, t):
        return ("otc" if "OTC" in str(par).upper() else "real") + str(int(t % 86400 // 3600))

    def propio(self, par, t):
        """Su propio historial: cómo le viene yendo en este par y en este mercado a esta hora."""
        hp = self.hist_par.get(par) or ()
        hc = self.hist_ctx.get(self._ctx(par, t)) or ()
        fp = (2 * sum(hp) - len(hp)) / len(hp) if hp else 0.0
        fc = (2 * sum(hc) - len(hc)) / len(hc) if hc else 0.0
        return (fp, len(hp) / 20.0, fc, len(hc) / 50.0)

    def registrar(self, par, t, gano):
        with self.lock:
            self.hist_par.setdefault(par, deque(maxlen=20)).append(bool(gano))
            self.hist_ctx.setdefault(self._ctx(par, t), deque(maxlen=50)).append(bool(gano))

    def mirar(self, cierre, q_mejor, senal):
        """Anota cada revisión (para mostrar qué opina del mercado aunque no marque señales)."""
        with self.lock:
            if cierre != self._cierre:
                if self._cierre is not None:
                    self.revisados = self._cuenta
                self._cierre, self._cuenta = cierre, 0
            self._cuenta += 1
            self.ev_prom = q_mejor if self.ev_prom is None else self.ev_prom * 0.998 + q_mejor * 0.002
            if senal:
                ahora = time.time()
                self.ultima_senal = ahora
                self.senales_t.append(ahora)

    def resumen(self):
        n = len(self.sombra)
        hora = time.time() - 3600
        m = self._medida()
        return {"activa": self.activa, "senales": n, "total": self.total_senales,
                "necesita": round(100 * m["necesita"], 1), "horas": round(m["horas"], 2), "horas_min": IA_HORAS_MIN,
                "acierto": round(100 * sum(self.sombra) / n, 1) if n else None,
                "necesarias": IA_SENALES_MIN, "aprendidas": self.aprendidas,
                "preentreno": self.preentreno, "fase": self.fase, "velas": max(self.velas_tf.values() or [0]),
                "ev": round(self.ev_prom * 100, 1) if self.ev_prom is not None else None,
                "revisados": self.revisados or self._cuenta,
                "ultima_senal": int(self.ultima_senal) or None,
                "senales_hora": sum(1 for t in self.senales_t if t >= hora)}

    def resumen_cliente(self):
        """Lo único que ve un cliente: si está lista y cuánto aprendió (sin cifras de sombra ni umbral)."""
        return {"cliente": True, "preentreno": self.preentreno, "aprendidas": self.aprendidas, "fase": self.fase}

    # --- guardar / cargar ---
    def guardar(self):
        with self.lock:
            d = {"v": IA_VERSION, "w1": self.w1, "w2": self.w2,
                 "hist_par": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_par.items()},
                 "hist_ctx": {k: "".join("1" if x else "0" for x in v) for k, v in self.hist_ctx.items()}, "aprendidas": self.aprendidas, "preentreno": self.preentreno,
                 "sombra": "".join("1" if x else "0" for x in self.sombra), "sombra_t": [int(t) for t in self.sombra_t],
                 "regla": 2, "velas_tf": {str(k): v for k, v in self.velas_tf.items()}, "hist_hecho": self.hist_hecho,
                 "total": self.total_senales,
                 "activa": self.activa, "base_publicado": self.base_publicado,
                 "ev_prom": self.ev_prom, "ultima_senal": self.ultima_senal, "tfs_entrenadas": self.tfs_entrenadas}
        tmp = self.ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh)
        os.replace(tmp, self.ruta)

    def cargar(self):
        try:
            with open(self.ruta, encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                self.total_senales = int(d.get("total", 0) or 0)
                return                                 # IA de otra versión: la autónoma aprende desde cero
            self.w1, self.w2 = d["w1"], d["w2"]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            if d.get("regla") == 2:                    # medición nueva: una por minuto, con su hora
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:                                      # la medición vieja se reinicia (contaba señales repetidas)
                self.activa = False
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = int(d.get("base_publicado", 0) or 0)
            vt = d.get("velas_tf")
            self.velas_tf = {int(k): int(v) for k, v in vt.items()} if isinstance(vt, dict) else (
                {1: 5000} if d.get("preentreno") else {})
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            self.ev_prom = d.get("ev_prom")
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.ultima_senal = float(d.get("ultima_senal") or 0)
        except Exception:
            pass

    def tomar_publicada(self):
        """Si la actualización trae una IA más nueva (entrenada en el PC del autor), se usa esa."""
        try:
            d = (IA_BASE or {}).get(BROKER) or {}
            if not d and (not self.aprendidas or self.base_publicado):
                d = (IA_BASE or {}).get("exnova") or {}     # IQ Option sin IA propia: arranca con lo aprendido en Exnova
            pub = int(d.get("publicado", 0) or 0)
            if not pub or pub <= self.base_publicado:
                return False
            if d.get("v") != IA_VERSION or len(d["w1"]) != IA_OCULTAS or len(d["w1"][0]) != IA_ENTRADAS:
                return False
            self.w1, self.w2 = d["w1"], d["w2"]
            self.aprendidas = int(d.get("aprendidas", 0))
            self.preentreno = bool(d.get("preentreno"))
            self.tfs_entrenadas = list(d.get("tfs_entrenadas") or ([1] if self.preentreno else []))
            self.sombra.clear(); self.sombra_t.clear()
            if d.get("regla") == 2:
                self.sombra.extend(ch == "1" for ch in d.get("sombra", ""))
                self.sombra_t.extend(float(t) for t in d.get("sombra_t", []))
                self.activa = bool(d.get("activa"))
            else:
                self.activa = False
            vt = d.get("velas_tf")
            if isinstance(vt, dict):
                self.velas_tf = {int(k): int(v) for k, v in vt.items()}
            self.hist_hecho = [int(x) for x in (d.get("hist_hecho") or [])]
            for k, v in (d.get("hist_par") or {}).items():
                self.hist_par[k] = deque((ch == "1" for ch in v), maxlen=20)
            for k, v in (d.get("hist_ctx") or {}).items():
                self.hist_ctx[k] = deque((ch == "1" for ch in v), maxlen=50)
            self.total_senales = int(d.get("total", 0))
            self.base_publicado = pub
            try:
                self.guardar()
            except Exception:
                pass
            return True
        except Exception:
            return False


def ia_estado_guardado(cliente=False):
    """Para la pantalla de Configuración (sin bot andando): el estado de la IA (resumido para el cliente)."""
    ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
    return ia.resumen_cliente() if cliente else ia.resumen()


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.tf_auto = False                         # una sola temporalidad
        self.tfs = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
        self.autor = False       # app_gui lo pone en True para las cuentas del autor (resumen semanal e IA)
        self.ia_cliente = False  # app_gui: cliente con la IA habilitada en la hoja (columna IA = SI)
        self.ia = None           # IA del autor (solo con estrategia "ia")
        self.ia_pend = {}        # (par, tf) -> decisiones por resolver cuando cierre la vela operada
        self.ia_cola = deque(maxlen=20000)     # ejemplos nuevos para aprender
        self.ia_repaso = deque(maxlen=20000)   # memoria de repaso (refuerzo con repetición de experiencias)
        self.ia_ev = {}                        # (par, tf) -> lo que la IA espera ganar por dólar en este cierre
        self.ia_prob = {}                      # (par, tf) -> probabilidad de acertar que calcula la IA en este cierre
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.animo_pend, self.animo_grabadas = [], {}       # filtro del autor (volatilidad): señales por resolver
        self.hist = {}           # (par, tf) -> velas
        # acierto "a la primera" de cada par (últimas señales de BB + RSI): manda en qué par se entra primero
        try:
            with open(_ruta_broker("racha_pares.json"), encoding="utf-8") as f:
                self.racha = {k: v for k, v in json.load(f).items() if isinstance(v, dict)}
        except Exception:
            self.racha = {}
        self.racha_t, self.racha_guardada = {}, time.time()
        self.niveles = {}        # par -> (hora en que se calcularon, [niveles de pivô, Fibo y S/R H1])
        self.hist_t = {}         # (par, tf) -> cuándo se bajó el historial completo
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.ultimo_cierre = 0.0
        self.perdidas_sueltas = []   # órdenes que el bot no pudo seguir: si el saldo muestra la pérdida, va a la recuperación
        self.seq = 0
        self.reconexiones = 0
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.pausado = False
        self.primeras = deque(maxlen=500)     # resultado de cada PRIMERA entrada de hoy (True/False) para "acierto de hoy"
        self.resultados = deque(maxlen=1000)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.ultima_entrada = None

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        msg = txt_broker(msg)
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- sesión en curso (al ir a Configuración se sigue con la misma sesión) ----------
    def estado_sesion(self):
        """Lo que sigue al cambiar la configuración sin salir del bot: P/L, ganadas/perdidas, resultados y la
        recuperación pendiente. Si ya se llegó al Stop Win o al Stop Loss, la sesión terminó: no sigue nada."""
        if self.stop_alcanzado():
            return None
        return {"cuenta": self.cuenta, "pnl": self.pnl, "stats": dict(self.stats), "nivel": self.nivel,
                "ciclo_perdida": self.ciclo_perdida, "ciclo_n": self.ciclo_n, "saldo_inicio": self.saldo_inicio,
                "curva": list(self.curva[-300:]), "resultados": list(self.resultados), "primeras": list(self.primeras)}

    def retomar_sesion(self, d):
        """Sigue la sesión que se pausó para cambiar la configuración (misma cuenta, sin cerrar sesión)."""
        if not d or d.get("cuenta") != self.cuenta:
            return False
        self.pnl = float(d.get("pnl") or 0.0)
        self.stats.update(d.get("stats") or {})
        self.nivel = min(int(d.get("nivel") or 0), int(self.cfg["rec_max"]))
        self.ciclo_perdida = float(d.get("ciclo_perdida") or 0.0)
        self.ciclo_n = int(d.get("ciclo_n") or 0)
        if isinstance(d.get("saldo_inicio"), (int, float)):
            self.saldo_inicio = d["saldo_inicio"]          # el P/L real se sigue midiendo desde el inicio de la sesión
        self.curva = list(d.get("curva") or []) or [(time.time(), self.pnl)]
        for r in reversed(d.get("resultados") or []):
            self.resultados.appendleft(r)
        self.primeras.extend(bool(x) for x in (d.get("primeras") or []))
        pend = f" · recuperación pendiente: ${self.ciclo_perdida:.2f} (nivel {self.nivel})" if self.ciclo_perdida > 0 else ""
        self.log(f"Se sigue la misma sesión con la configuración nueva: P/L {self.pnl:+.2f}{pend}.", "bold")
        return True

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más."""
        if self.stop_alcanzado():
            if not self.detener:
                self.detener = True
                self.avisar_stop()
            return True
        return self.detener

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que conviene operar ese par: binaria/turbo o digital, el que mejor pague
        entre los mercados elegidos. (None, None) si no se puede operar."""
        cfg = self.cfg
        tipo = "turbo" if tf <= 5 else "binary"
        opciones = []
        if (cfg["incluir_otc"] if es_otc else cfg["incluir_mercado_real"]) and pays.get(tipo) is not None:
            opciones.append((pays[tipo], tipo))
        if cfg.get("incluir_digital") and tf in (1, 5, 15) and pays.get("digital"):
            opciones.append((pays["digital"], "digital"))
        if not opciones:
            return None, None
        pago, t = max(opciones)
        return t, pago

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=bool(cfg.get("incluir_digital")))
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        if cfg.get("incluir_digital"):
            self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        return len(activos), len(lista)

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos y soltar los que salieron
            for par in list(self.seleccion):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                    self.recuperar_perdidas_sueltas(-dif)
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def recuperar_perdidas_sueltas(self, perdido):
        """El saldo bajó más de lo que el bot sabía y había órdenes que no pudo seguir (sin confirmar o sin resultado):
        esa pérdida se suma al ciclo de recuperación, así la siguiente operación es un NIVEL y no una entrada.
        Solo se usa con órdenes del bot (una operación hecha a mano no entra en la recuperación)."""
        ahora = time.time()
        if perdido <= 0:                      # el saldo subió: esas órdenes no se perdieron
            self.perdidas_sueltas = []
            return
        self.perdidas_sueltas = [x for x in self.perdidas_sueltas if ahora - x["t"] < 900]
        while self.perdidas_sueltas and perdido >= self.perdidas_sueltas[0]["monto"] - 0.05:
            x = self.perdidas_sueltas.pop(0)
            perdido -= x["monto"]
            if self.cfg["recuperacion"] == "ninguna":
                continue
            s = x["s"]
            if s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n:
                if self.nivel == 0:
                    self.nivel, self.ciclo_perdida = 1, round(x["monto"], 2)
            else:
                n = s.get("nivel_usado", 0) + 1
                ciclo = round(s.get("ciclo_antes", 0.0) + x["monto"], 2)
                if n > int(self.cfg["rec_max"]):
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                else:
                    self.nivel, self.ciclo_perdida = n, ciclo
            self.stats["perdidas"] += 1
            self.log(f"Orden sin confirmar de {x['s'].get('par')} (${x['monto']:.2f}) perdida según el saldo: "
                     f"se suma a la recuperación (nivel {self.nivel}).", "bold yellow")

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------


    def preparar(self, tfs_c, prox):
        """Durante la vela: baja el historial de cada par (la primera vez completo, después solo lo nuevo)
        y deja todo listo para el cierre. Primero los pares que más pagan. Si el bróker devuelve el número
        de pedido, lee hasta 3 pares a la vez (en un celular lento alcanzan más pares antes del cierre)."""
        limite = prox - self.adelanto_analisis() - 1.5
        pago = lambda p: (self.pares.get(p) or {}).get("payout") or 0
        tareas = [(par, tf) for par in sorted(list(self.seleccion), key=pago, reverse=True) for tf in tfs_c]
        if getattr(self.b, "_rid_ok", None) is not True:          # sin número de pedido: uno por uno, como antes
            for par, tf in tareas:
                if not self._preparar_uno(par, tf, prox, limite):
                    return
            return
        from concurrent.futures import ThreadPoolExecutor, wait
        if getattr(self, "_pool_prep", None) is None:
            self._pool_prep = ThreadPoolExecutor(max_workers=PREPARAR_A_LA_VEZ, thread_name_prefix="prep")
        futuros = [self._pool_prep.submit(self._preparar_uno, par, tf, prox, limite) for par, tf in tareas]
        wait(futuros, timeout=max(0.0, limite - self.b.ahora()) + 1.0)
        for f in futuros:
            f.cancel()                                             # lo que no alcanzó a empezar ya no se pide

    def _preparar_uno(self, par, tf, prox, limite):
        """Prepara un par en una temporalidad. Devuelve False si ya no hay tiempo (o se detuvo el bot)."""
        if self.detener or not self.b.conectado or self.b.ahora() > limite:
            return False
        if par in self.pares_en_uso:
            return True
        k = (par, tf)
        try:
            hist = self.hist.get(k) or []
            if not hist or time.time() - self.hist_t.get(k, 0) > 30 * tf * 60:
                self.fase = f"Leyendo {par} M{tf}"
                velas = self.b.velas(par, tf, HISTORIA_VELAS)
                if len(velas) < 30:
                    self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); return True
                self.hist[k] = velas
                self.hist_t[k] = time.time()
                if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                        and velas[-1]["t"] >= self.b.ahora() - 180):
                    try:
                        self.vivo_pend[par] = time.time()
                        if not self.b.suscribir_vivo(par, velas):
                            self.vivo_pend.pop(par, None)
                    except Exception:
                        self.vivo_pend.pop(par, None)
            elif hist[-1]["t"] < prox - 2 * tf * 60:
                nuevas = self.b.velas(par, tf, 4)
                por_t = {v["t"]: v for v in hist}
                for v in nuevas: por_t[v["t"]] = v
                self.hist[k] = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
            if self.autor and self.cfg.get("estrategia") == "bbrsi":      # en prueba: solo la cuenta del autor
                self.actualizar_niveles(par, limite)
            vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
            self.estado(par, f"Listo para el cierre M{tf} ({vivo})", "" if self.b.vivo.get(par) else "dim", 3)
        except Exception as e:
            self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)
        return True

    # ---------- prioridad: el par que más gana a la primera ----------
    def actualizar_racha(self, par, tf, cerradas):
        """Suma las señales nuevas del par (ya resueltas por la vela siguiente) a su historial de aciertos."""
        k = (par, tf)
        if len(cerradas) < 2 or self.racha_t.get(k) == cerradas[-2]["t"]:
            return
        try:
            nuevos = resultados_bbrsi(cerradas, tf, self.racha_t.get(k, 0))
            self.racha_t[k] = cerradas[-2]["t"]
            if nuevos:
                d = self.racha.setdefault(f"{par}|{tf}", {})
                for t, g in nuevos.items():
                    d[str(t)] = bool(g)
                if len(d) > 2 * RACHA_N:
                    for t in sorted(d, key=int)[:-2 * RACHA_N]:
                        del d[t]
            if time.time() - self.racha_guardada > 300:
                self.guardar_racha()
        except Exception:
            pass

    def actualizar_niveles(self, par, limite):
        """Una vez por hora y por par: velas D1 y H1 para los niveles (pivô, Fibo, S/R). Solo con tiempo de sobra
        antes del cierre; si el bróker no las da, el par sigue sin niveles (opera igual)."""
        hora = int(self.b.ahora() // 3600)
        if self.niveles.get(par, (None,))[0] == hora or self.b.ahora() > limite - 4:
            return
        self.niveles[par] = (hora, self.niveles.get(par, (0, []))[1])      # no reintentar en la misma hora
        try:
            aid = self.b._id(par)
            if aid is None:
                return
            dias = self.b._pedir_velas(aid, 86400, 3, time.time()) or []
            horas = self.b._pedir_velas(aid, 3600, 60, time.time()) or []
            self.niveles[par] = (hora, niveles_de(dias, horas, self.b.ahora()))
        except Exception:
            pass

    def es_clara(self, c):
        a = (c.get("racha") or (None,))[0]
        return (c.get("tf") in CLARA_TFS and c.get("adx") is not None and c["adx"] < CLARA_ADX
                and a is not None and a >= CLARA_ACIERTO)

    def acierto_par(self, par, tf):
        """(acierto de sus últimas señales a la primera, cuántas). Acierto None si aún tiene pocas."""
        if self.cfg.get("estrategia") == "ia" and self.ia is not None:
            # con la estrategia IA cuenta el acierto a la primera de la PROPIA IA en ese par (sus últimas 20 señales)
            with self.ia.lock:
                u = list(self.ia.hist_par.get(par) or ())[-RACHA_N:]
            return (sum(u) / len(u) if len(u) >= RACHA_MIN else None), len(u)
        d = self.racha.get(f"{par}|{tf}") or {}
        u = [d[t] for t in sorted(d, key=int)[-RACHA_N:]]
        return (sum(u) / len(u) if len(u) >= RACHA_MIN else None), len(u)

    def guardar_racha(self):
        self.racha_guardada = time.time()
        try:
            ruta = _ruta_broker("racha_pares.json")
            with open(ruta + ".tmp", "w", encoding="utf-8") as f:
                json.dump(self.racha, f)
            os.replace(ruta + ".tmp", ruta)
        except Exception:
            pass

    # ---------- filtro del autor: volatilidad (cada señal se graba para medirla) ----------
    def filtros_autor(self):
        return bool(self.autor)

    @staticmethod
    def volatilidad(cerradas):
        """Tamaño de las últimas 3 velas comparado con lo normal del par (mediana de las 50 anteriores). 1 = normal."""
        rangos = [v["h"] - v["l"] for v in cerradas[-53:]]
        if len(rangos) < 20:
            return None
        base = sorted(rangos[:-3])[len(rangos[:-3]) // 2]
        if base <= 0:
            return None
        return (sum(rangos[-3:]) / 3) / base

    def filtrar_autor(self, par, tf, d, cerradas, precio, expira, origen):
        """Devuelve (pasa, motivo). Graba cada señal, entre o no, para medir después si los filtros ayudan."""
        if not self.filtros_autor():
            return True, ""
        # ya no se descartan las velas agitadas (en el historial eran las que MEJOR salían): solo se graba
        self.grabar_senal(par, tf, d, cerradas, precio, expira, origen, vol=self.volatilidad(cerradas), pasa=True)
        return True, ""

    def grabar_senal(self, par, tf, d, cerradas, precio, expira, origen, prob=None, vol=None, pasa=True):
        """Anota la señal (una vez) para ver después cómo terminó el precio: así se mide si los filtros sirven."""
        if not self.filtros_autor():
            return
        clave = (par, tf, int(expira))
        if clave in self.animo_grabadas:
            return
        self.animo_grabadas[clave] = True
        if vol is None:
            vol = self.volatilidad(cerradas)
        self.animo_pend.append({"t": int(self.b.ahora()), "par": par, "tf": tf, "dir": d, "origen": origen, "vol": vol,
                                "prob": prob, "pasa": pasa, "precio": precio, "expira": int(expira)})
        if len(self.animo_grabadas) > 5000:
            self.animo_grabadas.clear()

    def hilo_animo(self):
        """Cuando vence cada señal grabada, mira cómo terminó el precio y lo guarda en senales_datos.csv."""
        ruta = os.path.join(os.path.dirname(os.path.abspath(LOG_FILE)), "senales_datos.csv")
        while not self.detener and not self.terminado:
            time.sleep(3)
            if not self.animo_pend:
                continue
            try:
                ahora = self.b.ahora()
                listas = [r for r in self.animo_pend if ahora >= r["expira"] + 2]
                if not listas:
                    continue
                filas = []
                for r in listas:
                    self.animo_pend.remove(r)
                    m1 = {v["t"]: v for v in (self.b.velas_vivo(r["par"]) or [])}
                    v = m1.get(r["expira"] - 60)
                    if v is None:
                        continue
                    fin = float(v["c"])
                    res = "empate" if fin == r["precio"] else (
                        "gana" if (fin > r["precio"]) == (r["dir"] == "call") else "pierde")
                    filas.append([datetime.fromtimestamp(r["t"]).strftime("%Y-%m-%d %H:%M:%S"), r["par"],
                                  "OTC" if r["par"].endswith("-OTC") else "real", f"M{r['tf']}", r["dir"], r["origen"],
                                  "" if r["vol"] is None else round(r["vol"], 2),
                                  "" if r.get("prob") is None else round(r["prob"] * 100, 1),
                                  "si" if r["pasa"] else "no", r["precio"], fin, res])
                if filas:
                    if os.path.exists(ruta):                        # archivo de una versión anterior (otras columnas):
                        with open(ruta, encoding="utf-8") as f:     # se guarda aparte y se empieza uno nuevo
                            cab = f.readline()
                        if "prob_ia" not in cab:
                            viejo = ruta.replace(".csv", "_viejo.csv")
                            if os.path.exists(viejo):
                                viejo = ruta.replace(".csv", f"_viejo_{int(time.time())}.csv")
                            os.replace(ruta, viejo)
                    nuevo = not os.path.exists(ruta)
                    with open(ruta, "a", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        if nuevo:
                            w.writerow(["fecha", "par", "mercado", "tf", "direccion", "estrategia", "volatilidad", "prob_ia", "pasa_filtro", "precio_entrada", "precio_vence", "resultado"])
                        w.writerows(filas)
            except Exception:
                with open(ERROR_LOG, "a", encoding="utf-8") as f:
                    f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] senales\n{traceback.format_exc()}")

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}


    def puntos(self, prox):
        """Temporalidades cuya vela cierra en este minuto."""
        return [tf for tf in self.tfs if prox % (tf * 60) == 0 and expiracion_valida(tf, prox + tf * 60, prox - 1)]

    def analizar(self, tfs_c, prox):
        """1,2 s antes del cierre: la señal de la estrategia con la vela que está cerrando."""
        cfg = self.cfg
        cands, revisados = [], 0
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        nombre = nombre_estrategia(cfg, self.autor)
        for par in list(self.seleccion):
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.hist:
                    continue
                actual = self.vela_en_formacion(m1, tf, prox)
                if not actual:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                inicio = actual["t"]
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v
                    cerradas = [por_t[t] for t in sorted(por_t)][-HISTORIA_VELAS:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < inicio]
                if not cerradas or cerradas[-1]["t"] != inicio - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.hist.pop(k, None)
                    continue
                revisados += 1
                self.actualizar_racha(par, tf, cerradas)
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                if cfg.get("estrategia") == "ia":
                    d, det = self.ia_analizar(par, tf, cerradas, actual, pago, prox, inst)
                else:
                    d, det = senal([v["c"] for v in cerradas] + [actual["c"]], cfg)
                    if self.ia is not None:
                        d, det = self.ia_filtrar(par, tf, cerradas, actual, pago, prox, d, det, inst)
                if not d:
                    self.estado(par, f"M{tf} sin señal", "dim", 3); continue
                p_min = cfg["payout_minimo"]
                if pago is not None and pago < p_min:
                    self.estado(par, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {p_min*100:.0f}%)", "dim", 3)
                    continue
                pasa, motivo = self.filtrar_autor(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, cfg.get("estrategia"))
                if not pasa:
                    self.estado(par, f"M{tf}: señal {d.upper()}, pero {motivo}", "dim", 3); continue
                cands.append({"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": nombre, "detalle": det,
                              "ev": self.ia_ev.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "prob": self.ia_prob.get((par, tf)) if cfg.get("estrategia") == "ia" else None,
                              "mercado": mercado_de(par), "inicio_vela": prox, "inst": inst,
                              "adx": adx_ultimo(cerradas + [actual]) if tf in CLARA_TFS else None,
                              "en_nivel": self.autor and cfg.get("estrategia") == "bbrsi" and rechaza_nivel(actual, d, self.niveles.get(par, (0, []))[1])})
                self.estado(par, f"SEÑAL {d.upper()} M{tf} · {det}", "bold green" if d == "call" else "bold red", 1)
        return cands, revisados

    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))





    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))


    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]


    def disparar(self, cands, prox):
        """Elige UNA operación por cierre de vela (primero la que más paga).
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: espera el RESULTADO REAL (≈1 s después del cierre) y decide:
          si perdió, el NIVEL entra con la siguiente señal en OTRO par; si ganó, entrada normal."""
        # entre las señales del mismo momento (todas ya pasaron el mínimo de 80 %), primero el PAR QUE MÁS GANA
        # A LA PRIMERA (sus últimas señales); un par con pocas señales cuenta como 50 %. Luego desempata:
        for c in cands:
            c["racha"] = self.acierto_par(c["par"], c["tf"])
        r = lambda c: c["racha"][0] if c["racha"][0] is not None else 0.5
        if self.ia_exigencia()[0] and self.cfg.get("estrategia") == "ia":
            # IA "señal más segura": luego la que la IA ve más probable; el payout al final
            cands = sorted(cands, key=lambda c: (r(c), c.get("prob") or 0.0, round(c.get("payout") or 0.0, 3)), reverse=True)
        else:
            cands = sorted(cands, key=lambda c: (r(c), round(c.get("payout") or 0.0, 3), c.get("ev") if c.get("ev") is not None else -9.0), reverse=True)
        en_vuelo = set(self.pares_en_uso) - {o["par"] for o in list(self.abiertas.values())}
        if en_vuelo:
            return                                         # una orden va en camino: una a la vez
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence:
            o = vence[0]
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o, "cands": list(cands)}
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        if self.frenar_por_stop() or self.pausado:
            return
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        etiqueta = "ENTRADA"
        if recuperando:
            # NIVEL: con la siguiente señal de la estrategia, en OTRO par (sin gale ni cambio de dirección)
            evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
            otros = [c for c in lista if c["par"] not in evitar]
            if plan and plan.get("perdio"):
                self.log(f"⇄ {o['par']}: perdió → NIVEL {nivel} con la siguiente señal en otro par.", "cyan")
            etiqueta = f"NIVEL {nivel}"
        else:
            otros = lista
        # entradas y recuperaciones, en cada cierre: 1) la señal que rebota en un NIVEL (pivô, Fibo o S/R H1),
        # 2) una señal CLARA, 3) la del par con mejor acierto a la primera
        en_nivel = [c for c in otros if c.get("en_nivel")]
        claras = [c for c in otros if self.es_clara(c)]
        if en_nivel:
            elegida = en_nivel[0]
            elegida["detalle"] = (elegida.get("detalle") or "") + " · rebote en nivel"
        elif claras:
            elegida = claras[0]
            elegida["detalle"] = (elegida.get("detalle") or "") + " · señal clara"
        else:
            elegida = otros[0] if otros else None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        self.lanzar(elegida)

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s.get("expira") or (s["inicio_vela"] + tf * 60)
            exp_min = s.get("exp_min") or tf
            precio_envio = self.precio_actual(par)
            rescatada = False
            try:
                try:
                    if s.get("inst") == "digital":
                        oid = self.b.comprar_digital(monto, par, d, tf, expira)
                    else:
                        oid = self.b.comprar(monto, par, d, exp_min, expira)
                except OrdenSinConfirmar as e_sc:
                    # mala conexión: la respuesta puede llegar tarde, pero la orden sí quedó abierta en IQ Option.
                    # Se sigue buscando (respuesta tardía o historial) sin abrir otra operación mientras tanto.
                    self.log(f"{par}: IQ Option no confirmó la orden a tiempo; se sigue buscando...", "bold yellow")
                    oid = None
                    if hasattr(self.b, "rescatar_orden"):
                        oid = self.b.rescatar_orden(e_sc, time.time() + max(0.0, expira - self.b.ahora()) + 45)
                    if not oid:
                        raise
                    rescatada = True
                    self.log(f"{par}: la orden sí se abrió en IQ Option (n.º {oid}); se sigue normal.", "bold yellow")
            except Exception as e:
                if isinstance(e, OrdenSinConfirmar):
                    self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden y no aparece en el historial; revísala en la plataforma. "
                             f"Si el saldo muestra que se perdió, se suma a la recuperación.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = precio_envio if rescatada else self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "detalle": s.get("detalle", ""),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst"), "t_vela": s.get("inicio_vela")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
            try:     # las 45 velas anteriores de su temporalidad, para el gráfico de la operación (solo velas, como el broker)
                prev = self.velas_hasta(par, tf, s["inicio_vela"])[-45:]
                self.abiertas[clave]["previas"] = [[round(v["o"], 6), round(v["h"], 6), round(v["l"], 6), round(v["c"], 6)]
                                                   for v in prev]
            except Exception:
                pass
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · "
                     f"{s['estrategia']} · " + (f"{s['detalle']} · " if s.get('detalle') else "") +
                     (f"par {s['racha'][0]*100:.0f}% a la primera ({s['racha'][1]} señales) · " if (s.get('racha') or (None,))[0] is not None else "") +
                     f"payout {s['payout']*100:.0f}% · vence {datetime.fromtimestamp(expira):%H:%M}", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.perdidas_sueltas.append({"monto": monto, "s": dict(s), "t": time.time()})
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real (si perdió, se suma a la recuperación).", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and etiqueta == "ENTRADA":
                self.primeras.append(res > 0)                  # "acierto de hoy" (solo primeras entradas)
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
            if getattr(self, "autor", False):
                threading.Thread(target=reportar_operacion, daemon=True,
                                 args=(self.b, self.cuenta, par, tf, tag, res, self.cfg.get("email", ""))).start()
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.avisar_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = self.puntos(prox)
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    cands, revisados = self.analizar(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, prox)
                    self.fase = "En pausa: analiza pero no abre operaciones" if self.pausado else "Esperando el cierre de vela"
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.guardar_racha()
            self.fase = "Detenido"
            self.terminado = True

    # ---------- pantalla ----------
    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        self.log(f"Estrategia: {nombre_estrategia(self.cfg, self.autor)} · "
                 f"{', '.join('M%d' % t for t in self.tfs)}", "bold")
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios, self.hilo_animo):
            threading.Thread(target=objetivo, daemon=True).start()
        if self.autor or (self.ia_cliente and self.cfg.get("estrategia") == "ia"):
            threading.Thread(target=self.hilo_ia, daemon=True).start()      # autor: aprende siempre · cliente: solo con IA

    # ---------- IA del autor (refuerzo en línea) ----------
    def ia_segundos(self):
        """(segundos desde el último cierre, segundos hasta el próximo) de la temporalidad elegida."""
        per = (min(self.tfs) if self.tfs else 1) * 60
        t = self.b.ahora() % per
        return t, per - t

    @staticmethod
    def ia_recompensas(mov, pago):
        """(premio CALL, premio PUT) por dólar según cómo se movió la vela operada."""
        if mov > 0:
            return pago, -1.0
        if mov < 0:
            return -1.0, pago
        return 0.0, 0.0

    def ia_pago(self, par):
        pays = (self.pares.get(par, {}) or {}).get("pays") or {}
        vals = [v for v in pays.values() if isinstance(v, (int, float)) and v > 0]
        return max(vals) if vals else 0.85

    def hilo_ia(self):
        try:
            self.ia = IARefuerzo(os.path.join(DATOS_BROKER, IA_ARCHIVO))
        except Exception as e:
            self.log(f"🤖 IA: no se pudo iniciar ({e}).", "red")
            return
        ia = self.ia
        estado = "opera" if ia.activa else "modo sombra"
        self.log(f"🤖 IA lista ({estado} · {ia.aprendidas:,} ejemplos aprendidos).", "bold")
        # ya no se descargan ni guardan velas: la IA llega entrenada con la actualización y aprende en vivo
        ia.fase = "Aprendiendo en vivo"
        rnd = __import__("random").Random()
        guardado = time.time()
        while not self.terminado:
            hechos = 0
            while self.ia_cola and hechos < 300:
                desde, hasta = self.ia_segundos()
                if hasta < 8 or desde < 4:
                    break
                x, rc, rp = self.ia_cola.popleft()
                ia.aprender(x, rc, rp)
                self.ia_repaso.append((x, rc, rp))
                if len(self.ia_repaso) > 200:                 # repasa una experiencia vieja al azar
                    ia.aprender(*self.ia_repaso[rnd.randrange(len(self.ia_repaso))])
                hechos += 1
            if time.time() - guardado > 300:
                try: ia.guardar()
                except Exception: pass
                guardado = time.time()
            time.sleep(0.2 if hechos else 1.0)
        try: ia.guardar()
        except Exception: pass

    def ia_procesar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """En cada cierre: resuelve lo pendiente (aprende de lo que pasó) y da la opinión de la IA.
        Devuelve (dirección de la IA o None, lo que espera ganar, [espera con CALL, espera con PUT])."""
        ia = self.ia
        pago = pago or self.ia_pago(par)
        pend = self.ia_pend.setdefault((par, tf), deque(maxlen=3))
        if pend:
            por_t = {v["t"]: v for v in cerradas[-4:]}
            for p_ in list(pend):
                v = por_t.get(p_["t_op"])
                if v is None:
                    continue
                pend.remove(p_)
                mov = v["c"] - p_["precio"]
                self.ia_cola.append((p_["x"],) + self.ia_recompensas(mov, p_["pago"]))
                if p_["d"] and mov != 0:
                    ia.registrar(par, p_["t_op"], (mov > 0) == (p_["d"] == "call"))
                m_ = ia.mejor.get(p_["t_op"])
                if p_["d"] and mov != 0 and m_ and m_[1] == par and m_[2] == tf:     # una sola por minuto
                    cambio = ia.anotar_senal((mov > 0) == (p_["d"] == "call"), p_["t_op"])
                    r = ia.resumen()
                    if cambio == "activa":
                        self.log(f"🤖 IA: acierto real {r['acierto']} % en {r['senales']} señales y {r['horas']:.1f} h "
                                 f"(necesitaba {r['necesita']} %) → "
                                 + ("EMPIEZA A OPERAR." if self.cfg.get("estrategia") == "ia" else "ya podría operar con la estrategia IA."), "bold green")
                    elif cambio == "sombra":
                        self.log(f"🤖 IA: el acierto bajó a {r['acierto']} % → vuelve a modo sombra.", "bold yellow")
        x = ia_rasgos(cerradas[-59:] + [actual], par, pago, prox, tf, inst == "digital", ia.propio(par, prox))
        if x is None:
            return None, 0.0, None
        q = ia.q(x)
        k = 0 if q[0] >= q[1] else 1
        d = ("call" if k == 0 else "put") if q[k] >= IA_UMBRAL else None
        ia.mirar(prox, q[k], d)
        if d:
            with ia.lock:
                if q[k] > ia.mejor.get(prox, (-9.0,))[0]:
                    ia.mejor[prox] = (q[k], par, tf)
                if len(ia.mejor) > 30:
                    for k_ in sorted(ia.mejor)[:-10]:
                        ia.mejor.pop(k_, None)
        pend.append({"x": x, "precio": actual["c"], "t_op": prox, "pago": pago, "d": d})
        return d, q[k], q

    def ia_analizar(self, par, tf, cerradas, actual, pago, prox, inst=None):
        """Estrategia IA: la decisión es de la IA. En modo sombra no opera."""
        if self.ia is None:
            return None, ""
        d, ev, _ = self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        self.ia_ev[(par, tf)] = ev
        if not d:
            return None, ""
        prob = ia_probabilidad(ev, pago)                          # qué tan probable cree que gane (sin el payout)
        self.ia_prob[(par, tf)] = prob
        segura, minimo = self.ia_exigencia()
        self.grabar_senal(par, tf, d, cerradas + [actual], actual["c"], prox + tf * 60, "ia",
                          prob=prob, pasa=(prob >= minimo) if segura else True)
        det = f"IA {prob * 100:.0f}% de acierto"
        if not self.autor and not ia_permitida():                        # el autor le quitó la IA a este cliente
            self.estado(par, "IA no habilitada para esta licencia", "dim", 3)
            return None, ""
        forzar = bool(self.cfg.get("ia_forzar")) and (self.autor or self.ia_cliente)   # opera sin el umbral
        if not (self.ia.activa or forzar):                                               # en sombra: no opera
            self.estado(par, f"IA (sombra) {d.upper()} M{tf} · {det}", "yellow", 2)
            return None, ""
        if segura and prob < minimo:                              # no es de las seguras: espera otra (entrada o nivel)
            self.estado(par, f"IA {d.upper()} M{tf} · {prob * 100:.0f}%: espera una más segura ({minimo * 100:.0f}%)", "dim", 3)
            return None, ""
        return d, det

    def ia_exigencia(self):
        """(¿solo la señal más segura?, mínimo de acierto). Autor: lo que elija. Clientes con IA: siempre 60 %."""
        if self.autor:
            return self.cfg.get("ia_modo") == "segura", ia_minimo(self.cfg)
        return bool(self.ia_cliente), IA_PROB_CLIENTES

    def ia_filtrar(self, par, tf, cerradas, actual, pago, prox, d, det, inst=None):
        """Bollinger/RSI del autor: la IA solo aprende en segundo plano. NO decide ni bloquea ninguna señal."""
        try:
            self.ia_procesar(par, tf, cerradas, actual, pago, prox, inst)
        except Exception:
            pass
        return d, det

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = max(o["tf"] * 60, o["vence"] - o["t0"])
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                tk = [p for _, p in list(o["ticks"])]
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO,
                        "previas": o.get("previas") or [],
                        "vela": [tk[0], max(tk), min(tk), tk[-1]] if tk else None}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "detalle": o.get("detalle", ""),
                             "vivo": vivo, "payout": o.get("payout"),
                             "previas": o.get("previas") or [], "t_vela": o.get("t_vela"), "vence": o.get("vence"),
                             "t0": o.get("t0")})
        return {      # solo lo que muestra la pantalla (se pide cada segundo: mientras menos, más liviano)
            "cuenta": self.cuenta, "saldo": self.saldo_actual,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error, "pnl": self.pnl,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"],
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "reconexiones": self.reconexiones, "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "hora_server": round(self.b.ahora(), 2),
            "vigilando": len(getattr(self, "seleccion", []) or []), "tf_auto": bool(self.tf_auto),
            "tfs": [f"M{t}" for t in self.tfs],
            "estrategia": {"nombre": nombre_estrategia(cfg, self.autor), "tipo": cfg.get("estrategia", "bollinger")},
            "acierto_hoy": {"ganadas": sum(1 for x in self.primeras if x), "total": len(self.primeras),
                            "ultimas": [bool(x) for x in list(self.primeras)[-10:]]},
            "resumen": self.resumen_dia(),
            "ia": (dict(self.ia.resumen(), forzar=bool(cfg.get("ia_forzar")) and self.autor) if self.autor
                   else self.ia.resumen_cliente()) if self.ia else None,
            "ia_cliente": self.ia_cliente,
        }

    def resumen_dia(self):
        """Resumen de la sesión para el panel del PC: operaciones, ganadas/perdidas, ciclos recuperados,
        nivel más alto usado y mejor racha de ganadas seguidas."""
        ops = gan = per = ciclos = recup = nivel_max = racha = mejor = 0
        ent_g = ent_p = niv_g = niv_p = 0
        abierto = False
        for r in reversed(list(self.resultados)):          # en orden de tiempo
            neto = float(r.get("neto") or 0)
            tipo = str(r.get("tipo") or "ENTRADA").upper()
            ops += 1
            if neto > 0:
                gan += 1; racha += 1; mejor = max(mejor, racha)
            elif neto < 0:
                per += 1; racha = 0
            if tipo.startswith("NIVEL"):
                niv_g += neto > 0; niv_p += neto < 0
                try: nivel_max = max(nivel_max, int(tipo.split()[-1]))
                except Exception: pass
                if neto > 0 and abierto:
                    recup += 1; abierto = False
            else:
                ent_g += neto > 0; ent_p += neto < 0
                if abierto:
                    abierto = False                          # el ciclo anterior se cerró sin recuperar
                if neto < 0:
                    ciclos += 1; abierto = True
        return {"ops": ops, "ganadas": gan, "perdidas": per, "ciclos": ciclos - (1 if abierto else 0),
                "recuperados": recup, "pendiente": abierto, "nivel_max": nivel_max, "mejor_racha": mejor,
                "ent_g": ent_g, "ent_p": ent_p, "niv_g": niv_g, "niv_p": niv_p}


OBSOLETAS = ("martingala_max_gales", "martingala_factor", "niveles_montos", "filtro_reciente", "ciclo_reciente",
             "pausa_tras_perdida", "winrate_minimo", "min_senales_catalogo", "velas_catalogo", "ev_minimo",
             "confluencia_minima", "filtros_v", "tf_auto_build", "ia_filtra", "ia_precision_alta", "solo_velas_fuertes",
             "estrategias_auto", "estrategias_activas", "solo_horas_buenas")


PAGO_MINIMO = 0.80        # fijo en el código: solo entra en pares que paguen 80 % o más
ANTICIPO_MS = 300         # fijo en el código: la orden se envía 300 ms antes del cierre de la vela


def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if int(guardado.get("config_v", 0) or 0) < 3:
                # 3.0: estrategia única. Se arranca con Bollinger, temporalidad Auto y todos los mercados.
                for k in ("estrategia", "tf_auto", "temporalidades", "incluir_otc", "incluir_mercado_real",
                          "incluir_digital"):
                    guardado.pop(k, None)
                guardado["rec_max"] = max(1, min(6, int(guardado.get("rec_max") or 2)))
                guardado["config_v"] = 3
            if int(guardado.get("config_v", 0) or 0) < 4:
                guardado["rsi_direccion"] = "normal"            # el RSI arranca en dirección normal
                guardado["config_v"] = 4
            if int(guardado.get("config_v", 0) or 0) < 5:
                # una sola temporalidad: quien tenía Auto o varias arranca en 1 minuto
                tfs = guardado.get("temporalidades") or []
                if guardado.get("tf_auto", True) or len(tfs) != 1:
                    guardado["temporalidades"] = [1]
                guardado["config_v"] = 5
            if int(guardado.get("config_v", 0) or 0) < 6:
                # M1 ya no se opera: quien estaba en M1 pasa a M2
                tfs = [int(t) for t in (guardado.get("temporalidades") or []) if int(t) in (2, 3, 4, 5)]
                guardado["temporalidades"] = tfs[:1] or [2]
                guardado["config_v"] = 6
            for k in OBSOLETAS:
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    cfg["recuperacion"] = "auto"                 # niveles con la siguiente señal
    cfg["max_pares"] = MAX_PARES                 # siempre todos los pares
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES})[:1] or [2]
    except Exception:
        cfg["temporalidades"] = [1]
    cfg["tf_auto"] = False                       # ya no hay temporalidad Auto
    cfg.pop("tfs_auto", None)
    cfg["payout_minimo"] = PAGO_MINIMO           # fijo: solo pares que paguen 80 % o más
    cfg["anticipo_ms"] = ANTICIPO_MS             # fijo: la orden sale 300 ms antes del cierre
    if cfg.get("estrategia") not in ("ia", "bbrsi"):
        cfg["estrategia"] = "bbrsi"                # Bollinger y RSI por separado ya no existen: quedan juntos
    return cfg

VIEJOS_ARCHIVOS = ("ia_ls.json", "ia_muestras.jsonl", "ia_equipo.json", "ia_red.json", "ia_red_real.json",
                   "ia_red_senales.json", "ia_arboles.json", "ia_modelos.json", "estrategias_en_prueba.json",
                   "estrategias_titulares.json", "rendimiento_vivo.json", "sombra_catalogo.json", "filtros.json",
                   "preparacion.json", "bloqueadas.csv", ".traido")
VIEJAS_CARPETAS = ("memoria_velas", "dataset_velas")


def limpiar_viejos(autor=False):
    """3.0: borra lo que dejaron las versiones anteriores (IAs, memoria de velas, catálogo) y ya no se usa.
    En el equipo del autor se conservan las velas guardadas (sirven para estudiar estrategias)."""
    import shutil
    time.sleep(90)                                # después de arrancar, sin estorbar el inicio
    for base in {DATOS, DATOS_BROKER, os.path.join(DATOS, "exnova")}:
        if not os.path.isdir(base):
            continue
        for n in VIEJOS_ARCHIVOS:
            try:
                if os.path.isfile(os.path.join(base, n)):
                    os.remove(os.path.join(base, n))
            except Exception:
                pass
        if not autor:
            for n in VIEJAS_CARPETAS:
                shutil.rmtree(os.path.join(base, n), ignore_errors=True)
        shutil.rmtree(os.path.join(base, "ia_velas"), ignore_errors=True)   # la IA ya no guarda velas: aprende en vivo


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = "Nivel"
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

