# -*- coding: utf-8 -*-
"""
IQ BOT ESCANER  -  Opciones binarias / turbo en IQ Option
=========================================================
Orden de arranque:
  1) Instala solo las librerías que falten (la primera vez).
  2) Inicia sesión con tu correo y contraseña (y código SMS si tu cuenta lo pide).
  3) Eliges cuenta DEMO o REAL (te muestra el saldo de las dos).
  4) Configuras monto, temporalidades, recuperación, stops y estrategias.
  5) Confirmas y arranca.

Qué hace:
- Escanea todos los pares abiertos (mercado real y OTC) en M1, M2, M5 y M15.
- Cataloga cada estrategia en cada par y elige la mejor por valor esperado.
- Varias operaciones al mismo tiempo (nunca dos en el mismo par).
- Recuperación: ninguna, martingala o niveles. Stop win / stop loss.

Si algo falla, la ventana NO se cierra: muestra el error y lo guarda en errores.log.
"""

import sys, os, json, time, math, random, threading, csv, getpass, subprocess, importlib, importlib.util, traceback, logging
if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")
from collections import deque
sys.dont_write_bytecode = True   # no crear carpetas __pycache__ junto al bot
from datetime import datetime

CARPETA = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
           else os.path.dirname(os.path.abspath(__file__)))  # donde está el bot (por ejemplo el escritorio)
# Todos los archivos del bot (ajustes, registros, historial) van a una carpeta interna, no junto al bot.
DATOS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "IQBotEscaner")
os.makedirs(DATOS, exist_ok=True)
os.chdir(DATOS)
ARCHIVOS_DEL_BOT = ("config_bot.json", "bot.log", "errores.log", "libreria.log", "operaciones.csv", ".version_libreria", "historial.csv")

def ordenar_archivos():
    """Mueve a la carpeta interna los archivos que versiones anteriores dejaban junto al bot,
    y recorta los registros si crecen demasiado."""
    import shutil
    for n in ARCHIVOS_DEL_BOT:
        viejo = os.path.join(CARPETA, n)
        if os.path.abspath(CARPETA) != os.path.abspath(DATOS) and os.path.exists(viejo):
            try:
                if os.path.exists(n):
                    if n.endswith((".log", ".csv")):
                        with open(viejo, encoding="utf-8", errors="ignore") as a, open(n, "a", encoding="utf-8") as b:
                            b.write(a.read())
                    os.remove(viejo)
                else:
                    shutil.move(viejo, n)
            except Exception:
                pass
    for n in ("bot.log", "errores.log", "libreria.log"):
        try:
            if os.path.exists(n) and os.path.getsize(n) > 1_000_000:
                with open(n, encoding="utf-8", errors="ignore") as f:
                    resto = f.read()[-300_000:]
                with open(n, "w", encoding="utf-8") as f:
                    f.write(resto)
        except Exception:
            pass
CONFIG_FILE = "config_bot.json"
LOG_FILE = "historial.csv"
ERROR_LOG = "errores.log"
VERSION_BOT = "2.0"
BUILD_BOT = 135
CONGELADO = getattr(sys, "frozen", False) or os.environ.get("IQBOT_EMBEBIDO") == "1"   # .exe o app Android

# Licencias: el mismo Google Apps Script de LS SmartTrade.
LICENCIA_URL = "https://script.google.com/macros/s/AKfycbwZFdg3mPwRAQLvmJxu3-dgHIaRfYquilothZb3XNAuIwRVUFL0uL_CZNBXruX2jumYyg/exec"
LICENCIA_KEY = "LSBasketEA2024SecretKey"
LICENCIA_EA = "IQBot"
LICENCIA_HORAS = 6          # se vuelve a verificar cada 6 horas
LICENCIA_GRACIA = 24        # horas que sigue funcionando si no hay internet para verificar
ARCHIVO_LICENCIA = "licencia.dat"

URL_LIBRERIA = "https://github.com/iqoptionapi/iqoptionapi/archive/refs/heads/master.zip"
API_ULTIMA_VERSION = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits/master"
ARCHIVO_VERSION_LIB = ".version_libreria"

# ---------------------------------------------------------------------
#  Librería actualizable dentro del .exe / app Android
#  El .exe trae una copia de la librería. Si en GitHub aparece una versión nueva, se descarga a
#  la carpeta de datos y se usa esa (va primero en sys.path). Si la nueva no conecta, se vuelve
#  a la anterior sola. Solo se instalan versiones con al menos ESPERA_VERSION_HORAS publicadas
#  (protección: si alguien publicara algo dañino, suele detectarse y retirarse antes de ese plazo).
# ---------------------------------------------------------------------
LIB_DIR = os.path.join(DATOS, "libreria")              # contiene la carpeta iqoptionapi
LIB_NUEVA = os.path.join(DATOS, "libreria_nueva")
LIB_ANTERIOR = os.path.join(DATOS, "libreria_anterior")
LIB_ESTADO = os.path.join(DATOS, "libreria.json")      # {"sha", "estado": "probando"|"ok", "fallos", "anterior"}
ESPERA_VERSION_HORAS = 24
API_COMMITS = "https://api.github.com/repos/iqoptionapi/iqoptionapi/commits"
REVISION_LIB_HORAS = 6

def _leer_estado_lib():
    try:
        with open(LIB_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _guardar_estado_lib(d):
    try:
        tmp = LIB_ESTADO + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, LIB_ESTADO)
    except Exception:
        pass

def _anotar_lib(msg):
    try:
        with open("libreria.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass

def _volver_a_anterior(motivo):
    """La versión descargada no sirvió: vuelve a la anterior (o a la que trae el .exe)."""
    import shutil
    est = _leer_estado_lib()
    shutil.rmtree(LIB_DIR, ignore_errors=True)
    if os.path.isdir(os.path.join(LIB_ANTERIOR, "iqoptionapi")) and est.get("anterior"):
        os.replace(LIB_ANTERIOR, LIB_DIR)
        _guardar_estado_lib({"sha": est["anterior"], "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a {est['anterior'][:7]}.")
    else:
        _guardar_estado_lib({"sha": None, "estado": "ok", "fallos": 0,
                             "descartada": est.get("sha"), "revisado": est.get("revisado", 0)})
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} descartada ({motivo}). Se vuelve a la incluida en el bot.")

def activar_libreria_descargada():
    """Se llama al cargar el bot, antes de importar la librería."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") == "probando" and int(est.get("fallos", 0)) >= 2:
        _volver_a_anterior("no logró conectar 2 veces")
        est = _leer_estado_lib()
    if est.get("sha") and os.path.isfile(os.path.join(LIB_DIR, "iqoptionapi", "stable_api.py")):
        if LIB_DIR not in sys.path:
            sys.path.insert(0, LIB_DIR)

def version_libreria():
    sha = _leer_estado_lib().get("sha")
    return sha[:7] if sha else "incluida en el bot"

def _validar_libreria(carpeta):
    """Revisa que la versión descargada esté completa y sin errores de sintaxis."""
    raiz = os.path.join(carpeta, "iqoptionapi")
    necesarios = {"stable_api.py": ("class IQ_Option", "def connect"), "api.py": ("class IQOptionAPI",),
                  "constants.py": ("ACTIVES",), os.path.join("ws", "client.py"): ("class WebsocketClient",)}
    for rel, marcas in necesarios.items():
        ruta = os.path.join(raiz, rel)
        if not os.path.isfile(ruta):
            return f"falta {rel}"
        texto = open(ruta, encoding="utf-8", errors="ignore").read()
        for m in marcas:
            if m not in texto:
                return f"{rel} no tiene {m}"
    for base, _, archivos in os.walk(raiz):
        for n in archivos:
            if n.endswith(".py"):
                ruta = os.path.join(base, n)
                try:
                    compile(open(ruta, encoding="utf-8", errors="ignore").read(), ruta, "exec")
                except SyntaxError as e:
                    return f"error de sintaxis en {n}: {e}"
    return None

def actualizar_libreria_embebida(forzar=False):
    """Busca en GitHub una versión nueva de la librería y la deja lista para usar.
    Devuelve (cambio: bool, mensaje). Debe llamarse ANTES de iniciar sesión (aún sin importar la librería)."""
    import io, shutil, zipfile
    if not CONGELADO:
        return False, ""
    est = _leer_estado_lib()
    if not forzar and time.time() - float(est.get("revisado", 0)) < REVISION_LIB_HORAS * 3600:
        return False, f"Librería de IQ Option: versión {version_libreria()}"
    try:
        import requests
        hasta = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - ESPERA_VERSION_HORAS * 3600))
        r = requests.get(API_COMMITS, params={"sha": "master", "per_page": 1, "until": hasta}, timeout=10,
                         headers={"Accept": "application/vnd.github+json", "User-Agent": "IQBotEscaner"})
        r.raise_for_status()
        ultima = r.json()[0]["sha"]
    except Exception as e:
        _anotar_lib(f"No se pudo revisar GitHub: {e}")
        return False, "No se pudo revisar si hay versión nueva de la librería (se usa la actual)."
    if ultima == est.get("sha") or ultima == est.get("descartada"):
        est["revisado"] = time.time(); _guardar_estado_lib(est)
        return False, f"Librería de IQ Option al día ({version_libreria()})"
    if "iqoptionapi.stable_api" in sys.modules:
        return False, "Hay versión nueva de la librería: se instalará al abrir el bot otra vez."
    est["revisado"] = time.time()
    _guardar_estado_lib(est)
    try:
        z = requests.get(f"https://codeload.github.com/iqoptionapi/iqoptionapi/zip/{ultima}", timeout=60,
                         headers={"User-Agent": "IQBotEscaner"})
        z.raise_for_status()
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for n in zf.namelist():
                partes = n.split("/")
                if len(partes) > 2 and partes[1] == "iqoptionapi" and not n.endswith("/") and ".." not in partes:
                    destino = os.path.join(LIB_NUEVA, "iqoptionapi", *partes[2:])
                    os.makedirs(os.path.dirname(destino), exist_ok=True)
                    with open(destino, "wb") as f:
                        f.write(zf.read(n))
        error = _validar_libreria(LIB_NUEVA)
        if error:
            shutil.rmtree(LIB_NUEVA, ignore_errors=True)
            est["descartada"] = ultima; _guardar_estado_lib(est)
            _anotar_lib(f"Versión {ultima[:7]} rechazada: {error}")
            return False, "La versión nueva de la librería venía incompleta: se sigue con la actual."
        shutil.rmtree(LIB_ANTERIOR, ignore_errors=True)
        if os.path.isdir(LIB_DIR):
            os.replace(LIB_DIR, LIB_ANTERIOR)
        os.replace(LIB_NUEVA, LIB_DIR)
        _guardar_estado_lib({"sha": ultima, "estado": "probando", "fallos": 0,
                             "anterior": est.get("sha"), "revisado": est["revisado"]})
        _anotar_lib(f"Librería actualizada {str(est.get('sha') or 'incluida')[:7]} → {ultima[:7]} (en prueba).")
        if LIB_DIR in sys.path:
            sys.path.remove(LIB_DIR)
        sys.path.insert(0, LIB_DIR)
        importlib.invalidate_caches()
        for m in [k for k in sys.modules if k == "iqoptionapi" or k.startswith("iqoptionapi.")]:
            del sys.modules[m]
        return True, f"Librería de IQ Option actualizada a {ultima[:7]}"
    except Exception as e:
        shutil.rmtree(LIB_NUEVA, ignore_errors=True)
        _anotar_lib(f"Falló la descarga de {ultima[:7]}: {e}")
        return False, "No se pudo descargar la versión nueva de la librería (se usa la actual)."

def libreria_conecto(ok, culpa_de_libreria=False):
    """Tras un intento de conexión: confirma la versión nueva o cuenta el fallo para volver atrás."""
    if not CONGELADO:
        return
    est = _leer_estado_lib()
    if est.get("estado") != "probando":
        return
    if ok:
        est["estado"], est["fallos"] = "ok", 0
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} conectó bien: queda confirmada.")
        _guardar_estado_lib(est)
    elif culpa_de_libreria:
        est["fallos"] = int(est.get("fallos", 0)) + 1
        _guardar_estado_lib(est)
        _anotar_lib(f"Versión {str(est.get('sha'))[:7]} no conectó (fallo {est['fallos']}).")

activar_libreria_descargada()

DEFAULT_CONFIG = {
    "cuenta": "PRACTICE",            # PRACTICE (demo) o REAL
    "email": "",                     # se recuerda el correo (nunca la contraseña)
    "monto_entrada": 1.0,
    "temporalidades": [1],           # una sola: 1=M1, 5=M5, 15=M15
    "incluir_otc": True,
    "incluir_mercado_real": True,
    "incluir_digital": False,        # también opciones digitales (se usa la que mejor pague)
    "payout_minimo": 0.80,           # 0.80 = 80 %
    "max_operaciones_simultaneas": 1,  # una operación a la vez (fijo)
    "max_pares": 1000,               # todos los pares abiertos
    "anticipo_ms": 300,              # la orden se envía estos milisegundos antes del cierre de vela
    "actualizar_libreria": True,     # revisar al iniciar si hay versión nueva de la librería de IQ Option
    "verificar_certificados": True,  # conexión cifrada verificada con IQ Option (no desactivar)
    "recuperacion": "martingala",    # "ninguna", "martingala", "niveles" o "auto" (la IA elige por par)
    "rec_max": 2,                    # máximo de gales (martingala) o de niveles
    "rec_modo": "auto",              # "auto" = recupera lo perdido + la ganancia; "multiplicador"
    "rec_multiplicador": 2.2,        # factor por gale/nivel si rec_modo = "multiplicador"
    "stop_win": 10.0,
    "stop_loss": 10.0,
    "velas_catalogo": 500,           # velas del historial para catalogar (fijo, ya no se muestra)
    "min_senales_catalogo": 10,      # mínimo de señales históricas para confiar
    "winrate_minimo": 0.75,          # % de acierto mínimo de la estrategia en ese par (catalogación)
    "ev_minimo": 0.05,               # valor esperado mínimo por $1 (0.05 = +5 %)
    "confluencia_minima": 1,         # nº de estrategias que deben coincidir
    "filtros_v": 5,
}

# =====================================================================
#  INSTALACIÓN AUTOMÁTICA DE LIBRERÍAS
# =====================================================================

def _pip(args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + args
    print("   > pip install " + " ".join(args))
    return subprocess.call(cmd) == 0

def _version_websocket():
    try:
        import websocket
        return getattr(websocket, "__version__", "")
    except Exception:
        return None

def asegurar_librerias():
    """Instala lo que falte. No toca nada si ya está bien instalado. En el .exe todo viene incluido."""
    if CONGELADO:
        return
    falta_iq = importlib.util.find_spec("iqoptionapi") is None
    ws = _version_websocket()
    ws_ok = ws is not None and ws.startswith("0.56")
    req_ok = importlib.util.find_spec("requests") is not None
    rich_ok = importlib.util.find_spec("rich") is not None
    if not falta_iq and ws_ok and req_ok and rich_ok:
        return
    print("\nInstalando librerías (solo la primera vez, tarda 1-2 minutos)...")
    try:
        import pip  # noqa: F401
    except ImportError:
        raise SystemExit("Tu Python no tiene 'pip'. Reinstala Python desde python.org marcando "
                         "'Add python.exe to PATH' y la opción 'pip'.")
    # El paquete 'websocket' (distinto de websocket-client) rompe la librería: se quita si existe.
    subprocess.call([sys.executable, "-m", "pip", "uninstall", "-y", "websocket"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not req_ok and not _pip(["requests"]):
        raise SystemExit("No se pudo instalar 'requests'. Revisa tu conexión a internet.")
    if not ws_ok and not _pip(["websocket-client==0.56"]):
        raise SystemExit("No se pudo instalar 'websocket-client 0.56'. Revisa tu conexión a internet.")
    if not rich_ok and not _pip(["rich"]):
        raise SystemExit("No se pudo instalar 'rich' (la pantalla del bot). Revisa tu conexión a internet.")
    if falta_iq and not _pip(["--no-deps", URL_LIBRERIA]):
        raise SystemExit("No se pudo descargar la librería de IQ Option desde GitHub.\n"
                         "Revisa tu internet o instala a mano con:\n"
                         f"   python -m pip install --no-deps {URL_LIBRERIA}")
    importlib.invalidate_caches()
    for m in [k for k in sys.modules if k.startswith("websocket")]:
        del sys.modules[m]
    print("Librerías instaladas correctamente.\n")

def _probar_libreria():
    """Comprueba en un proceso aparte que la librería instalada se puede usar."""
    return subprocess.call([sys.executable, "-c", "from iqoptionapi.stable_api import IQ_Option; IQ_Option('a@b.c','x')"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0

def actualizar_libreria(motivo=""):
    """Si hay una versión nueva de la librería de IQ Option, la instala.
    Si la nueva no funciona, vuelve a la anterior. Devuelve True si cambió de versión.
    En el .exe la librería viene incluida: se actualiza entregando un .exe nuevo."""
    if CONGELADO:
        return False
    try:
        import requests
        r = requests.get(API_ULTIMA_VERSION, timeout=8, headers={"Accept": "application/vnd.github+json"})
        ultima = r.json()["sha"]
    except Exception:
        print("No se pudo revisar si hay actualizaciones de la librería (se sigue con la instalada).")
        return False
    actual = None
    if os.path.exists(ARCHIVO_VERSION_LIB):
        actual = open(ARCHIVO_VERSION_LIB, encoding="utf-8").read().strip() or None
    if ultima == actual:
        print(f"Librería de IQ Option al día (versión {ultima[:7]}).")
        return False
    print(f"{motivo}Actualizando la librería de IQ Option ({(actual or 'sin registrar')[:13]} → {ultima[:7]})...")
    url = f"https://github.com/iqoptionapi/iqoptionapi/archive/{ultima}.zip"
    if _pip(["--no-deps", "--force-reinstall", "--quiet", url]) and _probar_libreria():
        with open(ARCHIVO_VERSION_LIB, "w", encoding="utf-8") as f: f.write(ultima)
        print("✔ Librería actualizada.")
        return actual is not None
    print("✘ La versión nueva no funcionó.", end=" ")
    if actual:
        print("Se vuelve a la anterior.")
        _pip(["--no-deps", "--force-reinstall", "--quiet", f"https://github.com/iqoptionapi/iqoptionapi/archive/{actual}.zip"])
    else:
        print()
    return False

def reiniciar_bot():
    """Vuelve a abrir el bot en esta misma ventana (por ejemplo, tras actualizar la librería)."""
    print("\nReiniciando el bot...\n")
    env = dict(os.environ, IQBOT_REINICIADO="1")
    comando = [sys.executable] + (sys.argv[1:] if CONGELADO else sys.argv)
    codigo = subprocess.call(comando, env=env)
    os._exit(codigo)

def _saldo_con_bono(bal):
    """Saldo que se muestra: lo depositado + el bono que IQ Option haya aplicado (un solo número)."""
    try:
        monto = float(bal.get("amount") or 0)
    except Exception:
        return bal.get("amount")
    # IQ Option puede mandar el bono con distintos nombres según la cuenta / moneda: se toma el mayor
    # de los campos de bono (son el mismo bono contado de distinta forma) y se suma UNA sola vez
    bonos = [float(v) for k, v in bal.items()
             if "bonus" in str(k).lower() and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    return round(monto + max(bonos), 2) if bonos else monto


def con_timeout(fn, segundos, *args, **kw):
    """Ejecuta fn con límite de tiempo (la librería a veces se queda esperando para siempre)."""
    res = {}
    def correr():
        try:
            res["v"] = fn(*args, **kw)
        except BaseException as e:  # noqa
            res["e"] = e
    h = threading.Thread(target=correr, daemon=True)
    h.start(); h.join(segundos)
    if h.is_alive():
        raise TimeoutError(f"IQ Option no respondió en {segundos} s")
    if "e" in res:
        raise res["e"]
    return res.get("v")

# =====================================================================
#  INDICADORES (Python puro, sin dependencias)
# =====================================================================

def ema(vals, n):
    if len(vals) < n:
        return None
    k = 2 / (n + 1)
    e = sum(vals[:n]) / n
    for v in vals[n:]:
        e = v * k + e * (1 - k)
    return e

def ema_series(vals, n):
    out = [None] * len(vals)
    if len(vals) < n:
        return out
    k = 2 / (n + 1)
    e = sum(vals[:n]) / n
    out[n - 1] = e
    for i in range(n, len(vals)):
        e = vals[i] * k + e * (1 - k)
        out[i] = e
    return out

def rsi(closes, n=14):
    if len(closes) < n + 1:
        return None
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0); losses += max(-d, 0)
    ag, al = gains / n, losses / n
    for i in range(n + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (n - 1) + max(d, 0)) / n
        al = (al * (n - 1) + max(-d, 0)) / n
    if al == 0:
        return 100.0
    return 100 - 100 / (1 + ag / al)

def bollinger(closes, n=20, k=2.0):
    if len(closes) < n:
        return None
    w = closes[-n:]
    m = sum(w) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in w) / n)
    return m - k * sd, m, m + k * sd

def estocastico(c, n=14, d=3):
    if len(c) < n + d:
        return None
    ks = []
    for j in range(d + 1):
        idx = len(c) - 1 - j
        w = c[idx - n + 1: idx + 1]
        hh = max(x["h"] for x in w); ll = min(x["l"] for x in w)
        ks.append(50.0 if hh == ll else 100 * (w[-1]["c"] - ll) / (hh - ll))
    ks.reverse()  # antiguo -> reciente
    k_now, k_prev = ks[-1], ks[-2]
    d_now = sum(ks[-d:]) / d
    d_prev = sum(ks[-d - 1:-1]) / d
    return k_prev, d_prev, k_now, d_now

def color(v):
    if v["c"] > v["o"]: return 1
    if v["c"] < v["o"]: return -1
    return 0

# =====================================================================
#  ESTRATEGIAS
#  Cada una recibe la lista de velas CERRADAS (más antigua -> más reciente)
#  y devuelve "call", "put" o None para la vela siguiente.
# =====================================================================

def st_mhi(c):
    """Minoría de las 3 últimas velas, en cualquier vela (versión continua, sin cuadrante)."""
    cols = [color(v) for v in c[-3:]]
    if 0 in cols: return None
    return "call" if cols.count(1) < cols.count(-1) else "put"

def st_mayoria(c):
    """Mayoría de las 3 últimas velas, en cualquier vela (versión continua, sin cuadrante)."""
    cols = [color(v) for v in c[-3:]]
    if 0 in cols: return None
    return "call" if cols.count(1) > cols.count(-1) else "put"

def st_rsi(c):
    """RSI 14 en zona extrema y la última vela ya gira."""
    cl = [v["c"] for v in c]
    r = rsi(cl, 14)
    if r is None: return None
    if r < 30 and color(c[-1]) == 1: return "call"
    if r > 70 and color(c[-1]) == -1: return "put"
    return None

def st_bollinger(c):
    """Toque de banda de Bollinger con rechazo (cierre de vuelta dentro)."""
    cl = [v["c"] for v in c]
    b = bollinger(cl, 20, 2.0)
    if not b: return None
    lo, _, up = b
    v = c[-1]
    if v["l"] < lo and v["c"] > lo: return "call"
    if v["h"] > up and v["c"] < up: return "put"
    return None

def st_cruce_ema(c):
    """Cruce de EMA 9 sobre EMA 21 en la última vela."""
    cl = [v["c"] for v in c]
    f = ema_series(cl, 9); s = ema_series(cl, 21)
    if None in (f[-1], f[-2], s[-1], s[-2]): return None
    if f[-2] <= s[-2] and f[-1] > s[-1]: return "call"
    if f[-2] >= s[-2] and f[-1] < s[-1]: return "put"
    return None

def st_envolvente(c):
    """Vela envolvente tras al menos 2 velas en sentido contrario."""
    a, b = c[-2], c[-1]
    if color(c[-3]) == -1 and color(a) == -1 and color(b) == 1 and b["c"] > a["o"] and b["o"] <= a["c"]:
        return "call"
    if color(c[-3]) == 1 and color(a) == 1 and color(b) == -1 and b["c"] < a["o"] and b["o"] >= a["c"]:
        return "put"
    return None

def st_pinbar(c):
    """Martillo / estrella fugaz: mecha >= 2x cuerpo en extremo de 10 velas."""
    v = c[-1]
    cuerpo = abs(v["c"] - v["o"]); rango = v["h"] - v["l"]
    if rango == 0: return None
    cuerpo = max(cuerpo, rango * 0.05)
    mecha_inf = min(v["o"], v["c"]) - v["l"]
    mecha_sup = v["h"] - max(v["o"], v["c"])
    w = c[-10:]
    if mecha_inf >= 2 * cuerpo and mecha_sup < cuerpo and v["l"] <= min(x["l"] for x in w):
        return "call"
    if mecha_sup >= 2 * cuerpo and mecha_inf < cuerpo and v["h"] >= max(x["h"] for x in w):
        return "put"
    return None

def st_tres_soldados(c):
    """Tres soldados / tres cuervos con cierres progresivos (continuación)."""
    w = c[-3:]
    if all(color(v) == 1 for v in w) and w[0]["c"] < w[1]["c"] < w[2]["c"]: return "call"
    if all(color(v) == -1 for v in w) and w[0]["c"] > w[1]["c"] > w[2]["c"]: return "put"
    return None

def st_estocastico(c):
    """Cruce %K/%D del estocástico en sobreventa / sobrecompra."""
    s = estocastico(c, 14, 3)
    if not s: return None
    kp, dp, k, d = s
    if kp <= dp and k > d and k < 25: return "call"
    if kp >= dp and k < d and k > 75: return "put"
    return None

def st_pullback_ema(c):
    """Tendencia por EMA 50 y retroceso que toca la EMA 9 y cierra a favor."""
    cl = [v["c"] for v in c]
    e50 = ema(cl, 50); e9 = ema(cl, 9)
    if e50 is None or e9 is None: return None
    v = c[-1]
    if v["c"] > e50 and e9 > e50 and v["l"] <= e9 <= v["c"] and color(v) == 1: return "call"
    if v["c"] < e50 and e9 < e50 and v["h"] >= e9 >= v["c"] and color(v) == -1: return "put"
    return None

def _williams(c, n=14, idx=-1):
    w = c[len(c) + idx - n + 1: len(c) + idx + 1] if idx != -1 else c[-n:]
    if len(w) < n: return None
    hh = max(x["h"] for x in w); ll = min(x["l"] for x in w)
    return -50.0 if hh == ll else -100 * (hh - w[-1]["c"]) / (hh - ll)

def st_williams(c):
    """Williams %R 14: sale de sobreventa (-80) o de sobrecompra (-20) en la última vela."""
    if len(c) < 16: return None
    prev, now = _williams(c[:-1]), _williams(c)
    if prev is None or now is None: return None
    if prev <= -80 and now > -80: return "call"
    if prev >= -20 and now < -20: return "put"
    return None

def _cci(c, n=20):
    if len(c) < n: return None
    tp = [(x["h"] + x["l"] + x["c"]) / 3 for x in c[-n:]]
    m = sum(tp) / n
    md = sum(abs(t - m) for t in tp) / n
    return 0.0 if md == 0 else (tp[-1] - m) / (0.015 * md)

def st_cci(c):
    """CCI 20: vuelve desde fuera de ±100 (agotamiento del movimiento)."""
    if len(c) < 22: return None
    prev, now = _cci(c[:-1]), _cci(c)
    if prev is None or now is None: return None
    if prev < -100 and now > -100: return "call"
    if prev > 100 and now < 100: return "put"
    return None

def st_macd(c):
    """Cruce de la línea MACD (12, 26) con su señal (9) en la última vela."""
    cl = [v["c"] for v in c]
    if len(cl) < 40: return None
    e12, e26 = ema_series(cl, 12), ema_series(cl, 26)
    macd = [a - b for a, b in zip(e12, e26) if a is not None and b is not None]
    if len(macd) < 12: return None
    sig = ema_series(macd, 9)
    if None in (sig[-1], sig[-2]): return None
    if macd[-2] <= sig[-2] and macd[-1] > sig[-1]: return "call"
    if macd[-2] >= sig[-2] and macd[-1] < sig[-1]: return "put"
    return None

def st_agotamiento(c):
    """Agotamiento: 4 velas seguidas del mismo color y la última más chica que la anterior -> reversión."""
    w = c[-4:]
    cols = [color(v) for v in w]
    if 0 in cols or len(set(cols)) != 1: return None
    if abs(w[-1]["c"] - w[-1]["o"]) >= abs(w[-2]["c"] - w[-2]["o"]): return None
    return "put" if cols[0] == 1 else "call"

def st_vela_fuerza(c):
    """Vela de fuerza: cuerpo >= 2x el promedio de las 10 anteriores y cierre en su extremo -> continuación."""
    v = c[-1]; rango = v["h"] - v["l"]; cuerpo = abs(v["c"] - v["o"])
    if rango == 0 or len(c) < 11: return None
    prom = sum(abs(x["c"] - x["o"]) for x in c[-11:-1]) / 10
    if prom == 0 or cuerpo < 2 * prom: return None
    if color(v) == 1 and (v["h"] - v["c"]) <= 0.2 * rango: return "call"
    if color(v) == -1 and (v["c"] - v["l"]) <= 0.2 * rango: return "put"
    return None

# ---------- Niveles: soportes, resistencias y números redondos ----------

def _atr(c, n=14):
    w = c[-n:]
    return sum(v["h"] - v["l"] for v in w) / len(w) if w else 0.0

def _pivotes(c, desde, hasta, lado=2):
    """Techos y pisos locales (fractales) entre las velas [desde, hasta)."""
    altos, bajos = [], []
    for i in range(max(lado, desde), min(hasta, len(c) - lado)):
        h, l = c[i]["h"], c[i]["l"]
        if all(h >= c[j]["h"] for j in range(i - lado, i + lado + 1) if j != i):
            altos.append(h)
        if all(l <= c[j]["l"] for j in range(i - lado, i + lado + 1) if j != i):
            bajos.append(l)
    return altos, bajos

def _niveles(precios, tol, minimo=2):
    """Agrupa precios parecidos: devuelve los niveles tocados al menos `minimo` veces."""
    grupos = []
    for p in sorted(precios):
        if grupos and p - grupos[-1][-1] <= tol:
            grupos[-1].append(p)
        else:
            grupos.append([p])
    return [sum(g) / len(g) for g in grupos if len(g) >= minimo]

def st_rechazo_sr(c):
    """Rechazo en soporte/resistencia: el precio toca un nivel donde ya rebotó 2+ veces y deja una mecha
    de rechazo (mecha de al menos la mitad de la vela) -> entra a favor del rebote."""
    if len(c) < 50: return None
    v = c[-1]; rango = v["h"] - v["l"]
    atr = _atr(c)
    if rango <= 0 or atr <= 0: return None
    tol = 0.25 * atr
    altos, bajos = _pivotes(c, len(c) - 50, len(c) - 3)
    for s in _niveles(bajos, tol):
        mecha = min(v["o"], v["c"]) - v["l"]
        if v["l"] <= s + tol and v["c"] > s and mecha >= 0.5 * rango:
            return "call"
    for r in _niveles(altos, tol):
        mecha = v["h"] - max(v["o"], v["c"])
        if v["h"] >= r - tol and v["c"] < r and mecha >= 0.5 * rango:
            return "put"
    return None

def st_retesteo(c):
    """Retesteo de ruptura: el precio rompió un techo (o piso) en las últimas velas, vuelve a tocarlo
    y lo respeta -> entra a favor de la ruptura (el techo roto ahora es piso)."""
    if len(c) < 50: return None
    v = c[-1]; atr = _atr(c)
    if atr <= 0: return None
    tol = 0.25 * atr
    altos, bajos = _pivotes(c, len(c) - 50, len(c) - 12)
    recientes = c[-12:-1]
    for r in _niveles(altos, tol):
        rompio = any(x["c"] > r + tol for x in recientes)
        if rompio and v["l"] <= r + tol and v["c"] > r and color(v) == 1:
            return "call"
    for s in _niveles(bajos, tol):
        rompio = any(x["c"] < s - tol for x in recientes)
        if rompio and v["h"] >= s - tol and v["c"] < s and color(v) == -1:
            return "put"
    return None

def _paso_redondo(precio):
    """Distancia entre números redondos: 1.1000/1.1050 (paso 0.005), 180.0/180.5 (paso 0.5)…"""
    if precio <= 0: return None
    return 0.5 * 10 ** (math.floor(math.log10(precio)) - 2)

def st_numero_redondo(c):
    """Agotamiento en número redondo: 3 velas seguidas del mismo color llegan a un número redondo
    (ej. 1.1000, 1.1050, 180.00) -> reversión (los números redondos frenan el precio)."""
    if len(c) < 20: return None
    w = c[-3:]
    cols = [color(x) for x in w]
    if 0 in cols or len(set(cols)) != 1: return None
    v = c[-1]; paso = _paso_redondo(v["c"]); atr = _atr(c)
    if not paso or atr <= 0: return None
    tol = 0.15 * atr
    if cols[0] == 1:
        nivel = math.ceil((w[0]["o"]) / paso) * paso       # siguiente número redondo hacia arriba
        if v["h"] >= nivel - tol and v["c"] <= nivel + tol: return "put"
    else:
        nivel = math.floor((w[0]["o"]) / paso) * paso
        if v["l"] <= nivel + tol and v["c"] >= nivel - tol: return "call"
    return None

# ---------- Estrategias de CUADRANTE (velas de 1 minuto, cuadrantes de 5 velas: :00-:04, :05-:09...) ----------
# Posición de la vela dentro del cuadrante: 0 = 1a vela (minuto :00/:05), ... 4 = 5a vela.
# Con doji en las velas analizadas NO se opera. Solo dan señal en M1.

def _cuadrante(c):
    """Devuelve (posición de la vela de entrada 0-4, función color_en(pos, cuadrante)) o None."""
    if len(c) < 12 or c[-1]["t"] - c[-2]["t"] != 60:
        return None
    t_entrada = c[-1]["t"] + 60
    pos = (t_entrada // 60) % 5
    inicio_actual = t_entrada - pos * 60
    por_t = {v["t"]: v for v in c[-12:]}
    def color_en(p, cuad=0):
        """cuad 0 = cuadrante de la entrada, -1 = cuadrante anterior."""
        v = por_t.get(inicio_actual + cuad * 300 + p * 60)
        if v is None: return None
        col = color(v)
        return col if col != 0 else None   # doji = no operar
    return pos, color_en

def _dir(col):
    return "call" if col == 1 else "put"

def _minoria(cols):
    if None in cols: return None
    return _dir(1 if cols.count(1) < cols.count(-1) else -1)

def _mayoria(cols):
    if None in cols: return None
    return _dir(1 if cols.count(1) > cols.count(-1) else -1)

def _hacer_mhi(pos_entrada, tipo):
    def f(c):
        q = _cuadrante(c)
        if not q or q[0] != pos_entrada: return None
        _, col = q
        cols = [col(2, -1), col(3, -1), col(4, -1)]   # 3 últimas velas del cuadrante anterior
        return _minoria(cols) if tipo == "minoria" else _mayoria(cols)
    return f

st_mhi1 = _hacer_mhi(0, "minoria")
st_mhi1.__doc__ = "MHI 1: minoría de las 3 últimas velas del cuadrante anterior; entra en la 1a vela."
st_mhi2 = _hacer_mhi(1, "minoria")
st_mhi2.__doc__ = "MHI 2: igual que MHI 1, pero entra en la 2a vela del cuadrante."
st_mhi3 = _hacer_mhi(2, "minoria")
st_mhi3.__doc__ = "MHI 3: igual que MHI 1, pero entra en la 3a vela del cuadrante."
st_mhi_may1 = _hacer_mhi(0, "mayoria")
st_mhi_may1.__doc__ = "MHI Mayoría 1: mayoría de las 3 últimas velas; entra en la 1a vela."
st_mhi_may2 = _hacer_mhi(1, "mayoria")
st_mhi_may2.__doc__ = "MHI Mayoría 2: mayoría de las 3 últimas velas; entra en la 2a vela."
st_mhi_may3 = _hacer_mhi(2, "mayoria")
st_mhi_may3.__doc__ = "MHI Mayoría 3: mayoría de las 3 últimas velas; entra en la 3a vela."

def st_torres_gemelas(c):
    """Torres Gemelas: entra en la 5a vela con el color de la 1a vela del mismo cuadrante."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    v = q[1](0, 0)
    return _dir(v) if v else None

def st_tres_mosqueteros(c):
    """Tres Mosqueteros: entra en la 4a vela con el color de la 3a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 3: return None
    v = q[1](2, 0)
    return _dir(v) if v else None

def st_tres_vecinos(c):
    """Tres Vecinos: entra en la 5a vela con el color de la 4a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    v = q[1](3, 0)
    return _dir(v) if v else None

def st_padron_23(c):
    """Padrón 23: entra en la 2a vela con el color de la 1a vela del cuadrante."""
    q = _cuadrante(c)
    if not q or q[0] != 1: return None
    v = q[1](0, 0)
    return _dir(v) if v else None

def st_mejor_de_3(c):
    """Mejor de 3: mayoría de las 3 velas del centro (2a, 3a, 4a) del cuadrante anterior; entra en la 3a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 2: return None
    col = q[1]
    return _mayoria([col(1, -1), col(2, -1), col(3, -1)])

def st_patron_3x1(c):
    """Patrón 3x1: minoría de las 3 primeras velas del cuadrante; entra en la 5a vela."""
    q = _cuadrante(c)
    if not q or q[0] != 4: return None
    col = q[1]
    return _minoria([col(0, 0), col(1, 0), col(2, 0)])


def _hacer_milhao(tipo):
    def f(c):
        q = _cuadrante(c)
        if not q or q[0] != 0: return None
        col = q[1]
        cols = [col(p, -1) for p in range(5)]          # las 5 velas del cuadrante anterior
        return _minoria(cols) if tipo == "minoria" else _mayoria(cols)
    return f

st_milhao_may = _hacer_milhao("mayoria")
st_milhao_may.__doc__ = "Milhão Maioria: mayoría de las 5 velas del cuadrante anterior; entra en la 1a vela del nuevo."
st_milhao_min = _hacer_milhao("minoria")
st_milhao_min.__doc__ = "Milhão Minoria: minoría de las 5 velas del cuadrante anterior; entra en la 1a vela del nuevo."

ESTRATEGIAS_CUADRANTE = {
    "MHI_1": st_mhi1,
    "MHI_2": st_mhi2,
    "MHI_3": st_mhi3,
    "MHI_Mayoria_1": st_mhi_may1,
    "MHI_Mayoria_2": st_mhi_may2,
    "MHI_Mayoria_3": st_mhi_may3,
    "Torres_Gemelas": st_torres_gemelas,
    "Tres_Mosqueteros": st_tres_mosqueteros,
    "Tres_Vecinos": st_tres_vecinos,
    "Padron_23": st_padron_23,
    "Mejor_de_3": st_mejor_de_3,
    "Patron_3x1": st_patron_3x1,
    "Milhao_Maioria": st_milhao_may,
    "Milhao_Minoria": st_milhao_min,
}

def st_reversao(c):
    """Reversão: tras 4+ velas seguidas de un color aparece la 1a vela contraria con cuerpo firme
    (>= 60 % de la anterior y cierre más allá de la mitad de esa vela, sin llegar a envolverla: eso ya
    lo cubre Envolvente) -> entra con el giro (patrón de penetración tras racha larga)."""
    if len(c) < 6: return None
    v = c[-1]; cv = color(v)
    if cv == 0: return None
    n = 0
    for x in reversed(c[:-1]):
        if color(x) == -cv: n += 1
        else: break
    if n < 4: return None
    a = c[-2]; ca = abs(a["c"] - a["o"])
    if ca == 0 or abs(v["c"] - v["o"]) < 0.6 * ca: return None
    mitad = (a["o"] + a["c"]) / 2
    if cv == 1 and mitad < v["c"] <= a["o"]: return "call"
    if cv == -1 and a["o"] <= v["c"] < mitad: return "put"
    return None

def _heikin(c):
    ha = []
    for v in c:
        hc = (v["o"] + v["h"] + v["l"] + v["c"]) / 4
        ho = (v["o"] + v["c"]) / 2 if not ha else (ha[-1][0] + ha[-1][1]) / 2
        ha.append((ho, hc, max(v["h"], ho, hc), min(v["l"], ho, hc)))
    return ha

def st_heikin_ashi(c):
    """Heikin-Ashi: tras 3+ velas HA de un color, la HA cambia de color y nace sin mecha en contra
    (señal de giro con fuerza) -> entra con el nuevo color."""
    if len(c) < 30: return None
    ha = _heikin(c[-30:])
    o, cl, h, l = ha[-1]
    rango = h - l
    if rango <= 0: return None
    col = 1 if cl > o else -1 if cl < o else 0
    if col == 0: return None
    previas = ha[-4:-1]
    if not all((x[1] < x[0]) if col == 1 else (x[1] > x[0]) for x in previas): return None
    if col == 1 and (min(o, cl) - l) <= 0.05 * rango: return "call"
    if col == -1 and (h - max(o, cl)) <= 0.05 * rango: return "put"
    return None


# ---------- Estrategias clásicas de velas e indicadores  ----------

def _cuerpo(v):
    return abs(v["c"] - v["o"])

def _prom_cuerpo(c, n=10):
    w = c[-n - 1:-1]
    return sum(_cuerpo(x) for x in w) / len(w) if w else 0.0

def st_tres_dentro(c):
    """Tres velas dentro (Three Inside Up/Down): vela grande, harami contrario y una tercera que confirma."""
    if len(c) < 12: return None
    a, b, v = c[-3], c[-2], c[-1]
    if _cuerpo(a) < _prom_cuerpo(c[:-2]): return None
    if color(a) == -1 and color(b) == 1 and b["c"] < a["o"] and b["o"] >= a["c"] and color(v) == 1 and v["c"] > a["o"]:
        return "call"
    if color(a) == 1 and color(b) == -1 and b["c"] > a["o"] and b["o"] <= a["c"] and color(v) == -1 and v["c"] < a["o"]:
        return "put"
    return None

def st_estrella(c):
    """Estrella de la mañana / de la tarde: vela grande, vela chica de duda y vela contraria que pasa la mitad."""
    if len(c) < 12: return None
    a, b, v = c[-3], c[-2], c[-1]
    ca = _cuerpo(a)
    if ca < _prom_cuerpo(c[:-2]) or _cuerpo(b) > 0.3 * ca: return None
    mitad = (a["o"] + a["c"]) / 2
    if color(a) == -1 and color(v) == 1 and v["c"] > mitad: return "call"
    if color(a) == 1 and color(v) == -1 and v["c"] < mitad: return "put"
    return None

def st_harami(c):
    """Harami: tras 2 velas de un color, una vela grande y luego una chica contraria dentro de su cuerpo."""
    if len(c) < 14: return None
    a, v = c[-2], c[-1]
    ca = _cuerpo(a)
    if ca < 1.5 * _prom_cuerpo(c[:-1]) or _cuerpo(v) > 0.5 * ca: return None
    if not (color(c[-3]) == color(a) != 0) or color(v) != -color(a): return None
    if max(v["o"], v["c"]) <= max(a["o"], a["c"]) and min(v["o"], v["c"]) >= min(a["o"], a["c"]):
        return "call" if color(v) == 1 else "put"
    return None

def st_pinzas(c):
    """Pinzas (tweezer): dos velas de color contrario con el mismo máximo (o mínimo) en un extremo de 10 velas."""
    if len(c) < 20: return None
    a, v = c[-2], c[-1]
    atr = _atr(c)
    if atr <= 0 or color(a) == 0 or color(v) != -color(a): return None
    tol = 0.1 * atr
    w = c[-10:]
    if color(v) == -1 and abs(a["h"] - v["h"]) <= tol and max(a["h"], v["h"]) >= max(x["h"] for x in w): return "put"
    if color(v) == 1 and abs(a["l"] - v["l"]) <= tol and min(a["l"], v["l"]) <= min(x["l"] for x in w): return "call"
    return None

def st_doji_bollinger(c):
    """Doji fuera de las bandas de Bollinger: indecisión en un extremo -> reversión."""
    b = bollinger([v["c"] for v in c], 20, 2.0)
    if not b: return None
    v = c[-1]; rango = v["h"] - v["l"]
    if rango <= 0 or _cuerpo(v) > 0.1 * rango: return None
    if v["l"] <= b[0]: return "call"
    if v["h"] >= b[2]: return "put"
    return None

def _sar(c, paso=0.02, maximo=0.2):
    """Parabolic SAR. Devuelve lista de (sar, alcista)."""
    if len(c) < 5: return []
    alc = c[1]["c"] >= c[0]["c"]
    sar = c[0]["l"] if alc else c[0]["h"]
    ep = c[0]["h"] if alc else c[0]["l"]
    af = paso; out = [(sar, alc)]
    for i in range(1, len(c)):
        sar = sar + af * (ep - sar)
        v = c[i]
        if alc:
            sar = min(sar, c[i - 1]["l"], c[i - 2]["l"] if i >= 2 else c[i - 1]["l"])
            if v["l"] < sar:
                alc, sar, ep, af = False, ep, v["l"], paso
            elif v["h"] > ep:
                ep = v["h"]; af = min(maximo, af + paso)
        else:
            sar = max(sar, c[i - 1]["h"], c[i - 2]["h"] if i >= 2 else c[i - 1]["h"])
            if v["h"] > sar:
                alc, sar, ep, af = True, ep, v["h"], paso
            elif v["l"] < ep:
                ep = v["l"]; af = min(maximo, af + paso)
        out.append((sar, alc))
    return out

def st_sar(c):
    """Parabolic SAR: los puntos cambian de lado en la última vela -> entra con la nueva tendencia."""
    s = _sar(c[-60:])
    if len(s) < 3 or s[-1][1] == s[-2][1]: return None
    return "call" if s[-1][1] else "put"

def _di(c, n=14):
    trs, pdm, mdm = [], [], []
    for a, b in zip(c[-n - 1:-1], c[-n:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0); mdm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    tr = sum(trs)
    return (100 * sum(pdm) / tr, 100 * sum(mdm) / tr) if tr > 0 else (None, None)

def st_adx_di(c):
    """Cruce de +DI y -DI con ADX mayor a 20 (tendencia con fuerza)."""
    if len(c) < 32: return None
    a = _adx(c)
    if a is None or a < 20: return None
    p1, m1 = _di(c); p0, m0 = _di(c[:-1])
    if None in (p1, m1, p0, m0): return None
    if p0 <= m0 and p1 > m1: return "call"
    if p0 >= m0 and p1 < m1: return "put"
    return None

def st_donchian(c):
    """Ruptura del canal Donchian de 20 velas con cierre fuera del canal -> continuación."""
    if len(c) < 22: return None
    w = c[-21:-1]; v = c[-1]
    if v["c"] > max(x["h"] for x in w) and color(v) == 1: return "call"
    if v["c"] < min(x["l"] for x in w) and color(v) == -1: return "put"
    return None

def st_keltner(c):
    """Rechazo en el canal de Keltner (EMA 20 ± 1,5 ATR): toca afuera y cierra adentro -> reversión."""
    if len(c) < 25: return None
    m = ema([v["c"] for v in c], 20); atr = _atr(c, 10)
    if m is None or atr <= 0: return None
    up, lo = m + 1.5 * atr, m - 1.5 * atr
    v = c[-1]
    if v["l"] < lo and v["c"] > lo: return "call"
    if v["h"] > up and v["c"] < up: return "put"
    return None

def st_ema_5_13(c):
    """Cruce rápido de EMA 5 sobre EMA 13 en la última vela."""
    cl = [v["c"] for v in c]
    f, s = ema_series(cl, 5), ema_series(cl, 13)
    if None in (f[-1], f[-2], s[-1], s[-2]): return None
    if f[-2] <= s[-2] and f[-1] > s[-1]: return "call"
    if f[-2] >= s[-2] and f[-1] < s[-1]: return "put"
    return None

def st_rsi2(c):
    """RSI de 2 períodos (Connors) en extremo, a favor de la tendencia de la EMA 50 -> rebote."""
    cl = [v["c"] for v in c]
    r = rsi(cl[-30:], 2); e = ema(cl, 50)
    if r is None or e is None: return None
    if r < 5 and cl[-1] > e: return "call"
    if r > 95 and cl[-1] < e: return "put"
    return None

def _medio(c, n, fin=None):
    w = c[-n:] if fin is None else c[fin - n:fin]
    return (max(x["h"] for x in w) + min(x["l"] for x in w)) / 2

def st_ichimoku(c):
    """Ichimoku: cruce de Tenkan (9) y Kijun (26) en la última vela."""
    if len(c) < 28: return None
    t1, k1 = _medio(c, 9), _medio(c, 26)
    n = len(c) - 1
    t0, k0 = _medio(c, 9, n), _medio(c, 26, n)
    if t0 <= k0 and t1 > k1: return "call"
    if t0 >= k0 and t1 < k1: return "put"
    return None

def st_barra_interna(c):
    """Barra interna: una vela dentro de la anterior y la siguiente rompe el rango de la vela madre."""
    if len(c) < 4: return None
    madre, interna, v = c[-3], c[-2], c[-1]
    if not (interna["h"] <= madre["h"] and interna["l"] >= madre["l"]): return None
    if v["c"] > madre["h"] and color(v) == 1: return "call"
    if v["c"] < madre["l"] and color(v) == -1: return "put"
    return None

def st_fractal(c):
    """Ruptura de fractal: el cierre rompe el último techo (o piso) fractal de Bill Williams."""
    if len(c) < 20: return None
    v = c[-1]
    techo = piso = None
    for i in range(len(c) - 4, len(c) - 20, -1):
        h, l = c[i]["h"], c[i]["l"]
        vec = [c[j] for j in (i - 2, i - 1, i + 1, i + 2)]
        if techo is None and all(h > x["h"] for x in vec): techo = h
        if piso is None and all(l < x["l"] for x in vec): piso = l
        if techo is not None and piso is not None: break
    if techo is not None and c[-2]["c"] <= techo < v["c"]: return "call"
    if piso is not None and c[-2]["c"] >= piso > v["c"]: return "put"
    return None

def _ao(c, fin=None):
    w = c if fin is None else c[:fin]
    if len(w) < 34: return None
    med = [(x["h"] + x["l"]) / 2 for x in w[-34:]]
    return sum(med[-5:]) / 5 - sum(med) / 34

def st_awesome(c):
    """Awesome Oscillator (Bill Williams) cruza la línea cero."""
    a1, a0 = _ao(c), _ao(c, len(c) - 1)
    if a1 is None or a0 is None: return None
    if a0 <= 0 < a1: return "call"
    if a0 >= 0 > a1: return "put"
    return None

def st_momentum(c):
    """Momentum de 10 velas cruza el cero (el precio pasa a subir o bajar frente a hace 10 velas)."""
    if len(c) < 13: return None
    m1 = c[-1]["c"] - c[-11]["c"]; m0 = c[-2]["c"] - c[-12]["c"]
    if m0 <= 0 < m1: return "call"
    if m0 >= 0 > m1: return "put"
    return None



ESTRATEGIAS_INDICADORES = {
    "Minoria_3_velas": st_mhi,
    "Mayoria_3_velas": st_mayoria,
    "RSI_extremo": st_rsi,
    "Bollinger_rechazo": st_bollinger,
    "Cruce_EMA_9_21": st_cruce_ema,
    "Envolvente": st_envolvente,
    "Pinbar": st_pinbar,
    "Tres_soldados": st_tres_soldados,
    "Estocastico": st_estocastico,
    "Pullback_EMA": st_pullback_ema,
    "Williams_R": st_williams,
    "CCI_extremo": st_cci,
    "Cruce_MACD": st_macd,
    "Agotamiento": st_agotamiento,
    "Vela_de_fuerza": st_vela_fuerza,
    "Rechazo_SR": st_rechazo_sr,
    "Retesteo_ruptura": st_retesteo,
    "Numero_redondo": st_numero_redondo,
    "Reversao": st_reversao,
    "Heikin_Ashi": st_heikin_ashi,
    "Tres_dentro": st_tres_dentro,
    "Estrella": st_estrella,
    "Harami": st_harami,
    "Pinzas": st_pinzas,
    "Doji_Bollinger": st_doji_bollinger,
    "Parabolic_SAR": st_sar,
    "ADX_DI": st_adx_di,
    "Donchian": st_donchian,
    "Keltner": st_keltner,
    "Cruce_EMA_5_13": st_ema_5_13,
    "RSI_2": st_rsi2,
    "Ichimoku": st_ichimoku,
    "Barra_interna": st_barra_interna,
    "Fractal": st_fractal,
    "Awesome": st_awesome,
    "Momentum": st_momentum,
}


# ---------- reversión (ideas que al autor le funcionaron en otro bot; versiones propias) ----------
def _rechazo_racha(c, n):
    """N velas seguidas del mismo color y la vela actual deja una mecha de rechazo de al menos la mitad
    de su rango en el sentido de la racha -> entra en contra de la racha (el precio se devuelve)."""
    if len(c) < n + 2:
        return None
    cols = [color(v) for v in c[-n - 1:-1]]
    if 0 in cols or len(set(cols)) != 1:
        return None
    s, v = cols[0], c[-1]
    rango = v["h"] - v["l"]
    if rango <= 0:
        return None
    mecha = v["h"] - max(v["o"], v["c"]) if s == 1 else min(v["o"], v["c"]) - v["l"]
    if mecha < 0.5 * rango:
        return None
    return "put" if s == 1 else "call"


def st_rechazo_racha_3(c):
    """Rechazo tras racha de 3 velas: mecha de rechazo >= 50 % de la vela -> en contra de la racha."""
    return _rechazo_racha(c, 3)


def st_rechazo_racha_4(c):
    """Rechazo tras racha de 4 velas: mecha de rechazo >= 50 % de la vela -> en contra de la racha."""
    return _rechazo_racha(c, 4)


def st_rechazo_racha_5(c):
    """Rechazo tras racha de 5 velas: mecha de rechazo >= 50 % de la vela -> en contra de la racha."""
    return _rechazo_racha(c, 5)


_RSI14_CACHE = {}


def _rsi14_extremo(c, alto, bajo):
    """RSI 14 en extremo y la vela ya se devuelve: arriba de `alto` y vela roja que lo baja -> PUT;
    abajo de `bajo` y vela verde que lo sube -> CALL."""
    clave = (c[-1]["t"], c[-1]["c"], c[-2]["c"] if len(c) > 1 else None, len(c))
    par_rsi = _RSI14_CACHE.get(clave)
    if par_rsi is None:                                 # las dos versiones (70 y 80) comparten el cálculo
        cierres = [v["c"] for v in c[-41:]]             # 40 velas bastan para el RSI 14 (más rápido en celular)
        par_rsi = (rsi(cierres[:-1], 14), rsi(cierres, 14))
        if len(_RSI14_CACHE) > 4000:
            _RSI14_CACHE.clear()
        _RSI14_CACHE[clave] = par_rsi
    r0, r1 = par_rsi
    if r0 is None or r1 is None:
        return None
    if r0 >= alto and r1 < r0 and color(c[-1]) == -1:
        return "put"
    if r0 <= bajo and r1 > r0 and color(c[-1]) == 1:
        return "call"
    return None


def st_rsi14_extremo_70(c):
    """RSI 14 en extremo 70/30 y la vela empieza a devolverse -> reversión."""
    return _rsi14_extremo(c, 70, 30)


def st_rsi14_extremo_80(c):
    """RSI 14 en extremo 80/20 (menos señales, más fuertes) y la vela empieza a devolverse -> reversión."""
    return _rsi14_extremo(c, 80, 20)


ESTRATEGIAS_V2 = {                 # nuevas: no cambian las entradas de la red de señales ya entrenada
    "Rechazo_racha_3": st_rechazo_racha_3,
    "Rechazo_racha_4": st_rechazo_racha_4,
    "Rechazo_racha_5": st_rechazo_racha_5,
    "RSI14_extremo_70": st_rsi14_extremo_70,
    "RSI14_extremo_80": st_rsi14_extremo_80,
}
ESTRATEGIAS_INDICADORES.update(ESTRATEGIAS_V2)
ESTRATEGIAS = {**ESTRATEGIAS_CUADRANTE, **ESTRATEGIAS_INDICADORES}
VENTANA = 60  # velas que ve cada estrategia (suficiente para EMA 50)
VELAS_CATALOGO = 500        # velas de historial: más historia para elegir la mejor señal y decidir la recuperación
VELAS_FILTRO = 300          # el acierto mínimo y las señales mínimas se miden con las últimas 300 (como siempre)

# =====================================================================
#  CATALOGACIÓN: winrate histórico de cada estrategia en cada par
# =====================================================================

SENALES_RECIENTES = 12      # cuántas de las últimas señales se miran para saber si la estrategia "se enfrió"

def catalogar(velas, fn):
    """Devuelve (señales, ganadas_sin_gale, ganadas_hasta_G1, señales_recientes, ganadas_recientes,
    ganadas_hasta_G2, ganadas_hasta_G3)."""
    n = g0 = g1 = g2 = g3 = 0
    nr = gr0 = gr1 = 0                          # las mismas cuentas, solo con las últimas VELAS_FILTRO velas
    ne = ge = npv = gp = 0                      # validación: elección (velas viejas) / prueba (últimas VAL_VELAS)
    ult = []
    total = len(velas)
    desde_prueba = total - 1 - VAL_VELAS
    desde_filtro = total - 1 - VELAS_FILTRO
    for i in range(VENTANA, total - 1):
        d = fn(velas[i - VENTANA + 1: i + 1])
        if not d: continue
        n += 1
        obj = 1 if d == "call" else -1
        gano_en = None
        for k in range(4):                      # 0 = la entrada, 1..3 = gales
            if i + 1 + k >= total:
                break
            if color(velas[i + 1 + k]) == obj:
                gano_en = k
                break
        if gano_en == 0: g0 += 1
        if i >= desde_prueba:
            npv += 1; gp += 1 if gano_en == 0 else 0
        else:
            ne += 1; ge += 1 if gano_en == 0 else 0
        if i >= desde_filtro:
            nr += 1
            gr0 += 1 if gano_en == 0 else 0
            gr1 += 1 if gano_en is not None and gano_en <= 1 else 0
        if gano_en is not None and gano_en <= 1: g1 += 1
        if gano_en is not None and gano_en <= 2: g2 += 1
        if gano_en is not None: g3 += 1
        ult.append(1 if gano_en == 0 else 0)
    ult = ult[-SENALES_RECIENTES:]
    return n, g0, g1, len(ult), sum(ult), g2, g3, nr, gr0, gr1, ne, ge, npv, gp

# ---------- catálogo validado (en prueba sin dinero) ----------
# El catálogo normal elige y mide la estrategia con las MISMAS velas: entre ~50 estrategias siempre aparece
# alguna que acertó 8 de 10 por casualidad (en vivo vuelve a ~50 %). El validado la elige con las velas viejas
# y la mide con las 200 más recientes que no usó para elegirla + lo que esa estrategia hizo de verdad en ese par.
VAL_VELAS = 200              # velas de prueba (las más recientes de las 500)
VAL_ELEGIR = 0.70            # acierto mínimo en las velas viejas (elección)
VAL_ELEGIR_MIN = 10          # señales mínimas en la elección
VAL_PRUEBA = 0.60            # acierto mínimo en la prueba + datos reales
VAL_PRUEBA_MIN = 8           # señales mínimas en la prueba + datos reales
RESPALDO_SEG = 600           # si en 10 min no aparece una señal validada, entra la mejor del catálogo normal
VAL_REAL_MALO = 0.45         # si la estrategia, en vivo y en todos los pares, viene por debajo de esto: no pasa
SOMBRA_ARCHIVO = os.path.join(DATOS, "sombra_catalogo.json")


def validar_estrategia(res, real_ep, real_e, minimo_cliente=None):
    """(pasa, acierto_validado, señales). res = tupla del catálogo; real_ep = resultados reales de esa estrategia
    en ese par; real_e = resultados reales de la estrategia en todos los pares."""
    v = (tuple(res) + (0,) * 14)[:14]
    ne, ge, npv, gp = v[10], v[11], v[12], v[13]
    gl, nl = sum(real_ep[-30:]), len(real_ep[-30:])
    n_val, g_val = npv + nl, gp + gl
    acierto = g_val / n_val if n_val else 0.0
    elegir = min(VAL_ELEGIR, minimo_cliente) if minimo_cliente else VAL_ELEGIR
    if ne < VAL_ELEGIR_MIN or ge / ne < elegir:
        return False, acierto, n_val
    if n_val < VAL_PRUEBA_MIN or acierto < VAL_PRUEBA:
        return False, acierto, n_val
    ult = real_e[-50:]
    if len(ult) >= 30 and sum(ult) / len(ult) < VAL_REAL_MALO:
        return False, acierto, n_val
    return True, acierto, n_val


def ciclo_reciente(cerradas, fn, velas_ciclo):
    """Cómo le fue a la estrategia en las últimas `velas_ciclo` velas (el momento actual del par).
    Devuelve (señales, ganadas) de la entrada sin gale."""
    total = len(cerradas)
    inicio = max(VENTANA, total - 1 - int(velas_ciclo))
    n = g = 0
    for i in range(inicio, total - 1):
        d = fn(cerradas[i - VENTANA + 1: i + 1])
        if not d: continue
        n += 1
        if color(cerradas[i + 1]) == (1 if d == "call" else -1):
            g += 1
    return n, g



def acierto_confiable(ganadas, total, z=1.64):
    """Acierto 'seguro' (límite inferior de Wilson, 90 %): castiga los porcentajes con pocas señales.
    Ej.: 8 de 8 (100 %) da 75 %, mientras que 45 de 50 (90 %) da 81 %: la segunda es más confiable."""
    if total <= 0:
        return 0.0
    p = ganadas / total
    den = 1 + z * z / total
    centro = p + z * z / (2 * total)
    margen = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total))
    return max(0.0, (centro - margen) / den)

def valor_esperado(wr0, wr1, payout, con_gale):
    """Ganancia esperada por cada $1 de entrada base."""
    if not con_gale:
        return wr0 * payout - (1 - wr0)
    m2 = (1 + payout) / payout                 # gale automático
    p_g2 = max(0.0, wr1 - wr0); p_l = 1 - wr1
    return wr0 * payout + p_g2 * (m2 * payout - 1) - p_l * (1 + m2)

# =====================================================================
#  INTELIGENCIA LS: aprende de cada señal (simulada y real) y filtra las que suelen perder
# =====================================================================
#  Cómo funciona:
#   - Cada vez que una estrategia da señal, se anota "cómo estaba el mercado" (rasgos): estrategia, par,
#     temporalidad, hora, fuerza de la vela, tendencia, volatilidad, lateralidad, RSI, payout...
#   - Cuando esa vela cierra se sabe si habría ganado o perdido, y la IA suma ese resultado a cada rasgo.
#     Las operaciones REALES pesan el triple.
#   - Antes de entrar, la IA estima la probabilidad de ganar con lo que aprendió de situaciones parecidas.
#     Si el contexto suele perder, bloquea la entrada; si suele ganar, la pone primero.
#   - Lo aprendido (conteos por rasgo) ocupa pocos MB y NUNCA se borra. Las muestras en bruto van a un
#     archivo con tope fijo que se reescribe por encima (lo más viejo, que ya fue aprendido).

IA_ARCHIVO = os.path.join(DATOS, "ia_ls.json")
IA_MUESTRAS = os.path.join(DATOS, "ia_muestras.jsonl")
IA_TOPE_MUESTRAS = 30 * 1024 * 1024        # tope del archivo de muestras en bruto (se reescribe al llenarse)
IA_TOPE_CONTEOS = 3_000_000                # al pasar este total se reescala (mantiene lo aprendido)


def _logit(p):
    p = min(0.99, max(0.01, p))
    return math.log(p / (1 - p))


def _tramo(v, cortes, nombres):
    for c, n in zip(cortes, nombres):
        if v < c:
            return n
    return nombres[-1]


def tramo_sent(animo, d):
    """animo = fracción de traders de IQ Option comprando CALL. Devuelve si la señal va con la mayoría o en contra."""
    if animo is None:
        return None
    a_favor = animo if d == "call" else 1 - animo
    return "favor" if a_favor >= 0.65 else ("contra" if a_favor <= 0.35 else "neutral")


def _adx(c, n=14):
    """ADX de Wilder: fuerza de la tendencia (sin importar la dirección)."""
    if len(c) < 2 * n + 1:
        return None
    trs, pdm, mdm = [], [], []
    for a, b in zip(c[-2 * n - 1:-1], c[-2 * n:]):
        up, dn = b["h"] - a["h"], a["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0); mdm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(b["h"] - b["l"], abs(b["h"] - a["c"]), abs(b["l"] - a["c"])))
    dxs = []
    for i in range(n, len(trs) + 1):
        tr = sum(trs[i - n:i])
        if tr <= 0:
            continue
        pdi, mdi = 100 * sum(pdm[i - n:i]) / tr, 100 * sum(mdm[i - n:i]) / tr
        if pdi + mdi > 0:
            dxs.append(100 * abs(pdi - mdi) / (pdi + mdi))
    return sum(dxs) / len(dxs) if dxs else None


def indicadores(c, d):
    """Indicadores técnicos clásicos, contados a favor o en contra de la dirección de la señal."""
    sentido = 1 if d == "call" else -1
    cl = [x["c"] for x in c]
    out = []
    try:
        if len(cl) >= 40:                                            # MACD 12/26/9
            e12, e26 = ema_series(cl, 12), ema_series(cl, 26)
            macd = [a - b for a, b in zip(e12, e26) if a is not None and b is not None]
            sig = ema_series(macd, 9) if len(macd) >= 10 else [None]
            if sig[-1] is not None:
                h = (macd[-1] - sig[-1]) * sentido
                out.append(f"macd:{'favor' if h > 0 else 'contra'}")
        es = estocastico(c, 14, 3)                                   # estocástico
        if es:
            k = es[2]
            out.append("sto:" + ("bajo" if k < 20 else "alto" if k > 80 else "medio"))
        b = bollinger(cl, 20, 2.0)                                   # posición en Bollinger
        if b and b[2] > b[0]:
            pb = (cl[-1] - b[0]) / (b[2] - b[0])
            pb = pb if sentido == 1 else 1 - pb
            out.append("bb:" + ("abajo" if pb < 0.2 else "arriba" if pb > 0.8 else "medio"))
        a = _adx(c)                                                  # fuerza de tendencia
        if a is not None:
            out.append("adx:" + ("debil" if a < 20 else "fuerte" if a > 35 else "media"))
        e50 = ema(cl, 50)                                            # lado de la EMA 50
        if e50 is not None:
            out.append(f"e50:{'favor' if (cl[-1] - e50) * sentido > 0 else 'contra'}")
        racha = 1                                                    # velas seguidas del mismo color
        col = color(c[-1])
        for x in reversed(c[:-1]):
            if col != 0 and color(x) == col: racha += 1
            else: break
        out.append(f"racha:{min(racha, 4)}{'f' if col == sentido else 'c'}")
    except Exception:
        pass
    return out


def rasgos_mercado(c, par, tf, d, nombre, wr0, payout, inicio, animo=None):
    """Rasgos de la situación en que una estrategia da señal (las claves que la IA aprende)."""
    v = c[-1]
    rango = v["h"] - v["l"]
    cuerpo = abs(v["c"] - v["o"])
    prom = sum(abs(x["c"] - x["o"]) for x in c[-11:-1]) / 10 if len(c) >= 11 else 0
    rangos = [x["h"] - x["l"] for x in c]
    atr14 = sum(rangos[-14:]) / max(1, len(rangos[-14:]))
    atr_l = sum(rangos[-60:]) / max(1, len(rangos[-60:]))
    cierres = [x["c"] for x in c]
    e = ema_series(cierres, 20)
    pend = 0.0
    if e[-1] is not None and e[-6] is not None and atr14 > 0:
        pend = (e[-1] - e[-6]) / atr14
    sentido = 1 if d == "call" else -1
    tend = "plana" if abs(pend) < 0.3 else ("favor" if pend * sentido > 0 else "contra")
    w = cierres[-16:]
    mov = sum(abs(w[i] - w[i - 1]) for i in range(1, len(w)))
    efic = abs(w[-1] - w[0]) / mov if mov > 0 else 0
    r = rsi(cierres[-40:], 14)
    otc = "otc" if "OTC" in par.upper() else "real"
    hora = time.localtime(inicio).tm_hour
    cu = _tramo(cuerpo / rango if rango > 0 else 0, (0.3, 0.5, 0.7), ("c0", "c1", "c2", "c3"))
    ta = _tramo(cuerpo / prom if prom > 0 else 1, (0.8, 1.5), ("chica", "normal", "grande"))
    vo = _tramo(atr14 / atr_l if atr_l > 0 else 1, (0.7, 1.3), ("baja", "normal", "alta"))
    ef = _tramo(efic, (0.2, 0.4), ("lateral", "media", "tendencia"))
    rs = "na" if r is None else _tramo(r, (30, 45, 55, 70), ("<30", "30-45", "45-55", "55-70", ">70"))
    wr = _tramo(wr0, (0.80, 0.85), ("75-80", "80-85", "85+"))
    py = _tramo(payout or 0, (0.80, 0.87), ("<80", "80-87", "87+"))
    return [f"e:{nombre}", f"tf:{tf}", f"m:{otc}", f"h:{hora}", f"cu:{cu}", f"ta:{ta}", f"tr:{tend}",
            f"vo:{vo}", f"ef:{ef}", f"rs:{rs}", f"wr:{wr}", f"py:{py}", f"d:{d}", f"p:{par}",
            f"e|p:{nombre}|{par}", f"e|tf:{nombre}|{tf}", f"e|tr:{nombre}|{tend}", f"e|vo:{nombre}|{vo}",
            f"e|cu:{nombre}|{cu}", f"e|ef:{nombre}|{ef}", f"e|h:{nombre}|{hora}", f"e|m:{nombre}|{otc}"] + \
           [x for i in indicadores(c, d) for x in (i, "e|{}:{}|{}".format(*i.split(":", 1)[:1], nombre, i.split(":", 1)[1]))] + \
           ([f"st:{tramo_sent(animo, d)}", f"e|st:{nombre}|{tramo_sent(animo, d)}"] if animo is not None else [])


class InteligenciaLS:
    """Registro de señales: guarda cada señal resuelta (sus rasgos y si ganó) para revisar y exportar."""
    def __init__(self):
        self.lock = threading.Lock()
        self.d = {"v": 1, "total": 0.0, "ganadas": 0.0, "c": {}}
        self.cambios = 0
        self.t_guardado = time.time()
        try:
            if os.path.exists(IA_ARCHIVO):
                with open(IA_ARCHIVO, encoding="utf-8") as f:
                    d = json.load(f)
            else:
                d = {}
            if isinstance(d.get("c"), dict):
                self.d.update(d)
            for k in ("reg", "horas", "sent", "estr", "hoy"):   # datos de versiones anteriores que ya no se usan
                self.d.pop(k, None)
        except Exception:
            pass

    # ---------- aprender ----------
    def aprender(self, claves, gano, peso=1.0, extra=None):
        with self.lock:
            c = self.d["c"]
            self.d["total"] += peso
            self.d["ganadas"] += peso if gano else 0
            for k in claves:
                x = c.get(k)
                if x is None:
                    x = c[k] = [0.0, 0.0]
                x[0] += peso if gano else 0
                x[1] += peso
            if self.d["total"] > IA_TOPE_CONTEOS:       # reescala: mismas proporciones, sigue aprendiendo
                self.d["total"] /= 2; self.d["ganadas"] /= 2
                for x in c.values():
                    x[0] /= 2; x[1] /= 2
            self.cambios += 1
        try:
            fila = {"t": int(time.time()), "g": int(bool(gano)), "p": peso, "k": claves}
            if extra: fila.update(extra)
            with open(IA_MUESTRAS, "a", encoding="utf-8") as f:
                f.write(json.dumps(fila, separators=(",", ":")) + "\n")
        except Exception:
            pass

    def _rotar_muestras(self):
        """El archivo de muestras tiene tope fijo: al llenarse se queda con la mitad más nueva."""
        try:
            if os.path.getsize(IA_MUESTRAS) <= IA_TOPE_MUESTRAS:
                return
            with open(IA_MUESTRAS, "rb") as f:
                f.seek(-IA_TOPE_MUESTRAS // 2, os.SEEK_END)
                resto = f.read()
            resto = resto[resto.find(b"\n") + 1:]
            tmp = IA_MUESTRAS + ".tmp"
            with open(tmp, "wb") as f:
                f.write(resto)
            os.replace(tmp, IA_MUESTRAS)
        except Exception:
            pass

    def guardar(self, forzar=False):
        if not forzar and (not self.cambios or time.time() - self.t_guardado < 300):
            return
        with self.lock:
            datos = json.dumps(self.d, separators=(",", ":"))
            self.cambios = 0
        self.t_guardado = time.time()
        try:
            os.makedirs(DATOS, exist_ok=True)
            tmp = IA_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datos)
            os.replace(tmp, IA_ARCHIVO)
        except Exception:
            pass
        self._rotar_muestras()


_IA = None
_IA_LOCK = threading.Lock()


def inteligencia():
    """Una sola IA por programa (la comparten todas las sesiones)."""
    global _IA
    with _IA_LOCK:
        if _IA is None:
            _IA = InteligenciaLS()
        return _IA


# =====================================================================
#  ESTADO DEL MERCADO (cada 15 minutos): avisa cuando no conviene operar
# =====================================================================


def eficiencia(velas):
    """0 = lateral (va y viene sin avanzar), 1 = tendencia limpia."""
    w = [v["c"] for v in velas]
    mov = sum(abs(w[i] - w[i - 1]) for i in range(1, len(w)))
    return abs(w[-1] - w[0]) / mov if mov > 0 else 0.0


def vela_debil(v, prom):
    rango = v["h"] - v["l"]
    cuerpo = abs(v["c"] - v["o"])
    return rango <= 0 or cuerpo / rango < 0.35 or (prom > 0 and cuerpo < 0.6 * prom)


VELAS_VIVO = 12            # la operación abierta se dibuja siempre con 12 velas que se van llenando


# =====================================================================
#  RÉGIMEN DEL MERCADO (cómo está cada par): dato que reciben las IAs y el aviso de mercado
# =====================================================================
REGIMENES = {"tendencia": "Tendencia", "normal": "Normal", "lateral": "Lateral", "explosivo": "Explosivo",
             "muerto": "Sin movimiento"}


def regimen(velas):
    """tendencia (avanza limpio) · lateral (va y viene) · explosivo (velas enormes) · muerto (doji, sin rango)."""
    if len(velas) < 30:
        return None
    rangos = [v["h"] - v["l"] for v in velas]
    atr14 = sum(rangos[-14:]) / 14
    atr_l = sum(rangos[-60:]) / len(rangos[-60:])
    ratio = atr14 / atr_l if atr_l > 0 else 1.0
    ult = velas[-10:]
    debiles = 0
    for i in range(len(velas) - 10, len(velas)):
        prom = sum(abs(x["c"] - x["o"]) for x in velas[max(0, i - 10):i]) / 10
        debiles += vela_debil(velas[i], prom)
    if ratio > 1.6:
        return "explosivo"
    if ratio < 0.5 or debiles >= 8:
        return "muerto"
    ef = eficiencia(velas[-16:])
    if ef >= 0.35:
        return "tendencia"
    if ef < 0.12:
        return "lateral"           # va y viene sin avanzar (de verdad, no el vaivén normal de M1)
    return "normal"


# =====================================================================
#  TENDENCIA (velas cerradas): decide la dirección de las recuperaciones y es la IA 4
# =====================================================================
TEND_VELAS = 50                # velas que mira
TEND_ADX_FUERTE = 25           # ADX desde el que la tendencia se considera fuerte
TEND_ADX_MIN = 20              # por debajo: mercado lateral
TEND_PENDIENTE = 0.15          # la media de 20 tiene que avanzar al menos 0,15 ATR en 5 velas


def tendencia(velas):
    """Tendencia real del par con velas CERRADAS: media de 20 (dirección y pendiente), fuerza ADX y las últimas
    3 velas. Devuelve {"dir": "call"/"put"/None, "fuerza": "fuerte"/"debil"/"lateral", "adx", "txt"}."""
    v = velas[-TEND_VELAS:]
    if len(v) < 30:
        return {"dir": None, "fuerza": "lateral", "adx": None, "txt": "pocas velas"}
    cierres = [x["c"] for x in v]
    serie = ema_series(cierres, 20)
    atr = _atr(v)
    adx = _adx(v)
    if serie[-1] is None or serie[-6] is None or atr <= 0 or adx is None:
        return {"dir": None, "fuerza": "lateral", "adx": adx, "txt": "sin datos"}
    pendiente = (serie[-1] - serie[-6]) / atr
    lado = cierres[-1] - serie[-1]
    d = "call" if pendiente > 0 and lado > 0 else "put" if pendiente < 0 and lado < 0 else None
    signo = 1 if d == "call" else -1
    a_favor = sum(1 for x in v[-3:] if color(x) == signo) if d else 0
    if d is None or adx < TEND_ADX_MIN or abs(pendiente) < TEND_PENDIENTE:
        fuerza = "lateral"
    elif adx >= TEND_ADX_FUERTE and a_favor >= 2:
        fuerza = "fuerte"
    else:
        fuerza = "debil"
    nombre = "lateral, sin tendencia clara" if fuerza == "lateral" else f"{'alcista' if d == 'call' else 'bajista'} {fuerza}"
    txt = f"{nombre} · ADX {adx:.0f} · media 20 {pendiente:+.2f} ATR"
    return {"dir": d if fuerza != "lateral" else None, "fuerza": fuerza, "adx": adx, "txt": txt}


def tramo_tendencia(t, d):
    """Cómo queda la señal respecto a la tendencia de su par."""
    if not t or t["fuerza"] == "lateral" or not t["dir"]:
        return "lateral"
    a_favor = t["dir"] == d
    if t["fuerza"] == "fuerte":
        return "a_favor_fuerte" if a_favor else "contra_fuerte"
    return "a_favor" if a_favor else "contra"


REC_DESCANSO_SEG = 900         # un par que pierde 2 veces en el mismo ciclo descansa 15 min
REC_MAX_PERDIDAS_PAR = 2       # nunca más de 2 pérdidas seguidas en el mismo par dentro de un ciclo


def lectura_recuperacion(velas, d, perdidas_par):
    """Recuperación automática. Se decide con la vela que ACABA de perder ya cerrada, mirando dos cosas:
      · corto plazo: cómo cerró la vela perdedora (fuerte en contra o solo mecha), las 3 últimas velas y la media de 5
      · fondo: la tendencia de 20 velas (tendencia())
    Devuelve (acción, dirección, motivo) con acción = "gale" (sigue), "invertir" (mismo par, al revés) o "nivel" (otro par)."""
    if perdidas_par >= REC_MAX_PERDIDAS_PAR:
        return "nivel", None, f"ya perdió {perdidas_par} veces en este par: se recupera en otro par"
    if len(velas) < 30:
        return "nivel", None, "pocas velas para leer el par"
    s = 1 if d == "call" else -1
    otra = "put" if d == "call" else "call"
    L = velas[-1]
    cuerpo, rango, atr = abs(L["c"] - L["o"]), L["h"] - L["l"], _atr(velas[:-1]) or 1e-12
    fuerte_contra = color(L) == -s and rango > 0 and cuerpo >= 0.5 * rango and cuerpo >= 0.5 * atr
    mecha = color(L) == -s and not fuerte_contra
    e5 = ema_series([v["c"] for v in velas[-30:]], 5)
    lado5 = 1 if L["c"] > e5[-1] else -1
    pend5 = 1 if e5[-1] > e5[-3] else -1 if e5[-1] < e5[-3] else 0
    corto = lado5 if lado5 == pend5 else 0                      # dirección de corto plazo (0 = indeciso)
    contra3 = sum(1 for v in velas[-3:] if color(v) == -s)
    t = tendencia(velas)
    fondo = 1 if t["dir"] == "call" else -1 if t["dir"] == "put" else 0
    nombre = lambda x: "CALL" if x == 1 else "PUT"
    det = (f"vela perdedora {'fuerte en contra' if fuerte_contra else 'con mecha / débil' if mecha else 'neutra'}"
           f" · corto plazo {nombre(corto) if corto else 'indeciso'} · {contra3}/3 velas en contra · fondo {t['txt']}")
    # 1) el mercado ya giró en corto plazo y el fondo no lo contradice con fuerza: se invierte la señal
    giro = (fuerte_contra and contra3 >= 2) or (fondo == -s and (fuerte_contra or contra3 >= 2))
    if corto == -s and giro and not (fondo == s and t["fuerza"] == "fuerte"):
        return "invertir", otra, det
    # 2) corto plazo y fondo siguen a favor y la pérdida fue un retroceso (mecha/débil): se sigue en la misma dirección
    if corto != -s and fondo == s and not fuerte_contra:
        return "gale", d, det
    # 3) lecturas que se contradicen o par lateral: recuperar en otro par a favor de su tendencia
    return "nivel", None, det


# =====================================================================
#  IA 5: RED NEURONAL (perceptrón de 2 capas, Python puro: corre igual en PC y celular)
# =====================================================================
RED_ARCHIVO = os.path.join(DATOS, "ia_red.json")
RED_VELAS = 30                 # velas que mira la red
RED_OCULTAS = 16               # neuronas de la capa oculta
RED_ENTRADAS = RED_VELAS * 3 + 3
RED_MUESTRAS = 4000            # ejemplos por entrenamiento (de los historiales que el bot ya descargó)
RED_EPOCAS = 6
RED_TASA = 0.02
RED_CADA_SEG = 45 * 60         # se reentrena cada 45 minutos para adaptarse al mercado del momento


def rasgos_red(v):
    """93 números de las últimas 30 velas: cuerpo, mecha superior e inferior (en ATR), RSI, distancia a la media 20 y ADX."""
    v = v[-RED_VELAS - 20:]
    if len(v) < RED_VELAS + 15:
        return None
    w = v[-RED_VELAS:]
    atr = _atr(v, 20)
    if atr <= 0:
        return None
    x = []
    for c in w:
        x.append(max(-3.0, min(3.0, (c["c"] - c["o"]) / atr)))
        x.append(min(3.0, (c["h"] - max(c["o"], c["c"])) / atr))
        x.append(min(3.0, (min(c["o"], c["c"]) - c["l"]) / atr))
    cierres = [c["c"] for c in v]
    r = rsi(cierres, 14)
    m = ema(cierres, 20)
    a = _adx(v)
    x.append(((r if r is not None else 50.0) - 50.0) / 50.0)
    x.append(max(-3.0, min(3.0, (cierres[-1] - m) / atr)) if m is not None else 0.0)
    x.append(((a if a is not None else 20.0) - 20.0) / 30.0)
    return x


class RedNeuronal:
    """Aprende de las velas de todos los pares si la vela siguiente cierra arriba o abajo. Se mide con velas que
    NO vio al entrenar; su opinión solo pesa si la Juez comprueba que acierta más que el promedio."""

    def __init__(self):
        self.lock = threading.Lock()
        self.w1 = self.b1 = self.w2 = None
        self.b2 = 0.0
        self.t = 0
        self.medida = None          # {"n", "acierto", "promedio"} con velas no vistas
        self.entrenando = False
        try:
            with open(RED_ARCHIVO, encoding="utf-8") as f:
                d = json.load(f)
            if len(d.get("w1", [])) == RED_OCULTAS and len(d["w1"][0]) == RED_ENTRADAS:
                self.w1, self.b1, self.w2, self.b2 = d["w1"], d["b1"], d["w2"], d["b2"]
                self.t, self.medida = d.get("t", 0), d.get("medida")
        except Exception:
            pass

    @property
    def lista(self):
        return self.w1 is not None

    def _adelante(self, x, w1, b1, w2, b2):
        h = [math.tanh(sum(wi * xi for wi, xi in zip(fila, x)) + bi) for fila, bi in zip(w1, b1)]
        z = sum(wi * hi for wi, hi in zip(w2, h)) + b2
        return h, 1 / (1 + math.exp(-max(-30.0, min(30.0, z))))

    def p_sube(self, velas):
        if not self.lista:
            return None
        x = rasgos_red(velas)
        if x is None:
            return None
        with self.lock:
            return self._adelante(x, self.w1, self.b1, self.w2, self.b2)[1]

    def debe_entrenar(self):
        return not self.entrenando and time.time() - self.t > RED_CADA_SEG

    def entrenar(self, historiales, libre=lambda: True, detener=lambda: False):
        """historiales: listas de velas cerradas por par. Lo más reciente de cada par se guarda para medirla."""
        if self.entrenando:
            return
        self.entrenando = True
        try:
            # se eligen las velas al azar ANTES de calcular sus rasgos (con muchos pares sería muy lento calcularlas todas)
            cand_e, cand_p = [], []
            for h, velas in enumerate(historiales):
                if len(velas) < RED_VELAS + 60:
                    continue
                corte = int(len(velas) * 0.8)                 # lo más reciente de cada par se guarda para medirla
                for i in range(RED_VELAS + 20, len(velas) - 1):
                    (cand_e if i + 1 < corte else cand_p).append((h, i))
            rnd0 = random.Random()
            cand_e = rnd0.sample(cand_e, min(len(cand_e), int(RED_MUESTRAS * 1.15)))
            cand_p = rnd0.sample(cand_p, min(len(cand_p), 1700))
            entren, prueba = [], []
            for lista_c, destino in ((cand_e, entren), (cand_p, prueba)):
                for j, (h, i) in enumerate(lista_c):
                    velas = historiales[h]
                    sig = color(velas[i + 1])
                    if sig == 0:
                        continue
                    x = rasgos_red(velas[max(0, i + 1 - RED_VELAS - 20):i + 1])
                    if x is not None:
                        destino.append((x, 1.0 if sig == 1 else 0.0))
                    if j % 50 == 0:
                        while not libre():
                            time.sleep(0.5)
                        time.sleep(0)
            if len(entren) < 800 or len(prueba) < 200:
                return
            entren = entren[:RED_MUESTRAS]
            rnd = random.Random(7)
            if self.lista:                                    # sigue desde lo que ya sabía
                w1 = [fila[:] for fila in self.w1]; b1 = self.b1[:]; w2 = self.w2[:]; b2 = self.b2
            else:
                esc = 1 / math.sqrt(RED_ENTRADAS)
                w1 = [[rnd.uniform(-esc, esc) for _ in range(RED_ENTRADAS)] for _ in range(RED_OCULTAS)]
                b1 = [0.0] * RED_OCULTAS
                w2 = [rnd.uniform(-0.3, 0.3) for _ in range(RED_OCULTAS)]
                b2 = 0.0
            for _ in range(RED_EPOCAS):
                if detener():
                    return
                rnd.shuffle(entren)
                for j, (x, y) in enumerate(entren):
                    while not libre():
                        time.sleep(0.5)                       # nunca entrena en los segundos cercanos a un cierre
                    h, p = self._adelante(x, w1, b1, w2, b2)
                    err = p - y
                    for k in range(RED_OCULTAS):
                        g = err * w2[k] * (1 - h[k] * h[k])
                        w2[k] -= RED_TASA * err * h[k]
                        if g:
                            fila = w1[k]
                            for i2, xi in enumerate(x):
                                if xi:
                                    fila[i2] -= RED_TASA * g * xi
                            b1[k] -= RED_TASA * g
                    b2 -= RED_TASA * err
                    if j % 25 == 0:
                        time.sleep(0)
            # medición honesta con velas que no vio: ¿lo que más le gusta gana más que el promedio?
            res = []
            for x, y in prueba:
                p = self._adelante(x, w1, b1, w2, b2)[1]
                res.append((max(p, 1 - p), (p >= 0.5) == (y == 1.0)))
            res.sort(key=lambda r: -r[0])
            mitad = res[:max(1, len(res) // 2)]
            medida = {"n": len(res), "acierto": round(sum(r[1] for r in mitad) / len(mitad), 4),
                      "promedio": round(sum(r[1] for r in res) / len(res), 4)}
            with self.lock:
                self.w1, self.b1, self.w2, self.b2 = w1, b1, w2, b2
                self.t, self.medida = time.time(), medida
            self.guardar()
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] red neuronal\n{traceback.format_exc()}")
        finally:
            self.entrenando = False
            self.t = max(self.t, time.time() - RED_CADA_SEG + 600)   # si falló, reintenta en 10 min

    def guardar(self):
        try:
            os.makedirs(DATOS, exist_ok=True)
            tmp = RED_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2, "t": self.t,
                           "medida": self.medida}, f, separators=(",", ":"))
            os.replace(tmp, RED_ARCHIVO)
        except Exception:
            pass


# =====================================================================
#  IA 3: RED DE SEÑALES (perceptrón de 2 capas que aprende del RESULTADO REAL de cada señal)
#  Mira la estrategia, su catálogo, la tendencia, el contexto de 5 minutos, la hora, el pago y lo que dice
#  la red de velas. Aprende de a poco con cada señal resuelta (no frena al bot, tampoco en el celular).
# =====================================================================
RS_ARCHIVO = os.path.join(DATOS, "ia_red_senales.json")
RS_OCULTAS = 12
RS_TASA = 0.01
TRAMOS = ("a_favor_fuerte", "a_favor", "lateral", "contra", "contra_fuerte")
RS_ESTR = None                 # orden fijo de las estrategias (se arma al primer uso)


def rasgos_senal(velas, d, nombres, wr300, conf500, wr500, wr_g1, tnd, tramo, p_red, payout, hora):
    """Vector de la señal (todo dirigido a su lado: positivo = a favor de la entrada)."""
    global RS_ESTR
    if RS_ESTR is None:
        RS_ESTR = {n: i for i, n in enumerate(sorted(n for n in ESTRATEGIAS if n not in ESTRATEGIAS_V2))}
    x = [0.0] * len(RS_ESTR)
    for n in nombres:
        if n in RS_ESTR:
            x[RS_ESTR[n]] = 1.0
    x.append(min(5, len(nombres)) / 5)
    x += [(wr300 - 0.5) * 4, (conf500 - 0.5) * 4, (wr500 - 0.5) * 4, (wr_g1 - 0.5) * 2]
    x += [1.0 if tramo == t else 0.0 for t in TRAMOS]
    x.append(((tnd or {}).get("adx") or 20.0) / 50.0)
    x.append(((p_red if p_red is not None else 0.5) - 0.5) * 4)
    signo = 1 if d == "call" else -1
    cerradas = velas[:-1]
    atr = _atr(cerradas, 20) or 1e-9
    m5 = []
    for k in range(6):                                  # últimas 6 velas de 5 minutos (armadas con las de 1 minuto)
        g = cerradas[len(cerradas) - 5 * (k + 1): len(cerradas) - 5 * k] if len(cerradas) >= 5 * (k + 1) else []
        m5.append(max(-3.0, min(3.0, signo * (g[-1]["c"] - g[0]["o"]) / (atr * 2.2))) if g else 0.0)
    x += m5
    x += [math.sin(2 * math.pi * hora / 24), math.cos(2 * math.pi * hora / 24), (payout - 0.8) * 5]
    return x


class RedSenales:
    def __init__(self):
        self.lock = threading.Lock()
        self.w1 = self.b1 = self.w2 = None
        self.b2 = 0.0
        self.n = 0
        self.cambios = 0
        self.t_guardado = time.time()
        try:
            with open(RS_ARCHIVO, encoding="utf-8") as f:
                d = json.load(f)
            self.w1, self.b1, self.w2, self.b2, self.n = d["w1"], d["b1"], d["w2"], d["b2"], d.get("n", 0)
        except Exception:
            pass

    def _iniciar(self, n_ent):
        rnd = random.Random(11)
        esc = 1 / math.sqrt(n_ent)
        self.w1 = [[rnd.uniform(-esc, esc) for _ in range(n_ent)] for _ in range(RS_OCULTAS)]
        self.b1 = [0.0] * RS_OCULTAS
        self.w2 = [rnd.uniform(-0.3, 0.3) for _ in range(RS_OCULTAS)]
        self.b2 = 0.0
        self.n = 0

    def _adelante(self, x):
        h = [math.tanh(sum(wi * xi for wi, xi in zip(fila, x) if xi) + bi) for fila, bi in zip(self.w1, self.b1)]
        z = sum(wi * hi for wi, hi in zip(self.w2, h)) + self.b2
        return h, 1 / (1 + math.exp(-max(-30.0, min(30.0, z))))

    def prob(self, x):
        """Probabilidad de que la señal gane (None mientras aprende sus primeras 300 señales)."""
        with self.lock:
            if self.w1 is None or len(self.w1[0]) != len(x) or self.n < 300:
                return None
            return self._adelante(x)[1]

    def aprender(self, x, gano):
        y = 1.0 if gano else 0.0
        with self.lock:
            if self.w1 is None or len(self.w1[0]) != len(x):
                self._iniciar(len(x))
            h, p = self._adelante(x)
            err = p - y
            for k in range(RS_OCULTAS):
                g = err * self.w2[k] * (1 - h[k] * h[k])
                self.w2[k] -= RS_TASA * err * h[k]
                if g:
                    fila = self.w1[k]
                    for i, xi in enumerate(x):
                        if xi:
                            fila[i] -= RS_TASA * g * xi
                    self.b1[k] -= RS_TASA * g
            self.b2 -= RS_TASA * err
            self.n += 1
            self.cambios += 1

    def guardar(self, forzar=False):
        if self.w1 is None or (not forzar and (not self.cambios or time.time() - self.t_guardado < 300)):
            return
        with self.lock:
            datos = json.dumps({"w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2, "n": self.n},
                               separators=(",", ":"))
            self.cambios = 0
        self.t_guardado = time.time()
        try:
            os.makedirs(DATOS, exist_ok=True)
            tmp = RS_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datos)
            os.replace(tmp, RS_ARCHIVO)
        except Exception:
            pass


# =====================================================================
#  EQUIPO DE IAs: cada una hace un trabajo real y se mide con señales que todavía no había visto
#    1 Pares · 2 Estrategias · 3 Red de señales · 4 Tendencia · 5 Red de velas · Juez (las junta)
# =====================================================================
EQUIPO_ARCHIVO = os.path.join(DATOS, "ia_equipo.json")
EQ_PARES = 40                  # últimas señales por par
EQ_ESTR = 50                   # últimas señales por estrategia
EQ_PREVIA = 10                 # peso del promedio mientras hay pocos datos
EQ_EVAL = 1500                 # cada IA se juzga por sus últimas 1.500 opiniones
EQ_MIN = 200                   # opiniones mínimas antes de medirla
JUEZ_LIFT = 0.02               # la Juez manda en el orden solo si lo que aprueba gana 2+ puntos más que el promedio
JUEZ_TASA = 0.02
NOMBRES_IA = ("pares", "estrategias", "senales", "tendencia", "red")


def _medir(ev):
    """ev: [(p, base, ganó)]. Acierto de lo que la IA aprueba (p > base) contra el promedio."""
    if len(ev) < EQ_MIN:
        return None
    ap = [(y) for p, b, y in ev if p > b]
    prom = sum(y for _, _, y in ev) / len(ev)
    if not ap:
        return {"n": len(ev), "aprobadas": 0, "acierto": None, "promedio": round(prom, 4)}
    return {"n": len(ev), "aprobadas": len(ap), "acierto": round(sum(ap) / len(ap), 4), "promedio": round(prom, 4)}


class EquipoIA:
    def __init__(self):
        self.lock = threading.Lock()
        self.d = {"v": 2, "pares": {}, "estr": {}, "tend": {}, "g": 0.0, "n": 0.0,
                  "juez": [0.0] * (len(NOMBRES_IA) + 1), "eval": {k: [] for k in NOMBRES_IA + ("juez",)}}
        self.cambios = 0
        self.t_guardado = time.time()
        try:
            with open(EQUIPO_ARCHIVO, encoding="utf-8") as f:
                d = json.load(f)
            for k in self.d:
                if k in d:
                    self.d[k] = d[k]
            if d.get("v") != 2:                          # antes la IA 3 era "Horario": su lugar empieza de cero
                self.d["v"] = 2
                self.d["juez"] = [0.0] * (len(NOMBRES_IA) + 1)
                self.d["eval"].pop("horario", None)
            for k in NOMBRES_IA + ("juez",):
                self.d["eval"].setdefault(k, [])
            if len(self.d["juez"]) != len(NOMBRES_IA) + 1:
                self.d["juez"] = [0.0] * (len(NOMBRES_IA) + 1)
        except Exception:
            pass

    # ---------- opiniones ----------
    def base(self):
        return self.d["g"] / self.d["n"] if self.d["n"] >= 50 else 0.5

    def _prob(self, g, n):
        return (g + EQ_PREVIA * self.base()) / (n + EQ_PREVIA)

    def opiniones(self, par, estrategias, p_senales, tramo, p_red):
        """Probabilidad de ganar según cada IA (None = todavía no sabe)."""
        with self.lock:
            r = self.d["pares"].get(par) or []
            o = {"pares": self._prob(sum(r), len(r)) if len(r) >= 5 else None}
            mej = None
            for e in estrategias:
                r = self.d["estr"].get(e) or []
                if len(r) >= 10:
                    p = self._prob(sum(r), len(r))
                    mej = p if mej is None or p > mej else mej
            o["estrategias"] = mej
            o["senales"] = p_senales
            g, n = self.d["tend"].get(tramo, (0.0, 0.0))
            o["tendencia"] = self._prob(g, n) if n >= 20 else None
            o["red"] = p_red
        return o

    def juez(self, o):
        b = self.base()
        w = self.d["juez"]
        z = w[0] + _logit(b)
        for i, k in enumerate(NOMBRES_IA):
            if o.get(k) is not None:
                z += w[i + 1] * (_logit(o[k]) - _logit(b))
        return 1 / (1 + math.exp(-max(-30.0, min(30.0, z))))

    def juez_lista(self):
        m = _medir(self.d["eval"]["juez"])
        return bool(m and m["acierto"] is not None and m["acierto"] - m["promedio"] >= JUEZ_LIFT)

    # ---------- aprender (señal resuelta) ----------
    def aprender(self, ctx, gano):
        y = 1.0 if gano else 0.0
        with self.lock:
            b = self.base()
            o = ctx.get("o") or {}
            # 1) medir a cada IA con lo que opinaba ANTES de saber el resultado
            for k in NOMBRES_IA:
                if o.get(k) is not None:
                    ev = self.d["eval"][k]; ev.append((round(o[k], 4), round(b, 4), int(gano)))
                    if len(ev) > EQ_EVAL: del ev[:len(ev) - EQ_EVAL]
            pj = self.juez(o)
            ev = self.d["eval"]["juez"]; ev.append((round(pj, 4), round(b, 4), int(gano)))
            if len(ev) > EQ_EVAL: del ev[:len(ev) - EQ_EVAL]
            # 2) la Juez aprende cuánto creerle a cada IA
            err = pj - y
            w = self.d["juez"]
            w[0] -= JUEZ_TASA * err
            for i, k in enumerate(NOMBRES_IA):
                if o.get(k) is not None:
                    w[i + 1] -= JUEZ_TASA * err * (_logit(o[k]) - _logit(b))
                    w[i + 1] = max(-2.0, min(2.0, w[i + 1]))
            # 3) cada IA guarda el dato que le toca
            r = self.d["pares"].setdefault(ctx["par"], []); r.append(int(gano))
            if len(r) > EQ_PARES: del r[:len(r) - EQ_PARES]
            for e in ctx.get("estrategias") or []:
                r = self.d["estr"].setdefault(e, []); r.append(int(gano))
                if len(r) > EQ_ESTR: del r[:len(r) - EQ_ESTR]
            tr = ctx.get("tramo", "lateral")
            g, n = self.d["tend"].get(tr, (0.0, 0.0))
            self.d["tend"][tr] = (round(g * 0.995 + y, 3), round(n * 0.995 + 1, 3))   # lo reciente pesa más
            self.d["g"] = self.d["g"] * 0.999 + y
            self.d["n"] = self.d["n"] * 0.999 + 1
            self.cambios += 1
        if ctx.get("x"):
            red_senales().aprender(ctx["x"], gano)       # la red de señales aprende con el resultado real

    def guardar(self, forzar=False):
        if not forzar and (not self.cambios or time.time() - self.t_guardado < 300):
            return
        with self.lock:
            datos = json.dumps(self.d, separators=(",", ":"))
            self.cambios = 0
        self.t_guardado = time.time()
        try:
            os.makedirs(DATOS, exist_ok=True)
            tmp = EQUIPO_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(datos)
            os.replace(tmp, EQUIPO_ARCHIVO)
        except Exception:
            pass

    def resumen(self):
        with self.lock:
            out = {k: _medir(self.d["eval"][k]) for k in NOMBRES_IA + ("juez",)}
            out["juez_lista"] = self.juez_lista()
            out["base"] = round(self.base(), 4)
            out["pesos"] = {k: round(self.d["juez"][i + 1], 2) for i, k in enumerate(NOMBRES_IA)}
            out["datos"] = {"pares": len(self.d["pares"]), "estrategias": len(self.d["estr"]),
                            "tendencia": round(sum(n for _, n in self.d["tend"].values()))}
        r = red()
        out["red"] = dict(out.get("red") or {}, lista=r.lista, entrenando=r.entrenando, medida=r.medida)
        out["senales"] = dict(out.get("senales") or {}, aprendidas=red_senales().n)
        return out


_EQUIPO = None
_RED = None
_RS = None
_EQ_LOCK = threading.Lock()


def equipo():
    global _EQUIPO
    with _EQ_LOCK:
        if _EQUIPO is None:
            _EQUIPO = EquipoIA()
        return _EQUIPO


def red_senales():
    global _RS
    with _EQ_LOCK:
        if _RS is None:
            _RS = RedSenales()
        return _RS


def red():
    global _RED
    with _EQ_LOCK:
        if _RED is None:
            _RED = RedNeuronal()
        return _RED


# =====================================================================
#  ESTADO DEL MERCADO (cada minuto, desde que se inicia sesión)
# =====================================================================
class EstadoMercado:
    """Decide si mostrar el aviso rojo y pausar el bot. Se prende cuando el mercado está malo y se apaga
    cuando vuelve a estar óptimo (o lleva 5 minutos seguidos aceptable)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.aviso = False
        self.operar_igual = False      # el cliente decidió operar aunque el mercado esté malo
        self.racha_viable = 0
        self.ultimo = None             # último diagnóstico
        self.cambio = 0
        self.mejoro_hasta = 0          # aviso verde "mercado óptimo" durante 30 s cuando se recupera

    def actualizar(self, diag):
        with self.lock:
            antes = self.aviso
            n = diag["nivel"]
            if n == "malo":
                self.aviso = True; self.racha_viable = 0
            elif n == "optimo":
                self.aviso = False; self.racha_viable = 0
            else:
                self.racha_viable += 1
                if self.aviso and self.racha_viable >= 5:
                    self.aviso = False
            if not self.aviso:
                self.operar_igual = False   # la próxima vez que se ponga malo vuelve a pausar
            self.ultimo = dict(diag, aviso=self.aviso)
            if antes != self.aviso:
                self.cambio = time.time()
            if antes and not self.aviso:
                self.mejoro_hasta = time.time() + 30
            return antes, self.aviso

    @property
    def pausa(self):
        return self.aviso and not self.operar_igual

    def resumen(self):
        with self.lock:
            if not self.ultimo:
                return {"leyendo": True, "aviso": False}
            return dict(self.ultimo, aviso=self.aviso, operar_igual=self.operar_igual, leyendo=False,
                        mejoro=time.time() < self.mejoro_hasta)


MERCADO = EstadoMercado()


def diagnosticar_mercado(pct_ok, pct_deb, regs, acierto, cfg, n_acierto=0):
    """Junta las mediciones y dice: malo / viable / óptimo, con los motivos en palabras.
    Lo que más pesa es cómo vienen acertando las señales (es lo que de verdad dice si el bot puede ganar)."""
    total = sum(regs.values()) or 1
    lateral = (regs.get("lateral", 0) + regs.get("muerto", 0)) / total
    motivos = []
    muy_malo = acierto is not None and n_acierto >= 20 and acierto < 0.48
    if acierto is not None and n_acierto >= 12 and acierto < 0.53:
        motivos.append(f"señales recientes acertando {acierto*100:.0f} %")
    if lateral >= 0.60:
        motivos.append(f"{lateral*100:.0f} % de los pares de lado a lado o sin movimiento")
    if pct_deb > 0.55:
        motivos.append(f"{pct_deb*100:.0f} % de velas sin cuerpo")
    if pct_ok is not None and pct_ok < 0.05:
        motivos.append(f"casi ningún par tiene estrategias sobre el {cfg['winrate_minimo']*100:.0f} %")
    if muy_malo or len(motivos) >= 2:
        nivel = "malo"
    elif not motivos and lateral < 0.45 and (acierto is None or acierto >= 0.60):
        nivel = "optimo"
    else:
        nivel = "viable"
    dominante = max(regs, key=regs.get) if regs else None
    return {"nivel": nivel, "motivos": motivos, "revisado": time.strftime("%H:%M"),
            "pares_ok": None if pct_ok is None else round(pct_ok, 3), "velas_debiles": round(pct_deb, 3),
            "regimen": dominante, "regimen_txt": REGIMENES.get(dominante, ""),
            "regimen_pct": round(regs.get(dominante, 0) / total, 3) if dominante else None,
            "regimenes": {k: round(v / total, 3) for k, v in regs.items()},
            "acierto": None if acierto is None else round(acierto, 3)}


class MonitorMercado:
    """Lee el mercado cada minuto desde que el cliente inicia sesión (antes de arrancar el bot)."""
    PARES = 15

    def __init__(self, broker, cfg):
        self.b = broker
        self.cfg = cfg
        self.parar = False
        threading.Thread(target=self._hilo, daemon=True).start()

    def _hilo(self):
        while not self.parar:
            t0 = time.time()
            try:
                self.revisar()
            except Exception:
                pass
            while not self.parar and time.time() - t0 < 60:
                time.sleep(1)

    def revisar(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos()
        lista = []
        for par, pays in activos.items():
            otc = par.endswith("-OTC")
            if (otc and not cfg.get("incluir_otc", True)) or (not otc and not cfg.get("incluir_mercado_real", True)):
                continue
            pago = pays.get("turbo") or pays.get("binary") or 0
            if pago >= cfg.get("payout_minimo", 0.8):
                lista.append((pago, par))
        lista.sort(reverse=True)
        regs, ok, total, deb, ndeb = {}, 0, 0, 0, 0
        gan = sen = 0
        for _, par in lista[: self.PARES]:
            if self.parar:
                return
            try:
                velas = self.b.velas(par, 1, 160)
            except Exception:
                continue
            if len(velas) < VENTANA + 40:
                continue
            r = regimen(velas)
            if r:
                regs[r] = regs.get(r, 0) + 1
            for i in range(len(velas) - 15, len(velas)):
                prom = sum(abs(x["c"] - x["o"]) for x in velas[i - 10:i]) / 10
                deb += vela_debil(velas[i], prom); ndeb += 1
            # catalogación rápida con lo viejo y prueba con las últimas 30 velas
            viejas = velas[:-30]
            total += 1
            buena = False
            for nombre, fn in ESTRATEGIAS.items():
                n, g0 = catalogar(viejas, fn)[:2]
                if n >= 8 and g0 / n >= cfg.get("winrate_minimo", 0.75):
                    buena = True
                    for i in range(len(velas) - 31, len(velas) - 1):
                        d = fn(velas[i - VENTANA + 1: i + 1])
                        if d:
                            sen += 1
                            gan += color(velas[i + 1]) == (1 if d == "call" else -1)
            ok += buena
        if not total:
            return
        diag = diagnosticar_mercado(ok / total, deb / ndeb if ndeb else 0.0, regs,
                                    gan / sen if sen >= 12 else None, cfg, sen)
        MERCADO.actualizar(diag)


# =====================================================================
#  CONEXIÓN A IQ OPTION
# =====================================================================

def _mensaje_error_login(motivo):
    """Convierte la respuesta de IQ Option en un mensaje entendible."""
    txt = str(motivo or "")
    try:
        d = json.loads(txt)
        code = str(d.get("code", "")).lower()
        msg = d.get("message") or ""
        if "invalid" in code or "credentials" in txt.lower():
            return "Correo o contraseña incorrectos."
        if "block" in code or "ban" in code:
            return f"IQ Option bloqueó el acceso: {msg}"
        if "limit" in code or "many" in txt.lower():
            return "Demasiados intentos. Espera unos minutos e intenta de nuevo."
        return msg or txt
    except Exception:
        pass
    if "invalid" in txt.lower():
        return "Correo o contraseña incorrectos."
    return txt or "IQ Option rechazó el inicio de sesión."


# =====================================================================
#  LICENCIA (por correo de IQ Option o por ID de cuenta de IQ Option)
# =====================================================================

def _firma_licencia(texto):
    import hmac, hashlib
    return hmac.new(LICENCIA_KEY.encode(), texto.encode(), hashlib.sha256).hexdigest()

def _consultar_licencia(cuenta):
    """Consulta el script. Devuelve 'VALID', 'EXPIRED', otro texto del servidor, o None si no hubo conexión."""
    import requests
    try:
        r = requests.get(LICENCIA_URL, timeout=15, params={
            "cuenta": cuenta, "key": LICENCIA_KEY, "ea": LICENCIA_EA,
            "build": BUILD_BOT, "v": VERSION_BOT})
        if r.status_code != 200:
            return None
        return (r.text or "").strip()[:80]
    except Exception:
        return None

def verificar_licencia(correo, id_iq):
    """(ok, mensaje). Válida si el correo O el ID de IQ Option están registrados y vigentes.
    Sin internet, sigue funcionando hasta LICENCIA_GRACIA horas desde la última verificación correcta."""
    cuentas = [c for c in (str(correo or "").strip().lower(), str(id_iq or "").strip()) if c]
    respuestas, sin_red = {}, False
    for c in cuentas:
        r = _consultar_licencia(c)
        if r is None:
            sin_red = True; continue
        respuestas[c] = r
        if r == "VALID":
            ahora = int(time.time())
            try:
                with open(ARCHIVO_LICENCIA, "w", encoding="utf-8") as f:
                    json.dump({"cuenta": c, "ok": ahora, "firma": _firma_licencia(f"{c}|{ahora}")}, f)
            except Exception:
                pass
            return True, f"Licencia activa ({c})"
    if any(r == "EXPIRED" for r in respuestas.values()):
        return False, "Tu licencia está VENCIDA. Comunícate con tu proveedor para renovarla."
    if sin_red and not respuestas:
        try:
            d = json.load(open(ARCHIVO_LICENCIA, encoding="utf-8"))
            if (d.get("cuenta") in cuentas and d.get("firma") == _firma_licencia(f"{d['cuenta']}|{d['ok']}")
                    and time.time() - int(d["ok"]) <= LICENCIA_GRACIA * 3600):
                horas = (LICENCIA_GRACIA * 3600 - (time.time() - int(d["ok"]))) / 3600
                return True, f"Sin conexión con el servidor de licencias: se usa la última verificación (quedan {horas:.0f} h)."
        except Exception:
            pass
        return False, "No se pudo verificar la licencia (sin conexión con el servidor de licencias)."
    return False, ("Este correo / ID de IQ Option NO tiene licencia para este bot.\n"
                   f"   Correo: {correo}\n   ID de IQ Option: {id_iq or 'no disponible'}\n"
                   "   Envía estos datos a tu proveedor para activarla.")


def _parchear_libreria():
    """La librería trae la función que recibe el historial de opciones cerradas ("options")
    pero nunca la conecta: sin esto el historial no responde jamás. Se conecta aquí."""
    try:
        import iqoptionapi.ws.client as cliente
        if getattr(cliente, "_iqbot_parche", False):
            return
        original = cliente.option
        def option(api, mensaje):
            original(api, mensaje)
            try:
                if mensaje.get("name") == "options":
                    api.get_options_v2_data = mensaje
            except Exception:
                pass
        cliente.option = option
        cliente._iqbot_parche = True
    except Exception:
        pass
    _conexion_segura()


def _conexion_segura():
    """La librería desactiva la verificación de certificados (verify=False / CERT_NONE): en una red
    insegura alguien podría ver la contraseña. Aquí se obliga a verificar los certificados reales
    de IQ Option, tanto en el inicio de sesión como en la conexión en vivo."""
    if not cargar_config().get("verificar_certificados", True):
        return
    try:
        import ssl, certifi, websocket
        import iqoptionapi.api as api_mod
        if getattr(api_mod, "_iqbot_seguro", False):
            return
        ca = certifi.where()
        init_original = api_mod.IQOptionAPI.__init__
        def init_seguro(self, *a, **kw):
            init_original(self, *a, **kw)
            self.session.verify = ca
        api_mod.IQOptionAPI.__init__ = init_seguro
        correr_original = websocket.WebSocketApp.run_forever
        def correr_seguro(self, *a, **kw):
            if "sslopt" in kw:
                kw["sslopt"] = {"cert_reqs": ssl.CERT_REQUIRED, "ca_certs": ca, "check_hostname": True}
            return correr_original(self, *a, **kw)
        websocket.WebSocketApp.run_forever = correr_seguro
        api_mod._iqbot_seguro = True
    except Exception:
        pass


def _esperar(obtener, segundos, paso=0.01):
    """Espera una respuesta SIN consumir procesador (la librería original gira al 100 % y a veces para siempre)."""
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            v = obtener()
        except Exception:
            v = None
        if v is not None:
            return v
        time.sleep(paso)
    return None


class BrokerIQ:
    """Conexión con IQ Option. Usa la librería solo para ENVIAR pedidos y leer respuestas;
    todas las esperas son propias, con límite de tiempo y sin bloquear el PC."""

    def __init__(self, api):
        self.api = api
        self.lock = threading.Lock()          # pedidos de velas (la librería tiene un solo buzón para velas)
        self.lock_compra = threading.Lock()   # compras: turno propio, nunca esperan a las velas
        self.lock_digital = threading.Lock()  # lectura de pagos digitales (un par a la vez)
        self.iconos = {}                      # par -> ícono que manda IQ Option (si lo manda)
        self.pago_digital = {}                # par -> pago de la opción digital (0.87 = 87 %), se refresca solo
        self.digitales = set()                # ids de órdenes digitales (su resultado llega por otro aviso)
        self.cuenta = None
        self.conectado = True
        self.offset = 0.0              # hora del servidor - hora de este PC
        self._muestras = deque(maxlen=40)
        self._ultimo_ts = None
        self.ultimo_latido = time.time()
        self.vivo = {}                 # par -> True si llegan velas en vivo
        self.latencia_compra = 0.25
        self.moneda = "USD"                   # moneda de la cuenta elegida (IQ Option deja depositar en varias)
        self.tasa = 1.0                       # unidades de esa moneda por 1 USD (None = no se pudo leer)
        self.tasa_fuente = ""
        self._crudo = {}                      # tipo de cuenta -> (monto en su moneda, moneda)
        self._req = 0
        threading.Thread(target=self._reloj, daemon=True).start()

    @property
    def inner(self):
        return self.api.api            # cambia en cada reconexión: siempre se lee de nuevo

    @staticmethod
    def _id(par):
        from iqoptionapi import constants as OP
        return OP.ACTIVES.get(par)

    # ---------- inicio de sesión ----------
    @staticmethod
    def iniciar_sesion(email, clave, pedir_codigo):
        """Devuelve (broker, None) o (None, mensaje_de_error)."""
        try:
            from iqoptionapi.stable_api import IQ_Option
            _parchear_libreria()
            api = IQ_Option(email, clave)
        except Exception as e:
            if CONGELADO and _leer_estado_lib().get("estado") == "probando":
                _volver_a_anterior(f"no se pudo cargar: {e}")
                return None, ("La versión nueva de la librería de IQ Option falló y se volvió a la anterior. "
                              "Cierra y abre el bot otra vez.")
            return None, f"No se pudo cargar la librería de IQ Option: {e}"
        try:
            ok, motivo = con_timeout(api.connect, 60)
        except TimeoutError:
            return None, ("IQ Option no respondió. Revisa tu internet; si estás en una red que "
                          "bloquea IQ Option (trabajo, universidad, operador), prueba otra red.")
        except json.JSONDecodeError as e:
            crudo = (getattr(e, "doc", "") or "").strip().replace("\n", " ")[:200]
            return None, ("IQ Option devolvió una respuesta inesperada al iniciar sesión "
                          "(bloqueo de red, captcha o cambio en su sistema). Entra primero desde el "
                          "navegador para confirmar que tu cuenta abre bien."
                          + (f"\n   Respuesta recibida: {crudo}" if crudo else "\n   (no llegó respuesta: posible bloqueo de red)"))
        except Exception as e:
            if "CERTIFICATE" in str(e).upper() or "SSL" in type(e).__name__.upper():
                return None, ("No se pudo verificar la conexión segura con IQ Option (certificado no válido). "
                              "Puede ser una red WiFi pública o un antivirus que revisa las conexiones seguras. "
                              "Prueba con otra red o pausa la revisión HTTPS del antivirus.")
            libreria_conecto(False, culpa_de_libreria=True)
            return None, f"Error de conexión: {e}"
        if not ok and str(motivo) == "2FA":
            codigo = pedir_codigo()
            try:
                ok, motivo = con_timeout(api.connect_2fa, 60, codigo)
            except Exception as e:
                return None, f"Error verificando el código: {e}"
            if not ok:
                return None, f"Código no aceptado: {_mensaje_error_login(motivo)}"
        if not ok:
            return None, _mensaje_error_login(motivo)
        b = BrokerIQ(api)
        libreria_conecto(True)
        try:
            b.activos_abiertos()       # carga los códigos de todos los pares binarios/turbo
        except Exception:
            print("Aviso: no se pudo leer la lista de pares todavía; se reintentará.")
        return b, None

    def id_iq(self):
        """ID de la cuenta de IQ Option (el número de usuario del perfil)."""
        try:
            p = self.inner.profile.msg or {}
            for k in ("user_id", "id"):
                if p.get(k): return str(p[k])
            for b in p.get("balances", []) or []:
                if b.get("user_id"): return str(b["user_id"])
        except Exception:
            pass
        return ""

    # ---------- reloj sincronizado con IQ Option ----------
    def _reloj(self):
        while True:
            try:
                v = self.inner.timesync._TimeSync__server_timestamp
                ts = v / 1000.0 if v else None
            except Exception:
                ts = None
            if ts and ts != self._ultimo_ts:
                self._ultimo_ts = ts
                self.ultimo_latido = time.time()
                self._muestras.append(ts - time.time())
                self.offset = max(self._muestras)
            time.sleep(0.1)

    def ahora(self):
        return time.time() + self.offset


    def esperar_hasta(self, t_servidor, detener=lambda: False):
        while not detener():
            falta = t_servidor - self.ahora()
            if falta <= 0: return True
            time.sleep(min(falta - 0.015, 0.2) if falta > 0.03 else 0.001)
        return False

    # ---------- cuenta ----------
    def saldos(self):
        """{"REAL": (monto, moneda), "PRACTICE": (...)}"""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05)
        if not raw:
            raise TimeoutError("IQ Option no envió los saldos")
        out = {}
        for bal in raw.get("msg", []):
            t = bal.get("type")
            if t not in (1, 4): continue
            monto = _saldo_con_bono(bal)
            self._crudo[t] = (monto, bal.get("currency", "") or "USD", bal.get("equivalent"))
            if t == 1: out["REAL"] = (monto, bal.get("currency", ""))
            if t == 4: out["PRACTICE"] = (monto, bal.get("currency", ""))
        if not getattr(self, "_campos_saldo_vistos", False):     # una vez: deja anotados los campos que manda IQ Option
            self._campos_saldo_vistos = True
            try:
                for bal in raw.get("msg", []):
                    if bal.get("type") == 1:
                        campos = {k: v for k, v in bal.items() if isinstance(v, (int, float)) and k not in ("id", "user_id", "type", "tournament_id")}
                        with open(os.path.join(DATOS, "campos_saldo.log"), "w", encoding="utf-8") as f:
                            f.write(json.dumps(campos, ensure_ascii=False))
            except Exception:
                pass
        return out

    def usar_cuenta(self, cuenta, releer_moneda=True):
        self.cuenta = cuenta
        con_timeout(self.api.change_balance, 30, cuenta)
        try:
            if releer_moneda or self.tasa is None:
                self.preparar_moneda()
        except Exception:
            pass

    # ---------- moneda de la cuenta ----------
    def preparar_moneda(self):
        """Lee la moneda de la cuenta elegida y cuántas unidades de ella vale 1 USD.
        El bot trabaja SIEMPRE en dólares (entrada, stops, P/L); solo la orden y el saldo se convierten.
        La tasa queda fija durante la sesión (así el P/L no 'se mueve' solo por el cambio de moneda)."""
        self.saldos()
        monto, moneda, equivalente = self._crudo.get(1 if self.cuenta == "REAL" else 4, (None, "USD", None))
        moneda = (moneda or "USD").upper()
        self.moneda = moneda
        if moneda == "USD":
            self.tasa, self.tasa_fuente = 1.0, ""
            return
        tasa, fuente = None, ""
        try:                                              # 1) tipo de cambio del día (USD -> moneda)
            import requests
            r = requests.get("https://open.er-api.com/v6/latest/USD", timeout=10)
            v = (r.json().get("rates") or {}).get(moneda)
            if v and float(v) > 0:
                tasa, fuente = float(v), "cambio del día"
        except Exception:
            pass
        if tasa is None:                                  # 2) lo que dice IQ Option: saldo y su equivalente en USD
            try:
                if monto and equivalente and float(monto) > 0 and float(equivalente) > 0:
                    tasa, fuente = float(monto) / float(equivalente), "IQ Option"
            except Exception:
                pass
        self.tasa, self.tasa_fuente = tasa, fuente

    def campos_saldo(self):
        """Campos numéricos que manda IQ Option de cada cuenta (para el diagnóstico)."""
        inner = self.inner
        inner.balances_raw = None
        inner.get_balances()
        raw = _esperar(lambda: inner.balances_raw, 10, 0.05) or {}
        out = []
        for bal in raw.get("msg", []):
            out.append({k: v for k, v in bal.items() if k not in ("id", "user_id") and not isinstance(v, (dict, list))})
        return out

    def a_local(self, usd):
        """Monto en dólares -> monto en la moneda de la cuenta (redondeado como lo acepta IQ Option)."""
        if not self.tasa or self.moneda == "USD":
            return round(float(usd), 2)
        v = float(usd) * self.tasa
        return float(round(v)) if self.tasa >= 50 else round(v, 2)

    def saldo_local(self):
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            return v[0] if v else None
        except Exception:
            return None

    def saldo(self):
        """Saldo en DÓLARES (si la cuenta es de otra moneda, convertido con la tasa de la sesión)."""
        try:
            v = self.saldos().get(self.cuenta or "PRACTICE")
            if not v:
                return "?"
            if self.moneda != "USD":
                return round(float(v[0]) / self.tasa, 2) if self.tasa else "?"
            return v[0]
        except Exception:
            return "?"

    # ---------- conexión ----------
    def salud(self):
        """(ok, motivo). Si el servidor deja de mandar la hora, se le hace una consulta real antes de darlo por caído."""
        try:
            if not self.api.check_connect():
                return False, "conexión cerrada"
        except Exception as e:
            return False, f"error de conexión ({e})"
        if time.time() - self.ultimo_latido > 25:
            try:
                self.saldos()                     # consulta real
                self.ultimo_latido = time.time()
            except Exception:
                return False, "IQ Option dejó de responder"
        return True, ""

    def reconectar(self):
        """Reconecta sin re-suscribir nada dentro de la librería (eso la colgaba). Devuelve (ok, motivo)."""
        for lista in ("subscribe_candle", "subscribe_candle_all_size", "subscribe_mood"):
            try: setattr(self.api, lista, [])
            except Exception: pass
        try:
            ok, motivo = con_timeout(self.api.connect, 45)
        except json.JSONDecodeError:
            return False, "respuesta inesperada de IQ Option"
        except Exception as e:
            return False, str(e)[:120]
        if not ok:
            if str(motivo) == "2FA":
                return False, "IQ Option pide el código SMS: cierra y vuelve a abrir el bot."
            return False, _mensaje_error_login(motivo)
        self.ultimo_latido = time.time()
        self.vivo = {}
        if self.cuenta:
            try:
                self.usar_cuenta(self.cuenta, releer_moneda=False)     # misma tasa toda la sesión
            except Exception as e:
                return False, f"reconectado, pero no se pudo elegir la cuenta: {e}"
        return True, ""

    # ---------- mercado ----------
    def activos_abiertos(self, digital=False):
        """{par: {"turbo": 0.87, "binary": 0.85, "digital": 0.88}} solo con pares abiertos.
        También actualiza los códigos de los pares."""
        from iqoptionapi import constants as OP
        inner = self.inner
        inner.api_option_init_all_result_v2 = None
        inner.get_api_option_init_all_v2()
        datos = _esperar(lambda: inner.api_option_init_all_result_v2, 20, 0.05)
        if not datos:
            raise TimeoutError("IQ Option no envió la lista de pares")
        res = {}
        ahora = time.time()
        for tipo in ("turbo", "binary"):
            for clave, a in (datos.get(tipo, {}) or {}).get("actives", {}).items():
                try:
                    nombre = str(a["name"]).split(".", 1)[-1]
                    OP.ACTIVES[nombre] = int(a.get("id", clave))
                    img = a.get("image")
                    if isinstance(img, str) and img.startswith("https://"):
                        self.iconos[nombre] = img           # ícono del activo en IQ Option (si lo manda)
                    if not a.get("enabled", False) or a.get("is_suspended", False):
                        continue
                    tramos = [h for h in (a.get("schedule") or [])
                              if isinstance(h, (list, tuple)) and len(h) >= 2
                              and all(isinstance(x, (int, float)) for x in h[:2])]
                    if tramos and not any(h[0] <= ahora <= h[1] for h in tramos):
                        continue                      # fuera de su horario de operación
                    com = None
                    try:
                        com = a["option"]["profit"]["commission"]
                    except Exception:
                        com = (a.get("profit") or {}).get("commission")
                    res.setdefault(nombre, {})[tipo] = (100.0 - float(com)) / 100.0 if com is not None else None
                except Exception:
                    continue
        if digital:
            for nombre, aid in self.digitales_abiertos().items():
                OP.ACTIVES.setdefault(nombre, aid)
                res.setdefault(nombre, {})["digital"] = self.pago_digital.get(nombre)
        return res

    # ---------- opciones digitales ----------
    def digitales_abiertos(self):
        """{par: id} de los pares abiertos ahora como opción digital."""
        inner = self.inner
        inner.underlying_list_data = None
        inner.get_digital_underlying()
        datos = _esperar(lambda: inner.underlying_list_data, 10, 0.05)
        out = {}
        ahora = time.time()
        for u in (datos or {}).get("underlying", []) or []:
            try:
                if u.get("is_suspended"):
                    continue
                if not any(h.get("open", 0) <= ahora <= h.get("close", 0) for h in (u.get("schedule") or [])):
                    continue
                out[str(u["underlying"])] = int(u["active_id"])
            except Exception:
                continue
        return out

    def leer_pago_digital(self, par):
        """Pago de la opción digital de 1 minuto en ese par (se suscribe un instante y se desuscribe)."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            return None
        inner = self.inner
        with self.lock_digital:
            inner.digital_payout = None
            try:
                inner.subscribe_digital_price_splitter(aid)
                v = _esperar(lambda: inner.digital_payout, 3, 0.05)
            finally:
                try: inner.unsubscribe_digital_price_splitter(aid)
                except Exception: pass
        if v:
            self.pago_digital[par] = round(float(v) / 100.0, 3)
            return self.pago_digital[par]
        return None

    def comprar_digital(self, monto, par, direccion, exp_min, expira):
        """Compra una opción digital al precio actual (SPT) con vencimiento exacto."""
        from iqoptionapi import constants as OP
        aid = OP.ACTIVES.get(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        fecha = datetime.utcfromtimestamp(int(expira)).strftime("%Y%m%d%H%M")
        instrumento = f"do{aid}A{fecha[:8]}D{fecha[8:]}00T{int(exp_min)}M{'C' if direccion == 'call' else 'P'}SPT"
        inner = self.inner
        with self.lock_compra:
            t0 = time.time()
            req = inner.place_digital_option_v2(instrumento, aid, self.a_local(monto))
            r = _esperar(lambda: inner.digital_option_placed_id.get(req), 6, 0.005)
        if r is None:
            raise TimeoutError("IQ Option no confirmó la orden (revisa la plataforma)")
        if not isinstance(r, int):
            raise RuntimeError(str((r or {}).get("message", r)))
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        self.digitales.add(int(r))
        return r

    def velas(self, par, tf_min, cantidad, solo_cerradas=True):
        if tf_min * 60 not in TAMANOS_VELA_IQ:
            return self._velas_armadas(par, tf_min, cantidad, solo_cerradas)
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock:                       # la librería tiene un solo "buzón" para velas
            inner.candles.candles_data = None
            inner.getcandles(aid, tf_min * 60, cantidad + 1, time.time())
            raw = _esperar(lambda: inner.candles.candles_data, 5)
        if raw is None:
            raise TimeoutError("IQ Option no envió velas")
        ahora = self.ahora()
        out = []
        for v in raw:
            if solo_cerradas and v["from"] + tf_min * 60 > ahora + 1:
                continue
            out.append({"t": v["from"], "o": v["open"], "c": v["close"], "h": v["max"], "l": v["min"]})
        return out

    def _velas_armadas(self, par, tf_min, cantidad, solo_cerradas=True):
        """Temporalidades que IQ Option no entrega (M3): se juntan velas M1 alineadas al reloj."""
        m1 = self.velas(par, 1, min(1000, (cantidad + 1) * tf_min + tf_min), solo_cerradas)
        grupos = {}
        for v in m1:
            grupos.setdefault(v["t"] - v["t"] % (tf_min * 60), []).append(v)
        out = []
        for t in sorted(grupos):
            g = sorted(grupos[t], key=lambda x: x["t"])
            if len(g) != tf_min:
                continue                              # vela incompleta (al inicio o la que se está formando)
            out.append({"t": t, "o": g[0]["o"], "c": g[-1]["c"],
                        "h": max(x["h"] for x in g), "l": min(x["l"] for x in g)})
        return out[-cantidad:]

    # ---------- velas en vivo (M1) ----------
    def iniciar_vivo(self, par, maximo=20):
        aid = self._id(par)
        if aid is None:
            return False
        inner = self.inner
        crudas = []
        with self.lock:
            inner.candles.candles_data = None
            inner.getcandles(aid, 60, maximo, time.time())
            crudas = _esperar(lambda: inner.candles.candles_data, 5) or []
        if not crudas:
            return False
        if max(v["from"] for v in crudas) < self.ahora() - 180:
            return "cerrado"                      # su gráfico no se mueve: mercado cerrado
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in crudas:
            inner.real_time_candles[par][60][v["from"]] = v
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return "pendiente"                        # la confirmación se revisa sin bloquear (hilo_pares)

    def suscribir_vivo(self, par, semilla, maximo=20):
        """Suscribe las velas en vivo SIN esperar, usando como semilla las velas que ya se descargaron
        al catalogar (no pide nada más a IQ Option). La confirmación llega sola: ver vivo_confirmado()."""
        aid = self._id(par)
        if aid is None or not semilla:
            return False
        inner = self.inner
        inner.real_time_candles_maxdict_table[par][60] = maximo
        for v in semilla[-maximo:]:
            inner.real_time_candles[par][60][v["t"]] = {"from": v["t"], "open": v["o"], "close": v["c"],
                                                        "max": v["h"], "min": v["l"]}
        inner.candle_generated_check[par][60] = {}
        inner.subscribe(aid, 60)
        return True

    def vivo_confirmado(self, par):
        try:
            return self.inner.candle_generated_check[par][60] is True
        except Exception:
            return False

    def detener_vivo(self, par):
        self.vivo.pop(par, None)
        aid = self._id(par)
        try:
            if aid is not None: self.inner.unsubscribe(aid, 60)
        except Exception:
            pass

    def velas_vivo(self, par):
        try:
            d = dict(self.inner.real_time_candles[par][60])
        except Exception:
            return []
        out = []
        for t in sorted(d):
            v = d[t]
            try:
                out.append({"t": int(v["from"]), "o": float(v["open"]), "c": float(v["close"]),
                            "h": float(v["max"]), "l": float(v["min"])})
            except Exception:
                continue
        return out

    # ---------- ánimo de los traders (dato para las IAs) ----------
    def suscribir_animo(self, par):
        try:
            from iqoptionapi import constants as OP
            self.inner.api.subscribe_Traders_mood(OP.ACTIVES[par])
            return True
        except Exception:
            return False

    def animo(self, par):
        """Fracción de traders de IQ Option comprando CALL en ese par (0 a 1), o None si no hay dato."""
        try:
            from iqoptionapi import constants as OP
            v = self.inner.api.traders_mood.get(OP.ACTIVES[par])
            return float(v) if v is not None else None
        except Exception:
            return None

    # ---------- órdenes ----------
    def comprar(self, monto, par, direccion, exp_min, expira):
        """Compra con vencimiento exacto. Devuelve el id de la orden o lanza el motivo del rechazo."""
        aid = self._id(par)
        if aid is None:
            raise RuntimeError("par desconocido")
        inner = self.inner
        with self.lock_compra:
            self._req += 1
            req = f"bot{int(time.time())}{self._req}"
            t0 = time.time()
            inner.buyv3_by_raw_expired(self.a_local(monto), aid, direccion, "binary" if exp_min > 5 else "turbo",
                                       int(expira), request_id=req)
            r = _esperar(lambda: inner.buy_multi_option.get(req) or None, 6, 0.005)
        if not r:
            raise TimeoutError("IQ Option no confirmó la orden (revisa la plataforma)")
        if "message" in r and not r.get("id"):
            raise RuntimeError(str(r["message"]))
        if not r.get("id"):
            raise RuntimeError(f"respuesta sin número de orden: {r}")
        self.latencia_compra = 0.7 * self.latencia_compra + 0.3 * (time.time() - t0)
        return r["id"]

    def _historial(self):
        inner = self.inner
        inner.get_options_v2_data = None
        inner.get_options_v2(20, "binary,turbo")
        return _esperar(lambda: inner.get_options_v2_data, 8, 0.05)

    @staticmethod
    def _neto(estado, apuesta, bruto, monto):
        """Resultado neto a partir del campo EXPLÍCITO ganó/perdió/empate.
        Ojo: IQ Option manda el monto que habría pagado incluso cuando la operación PIERDE,
        por eso nunca se calcula la ganancia sin mirar primero el estado."""
        estado = str(estado or "").strip().lower()
        if estado in ("equal", "draw", "tie"):
            return 0.0
        if estado in ("loose", "lose", "loss", "lost"):
            return -round(float(monto), 2)
        if estado == "win":
            try:
                ratio = float(bruto) / float(apuesta)
                if 1.0 < ratio < 2.5:                       # pago total / apuesta (independiente de la escala)
                    return round(float(monto) * (ratio - 1.0), 2)
            except Exception:
                pass
            return "win"                                    # ganó, pero sin monto confiable todavía
        return None                                         # sin estado explícito: no se usa

    def _leer_rapido(self, oid, monto):
        """Busca el cierre en los mensajes que llegan solos. Devuelve (neto|'win'|None, vía)."""
        inner = self.inner
        if int(oid) in self.digitales:                   # opción digital: llega como "position-changed"
            try:
                m = (inner.order_async.get(int(oid)) or {}).get("position-changed", {}).get("msg") or {}
            except Exception:
                m = {}
            if m.get("status") == "closed":
                k = self.tasa if (self.tasa and self.moneda != "USD") else 1.0
                if m.get("close_reason") == "expired" and m.get("close_profit") is not None:
                    inv = float(m["invest"]) if m.get("invest") is not None else self.a_local(monto)
                    return round((float(m["close_profit"]) - inv) / k, 2), "aviso digital"
                if m.get("pnl_realized") is not None:
                    return round(float(m["pnl_realized"]) / k, 2), "aviso digital"
            return None, ""
        def buscar(dic, k):
            try:
                if not dic: return None
                return dic.get(k) if k in dic else dic.get(str(k))
            except Exception:
                return None
        x = buscar(getattr(inner, "socket_option_closed", None), oid)
        if x:
            m = x.get("msg", x)
            r = self._neto(m.get("win"), m.get("sum"), m.get("win_amount"), monto)
            if r is not None: return r, "aviso de cierre"
        try:
            o = inner.order_async.get(int(oid))
        except Exception:
            o = None
        if o and o.get("option-closed"):
            m = o["option-closed"].get("msg", {})
            r = self._neto(m.get("result") or m.get("win"), m.get("amount"),
                           m.get("profit_amount") or m.get("win_amount"), monto)
            if r is not None: return r, "option-closed"
        x = buscar(getattr(inner, "order_binary", None), oid)
        if x:
            r = self._neto(x.get("result") or x.get("win"), x.get("amount"),
                           x.get("profit_amount") or x.get("win_amount"), monto)
            if r is not None: return r, "order_binary"
        return None, ""

    def _leer_historial(self, oid, monto):
        """Busca la orden en el historial de opciones cerradas de IQ Option (fuente oficial)."""
        try:
            h = self._historial()
        except Exception:
            return None
        for op in (h or {}).get("msg", {}).get("closed_options", []) or []:
            ids = op.get("id") or []
            ide = ids[0] if isinstance(ids, list) and ids else ids
            if str(ide) == str(oid):
                return self._neto(op.get("win"), op.get("amount"), op.get("win_amount"), monto)
        return None

    def resultado_rapido(self, oid, exp_min, monto, payout):
        """Resultado apenas IQ Option avisa el cierre (menos de 1 s), para decidir el gale a tiempo.
        Solo se acepta un aviso con el estado EXPLÍCITO ganó/perdió/empate. Si no llega, se busca en el historial."""
        limite = time.time() + exp_min * 60 + 240
        vence = time.time() + exp_min * 60 + 2          # desde aquí, si el aviso no llega, se mira el historial
        ultimo_hist = 0
        espera_monto = None
        while time.time() < limite:
            r, via = self._leer_rapido(oid, monto)
            if isinstance(r, (int, float)):
                return r, via
            if r == "win":                     # ganó, pero el aviso no trae el monto: 4 s para el historial
                espera_monto = espera_monto or time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
                if time.time() - espera_monto > 4:
                    return round(monto * (payout or 0.8), 2), via + " (monto según payout)"
            elif self.conectado and time.time() > vence and time.time() - ultimo_hist > 2:
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if isinstance(oficial, (int, float)):
                    return oficial, "historial"
            time.sleep(0.1)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

    def confirmar_en_historial(self, oid, monto, segundos=30):
        """Busca la orden en el historial oficial durante unos segundos. Devuelve el neto o None."""
        fin = time.time() + segundos
        while time.time() < fin:
            if self.conectado:
                r = self._leer_historial(oid, monto)
                if isinstance(r, (int, float)):
                    return r
            time.sleep(3)
        return None

    def resultado(self, oid, exp_min, monto, payout):
        """Resultado neto de la orden y cómo se confirmó.
        1) aviso de cierre con estado explícito, 2) confirmación en el historial oficial.
        Si las dos fuentes no coinciden, manda el historial."""
        limite = time.time() + exp_min * 60 + 240
        rapido, via = None, ""
        t_rapido = None
        ultimo_hist = 0
        while time.time() < limite:
            if rapido is None:
                rapido, via = self._leer_rapido(oid, monto)
                if rapido is not None:
                    t_rapido = time.time()
            if self.conectado and time.time() - ultimo_hist > 3 and (rapido is not None or time.time() > limite - 230):
                ultimo_hist = time.time()
                oficial = self._leer_historial(oid, monto)
                if oficial is not None:
                    if oficial == "win":
                        oficial = round(monto * (payout or 0.8), 2)
                        return oficial, "historial (monto estimado por payout)"
                    if rapido not in (None, "win") and abs(oficial - rapido) > 0.009:
                        return oficial, f"historial (corrigió {rapido:+.2f})"
                    return oficial, "historial"
            # si el historial no responde en 15 s, se usa el aviso de cierre
            if rapido is not None and t_rapido and time.time() - t_rapido > 15:
                if rapido == "win":
                    return round(monto * (payout or 0.8), 2), via + " (monto estimado por payout)"
                return rapido, via + " (sin confirmar en historial)"
            time.sleep(0.3)
        raise RuntimeError(f"No llegó el resultado de la orden {oid} (revísala en la plataforma).")

# =====================================================================
#  MOTOR DEL BOT
# =====================================================================

TEMPORALIDADES = (1, 2, 5, 15)               # minutos
LIMITE_GALE_SEG = {1: 3, 2: 5, 3: 6, 5: 8, 10: 15, 15: 15}     # si el resultado llega más tarde, el gale espera al siguiente cierre
TAMANOS_VELA_IQ = (60, 120, 300, 600, 900)    # tamaños de vela que da IQ Option (M3 se arma con velas M1)

def expiracion_valida(tf, expira, desde):
    """IQ Option solo acepta vencimientos de 1 a 5 minutos (turbo) o en los cuartos de hora :00 :15 :30 :45
    con más de 5 minutos por delante (binarias). Por eso M10 solo opera las velas que cierran en :00 y :30."""
    if tf <= 5:
        return True
    return int(expira) % 900 == 0 and expira - desde > 300
ANALISIS_SEG = 1.2                             # mínimo: se analizan las velas en vivo al menos 1,2 s antes del cierre
ANALISIS_MAX_SEG = 5.0                         # si el equipo es lento se empieza antes, hasta 5 s antes
REFRESCO_CATALOGO_VELAS = 10                   # recatalogar cada N velas

REFRESCO_PARES_SEG = 180                       # releer pares abiertos y payouts cada 3 min
NOTIFICAR = None                               # función(titulo, texto) que pone la ventana (PC o celular)


SIMBOLO_MONEDA = {"USD": "$", "COP": "$", "MXN": "$", "CLP": "$", "ARS": "$", "UYU": "$", "CAD": "$", "AUD": "$",
                  "NZD": "$", "SGD": "$", "HKD": "$", "BRL": "R$", "EUR": "€", "GBP": "£", "PEN": "S/", "INR": "₹",
                  "TRY": "₺", "PHP": "₱", "NGN": "₦", "KRW": "₩", "JPY": "¥", "CNY": "¥", "THB": "฿", "VND": "₫",
                  "IDR": "Rp", "ZAR": "R", "PLN": "zł", "CHF": "CHF ", "BOB": "Bs", "PYG": "₲", "GTQ": "Q", "CRC": "₡"}


def texto_dinero(usd, signo=True):
    """Monto (en dólares por dentro) como lo ve el cliente: en la moneda de su cuenta."""
    try:
        b = BOT_ACTUAL.b if BOT_ACTUAL is not None else None
        m, tasa = getattr(b, "moneda", "USD"), getattr(b, "tasa", 1.0)
    except Exception:
        m, tasa = "USD", 1.0
    s = ("+" if usd >= 0 else "−") if signo else ("−" if usd < 0 else "")
    if m != "USD" and tasa:
        v = abs(usd) * tasa
        num = f"{v:,.0f}".replace(",", ".") if tasa >= 50 else f"{v:,.2f}"
        sim = SIMBOLO_MONEDA.get(m)
        return f"{s}{sim}{num}" if sim else f"{s}{m} {num}"
    return f"{s}${abs(usd):.2f}"


def notificar(titulo, texto, **datos):
    """datos: tipo (ganada/stopwin/stoploss/mercado_malo/mercado_ok), par, dir, op, monto, sesion, ganadas."""
    try:
        if NOTIFICAR:
            threading.Thread(target=NOTIFICAR, args=(titulo, texto), kwargs=datos, daemon=True).start()
    except Exception:
        pass


MAX_PARES = 1000                               # sin límite práctico: se vigilan todos los pares abiertos en IQ Option


BOT_ACTUAL = None      # el único bot que puede trabajar y avisar (nunca dos a la vez)


class Bot:
    def __init__(self, broker, cfg, nombre_cuenta):
        global BOT_ACTUAL
        viejo = BOT_ACTUAL
        if viejo is not None and not viejo.terminado:
            viejo.detener = True                         # si quedó uno andando de antes, se detiene
        BOT_ACTUAL = self
        self.b = broker
        self.cfg = cfg
        self.cuenta = nombre_cuenta
        self.pnl = 0.0
        self.riesgo_abierto = 0.0
        self.pares_en_uso = set()
        self.nivel = 0               # niveles: cuántas pérdidas lleva el ciclo actual
        self.ciclo_perdida = 0.0     # niveles: dinero perdido en el ciclo, a recuperar
        self.ciclo_n = 0             # número del ciclo de recuperación (cambia cada vez que se recupera)
        self.plan = None             # decisión preparada que espera el resultado real de la operación que vence
        self.lock = threading.Lock()
        self.lock_hilos = threading.Lock()
        self.detener = False
        self.terminado = False
        self.hilos = []
        self.stats = {"ganadas": 0, "perdidas": 0, "empates": 0}
        self.estrategias = dict(ESTRATEGIAS)            # todas las estrategias, en automático
        self.tfs = sorted(cfg["temporalidades"])
        # estado para la pantalla
        self.pares = {}          # par -> {"payout", "otc", "estado", "estilo", "hora", "prio"}
        self.seleccion = []      # pares que se analizan
        self.total_abiertos = 0
        self.hist = {}           # (par, tf) -> velas
        self.cat = {}            # (par, tf) -> {"t": ultima vela catalogada, "res": {estrategia: (n, g0, g1)}}
        self.abiertas = {}       # id interno -> datos de la operación en curso
        self.eventos = deque(maxlen=300)
        self.fase = "Iniciando..."
        self.prox_cierre = None
        self.tfs_prox = []
        self.aviso_error = None   # {"texto", "t"}: último rechazo / problema que el cliente debe ver
        self._avisos_notificados = {}
        try:
            if hasattr(broker, "preparar_moneda"):
                broker.preparar_moneda()          # tasa del día para esta sesión
        except Exception:
            pass
        s0 = broker.saldo()
        self.saldo_txt = f"{s0:,.2f}" if isinstance(s0, (int, float)) else str(s0)
        self.saldo_inicio = s0 if isinstance(s0, (int, float)) else None   # saldo real al empezar
        self.saldo_actual = self.saldo_inicio
        self.t_saldo = time.time()
        self.ultimo_cierre = 0.0
        self.ajustes_saldo = 0
        self.ultima_lectura_pares = None
        self.seq = 0
        self.reconexiones = 0
        self.sombra_pend = {}    # (par, tf, dir, fin) -> {"act", "val", "e": [estrategias]}: catálogo validado en prueba
        self.sombra = self._leer_sombra()
        self._t_sombra_log = time.time()
        self.perd_ciclo = {}     # par -> pérdidas en el ciclo de recuperación actual
        self.descanso = {}       # par -> hasta cuándo no se usa (perdió 2 veces en un ciclo)
        self.par_perdio = None   # último par que perdió dentro del ciclo (el nivel va a OTRO par)
        self.vivo_pend = {}      # par -> cuándo se pidieron sus velas en vivo (esperando la primera)
        self.bloqueados = {}     # par -> hasta cuándo no se usa (IQ Option lo rechazó por no disponible)
        self.enfriar = {}
        self.ia = inteligencia()  # Inteligencia LS (aprende de cada señal y operación)
        self.ia_pend = []        # señales esperando que cierre su vela para aprender el resultado
        self.virtuales = deque(maxlen=600)   # (hora, ganó) de las señales que pasaron todos los filtros
        self.pausa_inicio = MERCADO.aviso and not MERCADO.operar_igual   # mercado malo al iniciar: arranca en pausa
        self.en_pausa_mkt = False     # ya se pausó por mercado malo en esta sesión
        self.espera_decision = False  # el mercado mejoró y espera que el cliente decida seguir
        self.confianza = None    # medidor del panel (lo que opinan las IAs de la mejor señal)
        self.t_analisis = 0.5    # cuánto tarda el análisis de cada cierre (se mide solo)
        self.analisis_cortado = False
        self.mercado = None      # último diagnóstico del mercado
        self.ultimo_escaneo = {}
        self.pausado = False
        self.resultados = deque(maxlen=200)    # para la ventana: cada operación cerrada
        self.curva = [(time.time(), 0.0)]       # P/L de la sesión en el tiempo
        self.inicio_sesion = time.time()
        self.reserva = None      # señales del último cierre que no entraron porque había operaciones por vencer
        self.ultima_entrada = None
        self._t_ultima_entrada = time.time()

    # ---------- registro ----------
    def log(self, msg, estilo="", mostrar=True):
        """Eventos de operaciones, recuperación, stops y conexión. Lo de escaneo/catalogación no se muestra."""
        if not mostrar:
            return
        hora = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")
        self.eventos.append((hora, msg, estilo))
        try:
            with open("bot.log", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d} {hora}] {msg}\n")
        except Exception:
            pass

    def estado(self, par, texto, estilo="", prio=3):
        p = self.pares.get(par)
        if p is not None:
            p["estado"], p["estilo"], p["prio"] = texto, estilo, prio
            p["hora"] = datetime.fromtimestamp(self.b.ahora()).strftime("%H:%M:%S")

    def guardar(self, fila):
        nuevo = not os.path.exists(LOG_FILE)
        with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if nuevo:
                w.writerow(["fecha", "cuenta", "par", "tf", "direccion", "estrategia", "intento", "monto", "resultado", "pnl_sesion", "confirmado"])
            w.writerow(fila)

    # ---------- riesgo ----------
    def stop_alcanzado(self):
        return self.pnl >= self.cfg["stop_win"] or self.pnl <= -self.cfg["stop_loss"]

    def frenar_por_stop(self):
        """True si ya se llegó al stop win / stop loss: el bot se detiene y no abre nada más."""
        if self.stop_alcanzado():
            if not self.detener:
                self.detener = True
                self.avisar_stop()
            return True
        return self.detener

    def avisar_stop(self):
        gano = self.pnl > 0
        self.log(f"=== STOP {'WIN' if gano else 'LOSS'} alcanzado: {self.pnl:+.2f} ===", "bold green" if gano else "bold red")
        if gano:
            notificar("🎯 Meta del día cumplida", f"{self.stats['ganadas']} ganadas · el bot se detuvo",
                      tipo="stopwin", monto=self.pnl, ganadas=self.stats["ganadas"])
        else:
            notificar("🛑 Saldo protegido", "Stop Loss alcanzado · el bot se detuvo",
                      tipo="stoploss", monto=self.pnl, ganadas=self.stats["ganadas"])

    def puede_arriesgar(self, monto):
        """No abre nada que, si se pierde todo lo abierto, rompa el stop loss."""
        return self.pnl - self.riesgo_abierto - monto >= -self.cfg["stop_loss"] - 1e-9

    def monto_siguiente_nivel(self, payout):
        """Monto de una entrada nueva (niveles: según el ciclo de pérdidas)."""
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if cfg["recuperacion"] != "niveles" or self.nivel == 0:
            return base
        p = payout or 0.85
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** self.nivel
        else:  # automático: recupera todo lo perdido en el ciclo + la ganancia de la entrada base
            m = (self.ciclo_perdida + base * p) / p
        return max(1.0, round(m, 2))

    def monto_base(self):
        return self.monto_siguiente_nivel(0.85)


    # ---------- pares abiertos (hilo en segundo plano) ----------
    def instrumento(self, pays, es_otc, tf):
        """(tipo, pago) con el que conviene operar ese par: binaria/turbo o digital, el que mejor pague
        entre los mercados elegidos. (None, None) si no se puede operar."""
        cfg = self.cfg
        tipo = "turbo" if tf <= 5 else "binary"
        opciones = []
        if (cfg["incluir_otc"] if es_otc else cfg["incluir_mercado_real"]) and pays.get(tipo) is not None:
            opciones.append((pays[tipo], tipo))
        if cfg.get("incluir_digital") and tf in (1, 5, 15) and pays.get("digital"):
            opciones.append((pays["digital"], "digital"))
        if not opciones:
            return None, None
        pago, t = max(opciones)
        return t, pago

    def refrescar_pares(self):
        cfg = self.cfg
        activos = self.b.activos_abiertos(digital=bool(cfg.get("incluir_digital")))
        tf0 = min(self.tfs) if self.tfs else 1
        lista = []
        for par, pays in activos.items():
            es_otc = par.endswith("-OTC")
            tipo, pago = self.instrumento(pays, es_otc, tf0)
            if tipo is None: continue
            # se catalogan y vigilan TODOS los pares abiertos; el payout mínimo solo se exige al entrar
            if self.bloqueados.get(par, 0) > time.time(): continue
            lista.append((par, pays, es_otc, pago))
        lista.sort(key=lambda x: x[3] or 0, reverse=True)
        lista = [x[:3] for x in lista[:MAX_PARES]]    # todos los pares abiertos
        if cfg.get("incluir_digital"):
            self.leer_pagos_digitales(activos)
        nuevos = {}
        for par, pays, es_otc in lista:
            viejo = self.pares.get(par, {})
            nuevos[par] = {"payout": self.instrumento(pays, es_otc, tf0)[1], "pays": pays, "otc": es_otc,
                           "estado": viejo.get("estado", "En espera"), "estilo": viejo.get("estilo", "dim"),
                           "hora": viejo.get("hora", ""), "prio": viejo.get("prio", 3)}
        for par in list(self.pares_en_uso):  # no perder de vista los pares con operación abierta
            if par not in nuevos and par in self.pares:
                nuevos[par] = self.pares[par]
        self.pares = nuevos
        self.seleccion = [p for p, _, _ in lista]
        self.total_abiertos = len(activos)
        self.ultima_lectura_pares = time.time()
        return len(activos), len(lista)

    def leer_pagos_digitales(self, activos):
        """En segundo plano lee el pago digital de cada par (primero los que solo existen como digital)."""
        if getattr(self, "_leyendo_digital", False):
            return
        pares = [p for p, v in activos.items() if "digital" in v]
        pares.sort(key=lambda p: ("turbo" in activos[p] or "binary" in activos[p], p))
        def leer():
            self._leyendo_digital = True
            try:
                for par in pares:
                    if self.detener or not self.b.conectado:
                        break
                    while not self.libre_para_entrenar() and not self.detener:
                        time.sleep(0.3)               # nunca en los segundos del cierre de vela
                    try:
                        self.b.leer_pago_digital(par)
                    except Exception:
                        pass
            finally:
                self._leyendo_digital = False
        threading.Thread(target=leer, daemon=True).start()

    def hilo_pares(self):
        espera = 0
        ultimo_saldo = 0
        while not self.detener:
            if not self.b.conectado:
                time.sleep(1); continue
            if time.time() >= espera:
                try:
                    tot, sel = self.refrescar_pares()
                    self.log(f"Pares abiertos: {tot}. Catalogando y vigilando {sel} (todos; el payout mínimo se exige al entrar).", "cyan", mostrar=False)
                    espera = time.time() + REFRESCO_PARES_SEG
                    if tot == 0:
                        self.log("IQ Option no devolvió pares abiertos. Reintento en 30 s.", "yellow")
                        espera = time.time() + 30
                except Exception as e:
                    self.log(f"No se pudo leer la lista de pares ({str(e)[:60]}). Reintento en 30 s.", "yellow")
                    espera = time.time() + 30
            # velas en vivo: confirmar las pedidas (sin bloquear) ...
            for par, t_ped in list(self.vivo_pend.items()):
                if self.b.vivo_confirmado(par):
                    self.vivo_pend.pop(par, None)
                    self.b.vivo[par] = True
                    self.b.suscribir_animo(par)
                    self.estado(par, "Velas en vivo conectadas", "", 3)
                elif time.time() - t_ped > 45:       # no llegó nada en 45 s: se vuelve a pedir
                    self.vivo_pend.pop(par, None)
                    self.b.vivo.pop(par, None)
            # ... suscribir los pares nuevos (primero los que tienen estrategias activas) y soltar los que salieron
            def activas(p):
                return max([(self.cat.get((p, tf)) or {}).get("activas") or 0 for tf in self.tfs] or [0])
            for par in sorted(self.seleccion, key=lambda p: -activas(p)):
                if self.detener or not self.b.conectado: break
                if self.b.vivo.get(par) or par in self.vivo_pend: continue
                if self.b.ahora() % 60 > 60 - ANALISIS_SEG - 4:   # no estorbar justo antes del cierre
                    break
                self.estado(par, "Conectando velas en vivo...", "yellow", 2)
                self.vivo_pend[par] = time.time()
                try:
                    ok = self.b.iniciar_vivo(par)
                except Exception as e:
                    ok = False
                if ok == "pendiente":
                    self.vivo_pend[par] = time.time()
                    continue
                self.vivo_pend.pop(par, None)
                if ok is False:                       # IQ Option no envió velas: se reintenta en 2 min
                    self.bloqueados[par] = time.time() + 120
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                if ok == "cerrado":
                    self.bloqueados[par] = time.time() + 900
                    if par in self.seleccion: self.seleccion.remove(par)
                    self.b.vivo.pop(par, None)
                    continue
                self.estado(par, "Velas en vivo conectadas", "", 3)
            for par in [p for p in set(self.b.vivo) | set(self.vivo_pend) if p not in self.seleccion and p not in self.pares_en_uso]:
                self.vivo_pend.pop(par, None)
                self.b.detener_vivo(par)
            time.sleep(1)

    def hilo_licencia(self):
        """Vuelve a verificar la licencia cada LICENCIA_HORAS. Si deja de ser válida, no se abren más entradas."""
        while not self.detener:
            for _ in range(LICENCIA_HORAS * 3600):
                if self.detener: return
                time.sleep(1)
            ok, msg = verificar_licencia(self.cfg.get("email"), self.b.id_iq())
            if not ok:
                self.log(f"✘ {msg.splitlines()[0]} El bot deja de abrir operaciones.", "bold red")
                self.detener = True
                return

    def pnl_segun_saldo(self):
        """P/L real: saldo actual − saldo inicial + lo que está apostado en operaciones abiertas."""
        if self.saldo_inicio is None or self.saldo_actual is None:
            return None
        abierto = sum(o["monto"] for o in list(self.abiertas.values()))
        return round(self.saldo_actual - self.saldo_inicio + abierto, 2)

    def hilo_saldo(self):
        """Lee el saldo real cada 4 s y, cuando no hay nada abierto, cuadra el P/L del bot con él."""
        while not self.detener or self.activas():
            time.sleep(2)
            if not self.b.conectado:
                continue
            pedido = time.time()
            sa = self.b.saldo()
            if not isinstance(sa, (int, float)):
                continue
            self.saldo_actual = sa
            self.t_saldo = pedido
            self.saldo_txt = f"{sa:,.2f}"
            if self.saldo_inicio is None:
                self.saldo_inicio = sa; continue
            quieto = (not self.abiertas and self.riesgo_abierto <= 0.0001 and self.activas() == 0
                      and pedido - self.ultimo_cierre > 3)
            if not quieto:
                continue
            real = self.pnl_segun_saldo()
            dif = round(real - self.pnl, 2)
            if abs(dif) >= 0.01:
                self.ajustes_saldo += 1
                self.log(f"⚠ Cuadre con el saldo de IQ Option: el bot llevaba P/L {self.pnl:+.2f} y el saldo real "
                         f"indica {real:+.2f} (diferencia {dif:+.2f}). Se usa el saldo real. "
                         f"(Si operaste a mano en esta cuenta, eso también cuenta.)", "bold yellow")
                with self.lock:
                    self.pnl = real
                    self.curva.append((time.time(), self.pnl))
                if self.stop_alcanzado() and not self.detener:
                    self.detener = True
                    self.avisar_stop()

    def hilo_vigilante(self):
        """Revisa la conexión cada 3 s. Si se cae, pausa las entradas y reconecta sin parar."""
        espera = 5
        while not self.detener:
            time.sleep(3)
            ok, motivo = self.b.salud()
            if ok:
                continue
            self.b.conectado = False
            self.reconexiones += 1
            self.log(f"⚠ Conexión con IQ Option perdida: {motivo}. Se pausan las entradas y se reconecta...", "bold yellow")
            intento = 0
            while not self.detener:
                intento += 1
                self.fase = f"Reconectando con IQ Option (intento {intento})" + (f": {motivo}" if motivo else "...")
                ok, motivo = self.b.reconectar()
                if ok:
                    self.b.conectado = True
                    self.b.vivo = {p: False for p in self.b.vivo}   # se vuelven a suscribir las velas en vivo
                    self.vivo_pend.clear()
                    self.log(f"✔ Reconectado con IQ Option (intento {intento}). Se reanudan las entradas.", "bold green")
                    if self.aviso_error and self.aviso_error.get("titulo") == "Sin conexión con IQ Option":
                        self.aviso_error = None
                    espera = 5
                    break
                self.log(f"Reconexión fallida ({motivo}). Nuevo intento en {espera} s.", "yellow")
                if intento == 3:
                    self.avisar_error(f"No se pudo reconectar con IQ Option ({motivo}). Revisa tu internet; el bot sigue "
                                      f"intentando solo.", "Sin conexión con IQ Option")
                for _ in range(espera):
                    if self.detener: break
                    time.sleep(1)
                espera = min(espera * 2, 60)

    # ---------- análisis ----------
    def evaluar(self, par, tf, velas, payout):
        """Devuelve (candidato o None, texto_estado, estilo)."""
        cfg = self.cfg
        ultima = velas[-VENTANA:]
        cat = self.cat.get((par, tf), {}).get("res", {})
        usa_gale = cfg["recuperacion"] == "martingala" and cfg["rec_max"] >= 1
        pago = payout or cfg["payout_minimo"]
        senales, descartes = {}, []
        inicio = ultima[-1]["t"] + tf * 60          # la vela donde entraría la operación
        hora = time.localtime(inicio).tm_hour
        eq = equipo()
        animo = self.b.animo(par) if hasattr(self.b, "animo") else None      # lado de los traders (dato de aprendizaje)
        tnd = p_red = None
        listo = False                                # tendencia y red se calculan una sola vez por par
        for nombre, fn in self.estrategias.items():
            try:
                d = fn(ultima)
            except Exception:
                d = None
            if not d: continue
            n, g0, g1, _nr, _gr, g2, g3, nf, gf0, gf1 = (tuple(cat.get(nombre, ())) + (0,) * 10)[:10]
            # catálogo VALIDADO: elegida con las velas viejas, medida con las 200 recientes que no usó para elegir
            # + lo que esa estrategia hizo de verdad en este par. El catálogo de siempre queda solo de respaldo.
            act = val = False
            acierto_v, n_v = 0.0, 0
            try:
                act = (nf >= cfg["min_senales_catalogo"] and n > 0 and gf0 / nf >= cfg["winrate_minimo"]
                       and valor_esperado(gf0 / nf, gf1 / nf, pago, usa_gale) > cfg["ev_minimo"])
                val, acierto_v, n_v = validar_estrategia(cat.get(nombre, ()), self.sombra["ep"].get(f"{nombre}|{par}", []),
                                                         eq.d["estr"].get(nombre, []), cfg["winrate_minimo"])
                if val and valor_esperado(acierto_v, acierto_v, pago, False) <= cfg["ev_minimo"]:
                    val = False
                s = self.sombra_pend.setdefault((par, tf, d, inicio + tf * 60), {"act": False, "val": False, "e": []})
                s["act"] = s["act"] or act; s["val"] = s["val"] or val; s["e"].append(nombre)
            except Exception:
                pass
            if not (val or act):
                descartes.append(f"{nombre} no pasa el catálogo"); continue
            wr0, wr1 = (gf0 / nf, gf1 / nf) if nf else (0.0, 0.0)
            ev = valor_esperado(acierto_v, acierto_v, pago, False) if val else valor_esperado(wr0, wr1, pago, usa_gale)
            if not listo:
                listo = True
                try:
                    tnd = tendencia(velas[:-1])          # velas CERRADAS
                except Exception:
                    tnd = None
                try:
                    pu = red().p_sube(velas)
                    p_red = pu
                except Exception:
                    p_red = None
            tramo = tramo_tendencia(tnd, d)
            pr = None if p_red is None else (p_red if d == "call" else 1 - p_red)
            try:
                x = rasgos_senal(velas, d, [nombre], wr0, acierto_confiable(g0, n), g0 / n, g1 / n, tnd, tramo, pr,
                                 pago, hora)
            except Exception:
                x = None
            o = eq.opiniones(par, [nombre], red_senales().prob(x) if x else None, tramo, pr)
            pj = eq.juez(o)
            # dato de aprendizaje: todas las señales que pasan el catálogo se resuelven al cerrar su vela
            try:
                claves = rasgos_mercado(ultima, par, tf, d, nombre, wr0, pago, inicio, animo)
            except Exception:
                claves = None
            pend = {"par": par, "tf": tf, "dir": d, "fin": inicio + tf * 60, "k": claves, "paso": False,
                    "ctx": {"par": par, "estrategias": [nombre], "tramo": tramo, "o": o, "x": x}}
            if len(self.ia_pend) < 6000:
                self.ia_pend.append(pend)
            # orden: acierto a la primera. Validada: el acierto validado (corregido por la cantidad de señales)
            conf = acierto_confiable(round(acierto_v * n_v), n_v) if val else acierto_confiable(g0, n)
            wg = g0 / n
            if usa_gale:
                gk = (g0, g1, g2, g3)[max(0, min(3, int(cfg["rec_max"])))]
                wg = gk / n
            senales.setdefault(d, []).append({"nombre": nombre, "wr": acierto_v if val else wr0, "n": n_v if val else nf,
                                              "ev": ev, "conf": conf, "validada": val,
                                              "wr500": g0 / n, "wr_g1": g1 / n, "wg": wg, "pend": pend,
                                              "o": o, "pj": pj, "tramo": tramo, "x": x, "pr": pr})
        if "call" in senales and "put" in senales:
            bc = max(x["conf"] for x in senales["call"]); bp = max(x["conf"] for x in senales["put"])
            if abs(bc - bp) < 0.05:
                return None, f"M{tf} señales contrarias, no entra", "yellow"
            senales.pop("put" if bc > bp else "call")
        for d, lst in senales.items():
            if len(lst) < cfg["confluencia_minima"]:
                return None, f"M{tf} {d.upper()} sin confluencia ({len(lst)}/{cfg['confluencia_minima']})", "yellow"
            lst.sort(key=lambda x: (x["validada"], x["conf"], x["wr"], x["n"]), reverse=True)
            mejor = lst[0]                      # la estrategia que más gana a la primera
            nombres = [x["nombre"] for x in lst]
            o = dict(mejor["o"])
            o["estrategias"] = max((x["o"].get("estrategias") for x in lst if x["o"].get("estrategias") is not None),
                                   default=None)
            if len(lst) > 1:                    # varias estrategias coinciden: la red de señales lo tiene en cuenta
                try:
                    xc = rasgos_senal(velas, d, nombres, mejor["wr"], mejor["conf"], mejor["wr500"], mejor["wr_g1"],
                                      tnd, mejor["tramo"], mejor["pr"], pago, hora)
                    o["senales"] = red_senales().prob(xc)
                    mejor["pend"]["ctx"]["x"] = xc
                    mejor["pend"]["ctx"]["o"] = dict(o)   # se mide con la misma opinión con la que aprende
                except Exception:
                    pass
            pj = eq.juez(o)
            juez_ok = eq.juez_lista()
            c = {"par": par, "tf": tf, "dir": d, "payout": pago, "estrategia": "+".join(nombres),
                 "wr": mejor["wr"], "n": mejor["n"], "conf": mejor["conf"], "wr500": mejor["wr500"],
                 "wr_g1": mejor["wr_g1"], "wg": mejor["wg"], "ev": mejor["ev"] + 0.02 * (len(lst) - 1),
                 "puntaje": mejor["conf"] + 0.01 * (len(lst) - 1), "o": o, "pj": pj,
                 "ia": pj if juez_ok else None, "tramo": mejor["tramo"], "tend": tnd, "validada": mejor["validada"],
                 "ia_keys": mejor["pend"].get("k")}
            mejor["pend"]["paso"] = True                # esta señal pasó todo
            mejor["pend"]["ctx"]["estrategias"] = nombres
            txt = f"SEÑAL {d.upper()} M{tf} · {c['estrategia']} {mejor['wr']*100:.0f}%"
            return c, txt, ("bold green" if d == "call" else "bold red")
        if descartes:
            return None, f"M{tf} descartada: {', '.join(descartes[:2])}", "dim"
        return None, f"M{tf} sin señal", "dim"

    def preparar(self, tfs_c, prox):
        """Durante la vela: descarga historial, cataloga y deja todo listo para el cierre."""
        cfg = self.cfg
        limite = prox - self.adelanto_analisis() - 1.5
        for par in list(self.seleccion):
            for tf in tfs_c:
                if self.detener or not self.b.conectado or self.b.ahora() > limite:
                    return
                if par in self.pares_en_uso:
                    continue
                k = (par, tf)
                c = self.cat.get(k)
                try:
                    if not c or (prox - c["t"]) >= REFRESCO_CATALOGO_VELAS * tf * 60:
                        self.fase = f"Catalogando {par} M{tf}"
                        self.estado(par, f"Catalogando M{tf}...", "yellow", 2)
                        velas = self.b.velas(par, tf, cfg["velas_catalogo"])
                        if len(velas) < VENTANA + 20:
                            self.estado(par, f"Pocas velas M{tf} ({len(velas)})", "dim", 3); continue
                        self.hist[k] = velas
                        if (tf == 1 and not self.b.vivo.get(par) and par not in self.vivo_pend
                                and velas[-1]["t"] >= self.b.ahora() - 180):
                            try:
                                self.vivo_pend[par] = time.time()
                                if not self.b.suscribir_vivo(par, velas):
                                    self.vivo_pend.pop(par, None)
                            except Exception:
                                self.vivo_pend.pop(par, None)
                        res = {n: catalogar(velas, fn) for n, fn in self.estrategias.items()}
                        self.cat[k] = {"t": velas[-1]["t"], "res": res}
                        eqd = equipo().d["estr"]
                        buenas = sum(1 for nom, r in res.items()
                                     if (r[7] >= cfg["min_senales_catalogo"] and r[8] / r[7] >= cfg["winrate_minimo"])
                                     or validar_estrategia(r, self.sombra["ep"].get(f"{nom}|{par}", []), eqd.get(nom, []),
                                                           cfg["winrate_minimo"])[0])
                        self.cat[k]["activas"] = buenas
                        if not buenas:
                            self.estado(par, f"M{tf}: ninguna estrategia llega al {cfg['winrate_minimo']*100:.0f}%", "dim", 3)
                            continue
                    elif tf > 1:
                        # velas M5/M15 cerradas más recientes (la que se forma se arma con las M1 en vivo)
                        hist = self.hist.get(k, [])
                        if not hist or hist[-1]["t"] < prox - 2 * tf * 60:
                            nuevas = self.b.velas(par, tf, 4)
                            por_t = {v["t"]: v for v in hist}
                            for v in nuevas: por_t[v["t"]] = v
                            self.hist[k] = [por_t[t] for t in sorted(por_t)][-cfg["velas_catalogo"]:]
                    vivo = "en vivo" if self.b.vivo.get(par) else "sin velas en vivo"
                    act = (self.cat.get(k) or {}).get("activas")
                    if act == 0:
                        self.estado(par, f"M{tf}: ninguna estrategia llega al {cfg['winrate_minimo']*100:.0f}%", "dim", 3)
                        continue
                    txt_act = f"{act} estrategias activas, " if act else ""
                    self.estado(par, f"Listo para el cierre M{tf} ({txt_act}{vivo})", "" if self.b.vivo.get(par) else "dim", 3)
                except Exception as e:
                    self.estado(par, f"Error M{tf} ({str(e)[:30]})", "red", 3)

    def vela_en_formacion(self, m1, tf, prox):
        """Arma la vela que cierra en 'prox' con las M1 en vivo (para M2…M15 junta varias M1)."""
        inicio = prox - tf * 60
        por_t = {v["t"]: v for v in m1}
        partes = [por_t.get(inicio + i * 60) for i in range(tf)]
        if any(p is None for p in partes):
            return None
        return {"t": inicio, "o": partes[0]["o"], "c": partes[-1]["c"],
                "h": max(p["h"] for p in partes), "l": min(p["l"] for p in partes)}

    def analizar_antes_del_cierre(self, tfs_c, prox):
        """1,2 s antes del cierre: toma la vela que se está formando como si ya cerrara y busca señales."""
        cfg = self.cfg
        cands, revisados = [], 0
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        vencen = {o["par"] for o in list(self.abiertas.values()) if abs(o["vence"] - prox) < 1}
        orden = [p for p in self.seleccion if p in vencen] + [p for p in self.seleccion if p not in vencen]
        for par in orden:
            if self.detener: break
            if self.b.ahora() > prox - anticipo - 0.25:      # nunca se pasa del momento de enviar la orden
                self.analisis_cortado = True
                break
            if par in self.pares_en_uso and par not in vencen:
                self.estado(par, "Operando", "bold cyan", 0); continue
            if not self.b.vivo.get(par):
                continue
            m1 = self.b.velas_vivo(par)
            if not m1:
                continue
            info = self.pares.get(par, {})
            for tf in tfs_c:
                k = (par, tf)
                if k not in self.cat:
                    continue
                formando = self.vela_en_formacion(m1, tf, prox)
                if not formando:
                    self.estado(par, f"M{tf} faltan velas en vivo", "dim", 3); continue
                if tf == 1:
                    por_t = {v["t"]: v for v in self.hist.get(k, [])}
                    for v in m1:
                        if v["t"] < prox - 60: por_t[v["t"]] = v       # M1 cerradas que llegaron en vivo
                    cerradas = [por_t[t] for t in sorted(por_t)][-cfg["velas_catalogo"]:]
                    self.hist[k] = cerradas
                else:
                    cerradas = [v for v in self.hist.get(k, []) if v["t"] < formando["t"]]
                if not cerradas or cerradas[-1]["t"] != formando["t"] - tf * 60:
                    self.estado(par, f"M{tf} historial incompleto, se completa en la próxima vela", "dim", 3)
                    self.cat.pop(k, None)   # fuerza recatalogar
                    continue
                revisados += 1
                inst, pago = self.instrumento(info.get("pays", {}), par.endswith("-OTC"), tf)
                if inst is None:
                    continue
                c, txt, est = self.evaluar(par, tf, cerradas + [formando], pago)
                if c and pago is not None and pago < cfg["payout_minimo"]:   # se cataloga y aprende, pero no se entra
                    c, txt, est = None, f"M{tf}: señal, pero paga {pago*100:.0f}% (mínimo {cfg['payout_minimo']*100:.0f}%)", "dim"
                self.estado(par, txt, est, 1 if c else 3)
                if c:
                    c["inicio_vela"] = prox
                    c["inst"] = inst
                    cands.append(c)
        return cands, revisados

    def ia_resolver(self, prox):
        """Las señales cuya vela ya cerró: la IA aprende si habrían ganado o perdido."""
        quedan = []
        velas_par = {}
        for p in self.ia_pend:
            if p["fin"] > prox - 60:                 # su vela todavía no cierra
                quedan.append(p); continue
            par = p["par"]
            if par not in velas_par:
                velas_par[par] = self.b.velas_vivo(par) if self.b.vivo.get(par) else []
            vela = self.vela_en_formacion(velas_par[par], p["tf"], p["fin"]) if velas_par[par] else None
            if vela is None:
                if p["fin"] > prox - 20 * 60:
                    quedan.append(p)                 # quizá llegan las velas en el próximo minuto
                continue
            col = color(vela)
            if col == 0:
                continue                             # empate: no enseña nada
            gano = col == (1 if p["dir"] == "call" else -1)
            if p.get("k"):
                self.ia.aprender(p["k"], gano)          # registro de señales (datos para revisar y exportar)
            if p.get("ctx"):
                equipo().aprender(p["ctx"], gano)        # las IAs se miden y aprenden con el resultado real
            if p["paso"]:
                self.virtuales.append((time.time(), gano))
        self.ia_pend = quedan
        try:
            self.resolver_sombra(prox, velas_par)
        except Exception:
            pass

    # ---------- catálogo validado: prueba en sombra (sin dinero) ----------
    def _leer_sombra(self):
        base = {"desde": time.time(), "act": [0, 0], "val": [0, 0], "solo_val": [0, 0], "solo_act": [0, 0], "ep": {}}
        try:
            with open(SOMBRA_ARCHIVO, encoding="utf-8") as f:
                d = json.load(f)
            for k in base:
                d.setdefault(k, base[k])
            return d
        except Exception:
            return base

    def guardar_sombra(self):
        try:
            tmp = SOMBRA_ARCHIVO + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.sombra, f)
            os.replace(tmp, SOMBRA_ARCHIVO)
        except Exception:
            pass

    def resolver_sombra(self, prox, velas_par):
        s = self.sombra
        for clave, info in list(self.sombra_pend.items()):
            par, tf, d, fin = clave
            if fin > prox - 60:
                continue
            if par not in velas_par:
                velas_par[par] = self.b.velas_vivo(par) if self.b.vivo.get(par) else []
            vela = self.vela_en_formacion(velas_par[par], tf, fin) if velas_par[par] else None
            if vela is None:
                if fin <= prox - 20 * 60:
                    self.sombra_pend.pop(clave, None)
                continue
            self.sombra_pend.pop(clave, None)
            col = color(vela)
            if col == 0:
                continue
            g = 1 if col == (1 if d == "call" else -1) else 0
            for e in set(info["e"]):                      # dato REAL de esa estrategia en ese par
                r = s["ep"].setdefault(f"{e}|{par}", []); r.append(g)
                if len(r) > 30: del r[:len(r) - 30]
            for k, ok in (("act", info["act"]), ("val", info["val"]),
                          ("solo_val", info["val"] and not info["act"]), ("solo_act", info["act"] and not info["val"])):
                if ok:
                    s[k][0] += g; s[k][1] += 1
        if len(s["ep"]) > 20000:                            # que el archivo no crezca sin fin
            for k in list(s["ep"])[:5000]:
                s["ep"].pop(k, None)

    def informe_sombra(self):
        s = self.sombra
        pct = lambda x: f"{x[0] / x[1] * 100:.0f} % en {x[1]} señales" if x[1] else "sin datos aún"
        return (f"🧪 Catálogo validado (prueba sin dinero): acierto a la primera {pct(s['val'])} · catálogo actual: "
                f"{pct(s['act'])} · solo el validado: {pct(s['solo_val'])} · solo el actual: {pct(s['solo_act'])}")

    def revisar_mercado(self):
        """Cada minuto: ¿el mercado está lateral/errático? Si está malo, el bot se pausa solo."""
        cfg = self.cfg
        sel = set(self.seleccion)
        cats = [v for k, v in self.cat.items() if k[0] in sel and "activas" in v]
        if len(cats) < 3:
            return
        pct_ok = sum(1 for v in cats if v["activas"] > 0) / len(cats)
        debiles = total = 0
        regs = {}
        tf_base = min(self.tfs)
        for par in sel:
            h = self.hist.get((par, tf_base)) or []
            if len(h) < 70:
                continue
            r = regimen(h[-70:])
            if r:
                regs[r] = regs.get(r, 0) + 1
            for i in range(len(h) - 15, len(h)):
                prom = sum(abs(x["c"] - x["o"]) for x in h[i - 10:i]) / 10
                debiles += vela_debil(h[i], prom); total += 1
        recientes = [g for t, g in self.virtuales if t > time.time() - 30 * 60]
        acierto = sum(recientes) / len(recientes) if len(recientes) >= 12 else None
        diag = diagnosticar_mercado(pct_ok, debiles / total if total else 0.0, regs, acierto, cfg, len(recientes))
        antes, ahora = MERCADO.actualizar(diag)
        self.mercado = MERCADO.resumen()
        if ahora and not antes:
            self.log("⚠ Mercado lateral y errático (" + "; ".join(diag["motivos"]) + "). "
                     "El bot se pausa hasta que mejore. Puedes elegir operar de todos modos.", "bold yellow")
        elif antes and not ahora:
            self.log("✔ El mercado mejoró: el bot vuelve a operar normalmente.", "bold green")

    def precio_actual(self, par):
        """Último precio del par según las velas en vivo."""
        try:
            m1 = self.b.velas_vivo(par)
            return m1[-1]["c"] if m1 else None
        except Exception:
            return None

    def adelanto_analisis(self):
        """Cuántos segundos antes del cierre empieza el análisis: lo que tarde en este equipo + la orden + margen."""
        anticipo = max(0.05, float(self.cfg.get("anticipo_ms", 300)) / 1000.0)
        return max(ANALISIS_SEG, min(ANALISIS_MAX_SEG, self.t_analisis * 1.5 + anticipo + 0.35))

    def quiza_entrenar_red(self):
        """La red neuronal se entrena en segundo plano con los historiales que el bot ya descargó."""
        r = red()
        if not r.debe_entrenar() or len(self.hist) < 10:
            return
        historiales = [list(v) for (par, tf), v in list(self.hist.items()) if tf == min(self.tfs)]
        threading.Thread(target=r.entrenar, args=(historiales, self.libre_para_entrenar, lambda: self.detener),
                         daemon=True).start()

    def libre_para_entrenar(self):
        """La IA 3 entrena en segundo plano, pero nunca en los segundos cercanos a un cierre de vela."""
        prox = self.prox_cierre
        if not prox:
            return True
        ahora = self.b.ahora()
        return prox - ahora > 6 or ahora - prox > 3

    # ---------- pausa por mercado malo ----------
    def avisar_mercado(self):
        """Avisos de mercado: errático mientras opera (se pausará al terminar), en pausa, y óptimo (decide el cliente)."""
        if self.detener or self.terminado or BOT_ACTUAL is not self:
            return                                       # detenido o reemplazado: no avisa nada
        pausado = self.pausa_mercado()
        espera = self.espera_decision
        malo = MERCADO.aviso and not MERCADO.operar_igual
        antes_p = getattr(self, "_aviso_pausa", False)
        antes_e = getattr(self, "_aviso_espera", False)
        if not malo:
            self._aviso_previo = False
        if pausado and not espera and not (antes_p and not antes_e):
            notificar("⚠ Mercado lateral y errático", "El bot está en pausa · avisa cuando mejore", tipo="mercado_malo")
        elif espera and not antes_e:
            notificar("✓ Mercado óptimo", "El mercado mejoró · ¿sigues operando?", tipo="mercado_ok")
        elif malo and not pausado and not getattr(self, "_aviso_previo", False):
            self._aviso_previo = True                    # una vez por cada racha de mercado malo
            if self.nivel > 0:
                txt = f"Pausa al recuperar · va {self.pnl:+.2f}"
            elif self.abiertas:
                txt = "Pausa al cerrar la operación"
            else:
                txt = f"Pausa al quedar en positivo · va {self.pnl:+.2f}"
            notificar("⚠ Mercado errático", txt, tipo="mercado_aviso")
        self._aviso_pausa, self._aviso_espera = pausado, espera

    def pausa_mercado(self):
        """Mercado malo: al iniciar la sesión el bot arranca en pausa (decide el cliente). Ya operando, solo se
        pausa si va en positivo, sin operaciones abiertas y sin recuperación pendiente (en negativo, primero
        recupera). Cuando el mercado mejora NO vuelve solo: espera a que el cliente toque "Seguir operando"."""
        if MERCADO.operar_igual:
            self.pausa_inicio = self.en_pausa_mkt = self.espera_decision = False
            return False
        if MERCADO.aviso:                                  # mercado malo
            if self.pausa_inicio or self.en_pausa_mkt or self.espera_decision:
                en = True
            else:
                en = self.pnl > 0 and not self.abiertas and self.nivel == 0
            if en:
                self.en_pausa_mkt, self.espera_decision = True, False
            return en
        if self.pausa_inicio or self.en_pausa_mkt:          # estaba en pausa y el mercado mejoró
            self.pausa_inicio = self.en_pausa_mkt = False
            self.espera_decision = True
        return self.espera_decision

    def seguir_operando(self):
        """El cliente decide seguir operando ahora que el mercado mejoró."""
        self.pausa_inicio = self.en_pausa_mkt = self.espera_decision = False
        self.log("▶ El mercado mejoró: el bot sigue operando por decisión del usuario.", "green")

    def modo_estricto(self):
        """v1.13: desactivado. Antes, con mercado malo y en negativo, solo aceptaba señales de 80 %+."""
        return False
        return MERCADO.aviso and not MERCADO.operar_igual and not self.pausa_mercado()


    def monto_recuperacion(self, nivel, ciclo, payout):
        cfg = self.cfg
        base = float(cfg["monto_entrada"])
        if nivel <= 0 or cfg["recuperacion"] == "ninguna":
            return base
        if cfg["rec_modo"] == "multiplicador":
            m = base * float(cfg["rec_multiplicador"]) ** nivel
        else:                                             # automático: recupera lo perdido + la ganancia base
            p = payout or 0.85
            m = (ciclo + base * p) / p
        return max(1.0, round(m, 2))

    def confianza_de(self, c):
        """Medidor del panel: qué opina cada IA de la mejor señal. El número grande es la probabilidad de la Juez."""
        eq = equipo()
        b = eq.base()
        o = c.get("o") or {}
        votos = []
        for k in NOMBRES_IA:
            v = o.get(k)
            votos.append("gris" if v is None else ("ok" if v >= b else "duda"))
        pj = c.get("pj")
        return {"valor": round(100 * pj) if pj is not None else None, "votos": votos, "par": c["par"],
                "dir": c["dir"], "juez": eq.juez_lista()}

    def tendencia_par(self, par, tf, prox=None):
        """Tendencia del par con sus velas CERRADAS (historial + las M1 que llegaron en vivo)."""
        k = (par, tf)
        corte = (prox - tf * 60) if prox else (int(self.b.ahora()) // (tf * 60)) * tf * 60   # inicio de la vela que se forma
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if tf == 1 and self.b.vivo.get(par):
            for v in self.b.velas_vivo(par):
                por_t[v["t"]] = v
        velas = [por_t[t] for t in sorted(por_t) if t < corte]
        return tendencia(velas)

    def velas_hasta(self, par, tf, cierre):
        """Velas CERRADAS del par hasta 'cierre' (incluye la que acaba de cerrar, armada con las M1 en vivo)."""
        k = (par, tf)
        por_t = {v["t"]: v for v in self.hist.get(k, [])}
        if self.b.vivo.get(par):
            m1 = self.b.velas_vivo(par)
            if tf == 1:
                for v in m1:
                    por_t[v["t"]] = v
            else:
                v = self.vela_en_formacion(m1, tf, cierre)
                if v:
                    por_t[v["t"]] = v
        return [por_t[x] for x in sorted(por_t) if x < cierre]

    def lectura_vivo(self, o, prox):
        """Dirección del gale según la TENDENCIA real del par (velas cerradas, media de 20 y ADX), no por segundos sueltos:
        tendencia fuerte -> el gale va a favor de ella · débil o lateral -> mantiene la dirección de la entrada."""
        t = self.tendencia_par(o["par"], o["tf"], prox)
        if t["fuerza"] == "fuerte" and t["dir"]:
            return t["dir"], 1.0 if t["dir"] == "call" else -1.0, [f"tendencia {t['txt']}"]
        return o["dir"], 0.0, [f"tendencia {t['txt']}: mantiene la dirección"]

    def disparar(self, cands, tfs_c, prox, revisados):
        """Elige UNA operación por cierre de vela.
        - Sin operación venciendo: la mejor señal entra justo antes del cierre (nunca tarde).
        - Con una operación venciendo en este cierre: el bot NO adivina. Deja todo preparado (señales y lectura en
          vivo para el gale) y decide con el RESULTADO REAL apenas IQ Option lo avisa (≈1 s después del cierre):
          si perdió -> gale o nivel; si ganó -> entrada normal. Así un gale ganado nunca se cuenta como perdido."""
        cfg = self.cfg
        rec = cfg["recuperacion"]
        # orden: acierto a la primera (70 %) + equipo de IAs (30 %): la Juez si ya demostró que acierta más que
        # el promedio; si no, lo que dicen los datos reales del par y de la estrategia
        for c in cands:
            o = c.get("o") or {}
            if c.get("ia") is not None:
                extra = c["ia"]
            else:
                datos = [o[k] for k in ("pares", "estrategias") if o.get(k) is not None]
                extra = sum(datos) / len(datos) if datos else c.get("conf", c["wr"])
            c["orden"] = 0.7 * c.get("puntaje", c.get("conf", c["wr"])) + 0.3 * extra + (1.0 if c.get("validada") else 0.0)
        cands.sort(key=lambda c: c["orden"], reverse=True)
        self.confianza = self.confianza_de(cands[0]) if cands else None
        self.ultimo_escaneo = {"hora": datetime.fromtimestamp(prox).strftime("%H:%M"), "revisados": revisados,
                               "senales": len(cands), "entradas": 0}
        if self.plan and self.plan["prox"] < prox:
            self.plan = None                               # su resultado nunca llegó a tiempo
        if self.detener:
            return
        abiertas = list(self.abiertas.values())
        if [o for o in abiertas if o["vence"] > prox + 1]:
            return                                         # una operación a la vez
        vence = [o for o in abiertas if abs(o["vence"] - prox) < 1]
        if vence and rec != "ninguna":
            o = vence[0]
            lectura = None
            try:
                if rec == "martingala":
                    lectura = self.lectura_vivo(o, prox)     # dirección del gale según la tendencia del par
                # auto: decide DESPUÉS del cierre, con la vela perdedora ya cerrada (ejecutar_plan)
            except Exception as e:
                lectura = (o["dir"], 0.0, [f"sin lectura ({str(e)[:40]})"]) if rec == "martingala" else None
            self.plan = {"par": o["par"], "vence": o["vence"], "prox": prox, "tf": o["tf"], "o": o,
                         "cands": list(cands), "lectura": lectura}
            self.fase = f"Esperando el resultado real de {o['par']} para decidir"
            return
        self._decidir(cands, prox)

    def ejecutar_plan(self, par, vence, res):
        """Llamado apenas llega el resultado real de la operación que vencía: decide y envía."""
        plan = self.plan
        if not plan or plan["par"] != par or abs(plan["vence"] - vence) > 1:
            return
        self.plan = None
        if self.detener or res is None:
            return
        plan["perdio"] = res < 0
        rec = self.cfg["recuperacion"]
        o = plan["o"]
        if res > 0 or self.nivel == 0:
            self.perd_ciclo.clear(); self.par_perdio = None
        elif res < 0:
            self.perd_ciclo[par] = self.perd_ciclo.get(par, 0) + 1
            self.par_perdio = par
            if self.perd_ciclo[par] >= REC_MAX_PERDIDAS_PAR:
                self.descanso[par] = time.time() + REC_DESCANSO_SEG
            if rec in ("auto", "martingala"):
                try:
                    velas = self.velas_hasta(par, o["tf"], plan["prox"])     # con la vela que acaba de perder
                    if rec == "auto":
                        accion, d_new, det = lectura_recuperacion(velas, o["dir"], self.perd_ciclo[par])
                        plan["accion"] = accion
                        plan["lectura"] = (d_new, 1.0 if d_new == "call" else -1.0, [det]) if accion != "nivel" else None
                        plan["motivo"] = det
                    else:
                        t = tendencia(velas)
                        if t["fuerza"] == "fuerte" and t["dir"]:
                            plan["lectura"] = (t["dir"], 1.0 if t["dir"] == "call" else -1.0, [f"tendencia {t['txt']}"])
                        else:
                            plan["lectura"] = (o["dir"], 0.0, [f"tendencia {t['txt']}: mantiene la dirección"])
                except Exception as e:
                    if rec == "auto":
                        plan["accion"], plan["lectura"], plan["motivo"] = "nivel", None, f"sin lectura ({str(e)[:40]})"
        try:
            self._decidir(plan["cands"], plan["prox"], plan)
        except Exception:
            with open(ERROR_LOG, "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}] plan\n{traceback.format_exc()}")

    def _decidir(self, cands, prox, plan=None):
        cfg = self.cfg
        if self.frenar_por_stop():
            return
        recuperando_ya = self.nivel > 0 and cfg["recuperacion"] != "ninguna"
        if not recuperando_ya and self.pausa_mercado():
            return                                         # mercado malo: no abre entradas nuevas (sí recupera)
        rec = cfg["recuperacion"]
        anticipo = max(0.05, float(cfg.get("anticipo_ms", 300)) / 1000.0)
        abiertas = list(self.abiertas.values())
        nivel, ciclo = self.nivel, self.ciclo_perdida          # el libro ya tiene el resultado real
        if nivel > int(cfg["rec_max"]):
            nivel, ciclo = 0, 0.0
        recuperando = nivel > 0 and rec != "ninguna"
        if self.pausado:
            return
        if getattr(self.b, "moneda", "USD") != "USD" and not getattr(self.b, "tasa", 1.0):
            if time.time() - getattr(self, "_t_tasa", 0) > 60:
                self._t_tasa = time.time()
                try:
                    self.b.preparar_moneda()
                    if self.b.tasa:
                        self.aviso_error = None; self.anunciar_moneda()
                except Exception:
                    pass
            if not getattr(self.b, "tasa", 1.0):
                return
        ahora_t = time.time()
        lista = [c for c in cands if self.descanso.get(c["par"], 0) <= ahora_t]     # pares en descanso: fuera
        if not recuperando:
            self.perd_ciclo.clear(); self.par_perdio = None
        o = plan["o"] if plan else None
        elegida, etiqueta = None, "ENTRADA"
        if recuperando:
            quiere_gale = bool(plan and plan.get("perdio") and plan.get("lectura") is not None)
            # v2.0: en martingala, desde el 2.º gale se recupera en OTRO par (como niveles): no persigue al par que falla
            mover_gale = quiere_gale and rec == "martingala" and nivel >= 2
            if mover_gale:
                quiere_gale = False
            if quiere_gale:
                d_gale, punt, det = plan["lectura"]
                cambio = d_gale != o["dir"]
                elegida = {"par": o["par"], "tf": o["tf"], "dir": d_gale, "payout": o.get("payout") or 0.8,
                           "estrategia": o.get("estrategia", "Gale"), "wr": o.get("wr") or 0.0,
                           "wr_g1": o.get("wr") or 0.0, "n": o.get("n") or 0, "conf": o.get("conf"),
                           "wg": o.get("wg"), "inicio_vela": prox, "cambio_dir": cambio, "inst": o.get("inst")}
                etiqueta = f"GALE {nivel}"
                lectura = " · ".join(det) if det else "sin datos"
                if rec == "auto" and cambio:
                    self.log(f"↻ {o['par']}: perdió y el mercado giró: se invierte a {d_gale.upper()} "
                             f"(antes {o['dir'].upper()}) · {lectura}", "cyan")
                elif rec == "auto":
                    self.log(f"→ {o['par']}: perdió en un retroceso; sigue en {d_gale.upper()} · {lectura}", "dim")
                elif cambio:
                    self.log(f"↻ {o['par']}: perdió; la tendencia va en contra y el gale va en {d_gale.upper()} "
                             f"(antes {o['dir'].upper()}) · {lectura}", "cyan")
                else:
                    self.log(f"→ {o['par']}: perdió; el gale sigue en {d_gale.upper()} · {lectura}", "dim")
            else:
                # nivel: otro par, a favor de SU tendencia (nunca contra una tendencia); primero las de tendencia fuerte
                rango = {"a_favor_fuerte": 0, "a_favor": 1, "lateral": 2}
                evitar = {o["par"]} if o else ({self.par_perdio} if self.par_perdio else set())
                otros = [c for c in lista if c["par"] not in evitar and c.get("tramo", "lateral") in rango]
                if plan and plan.get("perdio") and rec == "auto":
                    self.log(f"⇄ {o['par']}: perdió · {plan.get('motivo', '')} → NIVEL {nivel} en otro par a favor de su tendencia.", "cyan")
                otros.sort(key=lambda c: rango[c.get("tramo", "lateral")])
                elegida = otros[0] if otros else None
                etiqueta = f"NIVEL {nivel}"            # Nivel 1 = primera recuperación (igual que Gale 1)
                if mover_gale:
                    etiqueta = f"GALE {nivel}"
                    if elegida:
                        self.log(f"⇄ {o['par']}: perdió el gale; el GALE {nivel} pasa a {elegida['par']} "
                                 f"(no insiste en el mismo par).", "cyan")
                    else:
                        self.log(f"⇄ {o['par']}: perdió el gale; el GALE {nivel} espera una buena señal en otro par.", "dim")
        else:
            validadas = [c for c in lista if c.get("validada")]
            if validadas:
                elegida = validadas[0]
            elif lista and time.time() - self._t_ultima_entrada >= RESPALDO_SEG:
                elegida = lista[0]                         # hace rato sin señal validada: la mejor del catálogo normal
            else:
                elegida = None
        if not elegida:
            return
        if elegida["par"] in self.pares_en_uso:
            return
        monto = self.monto_recuperacion(nivel if recuperando else 0, ciclo, elegida["payout"])
        en_juego = sum(x["monto"] for x in abiertas)
        if recuperando and not self.puede_arriesgar(monto + en_juego):
            base = self.monto_recuperacion(0, 0.0, elegida["payout"])
            if self.puede_arriesgar(base + en_juego):
                self.log(f"La recuperación de ${monto:.2f} no cabe en el stop loss: se cierra el ciclo "
                         f"(−${ciclo:.2f}) y se sigue con la entrada base.", "bold yellow")
                with self.lock:
                    self.nivel, self.ciclo_perdida = 0, 0.0
                    self.ciclo_n += 1
                nivel, ciclo, recuperando, monto = 0, 0.0, False, base
                etiqueta = "ENTRADA"
                elegida.pop("cambio_dir", None)
        if not self.puede_arriesgar(monto + en_juego):
            self.log(f"Entrada de ${monto:.2f} cancelada: el stop loss no deja margen.", "bold yellow")
            return
        if plan:
            # después del resultado real: se envía ya, en la vela que acaba de empezar (máx. unos segundos)
            limite = LIMITE_GALE_SEG.get(elegida["tf"], 3)
            if self.b.ahora() > prox + limite:
                self.log(f"⏱ El resultado de {o['par']} llegó tarde ({self.b.ahora() - prox:+.1f}s): esta vela no se "
                         f"opera; se sigue en la próxima con el resultado ya contado.", "yellow")
                return
            elegida.update({"disparo": None, "post_cierre": True})
        else:
            if self.b.ahora() > prox - anticipo:
                self.log("⏱ El análisis terminó tarde para este cierre: no se envía la orden (nunca entra tarde).", "yellow")
                return
            elegida["disparo"] = prox - anticipo
        elegida["inicio_vela"] = prox
        elegida.update({"monto": monto, "etiqueta": etiqueta, "ciclo_n": self.ciclo_n,
                        "nivel_usado": nivel if recuperando else 0, "ciclo_antes": ciclo if recuperando else 0.0})
        self.ultimo_escaneo["entradas"] = 1
        self.lanzar(elegida)

    # ---------- ejecución ----------

    def avisar_error(self, texto, titulo="IQ Option rechazó la orden"):
        """Problema que el cliente DEBE ver: banda roja en pantalla + notificación (una vez cada 10 min por mensaje)."""
        self.aviso_error = {"titulo": titulo, "texto": texto, "t": time.time()}
        self.log(f"⚠ {titulo}: {texto}", "bold red")
        clave = (titulo + texto)[:120]
        if time.time() - self._avisos_notificados.get(clave, 0) > 600:
            self._avisos_notificados[clave] = time.time()
            try:
                notificar(f"⚠ {titulo}", texto[:160], tipo="error")
            except Exception:
                pass

    def anunciar_moneda(self):
        """Al iniciar: si la cuenta no es en dólares, deja claro cómo se convierte (y si no se pudo, no opera)."""
        m, tasa = getattr(self.b, "moneda", "USD"), getattr(self.b, "tasa", 1.0)
        if m == "USD":
            return
        if not tasa:
            self.avisar_error(f"Tu cuenta está en {m} y no se pudo leer el cambio a dólares. El bot no abre operaciones "
                              f"hasta poder leerlo (revisa tu internet).", "Moneda de la cuenta")
            return
        base = float(self.cfg["monto_entrada"])
        loc = self.b.saldo_local()
        f = lambda v: f"{v:,.0f}" if tasa >= 50 else f"{v:,.2f}"
        self.log(f"💱 Cuenta {self.cuenta} en {m} · 1 USD = {f(tasa)} {m} ({getattr(self.b, 'tasa_fuente', '')}). "
                 f"La entrada de ${base:.2f} se opera como {m} {f(self.b.a_local(base))}"
                 + (f" · saldo {m} {f(loc)} ≈ ${loc / tasa:,.2f}" if isinstance(loc, (int, float)) else "")
                 + ". Stops y ganancias se cuentan en dólares.", "bold cyan")

    def _bloquear(self, par, motivo):
        self.bloqueados[par] = time.time() + 1800
        if par in self.seleccion: self.seleccion.remove(par)
        self.b.detener_vivo(par)
        self.log(f"{par}: IQ Option no lo deja operar ahora ({motivo[:60]}). Se omite 30 min.", "yellow")

    def operar(self, s):
        """Envía UNA orden (entrada, gale o nivel) antes del cierre y anota el resultado."""
        cfg = self.cfg
        par, tf, d = s["par"], s["tf"], s["dir"]
        monto, etiqueta = s["monto"], s.get("etiqueta", "ENTRADA")
        clave = None
        res_final, expira = None, None
        try:
            if s.get("disparo"):
                self.b.esperar_hasta(s["disparo"], lambda: self.detener)
            if self.frenar_por_stop():                      # última revisión justo antes de comprar
                return
            if s.get("post_cierre"):
                if self.b.ahora() > s["inicio_vela"] + LIMITE_GALE_SEG.get(tf, 3):
                    self.log(f"{par} M{tf}: {etiqueta.lower()} descartada, ya pasaron más de "
                             f"{LIMITE_GALE_SEG.get(tf, 3)} s de la vela.", "yellow")
                    return
            elif self.b.ahora() > s["inicio_vela"] - 0.02:
                self.log(f"{par} M{tf}: la orden no alcanzó a salir antes del cierre; se descarta (nunca entra tarde).",
                         "yellow")
                return
            if not self.b.conectado:
                self.log(f"{par}: {etiqueta.lower()} cancelada, no hay conexión con IQ Option.", "yellow")
                return
            with self.lock:
                if self.stop_alcanzado():
                    return
                if not self.puede_arriesgar(monto):
                    margen = self.cfg["stop_loss"] + self.pnl - self.riesgo_abierto
                    self.log(f"{par}: {etiqueta} de ${monto:.2f} cancelada: el stop loss solo deja ${margen:.2f}.",
                             "bold yellow")
                    return
                self.riesgo_abierto += monto
            expira = s["inicio_vela"] + tf * 60
            t_envio = self.b.ahora()
            try:
                if s.get("inst") == "digital":
                    oid = self.b.comprar_digital(monto, par, d, tf, expira)
                else:
                    oid = self.b.comprar(monto, par, d, tf, expira)
            except Exception as e:
                with self.lock: self.riesgo_abierto -= monto
                txt = str(e).lower()
                m_loc = getattr(self.b, "moneda", "USD")
                monto_txt = texto_dinero(monto, False)          # en la moneda de la cuenta del cliente
                if any(k in txt for k in ("balance", "insufficient", "minimum", "maximum", "amount", "limit")):
                    self.log(f"ERROR al comprar {par} {monto_txt}: {e}", "bold red")
                    pista = (" Sube el monto de entrada en Configuración." if any(k in txt for k in ("minimum", "amount")) else
                             " Revisa tu saldo en IQ Option." if any(k in txt for k in ("balance", "insufficient")) else "")
                    self.avisar_error(f"{par} {monto_txt}: {e}.{pista}")
                elif "no confirmó" in txt:
                    self.log(f"{par}: IQ Option no confirmó la orden; revísala en la plataforma.", "bold red")
                    self.avisar_error(f"{par} {monto_txt}: IQ Option no confirmó la orden. Revisa la plataforma y tu conexión.",
                                      "Orden sin confirmar")
                else:
                    self._bloquear(par, str(e))
                    self.avisar_error(f"{par} {monto_txt}: {e}")
                return
            precio_entrada = self.precio_actual(par)
            with self.lock:
                self.seq += 1; clave = self.seq
                self.abiertas[clave] = {"par": par, "tf": tf, "dir": d, "monto": monto,
                                        "entrada": precio_entrada, "payout": s["payout"],
                                        "t0": self.b.ahora(),
                                        "ticks": deque([(self.b.ahora(), precio_entrada)] if precio_entrada else [], maxlen=1200),
                                        "intento": etiqueta, "vence": expira, "estrategia": s["estrategia"],
                                        "wr": s["wr"], "conf": s.get("conf", s["wr"]), "n": s["n"], "wg": s.get("wg"),
                                        "nivel_usado": s.get("nivel_usado", 0), "ciclo_antes": s.get("ciclo_antes", 0.0),
                                        "puntaje": s.get("puntaje"),
                                        "ciclo_n": s.get("ciclo_n"), "inst": s.get("inst")}
                self.ultima_entrada = dict(self.abiertas[clave], hora=time.time())
                self._t_ultima_entrada = time.time()
            rel = t_envio - s["inicio_vela"]
            extra = f", IA {s['ia']*100:.0f}%" if s.get("ia") is not None else ""
            self.log(f"{etiqueta} {par}{' (digital)' if s.get('inst') == 'digital' else ''} M{tf} {d.upper()} ${monto:.2f} · {s['estrategia']} "
                     f"({s['wr']*100:.0f}% en {s['n']} señales{extra}, payout {s['payout']*100:.0f}%) · "
                     f"enviada a {rel:+.2f}s del cierre", "bold cyan")
            try:
                res, via = self.b.resultado_rapido(oid, tf, monto, s["payout"])
            except Exception as e:
                with self.lock:
                    self.riesgo_abierto -= monto; self.abiertas.pop(clave, None)
                    self.stats["sin_resultado"] = self.stats.get("sin_resultado", 0) + 1
                self.log(f"{par}: {e} El P/L se ajustará con el saldo real.", "bold red")
                return
            with self.lock:
                self.abiertas.pop(clave, None)
                self.riesgo_abierto -= monto
                self.pnl = round(self.pnl + res, 2)
                self.ultimo_cierre = time.time()
                pnl = self.pnl
                self.curva.append((time.time(), pnl))
                if res > 0: self.stats["ganadas"] += 1
                elif res < 0: self.stats["perdidas"] += 1
                else: self.stats["empates"] += 1
                # libro de la recuperación (con el nivel con que salió ESTA operación; no depende del orden)
                if self.cfg["recuperacion"] != "ninguna":
                    viejo = s.get("ciclo_n") is not None and s.get("ciclo_n") != self.ciclo_n
                    if res > 0:
                        if s.get("nivel_usado", 0) > 0 and not viejo:
                            self.nivel, self.ciclo_perdida = 0, 0.0
                            self.ciclo_n += 1                 # ciclo recuperado: lo que siga de él ya no lo continúa
                    elif res < 0:
                        if viejo:
                            # salió antes de saber que el ciclo anterior ya se había recuperado:
                            # su pérdida abre un ciclo NUEVO desde el nivel 1 (no multiplica sobre el viejo)
                            if self.nivel == 0:
                                self.nivel, self.ciclo_perdida = 1, round(-res, 2)
                        else:
                            n = s.get("nivel_usado", 0) + 1
                            ciclo = round(s.get("ciclo_antes", 0.0) - res, 2)
                            if n > int(self.cfg["rec_max"]):
                                self.nivel, self.ciclo_perdida = 0, 0.0
                                self.ciclo_n += 1
                            else:
                                self.nivel, self.ciclo_perdida = n, ciclo
            res_final = res
            tag, est = ("GANADA", "bold green") if res > 0 else (("PERDIDA", "bold red") if res < 0 else ("EMPATE", "yellow"))
            self.log(f"{tag} {par} M{tf} {etiqueta} {res:+.2f} · P/L sesión {pnl:+.2f} · confirmado: {via}", est)
            if res > 0:
                tipo_txt = "Entrada" if etiqueta == "ENTRADA" else etiqueta.capitalize()
                notificar(f"Ganada · {par} {'▲ CALL' if d == 'call' else '▼ PUT'}",
                          f"{tipo_txt} · Sesión {texto_dinero(pnl)}", tipo="ganada", par=par, dir=d, op=tipo_txt,
                          monto=res, sesion=pnl, ganadas=self.stats["ganadas"])
                self.ultima_ganada = f"{par.split('-')[0]} {'▲' if d == 'call' else '▼'}"
            if res > 0 and s.get("nivel_usado", 0) > 0:
                self.log(f"✔ Recuperado en {etiqueta}: se cubrieron ${s.get('ciclo_antes', 0):.2f}. "
                         f"Se vuelve a la entrada base.", "bold green")
            registro = {"hora": datetime.fromtimestamp(s["inicio_vela"]).strftime("%H:%M"),   # cuando se abrió
                        "icono": getattr(self.b, "iconos", {}).get(par),
                        "resultado": tag, "par": par, "tf": tf, "dir": d, "tipo": etiqueta,
                        "monto": monto, "neto": res, "via": via, "estrategia": s["estrategia"]}
            self.resultados.appendleft(registro)
            if res != 0 and s.get("ia_keys"):
                self.ia.aprender(s["ia_keys"], res > 0, 2.0, {"real": 1})      # las reales pesan más
            if via != "historial":
                threading.Thread(target=self._verificar_historial, args=(oid, res, monto, registro), daemon=True).start()
            self.guardar([datetime.fromtimestamp(self.b.ahora()).isoformat(timespec="seconds"), self.cuenta,
                          par, f"M{tf}", d, s["estrategia"], etiqueta, monto, res, pnl, via])
        finally:
            with self.lock:
                self.pares_en_uso.discard(par)
                if clave is not None:
                    self.abiertas.pop(clave, None)
            if self.stop_alcanzado() and not self.detener:
                self.detener = True
                self.avisar_stop()
            if expira is not None:
                self.ejecutar_plan(par, expira, res_final)     # gale / nivel / entrada con el resultado REAL


    def _verificar_historial(self, oid, res, monto, registro):
        """Confirma el resultado en el historial oficial de IQ Option. Si no coincide, corrige el P/L y lo avisa."""
        oficial = self.b.confirmar_en_historial(oid, monto)
        if oficial is None:
            return
        registro["via"] = "historial"
        if abs(oficial - res) < 0.01:
            return
        cat = lambda v: "ganadas" if v > 0 else ("perdidas" if v < 0 else "empates")
        with self.lock:
            self.pnl = round(self.pnl + oficial - res, 2)
            self.stats[cat(res)] -= 1
            self.stats[cat(oficial)] += 1
            self.curva.append((time.time(), self.pnl))
        registro["neto"] = oficial
        registro["resultado"] = "GANADA" if oficial > 0 else ("PERDIDA" if oficial < 0 else "EMPATE")
        self.log(f"⚠ El historial de IQ Option corrigió {registro['par']}: {res:+.2f} → {oficial:+.2f}. "
                 f"P/L sesión {self.pnl:+.2f}", "bold yellow")

    def lanzar(self, s):
        with self.lock:
            self.pares_en_uso.add(s["par"])
        h = threading.Thread(target=self.operar, args=(s,), daemon=True)
        with self.lock_hilos:
            h.start(); self.hilos.append(h)

    def activas(self):
        with self.lock_hilos:
            self.hilos = [h for h in self.hilos if h.is_alive()]
            return len(self.hilos)

    # ---------- ciclo principal (hilo) ----------
    def ciclo(self):
        errores = deque(maxlen=20)
        try:
            self.fase = "Leyendo pares abiertos..."
            t0 = time.time()
            while not self.seleccion and not self.detener:
                if time.time() - t0 > 120:
                    self.log("Después de 2 minutos no hay pares para analizar. Revisa filtros (payout, OTC/real).", "yellow")
                    t0 = time.time()
                time.sleep(0.5)
            while not self.detener:
                try:
                    if not self.b.conectado:
                        time.sleep(1); continue
                    ahora = self.b.ahora()
                    prox = (int(ahora) // 60 + 1) * 60
                    adelanto = self.adelanto_analisis()
                    if prox - ahora < adelanto + 0.3:      # muy encima del cierre: se toma el siguiente
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                        continue
                    tfs_c = [tf for tf in self.tfs if (prox // 60) % tf == 0
                             and expiracion_valida(tf, prox + tf * 60, prox - 1)]
                    self.prox_cierre, self.tfs_prox = prox, tfs_c
                    if not tfs_c:
                        self.b.esperar_hasta(prox + 0.2, lambda: self.detener); continue
                    self.preparar(tfs_c, prox)
                    self.fase = "Esperando el cierre de vela"
                    if not self.b.esperar_hasta(prox - adelanto, lambda: self.detener): break
                    if self.activas() == 0 and not self.puede_arriesgar(self.monto_base()):
                        self.log(f"=== STOP LOSS: no queda margen para otra entrada (P/L {self.pnl:+.2f}) ===", "bold red")
                        self.detener = True; break
                    if not self.b.conectado:
                        continue
                    self.fase = "Analizando velas en vivo..."
                    t_a = time.time()
                    self.analisis_cortado = False
                    self.ia_resolver(prox)
                    cands, revisados = self.analizar_antes_del_cierre(tfs_c, prox)
                    self.t_analisis = 0.7 * self.t_analisis + 0.3 * (time.time() - t_a)
                    if self.analisis_cortado:
                        self.t_analisis = max(self.t_analisis, adelanto)      # la próxima vez empieza antes
                    self.disparar(cands, tfs_c, prox, revisados)
                    if self.pausado:
                        self.fase = "En pausa: analiza pero no abre operaciones"
                    elif self.espera_decision:
                        self.fase = "Mercado óptimo: esperando tu decisión para seguir"
                    elif self.pausa_mercado():
                        self.fase = "Mercado malo: en pausa hasta que mejore"
                    self.fase = "Esperando el cierre de vela"
                    try:
                        self.revisar_mercado()
                        self.avisar_mercado()
                        self.ia.guardar()
                        equipo().guardar()
                        red_senales().guardar()
                        self.guardar_sombra()
                        self.quiza_entrenar_red()
                    except Exception:
                        pass
                    self.b.esperar_hasta(prox + 0.2, lambda: self.detener)
                except Exception:
                    errores.append(time.time())
                    with open(ERROR_LOG, "a", encoding="utf-8") as f:
                        f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{traceback.format_exc()}")
                    self.log("Error en el ciclo (anotado en errores.log). El bot sigue funcionando.", "bold red")
                    if len(errores) >= 10 and errores[-1] - errores[0] < 600:
                        self.log("Muchos errores seguidos: pausa de 60 s y se revisa la conexión.", "bold yellow")
                        errores.clear(); self.b.ultimo_latido = 0   # obliga al vigilante a reconectar
                        time.sleep(60)
                    else:
                        time.sleep(2)
        finally:
            self.fase = "Esperando que cierren las operaciones abiertas..."
            for h in list(self.hilos): h.join(timeout=20 * 60)
            self.fase = "Detenido"
            self.ia.guardar(forzar=True)
            equipo().guardar(forzar=True)
            red_senales().guardar(forzar=True)
            self.guardar_sombra()
            self.terminado = True

    # ---------- pantalla ----------
    def render(self, alto, ancho=130):
        """Pantalla liviana: cabecera, operaciones abiertas y eventos de operaciones."""
        from rich.table import Table
        from rich.panel import Panel
        from rich.layout import Layout
        from rich.text import Text
        from rich import box
        cfg = self.cfg
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        wr = f"{st['ganadas']/tot*100:.0f}%" if tot else "-"
        pnl_est = "bold green" if self.pnl > 0 else ("bold red" if self.pnl < 0 else "bold white")
        cuenta_est = "bold black on yellow" if self.cuenta == "REAL" else "bold black on cyan"
        modo = "auto" if cfg["rec_modo"] == "auto" else f"x{cfg['rec_multiplicador']:g}"
        if cfg["recuperacion"] == "martingala":
            rec = f"Martingala {cfg['rec_max']} gales ({modo})"
        elif cfg["recuperacion"] == "niveles":
            rec = f"Niveles ({modo}) · nivel {self.nivel + 1}/{int(cfg['rec_max']) + 1}"
            if self.nivel > 0:
                rec += f" · por recuperar ${self.ciclo_perdida:.2f}"
        else:
            rec = "Sin recuperación"
        real = self.pnl_segun_saldo()
        inicio = f"{self.saldo_inicio:,.2f}" if isinstance(self.saldo_inicio, (int, float)) else "?"
        l1 = Text.assemble((f" {self.cuenta} ", cuenta_est), "  Saldo ", (self.saldo_txt, "bold"), (f" (inicio {inicio})", "dim"),
                           "   P/L ", (f"{self.pnl:+.2f}", pnl_est),
                           (f" (saldo real {real:+.2f})" if real is not None and abs(real - self.pnl) >= 0.01 else "", "dim"),
                           "   ", (f"{st['ganadas']} G", "green"), " · ", (f"{st['perdidas']} P", "red"),
                           " · ", (f"{st['empates']} E", "yellow"), f" · acierto {wr}",
                           (f" · {st.get('sin_resultado', 0)} sin resultado" if st.get("sin_resultado") else "", "red"))
        l2 = Text.assemble("Stop win ", (f"+{cfg['stop_win']:g}", "green"), " · Stop loss ", (f"-{cfg['stop_loss']:g}", "red"),
                           f"    {rec}    Entrada ${cfg['monto_entrada']:g}")
        if not self.b.conectado:
            con = Text.assemble(("● SIN CONEXIÓN  ", "bold red"), (self.fase, "yellow"))
        else:
            n_vivo = sum(1 for p in self.seleccion if self.b.vivo.get(p))
            if self.prox_cierre and not self.detener:
                falta = max(0, int(self.prox_cierre - self.b.ahora()))
                prox_txt = f"próximo cierre {', '.join('M'+str(t) for t in self.tfs_prox) or 'M1'} en {falta:>2}s"
            else:
                prox_txt = self.fase
            con = Text.assemble(("● ", "red" if self.detener else "green"),
                                ("Conectado" if not self.detener else self.fase, ""), "   ",
                                (prox_txt, "bold yellow"), "   ",
                                (f"vigilando {n_vivo} pares en vivo · TF {', '.join('M'+str(t) for t in self.tfs)}"
                                 + (f" · reconexiones {self.reconexiones}" if self.reconexiones else ""), "dim"))
        for t in (l1, l2, con):
            t.no_wrap = True; t.overflow = "ellipsis"
        cab_txt = Text("\n").join([l1, l2, con])
        cab_txt.no_wrap = True; cab_txt.overflow = "ellipsis"
        cab = Panel(cab_txt, title="[bold]IQ BOT ESCÁNER[/]", border_style="blue", box=box.ROUNDED)

        ta = Table(box=box.SIMPLE_HEAD, expand=True, header_style="bold blue", pad_edge=False)
        for c in ("Par", "TF", "Dirección", "Monto", "Tipo", "Vence en"):
            ta.add_column(c, no_wrap=True)
        ahora = self.b.ahora()
        for o in list(self.abiertas.values()):
            falta = max(0, int(o["vence"] - ahora))
            ta.add_row(o["par"], f"M{o['tf']}",
                       Text("▲ CALL", style="bold green") if o["dir"] == "call" else Text("▼ PUT", style="bold red"),
                       f"${o['monto']:.2f}", o["intento"], f"{falta//60}:{falta%60:02d}")
        if not self.abiertas:
            ta.add_row(Text("Esperando señal..." if self.b.conectado else "Sin conexión", style="dim"), "", "", "", "", "")
        alto_ab = min(cfg["max_operaciones_simultaneas"], 8) + 5
        arriba = Panel(ta, title=f"Operaciones abiertas ({len(self.abiertas)}/{cfg['max_operaciones_simultaneas']})",
                       border_style="magenta", box=box.ROUNDED)

        alto_ev = max(3, alto - 5 - alto_ab - 3)
        lineas = [Text.assemble((h + " ", "dim"), (m, e)) for h, m, e in list(self.eventos)[-alto_ev:]]
        cuerpo_ev = Text("\n").join(lineas) if lineas else Text("Todavía no hay operaciones.", style="dim")
        cuerpo_ev.no_wrap = True; cuerpo_ev.overflow = "ellipsis"
        ev = Panel(cuerpo_ev, title="Operaciones y resultados", border_style="green", box=box.ROUNDED)

        raiz = Layout()
        raiz.split_column(Layout(cab, size=5), Layout(arriba, size=alto_ab), Layout(ev),
                          Layout(Text(" Ctrl + C para detener", style="dim"), size=1))
        return raiz

    def iniciar_hilos(self):
        """Arranca el bot en segundo plano (para la aplicación con ventana)."""
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        for objetivo in (self.hilo_pares, self.hilo_vigilante, self.hilo_saldo, self.hilo_licencia, self.ciclo,
                         self.hilo_precios):
            threading.Thread(target=objetivo, daemon=True).start()

    def hilo_precios(self):
        """Cada segundo anota el precio de cada operación abierta (para las velas de 15 s en vivo)."""
        while not self.terminado:
            try:
                for o in list(self.abiertas.values()):
                    if o.get("entrada"):
                        p = self.precio_actual(o["par"])
                        if p is not None:
                            o["ticks"].append((self.b.ahora(), p))
            except Exception:
                pass
            time.sleep(1)

    @staticmethod
    def velas_15s(o):
        """Arma 12 velas que cubren toda la operación (M1: de 5 s, M5: de 25 s, M15: de 75 s)."""
        t0 = o["t0"]
        seg = max(1.0, (o["vence"] - t0) / VELAS_VIVO)
        por = {}
        for t, p in list(o["ticks"]):
            k = min(VELAS_VIVO - 1, max(0, int((t - t0) // seg)))
            v = por.get(k)
            if v is None:
                por[k] = [p, p, p, p]
            else:
                v[1] = max(v[1], p); v[2] = min(v[2], p); v[3] = p
        if not por:
            return []
        velas, previo = [], o["entrada"]
        for k in range(max(por) + 1):
            v = por.get(k)
            if v is None:
                v = [previo, previo, previo, previo]
            else:
                v = [previo if k else v[0], max(v[1], previo if k else v[0]), min(v[2], previo if k else v[0]), v[3]]
            velas.append([round(x, 6) for x in v])
            previo = v[3]
        return velas

    def resumen_gui(self):
        """Todo lo que muestra la ventana de operaciones, en datos simples."""
        cfg = self.cfg
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        ahora = self.b.ahora()
        abiertas = []
        for o in list(self.abiertas.values()):
            dur = o["tf"] * 60
            falta = max(0.0, o["vence"] - ahora)
            # ¿va ganando o perdiendo? precio de ahora contra el de entrada
            vivo = None
            precio = self.precio_actual(o["par"])
            if precio is not None and o.get("entrada"):
                if not o["ticks"] or o["ticks"][-1][1] != precio:
                    o["ticks"].append((self.b.ahora(), precio))
                dif = precio - o["entrada"]
                if dif == 0:
                    estado, neto = "empate", 0.0
                elif (dif > 0) == (o["dir"] == "call"):
                    estado, neto = "ganando", round(o["monto"] * (o.get("payout") or 0.8), 2)
                else:
                    estado, neto = "perdiendo", -round(o["monto"], 2)
                vivo = {"estado": estado, "neto": neto, "entrada": o["entrada"], "dir": o["dir"],
                        "velas": self.velas_15s(o), "huecos": VELAS_VIVO}
            abiertas.append({"par": o["par"], "tf": o["tf"], "dir": o["dir"], "monto": o["monto"], "tipo": o["intento"],
                             "falta": int(falta), "progreso": round(min(1.0, max(0.0, 1 - falta / dur)), 3),
                             "dur": round(max(1.0, o["vence"] - o["t0"]), 1), "falta_f": round(falta, 1),
                             "estrategia": o.get("estrategia", ""), "wr": o.get("wr"), "conf": o.get("conf"),
                             "n": o.get("n"), "nr": o.get("nr"), "gr": o.get("gr"), "wg": o.get("wg"), "vivo": vivo})
        ue = None
        if self.ultima_entrada:
            u = self.ultima_entrada
            ue = {"par": u["par"], "tf": u["tf"], "dir": u["dir"], "wr": u.get("wr"), "conf": u.get("conf"),
                  "n": u.get("n"), "nr": u.get("nr"), "gr": u.get("gr"), "wg": u.get("wg"), "tipo": u["intento"],
                  "hace": int(time.time() - u["hora"])}
        real = self.pnl_segun_saldo()
        prox = None
        if self.prox_cierre and not self.detener:
            prox = {"seg": max(0, int(self.prox_cierre - ahora)),
                    "tfs": [f"M{t}" for t in (self.tfs_prox or [1])]}
        return {
            "cuenta": self.cuenta, "saldo": self.saldo_actual, "saldo_inicio": self.saldo_inicio,
            "moneda": getattr(self.b, "moneda", "USD"), "tasa": getattr(self.b, "tasa", 1.0),
            "aviso_error": self.aviso_error,
            "pnl": self.pnl, "pnl_real": real, "ajustes_saldo": self.ajustes_saldo,
            "ganadas": st["ganadas"], "perdidas": st["perdidas"], "empates": st["empates"],
            "sin_resultado": st.get("sin_resultado", 0),
            "acierto": round(st["ganadas"] / tot * 100, 1) if tot else None,
            "stop_win": cfg["stop_win"], "stop_loss": cfg["stop_loss"], "entrada": cfg["monto_entrada"],
            "recuperacion": cfg["recuperacion"], "rec_modo": cfg["rec_modo"], "rec_max": cfg["rec_max"],
            "rec_mult": cfg["rec_multiplicador"], "nivel": self.nivel + 1, "por_recuperar": self.ciclo_perdida,
            "proxima_entrada": self.monto_siguiente_nivel(0.85),
            "conectado": self.b.conectado, "fase": self.fase, "pausado": self.pausado,
            "detenido": self.terminado, "deteniendo": self.detener and not self.terminado,
            "prox_cierre": prox, "reloj": round(self.b.offset, 2), "ultima_entrada": ue,
            "vigilando": sum(1 for p in self.seleccion if self.b.vivo.get(p)), "pares_abiertos": self.total_abiertos,
            "escaneo": self.ultimo_escaneo, "catalogados": len({k[0] for k in self.cat}),
            "tfs": [f"M{t}" for t in self.tfs], "reconexiones": self.reconexiones,
            "max_ops": cfg["max_operaciones_simultaneas"], "abiertas": abiertas,
            "resultados": list(self.resultados)[:60],
            "curva": [round(p, 2) for _, p in self.curva[-300:]],
            "eventos": [{"hora": h, "texto": m, "estilo": e} for h, m, e in list(self.eventos)[-40:]],
            "omitidos": [p for p, t in self.bloqueados.items() if t > time.time()][:12],
            "mercado": MERCADO.resumen(), "pausa_mercado": self.pausa_mercado(), "espera_decision": self.espera_decision, "estricto": self.modo_estricto(),
            "confianza": self.confianza, "hora_server": round(self.b.ahora(), 2),
            "equipo": equipo().resumen(),
        }

    def correr(self):
        from rich.console import Console
        from rich.live import Live
        consola = Console(file=sys.__stdout__)
        # la librería escribe mensajes sueltos: se mandan a un archivo para no ensuciar la pantalla
        archivo_lib = open("libreria.log", "a", encoding="utf-8")
        logging.basicConfig(stream=archivo_lib, level=logging.WARNING, force=True)
        viejo_out, viejo_err = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = archivo_lib
        self.log(f"Bot iniciado en cuenta {self.cuenta}. Saldo {self.saldo_txt}.", "bold")
        self.anunciar_moneda()
        threading.Thread(target=self.hilo_pares, daemon=True).start()
        threading.Thread(target=self.hilo_vigilante, daemon=True).start()
        threading.Thread(target=self.hilo_saldo, daemon=True).start()
        threading.Thread(target=self.hilo_licencia, daemon=True).start()
        principal = threading.Thread(target=self.ciclo, daemon=True)
        principal.start()
        try:
            with Live(self.render(consola.size.height, consola.size.width), console=consola, screen=True,
                      refresh_per_second=1, transient=False) as live:
                while not self.terminado:
                    try:
                        live.update(self.render(consola.size.height, consola.size.width))
                        time.sleep(1)
                    except KeyboardInterrupt:
                        if not self.detener:
                            self.detener = True
                            self.log("Deteniendo... se esperan las operaciones abiertas (Ctrl + C otra vez para salir ya).", "yellow")
                        else:
                            break
                live.update(self.render(consola.size.height, consola.size.width))
                time.sleep(1)
        finally:
            sys.stdout, sys.stderr = viejo_out, viejo_err
        st = self.stats
        tot = st["ganadas"] + st["perdidas"]
        wr = (st["ganadas"] / tot * 100) if tot else 0
        print("\n" + "=" * 60)
        print(f"FIN DE LA SESIÓN ({self.cuenta})")
        final = self.b.saldo()
        print(f"Ganadas: {st['ganadas']}  Perdidas: {st['perdidas']}  Empates: {st['empates']}  Acierto: {wr:.1f}%"
              + (f"  Sin resultado: {st['sin_resultado']}" if st.get("sin_resultado") else ""))
        if isinstance(final, (int, float)) and isinstance(self.saldo_inicio, (int, float)):
            print(f"Saldo inicial: {self.saldo_inicio:,.2f}   Saldo final: {final:,.2f}   "
                  f"P/L REAL (según IQ Option): {final - self.saldo_inicio:+.2f}")
        print(f"P/L calculado por el bot: {self.pnl:+.2f}" + (f"  (se cuadró con el saldo {self.ajustes_saldo} vez/veces)" if self.ajustes_saldo else ""))
        print("Últimos eventos:")
        for h, m, _ in list(self.eventos)[-8:]:
            print(f"  {h} {m}")
        print("=" * 60)

# =====================================================================
#  MENÚ
# =====================================================================

def preguntar(texto, defecto, tipo=str):
    while True:
        r = input(f"{texto} [{defecto}]: ").strip()
        if not r:
            return defecto
        try:
            if tipo is bool:
                if r.lower() in ("s", "si", "sí", "y", "yes", "1"): return True
                if r.lower() in ("n", "no", "0"): return False
                raise ValueError
            if tipo is float: return float(r.replace(",", "."))
            return tipo(r)
        except ValueError:
            print("   Valor no válido, intenta de nuevo.")

def preguntar_lista(texto, defecto, conv=float):
    while True:
        r = input(f"{texto} [{','.join(str(x) for x in defecto)}]: ").strip()
        if not r:
            return list(defecto)
        try:
            return [conv(x.strip()) for x in r.replace(";", ",").split(",") if x.strip()]
        except ValueError:
            print("   Escribe números separados por coma, por ejemplo: 1,2.2,4.8")

def cargar_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                guardado = json.load(f)
            if "rec_max" not in guardado and "martingala_max_gales" in guardado:   # versión anterior
                guardado["rec_max"] = max(1, int(guardado.get("martingala_max_gales") or 1))
                if float(guardado.get("martingala_factor") or 0) > 0:
                    guardado["rec_modo"] = "multiplicador"
                    guardado["rec_multiplicador"] = float(guardado["martingala_factor"])
            for k in ("martingala_max_gales", "martingala_factor", "niveles_montos"):
                guardado.pop(k, None)
            if int(guardado.get("filtros_v", 0) or 0) < 2:
                # v1.2: filtros más simples (acierto simple, sin ciclo reciente ni pausa)
                for k in ("filtro_reciente", "ciclo_reciente", "pausa_tras_perdida"):
                    guardado.pop(k, None)
                guardado["winrate_minimo"] = 0.75
                guardado["min_senales_catalogo"] = 10
                guardado["velas_catalogo"] = 300
                guardado["filtros_v"] = 2
            if int(guardado.get("filtros_v", 0) or 0) < 3:
                guardado["max_operaciones_simultaneas"] = 1      # v1.10: una operación a la vez
                guardado["filtros_v"] = 3
            if int(guardado.get("filtros_v", 0) or 0) < 4:
                guardado["filtros_v"] = 4
            if int(guardado.get("filtros_v", 0) or 0) < 5:
                tfs = [t for t in (guardado.get("temporalidades") or [1]) if t in (1, 5, 15)]
                guardado["temporalidades"] = [min(tfs)] if tfs else [1]   # v1.17: una sola temporalidad
                guardado["filtros_v"] = 5
            guardado["max_pares"] = MAX_PARES                    # siempre todos los pares
            guardado["velas_catalogo"] = VELAS_CATALOGO          # v2.0: fijo en el código
            for k in ("ia_filtra", "ia_precision_alta", "solo_velas_fuertes", "estrategias_auto",
                      "estrategias_activas", "solo_horas_buenas"):     # opciones de versiones anteriores
                guardado.pop(k, None)
            cfg.update(guardado)
        except Exception:
            print("Aviso: config_bot.json estaba dañado; se usan valores por defecto.")
    cfg["max_operaciones_simultaneas"] = 1
    if cfg.get("recuperacion") not in ("ninguna", "martingala", "niveles", "auto"):
        cfg["recuperacion"] = "martingala"
    try:
        cfg["temporalidades"] = sorted({int(t) for t in cfg["temporalidades"] if int(t) in TEMPORALIDADES}) or [1]
    except Exception:
        cfg["temporalidades"] = [1]
    return cfg

def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def paso_login(cfg):
    print("\n========== 1) INICIAR SESIÓN EN IQ OPTION ==========")
    for intento in range(1, 4):
        email = input(f"Correo [{cfg['email']}]: ").strip() if cfg.get("email") else input("Correo: ").strip()
        email = email or cfg.get("email", "")
        if "@" not in email:
            print("   Escribe un correo válido."); continue
        clave = getpass.getpass("Contraseña (no se ve mientras escribes): ")
        if not clave:
            print("   La contraseña está vacía."); continue
        print("Conectando con IQ Option...")
        broker, error = BrokerIQ.iniciar_sesion(
            email, clave, lambda: input("IQ Option te envió un código por SMS. Escríbelo: ").strip())
        clave = None
        if broker:
            cfg["email"] = email
            guardar_config(cfg)
            print("✔ Sesión iniciada correctamente.")
            return broker
        print(f"✘ No se pudo iniciar sesión: {error}")
        if "inesperada" in error and not os.environ.get("IQBOT_REINICIADO"):
            print("   Puede que IQ Option haya cambiado algo. Se busca una versión nueva de la librería...")
            if actualizar_libreria():
                reiniciar_bot()
            print("   No hay versión nueva de la librería todavía.")
        if intento < 3:
            print("   Intenta de nuevo.\n")
    print("\nSe alcanzaron 3 intentos. Verifica tus datos entrando a iqoption.com desde el navegador.")
    return None

def paso_cuenta(broker, cfg):
    print("\n========== 2) ELEGIR CUENTA ==========")
    try:
        s = broker.saldos()
    except Exception:
        s = {}
    demo = s.get("PRACTICE"); real = s.get("REAL")
    fmt = lambda x: f"{x[0]:,.2f} {x[1]}" if x and x[0] is not None else "?"
    print(f"  1 = DEMO  (práctica)   saldo: {fmt(demo)}")
    print(f"  2 = REAL  (dinero real) saldo: {fmt(real)}")
    actual = "2" if cfg.get("cuenta") == "REAL" else "1"
    while True:
        op = input(f"Elige 1 o 2 [{actual}]: ").strip() or actual
        if op in ("1", "2"): break
        print("   Escribe 1 o 2.")
    cfg["cuenta"] = "REAL" if op == "2" else "PRACTICE"
    broker.usar_cuenta(cfg["cuenta"])
    nombre = "REAL" if cfg["cuenta"] == "REAL" else "DEMO"
    print(f"✔ Cuenta {nombre} seleccionada. Saldo: {broker.saldo()}")
    return nombre

def tabla_recuperacion(cfg, payout=0.85):
    """[(etiqueta, monto, perdido_acumulado_si_pierde, neto_si_gana)]"""
    base = float(cfg["monto_entrada"]); filas = []; perdido = 0.0; monto = base
    nombre = {"martingala": "Gale", "auto": "Recuperación"}.get(cfg["recuperacion"], "Nivel")
    for i in range(int(cfg["rec_max"]) + 1):
        if i > 0:
            if cfg["rec_modo"] == "multiplicador":
                monto = monto * float(cfg["rec_multiplicador"])
            else:
                monto = (perdido + base * payout) / payout
            monto = max(1.0, round(monto, 2))
        etiqueta = "Entrada" if i == 0 else f"{nombre} {i}"
        neto = monto * payout - perdido
        perdido += monto
        filas.append((etiqueta, monto, perdido, neto))
    return filas

def mostrar_tabla_recuperacion(cfg, payout=0.85):
    filas = tabla_recuperacion(cfg, payout)
    print(f"\n   Montos de recuperación (calculados con payout {payout*100:.0f}%; el bot usa el payout real de cada par):")
    print(f"   {'':<10}{'Monto':>10}{'Si gana aquí':>16}{'Si pierde, va perdiendo':>26}")
    for et, monto, perdido, neto in filas:
        print(f"   {et:<10}{'$'+format(monto, '.2f'):>10}{format(neto, '+.2f'):>16}{'-$'+format(perdido, '.2f'):>26}")
    total = filas[-1][2]
    print(f"   Riesgo total si se pierde todo: ${total:.2f}")
    if cfg["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:]):
        print("   ⚠ Con ese multiplicador, ganar en algún paso NO alcanza a recuperar lo perdido. "
              "Usa el modo automático o un multiplicador mayor.")
    print()
    return total

def paso_ajustes(cfg):
    print("\n========== 3) AJUSTES (Enter = dejar el valor entre corchetes) ==========")
    cfg["monto_entrada"] = preguntar("Monto de entrada $", cfg["monto_entrada"], float)
    tfs = preguntar_lista("Temporalidades en minutos (1, 2, 5, 15)", cfg["temporalidades"], int)
    cfg["temporalidades"] = sorted({t for t in tfs if t in TEMPORALIDADES}) or [1]
    cfg["incluir_mercado_real"] = preguntar("¿Operar mercado real? (s/n)", "s" if cfg["incluir_mercado_real"] else "n", bool) in (True, "s")
    cfg["incluir_otc"] = preguntar("¿Operar OTC? (s/n)", "s" if cfg["incluir_otc"] else "n", bool) in (True, "s")
    if not cfg["incluir_mercado_real"] and not cfg["incluir_otc"]:
        print("   Tienes que elegir al menos uno; se activan los dos."); cfg["incluir_mercado_real"] = cfg["incluir_otc"] = True
    cfg["payout_minimo"] = preguntar("Payout mínimo en % (ej. 80)", int(round(cfg["payout_minimo"] * 100)), float) / 100
    cfg["max_pares"] = min(MAX_PARES, max(1, preguntar(f"¿Cuántos pares vigilar? (los de mejor payout, máx. {MAX_PARES})",
                                                         min(cfg.get("max_pares", 20), MAX_PARES), int)))
    cfg["max_operaciones_simultaneas"] = max(1, preguntar("Máximo de operaciones al mismo tiempo", cfg["max_operaciones_simultaneas"], int))
    print("\nRecuperación:  1 = ninguna   2 = martingala (gale en el mismo par, vela siguiente)")
    print("               3 = niveles (la pérdida se recupera en la siguiente señal, en cualquier par)")
    act = {"ninguna": "1", "martingala": "2", "niveles": "3"}.get(cfg["recuperacion"], "2")
    op = preguntar("Elige 1, 2 o 3", act)
    cfg["recuperacion"] = {"1": "ninguna", "2": "martingala", "3": "niveles"}.get(op, cfg["recuperacion"])
    if cfg["recuperacion"] != "ninguna":
        palabra = "gales" if cfg["recuperacion"] == "martingala" else "niveles de recuperación"
        cfg["rec_max"] = min(6, max(1, preguntar(f"¿Cuántos {palabra}?", cfg["rec_max"], int)))
        print("Cálculo del monto:  1 = automático (recupera todo lo perdido + deja la ganancia)")
        print("                    2 = multiplicador fijo (ej. 2.2 = cada entrada es 2.2 veces la anterior)")
        m = preguntar("Elige 1 o 2", "1" if cfg["rec_modo"] == "auto" else "2")
        cfg["rec_modo"] = "multiplicador" if m == "2" else "auto"
        if cfg["rec_modo"] == "multiplicador":
            cfg["rec_multiplicador"] = max(1.0, preguntar("Multiplicador", cfg["rec_multiplicador"], float))
        total = mostrar_tabla_recuperacion(cfg)
        sugerido = math.ceil(total)
    else:
        sugerido = cfg["monto_entrada"] * 3
    cfg["stop_win"] = preguntar("Stop WIN (ganancia para detenerse) $", cfg["stop_win"], float)
    if cfg["stop_loss"] < sugerido:
        print(f"   Para que la recuperación completa quepa, el stop loss debería ser al menos ${sugerido}.")
    cfg["stop_loss"] = preguntar("Stop LOSS (pérdida máxima) $", max(cfg["stop_loss"], sugerido) if cfg["recuperacion"] != "ninguna" else cfg["stop_loss"], float)
    if cfg["recuperacion"] != "ninguna" and cfg["stop_loss"] < sugerido:
        print(f"   ⚠ Con stop loss ${cfg['stop_loss']:g} la recuperación se cortará antes del último "
              f"{'gale' if cfg['recuperacion'] == 'martingala' else 'nivel'} (se necesitan ${sugerido}).")
    guardar_config(cfg)
    print(f"✔ Ajustes guardados en {CONFIG_FILE}")

def main():
    print("=" * 60)
    print(f"   IQ BOT ESCANER {VERSION_BOT} - Opciones binarias (M1 / M2 / M5 / M15)")
    print("=" * 60)
    ordenar_archivos()
    asegurar_librerias()
    cfg = cargar_config()
    if cfg.get("actualizar_libreria", True) and not os.environ.get("IQBOT_REINICIADO"):
        actualizar_libreria()

    broker = paso_login(cfg)
    if not broker:
        return
    print("\nVerificando licencia...")
    ok, msg = verificar_licencia(cfg.get("email"), broker.id_iq())
    print(("✔ " if ok else "✘ ") + msg)
    if not ok:
        return
    nombre = paso_cuenta(broker, cfg)
    paso_ajustes(cfg)

    saldo = broker.saldo()
    if isinstance(saldo, (int, float)) and cfg["stop_loss"] > saldo:
        print(f"\nTu stop loss ({cfg['stop_loss']}) es mayor que tu saldo ({saldo}). Bájalo y vuelve a iniciar.")
        return
    rec = cfg["recuperacion"]
    modo = "automático" if cfg["rec_modo"] == "auto" else f"multiplicador x{cfg['rec_multiplicador']:g}"
    extra = (f" ({cfg['rec_max']} gales, {modo})" if rec == "martingala"
             else f" ({cfg['rec_max']} niveles, {modo})" if rec == "niveles" else "")
    print("\n========== 4) RESUMEN ==========")
    print(f"Cuenta {nombre} | saldo {saldo}")
    print(f"Entrada ${cfg['monto_entrada']} | {', '.join('M'+str(t) for t in cfg['temporalidades'])} | "
          f"{'real ' if cfg['incluir_mercado_real'] else ''}{'OTC' if cfg['incluir_otc'] else ''} | "
          f"máx. {cfg['max_operaciones_simultaneas']} a la vez")
    print(f"Recuperación: {rec}{extra} | stop win {cfg['stop_win']} / stop loss {cfg['stop_loss']}")
    pregunta = "¿Iniciar con DINERO REAL? (s/n): " if nombre == "REAL" else "¿Iniciar en la cuenta DEMO? (s/n): "
    if input(pregunta).strip().lower() not in ("s", "si", "sí"):
        print("Cancelado."); return
    Bot(broker, cfg, nombre).correr()


def arrancar():
    try:
        main()
    except KeyboardInterrupt:
        print("\nDetenido.")
    except SystemExit as e:
        if e.code not in (None, 0):
            print(f"\n{e.code}")
    except Exception:
        err = traceback.format_exc()
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now():%Y-%m-%d %H:%M:%S}]\n{err}")
        print("\n" + "!" * 60)
        print("Ocurrió un error inesperado:")
        print(err)
        print(f"Quedó guardado en {os.path.join(DATOS, ERROR_LOG)}. Envíamelo para corregirlo.")
        print("!" * 60)
    finally:
        try:
            input("\nPresiona Enter para cerrar esta ventana...")
        except Exception:
            pass


if __name__ == "__main__":
    arrancar()
