# -*- coding: utf-8 -*-
"""
Servidor local para la versión Android (y pruebas): muestra interfaz.html y atiende las
llamadas de la ventana a la clase Api, solo desde el mismo equipo (127.0.0.1) y con una clave
aleatoria por sesión, para que otras apps del teléfono no puedan manejar el bot.
"""
import json, os, secrets, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def iniciar(api, ruta_html, puerto=0):
    """Arranca el servidor en segundo plano y devuelve la dirección a abrir."""
    token = secrets.token_urlsafe(24)
    with open(ruta_html, encoding="utf-8") as f:
        html = f.read().replace("/*IQBOT_LOCAL*/", "window.IQBOT_LOCAL = {token: %s};" % json.dumps(token), 1)
    pagina = html.encode("utf-8")
    metodos = {n for n in dir(api) if not n.startswith("_") and callable(getattr(api, n))}

    class Manejador(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _responder(self, codigo, cuerpo, tipo="application/json; charset=utf-8"):
            self.send_response(codigo)
            self.send_header("Content-Type", tipo)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self._responder(200, pagina, "text/html; charset=utf-8")
            else:
                self._responder(404, b"{}")

        def do_POST(self):
            if not self.path.startswith("/api/") or self.headers.get("X-Token") != token:
                return self._responder(403, b'{"error":"no autorizado"}')
            nombre = self.path[5:]
            if nombre not in metodos:
                return self._responder(404, b'{"error":"no existe"}')
            try:
                largo = int(self.headers.get("Content-Length") or 0)
                args = json.loads(self.rfile.read(largo) or b"[]")
                if not isinstance(args, list):
                    args = []
                res = getattr(api, nombre)(*args)
                self._responder(200, json.dumps(res, default=str).encode("utf-8"))
            except Exception as e:
                self._responder(500, json.dumps({"error": str(e)}).encode("utf-8"))

    servidor = ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)
    servidor.daemon_threads = True
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{servidor.server_address[1]}/", servidor
