# -*- coding: utf-8 -*-
"""
IQ Bot Escáner - aplicación con ventana.
La interfaz (interfaz.html) se muestra con el motor de Edge (WebView2) mediante pywebview,
y habla con el bot (iq_bot.py) a través de la clase Api.
"""
import json, os, sys, threading, time, traceback

if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")

import iq_bot as nucleo


REINICIAR = None      # Android pone aquí su forma de recargar la app tras una actualización
ABRIR_ENLACE = None   # Android pone aquí su forma de abrir el navegador del celular
ENLACE_REGISTRO = "https://iqoption.net/lp/mobile-partner-pwa/es/?aff=838529&aff_model=revenue"   # afiliado de Leiner Serpa


def ruta_recurso(nombre):
    """Ruta de un archivo de esta versión (la descargada por actualización, la del .exe o junto al script)."""
    junto = os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)
    if os.path.isfile(junto):
        return junto
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, nombre)


def _arranque():
    """El módulo que verifica actualizaciones (solo existe si el programa se abrió con arranque.py)."""
    return sys.modules.get("arranque")


def reiniciar_programa():
    """Vuelve a abrir el programa para usar la versión recién descargada."""
    if REINICIAR:
        REINICIAR()
        return
    import subprocess
    env = dict(os.environ, PYINSTALLER_RESET_ENVIRONMENT="1")
    if getattr(sys, "frozen", False):
        comando = [sys.executable] + sys.argv[1:]
    else:
        comando = [sys.executable, os.path.abspath(sys.argv[0])] + sys.argv[1:]
    subprocess.Popen(comando, env=env, close_fds=True)
    os._exit(0)


_TECLADO = []   # se guarda la referencia para que Android no la descarte antes de usarla


def ajustar_teclado_android():
    """Android: al abrir el teclado, la pantalla se DESPLAZA hacia arriba en vez de encogerse.
    Encoger la ventana es lo que dejaba la mitad de la app en negro al escribir el correo o la clave."""
    try:
        from java import jclass, dynamic_proxy
    except ImportError:
        return False                      # PC: no aplica
    try:
        actividad = jclass("org.beeware.android.MainActivity").singletonThis
        modo = jclass("android.view.WindowManager$LayoutParams").SOFT_INPUT_ADJUST_PAN
        Runnable = jclass("java.lang.Runnable")

        class Aplicar(dynamic_proxy(Runnable)):
            def run(self):
                try:
                    actividad.getWindow().setSoftInputMode(modo)
                except Exception:
                    pass

        tarea = Aplicar()
        _TECLADO.append(tarea)
        actividad.runOnUiThread(tarea)
        return True
    except Exception:
        return False


# =====================================================================
#  NOTIFICACIONES (PC: avisos de Windows · celular: notificaciones de Android)
#  y funcionamiento en segundo plano en el celular (servicio en primer plano)
# =====================================================================
_NOTIF_N = [100]


def _es_android():
    try:
        import java  # noqa: F401
        return True
    except ImportError:
        return False


def _actividad():
    from java import jclass
    return jclass("org.beeware.android.MainActivity").singletonThis


def _en_ui(fn):
    """Ejecuta fn en el hilo de la pantalla de Android."""
    from java import jclass, dynamic_proxy
    Runnable = jclass("java.lang.Runnable")

    class Tarea(dynamic_proxy(Runnable)):
        def run(self):
            try:
                fn()
            except Exception:
                pass
    t = Tarea()
    _TECLADO.append(t)
    _actividad().runOnUiThread(t)


# ---------- Android: tarjetas de notificación del bot ----------
_API = []                       # la Api activa (para el botón "Operar de todos modos" de la notificación)
_ESTILO = {  # tipo: (color inicio del degradado, color final, acento)
    "fija": ("#0D1626", "#1C2D52", "#34D27F"),
    "ganada": ("#063A25", "#12804F", "#5CF2A6"),
    "stopwin": ("#05331F", "#0F7A49", "#5CF2A6"),
    "stoploss": ("#3A0B12", "#9B2431", "#FF8A8A"),
    "mercado_malo": ("#3A2204", "#B0650F", "#FFC266"),        # naranja: el bot está en pausa
    "mercado_aviso": ("#2A1E08", "#7A5410", "#FFD27A"),       # dorado: errático, se pausará al terminar
    "mercado_ok": ("#063A25", "#12804F", "#5CF2A6"),
}
_PAIS = {"EUR": "EU", "USD": "US", "GBP": "GB", "JPY": "JP", "CHF": "CH", "AUD": "AU", "CAD": "CA", "NZD": "NZ",
         "COP": "CO", "BRL": "BR", "MXN": "MX", "PEN": "PE", "CLP": "CL", "ARS": "AR", "TRY": "TR", "ZAR": "ZA",
         "SGD": "SG", "INR": "IN", "HKD": "HK", "CNY": "CN", "CNH": "CN", "NOK": "NO", "SEK": "SE", "DKK": "DK",
         "PLN": "PL", "HUF": "HU", "CZK": "CZ", "RUB": "RU", "THB": "TH", "IDR": "ID", "KRW": "KR", "ILS": "IL",
         "AED": "AE", "SAR": "SA", "EGP": "EG", "NGN": "NG", "KES": "KE", "PHP": "PH", "MYR": "MY", "VND": "VN"}
_ERRORES_NOTI = set()


def _res(ctx, nombre, tipo):
    return ctx.getResources().getIdentifier(nombre, tipo, ctx.getPackageName())


def _color(hexa):
    from java import jclass, jint
    return jint(jclass("android.graphics.Color").parseColor(hexa))     # jint: elige setColor(int), no (long)


def _argb(a, r, g, b):
    from java import jint
    return jint(((a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255)) - (1 << 32 if a >= 128 else 0))


def _ctx():
    """Contexto para notificar: la app aunque la pantalla esté apagada o la ventana cerrada."""
    s = _SERVICIO.get("ctx")
    if s is not None:
        return s
    return _actividad().getApplicationContext()


def _icono_chico(ctx):
    """LS con la línea (silueta del APK); Android lo pinta dentro del círculo amarillo."""
    return _res(ctx, "ic_noti", "drawable") or ctx.getApplicationInfo().icon


def _bandera(cod):
    p = _PAIS.get(cod)
    return "".join(chr(0x1F1E6 + ord(c) - 65) for c in p) if p else None


def _par_bonito(par):
    """'EURUSD-OTC' -> ('EUR/USD OTC', '🇪🇺🇺🇸')."""
    base, _, resto = (par or "").partition("-")
    base = base.upper()
    a, b = base[:3], base[3:6]
    nombre = f"{a}/{b}" if len(base) == 6 else base
    if resto:
        nombre += " " + resto.upper().replace("OP", "").strip()
    fa, fb = _bandera(a), _bandera(b)
    return nombre.strip(), (fa + fb if fa and fb else None), a


def _ajustar(p, texto, ancho):
    if p.measureText(texto) <= ancho:
        return texto
    while texto and p.measureText(texto + "…") > ancho:
        texto = texto[:-1]
    return texto + "…"


def _dibujar_tarjeta(ctx, tema, izq, titulo, sub="", etiqueta="", monto="", chip="", punto=None, compacta=False,
                     pildoras=None):
    """Dibuja la tarjeta 'premium en degradado' como imagen (así no hace falta cambiar el APK).
    izq: ('logo',) · ('banderas', '🇬🇧🇯🇵', 'GBP') · ('check',)"""
    from java import jclass
    Bitmap = jclass("android.graphics.Bitmap")
    Config = jclass("android.graphics.Bitmap$Config")
    Canvas = jclass("android.graphics.Canvas")
    Paint = jclass("android.graphics.Paint")
    PaintStyle = jclass("android.graphics.Paint$Style")
    Align = jclass("android.graphics.Paint$Align")
    RectF = jclass("android.graphics.RectF")
    Path = jclass("android.graphics.Path")
    Direction = jclass("android.graphics.Path$Direction")
    LinearGradient = jclass("android.graphics.LinearGradient")
    TileMode = jclass("android.graphics.Shader$TileMode")
    Typeface = jclass("android.graphics.Typeface")
    Color = jclass("android.graphics.Color")
    BitmapFactory = jclass("android.graphics.BitmapFactory")
    m = ctx.getResources().getDisplayMetrics()
    d = min(m.density, 2.0)                 # imagen liviana (Android limita el tamaño de una notificación)
    dp = lambda v: v * d
    W = int(max(dp(260), (m.widthPixels / m.density - 84) * d))
    H = int(dp(52 if compacta else 88))
    a, b, acento = _ESTILO.get(tema, _ESTILO["fija"])
    bmp = Bitmap.createBitmap(W, H, Config.ARGB_8888)
    c = Canvas(bmp)
    rect = RectF(0.0, 0.0, float(W), float(H))
    rad = dp(14)
    forma = Path()
    forma.addRoundRect(rect, rad, rad, Direction.CW)
    c.save()
    c.clipPath(forma)
    p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.setShader(LinearGradient(0.0, 0.0, float(W), float(H), _color(a), _color(b), TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(LinearGradient(0.0, 0.0, 0.0, H * 0.5, _argb(26, 255, 255, 255), _argb(0, 255, 255, 255),
                               TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(None)
    # línea de gráfico de fondo
    linea = Path()
    pts = [(0, .83), (.15, .70), (.27, .77), (.40, .50), (.52, .57), (.65, .30), (.80, .37), (1, .10)]
    x0, ancho_l = W * 0.38, W * 0.62
    for i, (px, py) in enumerate(pts):
        x, y = x0 + px * ancho_l, H * 0.3 + py * H * 0.7
        (linea.moveTo if i == 0 else linea.lineTo)(float(x), float(y))
    p.setStyle(PaintStyle.STROKE)
    p.setStrokeWidth(dp(2.2))
    p.setColor(_color(acento))
    p.setAlpha(70)
    c.drawPath(linea, p)
    p.setStyle(PaintStyle.FILL)
    p.setAlpha(255)
    # izquierda: logo, banderas o ✓
    pad = dp(12)
    s = dp(34 if compacta else 46)
    cy = H / 2.0
    caja = RectF(pad, cy - s / 2, pad + s, cy + s / 2)
    if izq[0] == "logo":
        logo = BitmapFactory.decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))
        if logo is None:
            logo = BitmapFactory.decodeResource(ctx.getResources(), ctx.getApplicationInfo().icon)
        if logo is not None:
            c.drawBitmap(logo, None, caja, Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG))
    elif izq[0] == "banderas":
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if izq[1]:
            tp.setTextSize(s * 0.38)
            tp.setTextAlign(Align.CENTER)
            tp.setShadowLayer(dp(3), 0.0, dp(1.5), _argb(110, 0, 0, 0))
            c.drawText(izq[1], pad + s / 2, cy + s * 0.16, tp)
        else:                                            # cripto, acciones…: círculo con sus letras
            tp.setColor(_argb(46, 255, 255, 255))
            c.drawCircle(pad + s / 2, cy, s * 0.42, tp)
            tp.setColor(_argb(255, 255, 255, 255))
            tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
            tp.setTextSize(s * 0.26)
            tp.setTextAlign(Align.CENTER)
            c.drawText((izq[2] or "?")[:4], pad + s / 2, cy + s * 0.09, tp)
    else:
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.setColor(_argb(40, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.STROKE)
        tp.setStrokeWidth(dp(2))
        tp.setColor(_argb(115, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.FILL)
        tp.setColor(_argb(255, 255, 255, 255))
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
        tp.setTextSize(s * 0.48)
        tp.setTextAlign(Align.CENTER)
        c.drawText("✓", pad + s / 2, cy + s * 0.17, tp)
    # derecha: etiqueta + monto (+ cuenta y temporalidad debajo)
    negrita = Typeface.create("sans-serif", Typeface.BOLD)
    pm = Paint(Paint.ANTI_ALIAS_FLAG)
    pm.setTypeface(negrita)
    pm.setColor(_argb(255, 255, 255, 255))
    pm.setTextAlign(Align.RIGHT)
    pm.setTextSize(dp(18 if compacta else 21))
    pm.setShadowLayer(dp(4), 0.0, dp(1.5), _argb(60, 0, 0, 0))
    pe = Paint(Paint.ANTI_ALIAS_FLAG)
    pe.setTypeface(negrita)
    pe.setColor(_color(acento))
    pe.setTextAlign(Align.RIGHT)
    pe.setTextSize(dp(8.5))
    pc = Paint(Paint.ANTI_ALIAS_FLAG)
    pc.setTypeface(negrita)
    pc.setTextSize(dp(9))
    try:
        pe.setLetterSpacing(0.12)
        pc.setLetterSpacing(0.05)
    except Exception:
        pass
    derecha = W - pad
    ancho_der = ancho_etq = ancho_chip = 0
    chip_txt = chip if not compacta else ""
    if monto:
        ancho_der = pm.measureText(monto)
        if compacta:
            c.drawText(monto, derecha, cy + dp(6), pm)
        else:
            y_m = cy + (dp(5) if chip_txt else dp(13))
            c.drawText(monto, derecha, y_m, pm)
            if etiqueta:
                c.drawText(etiqueta, derecha, y_m - dp(23), pe)
                ancho_etq = pe.measureText(etiqueta)
            if chip_txt:
                cw = pc.measureText(chip_txt) + dp(12)
                fondo = Paint(Paint.ANTI_ALIAS_FLAG)
                fondo.setColor(_argb(40, 255, 255, 255))
                c.drawRoundRect(RectF(derecha - cw, y_m + dp(7), derecha, y_m + dp(23)), dp(5), dp(5), fondo)
                pc.setColor(_argb(225, 255, 255, 255))
                pc.setTextAlign(Align.CENTER)
                c.drawText(chip_txt, derecha - cw / 2, y_m + dp(18.5), pc)
                ancho_chip = cw
    # centro: punto + título / par / píldoras de dirección y nivel
    x = pad + s + dp(10 if not compacta else 11)
    limite = derecha - ancho_der - dp(10) - x                     # fila del par: al lado del monto
    limite_t = derecha - max(ancho_etq, 0 if (sub or pildoras) else ancho_der) - dp(10) - x   # título: arriba
    limite_p = derecha - (ancho_chip or ancho_der) - dp(8) - x    # píldoras: al lado de la cuenta
    pt = Paint(Paint.ANTI_ALIAS_FLAG)
    pt.setTypeface(negrita)
    pt.setColor(_argb(255, 255, 255, 255))
    pt.setTextSize(dp(15 if compacta else 15.5))
    ps = Paint(Paint.ANTI_ALIAS_FLAG)
    ps.setColor(_argb(205, 255, 255, 255))
    ps.setTextSize(dp(12.5))
    filas = 1 + (1 if (sub and not compacta) else 0) + (1 if (pildoras and not compacta) else 0)
    if compacta or filas == 1:
        y_t = cy + dp(5)
    elif filas == 2:
        y_t = cy - dp(4)
    else:
        y_t = cy - dp(12)
    xt = x
    if punto:
        pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.setColor(_color(punto))
        pp.setShadowLayer(dp(4), 0.0, 0.0, _color(punto))
        r = dp(4.5)
        c.drawCircle(xt + r, y_t - pt.getTextSize() * 0.36, r, pp)
        xt += r * 2 + dp(7)
    c.drawText(_ajustar(pt, titulo, max(dp(40), (limite if compacta else limite_t) - (xt - x))), xt, y_t, pt)
    y = y_t
    if sub and not compacta:
        y += dp(18)
        c.drawText(_ajustar(ps, sub, limite), x, y, ps)
    if pildoras and not compacta:
        y += dp(8)
        px = x
        oscuro = tema != "fija"                     # sobre verde o rojo, píldora con fondo oscuro para que resalte
        for texto, col in pildoras:
            pc.setTextAlign(Align.LEFT)
            w = pc.measureText(texto) + dp(12)
            if px + w > x + limite_p:
                break
            caja_p = RectF(px, y, px + w, y + dp(16))
            f = Paint(Paint.ANTI_ALIAS_FLAG)
            if oscuro:
                f.setColor(_argb(110, 0, 0, 0))
            else:
                f.setColor(_color(col))
                f.setAlpha(40)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            f.setStyle(PaintStyle.STROKE)
            f.setStrokeWidth(dp(1))
            f.setColor(_color(col))
            f.setAlpha(120)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            pc.setColor(_color(col))
            c.drawText(texto, px + dp(6), y + dp(11.8), pc)
            px += w + dp(5)
    c.restore()
    return bmp


def _vista_imagen(ctx, bmp, boton=None):
    """Mete la tarjeta dibujada en el diseño que ya trae el APK (Android 12+). Devuelve la vista o None."""
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 31 or not _res(ctx, "noti_tarjeta", "layout"):
        return None
    RemoteViews = jclass("android.widget.RemoteViews")
    TypedValue = jclass("android.util.TypedValue")
    v = RemoteViews(ctx.getPackageName(), _res(ctx, "noti_tarjeta", "layout"))
    for nombre in ("barra", "banderas", "titulo", "detalle", "insignia", "monto"):
        v.setViewVisibility(_res(ctx, nombre, "id"), 8)                  # GONE
    img = _res(ctx, "logo", "id")
    v.setImageViewBitmap(img, bmp)
    v.setViewLayoutWidth(img, -1.0, TypedValue.COMPLEX_UNIT_PX)          # todo el ancho
    v.setViewLayoutHeight(img, 88.0, TypedValue.COMPLEX_UNIT_DIP)
    v.setViewLayoutMargin(img, RemoteViews.MARGIN_START, 0.0, TypedValue.COMPLEX_UNIT_PX)
    v.setViewOutlinePreferredRadius(img, 14.0, TypedValue.COMPLEX_UNIT_DIP)
    if boton:
        texto, color_txt, fondo, pi = boton
        bid = _res(ctx, "boton", "id")
        v.setTextViewText(bid, texto)
        v.setTextColor(bid, _color(color_txt))
        if fondo.startswith("#"):                  # color directo, con esquinas redondeadas
            v.setInt(bid, "setBackgroundColor", _color(fondo))
            v.setViewOutlinePreferredRadius(bid, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        else:
            f = _res(ctx, fondo, "drawable")
            if f:
                v.setInt(bid, "setBackgroundResource", f)
        v.setViewLayoutMargin(bid, RemoteViews.MARGIN_TOP, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        v.setViewVisibility(bid, 0)
        v.setOnClickPendingIntent(bid, pi)
    return v


def jclass_bitmap_logo(ctx):
    from java import jclass
    return jclass("android.graphics.BitmapFactory").decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))


def _pi_abrir(ctx):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    abrir = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName())
    return PendingIntent.getActivity(ctx, 0, abrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _pi_servicio(ctx, accion, n):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    i = jclass("android.content.Intent")(accion)
    i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
    return PendingIntent.getService(ctx, n, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _canal(ctx, cid, nombre, importancia, publico=True, alerta=False):
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 26:
        return
    NotificationChannel = jclass("android.app.NotificationChannel")
    Notification = jclass("android.app.Notification")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    c = NotificationChannel(cid, nombre, importancia)
    if publico:
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC)
    if alerta:
        c.enableVibration(True)
        from java import jarray, jlong
        c.setVibrationPattern(jarray(jlong)([0, 250, 120, 250]))
        c.enableLights(True)
    nm.createNotificationChannel(c)


def _builder(ctx, cid):
    from java import jclass
    B = jclass("android.app.Notification$Builder")
    return B(ctx, cid) if jclass("android.os.Build$VERSION").SDK_INT >= 26 else B(ctx)


def _pildoras(direccion, intento):
    """▲ CALL verde / ▼ PUT rojo + ENTRADA (gris) o NIVEL/GALE (ámbar)."""
    d = ("▲ CALL", "#34D27F") if direccion == "call" else ("▼ PUT", "#FF5A5A")
    t = (intento or "Entrada").upper()
    return [d, (t, "#AEB6C4" if t.startswith("ENTRADA") else "#FFB547")]


def _datos_tarjeta(tipo, titulo, texto, par=None, dir=None, op=None, monto=None, **_):
    """Qué va en cada tarjeta: (izq, título, subtítulo, etiqueta, monto, botón, píldoras)."""
    dinero = (lambda v: f"{'+' if v >= 0 else '−'}${abs(v):.2f}") if monto is not None else (lambda v: "")
    if tipo == "ganada":
        nombre, flags, cod = _par_bonito(par)
        return ("banderas", flags, cod), nombre, "", "GANADA", dinero(monto), None, _pildoras(dir, op)
    if tipo == "stopwin":
        return ("logo",), "Stop Win", "Meta cumplida", "HOY", dinero(monto), None, None
    if tipo == "stoploss":
        return ("logo",), "Stop Loss", "Saldo protegido", "HOY", dinero(monto), None, None
    if tipo == "mercado_malo":
        return ("logo",), "Mercado errático", "El bot está en pausa", "", "", \
            ("Operar de todos modos", "#FFC266", "#3A2410", "iqbot.OPERAR_IGUAL", 7), None
    if tipo == "mercado_aviso":
        return ("logo",), "Mercado errático", texto, "", "", None, None
    if tipo == "mercado_ok":
        return ("check",), "Mercado óptimo", "¿Sigues operando?", "", "", \
            ("Seguir operando", "#BFF5D6", "boton_verde", "iqbot.SEGUIR", 8), None
    return ("logo",), titulo, texto, "", "", None, None


def _notificar_android(titulo, texto, tipo="ganada", **datos):
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado", NotificationManager.IMPORTANCE_HIGH,
           alerta=True)
    izq, t1, t2, etq, mto, boton, pild = _datos_tarjeta(tipo, titulo, texto, **datos)
    a, b, acento = _ESTILO.get(tipo, _ESTILO["ganada"])
    linea = f"{t1} · {mto}" if mto else t1
    if pild and not t2:
        t2 = " · ".join(p[0] for p in pild)
    b_ = _builder(ctx, "iqbot_alertas")
    b_.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(linea).setContentText(t2) \
      .setAutoCancel(True).setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
      .setShowWhen(True).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    pi_boton = None
    if boton:
        pi_boton = _pi_servicio(ctx, boton[3], boton[4])
    hecho = False
    try:
        grande = _dibujar_tarjeta(ctx, tipo, izq, t1, "" if pild else t2, etq, mto, pildoras=pild)
        vista = _vista_imagen(ctx, grande, (boton[0], boton[1], boton[2], pi_boton) if boton else None)
        if vista:
            b_.setCustomBigContentView(vista)            # cerrada: título y texto normales; abierta: la tarjeta
            b_.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
            hecho = True
        else:
            b_.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("tarjeta", e)
    if boton and not hecho:
        b_.addAction(_icono_chico(ctx), boton[0], pi_boton)
    _NOTIF_N[0] += 1
    nm.notify(77 if tipo.startswith("mercado") else _NOTIF_N[0], b_.build())


def _aviso_error(donde, e):
    clave = f"{donde}:{type(e).__name__}"
    if clave in _ERRORES_NOTI:
        return
    _ERRORES_NOTI.add(clave)
    try:
        bot = _bot_activo()
        if bot:
            bot.log(f"⚠ Notificación ({donde}): {type(e).__name__}: {e}", "yellow")
    except Exception:
        pass


def _app_visible():
    """True si la app está en pantalla (para esconder la tarjeta fija mientras la usas)."""
    try:
        from java import jclass
        RAP = jclass("android.app.ActivityManager$RunningAppProcessInfo")
        info = RAP()
        jclass("android.app.ActivityManager").getMyMemoryState(info)
        return info.importance <= RAP.IMPORTANCE_FOREGROUND
    except Exception:
        return False


def _estado_fija(bot, texto):
    """(punto, título, chip, subtítulo, monto, píldoras) de la tarjeta fija."""
    if not bot:
        return "#F5A524", "IQ Bot", "", texto, "", None
    cfg = bot.cfg
    chip = f"{'REAL' if cfg.get('cuenta') == 'REAL' else 'DEMO'} · M{(cfg.get('temporalidades') or [1])[0]}"
    g = bot.pnl
    monto = f"{'+' if g >= 0 else '−'}${abs(g):.2f}"
    if getattr(bot, "espera_decision", False):
        return "#5CF2A6", "En pausa", chip, "Mercado óptimo · ¿sigues operando?", monto, None
    if bot.pausa_mercado():
        return "#FFA53D", "En pausa", chip, "Mercado errático", monto, None
    ult = None
    try:
        abiertas = list(bot.abiertas.values())
        ult = abiertas[-1] if abiertas else getattr(bot, "ultima_entrada", None)
    except Exception:
        pass
    if ult and ult.get("par"):
        nombre, flags, _ = _par_bonito(ult["par"])
        sub = f"{flags + ' ' if flags else ''}{nombre}"
        return "#34D27F", "Operando", chip, sub, monto, _pildoras(ult.get("dir"), ult.get("intento"))
    return "#34D27F", "Operando", chip, "Buscando señales", monto, None


def _noti_trabajando(ctx, texto, bot=None):
    """Tarjeta fija del servicio. Con la app abierta va en modo mínimo (no se ve);
    al salir o bloquear aparece como la de la música."""
    from java import jclass
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    visible_app = _app_visible()
    _canal(ctx, "iqbot_fija", "Bot trabajando", NotificationManager.IMPORTANCE_DEFAULT)
    _canal(ctx, "iqbot_fija_min", "Bot trabajando (app abierta)", NotificationManager.IMPORTANCE_MIN, publico=False)
    cid = "iqbot_fija_min" if visible_app else "iqbot_fija"
    punto, titulo, chip, sub, monto, pild = _estado_fija(bot, texto)
    b = _builder(ctx, cid)
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")) \
     .setContentTitle(f"{titulo} · {chip}" if chip else titulo) \
     .setContentText(f"{sub} {' '.join(p[0] for p in pild) if pild else ''}  {monto}".strip()) \
     .setOngoing(True).setOnlyAlertOnce(True) \
     .setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
     .setCategory(Notification.CATEGORY_SERVICE)
    try:
        grande = _dibujar_tarjeta(ctx, "fija", ("logo",), titulo, sub, "GANANCIA" if monto else "", monto, chip, punto,
                                  pildoras=pild)
        vista = _vista_imagen(ctx, grande)
        if vista:
            b.setCustomBigContentView(vista)
            b.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
        else:
            b.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("fija", e)
    return b.build()


def _notificar_windows(titulo, texto):
    import base64, subprocess
    from xml.sax.saxutils import escape
    xml = ("<toast><visual><binding template='ToastGeneric'><text>" + escape(titulo) + "</text><text>"
           + escape(texto) + "</text></binding></visual></toast>")
    xml = xml.replace("'", "''")                  # comillas para PowerShell
    ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
          "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null;"
          "$x = New-Object Windows.Data.Xml.Dom.XmlDocument; $x.LoadXml('" + xml + "');"
          "$n = [Windows.UI.Notifications.ToastNotification]::new($x);"
          "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
          "'{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe').Show($n)")
    cod = base64.b64encode(ps.encode("utf-16-le")).decode()
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-EncodedCommand", cod],
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=20,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _bot_activo():
    try:
        return _API[0]._bot if _API else None
    except Exception:
        return None


def _notificar_simple(titulo, texto):
    """Último recurso: notificación normal de Android, sin diseño."""
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado",
           jclass("android.app.NotificationManager").IMPORTANCE_HIGH, alerta=True)
    b = _builder(ctx, "iqbot_alertas")
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(titulo).setContentText(texto).setAutoCancel(True) \
     .setContentIntent(_pi_abrir(ctx)).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    _NOTIF_N[0] += 1
    ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).notify(_NOTIF_N[0], b.build())


def _ruta_perfil():
    return os.path.join(nucleo.DATOS, "perfil.json")


def _leer_perfil():
    """Datos del usuario que no se cambian (su nombre)."""
    try:
        with open(_ruta_perfil(), encoding="utf-8") as f:
            p = json.load(f)
        return p if isinstance(p, dict) else {}
    except Exception:
        return {}


def _quitar_aviso_mercado():
    """Borra la tarjeta de mercado (errático / óptimo) cuando el bot se detiene."""
    if not _es_android():
        return
    try:
        from java import jclass
        _ctx().getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).cancel(77)
    except Exception:
        pass


def notificar_sistema(titulo, texto, **datos):
    if str(datos.get("tipo", "")).startswith("mercado"):
        b = getattr(nucleo, "BOT_ACTUAL", None)
        if b is None or b.detener or b.terminado:
            return                                       # sin bot trabajando no hay avisos de mercado
    if _es_android():
        try:
            _notificar_android(titulo, texto, **datos)
        except Exception as e:
            _aviso_error("aviso", e)
            try:
                _notificar_simple(titulo, texto)
            except Exception as e2:
                _aviso_error("aviso simple", e2)
        return
    try:
        if False:
            pass
        elif sys.platform.startswith("win"):
            if datos.get("tipo") == "ganada":
                titulo = "✅ " + titulo
                texto = f"{datos.get('op', 'Entrada')} · +${datos.get('monto', 0):.2f} · Sesión {datos.get('sesion', 0):+.2f}"
            elif datos.get("tipo") in ("stopwin", "stoploss"):
                texto = f"{datos.get('monto', 0):+.2f} · " + texto
            _notificar_windows(titulo, texto)
    except Exception:
        pass


nucleo.NOTIFICAR = notificar_sistema


def _permisos_android():
    """Pide permiso de notificaciones (Android 13+) y que no se limite la batería."""
    from java import jclass, jarray
    ctx = _actividad()
    Build = jclass("android.os.Build$VERSION")
    if Build.SDK_INT >= 33 and ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0:
        permisos = jarray(jclass("java.lang.String"))(["android.permission.POST_NOTIFICATIONS"])
        _en_ui(lambda: ctx.requestPermissions(permisos, 77))
    Context = jclass("android.content.Context")
    pm = ctx.getSystemService(Context.POWER_SERVICE)
    if Build.SDK_INT >= 23 and not pm.isIgnoringBatteryOptimizations(ctx.getPackageName()):
        Intent = jclass("android.content.Intent")
        Uri = jclass("android.net.Uri")
        i = Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + ctx.getPackageName()))
        _en_ui(lambda: ctx.startActivity(i))


_SERVICIO = {"texto": "Toca para abrir", "activo": False, "error": "", "cerrojos": []}


def servicio_iniciar(servicio, intent):
    """Lo llama el servicio de Android al arrancar (o al tocar un botón de sus notificaciones):
    notificación fija + CPU y wifi despiertos."""
    from java import jclass
    Build = jclass("android.os.Build$VERSION")
    try:
        accion = intent.getAction() if intent is not None else None
        if accion in ("iqbot.OPERAR_IGUAL", "iqbot.SEGUIR"):
            if _API:
                if accion == "iqbot.OPERAR_IGUAL":
                    _API[0].operar_igual()
                else:
                    _API[0].seguir_operando()
            nm = servicio.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
            nm.cancel(77)                                # quita el aviso de mercado
    except Exception:
        pass
    _SERVICIO["ctx"] = servicio.getApplicationContext()
    notif = _noti_trabajando(servicio, _SERVICIO["texto"], _bot_activo())
    if Build.SDK_INT >= 34:
        ServiceInfo = jclass("android.content.pm.ServiceInfo")
        servicio.startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    else:
        servicio.startForeground(1, notif)
    if not _SERVICIO["cerrojos"]:
        Context = jclass("android.content.Context")
        PowerManager = jclass("android.os.PowerManager")
        cpu = servicio.getSystemService(Context.POWER_SERVICE).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "iqbot:operando")
        cpu.acquire()
        _SERVICIO["cerrojos"].append(cpu)
        try:
            WifiManager = jclass("android.net.wifi.WifiManager")
            wifi = servicio.getApplicationContext().getSystemService(Context.WIFI_SERVICE) \
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "iqbot:wifi")
            wifi.acquire()
            _SERVICIO["cerrojos"].append(wifi)
        except Exception:
            pass
    _SERVICIO["activo"] = True


def servicio_detener(servicio=None):
    for c in _SERVICIO["cerrojos"]:
        try:
            if c.isHeld():
                c.release()
        except Exception:
            pass
    _SERVICIO["cerrojos"] = []
    _SERVICIO["activo"] = False
    _quitar_aviso_mercado()
    _SERVICIO["ctx"] = None


def _actualizar_noti(texto):
    """Cambia el texto de la notificación fija (ganancias de la sesión)."""
    _SERVICIO["texto"] = texto
    if not _SERVICIO["activo"]:
        return
    try:
        from java import jclass
        ctx = _ctx()
        nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
        nm.notify(1, _noti_trabajando(ctx, texto, _bot_activo()))
    except Exception:
        pass


def segundo_plano(encender, texto="Toca para abrir"):
    """Celular: enciende o apaga el servicio que mantiene vivo el bot con la app cerrada o bloqueada.
    Devuelve (ok, motivo)."""
    if not _es_android():
        return True, ""
    try:
        from java import jclass
        ctx = _actividad()
        Intent = jclass("android.content.Intent")
        i = Intent()
        i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
        if encender:
            _SERVICIO["texto"] = texto
            try:
                _permisos_android()
            except Exception:
                pass
            if jclass("android.os.Build$VERSION").SDK_INT >= 26:
                r = ctx.startForegroundService(i)
            else:
                r = ctx.startService(i)
            if r is None:
                return False, "este APK no trae el servicio de segundo plano"
            _SERVICIO["activo"] = True
            threading.Thread(target=lambda: (time.sleep(2), _actualizar_noti(texto)), daemon=True).start()
        else:
            ctx.stopService(i)
            servicio_detener()
        return True, ""
    except Exception as e:
        _SERVICIO["error"] = str(e)[:150]
        return False, _SERVICIO["error"]


def _vigilar_fin(bot):
    """Mientras el bot trabaja actualiza la tarjeta fija (y la esconde con la app abierta);
    al terminar apaga el servicio."""
    ultimo = None
    while not bot.terminado:
        try:
            clave = (_app_visible(), round(bot.pnl, 2), bot.stats["ganadas"], bot.pausa_mercado(), getattr(bot, "espera_decision", False),
                     getattr(bot, "ultima_ganada", ""), str((getattr(bot, "ultima_entrada", None) or {}).get("par")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("dir")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("intento")), len(bot.abiertas))
            if clave != ultimo:
                _actualizar_noti("")
                ultimo = clave
        except Exception:
            pass
        time.sleep(2)
    segundo_plano(False)


def anotar_error():
    try:
        with open(nucleo.ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}]\n{traceback.format_exc()}")
    except Exception:
        pass


ETIQUETAS = {
    "MHI_1": "MHI 1", "MHI_2": "MHI 2", "MHI_3": "MHI 3", "MHI_Mayoria_1": "Mayoría 1", "MHI_Mayoria_2": "Mayoría 2",
    "MHI_Mayoria_3": "Mayoría 3", "Torres_Gemelas": "Torres Gemelas", "Tres_Mosqueteros": "Tres Mosqueteros",
    "Tres_Vecinos": "Tres Vecinos", "Padron_23": "Padrón 23", "Mejor_de_3": "Mejor de 3", "Patron_3x1": "Patrón 3x1",
    "Minoria_3_velas": "Minoría 3 velas", "Mayoria_3_velas": "Mayoría 3 velas", "RSI_extremo": "RSI extremo",
    "Bollinger_rechazo": "Bollinger", "Cruce_EMA_9_21": "Cruce EMA 9/21", "Envolvente": "Envolvente", "Pinbar": "Pinbar",
    "Tres_soldados": "Tres soldados", "Estocastico": "Estocástico", "Pullback_EMA": "Pullback EMA",
    "Williams_R": "Williams %R", "CCI_extremo": "CCI extremo", "Cruce_MACD": "Cruce MACD",
    "Agotamiento": "Agotamiento", "Vela_de_fuerza": "Vela de fuerza", "Rechazo_SR": "Rechazo en S/R",
    "Retesteo_ruptura": "Retesteo de ruptura", "Numero_redondo": "Número redondo",
    "Milhao_Maioria": "Milhão Maioria", "Milhao_Minoria": "Milhão Minoria", "Reversao": "Reversão",
    "Heikin_Ashi": "Heikin-Ashi",
    "Tres_dentro": "Tres velas dentro", "Estrella": "Estrella mañana/tarde", "Harami": "Harami", "Pinzas": "Pinzas",
    "Doji_Bollinger": "Doji en Bollinger", "Parabolic_SAR": "Parabolic SAR", "ADX_DI": "ADX + DI",
    "Donchian": "Ruptura Donchian", "Keltner": "Rechazo Keltner", "Cruce_EMA_5_13": "Cruce EMA 5/13",
    "RSI_2": "RSI 2 (Connors)", "Ichimoku": "Ichimoku", "Barra_interna": "Barra interna", "Fractal": "Ruptura fractal",
    "Awesome": "Awesome Oscillator", "Momentum": "Momentum",
}


class Api:
    """Métodos que la ventana puede llamar (window.pywebview.api.*)."""

    def __init__(self):
        _API[:] = [self]
        self._cfg = nucleo.cargar_config()
        self._broker = None
        self._bot = None
        self._nombre = "DEMO"
        self._login = {"fase": "inactivo", "mensaje": ""}
        self._evento_codigo = threading.Event()
        self._codigo = ""
        self._monitor = None   # lee el mercado desde que se inicia sesión (antes de arrancar el bot)
        viejo = getattr(nucleo, "BOT_ACTUAL", None)      # se cerró la ventana con el bot trabajando: se retoma
        if viejo is not None and not viejo.terminado and not viejo.detener:
            self._bot, self._broker, self._nombre = viejo, viejo.b, viejo.cuenta
        ajustar_teclado_android()
        self._prep = {"listo": False, "mensaje": "Revisando la librería de IQ Option…"}
        threading.Thread(target=self._preparar, daemon=True).start()

    # ---------- arranque ----------
    def _preparar(self):
        try:
            if not nucleo.CONGELADO:
                nucleo.asegurar_librerias()
                if self._cfg.get("actualizar_libreria", True):
                    nucleo.actualizar_libreria()
            elif self._cfg.get("actualizar_libreria", True):
                # .exe / Android: busca versión nueva de la librería en GitHub y la usa si es válida
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones de la librería de IQ Option…"}
                cambio, msg = nucleo.actualizar_libreria_embebida()
                if cambio:
                    self._prep = {"listo": True, "mensaje": msg}
            # actualizaciones del bot publicadas por el autor (firmadas)
            arr = _arranque()
            if arr is not None and getattr(arr, "URL_ACTUALIZACIONES", ""):
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones del bot…"}
                nueva = arr.buscar_actualizacion(lambda t: self._prep.update(mensaje=t))
                if nueva:
                    self._prep = {"listo": False, "mensaje": f"Actualización {nueva} instalada. Reiniciando…"}
                    time.sleep(1.5)
                    reiniciar_programa()
                    return
            if self._prep.get("mensaje", "").startswith("Librería de IQ Option actualizada"):
                self._prep = {"listo": True, "mensaje": self._prep["mensaje"]}
            else:
                self._prep = {"listo": True, "mensaje": "Listo para conectar" + self._estado_actualizaciones(arr)}
        except BaseException as e:
            anotar_error()
            self._prep = {"listo": True, "mensaje": f"Aviso al preparar: {str(e)[:80]}"}

    def _estado_actualizaciones(self, arr):
        """Texto corto para la pantalla de inicio: versión y si la revisión de actualizaciones falló."""
        if arr is None or not getattr(arr, "URL_ACTUALIZACIONES", ""):
            return ""                                  # la versión ya se ve abajo a la izquierda
        try:
            with open(os.path.join(arr.DATOS, "actualizaciones.log"), encoding="utf-8") as f:
                ultima = f.read().strip().splitlines()[-1]
            hora = time.mktime(time.strptime(ultima[1:20], "%Y-%m-%d %H:%M:%S"))
            if time.time() - hora < 120 and ("No se pudo" in ultima or "inválida" in ultima or "no coincide" in ultima):
                return " · no se pudo revisar actualizaciones"
        except Exception:
            pass
        return ""

    def preparacion(self):
        return self._prep

    def guardar_nombre(self, nombre):
        """El nombre del usuario se guarda UNA sola vez; después no se puede cambiar."""
        p = _leer_perfil()
        if p.get("nombre"):
            return {"ok": False, "nombre": p["nombre"], "mensaje": "El nombre ya está guardado."}
        limpio = " ".join(str(nombre or "").split())[:24]
        if sum(ch.isalpha() for ch in limpio) < 2:
            return {"ok": False, "mensaje": "Escribe tu nombre (al menos 2 letras)."}
        p["nombre"] = limpio
        try:
            with open(_ruta_perfil(), "w", encoding="utf-8") as f:
                json.dump(p, f, ensure_ascii=False)
        except Exception as e:
            return {"ok": False, "mensaje": f"No se pudo guardar: {e}"}
        return {"ok": True, "nombre": limpio}

    def inicio(self):
        arr = _arranque()
        if arr is not None:
            try:
                arr.confirmar()        # la ventana abrió bien con esta versión
            except Exception:
                pass
        return {"email": self._cfg.get("email", ""), "cuenta": self._cfg.get("cuenta", "PRACTICE"),
                "version": nucleo.VERSION_BOT, "nombre": _leer_perfil().get("nombre", ""),
                "bot_activo": bool(self._bot and not self._bot.terminado and not self._bot.detener)}

    def crear_cuenta(self):
        """Abre el registro de IQ Option con el enlace de afiliado del autor (en el navegador del equipo)."""
        try:
            if ABRIR_ENLACE:
                ABRIR_ENLACE(ENLACE_REGISTRO)
            else:
                import webbrowser
                webbrowser.open(ENLACE_REGISTRO, new=2)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mensaje": str(e)}

    # ---------- inicio de sesión ----------
    def iniciar_sesion(self, email, clave, cuenta):
        if self._login["fase"] in ("conectando", "codigo", "licencia"):
            return {"ok": False, "mensaje": "Ya se está conectando…"}
        if "@" not in (email or ""):
            return {"ok": False, "mensaje": "Escribe un correo válido."}
        if not clave:
            return {"ok": False, "mensaje": "Escribe tu contraseña."}
        if not self._prep["listo"]:
            return {"ok": False, "mensaje": "Espera un momento: se está preparando la librería de IQ Option."}
        self._login = {"fase": "conectando", "mensaje": ""}
        threading.Thread(target=self._hacer_login, args=(email.strip(), clave, cuenta), daemon=True).start()
        return {"ok": True}

    def _pedir_codigo(self):
        self._evento_codigo.clear()
        self._login = {"fase": "codigo", "mensaje": ""}
        self._evento_codigo.wait(300)
        self._login = {"fase": "conectando", "mensaje": ""}
        return self._codigo

    def enviar_codigo(self, codigo):
        self._codigo = (codigo or "").strip()
        self._evento_codigo.set()
        return {"ok": True}

    def _hacer_login(self, email, clave, cuenta):
        try:
            broker, error = nucleo.BrokerIQ.iniciar_sesion(email, clave, self._pedir_codigo)
            clave = None
            if not broker:
                self._login = {"fase": "error", "mensaje": error}
                return
            self._login = {"fase": "licencia", "mensaje": ""}
            id_iq = broker.id_iq()
            ok, msg = nucleo.verificar_licencia(email, id_iq)
            if not ok:
                self._login = {"fase": "sin_licencia", "mensaje": msg, "id_iq": id_iq}
                return
            cuenta = "REAL" if cuenta == "REAL" else "PRACTICE"
            broker.usar_cuenta(cuenta)
            self._broker = broker
            self._nombre = "REAL" if cuenta == "REAL" else "DEMO"
            self._cfg["email"] = email
            self._cfg["cuenta"] = cuenta
            nucleo.guardar_config(self._cfg)
            self._login = {"fase": "listo", "mensaje": "", "licencia": msg}
            self._vigilar_mercado()
        except Exception as e:
            anotar_error()
            self._login = {"fase": "error", "mensaje": f"Error inesperado al conectar: {e}"}

    # ---------- lectura del mercado ----------
    def _vigilar_mercado(self):
        if self._monitor:
            self._monitor.parar = True
        self._monitor = nucleo.MonitorMercado(self._broker, self._cfg) if self._broker else None

    def _dejar_de_vigilar(self):
        if self._monitor:
            self._monitor.parar = True
            self._monitor = None

    def mercado(self):
        return nucleo.MERCADO.resumen()

    def operar_igual(self):
        """El cliente decide operar aunque el mercado esté malo."""
        nucleo.MERCADO.operar_igual = True
        if self._bot:
            self._bot.log("▶ Operando aunque el mercado está malo, por decisión del usuario.", "yellow")
        return {"ok": True}

    def seguir_operando(self):
        """El mercado mejoró y el cliente decide seguir operando."""
        if self._bot:
            self._bot.seguir_operando()
        return {"ok": True}

    def estado_login(self):
        return self._login

    def cerrar_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "Detén el bot primero."}
        try:
            if self._broker:
                self._broker.api.api.close()
        except Exception:
            pass
        self._dejar_de_vigilar()
        self._broker = None
        self._bot = None
        self._login = {"fase": "inactivo", "mensaje": ""}
        return {"ok": True}

    # ---------- configuración ----------
    def datos_config(self):
        estrategias = []
        for n, fn in nucleo.ESTRATEGIAS.items():
            estrategias.append({"nombre": n, "etiqueta": ETIQUETAS.get(n, n.replace("_", " ")),
                                "grupo": "cuadrante" if n in nucleo.ESTRATEGIAS_CUADRANTE else "indicadores",
                                "descripcion": (fn.__doc__ or "").strip()})
        c = dict(self._cfg)
        c["max_pares"] = nucleo.MAX_PARES
        saldo = self._broker.saldo() if self._broker else None
        return {"cfg": c, "estrategias": estrategias, "email": self._cfg.get("email", ""),
                "cuenta": self._cfg.get("cuenta", "PRACTICE"), "saldo": saldo if isinstance(saldo, (int, float)) else None}

    def _mezclar(self, parcial):
        c = dict(self._cfg)
        c.update({k: v for k, v in (parcial or {}).items() if k in nucleo.DEFAULT_CONFIG})
        return c

    def tabla_recuperacion(self, parcial):
        c = self._mezclar(parcial)
        if c.get("recuperacion") == "ninguna":
            return {"filas": [], "total": float(c.get("monto_entrada") or 0), "mult_insuficiente": False}
        try:
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            filas = nucleo.tabla_recuperacion(c, 0.85)
        except Exception:
            return {"filas": [], "total": 0, "mult_insuficiente": False}
        return {"filas": [{"paso": e, "monto": m, "perdido": p, "neto": round(n, 2)} for e, m, p, n in filas],
                "total": filas[-1][2] if filas else 0,
                "mult_insuficiente": c["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:])}

    def iniciar_bot(self, parcial):
        if not self._broker:
            return {"ok": False, "mensaje": "No hay sesión iniciada."}
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "El bot ya está funcionando."}
        c = self._mezclar(parcial)
        try:
            c["monto_entrada"] = float(c["monto_entrada"])
            c["max_operaciones_simultaneas"] = 1                       # una operación a la vez
            if c.get("recuperacion") not in ("ninguna", "martingala", "niveles", "auto"):
                c["recuperacion"] = "martingala"
            c["max_pares"] = nucleo.MAX_PARES                          # siempre todos los pares
            c["estrategias_auto"] = True; c["estrategias_activas"] = "todas"   # las 50, en automático
            c["payout_minimo"] = float(c["payout_minimo"])
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            c["stop_win"] = float(c["stop_win"]); c["stop_loss"] = float(c["stop_loss"])
            c["winrate_minimo"] = float(c["winrate_minimo"]); c["confluencia_minima"] = max(1, int(c["confluencia_minima"]))
            c["anticipo_ms"] = max(50, min(1500, int(c["anticipo_ms"])))
            c["min_senales_catalogo"] = max(5, min(60, int(c["min_senales_catalogo"])))
            c["winrate_minimo"] = max(0.50, min(0.95, c["winrate_minimo"]))
            c["solo_velas_fuertes"] = False                             # v1.17: fijos en el código
            c["ia_filtra"] = True
            c["ia_precision_alta"] = False
            c["estrategias_auto"] = bool(c.get("estrategias_auto", True))
            if c["estrategias_auto"]:
                c["estrategias_activas"] = "todas"
            for k in ("filtro_reciente", "ciclo_reciente", "pausa_tras_perdida"):
                c.pop(k, None)
            tfs = [int(t) for t in (c.get("temporalidades") or []) if int(t) in (1, 5, 15)]
            c["temporalidades"] = tfs[:1]                              # una sola temporalidad
            c["incluir_digital"] = bool(c.get("incluir_digital", False))
            c["ia_filtra"] = True; c["solo_velas_fuertes"] = False      # fijos en el código
        except Exception:
            return {"ok": False, "mensaje": "Revisa los números de la configuración."}
        if c["monto_entrada"] < 1:
            return {"ok": False, "mensaje": "La entrada mínima en IQ Option es $1."}
        if not c["temporalidades"]:
            return {"ok": False, "mensaje": "Elige la temporalidad."}
        if not (c["incluir_mercado_real"] or c["incluir_otc"] or c["incluir_digital"]):
            return {"ok": False, "mensaje": "Elige al menos un mercado: real, OTC o digital."}
        if c["estrategias_activas"] != "todas" and not c["estrategias_activas"]:
            return {"ok": False, "mensaje": "Elige al menos una estrategia."}
        if c["stop_win"] <= 0 or c["stop_loss"] <= 0:
            return {"ok": False, "mensaje": "Los stops deben ser mayores que cero."}
        if (c["estrategias_activas"] != "todas" and 1 not in c["temporalidades"]
                and all(n in nucleo.ESTRATEGIAS_CUADRANTE for n in c["estrategias_activas"])):
            return {"ok": False, "mensaje": "Las estrategias de cuadrante solo funcionan en M1: activa M1."}
        saldo = self._broker.saldo()
        if isinstance(saldo, (int, float)) and c["stop_loss"] > saldo:
            return {"ok": False, "mensaje": f"El stop loss (${c['stop_loss']:.2f}) es mayor que tu saldo (${saldo:.2f})."}
        self._cfg = c
        nucleo.guardar_config(c)
        try:
            self._bot = nucleo.Bot(self._broker, c, self._nombre)
            self._bot.iniciar_hilos()
            ok_sp, motivo_sp = segundo_plano(True, f"{'REAL' if c.get('cuenta') == 'REAL' else 'DEMO'} · operando")
            if _es_android():
                if ok_sp:
                    self._bot.log("📱 Segundo plano activo: puedes bloquear el celular o usar otras apps.", "green")
                else:
                    self._bot.log(f"⚠ No se pudo activar el segundo plano ({motivo_sp}). Deja la app abierta "
                                  f"y la pantalla encendida.", "bold yellow")
            threading.Thread(target=_vigilar_fin, args=(self._bot,), daemon=True).start()
            self._dejar_de_vigilar()          # con el bot andando, él mismo lee el mercado cada minuto
            if nucleo.MERCADO.pausa:
                self._bot.log("⚠ El mercado está malo: el bot arranca en pausa hasta que mejore.", "bold yellow")
        except Exception as e:
            anotar_error()
            return {"ok": False, "mensaje": f"No se pudo iniciar: {e}"}
        return {"ok": True}

    # ---------- operaciones ----------
    def estado(self):
        if not self._bot:
            return {}
        try:
            return self._bot.resumen_gui()
        except Exception:
            anotar_error()
            return {}

    def pausar(self):
        if self._bot:
            self._bot.pausado = not self._bot.pausado
            self._bot.log("⏸ Bot en pausa: sigue analizando pero no abre operaciones." if self._bot.pausado
                         else "▶ Bot reanudado.", "yellow")
        return {"pausado": bool(self._bot and self._bot.pausado)}

    def detener(self):
        _quitar_aviso_mercado()
        if self._bot and not self._bot.detener:
            self._bot.detener = True
            self._bot.log("Deteniendo por pedido del usuario: se esperan las operaciones abiertas.", "yellow")
        return {"ok": True}

    def nueva_sesion(self):
        if self._bot and not self._bot.terminado:
            return {"ok": False}
        self._bot = None
        self._vigilar_mercado()
        return {"ok": True}

    def bot_operando(self):
        """True solo si el bot está trabajando (no detenido). Así la X pregunta solo cuando hace falta."""
        return bool(self._bot and not self._bot.detener and not self._bot.terminado)

    def al_cerrar(self):
        self._dejar_de_vigilar()
        try:
            nucleo.inteligencia().guardar(forzar=True)
        except Exception:
            pass
        if self._bot:
            self._bot.detener = True


def main():
    nucleo.ordenar_archivos()
    import webview
    api = Api()
    with open(ruta_recurso("interfaz.html"), encoding="utf-8") as f:
        html = f.read()
    ventana = webview.create_window("IQ Bot Escáner", html=html, js_api=api, width=1240, height=800,
                                    min_size=(720, 540), background_color="#0B0F14", confirm_close=False)

    def al_intentar_cerrar():
        # pregunta solo si el bot está operando; si ya se detuvo (o no ha empezado) cierra directo
        ventana.confirm_close = api.bot_operando()

    ventana.events.closing += al_intentar_cerrar
    ventana.events.closed += lambda: api.al_cerrar()
    opciones = {"gui": "edgechromium"} if sys.platform == "win32" else {}
    webview.start(**opciones, localization={
        "global.quitConfirmation": "El bot está operando. ¿Cerrarlo? Las operaciones abiertas siguen en IQ Option hasta su vencimiento.",
        "global.ok": "Aceptar", "global.quit": "Cerrar", "global.cancel": "Cancelar"})


def arrancar():
    try:
        main()
    except Exception:
        anotar_error()
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, "No se pudo abrir la ventana de IQ Bot Escáner.\n\n"
                                             "Si la ventana no aparece, instala 'Microsoft Edge WebView2 Runtime' "
                                             "(gratis, de microsoft.com) y vuelve a abrir el programa.\n\n"
                                             "Detalle en errores.log, carpeta: " + nucleo.DATOS, "IQ Bot Escáner", 0x10)
        except Exception:
            raise


if __name__ == "__main__":
    arrancar()
