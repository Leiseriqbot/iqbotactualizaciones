# -*- coding: utf-8 -*-
"""
IQNOVA BOT - aplicación con ventana (IQ Option y Exnova).
La interfaz (interfaz.html) se muestra con el motor de Edge (WebView2) mediante pywebview,
y habla con el bot (iq_bot.py) a través de la clase Api.
"""
import json, os, sys, threading, time, traceback

if sys.stdout is None: sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None: sys.stderr = open(os.devnull, "w", encoding="utf-8")

import iq_bot as nucleo


REINICIAR = None      # Android pone aquí su forma de recargar la app tras una actualización
ABRIR_ENLACE = None   # Android pone aquí su forma de abrir el navegador del celular
ENLACE_REGISTRO = "https://iqoption.net/lp/mobile-partner-pwa/es/?aff=838529&aff_model=revenue"   # afiliado de Leiner Serpa
ENLACES_REGISTRO = {                                       # enlace de afiliado de Leiner Serpa en cada broker
    "iqoption": ENLACE_REGISTRO,
    "exnova": "https://trade.exnova.com/pwa?aff=838529&aff_model=revenue&afftrack=",
}
NOMBRE_APP = "IQNOVA BOT"


def ruta_recurso(nombre):
    """Ruta de un archivo de esta versión (la descargada por actualización, la del .exe o junto al script)."""
    junto = os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)
    if os.path.isfile(junto):
        return junto
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, nombre)


def _arranque():
    """El módulo que verifica actualizaciones (solo existe si el programa se abrió con arranque.py)."""
    return sys.modules.get("arranque")


def reiniciar_programa():
    """Vuelve a abrir el programa para usar la versión recién descargada."""
    if REINICIAR:
        REINICIAR()
        return
    import subprocess
    env = dict(os.environ, PYINSTALLER_RESET_ENVIRONMENT="1")
    if getattr(sys, "frozen", False):
        comando = [sys.executable] + sys.argv[1:]
    else:
        comando = [sys.executable, os.path.abspath(sys.argv[0])] + sys.argv[1:]
    subprocess.Popen(comando, env=env, close_fds=True)
    os._exit(0)


_TECLADO = []   # se guarda la referencia para que Android no la descarte antes de usarla


def ajustar_teclado_android():
    """Android: al abrir el teclado, la pantalla se DESPLAZA hacia arriba en vez de encogerse.
    Encoger la ventana es lo que dejaba la mitad de la app en negro al escribir el correo o la clave."""
    try:
        from java import jclass, dynamic_proxy
    except ImportError:
        return False                      # PC: no aplica
    try:
        actividad = jclass("org.beeware.android.MainActivity").singletonThis
        modo = jclass("android.view.WindowManager$LayoutParams").SOFT_INPUT_ADJUST_PAN
        Runnable = jclass("java.lang.Runnable")

        class Aplicar(dynamic_proxy(Runnable)):
            def run(self):
                try:
                    actividad.getWindow().setSoftInputMode(modo)
                except Exception:
                    pass
                # sin la barra de arriba con el nombre: la interfaz ocupa toda la pantalla
                try:
                    barra = actividad.getSupportActionBar()
                    if barra is not None:
                        barra.hide()
                except Exception:
                    try:
                        barra = actividad.getActionBar()
                        if barra is not None:
                            barra.hide()
                    except Exception:
                        pass
                try:   # la barra del reloj y la batería con el mismo azul de fondo
                    color = jclass("android.graphics.Color").parseColor("#090E1C")
                    actividad.getWindow().setStatusBarColor(color)
                    actividad.getWindow().setNavigationBarColor(color)
                except Exception:
                    pass

        tarea = Aplicar()
        _TECLADO.append(tarea)
        actividad.runOnUiThread(tarea)
        return True
    except Exception:
        return False


# =====================================================================
#  NOTIFICACIONES (PC: avisos de Windows · celular: notificaciones de Android)
#  y funcionamiento en segundo plano en el celular (servicio en primer plano)
# =====================================================================
_NOTIF_N = [100]


def _es_android():
    try:
        import java  # noqa: F401
        return True
    except ImportError:
        return False


def _actividad():
    from java import jclass
    return jclass("org.beeware.android.MainActivity").singletonThis


def _en_ui(fn):
    """Ejecuta fn en el hilo de la pantalla de Android."""
    from java import jclass, dynamic_proxy
    Runnable = jclass("java.lang.Runnable")

    class Tarea(dynamic_proxy(Runnable)):
        def run(self):
            try:
                fn()
            except Exception:
                pass
    t = Tarea()
    _TECLADO.append(t)
    _actividad().runOnUiThread(t)


# ---------- Android: tarjetas de notificación del bot ----------
_API = []                       # la Api activa (para el botón "Operar de todos modos" de la notificación)
_ESTILO = {  # tipo: (color inicio del degradado, color final, acento)
    "fija": ("#0D1626", "#1C2D52", "#34D27F"),
    "ganada": ("#063A25", "#12804F", "#5CF2A6"),
    "stopwin": ("#05331F", "#0F7A49", "#5CF2A6"),
    "stoploss": ("#3A0B12", "#9B2431", "#FF8A8A"),
    "mercado_malo": ("#3A2204", "#B0650F", "#FFC266"),        # naranja: el bot está en pausa
    "mercado_aviso": ("#2A1E08", "#7A5410", "#FFD27A"),       # dorado: errático, se pausará al terminar
    "mercado_ok": ("#063A25", "#12804F", "#5CF2A6"),
    "error": ("#3A0B12", "#9B2431", "#FF8A8A"),               # rojo: IQ Option rechazó algo / sin conexión
}
_PAIS = {"EUR": "EU", "USD": "US", "GBP": "GB", "JPY": "JP", "CHF": "CH", "AUD": "AU", "CAD": "CA", "NZD": "NZ",
         "COP": "CO", "BRL": "BR", "MXN": "MX", "PEN": "PE", "CLP": "CL", "ARS": "AR", "TRY": "TR", "ZAR": "ZA",
         "SGD": "SG", "INR": "IN", "HKD": "HK", "CNY": "CN", "CNH": "CN", "NOK": "NO", "SEK": "SE", "DKK": "DK",
         "PLN": "PL", "HUF": "HU", "CZK": "CZ", "RUB": "RU", "THB": "TH", "IDR": "ID", "KRW": "KR", "ILS": "IL",
         "AED": "AE", "SAR": "SA", "EGP": "EG", "NGN": "NG", "KES": "KE", "PHP": "PH", "MYR": "MY", "VND": "VN"}
_ERRORES_NOTI = set()


def _res(ctx, nombre, tipo):
    return ctx.getResources().getIdentifier(nombre, tipo, ctx.getPackageName())


def _color(hexa):
    from java import jclass, jint
    return jint(jclass("android.graphics.Color").parseColor(hexa))     # jint: elige setColor(int), no (long)


def _argb(a, r, g, b):
    from java import jint
    return jint(((a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255)) - (1 << 32 if a >= 128 else 0))


def _ctx():
    """Contexto para notificar: la app aunque la pantalla esté apagada o la ventana cerrada."""
    s = _SERVICIO.get("ctx")
    if s is not None:
        return s
    return _actividad().getApplicationContext()


def _icono_chico(ctx):
    """LS con la línea (silueta del APK); Android lo pinta dentro del círculo amarillo."""
    return _res(ctx, "ic_noti", "drawable") or ctx.getApplicationInfo().icon


def _bandera(cod):
    p = _PAIS.get(cod)
    return "".join(chr(0x1F1E6 + ord(c) - 65) for c in p) if p else None


def _par_bonito(par):
    """'EURUSD-OTC' -> ('EUR/USD OTC', '🇪🇺🇺🇸')."""
    base, _, resto = (par or "").partition("-")
    base = base.upper()
    a, b = base[:3], base[3:6]
    nombre = f"{a}/{b}" if len(base) == 6 else base
    if resto:
        nombre += " " + resto.upper().replace("OP", "").strip()
    fa, fb = _bandera(a), _bandera(b)
    return nombre.strip(), (fa + fb if fa and fb else None), a


def _ajustar(p, texto, ancho):
    if p.measureText(texto) <= ancho:
        return texto
    while texto and p.measureText(texto + "…") > ancho:
        texto = texto[:-1]
    return texto + "…"


def _dibujar_tarjeta(ctx, tema, izq, titulo, sub="", etiqueta="", monto="", chip="", punto=None, compacta=False,
                     pildoras=None):
    """Dibuja la tarjeta 'premium en degradado' como imagen (así no hace falta cambiar el APK).
    izq: ('logo',) · ('banderas', '🇬🇧🇯🇵', 'GBP') · ('check',)"""
    from java import jclass
    Bitmap = jclass("android.graphics.Bitmap")
    Config = jclass("android.graphics.Bitmap$Config")
    Canvas = jclass("android.graphics.Canvas")
    Paint = jclass("android.graphics.Paint")
    PaintStyle = jclass("android.graphics.Paint$Style")
    Align = jclass("android.graphics.Paint$Align")
    RectF = jclass("android.graphics.RectF")
    Path = jclass("android.graphics.Path")
    Direction = jclass("android.graphics.Path$Direction")
    LinearGradient = jclass("android.graphics.LinearGradient")
    TileMode = jclass("android.graphics.Shader$TileMode")
    Typeface = jclass("android.graphics.Typeface")
    BitmapFactory = jclass("android.graphics.BitmapFactory")
    m = ctx.getResources().getDisplayMetrics()
    d = min(m.density, 2.0)                 # imagen liviana (Android limita el tamaño de una notificación)
    dp = lambda v: v * d
    W = int(max(dp(260), (m.widthPixels / m.density - 84) * d))
    H = int(dp(52 if compacta else 88))
    a, b, acento = _ESTILO.get(tema, _ESTILO["fija"])
    bmp = Bitmap.createBitmap(W, H, Config.ARGB_8888)
    c = Canvas(bmp)
    rect = RectF(0.0, 0.0, float(W), float(H))
    rad = dp(14)
    forma = Path()
    forma.addRoundRect(rect, rad, rad, Direction.CW)
    c.save()
    c.clipPath(forma)
    p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.setShader(LinearGradient(0.0, 0.0, float(W), float(H), _color(a), _color(b), TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(LinearGradient(0.0, 0.0, 0.0, H * 0.5, _argb(26, 255, 255, 255), _argb(0, 255, 255, 255),
                               TileMode.CLAMP))
    c.drawRect(rect, p)
    p.setShader(None)
    # línea de gráfico de fondo
    linea = Path()
    pts = [(0, .83), (.15, .70), (.27, .77), (.40, .50), (.52, .57), (.65, .30), (.80, .37), (1, .10)]
    x0, ancho_l = W * 0.38, W * 0.62
    for i, (px, py) in enumerate(pts):
        x, y = x0 + px * ancho_l, H * 0.3 + py * H * 0.7
        (linea.moveTo if i == 0 else linea.lineTo)(float(x), float(y))
    p.setStyle(PaintStyle.STROKE)
    p.setStrokeWidth(dp(2.2))
    p.setColor(_color(acento))
    p.setAlpha(70)
    c.drawPath(linea, p)
    p.setStyle(PaintStyle.FILL)
    p.setAlpha(255)
    # izquierda: logo, banderas o ✓
    pad = dp(12)
    s = dp(34 if compacta else 46)
    cy = H / 2.0
    caja = RectF(pad, cy - s / 2, pad + s, cy + s / 2)
    if izq[0] == "logo":
        logo = BitmapFactory.decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))
        if logo is None:
            logo = BitmapFactory.decodeResource(ctx.getResources(), ctx.getApplicationInfo().icon)
        if logo is not None:
            c.drawBitmap(logo, None, caja, Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG))
    elif izq[0] == "banderas":
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        if izq[1]:
            tp.setTextSize(s * 0.38)
            tp.setTextAlign(Align.CENTER)
            tp.setShadowLayer(dp(3), 0.0, dp(1.5), _argb(110, 0, 0, 0))
            c.drawText(izq[1], pad + s / 2, cy + s * 0.16, tp)
        else:                                            # cripto, acciones…: círculo con sus letras
            tp.setColor(_argb(46, 255, 255, 255))
            c.drawCircle(pad + s / 2, cy, s * 0.42, tp)
            tp.setColor(_argb(255, 255, 255, 255))
            tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
            tp.setTextSize(s * 0.26)
            tp.setTextAlign(Align.CENTER)
            c.drawText((izq[2] or "?")[:4], pad + s / 2, cy + s * 0.09, tp)
    else:
        tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.setColor(_argb(40, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.STROKE)
        tp.setStrokeWidth(dp(2))
        tp.setColor(_argb(115, 255, 255, 255))
        c.drawCircle(pad + s / 2, cy, s * 0.45, tp)
        tp.setStyle(PaintStyle.FILL)
        tp.setColor(_argb(255, 255, 255, 255))
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
        tp.setTextSize(s * 0.48)
        tp.setTextAlign(Align.CENTER)
        c.drawText("✓", pad + s / 2, cy + s * 0.17, tp)
    # derecha: etiqueta + monto (+ cuenta y temporalidad debajo)
    negrita = Typeface.create("sans-serif", Typeface.BOLD)
    pm = Paint(Paint.ANTI_ALIAS_FLAG)
    pm.setTypeface(negrita)
    pm.setColor(_argb(255, 255, 255, 255))
    pm.setTextAlign(Align.RIGHT)
    pm.setTextSize(dp(18 if compacta else 21))
    pm.setShadowLayer(dp(4), 0.0, dp(1.5), _argb(60, 0, 0, 0))
    pe = Paint(Paint.ANTI_ALIAS_FLAG)
    pe.setTypeface(negrita)
    pe.setColor(_color(acento))
    pe.setTextAlign(Align.RIGHT)
    pe.setTextSize(dp(8.5))
    pc = Paint(Paint.ANTI_ALIAS_FLAG)
    pc.setTypeface(negrita)
    pc.setTextSize(dp(9))
    try:
        pe.setLetterSpacing(0.12)
        pc.setLetterSpacing(0.05)
    except Exception:
        pass
    derecha = W - pad
    ancho_der = ancho_etq = ancho_chip = 0
    chip_txt = chip if not compacta else ""
    if monto:
        ancho_der = pm.measureText(monto)
        if compacta:
            c.drawText(monto, derecha, cy + dp(6), pm)
        else:
            y_m = cy + (dp(5) if chip_txt else dp(13))
            c.drawText(monto, derecha, y_m, pm)
            if etiqueta:
                c.drawText(etiqueta, derecha, y_m - dp(23), pe)
                ancho_etq = pe.measureText(etiqueta)
            if chip_txt:
                cw = pc.measureText(chip_txt) + dp(12)
                fondo = Paint(Paint.ANTI_ALIAS_FLAG)
                fondo.setColor(_argb(40, 255, 255, 255))
                c.drawRoundRect(RectF(derecha - cw, y_m + dp(7), derecha, y_m + dp(23)), dp(5), dp(5), fondo)
                pc.setColor(_argb(225, 255, 255, 255))
                pc.setTextAlign(Align.CENTER)
                c.drawText(chip_txt, derecha - cw / 2, y_m + dp(18.5), pc)
                ancho_chip = cw
    # centro: punto + título / par / píldoras de dirección y nivel
    x = pad + s + dp(10 if not compacta else 11)
    limite = derecha - ancho_der - dp(10) - x                     # fila del par: al lado del monto
    limite_t = derecha - max(ancho_etq, 0 if (sub or pildoras) else ancho_der) - dp(10) - x   # título: arriba
    limite_p = derecha - (ancho_chip or ancho_der) - dp(8) - x    # píldoras: al lado de la cuenta
    pt = Paint(Paint.ANTI_ALIAS_FLAG)
    pt.setTypeface(negrita)
    pt.setColor(_argb(255, 255, 255, 255))
    pt.setTextSize(dp(15 if compacta else 15.5))
    ps = Paint(Paint.ANTI_ALIAS_FLAG)
    ps.setColor(_argb(205, 255, 255, 255))
    ps.setTextSize(dp(12.5))
    filas = 1 + (1 if (sub and not compacta) else 0) + (1 if (pildoras and not compacta) else 0)
    if compacta or filas == 1:
        y_t = cy + dp(5)
    elif filas == 2:
        y_t = cy - dp(4)
    else:
        y_t = cy - dp(12)
    xt = x
    if punto == "radar":                     # radar pequeño: el bot está analizando el mercado
        r = dp(7)
        cxr, cyr = xt + r, y_t - pt.getTextSize() * 0.36
        pr = Paint(Paint.ANTI_ALIAS_FLAG)
        pr.setStyle(PaintStyle.STROKE); pr.setStrokeWidth(dp(1.2)); pr.setColor(_color("#4A5A7A"))
        c.drawCircle(cxr, cyr, r, pr); c.drawCircle(cxr, cyr, r * 0.55, pr)
        pa = Paint(Paint.ANTI_ALIAS_FLAG); pa.setColor(_argb(110, 245, 165, 36))
        c.drawArc(RectF(cxr - r, cyr - r, cxr + r, cyr + r), -90.0, 60.0, True, pa)
        pl = Paint(Paint.ANTI_ALIAS_FLAG); pl.setColor(_color("#FFC35A")); pl.setStrokeWidth(dp(1.6))
        c.drawLine(cxr, cyr, cxr + r * 0.87, cyr - r * 0.5, pl)
        pv = Paint(Paint.ANTI_ALIAS_FLAG); pv.setColor(_color("#34D27F"))
        c.drawCircle(cxr + r * 0.4, cyr + r * 0.45, dp(1.6), pv)
        xt += r * 2 + dp(7)
    elif punto:
        pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.setColor(_color(punto))
        pp.setShadowLayer(dp(4), 0.0, 0.0, _color(punto))
        r = dp(4.5)
        c.drawCircle(xt + r, y_t - pt.getTextSize() * 0.36, r, pp)
        xt += r * 2 + dp(7)
    c.drawText(_ajustar(pt, titulo, max(dp(40), (limite if compacta else limite_t) - (xt - x))), xt, y_t, pt)
    y = y_t
    if sub and not compacta:
        y += dp(18)
        c.drawText(_ajustar(ps, sub, limite), x, y, ps)
    if pildoras and not compacta:
        y += dp(8)
        px = x
        oscuro = tema != "fija"                     # sobre verde o rojo, píldora con fondo oscuro para que resalte
        for texto, col in pildoras:
            pc.setTextAlign(Align.LEFT)
            w = pc.measureText(texto) + dp(12)
            if px + w > x + limite_p:
                break
            caja_p = RectF(px, y, px + w, y + dp(16))
            f = Paint(Paint.ANTI_ALIAS_FLAG)
            if oscuro:
                f.setColor(_argb(110, 0, 0, 0))
            else:
                f.setColor(_color(col))
                f.setAlpha(40)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            f.setStyle(PaintStyle.STROKE)
            f.setStrokeWidth(dp(1))
            f.setColor(_color(col))
            f.setAlpha(120)
            c.drawRoundRect(caja_p, dp(5), dp(5), f)
            pc.setColor(_color(col))
            c.drawText(texto, px + dp(6), y + dp(11.8), pc)
            px += w + dp(5)
    c.restore()
    return bmp


def _vista_imagen(ctx, bmp, boton=None):
    """Mete la tarjeta dibujada en el diseño que ya trae el APK (Android 12+). Devuelve la vista o None."""
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 31 or not _res(ctx, "noti_tarjeta", "layout"):
        return None
    RemoteViews = jclass("android.widget.RemoteViews")
    TypedValue = jclass("android.util.TypedValue")
    v = RemoteViews(ctx.getPackageName(), _res(ctx, "noti_tarjeta", "layout"))
    for nombre in ("barra", "banderas", "titulo", "detalle", "insignia", "monto"):
        v.setViewVisibility(_res(ctx, nombre, "id"), 8)                  # GONE
    img = _res(ctx, "logo", "id")
    v.setImageViewBitmap(img, bmp)
    v.setViewLayoutWidth(img, -1.0, TypedValue.COMPLEX_UNIT_PX)          # todo el ancho
    v.setViewLayoutHeight(img, 88.0, TypedValue.COMPLEX_UNIT_DIP)
    v.setViewLayoutMargin(img, RemoteViews.MARGIN_START, 0.0, TypedValue.COMPLEX_UNIT_PX)
    v.setViewOutlinePreferredRadius(img, 14.0, TypedValue.COMPLEX_UNIT_DIP)
    if boton:
        texto, color_txt, fondo, pi = boton
        bid = _res(ctx, "boton", "id")
        v.setTextViewText(bid, texto)
        v.setTextColor(bid, _color(color_txt))
        if fondo.startswith("#"):                  # color directo, con esquinas redondeadas
            v.setInt(bid, "setBackgroundColor", _color(fondo))
            v.setViewOutlinePreferredRadius(bid, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        else:
            f = _res(ctx, fondo, "drawable")
            if f:
                v.setInt(bid, "setBackgroundResource", f)
        v.setViewLayoutMargin(bid, RemoteViews.MARGIN_TOP, 10.0, TypedValue.COMPLEX_UNIT_DIP)
        v.setViewVisibility(bid, 0)
        v.setOnClickPendingIntent(bid, pi)
    return v


def jclass_bitmap_logo(ctx):
    from java import jclass
    return jclass("android.graphics.BitmapFactory").decodeResource(ctx.getResources(), _res(ctx, "logo_ls", "drawable"))


def _pi_abrir(ctx):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    abrir = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName())
    return PendingIntent.getActivity(ctx, 0, abrir, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _pi_servicio(ctx, accion, n):
    from java import jclass
    PendingIntent = jclass("android.app.PendingIntent")
    i = jclass("android.content.Intent")(accion)
    i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
    return PendingIntent.getService(ctx, n, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)


def _canal(ctx, cid, nombre, importancia, publico=True, alerta=False):
    from java import jclass
    if jclass("android.os.Build$VERSION").SDK_INT < 26:
        return
    NotificationChannel = jclass("android.app.NotificationChannel")
    Notification = jclass("android.app.Notification")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    c = NotificationChannel(cid, nombre, importancia)
    if publico:
        c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC)
    if alerta:
        c.enableVibration(True)
        from java import jarray, jlong
        c.setVibrationPattern(jarray(jlong)([0, 250, 120, 250]))
        c.enableLights(True)
    nm.createNotificationChannel(c)


def _builder(ctx, cid):
    from java import jclass
    B = jclass("android.app.Notification$Builder")
    return B(ctx, cid) if jclass("android.os.Build$VERSION").SDK_INT >= 26 else B(ctx)


def _pildoras(direccion, intento):
    """▲ CALL verde / ▼ PUT rojo + ENTRADA (gris) o NIVEL/GALE (ámbar)."""
    d = ("▲ CALL", "#34D27F") if direccion == "call" else ("▼ PUT", "#FF5A5A")
    t = (intento or "Entrada").upper()
    return [d, (t, "#AEB6C4" if t.startswith("ENTRADA") else "#FFB547")]


def _datos_tarjeta(tipo, titulo, texto, par=None, dir=None, op=None, monto=None, **_):
    """Qué va en cada tarjeta: (izq, título, subtítulo, etiqueta, monto, botón, píldoras)."""
    dinero = (lambda v: nucleo.texto_dinero(v)) if monto is not None else (lambda v: "")
    if tipo == "ganada":
        nombre, flags, cod = _par_bonito(par)
        return ("banderas", flags, cod), nombre, "", "GANADA", dinero(monto), None, _pildoras(dir, op)
    if tipo == "stopwin":
        return ("logo",), "Stop Win", "Meta cumplida", "HOY", dinero(monto), None, None
    if tipo == "stoploss":
        return ("logo",), "Stop Loss", "Saldo protegido", "HOY", dinero(monto), None, None
    return ("logo",), titulo, texto, "", "", None, None


def _notificar_android(titulo, texto, tipo="ganada", **datos):
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado", NotificationManager.IMPORTANCE_HIGH,
           alerta=True)
    izq, t1, t2, etq, mto, boton, pild = _datos_tarjeta(tipo, titulo, texto, **datos)
    a, b, acento = _ESTILO.get(tipo, _ESTILO["ganada"])
    linea = f"{t1} · {mto}" if mto else t1
    if pild and not t2:
        t2 = " · ".join(p[0] for p in pild)
    b_ = _builder(ctx, "iqbot_alertas")
    b_.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(linea).setContentText(t2) \
      .setAutoCancel(True).setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
      .setShowWhen(True).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    pi_boton = None
    if boton:
        pi_boton = _pi_servicio(ctx, boton[3], boton[4])
    hecho = False
    try:
        grande = _dibujar_tarjeta(ctx, tipo, izq, t1, "" if pild else t2, etq, mto, pildoras=pild)
        vista = _vista_imagen(ctx, grande, (boton[0], boton[1], boton[2], pi_boton) if boton else None)
        if vista:
            b_.setCustomBigContentView(vista)            # cerrada: título y texto normales; abierta: la tarjeta
            b_.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
            hecho = True
        else:
            b_.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("tarjeta", e)
    if boton and not hecho:
        b_.addAction(_icono_chico(ctx), boton[0], pi_boton)
    _NOTIF_N[0] += 1
    nm.notify(77 if tipo.startswith("mercado") else _NOTIF_N[0], b_.build())


def _aviso_error(donde, e):
    clave = f"{donde}:{type(e).__name__}"
    if clave in _ERRORES_NOTI:
        return
    _ERRORES_NOTI.add(clave)
    try:
        bot = _bot_activo()
        if bot:
            bot.log(f"⚠ Notificación ({donde}): {type(e).__name__}: {e}", "yellow")
    except Exception:
        pass


def _app_visible():
    """True si la app está en pantalla (para esconder la tarjeta fija mientras la usas)."""
    try:
        from java import jclass
        RAP = jclass("android.app.ActivityManager$RunningAppProcessInfo")
        info = RAP()
        jclass("android.app.ActivityManager").getMyMemoryState(info)
        return info.importance <= RAP.IMPORTANCE_FOREGROUND
    except Exception:
        return False


def _estado_fija(bot, texto):
    """(punto, título, chip, subtítulo, monto, píldoras) de la tarjeta fija."""
    if not bot:
        return "#F5A524", NOMBRE_APP, "", texto, "", None
    cfg = bot.cfg
    tf_txt = " ".join(f"M{t}" for t in (cfg.get("temporalidades") or [1]))
    chip = f"{'REAL' if cfg.get('cuenta') == 'REAL' else 'DEMO'} · {tf_txt}"
    g = bot.pnl
    monto = nucleo.texto_dinero(g)
    if getattr(bot, "pausado", False):
        return "#FFA53D", "En pausa", chip, "El bot no abre operaciones", monto, None
    ult = None
    try:
        abiertas = list(bot.abiertas.values())
        ult = abiertas[-1] if abiertas else None          # solo la operación ABIERTA (no la última que cerró)
    except Exception:
        pass
    if ult and ult.get("par"):
        nombre, flags, _ = _par_bonito(ult["par"])
        sub = f"{flags + ' ' if flags else ''}{nombre}"
        return "#34D27F", "Operando", chip, sub, monto, _pildoras(ult.get("dir"), ult.get("intento"))
    # sin operación abierta: analizando el mercado + el resultado de la última operación
    pild = None
    try:
        r = bot.resultados[0] if bot.resultados else None
        if r and r.get("par"):
            nombre = _par_bonito(r["par"])[0].replace(" OTC", "")
            flecha = "▲" if r.get("dir") == "call" else "▼"
            neto = float(r.get("neto") or 0)
            pild = [(f"Última {nombre} {flecha} {nucleo.texto_dinero(neto)}", "#34D27F" if neto > 0 else "#FF5A5A" if neto < 0 else "#AEB6C4")]
    except Exception:
        pild = None
    return "radar", "Operando", chip, "Analizando mercado…", monto, pild


def _noti_trabajando(ctx, texto, bot=None):
    """Tarjeta fija del servicio. Con la app abierta va en modo mínimo (no se ve);
    al salir o bloquear aparece como la de la música."""
    from java import jclass
    Notification = jclass("android.app.Notification")
    NotificationManager = jclass("android.app.NotificationManager")
    visible_app = _app_visible()
    _canal(ctx, "iqbot_fija", "Bot trabajando", NotificationManager.IMPORTANCE_DEFAULT)
    _canal(ctx, "iqbot_fija_min", "Bot trabajando (app abierta)", NotificationManager.IMPORTANCE_MIN, publico=False)
    cid = "iqbot_fija_min" if visible_app else "iqbot_fija"
    try:
        punto, titulo, chip, sub, monto, pild = _estado_fija(bot, texto)
    except Exception:                         # nunca deja el servicio sin su tarjeta
        punto, titulo, chip, sub, monto, pild = "#F5A524", NOMBRE_APP, "", texto or "Toca para abrir", "", None
    b = _builder(ctx, cid)
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")) \
     .setContentTitle(f"{titulo} · {chip}" if chip else titulo) \
     .setContentText(f"{sub} {' '.join(p[0] for p in pild) if pild else ''}  {monto}".strip()) \
     .setOngoing(True).setOnlyAlertOnce(True) \
     .setContentIntent(_pi_abrir(ctx)).setVisibility(Notification.VISIBILITY_PUBLIC) \
     .setCategory(Notification.CATEGORY_SERVICE)
    try:
        grande = _dibujar_tarjeta(ctx, "fija", ("logo",), titulo, sub, "GANANCIA" if monto else "", monto, chip, punto,
                                  pildoras=pild)
        vista = _vista_imagen(ctx, grande)
        if vista:
            b.setCustomBigContentView(vista)
            b.setStyle(jclass("android.app.Notification$DecoratedCustomViewStyle")())
        else:
            b.setLargeIcon(jclass_bitmap_logo(ctx))
    except Exception as e:
        _aviso_error("fija", e)
    return b.build()


# ---------- Notificaciones de Windows: tarjetas como las del celular ----------
# Cada tipo trae su imagen premium (degradado + logo LS) y el texto con el par, el monto y la sesión.
_IMG_NOTI = {   # imágenes de las notificaciones de Windows (IQNOVA BOT)
    "ganada": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHAABAQEAAgMBAAAAAAAAAAAAAQACBgcDBQgE/8QAVxAAAgEDAgIFBgcJCwkJ"
        "AQEAAAECAwQRBQYSIQcxQVFhCBMicYGRFBUXMlKhsSM2QlV0pLLS4hYYN2V1kpSis8HRJCYzVmJygsLhJTRDU2Zzk9PwNfH/xAAb"
        "AQEBAAMBAQEAAAAAAAAAAAAAAQIDBQQGB//EADQRAQACAQIFAgMGBgMBAQAAAAABAgMEERITITFRBUEUMnEiNGGR0fAGM1KBobEk"
        "4fEjwf/aAAwDAQACEQMRAD8A6QEEJi+aREJRIQFEQigEiIQEokICiIRQCAkRBEJCBIQFBCREEQohAhAQiEiASRCEQkQEICRiRAQI"
        "SICFESCNIUCFAaQoEaQCjSBCgE0gQoI0hQIUBoUCFAaEBQCjSMo0gFGkZRpBCaQIUAmkCFAJpAhQQo0jKNIBQoEKA0hQISDSFGUa"
        "QCjSMoUBoUCFAaQmRCEgLIEREEREQRERBETIggIiCSiIgOrxIjN1EKIioRBCRCiIiBIiKEQQkQoQECIhCIQQgIgIREQhEKIghIhA"
        "hAQkpCQgREREJEIRCQgREIEICEKNAhQGkKBCBpCgQoI0hQIUBpCgQgaFAhQGhQIUEaQoEKA0hQIQNIUCEIUaMmkAo0jKNIgUKBCg"
        "NIUCFFCaRlCBpCgQoiNIUZQoDSFGcjkDWRyZyWQjWSAgNEBAOSAghIBCICIIiIgiIiIjrAiI2uqRQCEIoEJEQgIEICiIRQCAkRAQ"
        "gKCEUAhCREEQkIEICEQkQCSIQiEiAhAURihIQISICEiCEQEBQoBQRpGkZRpAKFAhQGkICgNITKNIIUaMo0gNIUZRpAaQoEKCNITJ"
        "pAKNIyjSAUaRlCgNIUCEDQoyjSCFGkZFAaQoyhINogRZA0jWTCYoI1kUZFAaHJkQHIhkshCQZIByIEEJBkghIBCIiAiEiII6wEBN"
        "rrFCAojFCRECRFkoSyAkQ5HJnI5AckGRyEImRA0iM5FMI0QZHIChTMimEayOTKYhGiAUwhFAhASIiJKEkIRCQgREIERCEQkIEKIg"
        "jSFAhA0KMo0gNCjKNIIUaRlGkBoUCFBCaRlGkAo0ZQoDSEEKA0hRk0ghRpGUIGkaRlCBpCjKFEGkKMigjY5MoUBoUzKFAaFGUIGi"
        "AsgaEzkgjWRMiEI5MjkBICCHJEQQkBEQkBBCREB1kIITY6pIhCIiABIiAhAMg2aLJnJLL6kwsQ1kcmeGf0Ze4uGf0Ze4vDPheCfD"
        "WRyY4Z/Rl7h4Z/Rl7hwz4OXPhvJZMYn9GXuHEvoy9w4Z8HBbw3kUzGJfRl7ixL6L9w4Z8Jy58PImKZ48S+i/cOcE2lJpMd4eRMUz"
        "xpmkyMJh5ExRhM0gx2aRpGUxCEiEjFCiQgQkiAhIgiEhAhIghIiAUaRlGkEKNIyjSAUaRlCgjSNIyhQGkaRlCgNIUZRoDSFGUaCF"
        "CgQoDSEEKA0hMoSDSFGUaQQ5NGRQCaRlCgNIUZFAaQmUOQNIcmcimE3ayWQJBGsjkyhARDJZCETIgJZAQhIMlkiHJAIQkBBCREB1"
        "oSITY6qEkRBMCEogyTYZIqyEpKEeKT4Y95mUoxi5SeIrrPwVq8q0+J8l2LuPRhw8XWez14NPx/at2foqXz6qUVFd75s8Eq9ST51J"
        "P2njyWT3RWI6Q99axXpDXHL6T95ccvpP3mclkrLZrjl9J+8uOX0n7zOSyDZrjl9J+8uOX0n7zOSyDZrjl9J+8uOX0n7zOSyDZrjl"
        "9J+81GvUg8xqSXtPHksg2fspajJcqqUl3rkz91KrGrFSg8r7D0uTyUK86E+KPV2rvNOTDW3bu8+XTVvHTpL3aZtM/PSqxqwU4vKf"
        "1HmTOfaJidpcm9JrO0vIhRlM0iNUtITJpEYkSECIiASIQiEhAhAQiIhAhIQxKEEKA0hRlGkBpCjKNIBQoEKCNIUCEDQoyjQCaRlC"
        "iI0mKMoQNCmCEDSFGRTA0hRlGgEUZFBGhyZyOQNJjkyhA0KMigjQmRyAiZEIciZEByOQII0QFkISASISIMhCWQEBICCOtkJCjY6y"
        "JkRAEIMoGZbFmVzkl4iGdY3flvavpKkuqPN+s/Lka0+OtOXfJmMnUrG0bQ7Na8MbQ1ksmcnLejvo8vekDUK1KjXha2ltwuvXlFya"
        "znCiu1vD7V1GrPqMeDHOXLO1YbceO2S0VrG8y4pksndO4vJ2dtps6+h6rVuLmnHidC4gkqmOtRcep9yw/WdKPKbT5NGjReo4NZWb"
        "YLb7d2zPpsmGdskNZLJ2PoHRDK90+nc6pe1LepVipRo0opuCa5cTfb4fWcc3lse82lUhUlUVzZ1XwwrqPDiX0ZLsf2nYyaLNSnMt"
        "Xo51NZhvfl1t1cbyWTOSyeR6mslkzkusDWSydl6N0OuvYwrapfVKFepHi8zSin5vwbfW+/7TiW8dn3W0b2nTqVFXt6ybo1ksZx1p"
        "rsayveevLos2OnMvXo8uPWYcl+Cs9Xoclkzksnkep+7Ta7jUdJ9Uua9Z7SLPQUZ8FaEl2SR72L5nj1NesS52tp1izzJm0eKLPIjy"
        "ubLaFAjSIxKEDn3QjtShuzpAs7e7gqlrZwle1qbWVNQaUU/DilHPesoMsdJvaKx7ve7C8nnW902dLUtXulo9lVSnThKnx16kX1Ph"
        "ylFPsbefA7Bh5Lu1FTxPV9bdT6SnSS93B/ec36Tt/UOjvbM9TdKNe6qTVG1oSeFOb55eOxJNv3dp84V+n3pCrXTrx1uFGOcqlTta"
        "XAl3c4tv2vJl0h1cldLp/sXjeXKd4+TRqml207vbd/8AGkIJydrViqdbH+y84k/Dl4ZOl5050pyp1IyhOLcZRksNNdjR9bdDHSdW"
        "6RNHuYahTp09UsJRjWdNYjVjLPDNLsfJprw8cLp7yjtt0NG3xT1C2pxp09UoKtNLl91i+GTx4rhfrbEx7tGq02Plxmw9nVJ3H0dd"
        "AdLeu1LbXbvWa9i7mU+ClGgpejGTjnLa62mdPU4SqTjCEXKUmkklzbPtzSbWhsjZFtQqtKlpOnp1X38EMyftabJEMNBgrltM3jpD"
        "ql+SzY4eNz3OezNrH9Y+fru1q2N3Wta8eGtQqSpzj3STw170fVnQJuq43RsurK9rSq3dreVYVJSeW1N+cT9XptL/AHTonpu0P4i6"
        "SdVjGCjSvJRvKfjxrMn/AD+Mswy1eHHyq5cUbbuJaFp0dY1vT9NlUdKN3c0rdzSy4qc1HOPDJ31+9asP9Zrr+ix/WOktk/floP8A"
        "KNt/axPrnpMvrjTdh61eWlWdG4oW7nTnB4cWmhEGhw470tbJG+zo7pE6BaOydq3Ou2us1r1206anSnQUVwyko5ym+1o4BsDa9Pem"
        "7rDQatzK1hd+czVjHiceGnKfVy+jj2n1lr9vT3r0fXkKCUo6nprqUe30pU+KD9+D5p6Cv4VND9df+wqCY6rqdNjpmpFY+zO3+3ve"
        "kzoRtdg7Zes0darXklXhR83OgoL0s88pvuOpj6m8oz+DmX5bR/5j5ZJLz+oYq4svDSNo2dgdE/ReukivqKrX1SxoWUYfdIU1PilJ"
        "vC5tdkX9R2N+9esP9Zbr+ix/WOQeTtofxX0fxvZxxU1K4nXy+vgj6EV6vRb9pbR3xLVOmXdOiyrylbRowp0IuWYxnRxGaS725zf/"
        "AA+BYiHuwabDGOnMjrZ0H0h7NlsTdNxovn5XNKEIVKVaUeF1IyiuePB8S9hxtHenlO6JitouuQj86M7OrL1enBfXM6KRJcvV4oxZ"
        "bUjs+goeTFYyin+6W55rP/dY/rGv3sNj/rLc/wBFj+sZ6GOlHc+8d2VNM1e7o1baFnOqowoRg+JSglzS8Wcs6aN8avsXRbC80eVC"
        "NWvculPztPjXDwt/3F6OtXHpLYpzcPSP35cI1DyYq8KcpaduSnUnjlC4tXBfzlJ/YdVbq2Zrey79Wes2cqLlzp1Yvip1V3xl2+rr"
        "Xajs3aflHap8Z0LfclnZzsqklCde3jKE6WX85rLUku1LH9x270gbWtd67SvLCUYVKrputa1Fz4KqWYtPx6n4NjaJ7NM6XBqKTbB0"
        "mHx2jknR7s+W+dz0NH8/K3pzhOpVrRjxOEYxznHi8L2nGjvPyZ9F4q2s63OPzYwtKUvX6U/sgYw52kxc3LWk9n7f3s1j/rJc/wBG"
        "j+sdfdKXRmujuvp6o31S9oXkZ+nOmocMotZXJvskjt/de9Zab0wbY0eNaUbaVGcK8VLClOtmME/FOEX/AMXiPlAaL8ZbDleQjmpp"
        "1xCvldfC/Qkv6yfsMtodTPpcE478uu01fMqNIyhRg4bQoyhQGkaRnIhCmaMJiBrIoEKCFCgQgKEEOQFCZyOQjWSyGRyA5EzkQjRB"
        "kshGiAiDRAIQ5ICCETORASyBBCQZIiOuRJEbHXRCBRGWaMsDMjMX90j60MjMfnx9aLXvDdj+aHqm+bLJlvmyydPd2Wsn0J5ONOC2"
        "pqVRRXHK/cXLtaVOGF9b95885PojycPvR1H+UJf2cD57+J5/4FvrH+3R9L+8R/d2wfHetUacd6X1BQSpLUqkOHs4fOtYPr68vLfT"
        "7Wrd3danQt6MHOpUm8RhFdbbPi7cGpxv9wajfWk5qlWu6talLqlhzbT8HzON/B28ZMltunR7PWutax9X00fi1jSbbXNNr6fdx4qV"
        "aOHjri+xrxT5nEejDb2uULb411zUtQn56OaNnVrSain+HJN9b7F7/Dns0ljvP1jB6/g1GaNNwz9rp+D8lyaimLUcqlt9vePL5r13"
        "Rrnb+qV9Ou16dJ8pLqnHskvBn4MneXSNtBbl0v4Ra009QtU5U8ddSPbD+9ePrOi3lNppprsOdrtLOnycPtPZ9jotVGfHv7x3ayfu"
        "0GMamuadCaTjK6pJp9q40evyfv28/wDt/Tfyql+mjy4/nh6cnyy+lDr7pnjH4gsptLiV0kn3Jwln7EdgnX3TR97tn+Vr9CZ9f6h9"
        "3v8AR8poPvFPq6fyWTOSyfG7vrmk+aPfxfN+s48nzRyCPW/WebU9oeLW/LDzRPLE8MTyxPG5MvIjSMo0gwaO5/JcinvDVZY9Jac0"
        "n66kP8Dpg7l8l2tGO9dTov509OlJeypT/wARHd6NH/Oq5J5VM5LTdvQT9F1q7a8VGGPtZ0XpW19e1yhK40rRNT1CjCXBKpa2tSrG"
        "MsJ4bims4a5eJ3v5VFCctI0C4S9CFxWg34yjFr9FnHOhTpa27sHbV5p2sK9deteSrx8xSU1wuEI9eVzzFlnu9OppW+qmLztH/Th2"
        "3tJ6TdqVK1TRNE3NYzrpRqOlp9X0kurOYeJ+Det9vO+q2kt4w1WNSMZK3+H28qTayuLhzFZ7D6p2N0naF0hVbulo0b3NpGMqrr0l"
        "Bek3jHN9zOp/Ko/7/t3/ANq4+2AmOi5tNWmCb0vMx/ju646JND/dB0iaJaShxUoV1cVO7hprj5+D4UvafRfTxrfxL0a6jGMlGrfS"
        "hZw8eJ5kv5kZHW3ku6H57V9Y1ycOVvRja02+rim+KWPFKC/nHbfSP0c2/SPZ2dnd6jc2dG1qSq4oxT45NYWc9yz7xHZu0mK3w1uH"
        "vb/x0/5MGt/Btw6ro05NRu7aNeCb5cVOWMLxxN/zT2flR6H/APxNdhH6dnVl/Xgv7Q5Xs3oG07Ze47TXLPW76rVtuJebnCKjNSi4"
        "tPHrPbdN2h/HnRtqsYx4qtnGN5Dl1ebeZf1OMbdGUae8aW2O8dY/9fLeyfvy0H+Ubb+1ifWXS1/BtuD8kl9qPk3ZP35aD/KNt/ax"
        "PrLpa/g33B+SS+1COzR6f/Jyfv2eu6DNY+N+jXS+KXFUtOO0n4cEnwr+a4nUWx9H+IPKIjpqjwwo3l35tf7Do1JR/qtHJfJd1jit"
        "Nc0aT+ZUp3dNd/EnGX6MPeez1zR/gHlI7fv4wxDULWpUcu+cKFWD+pQ94bf5mLDfxMfo9n5Rn8HMvy2j/wAx8uUqc61SFKnFznNq"
        "MYrrbfUj6j8oz+DmX5bR/wCY6L6IdD+P+kTRraUOKlRrfCqnco01x8/BtJe0T3eX1Ck31MVj32fVOnW9vsvZtCjUaVDSbBecfeqc"
        "Myftw2fK/RxuWrYdJul6xcVPSub1xry7H55uMm/D08+w+r90aFHc2gX2jTualrC8p+alVppOUYtrOM96yvadWQ8mPRqclOG4NSjK"
        "LymoQTTLMPdrMGW1qcqOlXK+nDRPjvo41LhjxVbLhvIeHA/Sf8xzPkpH3TdWUL7T61jcvzlOvSlRqcscSaw/tPh/U7CrpOpXen1/"
        "9La1p0J/70ZNP7CWeP1fHtat/Lszyb/4QK38n1f06ZznymvvY0n8tf8AZyODeTf/AAgVv5Pq/p0znPlNfexpP5a/7OQjsyw/cbfv"
        "w+dUfauzKkquz9CqSeZT0+3k/W6cT4pR9tbWtZ6ftfSLSqmp29jQpSzyw400n9gqnpHzWfGWpwVLU7unHqjWnFfzmfU3QlovxL0d"
        "abxRUat7xXk/Hjfov+YonzBC2nru4VbW3OpfXfm6frnPC+0+0rWyhY6fRsrb7nToUo0afL5qSwvsFT0rHve1/D5O6Q9yVb/pK1PV"
        "7efpW94o0Jdi801GLXh6OfafUGoULfeO0K1KDTo6rYvgfcqkMxfsymday8mrR5ycpa/qMpSeW3CGWztDbOiLbeg2WkRualzC0p+a"
        "jVqJKTinyzjuWF7BEPVo8GWtr82OlnxdUpzo1JU6kXGcG4yi+tNdaBHLeljRfiLpA1i3jDhpVa3wmn3NVFxcvBNtew4ijB8/kpNL"
        "TWfZvImUSDBvI5MoUEaQoyhA0hMoUwNDkzkchGslkyhA0hRlCgjQmRA0WTORCHIgREayWQHJQiZyWSI0QEEaLIEAkAkQkBFR12RC"
        "ZuwgECojLNAwyh45GF8+PrRuR418+PrLXu24+8PUt82GQb5sMnRdlrJ9D+TpVp0dmapVqzjTpwvpylOTwopUoZbfYj52ye4o7y1G"
        "z2nX2zaT8zaXNy7i4nF+lVXDFKHhH0cvv5d3Pmer6K2swcms7bzH5PVo88YcnHPhzDph6WKm8bqWj6TVlDRaE+clyd3NfhP/AGV2"
        "L2vsx5ei7o4+EOlr2s0fuSxO1t5r5/dOS7u5dvX1Yz+Xow6OPjadPW9Xpf5DF5oUJL/TtfhNfR+31dfb+pajaaPYVb29rRoW9GPF"
        "KT7PBd77EjRFcelxxptPHSP3+b4/+IfXb5bzp8M72npMx/qP3/l49a1qy2/p1XUL+qqdCkvbJ9kUu1s662Fu/Ud3b6vLqu3TtI2c"
        "40qCfo0lxwx65Pnl/wByOEbw3bqG/NZp06NOqrdT4LS1jzeXyy0uuT+rqOV3ug3HRvs60vqU4rVZX1KrWmuaWIT+5+Kw2n35fgdz"
        "0fSTiv8AEWj5es/o1aP0qulxbZf5t+kfh+/eXbR090rbO+Lrp67ZU8W1xLFxGK5U6j/C9Uvt9Z2dt3Xrbcmk0NRtXiNRYnDOXTmu"
        "uL9X2YZ+y9sqGo2la0uqaq0K0XCcH2pn2WpwU1WHaPrEtenzX02XefpMPmHJ7Dbz/wC39M/K6X6aP0bt23cbW1mrY1cypP06FV/+"
        "JB9T9fY/FH5duv8Azg0z8rpfpo+RilqZYrbvEvqpvF8c2r2mH0udfdNP3u2X5Yv0JnYJ1701fe5Zfli/QmfW+ofdr/R8toPvFPq6"
        "cyWTOSyfGPrm0+aOQR6zjqfNHIYHn1HaHi1vyw88DyxPFA8seo8jlWeRGkZRpEa2kcv6Kd3w2Rvex1S4k1ZyzQusLOKc+TfseJf8"
        "JxBCFpeaWi0ez7f3dtXSekLbU9MvJ8dtcKNajcUWm4S64zi+rqftTfedDXfkvbnp3fBaaxpFa2zyq1XUpyx4xUZfaziWyemPdWxq"
        "EbOzuad3YReVa3cXOEO/haacfUnjwOc1PKm1d0OGntyxjWx8+Veco/zcJ/WZbxLqX1Glz7WyRtLtXov6PLDo202pp8byF1qd5itc"
        "VMKLmo8koxznhi5Pn3y8cHWPlT/9/wBu/wDtXH2wOEWHTfuuz3Vc7lqOyu7yvb/BVTr05eao0+JSxCMZLHNd763k9bv/AKStX6Rq"
        "1lV1a2sKErOM40/gsJxTUms54pS+ihv0YZtXitgnFSNvH5vobyftD+J+ji0rzhw1dRq1LuWevDfDH+rBP2nX/SF087m0Teeq6Xo1"
        "SxVlZ1vMQ85R45cUUlPLz9LiPQ6V5Re6dG0y00200vQY29pRhQpp0aueGKSWfuvXhHWN7eVtQvbi8uJcVa4qSq1H3yk8v62N2GbW"
        "RGKuPDO2zsr98bvr/wA3Tv6N/wBT6S0O/obu2lZ3lSKlR1OyjKpBf7cPSj9bR8PHY+0+nfc+0NAtdEsrTSq9ta8SpzuaVSU8OTlh"
        "uM0uTbxy6iRJpNdNbTzpmYce0HTaujdJGnabX/0tprFKhPl2xrJP7D6m6Wv4N9wfkkvtR8o6ju+91PeH7qqltZ0r13NO781SjJUu"
        "ODT6nJvDccvn2vqOYbh6ft0bm0S80e8sNGp295TdKcqNKqppPubqNZ9giWOm1GPFS9J9+zPk+6x8V9I9rQlLEL+hVtX3Zxxr64Je"
        "0+h9xbcraju7autUKSl8WV7mNaXElw06lCSzz6/SUFyy/S7snx5ourXOg6vZarZ8PwizrQr01NNxbi08PDXJ9T8DtD981vD8W6B/"
        "8Fb/AO0sSy0erx0x8GTzu7J8oz+DmX5bR/5jhfkwaH5zUtZ1ycOVGlC0pyfa5Pil7lGPvOGb06aNwb70V6RqVnpVG3dWNXitqdSM"
        "8xzjnKbWOfcZ2P0w65sHSJ6XpVhpNSlUrSrzncUqkpyk0l1xmljEV2DfqX1WK2pjLPaIdvdNvSpq+xdR0zT9EnbKtWozr1/PU+P0"
        "cpQxz5c1M61/fE74/wDN07+jf9Th2895ajvrW5avqcLenXdONJQt4yjCMY9ybb7W+vtPREmXn1GuyWyTNLTEPrjoc31eb82xWvNS"
        "dL4db3MqNTzceFNYUovHtx7Dovp40T4n6Rr2pGPDSv6cLuHLvXDL+tGT9p6rYXSdrXR2r2OlUbKvC84HUjdQlJJxzhrhlHHznn2H"
        "j350iap0h3FpcapaafQq2sJQjK1hOPEm08S4pS6scurrY36NmfV0y6eKWn7UO8Oi3oZvdg7ilrFxq1tdwnayo+bp05RacnF5y/8A"
        "dOSdKPR5U6RdKs7GnqMLF21fzznKk6nF6LWMZXedOR8pbd8UktO0Hksf6Cr/APaP75fd/wCLdB/+Cr/9pd4equq0lcc4o32lznaP"
        "k66VoWp0NQ1XVKmqSoSVSnQjR81T408py9JuS8OXjy5HJelzfNts3at1CNePxne05UbWkn6WXyc8diisvPfhdp0tf+URva9pShRl"
        "pti3+Hb27cl/PlJHXmp6rfa1eVL3Uryvd3NT51WtNyk/Dn2eBN49mq+uw4qTTT17uc9BWi/HHSJZVJR4qVhCd3Pl3Lhj/WlF+w7x"
        "6YN8Xmxds0bzTnS+G3FzGjT85HiSWHKTx7Me0+dNidIep9H1xd3Gl2lhXq3UIwlK6hOXCk28R4ZR688+vqR5t99Jms9ISs46rRsq"
        "ELPjcI2sJxTcsZb4pSz81Y9oiejVg1dMWnmlZ+1LkH74Te3/AJmn/wBG/wCp2R0L9KGrb41DUrDWpWzrUaUK1DzVPg9HLU89/NwP"
        "mtHvtm7w1DY+srVtMhb1K6pypOFeLcJRl3pNPsT6+wkS1afXZK5Im9pmHaPlLaL5vUNI1qEOValO1qSXfF8UfepS9x0oc33p0u63"
        "vvSYaZqljpVOlCtGvGdvTqRnGSTXW5tYxJ9hwhCe7VrMlMmWb07S0KZlCiPK0hMoQjSEzkUwNZFMyKA0JlCEaQmUOQE0mYyIRogT"
        "HICIZLIRoTOSIjRBkgNFkCyEayQEEaIMlkg0QEEJAQHXokRtdhEIBADEGRYeOR4/wo+s8kjx/hL1mUd4bsfzQ9K3zZZMt82EnyOg"
        "7SnLsRzzo16O5bjrR1TU6co6ZTl6MHydxJdi/wBldr9nfj1nRxtCnu7W3TuZONnbRVWsk8OfPCiu7Pf3I+gP8l0yz/8ACtrW3h4R"
        "hTgl9SSPDqtRw/Yr3fNeu+rzg/42H557z4+n4i5ubXSrKdevOnb2tvDMpPlGEV/+6joHf2+rneN+qVBTp6dRlihR7Zvq45eL7F2e"
        "/P6ekXpBq7runY2Mp09Loy9FdTryX4T8O5e3r6uL2FGpb6vb0q0JU6kLiMZQksOLUsNNd5dJpuGYtfvJ6L6P8PX4jPH2/aPH/buX"
        "o36PobcoR1LUacZanVjyi+at4vsX+0+1+zvzdMv3p0vyuH6MznZwPpm+9Kl+Vw/Rmfe6jBTDpLUpHTZp0+a2XVVvfvu6/wCjveMt"
        "r6t5u4m/i+6ajWX0H2TXq7fD1I77jKM4qUWpRaymnyaPlbJ2/wBEm8/hlutv31T7vRjm1lJ/PguuHrXZ4eo5npGt4Z5F56T2/R0P"
        "VdHvHOp39/1co3ztOnuvRpUYqMbyjmdtUfZLti/B9XufYdG6HRqW+5tPo1oSp1Kd7ShOElhxamk0z6VOvN9bM4tf03cVjT5q7oq7"
        "hFda40lU/ufsfeez1PRccxmp3jv9P+nl9O1fBE4b9p7fV2GdedNf3uWX5Yv0JnYZ1502fe5Zfli/Qmev1H7tf6PLoPvFPq6ayWTO"
        "SyfFvr2k+aORwONJ80clpnn1HaHi1vyw88DzRPDA80TyuTZtG0ZRpEapKFEhCISIBEBCIiECEiDEiAgQgIRCQgREIRCAgQkIRERE"
        "QoUAgaQoyhQGkKZkchGyyZHIGsijKFAaQoyjQQoQFAIpmcjkI0mOTKFAIoBQQjkyIGslkMkRGslkBCEcmRyA5LICRCJnI5KhLIZI"
        "g0QCEJAQHX5EKNrsIhAgDLNAwsPFI8b616zyyPG+tessd27H80PQt82D6gb5ssnQdvZ7vaO7LzaGqfDrWEKsZx83VozeFOOc9fY+"
        "XWe23l0m6lu23VnGjGxssqU6UJuTqPs4pYWV4Y/uOGnefk+7K0DWtJuda1LTqV3e2166dGVVuUYJQi16GeFvLfNpnP8AUNTi0mOd"
        "Tkrvs14vSsOp1MZOGOPy8nQn0RuLobp3BbNPlOxtai6u6rJfor29x1Vrj/z91D+Van9sz7JPjTW3/n9f/wAq1P7ZnE/h7X5dZq8m"
        "XJ4jaPEbuz6lp64cNaV/F9HHAumf70qX5ZD9GZz04F00fejS/LIfozP2HX/d7/R+c6H7xT6ukMnmtLuvY3NK6tqkqVajJThOPXFr"
        "qPBksnxMTMdYfYTG/SX0hs3dNDdmi07yHDC4h6FxSX4E/wDB9a/6HvOs+c9kbsrbS1qF16UrWriFzSX4UO9eK617V2n0RbXFG8t6"
        "dxb1I1KNWKnCcXylFrKZ9j6drPiMf2vmjv8Aq+U9Q0k4MnT5Z7fo8p1302/e3Zfli/QmdiHXXTd97dl+WL9CZs9R+7X+jXoPvFPq"
        "6YyWQyWT4p9hs0nzRyan1I4unzRyil1I8+ftDw675YeeB5onigeaJ5nIs2us0jKNEa5aQghCEQEISIgISEIhAQhIiAhRCEQgIEJE"
        "EJEIEJEREICEIgIEJEEQpkQDk0mZEI0KMiBpDkzkUwjWSyCIDSEyKCNCjIgaEzkskRoTORyEIgQGiAshGhM5EBEzkQhyJkSBECyE"
        "ImcjkISAgOAiSE2OyiIgMgzQMLDxSPHI8sjxyRY7tuOdphxxvmyyNePBWnF9kmYye7d3Wsn0d5NE4vaGpxyuJag214OnD/Bnzfk5"
        "j0b9JeodHeoValGjG7sbnCuLaUuHOOqUX2SXPwfua5XrOkvqtLbFj79J/J6tFmriyxa3Z9enxhrdaD3zf1VJebeqVJcXZjzr5nam"
        "5PKVdzplS30DSatrd1Y8Pwi5mn5rK64xXW+5v3M6NlOU5OUm5Sk8tvrbOZ/Dfp2fSTfJmjbfbaHq9T1OPNEVpO76wOAdNUlHaVFN"
        "4bvIYXf6Mzj+3+mudpYQt9YsalzWpx4VXoySc0uriT7fH6ji2+N+3e8q9OMqStrKg26dFS4m39KT7X9h+oaz1PBk081pPWfZ8RpP"
        "Ts1M8TaOke7jGSyZyWT5d9G1k7R6IN6eYqrbl/V+51G3aTk/myfXD29a8c96OrMmoVJ0pxqU5OE4tSjKLw012o9Gl1NtPkjJV59T"
        "p658c0s+rzrjpwnFbdsYZXE7tNLvShL/ABR6zROm+NGxjS1jT6ta5gseeoSSVTxaeMP1fUcM3tva73lfQq1Kat7WimqNBPPDnrbf"
        "a3hHf13qeDJp5rSd5lxNF6fmpni142iHHclkzksnzD6NpPmjldL5qOLUIudaEV2yRyqmsJI0Z56Q8Gvn7MQ80DzRPFA80TzuRZtG"
        "kZiaRGuWke52vte+3Vfu0s+CEYR46tap82nHvfj3I9MjsHZebfo+3TcUm41ZRjTcl18OP2n7zG07R0astprXeO7xUujzR7+q7LTN"
        "32dzqCzw0nScYza7FLif1ZOHahp9zpV9Wsbum6dejJwnF9j/AMC0ytO31G1rU5OM4VoSi12NNHZW59Ls9Q6WbG1uqKq0bmlF1YNt"
        "KWIy7v8AdRN5rPVqm00ttad423/J1aR2Dqmp7R2trV1ptLbcNRjCrJVq1arzhl54IJp8o5xnlnHtPwbt2haW+p6RU0SUvgWtcPwe"
        "M235uTcVjvx6Uevn1li7KuaJmN423cOE7UvdI0za9aGmWuyb7XFGK8/eypTfE2ufA1Fr3Y7vE9DubaNlo+49GdtSrR0/U505K3rp"
        "qdP0o8UHnn1SXXzJF4ljXPFpcKE7B3rDaO3bu+0y20WpVvZ01ir51qFvJwXDwrPPslz7zxaH8TWmiWk7La11uK+qJu5nKlPgpP6K"
        "9Fp93Lu9g4+m+xzt68WzgZHMt/7ftNPoaZqtlY1dOjfwl52zqJp0ZrHLnz7fq8T2F/b7e6P6NrZ3mjx1jVK1JVa7rT4YU0+xcmux"
        "9me3wHH4OdExExHd18e+3Rtf9zMrNfGFvefCqXnfuX4P+K58n24Z+vdVDbt1ptnq+iOFpVrScK+nupxSpvn6SXYuX1rqP2by25aW"
        "+o6FZaZbwoTvrempYbalOUsZefWOLrCczeY9u70m2dt1Nx3Van8Iha29vSdavcTWY04r/wDfU+49VWjThWnGlUdSmpNRm48PEux4"
        "7Dn2r3O19lXa0eOgw1avTjH4TcXFTD4mk8R5PHJrqx7T1W89v6daWen65o3HCw1CL+4zeXSmuzPv7+p8xFt5SuTeevaezignZG77"
        "bau0NTopaIr2tWpRl8HdaUKdOOWuLty31dywel3lomlQ0nTNf0ejO2tr7MZ28pcShJdzfqa9gi+5XNFtundxETz2FpU1C9t7Oljz"
        "lepGlHPfJpL7TnWtXG1tn3HxLHQYarWpxXwm4rVOGXE0ny5PHJrqxgs226MrX2naI3l1+RzfdmjaHbbQ0zU9IoSj8Krv7pUbc+F8"
        "T4H2ei1j2Hn034ms9Ls/i7ad1uCtOHFc150p8MZdqXote77THj6bsOb03iHAiOV7+0C10i4sbyyt6lpSv6PnXbVM5oy5Zjz5rrXL"
        "s5nutx2e2Nr09NuZ6QruvcW8WrfzrhTXfOT55bzhLq5MvF2ObG0bR3ddicw3RpGk3G3LLcmkW0rOFeq6Na2cuJRlz5pv/dfvXJH6"
        "9J+J7TSLSVhte61+6qRzc1ZUp8MJfRXotPu5dxOLoTl6bxDgpHLd9bfttPnpt7Y2lWzjqNNylaVM5ozXDlc+a+cuXgez1alt7YtK"
        "hptfSIavf1KaqV6lWfCo5+jyeOp9XvHF4TmxMRtHdxuG2uLak9f+FY4a/mPMeb6+rnxZ8e49Kdi6u9Nn0aTraVTqUbetdxm6M5cT"
        "pSyk457Vy5es9foK0i10a3qWu3LnX9QqN+fzSnwUu5LCaf8A/vgSLMYyTtMz5cLI5hvfQrW1sdP1i0sKum/C8xq2dRNebkvB812/"
        "UcQM4neN2ytuKN4QkRVQoBCEUAgJZIghyOTIog0JkQhHJkQNEBERoTIlQiZEgciAhEICAkAhEJCBEJBHARREbHaICQAZZoGCHjkj"
        "xyR5pI8ckGyJek1ah5uqqq+bPr8GfgyciuKEa9N05Lk/qPQXFCdtUcJr1PvPVjtvDr6fLx1294YyWQyWTN6DkshksgOSyGSyA5LI"
        "ZLIDkshksgOSyGSyA5LIZPLb287mooQT8X3Dcft0a3dW48616MPtOQwR+a0toW1JU4L1+J+uCPLktxS42qy8dunZ5Io8seoxFHlS"
        "MHhmWkaRlGkRraOZdH+uabbUdT0LWKvmLLU6agq/ZTmsrn3dfX2YRw0STG8bML1i0bS7Dsej/SdKvaWoajunTKlhRmqmKc1xVUnn"
        "GM/ZkNO1+G5ele0v6UXGg6jp0k+twjCSTfr5v2nXx7Ta+sU9A1601KrSlVhbycnCLw3mLX95jNZabYp2mZnednM9e2Zpmu7hv7u0"
        "3FYWsPhFT4VRuZcNSjJNqTSz6Sby0+XWfi3buiwoahoNpo9R3NtoXC1V7Ksk4/qLn4s4lrV/HVNYvr+EJQjc151VGXXFSk3j6z8Y"
        "ivkrinpxT2ds6vCvui7+NdA3srK0qxi6ttVvJ0nQaWHiKf8AhzzzOL6zeWkN1aVSo69e6rb21Wk6lxd1nOEZcS4nBvqjyT/veDh4"
        "iKbFcPD7uTdI13b328L64tbilcUZKnw1KU1KLxTinhrl1nM7m6r61omly23uax0m2t7dQr0KtbzUoSWObwm/fy7e06nITTpEFsW8"
        "RG/Z2RvO707XdqWcrbXre5udNco1FWnitcPKi5RT5vOMrwM63baf0jO01Oy1axsr+NFUri1u58HVl5i8c+t+zHUddCIpt2lIw7R0"
        "lyjdNjt/R9OtNNsKtO/1OMnK5vKU24Jc/QSzh9nu8T2m9dctoart2+srmhdOzt6U5KlUUsSjJPheOp8jgYl4V5fbeXYevaFpe89Q"
        "lrel69p1tGvGMrijd1OCdJpJN49nq8T1u9dX02Ol6Zt3Sbj4VQsE5VLhL0Zzfd75P2nDyJFUri223ns5j0pX1pqG4qNWzuqFzTVr"
        "CLnRqKcU+KXLK7R1q+tKvR1oVpTuqE7mlWm6lGNROcFmfNx611o4cJeHpEeCMcRER4fp029lpuoWt7CKlK3qwqqL7XFp4+o51r2l"
        "7e3fe/HVpuOzsJV4xdehdNRlFpYyllZfJcvrOvDldjq+zKVlQp3e3LmtcRpxVWormaU5Y5vHFyyyWj3hMkTvFo7vdbzjYU+j/Rae"
        "m1J1bSFzKEKklh1GuNSljsy037T2usXNxrNGzutvbpsdM0ynQjGdCdbzUqTXglnq5YeOrxOHbn3XY6rpVlpGladKysrWbqKM6nE2"
        "3n/F9vacYMYp0a64pmOv4uwN+3Wna7oenXllrFC4nZQdKdOrPFeq24ri4ev8HPtPwdIt9aX1TSHa3VC4VOyjCfmqilwy7njqZw8S"
        "xXZnXFw7dezmFzfWkujK0s1dUHdRvXN0VUXGo+nz4evHNHJdQua+sWGn1tu7msdLsaNCMKtCpW81Km134Werlh4XLxOqyE0ScW7s"
        "Led7YavoGm3dnrVC4r6ZmMoVp4rV5OUY8Sj1/g8XqZvW9P0zf8qOr2OsWdndeajC4trqfDw47e/t9T5dR10I4NuyRi222lz/AFar"
        "o1lsCrpNjqdG7rUrpcbUknUllNyjHOXHsz4HsXc1dW29pcNvbhstLhbUVC4o1avmpKSSy20m+vPg85OsBHAnK/F2Hum6sNZ2nQpU"
        "tet7m60+bdR1p4qXD6m4p82svl4HXpEWsbM6U4Y2JERkyKEBQRCQhEREQIgJUkkRECRCREIISoSIiCEhBKEiCEiIBIhQRCQhEREE"
        "cCQgJsdsgxJhADQkBhow0eVoy0GUS8Mon569vCvDgnHK+w/W4mHEsTs20vNZ3h6KvpNWDbpPjXc+s/HKjVg2pU5r2HJ3Ew4G2Mvl"
        "7qaz+qHGeGXc/cXDLufuOS8HgXB4F5sNnxlfDjXDLufuLhl3P3HJeAuDwHNg+Mr4ca4Zdz9xcMu5+45LwLuHgXcObB8ZXw4zwy7n"
        "7i4Zdz9xybza7kPm13Ic2D4yvhxjhl3P3G40Ks3iNObb8DkypruRqNNdw5v4MZ1tfD0lvo1ao06v3OPd2nubW0p20FGnHC+080YH"
        "kjE12vMvJm1Nr9O0GMTyxQRieSKMHjtLUUeRIykbRGqSjSBGkGJREe70fZev6/bfCtO06dahlx43OEE2uvHE1kkzEd2NrRHWZelI"
        "5T8l+7vxR+cUv1h+S/d34p/OKX6xOOvlhzqf1R+biwnKfkw3d+Kfzil+sXyYbt/FP5xS/WHHXynNp/VH5uLico+TDdv4p/OKX6xf"
        "Jju38U/nFL9YcdfKc2n9Ufm4uRyn5Md2/in84pfrF8mO7fxT+cUv1hx18nNp/VDi4nKPky3Z+Kfzil+sXyZbs/FP5xS/WHHXynNp"
        "/VDjBHKPky3Z+Kfzil+sXyZ7s/FX5xS/WHHXyc2nmHGCOR3HR3ui1oTrVdKnwQXFLhq05PHqUm2cdLExPZa2i3aUJEVkSIiMUJIQ"
        "ISECIiCEiECEhCIQEIhAQhIhAhIgiEBIEiEqIQEghIkRiRASiIhIJCRIIRAQIiEIhIQJCAhEQkEcCEBNjtoiFBAWBwQADRrAYBuw"
        "0ZcTy4BxDLd4XEy4Hn4Q4QvE8HAXAebhLhC8Tw8A8B5uEuALxPDwDwHm4C4AnE8XAXAebgHhCcTxKBpQPIomlEJxMRibjE0om1EM"
        "JsIxNpEkaSIwmSkaQJGkGMpG0CQhEc62l0pVtsaPT0yemQu6dKUnTkq3m2k220/ReebZwYiTWJ6S13x1vG1nafy4/wDp/wDPP2B+"
        "XD/0/wDnn7B1WJhyq+Gn4XF4/wBu0/lw/iD88/YH5b/4g/PP2DqwRyq+D4XF4dpfLf8AxB+efsF8t38Qfnn7B1cQ5VfCfC4vDtH5"
        "bv4g/O/2B+W7+IPzv9g6uIcqvg+GxeHaPy2/xB+d/sD8tv8AEP53+wdXCOVXwnw2Lw7Q+Wz+Ifzv9gvls/iH87/YOrxHKr4Phsfh"
        "2Xc9NFapQnChosKVSUWozlccSi+/HCs+861ITKtYr2Z0x1p8sIQErNEQhEKIQISRBEICBCQhEJEAkRBCICEQkhCIiIgRAQiEiKEi"
        "IiEQEiEiIohREQIghCEiICEhCISIISIQiIiA4GREbHaQkIEiwSFBAWBwQQYLAjgLuzgMGywDdjhHhN4LAN2OEeE3gsA3Y4R4TeCw"
        "E3YUR4TeBSCbsKJpRNJDghuykaSFIUgx3SQohQTdI0kSQoIhIQiIiARAQhEBCIiEIhAQEiIISIQISRBCREQQkIRCRAJEQQkQgQkI"
        "RCAhERCEQkIEJEEQgJAkQlRCapOEasHUi5wUk5RTxldqOzbuz2LR2Xb7kjtm6SubmVrGl8OnmDUZPiz2/N6g24sPM36xGzrATlXR"
        "3tuw3DqV7U1TzsrHT7Opd1adKWJVOHHo57Ov6j2GtaNt3WNlVdy6Fp9fS52l2ratb1K7rRnFpYkm+eea+vwJstdPa1OPfz/ju4MJ"
        "2FS2Tpd50W0tat6U1rCjVuJS43idKnV4Z+jnCxGSfsPVb523ZaTrelWOm03Rjd2VvVlxTcs1Jtpvn7BsX01614p/CfzcSI7c/cfs"
        "yW657Hjp16r+NHPxn8If+k81x/M+bjH+HicT2Jtuw1671rSb2k53tOzq1LOcZtKNWHLqXXnK6+4bMraS8Wiu8dd4/vHs4ghOVWeg"
        "6fT6Ob7Xryk5XlS9haWcuNpRwlKTwuT5cS59x+7ox2xpGuVdQu9dpznY2yo0klNw+6VaijF5TXj7xs1109rWrWPeN3CBPY7j0p6J"
        "r+oaa00ravOnHPbFP0X7VhnriNNqzWZiURy3o00LTtf1y5t9TtpXNCjZVK6pxqODcouOOa9bP3axoGh3uyq24bDTLvRa9vcxofB6"
        "9Z1IV08fNcknlZz7GXZurp7WpxxPn/HdwVCc20HRtA0zZj3NrthX1N1rz4JRtqdd0ox9FtybXPsfuR+fe+gaXt/V9LubKlWlpl/b"
        "UrxW85+nGLfOHF6u3xGyTp7RTjmY9v8ALiQnZlG12NW2hX3Its3ShRu1aOh8Onlvhi+LP/EddXtS3q3lepaUZULeVSUqVKUuJwhn"
        "lFvtwu0TDHNh5cRPFE7+N/0eASIjQiEgOBEQmx2kKAQEQQhERCEGBwKIIBEsAA4HBYCLBYHA4AMCiwOCIBwKRYAsCkKQpBBgsCIA"
        "kKIQhJEhAhIgiEBQQiAhEJEBCAhCICBCAhEJEgEQEiIiEIhIQIQEIhAQISEIhIgEiIIhRCEQkhCIiIgSIQiEiKN0qcq1WFKCzObU"
        "YrvbO3dR6P8Acr6LbHR1pv8Al1vqE7mrS8/T9Gnwz9LPFh9a5J5OoCJEt2HLWkTxRvvG3fb/APJc96Iq1Gep6vpk61OlX1HTattb"
        "+ceFKo8Yj9vuPYapo13szotu9K1pU7e/v9QjUo26qRnJwio5l6Lax6P1rvOs02mmuTR7+93bX1PbFtod9bwuJ2dVzt7uUn5ynF9c"
        "PFf9O4sS2Y89YxzWe8RO393PNA1WnpO1tjzuMO1uLm8tLiL6nTqTcXnwWU/Yes6WYR0reukwqSco2tlbKUl2qMpc/qOuSG5fVzbH"
        "wbeP8Rs74WhXEOk+pvh1bb9zztvPfDfPR4ceYVPGM561nqx7eR1hsfWlpu/rC/TcaVS6cJZ+jUbjz9XFn2HGvPVfNea85Pzec8HE"
        "8e4wJlMmq4rRasbbTv8A3nb9HZPS1Qpbes9I2xbSXBRlXvJpdvnKkuD3LKP0aFV0fbnRlbVNap30o6vfOtBWjjGpim0ov0uxOOfa"
        "jq9CTdPiv/pN4r3jaPw/cOd9L1CjW1+01u1i/g+r2VK5i334xj14UfecFIhLRmycy83223c/6FlVe6bxUP8ATfF1bzfV87MMdfie"
        "53THV/3AXsd8Tt3q0LiD05cdN1sNri+Zy4cZ/wD2DqgRv0bqarhxcvbz79Ov4fh7OxtF0q53f0Xx0fSFTr6hZ6n8IqW7qRhJwcGs"
        "riaWPS+pn5OlapSpXujaWqtOrcadptK3uOB5Uai64+vt9pwelVqUZcVOcoS6sxeGDbbbbbb62N2N9TE4+Dbr0j8nOrL+Bm//AJZX"
        "9nTOCkQacmTj4enaNiRCiNSIiCOBCRI2O2RAQhIiCIUQgQgIRCRAJIhCISICEBRGKFEIEJIgISIIURCgISEIiIgEUCEISIQiIiCE"
        "QEBIiCEiECEEICREREJCEQkQCREEJEIEJCEQgIREQhEJCBCAhEICQQkJUREJBCAkQkQlREREChAUEIgIERCEQgKARQCEQgIRCRAK"
        "IiCOBCCE2O2UIIQiIhCIUCEJJIhAiIQiQkiASIiJJIhCJCRAJEIEKBCEQkhQEJEEQoBCEkSEIhIgISIISIQIQEIhIgEQEIiISIkJ"
        "EAiAhERCBCRBCICAkRBEJCgiEDQJREQQkQoghASohIiISIUREJEUQgKIEQFBCREBCRBCICAoiEMURCgIQQhCRIgP/9k="
    ),
    "stopwin": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHAABAQEAAgMBAAAAAAAAAAAAAQACBgcDBQgE/8QAVxAAAgEDAgIFBwUIDQkJ"
        "AQEAAAECAwQRBQYSIQcTMUFRCBQiYXGBkRdSobGyFTI2QlV0pNIWGCMzN2JmcnWUs8HiJFNWZXOTwtHhJSY0Q4KSouPw0/H/xAAb"
        "AQEBAAMBAQEAAAAAAAAAAAAAAQIDBQQGB//EADQRAQACAQIEAwQJBAMAAAAAAAABAgMEERIhMVEFE0EUMmFxIjRSgZGhsdHwBjPB"
        "4SMkQv/aAAwDAQACEQMRAD8A6KQkiMXzxIiKEUCEjEkRAIoEJEKIkIREQgSEkIRIQEIhAUAkQhEICESEkQCREiIUICioSIiISIUE"
        "QkIERCgISII0jSMo0ghRpAhQCjSMo0ghRpGUaQCaQGkAo0jJpEQo0jKNIoUaRlCiDSEEaQQo0jJpAKNIyhQGkKBCgjQoEKAUaQIU"
        "BpCgQoI0hBCgNIUZRpAKNIyhA0OTORyAkAhERAEQgJEBEQRERBERERiiIgjqwQE2u2hBCgklCAkRCAoqIUQoghIgiFEKCIUSIISI"
        "gEUCEIhIgEkQhEICEQghIhQghCIQECEkIRCRAQkQQiAhGkKBCgNIUCFBGkKBCgNIUCFAaRpGUaQQmjJpECaRlCgNI0jKFBGkaRlC"
        "gNI0jKFBGkKAQNIUZRpAaQoyjSCNIUZRpAaQoyjSAUaRlCBpCZQoDSY5MoQjSY5MocgayWQyWQhyQCERERERAIRERERERBEREEdW"
        "kRI3O2UIISMSiIiBJEJUSEkJElEQoCQgKCFCAhEICgFEQhEICElCRAJEREIoBRUJEREJEhQRCQgREQCKAQhEBCJGkZRpBCjSMo0g"
        "NIUCNIBRpGUaQQo0ZRpEChQIUBpCgRpBCjSMoUEaQgKA0hMo0gFGkZRpBCjSMo0gFGkZQgbQoyhyBpCZQgaQmUaQQpmkZQgaQmRC"
        "EcmRIHIgRUIhkskQkAhEIEEREREQgQRERBHVwoBNztlCAmKIQEqJCiLJAlkBCLI5AgNCjKEI0QIshChAgNCZTFMIRTDIphCmOQyQ"
        "RpCjIpkRpCCEEoiFBEJIQiQkQEKAQhEBQQkRAlGkAoI0hQIUBpGkZQoiNIUCFAaQoEKCNCjKNIDQoyjSCNCjKNAKFAhQGkaRlCgj"
        "SNIyKA0hRkUBsUZQoDSEyhQRpCmCFAaQoyhA0hM5HIRrJZM5NZCEUZyOQNFkMkRGiAghEMkEJAREJEQRCBBEREB1ghQCja7RIiIE"
        "iIqIQIBLIZLJDY5HJjIrL7E2UiN2slkOCfzJfAeCp8yXwLwz2ZcE9jkshwT+ZP4FwVPmS+A4Z7JwT2ayOTPBU+ZL4Fwz+ZL4Dhns"
        "cE9msimZ4Z/Ml8B4Z/Nl8Bwz2Tgns0mOTPDP5svgWWu3KJMTCTSY9G8mkzxpmkyMJhtCjKYoMWkaMoSMSJIUBIUSEIiIgEQEIRBC"
        "EREKCISEBQoyaQRoTKFEGkaRlGkEKNIyhQGkaRlCgjSFAhQGkKMo0gjSFGUaQGkJlCgNIUZNIBNIyhQRpCgQoDSFGUKA0JkchGhM"
        "pimEaTFMyhA0OTORyRDkcmRQDkQHIQkGSCNFkCCEQLJEJAQQkGSASIgjrIQQm120RCEAgiAiIGwqyTaUeKT4YrvDMUnKbxGPafjr"
        "VpVpZfJLsXckb8OHi5z0enBg4uc9HnneY5UopeuXNnhlXqSfOpJ+88eSye6KxHKHvisRyhrjl85/EuOXzn8TOSyVdmuOXzn8S45f"
        "OfxM5LINmuOXzn8S45fOfxM5LINmuOXzn8S45fOfxM5LINmuOXzn8TUa9SLyqkl7zx5LINn66d+1yqxUl4rkz9lOpGcVKLyvE9Rk"
        "3RryoT4o9nevE05MNbdOrRl09bx2l7hM0jw06kakVOLzFnlTOfasxO0uTek1naW0aMI2jFrko0jJpBiRIgIQEIRBCEJEQJQkIRCR"
        "BCSIiDSFGTSCNIUZRpBGkKMoUBpGkZQoI0jSMoUBpGkZQgaEyhQGkKAUEaQoyjQCaRlCmBpCmZFBGhTMigNZFMEKCFCBERoTORKN"
        "CZQkQoQRZA0QERGslkBCEgyWQhECCHJAWQEQIISAgjrUiI2O4hIioCIgB8jLYsFzlFeLEM4jd4LyphxpLsXN+1n5sjWnx1Zy8ZMx"
        "k6lY2jaHWrXhjaGslkzk5b0d9Hl70gahWpUa8LW0tuF168ouTWc4UV3t4feuw1Z9RjwY5y5Z2rDbjx2yWitY3mXFMlk7p3F5Oztt"
        "NnX0PVatxc048ToXEElUx2qLj2PwWH7TpR5TafJo0aLxHBrKzbBbfbq2Z9NkwztkhrJZOx9A6IZXun07nVL2pb1KsVKNGlFNwTXL"
        "ib7/AFfScc3lse82lUhUlUVzZ1XwwrqPDiXzZLuf1nYyaLNSnmWryc6msw3v5dbc3G8lkzksnkeprJZM5LtA1ksnZejdDrr2MK2q"
        "X1ShXqR4uppRT6v1Nvtfj9ZxLeOz7raN7Tp1Kir29ZN0ayWM47U13NZXxPXl0WbHTzL15PLj1mHJfgrPN6HJZM5LJ5Hqft0+tibp"
        "PslzXtPYxZ6SjPgrQku6SPcrk8Hj1NecS5+tpzizyxZtHjizyRPI50toUZRtBgTdChVua1OhQpTq1aklCFOEXKUpPkkku1swdseT"
        "TpFvqXSHO5rwjN2FlUr0k+6blGCePZOX0BsxY/MvFO73uzfJhvb+2p3e6dSlp/Gs+Z2yUqsf5036KfqSftOU1fJa2o6bVHV9bhUx"
        "ylOdKSz7FBfWe46eOkTVdhaFYx0bgp3eoVJwVxKCl1MYpN4T5cT4ljPg+R0Vp3Tt0gWF1Gu9dldRTzKjcUYShP1PCTXuaMuUOlk9"
        "lw28u1d5fo6Rug/Xdg28tRp1YappUWlK5pR4ZUsvC44ZeF602vYfl6JOjWh0lalf2dfUalirWjGqpQpqfFmWMc2j6n2xrNrvzZtn"
        "qVa1iqGp22K1vJ8UVnMZx9aymj5S07dWs9Em7ddtNDnR4qdxVs5SuKfHxRhUaT9vITDVn0+LFet//Eu1f2qun/6T3X9Vj+sX7VXT"
        "/wDSe6/qsf1jg/7ZDfn+d03+q/8AU+otYuqllpF7dUsKpRt6lSGVlZUW19QjZ6MGPS5t5rXp/O7pb9qtp/8ApPdf1WP6x1P0p7Dp"
        "dHe5KWkUb6pexnawuOsnTUGm5SWMJv5v0nIP2x++/wDO6b/Vv+p6yxv9T6Z+kfRqGuSpOddxoVHQhwfuMOKcsevHFzJyeLNOnvEV"
        "w1+lMv0dHnQjr2/KENQnUhpelSfo3NaLlKr48EOWV620vadp2/kvbYjSSudZ1mpUxzlTlSgs+xwf1nZG6dw6dsHalxqdWlGFrY0l"
        "CjQp+ipPlGFOPhzwvUvYfNGq+UFv3ULyda21Klp9FyzChQt6coxXcszi2/ey8oem+PTaaIrkjeXNtxeS7wUJVdu65KdWKyqF9Ben"
        "/wCuPZ/7fejo/WNF1Db+pV9N1S1qWt3QfDOlNc16/Bp9zXJn0J0M9N1/uvVo7e3H1MryrGUra6px4OtaWXCUVyzjLTWOzB5PKW2p"
        "QvduW25KVNRu7CrGjVml9/Rm8JP2Sxj+cybR1hqz6bFkxTmwctvR010W7EpdIe46mkVr6dlGFtO46yFNTbalFYw2vnfQdsftWbD/"
        "AEnuv6rH9Y4h5NH8IVx/R1X7dM7b6bt96xsLRNPvNGlQjVuLl0p9dT41w8Lf1osRGy6XDh8icuWN9nE5eS1Y8L4dz3Kfc3aRa+0c"
        "E350F7g2XaVNRoVaeradSWalajBwqUl86UMvC9abx34P0UPKQ3vTqxnUWl1oJ84St2lJeGVJM+h9lbotd97UtNZhbqnC6hKNWhP0"
        "lCSbjKPrWU/amhtEs8eHSajeuONpfFKE5B0haFS21vbWNKoR4aFC5l1UfmwliUV7lJHH0YONes1tNZ9HYHRP0aWvSPW1KjX1OrYz"
        "s405RUKSnxqTkn2tYxhfEx0q9G1Po4vrC3o39S9p3dKU+OdNQ4XFpNcm/FHIPJpvnQ3te2jfo3FhJpeMozg19Dkcl8qGz4rHQL1L"
        "97q16Tf85Qa+yzLbk6FcGO2knJEfSj93W/RX0dx6RdVvLSrfTsqVrQVV1IU1NuTkklhtd2fgdmftYbD/AEluf6rH9Yx5L9hw2Wva"
        "g1++VKNCL8OFSk/tI5toW4Hc9L25tI6xuNGwtWo55Jxy3j/fIREPTpdNhnFS2Su82n9/2fN+/wDaf7Cd1XeiK4lc06KpyhWlHhc1"
        "KCl2e1te45X0W9EFHpC0e71GvqlWyVC46iMYUVPi9FSb5tfOR+zykrB2+9bO7SxG5sY5fjKM5J/Q4nZPk9WitujqnVSx5zd1qr9e"
        "MQ/4BEc3nw6ak6q2O0co3dE9JGzbfYu5PuPb3071RoQqyqTgoNOWeWE33JfE7K0rycLTUdLs717jr03cUIVnFWqfDxRTx996zgHT"
        "Peu+6S9annMadSFFerhpxi/pTPqPbH4NaT+ZUfsIREbtmk0+LJmyVmOUdHxa6fDWdPPZLhz7zvv9rNY/6SXP9Wj+sdDz/wDGS/2j"
        "+s+z90VJ0dtatUpzlCcLKtKMovDi1B4afiKw1+HYMeSLzkjfbb/LpLdvQBR27tvUNWttar3VWzpOt1UqCipJffc0/DL9x1dtjSI7"
        "g3Dp2kzrOjG8uIUXUUcuPE8ZwfV+2rqnu/YVjVrvjWoWCp1n25k4cM/pyfM2wbapZdJOjWtZYq0NShTmvCSnh/UJg1mnx1vjmkcr"
        "Obb46DLXaO1r7W6Wt17mdqoNUpUFFS4pxj25/jHUSPq3po/gz1v+bS/toHyiiWjZq8Sw0xZIrSNo2/doUZRpEc4pmkZFAaEySZEa"
        "HJlMUwNIcgmWQjSY5M5HIQ5HJkchGiDIgI5MkRGiAshGslkCARAghIBCIiII62IhNrupERERAIMpDLMw/fYfzkLMw/fIfzkWvVtp"
        "1h65vmyyZb5ssnT3ddrJ9CeTjTgtqalUUVxyv3Fy72lThhfS/ifPOT6I8nD8EdR/pCX9nA+e/qef+hb5x+ro+F/WI+92wfHetUac"
        "d6X1BQSpLUqkOHu4etawfX15eW+n2tW7u61Ohb0YOdSpN4jCK7W2fF24NTjf7g1G+tJzVKtd1a1KXZLDm2n6nzON/R28ZMltuXJ7"
        "PGudax8300fi1jSbbXNNr6fdx4qVaOHjti+5r1p8ziPRht7XKFt91dc1LUJ9dHNGzq1pNRT/AB5Jvtfcvj6uezSWPE/WMHj+DUZo"
        "03DP0uXwfkuTUUxajyqW329Y7vmvXdGudv6pX067Xp0nykuyce6S9TPwZO8ukbaC3LpfnFrTT1C1TlTx21I98P716/adFvKbTTTX"
        "cc7XaWdPk4fSej7HRaqM+Pf1jq1k/doMY1Nc06E0nGV1STT71xo9fk/ft5/9v6b+dUvto8uP34enJ7svpQ6+6Z4x+4FlNpcSukk/"
        "BOEs/UjsE6+6aPwds/ztfYmfX+IfV7/J8poPrFPm6fyWTOSyfG7vrmk+aPeJ+k/aehT5o94n6T9p5tT0h49b7sPNFnlieGJ5Ynic"
        "qW0bRhGw1k5p0R74p7A3lQ1S5hKVlWpytbrgWZKnJp8SXqlGLx4JnCzm/Rt0V6j0lx1B6ff2dp5i6fGq/FmXHxYxhP5jENmHj448"
        "vq+q9W0Xa/Sdt2lC6jQ1XTazVWjVpVGuGXZxRlF5TXNNe1Ndx1XrXkr6fU4p6LuG5oPOVTvKSqL2cUeHHwZ1rubRd29B+sW1tabg"
        "nSqXVHr+KznJU5ek1iUZLDfLvT7T3WheUvvDT5046nRsNVor7/jp9VUl7JQ5J/8ApZlvHq6V9RhvPDnptLGvWfS10UafTs1qF3T0"
        "e3zGlXs2p0Iptvm8Zjzb++S7Tq+/vrnVL2vfXlaVe5uJupVqS7Zyby2z7W2buzS+kfa8dTt7d+bV+OhXtriKlwyXKUJdzWH70/cf"
        "JXSbtyhtPfesaRaxcbajWUqMX+LCcVOK9ylj3EmHn1mDgrF623rLi5937j/B3VPzOt9hnwifd24/wd1T8zrfYZatvhnS/wB3+Xwk"
        "jsfyfYKXSlpjay40q7XqfVSX951ydi+T/VjT6U9KjJ86lOvFe3qZv+4xhz9N/er84dx+UpOUOjqCi8Kd/RT9a4Zv60j5YPqrykLe"
        "dbo3c4LKo3tGcvUvSj9ckfKpbdXp8T/vfc5d0STlT6SdvOLw3dxXuaaZ9I9O0FPoq1zPcqDX+/pnzj0QUJ3HSXt+FNZaulP3Ri5P"
        "6Ez6N6d6ip9FWt57ZdRFf7+mWOjdovq2T7/0dN+TR/CFcf0dV+3TO1OnnZuu700HTbXQbHzytQunUqR62FPhjwNZzOSXazqzyaP4"
        "Qrj+jqv26Z3v0g9Ien9HWn2t7qNrdXMLmr1MY26jlPDeXxNcuQjo2aStLaSYvO0PnS06AOkG4rxp1dHo2sH21at3ScY+3glJ/QfS"
        "XR/tOGxdpWWiu4jXnQUp1qyWFKcm5Sx6lnC9SOvZ+U/txQbp6Lq8pdyl1aXx4mdf7/6fNZ3fY1NM061WkWFXMavBU46taPzXLCwn"
        "3pL1ZwOUMceTS6be9J3lxPpJ12huTfes6nbS46FW4cacvnRglBP2NRT95xtGRRg417Ta02n1c+6Db7zHpO0jniNbraMvXxU5Y+nB"
        "3D5SVn5xsO3rpc7a/pyb9ThOP1tHz9sS++5u9NCu84VO/oOX83jSf0ZPpzpys3edGOsJLMqXVVV7qsc/Rkyjo6mj+lpclf50/wBP"
        "WeTrYK06O418c7y8q1s+OMQ/4DhmxtfVfyhtXnxejeVLq0i/FQ5r6KSO0+i+3hovRlofGuGEbJXMvZPNRv8A+R81dHusTo9Jejal"
        "VeJVtQipvw6yXC/tMs+jbmt5VcFfl/PzdpeU9YcVroOoJfeTrUJPx4lGS+zI7B6H7NWPRroVLGOKg6v/AL5yn/xHofKKsPO+j3zj"
        "HO0vKVXPqfFD/jRy/Q0tv7BsM8lY6XTbz/EpJv6h6vVSnDqr3+Efz8nyVu69+6O69ZvM5Ve+r1E/U5tr6D7C2x+DWk/mVH7CPiZy"
        "cm5SbbfNt959s7X/AAa0n8yo/YRKvF4TbiveXxfP/wAZL/aP6z7O3Z+C2s/mNf8As5HxhN/5ZL/aP6z7P3Z+C2s/mNf+zkKp4X7u"
        "T7v8uC+Tzq3n+xJWUn6VhdTppfxZYmn8ZS+B19q2k/cfygreko8NOvqdG6h6+sak/wD5OS9x+zyatX6jXtV0qUsK6to14p/Opyx9"
        "U38DlHSZpPVdK+yNWjHlcV4W82vGFRSX0TfwHozj/l0uO32Zj9dnJ+mj+DPW/wCbS/toHyij6t6aP4Mtb/m0v7aB8oi3V5/F/wC9"
        "Hy/zLSYpmcimYOS0OTIpgayKMoUEaQoyIRrJGRA0hRlCEaQmSyRGslkCA0mOTOSCNZIByAkGSyEayWQIIRDJZCEgII64FERtd0ki"
        "IgAYgwQxIxD98h7UbkYj++R9qMq9W7H1h6xvmwyDfNhk6LrNZPofydKtOjszVKtWcadOF9OUpyeFFKlDLb7kfO2T3FHeWo2e06+2"
        "bSfU2lzcu4uJxfpVVwxSh6o+jl+PLw58zxfRW1mDyaztvMfg9Wjzxhycc9nMOmHpYqbxupaPpNWUNFoT5yXJ3c1+M/4q7l733Y8v"
        "Rd0cecOlr2s0f3JYna2819/4TkvDwXf29mM/l6MOjj7rTp63q9L/ACGLzQoSX7+1+M1836/Z29v6lqNpo9hVvb2tGhb0Y8UpPu9S"
        "8X3JGiK49LjjTaeOUfz8Xx/9Q+O3y3nT4Z3tPKZj9I/n5vHrWtWW39Oq6hf1VToUl75Puil3tnXWwt36ju7fV5dV26dpGznGlQT9"
        "GkuOGPbJ88v+5HCN4bt1Dfms06dGnVVup8Fpax5vL5ZaXbJ/R2HK73Qbjo32daX1KcVqsr6lVrTXNLEJ/ufrWG0/HL9R3PB9JOK/"
        "tFo93nP7NWj8KrpcW2X+7flHw/nrLto6e6Vtnfc66eu2VPFtcSxcRiuVOo/xvZL6/adnbd1623JpNDUbV4jUWJwzl05rti/Z9WGf"
        "svbKhqNpWtLqmqtCtFwnB96Z9lqcFNVh2j5xLXp819Nl3n5TD5hyew28/wDt/TPzul9tH6N27buNrazVsauZUn6dCq//ADIPsft7"
        "n60fl26/+8GmfndL7aPkYpamWK26xL6qbxfHNq9Jh9LnX3TT+Dtl+eL7EzsE696avwcsvzxfYmfW+IfVr/J8toPrFPm6cyWTOSyf"
        "GPrm0+aPer75+09AnzR76Pa/aefUdIePWe7DzRPLE8UDyxPG5Vm0bMo0Gso7V8nnetrtXd9Wy1CtChZ6rTjR62fJQqxeYZfcnmS9"
        "rR1WhQZ4sk47xePR9kdK3RZadJenW8fOfMtQs3J0Ljg4k0+2Ellcm0ufdj2nTUPJf3e7lQnqWiRo551VVqN49UeDt9Wfeem2b097"
        "t2la0rGpOhqtlSWIU7tNzhHwjNPOPbk5dLyqtQcMR2xaqfi7qTXw4TLlLo3y6TNPHfeJdy7M2tpvRrtGnpsbtOhbRnXubqtiClJ8"
        "5TfdFcvckj5I6RtyU93b31fWqKfUXFbFLPa6cIqEX6sqKePWew3x0ubo37DzfUbqFvYp580tU4U2+7i5ty97wcMRJl5tXqq5IjHj"
        "jasI+7txfg7qf5pW+wz4SO2b3ylN3X9lXtKunaCqdenKlJxo1cpSWHj917eYiV0Wopii0X9f9upz2+09wVdq7k07WqMeOVnXjUcM"
        "4449ko++La956gSPBEzE7w+4JLROkTabSlG80rVKGMrk8P6pRa9zXqOjNY8l7W6d5L7jazp9e0cvRd3x06kY+vhjJP3Y9h1xs3pG"
        "3JsSrJ6NfuNCcuKpa1Y8dGo/XF9j9aafrOy7bypdWjSSuduWNWpjnKnXnCOfY1L6zLeJ6utbU6bPEedG0w5/0V9Ctp0f3EtUvbuN"
        "/qsoOnGUY4p0Ivt4c82348uXLHbniXlKb5tpW1vtCzqqdfrI3F64v7xJehB+t54n4Yj4nE9xeUdu7WKE7fT6dnpFOaw6lCLnV9fp"
        "S5L3JP1nVtatVuKs61apOrVqScpznJuUm+1tvtZJn0hqz6vHGPycEcna3k0fwhXH9HVft0znPlQ/gxo/56/7NnR+xt76jsDWZ6tp"
        "dG0rV50ZUHG5jKUOFuLbxGUXn0V3ntt+dLeudIdhbWWq2mm0adtV66Dtac4tvDXPinLlzETya6amkaacU9ZcJEiMXOQoiCN0as6F"
        "WFWm+GcJKUX4NH2numxqbr2LqNraRjKrqFhLqIt4TnKGYrPdzwfFR2npflE7s0nTLTT6VjotSnaUYUIzq0arnJRiopyxUSzy54SL"
        "E7OhodRTFFq5Oku993yW2+jLU4Qai7TSpUINdz6vgj9OD5Asbqdje293T+/oVI1I+2LTX1HPd1dOu5t3aDdaJe2ek0be6UVOdvSq"
        "RnhSUsJubXavDsOukJndNfqa5bVnH0iH2bv3Q57x2PqGmWnDKpeUoSo8TSTalGa5+48fSZcx0vo512cHwxVjOjH1cS4F9o6K0/yi"
        "926dYW1lTsdFqQt6UKUZ1KNVykopLLxUSzy8D8G7OnDcm8dBudEv7PSqNtcuHHK3pVIz9GSksNza7Uu4y4oe/J4jhmtpjfeY2/X9"
        "3X6Z9tbX/BnSPzKj9hHxIjtOw8onden2NvZUtP0SVO3pRpRcqNVtqKSWf3Tt5GNZ2eHw/U0wTab+rrWf/jJf7R/WfaG7PwW1n8xr"
        "/wBnI+K3UbqOpyy3xHZ+oeUNurU7C5sa2n6JGlc0p0ZuFGqpJSTTxmp28xE7Gh1VMMXi/r/t6Dok1f7jdIei15S4YVa3m0/BqonB"
        "Z97T9x9L7w2/V1uroVxb01Orp2qUbp80v3NZU+31PPuPjy2uKlpcUrijLhqUpqcJeDTymdqftkt2/k7Qv9zV/wD6FiV0Orx48dse"
        "V2300/wZa3/Npf20D5QOwNz9N+492aFdaLfWWk07e6UVOVClUU1wyUlhubXbFdx18iWndq8Q1FM2SLU6bNCmZQojntIUZEg0OTIp"
        "hGiAUEKFAmOQEcmcjkiHImciE3aLIZIDRAIQjkzkchDksgICIFkIckBBGiAgjroQQo2O8QEggMs0ZYWGJGI/fx9puRhffx9plXrD"
        "dj96HqG+bLJlvmwk+R0HXU5dyOedGvR3LcdaOqanTlHTKcvRg+TuJLuX8Vd793jj1nRxtCnu7W3TuZONnbRVWsk8OfPCivDPj4I+"
        "gP8AJdMs/wDyra1t4eqMKcEvoSR4dVqOH6Fer5rx3xecH/Ww+/PWe3y+Iubm10qynXrzp29rbwzKT5RhFf8A7sOgd/b6ud436pUF"
        "Onp1GWKFHvm+zjl633Lu+Of09IvSDV3XdOxsZTp6XRl6K7HXkvxn6vBe/t7OL2FGpb6vb0q0JU6kLiMZQksOLUsNNeJdJpuGYtfr"
        "J4L4P7PX2jPH0/SO3+3cvRv0fQ25QjqWo04y1OrHlF81bxfcv4z737vHN0y/gnS/O4fZmc7OB9M34JUvzuH2Zn3uowUw6S1KRy2a"
        "dPmtl1Vb367uv+jveMtr6t1dxN/c+6ajWXzH3TXs7/V7Ed9xlGcVKLUotZTT5NHytk7f6JN5+eW62/fVP3ejHNrKT+/gu2HtXd6v"
        "YczwjW8M+ReeU9P2dDxXR7x51Ovr+7lG+dp0916NKjFRjeUcztqj7pd8X6n2fB9x0bodGpb7m0+jWhKnUp3tKE4SWHFqaTTPpU68"
        "31szi1/TdxWNPmruiruEV2rjSVT+5+5+J7PE9FxzGanWOvy/08vh2r4InDfpPT5uwzrzpr/Byy/PF9iZ2GdedNn4OWX54vsTPX4j"
        "9Wv8nl0H1inzdNZLJnJZPi317SfNHIIdrOOp80cigefUdIePW+7DzQPNE8MDzRPI5Nm4mjMTSDXLSEkIYoSICEDQRCAhCREQKIhK"
        "iIhIiQkIREQhEICgEQECIhCFCgEIUaRkchGkxyZQgaQmUKCNIUZRogUJkQjQ5MimBrIoymOQjSY5M5EiNZIEQGhMjkIciZEDSIBC"
        "HI5M5EIciZHIQiGSyAiZEIRyBZCHJBkiI69QoEJtd8gIBADNGWFh45GPxl7TySPH+MvaWvVux9Yelb5sH2A3zZZOg7Gz3e0d2Xm0"
        "NU8+tYQqxnHq6tGbwpxznt7ny7T228uk3Ut226s40Y2NllSnShNydR93FLCyvVj+44ad5+T7srQNa0m51rUtOpXd7bXrp0ZVW5Rg"
        "lCLXoZ4W8t82mc/xDU4tJjnU5K77NeLwrDqdTGThjj7vJ0J9Ebi6G6dwWzT5TsbWouzwqyX2V7/A6q1x/wDf3UP6Vqf2zPsk+NNb"
        "f/f6/wD6Vqf2zOJ/T2vy6zV5MuTtG0do3dnxLT1w4a0r8X0ccC6Z/wAEqX55D7MznpwLpo/BGl+eQ+zM/Ydf9Xv8n5zofrFPm6Qy"
        "ea0u69jc0rq2qSpVqMlOE49sWuw8GSyfExMxzh9hMb8pfSGzd00N2aLTvIcMLiHoXFJfiT/5PtX/AEPedp857I3ZW2lrULr0pWtX"
        "ELmkvxoeK9a7V713n0RbXFG8t6dxb1I1KNWKnCcXylFrKZ9j4drPaMf0vejr+75TxDSTgycvdnp+zynXfTb+Ddl+eL7EzsQ666bv"
        "wbsvzxfYmbPEfq1/k16D6xT5umMlkMlk+KfYbNJ80cjgcaT5o5LTPPn6Q8Wt92HngeWJ4oHmieVybNxNIzE0g1S0hJCEREQQigEB"
        "IhCIUAkRCRBEJCEQkiAhAUEIgICREEQkIRCQhEREAoUAhCjWTIhGkyMiQaFMymaCFGjORyEaLJkQNCZQ5CETI5INCjKYoIRQZLIG"
        "skGRyEKEyOQjRZM5EI0QEBoshkshiciBZINEGSCOvxATa76AQAjLNAwQ8ckY717TySPHIsdW6k7TD0DfNlka8eCtOL7pMxk927tN"
        "ZPo7yaJxe0NTjlcS1Btr1OnD/kz5vycx6N+kvUOjvUKtSjRjd2NzhXFtKXDnHZKL7pLn6n8GuV4zpL6rS2xY+vKfwerRZq4ssWt0"
        "fXp8Ya3Wg9839VSXVvVKkuLux1r5nam5PKVdzplS30DSatrd1Y8PnFzNPqsrtjFdr8G/gzo2U5Tk5SblKTy2+1s5n9N+HZ9JN8ma"
        "Nt9toerxPU480RWk7vrA4B01SUdpUU3hu8hhePozOP7f6a52lhC31ixqXNanHhVejJJzS7OJPv8AX9BxbfG/bveVenGVJW1lQbdO"
        "ipcTb+dJ97+o/UNZ4ngyaea0nnPo+I0nh2ameJtHKPVxjJZM5LJ8u+jaydo9EG9Ooqrbl/V/c6jbtJyf3sn2w9/avXnxR1Zk1CpO"
        "lONSnJwnFqUZReGmu9Ho0uptp8kZKvPqdPXPjmln1edcdOE4rbtjDK4ndppeKUJf80es0TpvjRsY0tY0+rWuYLHXUJJKp62njD9n"
        "0HDN7b2u95X0KtSmre1opqjQTzw57W33t4R39d4ngyaea0neZcTReH5qZ4teNohx3JZM5LJ8w+jaT5o5RT7EcZoRc60Irvkjk9NY"
        "SNGeeUPBrp5RDzQPLE8UUeaJ5nJs0jSBGkGuWkcq2Vsmnu6lf1aupqwhZdW23R6ziUuL+MsY4fpOKo5/0eNx2jvJptNWkGmu70ap"
        "jeZiOTTntNab16/7cW3RoE9s65c6XOr13U8LjV4OHjTimnjL8fHuOU6L0V/dTQ7bUqusK2q3FCdxG3834nwRfbxcS8Y93ePSVby1"
        "qpt7WaEcz1S0hTaX+cTXL2+nj3HOKNeFHdFxo1FrqdM0NUkvCTcf+FRNc3naNnmvmtwRMTz9fudFITm2wtq2d9pd9r+o2VzqNK0m"
        "qdKyt4uUq1TCfNLnhcUfpz2HvIbcs94WN3Re0bvbt/QpOpb1ernGnVx+K8xSz2evv8UZzeIlutnrE7dnAdu7evNzaj5hYypKtwOp"
        "mrJpYXsT8T1s4OnOUH2xbTOzOibVNLq6nRsaWiwpX0KE3O+69tzWezgxhdq7+44lr+qaLqt5b07TRlpEIVWq9WFZ1nOLa54aXZzf"
        "vHFO+yRktN5rtycfE7Sox0NXVGx0/YV7fadNxhK/nSqcTzjMucc8svvXuOE700Kltzcl3p1CUpUIOM6bl28Mknh+zOPcK235LTLF"
        "p222ekI97snbkd0a/RsKk5U6Ci6tWUe3hXcvW20vee+vde2VVu5aVHbipWMZOkr+nVaqru48Y5rvw2/7hNuexbJtO0Ru9Fu/a/7F"
        "NQoWfnfnXXW8a/H1fBjMpLGMv5vb6z0Z2R0k6VPVt9aRplKaTr2lKkpvnhdZPL+HM/ZeadpWg3f3Ktth6hqttDEat66c3Kb73FqP"
        "1NL6yRflDVXN9GN+cy6sPb7W0B7m1qjpiuPN+tjJ9ZwcWMRb7MrwP3b92zR2zrEKdq6nmlzSVakqn30E3hxffy/vP09Ff4a2f8yr"
        "9hlm30d4Z2vvjm1ezjF5beZ3le24uPqakqfFjGcPGTxHKtHo6PU3VqctXoXF1GFStKja0YSk60+J4T4ef93jyOSw0Wz3Rp1/RqbQ"
        "r7fr29F1re44JRU2vxXmKT+n6CTbZjOXh6w6xEDnmyNFsqu3L/V/uTHWtQo1lThaSnyjHCfFjv7X3Ps5d5ZnZne8VjeXBCOVbslo"
        "9Wxt6lPRrnRNW42qtq6clTlD53pYw+zsXj6me+stuWm3NCsbye3LrcGoXsFVcYwlKnQi0mk8JrPNd3j2E4mE5YiN9nXAo5xu7bVp"
        "PQKW4bLS7nSKnWKlc2VaLSi32SjlLlnHq592Ge0p6RZaNt3S7qx2tHX3dUVUuK+XNwk0sxSSbXeuzljnzHHCedG27rzT7Tz6+t7T"
        "radHrqkafWVHiMcvGX6j9u5dD/Y7q9XT/Oqd1wJPrILHauxrLwz9+pW+iV91WdLTLe4pW1WrSjWtq8XHq5OSUorLzj/qe01HaFrf"
        "9I1TQ7OHmtmlCclB54I9WpPGe9v6xxJOTnvPZ6PSttefaLe6xc3cbO0tWoRbhxOtP5sVlc+z4npTnVbXtnWl9PS1tqFWxhN0pXbq"
        "PrXh4clyz9Pw7D819tO10ffWn6Y83FhdVKc4Kb5unKWMNr2MRbukZJ/9OHic81uttTbGu3Fh9wfP/STqylWcVSTSfDBd+E+1vtPU"
        "b62/aaFqVB6e5eZ3dFV6cZPLhnuz4dnxLFt1rk3mOXVxsj2e2dFe4dbttOU3TjVbc5rtjFLL9+EcnuNb2fpt9PSo7bjcWlKbpVLq"
        "VR9Y2nhyXLPj3r3Cbeha+07RG7gonMbHQdHe/wC2063rUtQ0ys5SSjPiSXBJ8La8GvqOO67b07XXNRt6MFClSuasIRX4sVNpIRJF"
        "4mdn4UJzvcO39Ms9/aZptC0hTtK3VcdJN4lmbT789x+mtDaljut6A9B66NatGlKvKtL0JSxhRj4LK55z2mPGw82PSHXhI5/O32vo"
        "24o7dqaPO96yrGnO6qVmpQc2uFJLuSaWcp9p+bTNsWFHpEqaLXp+cWkOJqM2+x0+JZa8Mr4DiPNhwo89jb+eXtvbcXB11SNPixnh"
        "y0s4OX19W2pomo1tNjoCvaNOpKFW5qVPTbzz4VjsXYuazg8Otbet9B3XpUrGbnZXdSlWo5eXFOa5Z7+74jiTj39H5ZbNcd2vbz1C"
        "nHCT6+cMZzBSwo55vnjtPSahafc+/uLTrYVupqSh1kH6MsPGUc41KwttT6WHaXlJVqFRLig20nihldnrSPV6Htiz1XdOp0bhulp1"
        "hUqznGL/ABYyaUc9v/8AhIt3Yxf1ns4xaUPOrqjQ4uHrZxhxYzjLxk9juXRP2O6vU0/zjzjq4xl1nBw5ys9mWchtNa2vqeq29nHQ"
        "VY0+tjGhdU6npxlxLhco4w0+/mzO9KdnV3+4X86kLV9V1jpxbljhXJJePZ7y8U7rxzxbOGDk7Is7XS9Sv1psdlXNGwqNwhfOE1JL"
        "uk248u7tZwHV7D7l6pd2PE5KhVlTUn3pPk/gWLbrW+87PzZIBRWRFMCCNZLJkUEaySAQhyWSIIckQkRCSICISCOAERG19AiEggBi"
        "QV42jxyR5mjxyQZxL0+qUeCqqq7J8n6mfhye/r0Y1qbhNcn9B6OvQnbz4ZLl3PxPVjtvDrYMnHX4sZLIZLJm3nJZDJZAclkMlkBy"
        "WQyWQHJZDJZAclkMlkByWQyeW3oTuaihBe1+A3H7NHt3Uruq16MOz2nv4I/Na28bekoRXJfSfrgjy5LcUuNqsvHbl0huJ5YmIo8k"
        "TW8UtI2jKNIMGjm2xdQs7Ta27aFzd29GrcWsY0YVKijKq+Gpyin2vmuzxOEkS0bxs15K8UbO09lX2kaptrR6GqanY2lbSNQdaMbi"
        "tGEpwSclhN81xSX/ALTw7X3HZXG89y6hd3tvQpXFCrCjOrUUVNKSUUm3zfCkdZiY8HVpnTxO/Pq59sDXbX7g6jty41WekVrioq1t"
        "eRm4cM8JNOSax96u/mmz9l3a3eg6dd3Gs79u61fq35rb2F/Ocpy7nLL7P/2TrYRNOZOHe28T1cs6MNVs9I3VTrX1eFvRnSnT6ybx"
        "FN4ay+7sF6dpu2N06bdXOqafqlnK46yo7WaqdWlJYckvbnHqZxIUOHnuynHvaZ36u3dZur6Gry1mW9bWOhqaqRoW9f8AdZxXPq4w"
        "XJt9mc9+WcX6UHY32sU9XsdTs7yldQUero1FKdPhSXpLuycLIkU2lhTDwzE7uR7A3DQ21uOld3WfN6kJUakksuKeOeO/DSPcXmxN"
        "Et609R/ZPYS0dNzSpyUq7XbwRjnDfdn6Dgol4ee8Lam9uKJ2dib23JZW++tH1exr0bqhbW9JyVGpGeFxzzHKeE8P6Uez1W1udev5"
        "6po2+42um1mpzp1LydN0OXNKOV7cPHadUCTgYeRtEbT0e93jc29fV3TtNWvtUt6MVGNe7qub4u/hb/FP19G15bWO7rWvd3FG3oxh"
        "UzUqzUIrMH3vkcXEu3LZnNN68LsXZeqWNK/3Hbw1C3sb+8lLzS7qNcH30uxvl2tP1+49xoV/LRrm5s9xbttruvd0pQpRjcOdKj4u"
        "UnhJvuXqZ1GJjNN2u2CJmeb9OoWkbC9rWsbijcxpS4VWoy4oT9afejlG06NjcaVVVjrL0fXo1PRqVa7p061P5uez6+xHDyMpjeGy"
        "1d423djbo1J0tm1NM1vVbPVNXlXjKj1ElN0YprOZJLnhS9fpH6aWpS3boGm0tM3H9yNTs6SpVqE7iVGNVJJKXLt7M8s9p1iJOBq8"
        "mNnMN3NWGmULKpum81e+nPNxSjcyqW8Yrs7X25x/0PZ6fb9ZY2lbaW46enS6tO6s7q5ccVO+STymvdjkjr0hw8lnHy23c+3Zq9hd"
        "69t7F5bXV1aumr28pYVOb4o9/ZhYk/Dmbv8AdFnpXSdV1WFanc2UowpzqUZKa4XTim0124a+hnX5DghIxRts5zcbJ0m61Cd/R3Lp"
        "kNJnUc23VxVgm88OPHu/uHUty2Osb/0u6oVI0rC0nSowqVHwrhjLLk89i59/cjgyFDh7p5feXvN63FG73TqNe3q061KdRONSnJSj"
        "JYXY0e16Qr60vVo3mt1Qr9XZRhPqqilwy5cnjsZw8S8PRlwdPg9xtHW4bf1+1v6sZSpQbjUUe3haw2vZnPuOQ3Oy9N1PUauoW249"
        "MjplWo6knOpirTTeXHhff7WvYcGEkxz3hjam87xLlUNZ0TSd7W19pVvKlptvNRbTlJzympTSbz39nqPZaxt3Qq2p19aluOynYVqs"
        "riVGm1KtLL4nBRz293Ps7zggia/FJp6xLsHcuqWFx0i6Td0b22qW0FR460asXCOJvOZJ4R6nUb21n0kQu4XNGVsr+jPrlNOHCnHL"
        "4uzHrOKCSK7JGPb8HK9bvbWr0iq7p3NGdt55Ql10ZpwwuDL4uzCwz32n3NC86W6le2rU69KUXw1KclKL/cUuTR1sj3G1Nbp7e1uj"
        "qFWlOrCnGScIPDeYtf3ia8mNqcuXbZyK92fpmqapc3lvuGxoWkqs5VoV5KNWi+LmsZ5rOcPl7zw7j16w1DcukUbKovMdOlSpKtJ4"
        "TxJZfsSS5+o4ne11dXte4inFVakppPuy8nhQivdYp3l2DPU7F9K0b5Xtt5p/n+tj1f7xj77OO3kfj0DX7DT91axC8qLzHUJ1aTrQ"
        "eUk5vEsruab5+s4WI4U8uNtnNqG0tL0a+o6jdbgsq1jTqRnTjRknUq8+SxnCXi8+PYftuNZ0mn0mK+rXFCra9XGMa8JKcIz4Ek8r"
        "l6vUdekOHunBv1l2fTurzSdYjqGrbst69g6voUaFbidRN4WYpYUVnL7ew4fvWjQjr9e5tr62vKd03WToTUuDL+9eO89CIiu07lab"
        "TuhJEZMyREEKEBAURCGKIhRBISFBERCElERAcAIhNr6BEKIICYkBhow0eTANBlEvDJHgrUIVoOE45X1H6nEw4lidujZS81neHpq2"
        "lVItuk+NeD5M/HKjVg8SpzXuORuJlxNsZe7211n2occ4ZeD+BcMvB/A5Fwlwl82Gz2uvZx3hl4P4Fwy8H8DkXCy4WPNg9rr2cd4Z"
        "eD+BcMvB/A5HwFwDzYPa69nHOGXg/gXDLwfwOR8AqHqHmwntlezjfDLwfwNxoVZvEac236jkah6kajBeA834JOtj0h6a30erNp1n"
        "wR8O89xbW1O3go044R5YxPJGJrteZeTNqbX5eijE8sUEYnkijW8dpaijyIzFG0GqSjSBCgxIoD3ujbK3Br9r51punTrUMuPG6kIJ"
        "tduOJrPuJMxHVja0VjeZekE5V8lu7/yR+k0v1y+S7d/5I/SKX65OOvdr87H9qPxcVE5V8l27/wAkfpFL9cvku3f+SP0il+sTir3P"
        "Op9qPxcVE5V8l27vyR+kUv1i+S/d35I/SKX6xeKvdPOp9qHFiOU/Jfu78kfpFL9Yfkv3d+Sf0il+sTir3Tzafaj8XFhOU/Jhu78k"
        "/pFL9Yvkw3b+Sf0il+sXir3TzafahxcjlPyYbt/JP6RS/WL5Md2/kn9IpfrE4o7nm07w4uJyO46Od02lCderpM+CCcpcNWnJ49ik"
        "2zjhYmJ6LW0W6SURCVkiIQiEhQRCAhEICgEQEIhIiIhJCESEiCISIgSIghJEIEJCEREIRCiRBCICBCAhCKBCEQkQRCSEiISRAQgI"
        "QkSIDr8UQo2u+hRCEZEiQBgMGiCsOJlxPJgsBYl4XEOA83CHCF4nh4C4Dy8I8IXieHgLg9R5uEuEHE8XAXCebh9Q8ITieHhFQPLw"
        "jwg4niUDSgeRRNKIYzZhRNqJpRNqJGM2EYm0iSNJBrmSkaSBGlyDEiCEMSjnm0elSttjR6elz0uF3TpSk6c1W6tpNttP0Xnm2cDF"
        "EmsTylhfHW8bWh2t8uf8n/0z/wCsvlz/AJP/AKZ/gOqhMPKr2afZcXb9Xany5/yf/TP/AKy+XL+T/wCmf4DqsR5deyey4u36u1Pl"
        "x/k/+mf/AFl8uP8AJ/8ATP8AAdViPLr2PZcXZ2n8uP8AJ/8ATP8AAPy4fyf/AEz/AAHVhDyq9k9mxdnafy4f6g/TP8A/Lf8A6g/T"
        "P8B1YI8uvY9mxdnaXy3/AOoP0z/AXy3/AOoP0z/AdWiieXXsns2Ps7NuemutUoVIUNFhSqyi1GcrnjUX444Vn4nWZCZRWI6M6Y60"
        "92EJEZM0JEEIkiASIghEBQQkQgREJGKQkIERCREICEQgIEhIUESEiCISJAIgIQkRBCIIUAkQhERCEQkKIiIiCEUCEBIiA6/QkhNr"
        "vpCAhEWCFABYHBBBgsGiwDdnBYNYHAN2OEuE3gcA3Y4S4TeBwDdjhHhNYHATdjhFRN4FIibsKJpRNYJIJuEjSQpCkGO4SNIkhQRJ"
        "YNJEkIRCgFBCIIQIQEiISIISIghEEJUJERAkQhEJCBERBCICEIgIRCAgIoBCISIiISEIhIgiEiIFERBCSIQISQhERuk4RqwdSLnB"
        "STlFPGV3o7OvLPYlHZVvuWO2LpK5uZWkaXn08wkoyfFnv+97CxDbiw+ZvziNnV4nKujrbdhuHU72pqnWysdPs6l5Vp0pYlU4cejn"
        "u7foPY61o23dY2TV3NoOnV9KnaXatq1vUrutGcWliSb555r6fUNlrp7WpxxPf8urgonYdLZGl3nRZS1q3pTWsKNa4lLjeJ0qdXhn"
        "6OcLEZJ+49TvnbdlpOt6VY6bTdGN3Y29WXFNy/dJtpvn7hsX01614p+E/i4kR27+w7Zct1z2NHTr5X8aGfun5y/3zquP7z73GP8A"
        "l6ziew9t2Gv3etaTe0nO9p2dWpZzjNpRqw5Ywu3OV2+A2W2kvForvHPePvj0cQRHK7PQdPp9HN9r15RlK8q3sLSzlxtKOEpSeFyf"
        "LiXPwP3dGG2NI1yrqF5rtOc7C2VGkkpuH7pVqKMXlNev4jZhXT2tatI6zG7g4nsdyaU9D1/UNNaaVtXnTjnvin6L96wz1xGi1ZrM"
        "xKFHLejPQtO3Brl1b6pbSuaFGyqV1TjUcG5Rccc17Wfu1jQNDvtlVtxafpl3ole3uY0PN69d1IV08feuSTys59z9zZurprWpxxMe"
        "v5dXBUJzfQNG0DTNlvc2u2FfU3WvfNKNtTrulGPotuTa59z+CPzb42/pW3tX0u5sqVaWmahbUrxW85+nGLfOHF7O/wBY2SdNaKcc"
        "zHp+biInZ1G12LW2fX3Kts3Sp0bxWjoefTy3wxfFn/1HXF7Ut6t7XqWlGVC2lUlKlSlLicIN8ot9+F3iYY5sHlxE8UTv23/Z4RAS"
        "NBIiCOvxREbXfJEQChQCEQkQFgsCIQEJYCIkOBSCDA4FIcEBghwSQRDgkhwESQlgcAApEhCJI0gQhCRECShAUEKIiCEiEiIQEIhA"
        "QEUAhEICEQohAhIgIQEMSIIQEiIIRAUEQkIERCRikJEAkREQiAhEICBISFBEhIgjdKnOtVhSprM5yUYrxbO3tR6P9yvossdHWm/5"
        "db6hO5q0uvp+jT4Z+lniw+1ck8nTwosS34ctaRbijfeNuu3+Jc96Ia1Gep6vpk61OlX1LTattbuo8KVR4xH6/gew1TRrvZfRZd6V"
        "rap21/qGoRqUbdVIzk4RUcy9FtY9H6V4nWibTTXJnv73d1fU9sW2h31vC4nZ1XO3u5SfWU4vth61/wBPAbtmLPWMc1nrETt97nmg"
        "atT0ja2xp3GHaXNzeWlxF9jp1JuLz6llP3HrOlqEdK3rpEJyco2tlbKUl3qMpc/oOuCLul9XNsfl7dvyjZ31HQriHShU3y6tt+x5"
        "23X+e9dHhx1Cp4xnPas9mPfyOr9ja0tN3/p+oJuNKrdOEs/MqNxefZxZ9xxnrqvVdV1k+rzng4nj4GUSZMmr4rRasbbTv987fs7K"
        "6W6FLb1npG2LaS4KMri8ml39ZUlwfBZR+jQquj7c6MbaprdO/lHV751oK0cY1MU2lF+l3Jxz70dXEN2M6v8A5LZIr1jaPh/Ic86X"
        "6FKvuCz1y1i/NtXsqVzFvxxjD9eFH4nBCEky0ZsnmXm+227sDoUVV7pvFb/v33OrdX2ffZhjt9Z7ndMdX+T+9jvmdu9WhcQenLjp"
        "uthtcX3nLhxn/wDYOphQ35N1NXw4vL27+vLn8Ph6c3ZGiaVc7v6Lo6Po6p19Rs9T84qW7qRhJwcGsriaWPS+hn4+lipSo3ui6Uq1"
        "OrcabptK3uOreVCou2Pt7/ecHp1alGXFTnKEuzMXhmW2223lvvY35Mb6mJx8G3PlH4Od2X8C9/8A0yv7OmcFQIRMtGXJx8PLpGxE"
        "BI1oiII4AhATa76FAKAURCEQgISUhJEAkREQoQQoqEiIiEiFAQohCIiIBQoBCEQQhEKAUEJEhQEICREJEEJEQQiAlQoiIghRCEQk"
        "IEREEKEBCEQQhERCBCiEIhASIhREEIghCIQEgSIgiFEIEJIQiIiCEQQhCICBEQhEhIQiEBCIQFEJKEBCIQEIUICgJCRBEQkEcAIi"
        "Nr6AkiQhEJEBCiJBCICEQghREIgIJQgKCJCiFBEhIgIQFBChBCEJEQJSEhCISIISIiBEBKxQgJAoQFBERCElIUQoCEBAhAUGJEBA"
        "SIgiEhCSkJIgEgNERCCEISIiIRBCEQgIEhIghEBCIQEBFAKCEiICFEIRCSEIiIghFAhIhIhAiRCEQkhAiIghRCiCP//Z"
    ),
    "stoploss": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHQABAQEAAgMBAQAAAAAAAAAAAQACBgcDBQgECf/EAFQQAAIBAwICBQYHCQ0F"
        "CQEAAAABAgMEEQUGEiEHEzFBYQgiUXGBkRQXMlKhsbIVMzZVcnSkwdIYIzdCU2JldZKUs9HiVmZzguEWJCUmNEOT0/CD/8QAGwEB"
        "AQADAQEBAAAAAAAAAAAAAAECAwQFBgf/xAA1EQEAAgECBQIDBgYDAAMAAAAAAQIDBBESEyExUQVBMjRxImGBsdHwBhQVkaHBJDPh"
        "I0Lx/9oADAMBAAIRAxEAPwD55IiNT6JCiQoKUREFJESClCRBUhIiKhIiBQghCoSEKhQCgpIiCoUQoKkJEAkREUoUCEKSIgqEhCoQ"
        "ECEiQUoSIK0KA0iBQoEKCtIQRpAKNIyjSClGkCFAaNIyjSClCgQoDQgaRAo0jKNIKUaQIUBpCgQoK0hAUBpCgQog0hQCgrSFAhQG"
        "kIIUBpCgQgaQmUaQUocgiyAiBZCoiAKiIiKiIgySIiCgiIKiIgrqwiE3vBSNIEIVCAgQoEJFJEJVREJiqFAKClEQhYSEiAUIIQqI"
        "hCpCiQhURCRUKAUAoiEMkRCBISIKSIQqFAjSAiISKUaRlCgrSNIyjSAUaRlGkFaQoEaQCjRlGkFKFAhQGkaMmkQKNIyjSClGkCFA"
        "aQoEKCtIQFAaQoyjSIFGkZRpBWkKMo0gNIUZFAaRpGUIVpCjKFAbQmUOQrSEyWQNFkMlkKSDJEUkQZCkgIKQIgqIiDJEREV1YKIU"
        "dDwCiIgqEiQUoQEghIgyQkRAoQQhUKIgpIhQVCRBUJEgpQkiAhIiKUKBCFhCRBUKJCFQgIEJEgpQkQVCREUoUAoDSNIyjSClGkZR"
        "pAaQghQVpCgQoDSFAKINCgRpBSjSMo0gNIUZRoKTSMoUBpGkZQkVpGkZRpAKNIyhQGkKBCgrSFGUKA0hMo0grSYpmRTA1kcmRyFO"
        "RyZyOQHI5M5HJFI5MjkKSAgpICyFJAQUkBEVERBk6uQokJ0PAREIEKBCRSRFkqksgRFORyBEVpEAgKECCkQEKSIgpFAQVrI5MoQr"
        "QoyKZBpESEKiIQqQkQUkSEKhQIUAkQkVEQhUKAUFaRpGUaQGkKMo0gpRoyaQCaRlGkRSjSMo0gNI0jKEK0hRlGkBpCjKNIDSFGUa"
        "RFaQoyhA0jSMoQrSFGTSYGkKMoUFaRpGUKA0hRnIphWhyZLIGhDJZCtZEyOSKRM5HIDksgIUlkCyFJAIUlkCCoQIikgIK6wQkR0P"
        "AQkQWCiIiKhASiIshkhu0RnJqMZy+TFv1IbJNojucka+D1/5Gp/ZZfB6/wDI1P7LLwz4Y82nlnI5H4PX/kan9lj1Fb+Rqf2WOGfB"
        "zaeRksj1Ff8Akan9lj1Fb+Rqf2WOGfC82nkZHI9RW/kan9ll1Fb+Sqf2WOGfC82nlJimXU1v5Kp/ZYOMo/KTXrROGYZRkrPaWhRh"
        "MUyNkS2KMpmiMoKNIyhQZEUCNBURCgISIKUICFQkRFQkQCIIQpQoBQVoUZRpEGkKBCgrSNIyhQGkaMoUFaQoyjSA0hRlGkRWkKMo"
        "0gNIUZQphW0JkUBoUZRpAaQoyhQVtCZQ5CtJijORQGsijIhWkJkgNDkyJFayWQyWQrWSyAhShM5IDWSDJBWiyBZCkgIjIlkgASIg"
        "rrIiE6Hz6FAJFRAJVREGSIsnkp0nNOcmoQXbJ/q9IUaam3KbxCPOT/UVWq6j7MRXKMV2JHTgwcfWezztZrOV9inf8nk62FPlSgvy"
        "prL/AMkZlXqS7akn7Tx5LJ31rFekQ8S97Xne07tccvnP3lxy+c/eZyWTJhs1xy+c/eXHL5z95nJZBs1xy+c/eXHL5z95nJZBs1xy"
        "+c/eXHL5z95nJZBs1xy+c/eajXqR7Kkl7Tx5LIH6FcRlyqwT/nR5M044ipxalB96/WflybpVpUpZXNPk4vsaNGXBW8dOku7Ta7Ji"
        "naZ3h50zSZmSSxKDzCXZ/kKZ5lqzWdpfSY8kXrFq9pbQmUaMW6CjRlGkGSEkQCKAUFJEJJWERCFQgKClEQhYRIhAUaRlGkFKNIyh"
        "QVpGkZQog0KBCgrSFAhRBpCjKNIDSFGRQVo0jIoDSFAhQVpCjKFMK2hTMIUwNoUYNIK0KMpigNCmZyJFayWTORyBrI5MigpFAQVo"
        "TOSyFaIMiFJAQCIEFaIAIrWSAgyJBkgOtBIjofPlEyREEREUAMWVNcVSEX3tIRDG07Ru8lV8EIUl3Lil62eLI1p8VWcvTJmMnrVj"
        "hiIh8rkvN7TafdrJZM5OW9HfR5e9IGoVqVGvC1tLbhdevKLk1nOFFd7eH3rsNefUY8GOcuWdqwuPHbJaK1jeZcUyWTuncXk7O202"
        "dfQ9Vq3FzTjxOhcQSVTHaouPY/QsP1nSjym0+TRo0XqODWVm2C2+3dsz6bJhnbJDWSydj6B0QyvdPp3OqXtS3qVYqUaNKKbgmuXE"
        "33+H0nHN5bHvNpVIVJVFc2dV8MK6jw4l82S7n9Z7GTRZqU5lq9HnU1mG9+XW3VxvJZM5LJyOprJZM5LtA1ksnZejdDrr2MK2qX1S"
        "hXqR4uppRT6vwbfa/T9ZxLeOz7raN7Tp1Kir29ZN0ayWM47U13NZXvOvLos2OnMvXo5cesw5L8FZ6vQ5LJnJZOR1P020+JSpPv8A"
        "Oj4NHkiz8tGfBWhL0SR+prhnJehtHDq69Ys9v0nJMxak+zaZtHjRtHE9uGkaRlGl2hmTyUKFW6rU6FClOrWqSUIU4RcpTk3hJJc2"
        "36Dxnb/kv6Nb6n0kTuriEZvT7GpcUk+6o5RgnjwU5e3BYjdhlycuk38PfbJ8la+1C1p3m69Tlp3Gs/ArWKnViv503mKfglL1nLa3"
        "kn7RdJqjrOuwqY5SnOlJZ9Spr6z3PlAdJOr9H2gWEdE4KV5qNWcFcygp9TGKTeE+XE+JYznsfI6C07p+6RdPu43D1+V3FPMqNzRp"
        "yhNeh4Sa9jRnPDHR5eP+bz15lbbQ/T0l9BGv9HtvPUqdWGq6RFpSuqUOCVLLwuOGXheKbXqPydD3RhQ6UNT1Cyr6lVsFaUI1VKFJ"
        "T4syxjm0fWe1datekDZNlqda1irfVLVqtbyfFFZzGcPFZUkfIum7t1rod3hr9noM6PHSuKtlKVxT4+KFOo0n3c+RjNYid23T6jLl"
        "pbH2vDtv9yRp3+1V3/dI/tD+5J07/aq7/ukf2jgX7pvpA/ldM/uv/U+r9Zuqljo19d0cKrQtqlWGVlcSi2vqMoisubPl1eGY4rd/"
        "34dG/uSdO/2qu/7pH9o6h6Wej6j0bbmpaNQv6l9GpawuetnTUGnKUljCb+b9JyL901v/APldM/uv/U9VYajqnTf0maLQ16dJ1K7j"
        "b1Hbw4P3iHFUljxxxczGeGezuwxqaTNs1t6xH79n6ejfoJ3D0gW8NRnUhpWkyfm3VaDlKr6erhyyvFtL0ZO2rbyUtqwpJXOta3Vq"
        "Y5ypSpQjn1OEvrOzN2bj03o82jc6rVoxha2FFQo29PzVJ8owpx9GXheC59x8u6t5RfSDqN7Ova6pR02i5Zhb0LanKMV3LM4tv2ss"
        "xWvdzUy6rVTNsc8MOdbl8lHgoSq7b16U6sVlW9/BLj//AKR7P7PtR0PrWh6jtzU6+l6raVLS8oS4alKoua9DXc0+1NcmfR3Ql07a"
        "hu7V47b3N1Er2rGUrW7pwUOtaWXCUVyzjLTWOzHaeTyoto299tm13NSpqN3p9WNCrNL5dGbwk/VPGPymJrExvDbg1ObHmjDn67+7"
        "pPon2BR6SNzVNGr39SxjC1ncdbCmptuMorGG1876Dt/9ybp/+1N1/dI/tHDPJd/hGuP6sq/bpncXTtv/AFro+0LTb3RJW8atxdOl"
        "PrqfGuHgb5e1CsRtvKavNn/mIxYrbbuHy8k2x4Xw7quU+5uzi19s4B0g9AW4tj2dTUretT1jTKS4qlahBwqUo/OnDLwvFN478H6b"
        "fym990q0Z1FpVaCabhK2aUl6MqSZ9I7G3Xa7/wBo2etU7dU6d3CUKtvPzlCSbjOPisp+tNCIrbswyZtXptrZJ3h8MI0jkXSPoFLa"
        "++ta0i3i40Le5l1Ufm05YlFexSSOOI1S9ulotWLR7uRbA2vT3nu7TtBq3MrWF5KcXWjHiccQlLs5fNOxekroFtNhbUr67R1yveTp"
        "VKcOqnQUE+KWO1SZxXoL/hW0D/iVf8GZ395Rf8F17+cUPtozrETWZebqtRkpqaY6z0nb83ySmKMo0ma3qv0WNlc6ld0bOzoVLi5r"
        "zUKdKnHMpyfYkjvDavkwXd1b07jcurfA5ySbtbSKnOPhKb5J+pNeJ5fJe2nb15alum4pqdWhP4HbNr5DcVKbXjhxXqb9Jy3pq6Yq"
        "+w50NH0WnRqarXp9bOrVXFG3g3hPHY5PD7ezHY8m2tYiN5eRqtVmvm5GDv5fjqeS9tV08UtX1uNTHypTpSWfVwL6zrnfvQDru0bS"
        "rqWnXEdY0+knKo6dNwrUo+lwy8pd7T8cJHrrTp+6Qbe6Vees07mOcujVtaXBLw82Ka9jR9I9HG+rbpD2xS1WnSVGvGTo3NDOVTqL"
        "tS9Kaaa9fgWIrbpDTkvrNLte88UPi5HK9h9HGudIN7KjplKNO2pNKvd1uVOlnu8ZeC+hcz9fTHtWhtHf1/Z2kFTtLhRuqEF2QjPt"
        "ivBSUkvBI+lOiHSbfSOjjQqdvBR6+2jdVGu2U6i4m378exGFa7ztLt1et5eGMlO9uzhNh5MG36dCK1DW9Vr1sedK3VOlFvwTjJ/S"
        "fg1/yYbX4NKe39crqvFNqlfRUozfo4oJcPuZwze3ThvG63FfUtO1GWmWdCvOlSoUacc4jJrMm1lt459xzDoW6Zdd3BuOltzcFaF5"
        "8KhN29x1ahOM4xcuGXCkmnFPuznBn9iZ2clqa6lObN/v2/cOkte0DUtsapW0vVrWdtd0X50Jc013NNcmn6UY0jSb7XtRoadpttUu"
        "ruvLhp0oLm3+pelvkj6B8prQaFxtzTtcjBfCbW5VvKS76U4t8/VKKx+Uz1XkvaTbylrmrzhGVxDq7anLvjF5lL3tR9xhwfa2dldf"
        "vpeft1/28u3PJkpSto1dxazVjXksuhYpYp+uck8+5e09peeTJt2dGSstZ1ajWx5sq3V1Ip+KUY5954unfpR17aWp2eh6HVVnKrbq"
        "5q3PApSacpRUY5TS+S8vxXYddbe6eN56Rf0qt7qP3TtOJdbb16ccyjnniSSafo7vBmU8ETs5Mdddmpza37+37h6vf3RjrnR9Xg76"
        "MLixqy4aN5R+RJ9uGu2Msdz8cN4OIo+0d06Tabw2de2VSPHRvLVzptrnGWOKEl4p4Z8WoxvXh7O307V21FJ4+8NZFMyOTW9FojI5"
        "CtJijKYoDQmcjkKcjkzkUwrRAIU5HJkgrRAhyRSQZIKRyZEKSAshTkgyQV1uKAUb3zpAQKqIQIjLNUP/AFFL8tfWZY2//qKf5a+s"
        "yr3hpy/DLxt82WTLfNlk9bd8w1k+hPJxpwW1NSqKK45X7i5d7SpwwvpfvPnnJ9EeTh+COo/1hL/DgfPfxPP/AALfWPzej6X8xH4u"
        "2D471qjTjvS+oKCVJalUhw93D1rWD6+vLy30+1q3d3Wp0LejBzqVJvEYRXa2z4u3Bqcb/cGo31pOapVrurWpS7JYc20/B8zxv4O3"
        "jJktt06Oz1rrWsfV9NH4tY0m21zTa+n3ceKlWjh47Yvua8U+ZxHow29rlC2+6uualqE+ujmjZ1a0mop/x5Jvtfcvf4c9mksek/WM"
        "Hr+DUZo03DP2un3PyXJqKYtRyqW32948vmvXdGudv6pX067Xn0nykuyce6S8Gfgyd5dI20FuXS/hFrTT1C1TlTx21I98P1rx9Z0W"
        "8ptNNNdx52u0s6fJw+09n2Oi1UZ8e/vHdrJ+7QYxqa5p0JpOMrqkmn3rjR6/J+/bz/8AH9N/OqX20cuP44dOT4ZfSh190zxj9wLK"
        "bS4ldJJ+hOEs/UjsE6+6aPwds/ztfYmfX+ofL3+j5TQfMU+rp/JZM5LJ8bu+uaT5o/dU+/T/ACn9Z69Pmj99T79P8p/Wcmr7Q9X0"
        "r47fRuJuJ44nkRwPfq2hQIUGyGjm/Q7vyl0d72t9VuoSnY1qcrW64FmUacmnxJd+JRi8d6TOEI530Y9EupdKEdRenajZWjsHS41c"
        "cWZcfFjHCn8xljv0a8/BwTzOz621fRNq9Km26ULuNvq2mVmqtGtRqNcMly4oyi8prmmvWmu46l1zyS9Oq8U9D3Hc27zlU7yjGqvV"
        "xR4ce5nWO6dD3h0D61a21puKdKpd0ev4rKc1Tl5zjiUZLEny70+1HvNA8qLeemzpx1Whp+r0Vynx0+pqS9Uoean/AMrM5tE93mY9"
        "NnpHFp771eLcFl0wdEWm07JajeU9Ft8xpXFk1UoRTbfN4zHLb+Ul2nVWoahdarfXF/e1pV7q4qOrVqy7Zyby2z7m2Tu/SukzakNU"
        "traXwa446Fe2uIqXDJcpQl3NYftT9h8edKe2aG0N/wCs6NaxcbajWU6MX/FhOKnFexSx7DG0bdYdGi1HHe1L12tDip/QDcv4Nar+"
        "Z1vsM/n+f0A3L+Deq/mdb7DLj92r1Xvj/H/T4BR2Z5OcIy6WNLbWXGlcNeD6qS/WdZnZXk7VY0+lnSYyfOpTuIr19TN/qMK93o6r"
        "/pv9Jd1eU/OUOjSCi2lPUKKl4rhm/rSPkw+tvKbt51+jJ1ILMaF9RqT8F50frkj5JMsndzelf9H4uZdDs5U+k/bji8P4ZGPsaaf0"
        "H050/QU+iTXs9yoNevr6Z8zdDNvO56UduQprLV0pv1Ri5P6Ez6X8oCqqXRJrue2XweK9fX0y1+GWjXfNY/w/N0r5Lv8ACPcf1ZV/"
        "xKZ2z5QWydf3xt/TLTb9h8Nr0Lt1akeup0+GPA1nM5JPmzqbyXf4R7j+rKv26Z9AdI3SRp3Rrp1rfalaXdzTuazoxjbqOU+FvL4m"
        "uXItduHq1ay166uJxxvL5qs/J36Rrm4jSq6LRtIPtq1ryi4x9fBKT9yPpzo62fDYOzrLQ5XEa87dSnWrJcKlOUnKWPBZwvBHXFTy"
        "q9sqDdPQ9YlLuUurSft4mdd9IflC63vKwq6VptqtG0+snGtwVOOtWh81ywsJ96S59mcZJE1r1hnkx6vVbUyRtDh/Sfr9Dc2/9b1W"
        "1lx29a5caU/nwglBSXg1FP2nGUZFM1S9ulIrWKx7OfdBf8K2gf8AEq/4Mzv7yi/4Lr384ofbR0B0FfwraB/xKv8AgzO/vKL/AILr"
        "384ofbRsr8MvH1vzmP8AD83yShRlCjU9x9VeTNBR6OqzSw5ajVb8XwU1+o6i8oWcp9KOoRk8qFGgo+C6uL+ts7b8mSrGp0eXEV20"
        "9Sqxf9im/wBZ1N5RNvOj0n3k5rCrW9CcPFcCj9cWbbfBDxNL89f8f9OtT6O8lmcnoeuwb81XVNpeLg8/Uj5wR9I+SzQnHbut3DXm"
        "Tu4QT8Ywy/tIxx/E6/VPl5/D83EfKego770+S7ZaZTz/APLVOf8AQN0l6bq+3rPbF7cQt9VsYdVRhN4VxTXyeH0yS5NdvLPpx1/5"
        "TtVS35YQXbDTKefbVqm6nk17htrGd/DWtMkqdJ1kodZxPCzy83tMusWnZzTTFfSUplttv2dq7x6Cdqbtva2oKNzpt9Wk51atrJcN"
        "ST7XKEk1n1YydeXvk/bs2ldx1faOt0ru6t3J0049RWWU00stxbw2ubRwPQembfG34RpUNbq3NGKwqV5FVlj1y85exnbHR15Q89wa"
        "vZ6LuDTaNCvd1I0aV1atqDm3iKlCTbWXhZTfN9g3rLG2HW6evSeKse33fi6f3buze90quh7ovtQfBNSna3UFFqS7HjC9jOTdBPSJ"
        "ZbK1q6sdWqdTp+pKCddrlRqRzwt/zWpNN93Luydq+UJta01fY9fWOoj8O0yUJwqxXnOm5qMot+jzuL2HT2xOhXVd+6F92LLU7C3p"
        "ddKi6dbj4k449C8USYmLdHRjz4M2mnjjhjtP1fRe7dhbb6RLKhLU6PXcMW7e7t6mJxjLvjJZTXfzTR1ZrXkwYjKeibgy0vNpXtLt"
        "/wCeP7J15qGp7w6INxXWg2Wv1qcrbgbVJuVCXFBTyoTWP42Oz0nLNveUtr9pWhDXNPs9Qt+SlOinSqrx74v1YXrLNqz3hz00urxV"
        "icF96+37l6ncutdK+w+rs9V1HUba2ilSo1YcMqM0lhKMksdnc+fgdao+1uHR+kHakJVKXwjTdUt1NRqRxJKS5eqSfuaPjLVbGWl6"
        "peWE3mdrXnQk+zLjJr9Rjeuzs9N1MZeKs1ito77PzplkEKNb0yjSMlkK0OTORCtZJAKARMiFaIyIVogQ5IpyWQyWQrRAiCtZLIZL"
        "IUkAhSQERXXCNAhOh84gEgqBiDCSyxoff6f5a+sGNH7/AE/yl9ZlXvDTl+GXgb5sMg3zYZPUfMNZPofydKtOjszVKtWcadOF9OUp"
        "yeFFKlDLb7kfO2T3FHeWo2e06+2bSfU2lzcu4uJxfnVVwxSh4R83L9PL0c/M9X0VtZg5NZ23mP7OrR54w5OOfDmHTD0sVN43UtH0"
        "mrKGi0J85Lk7ua/jP+au5e192PL0XdHHwh0te1mj+9LE7W3mvl+icl6PQu/t7MZ/L0YdHH3WnT1vV6X/AHGLzQoSX39r+M1836/V"
        "29v6lqNpo9hVvb2tGhb0Y8UpPu8F6X3JGiK49LjjTaeOkfv+74/+IfXb5bzp8M72npMx+Ufv/Lx61rVlt/TquoX9VU6FJe2T7opd"
        "7Z11sLd+o7u31eXVdunaRs5xpUE/NpLjhj1yfPL/AFI4RvDduob81mnTo06qt1PgtLWPN5fLLS7ZP6Ow5Xe6DcdG+zrS+pTitVlf"
        "Uqtaa5pYhP8Ae/FYbT9OX4Huej6ScV/5i0fD1n9GrR+lV0uLbL/236R93795dtHT3Sts77nXT12yp4triWLiMVyp1H/G9Uvr9Z2d"
        "t3Xrbcmk0NRtXiNRYnDOXTmu2L9X1YZ+y9sqGo2la0uqaq0K0XCcH3pn2WpwU1WHaPrEtenzX02XefpMPmHJ7Dbz/wDH9M/O6X20"
        "fo3btu42trNWxq5lSfn0Kr/9yD7H6+5+KPy7df8A5g0z87pfbR8jFLUyxW3eJfVTeL45tXtMPpc6+6afwdsvzxfYmdgnXvTV+Dll"
        "+eL7Ez631D5a/wBHy2g+Yp9XTmSyZyWT4x9c2nzR7Cf32f5T+s9anzR7Gf32f5TOXVdoep6X8dm4nkR44nkRxS+gq2hQI0iNkFHb"
        "fk4b4tNpbyq2Oo1oULLV6caHWz5KFWLzTy+5PMl62jqVCWJ26sMuOMlJpPu+1elzomtOlDTbePwpWOpWbk7e4cOKLi+2Ellcm0nn"
        "ux60+k4eSnvJ3Spz1TQo0M86qq1W8eEer7fDPtPS7J8oTeGz7SlYVJ0NXsaS4YU7xN1IR7lGaecLxzjsOYy8rfUnDEdq2in6Xdya"
        "93D+symaz1l5tMWrwxwU2mHdmyNp6Z0YbOp6ZG7Tt7WM69zd1sQUpPnKb7orl7El29p8d9Je56e8t96xrlBNULmvijntdOEVCL8M"
        "xinjxPY776Yt19INP4NqV1TtrDOfgdpFwpyfdxZbcva8eBwgxtbfpDp0ektjmcmSd7Sj+gG5Pwb1X8zrfYZ8AHcF95T+8r+xuLOr"
        "pm31Tr0pUpONCsmlJYeP33t5lpaI7prtNfNNJp7f+OoD3Gz9xVtpbn03XKEeOVlXjVcM4449ko+2La9p6cTB6M1i0bS+8ZLQuknZ"
        "7SlG90jVbfGVyeH9mUWvY14HQeteSnrtK+l9xdb06vZyl5ru+OnUhHx4YyT9ax6jrPZPSXufYFaUtE1Bwt5y4qlrWjx0aj8Yvsfj"
        "Fp8u07RtfKx1eNJK62zYVauOcqVxOnFv1NS+s2cVZ7vHrpdTp7TyJ3iXYfRL0HWfR1cz1a+vI6hq84OnGcYcNKhF9vDnm2+zi5cu"
        "WO3PD/Kf37bStbfZtlVVSv1kbm+cX97ST4Kb8XnifoxH0nENyeUxvHWqE7fTqdlo1Oaw6lCLnW8fOk8L2RT8TqetWq3NadavUnVq"
        "1JOU5zk5Sk32tt9rJNo22ht0+jyzl52eertzyXf4Rrj+rav26Zz3yrfwV0X8+f8AhyOh9hb71Po71qesaVQs69xOhK3cbqEpQ4W4"
        "tvEZRefNXee36QOmHX+knT7Wx1e00yhStqvXQdpTqRk3hrnxTly5k4o4dm3Jpb21Vc0docGQghNb0kICFc86Cv4V9A/4lX/BmfUn"
        "STsue/tqV9Cp3sbKVWpTn10qfGlwyzjGV9Z8bbT3NebO3DZ67YU7erc2jlKEK8W4PMXF5SafZJ952b+6l3n+LNvf/BW/+02UtERt"
        "Lytbpc2TNXJi9nu/3KN3/tXQ/uT/AGzw3vkt3VlZXF0900JqjTlU4fgbWcLOPl+B6v8AdSbz/Fm3v/grf/aeK78pveF5a1rappug"
        "KFanKnJxoVspNYeP30v2GMV9Q36zH+P0fv8AJr33baJq91tq/qqlS1OUZ205PCVdLHC/yljHjFLvO3OlTolsOkm2o1fhDsdTtYuN"
        "G4UeKMovnwTXa1nsw+WX2nx1GTi002muaaOz9qeULvHblvTtLqdvrFtBKMfhifWxS7lNNN+uXESto22lnqtDknLz8E7S95ZeS5uO"
        "d7wXus6VRtVJZqUesqTa8IuKWfad8bb29o3R1teNhbVFQsbOEqta4rNJyfbKpN//ALCSXcdJVPKq1OVPFLbNnCpj5UrmUln1YX1n"
        "Xu9OljdO/IdRql5ClZZUvgdrHq6WfS+bcv8AmbLxVr2ab6XV6mYrmnaHg6TN3rfG87/WKSlG1lJUraMu1UorCfg3zlj0tn1B0Sbz"
        "tN67Lsqiqwle2lKNteUe+M4rGWvRJLK9q7mfGx7Tbu5tW2pqUNR0a9q2lzDlmD5TXzZJ8pLwZjW+07u7VaGMuKMdenD2d0bu8ma8"
        "q6lXutsalZxtas3ONrd8UHRy/kxklLiXozj29p7Do38nq82/uC11rcV/aVXZVFWoW1o5SUprnGUpSSxh88JPOFz7j0GneVFrlGhG"
        "GoaFYXVVdtSlUlS4vZ53M8Wr+U7uK7t3S0zSrDT5y/8Adk5VpR9SeFn1pmW9O7jnH6hNeXO23no7A8ofdtrpGzKmhRqxd/qkoRVN"
        "PzoUoyUpTa9DcVHxy/Qzink07ztbR3u1byrClO4q/CrTieOsnwpTh68Ri0vWdI6nqt9rd9Vv9Su613dVnmdWrLik/wDp4dx4KVWd"
        "GpGrSnKFSDUoyi8OLXY0+4xm/wBrd1U9OrGnnBM9Z67/AHvqfpX6F6e/7unq2n3tOx1OFNUp9bFunXiuzLXOLXPnh5WF3HXeneTL"
        "uareQhqGqaVb2ufPqUJTqTx/Ni4xT9rR+DbflGbq0a2hbajRtdXpwjwxqVswq+2S5P2rPie7r+VHqcqbVvtuzp1McpVLiU0n6kl9"
        "ZlM0nrLlpi1+KvLptMfg7prV9I6OdnxdSp1OnaXbKEeOXnTwsJeMpP6WfGWpX1TVNRur+qkqlzWnWkl3OUm39Z7jeG/9wb5uY1tZ"
        "vXOnB5p29NcFKn6o+nxeX4nHjC9t+zt0GinBE2vO9pKNIzksmD0WsjkymKCtZHJlDkK1kshkgrWRyZQkGkWQyWQrWSyGSCtCZLIV"
        "oshkgpyOQIKRyZyOSKSAgrrsSI6XzhAQIqBiDCSyxo/f6f5S+sGVL79T/KX1mVe8NGX4Zflb5ssmW+bCT5HpvmVOXcjnnRr0dy3H"
        "Wjqmp05R0ynLzYPk7iS7l/NXe/Z6ces6ONoU93a26dzJxs7aKq1knhz54UV6M+n0I+gP+66ZZ/8AtW1rbw8IwpwS+hJHDqtRw/Yr"
        "3fNeu+rzg/42H457z4+n3i5ubXSrKdevOnb2tvDMpPlGEV/+7DoHf2+rneN+qVBTp6dRlihR75vs45eL7l3e/P6ekXpBq7runY2M"
        "p09Loy81djryX8Z+HoXt7ezi9hRqW+r29KtCVOpC4jGUJLDi1LDTXpLpNNwzFr95PRfR/wCXr/MZ4+37R4/9dy9G/R9DblCOpajT"
        "jLU6seUXzVvF9y/nPvfs9Obpl/BOl+dw+zM52cD6ZvwSpfncPszPvdRgph0lqUjps06fNbLqq3v33df9He8ZbX1bq7ib+5901Gsv"
        "mPumvV3+HqR33GUZxUotSi1lNPk0fK2Tt/ok3n8Mt1t++qfv9GObWUn8uC7Yetd3h6jzPSNbwzyLz0nt+j0PVdHvHOp39/1co3zt"
        "OnuvRpUYqMbyjmdtUfdLvi/B9nufcdG6HRqW+5tPo1oSp1Kd7ShOElhxamk0z6VOvN9bM4tf03cVjT5q7oq7hFdq40lU/U/Y/Sdn"
        "qei45jNTvHf6f+OX07V8EThv2nt9XYZ1501/g5Zfni+xM7DOvOmz8HLL88X2JnX6j8tf6OXQfMU+rprJZM5LJ8W+vaT5o9nL77P8"
        "p/WeqT5o9rL75L8pnLqe0PU9L+OzcTyI8cTyo43v1aRpAhRGyGkJIiMoJEQUkQhUhIgEiIKUKBCRSREFIoBRFJEQUkQoCQkiCkiI"
        "KUKBCFaQpmUKYVpDkyhyBpMTKEitJiZTNJhSjSZlDkDSZGciFaQmUaClCZyOQNCZyKCkUBIitCZIK0JkUwNFkCyFayQEFaICCtEB"
        "ZIpyJkQpICCuvhATofNoBAikyzQMqSywpffoflL6xZU/v0PykZV7tOX4Zfhb5sH2A3zZZPSfM7Pd7R3ZebQ1T4dawhVjOPV1aM3h"
        "TjnPb3Pl2ntt5dJupbtt1ZxoxsbLKlOlCbk6j7uKWFleGP1HDTvPyfdlaBrWk3Otalp1K7vba9dOjKq3KMEoRa8zPC3lvm0zz/UN"
        "Ti0mOdTkrvs14vSsOp1MZOGOPy8nQn0RuLobp3BbNPlOxtai7PRVkvsr2+g6q1x/+fdQ/rWp/jM+yT401t/+fr/+tan+MzxP4e1+"
        "XWavJlyeI2jxG72fUtPXDhrSv3vo44F0z/glS/PIfZmc9OBdNH4I0vzyH2Zn7Dr/AJe/0fnOh+Yp9XSGTzWl3XsbmldW1SVKtRkp"
        "wnHti12HgyWT4mJmOsPsJjfpL6Q2bumhuzRad5DhhcQ8y4pL+JP/ACfav+h7ztPnPZG7K20tahdedK1q4hc0l/Gh6V4rtXtXefRF"
        "tcUby3p3FvUjUo1YqcJxfKUWspn2Pp2s/mMf2vijv+r5T1DSTgydPhnt+jynXfTb+Ddl+eL7EzsQ666bvwbsvzxfYmbPUflr/Rr0"
        "HzFPq6YyWQyWT4p9hs0nzR7Z/fJetnp0+aPcP5cvWzm1PaHqel/HZ5InkR44nkRxPeq2jSMo0g2w0hBCRkhAQIUQhUICFQoBRFKE"
        "BKqEBIJGgQkVCAhUKBGkFQgIVCAoKSIQIQEKhTASKUKBCFaTHJkshWkOTKZpMBQoEOQpQ5M5EK0JlCgNDkyOSK1ksmciFaFGRyFO"
        "RyZyOQrWSyBAaICCtEBEUiBZCtEBEUkBFVwEiI6HzaIQRFQMSZWMsMqf32H5SFmU8ST9DLHdqyRvWYeub5ssjXXBWnH0SZjJ6O75"
        "lrJ9HeTROL2hqccriWoNteDpw/yZ835OY9G/SXqHR3qFWpRoxu7G5wri2lLhzjslF90lz8H7mvK9Z0l9VpbYsffpP9nVos1cWWLW"
        "7Pr0+MNbrQe+b+qpLq3qlSXF3Y618ztTcnlKu50ypb6BpNW1u6seH4RczT6rK7YxXa/Q37mdGynKcnKTcpSeW32tnmfw36dn0k3y"
        "Zo2322h1ep6nHmiK0nd9YHAOmqSjtKim8N3kML0+bM4/t/prnaWELfWLGpc1qceFV6MknNLs4k+/x+g4tvjft3vKvTjKkrayoNun"
        "RUuJt/Ok+9/UfqGs9TwZNPNaT1n2fEaT07NTPE2jpHu4xksmclk+XfRtZO0eiDenUVVty/q/vdRt2k5P5Mn2w9vavHPpR1Zk1CpO"
        "lONSnJwnFqUZReGmu9HRpdTbT5IyVc+p09c+OaWfV51x04Titu2MMrid2ml6UoS/zR6zROm+NGxjS1jT6ta5gsddQkkqni08Yfq+"
        "g4Zvbe13vK+hVqU1b2tFNUaCeeHPa2+9vCPf13qeDJp5rSd5l4mi9PzUzxa8bRDjuSyZyWT5h9G0nzR7v+O/Wz0tBcdaEfTJHuVz"
        "bZz6iekPU9Lj7VpeSJ5UeOJ5Ecb3qtoUCNINkFHvtq7Sud0VK8o16NpZ2seO4uaz82mufvfJ+jsPRI5fsfcmmafZanoutKtCw1GK"
        "TrUVmVJrKzj0ex9nZzMZ7dG3HETb7T9cejnT9Up1Y7f3Naald0ouTt5U+rc8eh5f+XicInCVOcoTi4yi8NPtT9B2No+z52WoR1jZ"
        "mvafqla3UpRt63mzw4uOGs+PfwnoNvLTbzcd/cbitLitWzUqRsqFKWalbLbi0uaSeVj39hjEtlqdum35OLo97oG2Hrul6xfq6VH7"
        "mUVW4Or4usypPGcrHyfHtOaw0Sz3TpuoUamzq+3ri2oOtb3HBKKm1/FeYpP6foPUdH/4Lbx/M4/Zqji6EY9rRv2cGPdbQ23/ANqt"
        "YWnfCvguacp9Z1fH2d2Mr6z3e1NF0ix23c7p123leU4VOpt7VPCqS5c37fqfJ8jkfR7qe39a3E61npC0m/pUptQpVOKnWg8J8sLD"
        "XLs8RNvC0x7zG/u6rrU+qrTp5zwScc+nDMo5ftLblhqlzq+qau5/c7Tc1KlODw6rbbSz7PpR7PSb/ae776OjVNuw0uVbMbe5oVcy"
        "Uscs8l9Of1lmyRj393XxH6tV06ppOp3VhValO3qypuS7JYeM+05bsLQtG1TQ9cutXpNwtIwmqsW+KnHEm8d2XjvLM7RulazM7OEC"
        "dgaLqO0dyXkNDqbcjp8a+YULmnWcqil3ZeO1+1ZPFs3adnLeep6NqtKNzTtaFTDbaWVOKUuT9D+kx4mcY99tpcGI5VdQ0LcF7YaN"
        "t/TKlpOddU3d1ajlKpHsbcc8vSe21TUdp7Vv56NT27DUlQahXua1XE5S78cu7wxz943Ip77uAHs9S27eaXpthqNd0nRv4uVJRk3J"
        "JY7Vjl2nIdf0nRttajp2r0LKWo6PqFGVWnbVKrg4vC5cXN8uJP3nIty63otttnQK9ztyF1QrU5Ojbu5lFUFiPLOPO7vcTi8Moxx1"
        "3l1UhOcbQ21Zz0S53De6bc6nw1HTtrGgm+N8ubxzxz+h9vI/fc7etdy6NfXEdtXO39Qs6bqwzCUadeKTfDzSWeX1F4iMc7OuSOZ7"
        "d0jSNK21Pc+t2zvVOr1Nra5xGcvS/c/Ul2M9vtOltXeWp1Iz0ONlcUqUpdRCo3SqxylnljDTf0+5NljHv7uI6Dtj7t6bqV78Pt7b"
        "4DT4+rqds+Tfp5LljPPmelOU7Q0ix1DQdyXN1bxq1rS2jOjJtrglwz5/Qvcfp2vo2k2W3rjc2tUJXdOFTqbe1Twpy5c37fqfbyG5"
        "w7xD021Nu/8AafVlp/wn4NmnKfWdXx9ndjKPVVafVVZ0854ZOOfTg7O2DqWhaxr7rWmlLSr2lSk1ClU4qdWDwnywsNcuzxONbW2/"
        "Y6ncarqerOf3P07NSpCDw6jbeFn2fSibsuDpGzihHPdLvtrbrvY6PU2/DTJVsxoXFCpmSljlnkvpz+s4ZqdhU0vUbmxqtSnb1JU2"
        "134fb7Ruxmu3V+UUQooSIgIUQoKkJEFJZIgpFAhClCBEVrIoyKAUIEFayOTIoKRMiFaICCtEBBSIISBIiIqFEhQVEJBXABATofNI"
        "kSEKCIgksswzyNGWisJh+O+p841V2SWH4NH5MntJRjKLhNZjLt8PE9dWoyoT4Zc13PuaOzHfeHgavBOO+8dpYyWQyWTY5Tkshksg"
        "OSyGSyA5LIZLIDkshksgOSyGSyA5LIZPJQozrz4Y9ne+5DciN36tNpcU3VfZHkvWeyijx0qcaUFCCwl9J5oo4st+KX0WiwcqnXvL"
        "cTyIxE8iNT0YaQoEaRJbIJzfY2o6PdaLqe2dYuIWUb1qpRuppYhNY5Nvs5xi+7PPmjhAkmN2dLcM7uzNv7T0/Z+r0da1Hc+myt7d"
        "SnCNCpmdVtNYx7e7IbP3HY3up7lqwu6OlahqTc7O4r4SgsyeG3yT5x9fsOtRROHy2Rl222h2/oN/LRbm5stx7vtbuveUZU6UY3Dn"
        "Ro8ubnJ4UW+5eDOObYnZaLpO8dPranYznO2VOjONaPDXfDU+Rn5Xauz0nAxJwrze3Rzva99pWu7Sr7W1K+hp1aNbr7avV+Q36G37"
        "e9dvge32ZpGj7L11VdS3Bp9W7q0pwhGlUXV0o8m3OTaw3jCXr7Tq0UJqVybbTt1hzXZut6bRetaLqtfqLTVE4xuFzVOSzhvw59vg"
        "fu0LbWlbT1OlrWqbi0yvb2+alCna1OOdZ45cv8s+s69EvCsZNtt47P263qT1jV7zUHHg+EVZVFH5qb5L3HNujiNpPa+5YX8507WU"
        "IRqTisuCakspeHadeHIdB3LR0jQNZ0ypQqVJ6hCMYTi1iGE+33ktHTYx22tvLkehbV0jbuo0dbv9zabXtLaXWUY0J8U6rXZy7nnu"
        "WS2duO0u98avqt3Xo2dK5t6vA69RQXyocMct4zhfQdeoRssZNttofv0HU3ous2eocLmrerGcortku9e7JzHWtsaXubU62s6ZuPTK"
        "NrcNVa0LmpwVKLfby9fpwdfiJgrbaNpct35rWn3kNM0jSqjrWmmUnT67GFUk8Jtf2e3xZ7W7o6dufZ2iUaet6bZ17CnKNSldVVCT"
        "fLsXs+k69RpDZePrO7nuztaoXm2bjb0tXlo96qvW21wqjpxlnti5Jrvz7124NanQuNF0i6lqm9bq6vZx4be2s72c1LPz893u9pwA"
        "Rwrx9NnN9v6hpGubTltnVb2On1aNbrra4mvMy89vvl6O05B0faLpOiazUhS1i31O/q0JYVt51OlBOOcyz2t49zOv9vXmiWdSs9a0"
        "yrfwkl1ahVcOB9/Y1nuOS2G9ds6DOrc6Nt2vQu5U3TjOdxKSSfpy33pGMx4bKWjpMvybLvrS127uilcXNCjUr2sY0oVKijKo+Gpy"
        "in2vmuz0nn21e6ZrW1q22dRvYWFaNbr7evU+Q36Hn2+/wOEiZbMIu7L2hpOkbP1tVNR16wq3VSnOEI0qi6umuWXKTaw32JevtPS7"
        "R1nTqT1jR9TrdRaamnGNdc1Tks4b8Ofb4HDhJsvH4c90TbumbW1KlrGp6/ptehb5qUadtU451Xjly/yycP1nUXq2rXd+48PwirKo"
        "o/NTfJe4/EIiCZ6bQkJISoiIQqFAjQVEQgQoBQZEiEgiIQqQkhCoiEKhBCFJEIVERAIoBRFJEJFREKCpCSEKiIgOAkRI6HzZRCiY"
        "AQkBlmWjeAwVjMPG0YnFTi4TipRfceVoGixO3WGq+OLRtaH4KlhJ86MlJfNfJn55UasHiVOa9h7XhLmu9r2m6M0+7zr+nx/9Zeo4"
        "Zeh+4uGXofuPb5l86XvLin86XvMudHhr/p9vL1HDL0P3Fwy9D9x7fin86XvLM/nS9450eD+n28vUcMvQ/cXDL0P3Ht8y+dL3jmXz"
        "pe8c6PB/T7eXp+GXofuLhl6H7j3GZfOfvHMvnP3jnx4P6fby9Nwy9D9xqNGrN4jTm/Ye4zL5z94pN97Jz48Mo9Ot7y/BS02beazU"
        "F6FzZ++lSjTiowjwxRpRNxiar5Js7tPo6Y+veTFHkigijyRRrd9YKRtIykbSI2wUKA0iMiRHvNG2Vr+v2vwrTtOnWoZceN1IQTa7"
        "ccTWSbs61mez0iE5T8V27vxR+kUv2h+K/d34o/SKX7ROKGXLv4cWI5T8V+7vxT+kUv2h+K/d34p/SKX7Q4oXl28OKmkco+K/d34p"
        "/SKX7Q/Fhu38U/pFL9ocULy7eHFyOU/Fhu38U/pFL9ovix3b+Kf0il+0OKDl28OLCco+LHdv4p/SKX7Q/Fju38U/pFL9om8Ly7eH"
        "F0Jyj4st2fin9IpftF8WW7PxT+kUv2hvC8FvDi4nI7jo63Ta0J16ulT4IJylw1acnj1KTbOOF3SazHcoQQgJEQVGkCEKhAQqEiIq"
        "FEKCoSICEiQUiRBUJEFKFAhCoSIioUQoCQkQVCRBSICFQkQVCAhShBCQQkRFQokKCoSIKiIgrgIoBR0PmiICFBCQATQjgGzGAwbw"
        "GAx2YaDhPJgOEqcLx8JcJ5OEuHwCcLHCXCeThLhBwvHwjwnk4R4QvC8fCPCb4R4SLwsKIqJtRNKIWKsKJtRNKJpIM4qEjaQJGkiN"
        "kQUjSBIQygo0CQkZI53tLpSrbY0enpk9Mhd06UpOnJVuraTbbT8155tnBDSJMRPdnW81nertT48f93/0z/QXx4/7v/pn+g6rEx4I"
        "befk8u0/jx/3f/TP9BfHh/u/+mf6DqwUOCDn38u0/jw/oD9M/wBBfHf/AEB+mf6Dq0RwQvPv5do/Hf8A0B+mf6B+O/8AoD9M/wBB"
        "1aI4IXn38u0fju/oD9M/0D8dv9Afpf8AoOrkJOCDnX8u0Pjt/oD9L/0F8dv9A/pf+g6vEcELzr+XZdz001qlCcKGiwpVZRajOVzx"
        "KL9OOFZ951qgFFiIjsxtebdyICVERCgqQkQCRCFREJFSEkIVEQhUKBCgpIhAiRCgpREIVEQkVIUSEKiIQqFAIVCRAJEQUkiFEUkQ"
        "kVEQoKkJIQqIiASJEFcBQghOh80hIQqLBCgoIcEFRYIQbDBYEcA2Z4SwawOAbM4LhN4LANmcDg1gcBdmcFg1gcEXZlIUjWBSC7BI"
        "UhQhlEJIUSQoLEIUiSEjIkRBShBCBCRBUaQISKhIiqhRCjFUhIgISIKUICFQkQVCiQhUICFQkRFQkKCoSICEiQUiCEKhIgqRpAhC"
        "oSIioUBpAQmqLhGrCVSLnBSTlFPGV3o7VvbLo/obGt90R2rdpXV1K0jR+6E8wkoyfFnv+T2FiN2rLm5e0bTO/jb9XVAnLujXbGn7"
        "k1S+qat1srDTbKpe1adKXDKrw481Pu7foPZa5om2ta2JW3Tt/TbjSalneK1rW1S4daM4tLEk3zz5y+nwHD03S2prW/BMeP8APZwB"
        "EdlUdiaTe9ElLXLajNa0oVrmUusk1OlTrcE/NzhYjKL7O49Pv7bFjo+vaRp+l0nRjeWFvVlxTcs1Jtpvn7BNZKaql7cMeZj+zhwn"
        "ci2VseW757Cjpl+tQjQz91fhL++dV1n3v5OMf5eJw/o+2xp24bzXNIvqLnfU7KrUspxm0o1ocsYXbnKfP0F4ZY11tJrNtp6RE/hP"
        "u4WJy6y29ptLoyv9w3tGUr2rfQs7KXG0o4SlJ4Tw+XEufoP39FO1NG1+tqN7uClOpp9qqNFKM3D99q1FGLymuzn7yRX2bLamla2v"
        "PaJ2/wDz+7gSNI9lufSHoO4tR0tppWtxOnHPfFPzX7VhnrTGXRW0WiLR7oTmHRbt/TNxa/dW+q20rmhRsatwqcakoNyi445rn3s9"
        "hre3dAv9i19y6dpV5oVxbXUbf4PXrurCunj5Lkk8rOfY/ZYr03abaqtcnLmJ9v8APb73X4o55t7RNuaXsd7q3Bp9fVHXvvgdC2p1"
        "3RjHzW3Jtc+6XuR+bfu3NJ23rOk3VhSrS0rUbWjeq3qT8+MZPzocXq7/ABHD03K6qs34Iiff/Hdw0TtWhadH9bZdfdC2rdqnRvVZ"
        "uh90J5b4Yy4s/wDN2eB1jf1LatfXFSzoSt7adSUqVKUuJ04N8ot9+FhZExszw5+bMxFZjbzt+rwCAoxdBREQHARATofNoSICRoEI"
        "VEQhRgUiRoKyIlgiohwKQBgcDgsBUQ4LAVFgcDgKEIpFgKhSJGgDAohIqIhCoUAoKSIQsIiFASEkIVEQklUhRISKiIQqFAKCkiEK"
        "iIUBISIKSIQqIhIqQkhCoiIKRQIUAkRBSSIUFSEhCoiIilCiQhWqVKderClTXFOclGK9LfYdzal0c7ofRLYaKtL/APELbUZ3NWj1"
        "9LzafDPzuLiw+1ck8nS5FidmjNitkmvDO2079t/9w7D6Ga1Geq6zpU69OjX1PS61rbupLClUeMRz6e33HsdV0S82P0S3mka7Glba"
        "hqOpRq0LdVYzk4RUcy81tY836V6TqxNppp4aORX28rjVdqWug39tC5nZVZVLa8lN9bTi+2Hiv+noLFumzVl09pyRes9JmN/wdhbd"
        "1elo+0tgzucO0ubm9s7mL7JUqk3F58FlP2HqumKEdI31o0KknKNpYWqlJLtUJyy/oOsiQm3TZlTRxXJzN/P+Z3fQkdv3MOlapv2V"
        "a1/7Nu26/wCHddHhx8HVPGM57Vnsxjx5HVGwddjpfSJp2opuNKrdunLPzKjcXn1cWfYcW6+r1XU9bPq854OJ8OfUYE2MWj4azW87"
        "7xFe3tG/+ertDpjt6O27LRtqWsl1dGVxezS7+sqy4PcuJH6dAraLtjoqtqmu09QlHWb91oKzlGNTFJpRfndycc+1HU4ocXXdY0f/"
        "AMdcc27TvP3+/wCbsHpnt6NfcVnr1rF/BtZsaV1Fv04xh+OFH3nX5EYTO87unBi5dIpvvs7G6C1We7L1W/377m1ur7PlcUMdvie7"
        "3bHWV0c30N/TtnrELmm9NXHSdfDa4vvfLhxxf/sHT5Iyi20bNGTR8ebm7+Pbr0+/f39+js/QtHut6dE8dE0VU7jUrHVfhNS2dSMJ"
        "Om4SSkuJpY876Gfi6YKlKjfaHpMa1OrcaZpdG2uerllQqLtjn09/tRwGlVqUJcdKpOnLszF4YNuTbbbb7WxNumzKmlmuXj36bzO3"
        "3z97sCx/gO1H+u1/h0zr8iMZndvxYuDi6953IoEKI3EiIK4CREdD5okiFBUJEFQkSClCSICEiIpQoEIUkRBUKIQqFAKAhIkFKEEI"
        "VCREVCRAgoQQhUJEFQokKIqEiKqFAKMVKEiAhIgpQghCoSIKhRIUFQgIWEJEQQkKDJCRAQgKClCCEKhAQqFEhCoSIioUAoBQkQVC"
        "AhSiIQqEBCoQEKhRISSIQEioUCNIKhAQqEBQUoQQhUREFcBQgJ0PmUJIQqIhCoUAhSRCRYQoBQCiIQqIhCpCRBUhJCBCgQoKSISK"
        "iIQqEBCkiILBIiAUJCGSIiJIRQCiKSIgpJEKClEQhUREgpQkQCRCFRERFgigNBUREFIoBASIQqIhCpCSIKSIiKUKBCgsEiIBIhCo"
        "SIKSIgpJEIVISIxUkRBShQIQpIiARQIUFJEQWCREFf/Z"
    ),
    "mercado_malo": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHAABAQEAAgMBAAAAAAAAAAAAAQIABgcDBQgE/8QAWBAAAgEDAgIFBgYKDgcJ"
        "AQEAAAECAwQRBQYSIQcTMUFRCCJhcYGRFBUydKGyFzM2N0JSVaSx0hYYI1NiZnJ1kpSzweHjJDVDVqLR8CUmc4KTw9Pi8aXC/8QA"
        "GwEBAQADAQEBAAAAAAAAAAAAAQACAwUEBgf/xAA0EQEAAgECBAMFBwQDAQAAAAAAAQIDBBESITFRBRNBFCIyYXE0gZGh0eHwBiMz"
        "sSRCUvH/2gAMAwEAAhEDEQA/APn1CjCjluqyFGQokyEyFAShQIpGJKMZCSZFIEUgLCgKQFkUgQoEUKAUBKFAikBZCZCgLCjIQlFC"
        "CEEUKBFICUKBCBKFAikRZFIEJiihBCiJEEJiihQFIiUUgRSBFFIEUgJRSBCiKkUgRSBFFIEUgRRQIpESikSi0CKKQIpAiUiUUiSk"
        "KBFICpFIlFIkUUgRSAlCgRSJKQoEUiJRSBCCUhQIpAiikSikSUhQIUCUhQIURJgyIFhAQTGMKMSxjGAlGMYJJMYxiWMYxF0OhRkJ"
        "9I4zCjIUEpkUgFAShRkKAsKMKAlCZGJFCjIUYkoUCFAihQIURIoEUgLIUZCgLIUZCgRMYUBKFGQoEUICgJQmQoCyFGQoCUIIUCKF"
        "AhAlCCKQIopEotASikCFEVIpEopAlIpEotEiikCKQEopEopElIpEopAlIpEopAiikCKQEopAikRKKQIUCUikSikSKKQIURUikSik"
        "CKKRKKQJSKRKFElIpEoUwKkykShQJSFEoURVkwIQRQgYCRAwEigQgWEBMSxjGAkxjAnQ6FGQo+lcZkJkKAsikCFAShMhBMikCFAS"
        "KAUBKEyFAihQIQRQoEKAlCgRSAshRkKAsikCEExSBFIiyKQITGSRQIpEWQoyFGKZCZCiklCgQgihQIUBKEEUgRRSJRSAqRSJRSAl"
        "FolFIkpFIlFICpFIlFIkpFIlFIEpCgQoEpFIlFICpFIlFIipFIlCgSkUiUUiKkUiUUgRRSJRSJKRSJQoEpFIlCgKkUiUKJKTKTJT"
        "ECpCShRJSFAhQFSMGTJglCCMBIoBAkxjASYxjFEyBCRYxjGJdEoUZCj6VxWQoyFAShQIpAWFGMmBUjZBCSKYoEKAkUCFMxRQoBRF"
        "SElMUwSkKBMUwJQphkUBUmKYCgKkKJRSYJSEBQEoUCKQSWQoyFAWEyEEUKAQJQghRIoUZCYlikAoCpFIlFokUUgQoCpFIlFIkpFI"
        "lFIEpFIlFICUWiUKBKRSJRSIqRSJRSBKQoEKIqRSJRSBKQolFIEpFIlCiKkUiUKBKRSJQokpFIlCmBUmKJRSBKQolCBUhJQokpCg"
        "RgKsiShAqQkiBIkiCIgYCRAQLGMYxLooTIUfTOKyFGFASh7DACIoEIEoSTZJKHJGSkpPsTfqRRG/Qb7KyZM3VVf3uf8ARHqqv73P"
        "3My8u3Ycde5THJPVVP3uf9Fj1dT97n/RYeXbsuOvdSYpk9XU/En7h4Kn73P3B5Vux8yvdSYpk8FT8SXuFQn+JL3B5Vuy8yvdaYpk"
        "qM/xJe43NdqaMZpaOsMovE9JeRCmQmUmYTDNaKRCKRiVIpEopAVIUCKRiWEyFFJYpAhBFCAoCRBCglFCZCBZFIEKAqRSJRSAlFIl"
        "FIkpFIlFIEopEopAVIUCKQJSKRKFEVIpEopAlIpEIpEVIpEoUCWhRKKQJSKRCKTIqRSJQoEpFIlCgKkKBCiSkKJRSAqQolCCUikQ"
        "ikBUhRIokoUShQFSEnI5AqMAgjkSRAkQECTAJiijGRiZOi0KMhR9K4jIpAhAsKAQLGMGSBKUfNcpPhgu9hBLnKbxGPb/AMjwVa0q"
        "ssvklyUV2JHQ0ej833rdHj1Op4Pdr1eWVyo8qUEv4UubPHKvUl21JP2njybJ2aUrSNqxs5lrWtO9pVxy/GfvNxy/GfvJybJmx2Vx"
        "y/GfvNxy/GfvJybJLZXHL8Z+83HL8Z+8nJsktlccvxn7zccvxn7ycmyS2Vxy/GfvKjXqRfKpJe08eTZJP1079rlUipLxXJn7ITjO"
        "KlB8SPUZLo15UJ8UezvXieLUaHHljeI2l6sOqvjnnzh7dMtHhpzjUipweYv6DyxZ85kxzS01t1h2qXi0RaHkRSIiy0apbIUikSik"
        "YsihRkIJkUgFAShBCiRFAikYlhQFICUKBFIiwowoEUUiUUgSkUiUUgKkUiUUgSkKJRSIqRSJRSAqQolFIkpFIlCgSkUiUUgKkKJK"
        "QJSFAhRJSKRKFAVIUCFElIUCFAVIpEoUBUhRKFAlIUSikSKKJQoCpCShQFSZsgOQREMmQFSElCBKFAYCoyBCgSkYDAXRqFGQo+mc"
        "QoTIALCYwEA2JorinFeLSMojedmEzsi5nwqNJd3nS9LZ4MjWnx1Zy8ZMjJ9NjrFKxWPRw72m0zMqybJOTlvR30eXvSBqFalRrwtb"
        "S24XXryi5NZzhRXe3h967DDPqMeDHOXLO1YOPHbJaK1jeZcUybJ3TuLydnbabOvoeq1bi5px4nQuIJKpjtUXHsfgsP1nSjym0+TR"
        "o0XiODWVm2C2+3Vsz6bJhnbJCsmydj6B0QyvdPp3OqXtS3qVYqUaNKKbgmuXE33+j6Tjm8tj3m0qkKkqiubOq+GFdR4cS/Fku5/p"
        "Oxk0WalPMtXk51NZhvfy625uN5NknJsnkepWTZJybtJKybJ2Xo3Q669jCtql9UoV6keLqaUU+r9Db7X4/pOJbx2fdbRvadOpUVe3"
        "rJujWSxnHamu5rK9568uizY6eZevJ5cesw5L8FZ5vQ5NknJsnkep+3T62Juk+yXNehnsYs9JRnwVoSXdJHul24OJ4rjiJrePV1PD"
        "7ztNXlizyI8UTyxONLpwtCgRSMWRRyro12bS35uuhoda8nZwq06k+thBTa4Y57Mo4sjszydvvn2Xzev9RmeKsWvES15ZmKTMOf8A"
        "7VXT/wDee6/qsf1h/araf/vPdf1WP6xzfpp3nquxdpUNU0eVGNxO9hQfWw41wuE2+XrijpD9sfvv9903+q/4nvyxpsduG1XixzqM"
        "kcVZcm3N5Ntlt/bmqavDcVzWlY2tW4VN20UpuEXLGeLlnB110W7EpdIe5KmkVr6pZRhbTuOshTU23GUVjDa/G+g9rq3T3vPW9KvN"
        "Mu6lg7e8ozoVeC3w+GSaeHnk8M9p5M/3wrj+bqv16Z5v7V8tYpHJ6P7tMdpvPNy/9qxYf7z3X9Vj+sdc9LPRdHo1uNNjRv6l9Rvo"
        "VGpzpqDjKDWVyb7pI+id7a9U0Pc+zl10oULy/qWtWClhT46bUc/+ZxZxjyk9H+H7DpahFefp93CbfhCeYP8A4nD3Hpz6fHwW4I5w"
        "8+HPk468U8pdQdEnRbb9Jb1VV9Tq2PwDqccFJT4+Pj8WsY4PpPz9K3RzR6ONUsrKhqFS+VzQdZynTUOHEmscm/A7C8lb5W5/Vaf+"
        "8eu8qD7pdG+ZS+uzzTip7Nx7c/3eiMtvaODfl+zpdCZCeB7XcmwegS03ltKw12rrte1ndqo3SjbqSjw1JR7eL+Dk5B+1esP95br+"
        "qx/WObdB33rND/k1/wC3qHWW+enDd23936tpVlUsVbWtxKnT46GZcK8Xk6049Pjx1vevVzIyZr5LVpPR+++8l5KjKVhubNZLzYV7"
        "XEZP0yUuXuZ1DuvZ+s7K1N6frNr1NRrip1Ivip1Y/jRl3r6V3pHbfR30/axqm5LPSdw0LSpQvakaFOtQg4Sp1JPEcrLTTbS7sdpz"
        "np12/Q1ro+vbmVNO505xuaM8c480prPg4t+5eBrvgw5cc3w8phnXNlx5Ipl57vlSEXOSjFNtvCS7zvy28mS2nb0pV9w3FOrKCc4R"
        "totRljmk+LxOq+i7RP2Qb+0WycXKmrhV6i7uCn57T9fDj2n0V016/U2/0f3tS3rSo3N1OnbUpxliScnl4fjwxkatJhpOO2TJG8Q2"
        "anLeL1x0naZdZ706AaW2NsX+s2ms17yraQVR0ZUFFSjxJSeU32LL9h06j7N0yvQ3psuhVq4dLVbBKovDjhiS9mWj44vLSrYXlezr"
        "x4a1vUlSmvCUXh/SjHXYaU4bUjlJ0eW19636w5p0WdHVHpDvL+3rahUsla04zUoU1Piy2sc2vA83Sn0a0OjqppsKOo1L34aqrfHS"
        "UODg4fBvPyvoOU+TN/rfW/m9L6zP1eU19v27/Juf00x8mnsvmbc/3Xm39p4N+X7OkkdhdFvRfQ6QrbUK1bU6tk7ScIpQpKfFxJvv"
        "a8DrxHffk0f6u13/AMaj9WRo0eOt8sVtHJu1V7UxzavV1z0m7Do7A1i10+jfTvFXt1Xc501BrzpLGE34HqNq7S1beOpKw0m362ol"
        "xVKknw06UfGT7v0vuR2B5R/3Wab8wX9pM5/0B6ZQstg0rynBKrfV6lSpLvfDJwS9ij9LN0aWt9TOOOUQ1TqLUwReecy9Lpfk4aVC"
        "3j8a6ze1q/4XwWMacV6FxKTfr5eo2qeTjpk6D+KtavKNZdnwqMakX6PNUWvXz9R6HpR6Wdy2W673SNKu3p9rZS6v9zhFzqPCbk20"
        "/HlgOjfpl3DU3HY6VrdzG/tL2tG3U504xqU5SeItOKWVlrOcm7i0nH5XD8t2nh1PD5nF83X26Np6ts7Unp+rUFTqNcUJweYVY+MX"
        "3/p8T1CPpjpw0Sjqmw7q6lBOvp84V6Uu9ZkoyXq4W37EfM6PDq9P5OThjo9mmzebTinq5x0ZdHK3/Wv1VvalnRtIw8+NNS4pSbwu"
        "bXdFnPv2uVl/vDcf1aP6x7zoH0f4u2PG7nHFTUK862X28K8xfVb9ptr7xlqPSxuTSXWcreNKMKMW8qMqOIzS9Lc5f0fQdDDpsMY6"
        "eZHOzxZc+Wb34J5Q6T33tSWy9yV9J66VxTjCFSnVlHhc4yXbj15XsPQI7l8orR8VdJ1mEflRna1JerzofpmdMo5mqxeXltWOjoab"
        "J5mOLSpCiUUjzN6kUiUJJSElFICpMUSigRRRKFAVIUShQJSElCiKkKAQRFAhQEjkkUBUKBGBEUAoGREBBExjAXRyKQIUfTOIUYxk"
        "BYxjEAzUvt0P5S/SDNS+3Q/lI2Y/ihrv8Mvxt82bJLfNmyfTbuIrJ9CeTjTgtqalUUVxyv3Fy72lThhfS/efPOT6I8nD7kdR/nCX"
        "9nA+e/qef+Bb6x/t0fC/tEfe7YPjvWqNOO9L6goJUlqVSHD3cPWtYPr68vLfT7Wrd3danQt6MHOpUm8RhFdrbPi7cGpxv9wajfWk"
        "5qlWu6talLslhzbT9D5nG/o7eMmS23Lk9njXOtY+r6aPxaxpNtrmm19Pu48VKtHDx2xfc16U+ZxHow29rlC2+Ndc1LUJ9dHNGzq1"
        "pNRT/Dkm+19y9/o57NJY8T9YweP4NRmjTcM+9y+T8lyaimLUeVS2+3rHd8167o1zt/VK+nXa8+k+Ul2Tj3SXoZ+DJ3l0jbQW5dL+"
        "EWtNPULVOVPHbUj3w/vXp9Z0W8ptNNNdxztdpZ0+Th9J6PsdFqoz49/WOqsn7tBjGprmnQmk4yuqSafeuNHr8n79vP8A7f0351S+"
        "ujy4/jh6cnwy+lDr7pnjH4gsptLiV0kn4Jwln9COwTr7po+52z+dr6kz6/xD7Pf6PlNB9op9XT+TZJybJ8bu+uUnzR7xfKfrPQp8"
        "0e9Xyn6zleKfBV79B8UvNE8sTxRPLE4UutDyIpEopGEs1I7N8nb759l83r/UZ1mjszydvvn2Xzev9RmzB/kr9WvN/jt9H0P0m7B+"
        "yNt6lo/xj8X9XcxuOt6nrc8MZLGOKP43bnuOrf2qX8cP/wCb/mnYPTTvPVdi7Soapo8qMbid7Cg+thxrhcJt8vXFHSP7Y/ff77pv"
        "9W/xOhqLYIv/AHI5vBgrmmnuTyeXpI6C/sfbbetfsh+H4rQo9T8D6r5WefF1kvDwPL5M/wB8K4/m6r9emcc3d0wbn3tpD0nVp2cr"
        "Z1I1cUqPDLiWcc8+k5H5NH3wrj+bqv16Z5KTjnPXy45PVaLxht5k83PfKUvKunabty9oPFW31B1YPwlGOV9KOf7xs6e7+jzUqVBK"
        "cb7T3Vod+ZcPHD6VE658qP7n9E+dz+oc06FNY+OejTRpyeZ21N2k14dXJxj/AMKie6s75r0n1h45jbDW8ekuuvJX+Vuf1Wn/ALx6"
        "/wAp/wC6XR/mUvrs5T0FaP8Asf3dv3S1HhhbXVGEF/A4q3D/AMODi3lP/dLo/wAyl9dnmvG2k2n+c2+k76rf+dHS4owo5bpPrnoO"
        "+9Zof8mt/b1DqTf/AEP731vemsalp+iddaXNzKpSqfCqMeKL78Oaa9qO2+g771uh/wAmt/b1D1O4un/QNt65e6Pc6XqdWtZ1XSnO"
        "mqfDJrvWZZO1kpjthp5k7Ry/05FLZK5beXG/X/bhHRx0D7itdx2Gq7ghQsbayrRuOpVWNSpUlF5ivNbSWUs8+z6Oyum/XaGi9Hmo"
        "06k0q1+la0YZ5ycn53uipfQcQ1HyndMhRfxboF5Vq45fCasacU//AC8WTpzeW99Y31qnw/Vq6ahmNGhDlToxfdFfpb5s898+HDjm"
        "mKd5lvrhy5ckXy8oh2T5M2idfreq6zOPm2tCNvBvs4pvLx6Uof8AEft8pvWs1tF0SEvkxnd1I+vzYP6JnMugHRPino9t7iceGrqF"
        "apcyz28OeCPsxHPtHfHQtYb616esXmsXlCbpwpRpU4RcYRivT6W37TbGG86WKUjnLXOasambW6Q8Pk96z8ZbAjZylmpp1xUoYfbw"
        "vz0/V5zXsOnOmvRfiXpF1Lhjw0rzhvIenjXnP+mpHfnR30Z2vR075WepXN3TvODihWjFKLjnDWP5T+g4B5TGi5o6NrcI/JlO0qPH"
        "j58P0TMdRit7LEW61ODJX2ieHpL8Pkzf631v5vS+sz9XlN/b9u/ybn9NM/J5M04rWtahnznbU2l6FJ/80fs8puEus27U4Xw4uY59"
        "P7ma4+xfzu2T9s/nZ0gjvvyaP9X69/41H6sjoNHf3k0QktL1yph8Mq9KKfi1GWf0o8vh/wDnj7/9PRrf8MvQeUh91mm/MF/aTPb9"
        "A/SHp9pYfsW1OvC2qKq52lSbxGfFzcG+6WcteOcdvb6byj5xe79Ogn50dPi2vXUn/wAj82h9Ams67o1lqlDVtOhSvKMK0YyU8xUl"
        "nDwu03TOSNVa2KN2qIxzp61yTs7g3j0Ubc3pcSvLulWtr6SSlc20+GUkuS4k8p8uWcZ9J13qPk+atpVaF9t3XKVevQnGrShXp9VO"
        "MovKxJNpvK70jgmn9IW8NnXVXT7bWq8oWtSVJ0q2KsPNeMJTTwuXdg59tXyh7mV1SttyWFB0ZyUXdWuYuGe+UW3leOGvUzOc2lyz"
        "78bSwjFqMUe5O8OE7q3Lv6y6/Rdx3uoU41Y8M6NZLhqR9DSxJelM4hSpzq1I04RcpzajGK7W33H1X0obbtdybM1GFWjGdxa0J3Nt"
        "NLzoziuLCfpxh+s+feizR/jvfmkW8o8VOlW+EVPDFNcXP1tJe08+q01q5YpM779G/T562xzbbbZ9L2FChtHadGlNpUdMslxvxUIZ"
        "k/bhs+a9g7hq2XSJp2q15+dcXbjWl3PrW4yb/pZ9h9Nbj0Zbh0O80mVxUtoXdPq5VIJOSi3zxnxWV7TrWHk7aTCSlHXNQjJPKahD"
        "KZ0NXgy2tTy45VeLTZcda28yecuTdMWj/G+wdQ4Y8VS04buHo4H5z/ouR8xI+y7m0heWNWzuH1kK1J0qnL5Sawz481GyqaZqF1Y1"
        "vtttVnRn/Ki2n+g8nitNrVv3enw2+9Zr2eBFIlCjkOmpFIlCgSkKJQpkloUShQFSFAhQFSElCgSkKJTFAVIUShRJQkigKkKJQglG"
        "QIUDJSEkQREEIEmAxiXSSFAhPqHDJkYyAsAmJIZqX22H8pCwp/bYfykbcfxQ1X+GX4G+bDIN82GT6NxFZPofydKtOjszVKtWcadO"
        "F9OUpyeFFKlDLb7kfO2T3FHeWo2e06+2bSfU2lzcu4uJxfnVVwxSh6I+bl+PLw58zxfRW1mDyaztvMfg9Wjzxhycc9nMOmHpYqbx"
        "upaPpNWUNFoT5yXJ3c1+E/4K7l7X3Y8vRd0cfCHS17WaP7ksTtbea+X4TkvDwXf29mM/l6MOjj42nT1vV6X+gxeaFCS+3tfhNfi/"
        "p9Xb2/qWo2mj2FW9va0aFvRjxSk+70LxfckaIrj0uONNp45R/PxfH/1D47fLedPhne08pmP9R/PzePWtastv6dV1C/qqnQpL2yfd"
        "FLvbOuthbv1Hd2+ry6rt07SNnONKgn5tJccMeuT55f8AcjhG8N26hvzWadOjTqq3U+C0tY83l8stLtk/o7Dld7oNx0b7OtL6lOK1"
        "WV9Sq1prmliE/wBz9Kw2n45foO54PpJxX9otHw85/Rq0fhVdLi2y/wCW/KPl/PWXbR090rbO+Lrp67ZU8W1xLFxGK5U6j/C9Uv0+"
        "s7O27r1tuTSaGo2rxGosThnLpzXbF+r9GGfsvbKhqNpWtLqmqtCtFwnB96Z9lqcFNVh2j6xLXp819Nl3n6TD5hyew28/+39M+d0v"
        "ro/Ru3bdxtbWatjVzKk/PoVX/tIPsfr7n6Ufl26/+8GmfO6X10fIxS1MsVt1iX1U3i+ObV6TD6XOvumn7nbL54vqTOwTr3pq+5yy"
        "+eL6kz63xD7Nf6PltB9op9XTmTZJybJ8Y+uWnzR72Pyn6z0CfNHv49r9ZzPE/gq92g+KXngeWJ4oHmicKXXhaLRKKRrlmpHZnk7/"
        "AHz7L5vX+ozrRHvdmbvv9ja9S1rTaNtWuaUJwUbiMpQxJYfKLT+kyxWit4tLHJWbUmIfWfSjsKp0i7cpaRTv42Lp3ULjrZUusTxG"
        "SxjK/G+g6p/arXX+9VD+pP8AXPTftn95fkzb/wD6Fb/5R/bPbx/Ju3//AEK3/wAp78mbTXnis8NMWopG1X7tW8mW50rSry/e5qNR"
        "WtCpXcFZtcXDFvGePl2HrPJo++FcfzdV+vTI1Hyj926pp91YVtO0KNK5ozozcKNVSUZJp4zU7eZwvY299R2BrM9W0ujaVq86MqDj"
        "cxlKHC2m3iMovPmrvPPN8NclbY+kdXoimW2O1b9XdvlR/c/onzuf1DxeS7rHWaTrWjylzoV4XUE/CceF4/oL3nVm/OljXOkSztbT"
        "VbXTaFO1qOrB2tOcW21jnxTlyPwbE37qvR7qdbUdKp2tWpXouhOncxlKDXEnnEZJ5WPHvZlOpr7R5kdGMae3keXPV9W6Ltytpe+d"
        "yauqSVtqtCzlGakudSmqkZrHasLgfg+L1nTHlP8A3S6P8yl9dn4/2zW8PyboH/oVv/lOFb76QdU6Q762vNVt7KjUtqTpQVrCUU1n"
        "PPilLmZajU4rYppT+c2ODT5K5ItZxkUZCcx0H1x0Hfet0P1Vv7eofOfSp98XcHzyZ7ravTnuTaGgWuiWFlpFS2tVJQlXpVHN8U3J"
        "5aqJdsn3HC9f1q43HrV5q93ClC4u6jq1I0k1BN+Cbbx7T26jPS+KtI6x+jyYMNqZbWnpL8CPLbW9S6uKVvRi51as1CEV3ybwkeI/"
        "douqVNE1az1OjRo1qtpWjXhCsm4OUXlZSaeMrxPDG2/N7J+T7LtqVttHatOm2lbaVZJN/wAGnDm/oPnV+ULvZt4qacvR8G/xPHuD"
        "p73RuPRbzSLm00ijQu6bpVJ0KVRTUX24bqNc+zsOuEe/VazfaMU7RDxafSbbzljeXcO0unrc9/ubTLPVZ2Tsri5hRrcFDhaUnw5z"
        "nuzn2Ha3THovx30d6tTjHNS2gruHo6t8T/4eJe0+SoTlTnGcJOMovKa7UztOt5RW6rm2qW1bTdCqU6kHTmnRq+cmsP8A2hYNZHBa"
        "maeqzaWeOtsUdHo+h3dtDaG9be4vKqpWV1CVrXm+yClhxk/QpKOX4ZPozfmxdP6QNFjY3dWVGpTl1tvc01l05Y8O9NdqPj05ztHp"
        "i3VtG3p2dC5pXtlT5Rt7uLmoLwjJNSS9GcLwMNLqq0rOLLG9ZZ6nTWtaMmOdphyePk27h+GcEtX0tWv76uNz/o8P953PszaGm7A0"
        "D4vtajcIt1ri5q4TqSxzk+5JJLl3Je06hflL6n1WFt6z6z8br5cPux/ecN3d0tbn3lRla3d1TtbKT521rFwjL0SeW5epvHoN1c+l"
        "w+9jjeWm2HUZfdyTtDxdKG6ae7953uoW03O0hw0LdtYzTj3+18T9p3X0Fbvtta2nS0apVir/AExOm6b5OdLPmyXilnhfq9KPmhH6"
        "9N1O90e9pXun3NW1uaTzCrTlhr/D0Hjw6u2PLOSfXq9WXTRfHGOPTo72370D1Nd1i51bQb62t53U3Uq21wpKCm+2UZRTfN88Y7X2"
        "nqdseTzqNPU6NfcF9ZfA6UlOVG2lKcquPwW2kop+PP8AvPw6V5Rev2tBU9R0yyvpr/axbpSfrxlZ9SR5r/yj9YrUZQsdFsrao+yd"
        "SpKpj2eaeub6Kbcc9e3N5opq4jgh2f0rbotts7Nv+OpFXV7SnbW9PPnSlJYbXoinn3eJ115OWj9Zf6trM48qNONtTb8ZPil7uGPv"
        "Oqdd3Dqm5r+d/q15Uuq8uScnyivCK7EvQjkuzelfWdj6VPTdMstMqUp1XWlOvTnKcpNJdqmljCXca51tL54yX5RDZGktTDNK9Zdq"
        "9MHSVqmzL/TrHR5W6q1aU61brafH5uUo48OyR199nneX75Yf1f8AxOJ7t3ZqG9NYeq6jChCs6caahQi1CMV4Jtvvb7e89MjRn1uS"
        "2SZpaYhtw6SlaRF6xu+o+ijed3vXblW71B0vhlC4lSqdXHhTWE4vHtx7Dprpp0j4q39eTjHFO9hC6j7ViX/FGT9p6vZPSLq+w1dx"
        "0ylZ1o3fA5xuYSkk45w1wyWO1/QRvTfmo77r2tfUraxo1LaMoRlbQlHiTafPik+zHL1s2Z9VTLp4pafehhi01seebV+GXHUKBCjm"
        "PepMpEIpElIUShQFSKRKFAVIUShTBKHJKYpgVIpEocglCiUKAqQkoQKhRKKREoQMgShRImJIgKAkwGJOlEICj6dw4JhMRAMolkks"
        "IfbI/wApCwh9sj60bMfxQ1X6S9Y3zZskt82EnyPo3Facu5HPOjXo7luOtHVNTpyjplOXmwfJ3El3L+Cu9+zxx6zo42hT3drbp3Mn"
        "GztoqrWSeHPnhRXhnx8EfQH+i6ZZ/wCytrW3h6IwpwS+hJHh1Wo4fcr1fNeO+Lzg/wCNh+Oes9vp8xc3NrpVlOvXnTt7W3hmUnyj"
        "CK/67DoHf2+rneN+qVBTp6dRlihR75vs45el9y7vfn9PSL0g1d13TsbGU6el0Zeaux15L8J+jwXt7ezi9hRqW+r29KtCVOpC4jGU"
        "JLDi1LDTXiOk03DMWv1leC+D+z19ozx7/pHb93cvRv0fQ25QjqWo04y1OrHlF81bxfcv4T737PHO6ZfuTpfO4fVmc7OB9M33JUvn"
        "cPqzPvdRgph0lqUjls06fNbLqq3v13df9He8ZbX1bq7ib+L7pqNZfiPumvV3+j1I77jKM4qUWpRaymnyaPlbJ2/0Sbz+GW62/fVP"
        "3ejHNrKT+XBdsPWu70eo5nhGt4Z8i88p6fo6Hiuj3jzqdfX9XKN87Tp7r0aVGKjG8o5nbVH3S74v0Ps9z7jo3Q6NS33Np9GtCVOp"
        "TvaUJwksOLU0mmfSp15vrZnFr+m7isafNXdFXcIrtXGkqn9z9j8T2eJ6LjmM1Osdfp+zy+HavgicN+k9Pq7DOvOmv7nLL54vqTOw"
        "zrzps+5yy+eL6kz1+I/Zr/R5dB9op9XTWTZJybJ8W+vUnzRyGHb7TjifNHI4HM8T+CHu0PxS88DzRPDA80Th2daHkRaIRaNcs4Uh"
        "RkIEoUAoxJEBQEopAikRYTCgTIoEISmKBCBKFAhAwRQIpAWFGFBKZFIEIEigRSBFCgFAVIUSikBUikShRJSKTIRSAqRSJQoEpCiU"
        "UmRUmKJQoxSkUiUKIqQolCmBUikSmKBKQolCgKsigQoEpCSIEopEoUBUhJFAlIUSIHZQokUBUjAKAlGAwJ0sKBFI+pcNjCASmBiZ"
        "ikMmPy4+tFMmPy4+tGzH8UNd+kvUt82D7Ab5s2T6Jxdnu9o7svNoap8OtYQqxnHq6tGbwpxznt7ny7T228uk3Ut226s40Y2NllSn"
        "ShNydR93FLCyvRj+44ad5+T7srQNa0m51rUtOpXd7bXrp0ZVW5RglCLXmZ4W8t82mc/xDU4tJjnU5K77NeLwrDqdTGThjj7vJ0J9"
        "Ebi6G6dwWzT5TsbWouzwqyX1V7fA6q1x/wDf3UP51qf2zPsk+NNbf/f6/wD51qf2zOJ/T2vy6zV5MuTtG0do3dnxLT1w4a0r830c"
        "cC6Z/uSpfPIfVmc9OBdNH3I0vnkPqzP2HX/Z7/R+c6H7RT6ukMnmtLuvY3NK6tqkqVajJThOPbFrsPBk2T4mJmOcPsJjflL6Q2bu"
        "mhuzRad5DhhcQ8y4pL8Cf/J9q/wPedp857I3ZW2lrULrzpWtXELmkvwoeK9K7V7V3n0RbXFG8t6dxb1I1KNWKnCcXylFrKZ9j4dr"
        "PaMfvfFHX9XyniGknBk5fDPT9HlOu+m37m7L54vqTOxDrrpu+5uy+eL6kzZ4j9mv9GvQfaKfV0xk2QybJ8U+w2UnzRySmcZT5o5P"
        "T7DmeJfBV7tD8UvPA80DxQPLA4curDyItEopGEtkKQoyFGKKEEIEigRSAlCCKAsKBFIkwmFGJKEBQIiCEmRQgUCZCjIUYkoQFAih"
        "QIoiwoCkBKFGQmJZCjCiRQoEIFSFElIEpCiUKAqRSJQoEpCiSkRKZSJRSBFFEoUBUmKJQoEpCiSkBKKRKECpDklCgKhJTEEpCShA"
        "qFEoUBUZAKAlGMjAnS6FGQn1ThMZGFAQDKAghkr5UfWW0Q+TybKTtMSwvG8bPSN82bI148FacX3SZGT6HdxVZPo7yaJxe0NTjlcS"
        "1Btr0OnD/kz5vycx6N+kvUOjvUKtSjRjd2NzhXFtKXDnHZKL7pLn6H7muV4zpL6rS2xY+vKfwerRZq4ssWt0fXp8Ya3Wg9839VSX"
        "VvVKkuLux1r5nam5PKVdzplS30DSatrd1Y8Pwi5mn1WV2xiu1+DfuZ0bKcpycpNylJ5bfa2cz+m/Ds+km+TNG2+20PV4nqceaIrS"
        "d31gcA6apKO0qKbw3eQwvHzZnH9v9Nc7Swhb6xY1LmtTjwqvRkk5pdnEn3+n6Di2+N+3e8q9OMqStrKg26dFS4m3+NJ97/QfqGs8"
        "TwZNPNaTzn0fEaTw7NTPE2jlHq4xk2ScmyfLvo1ZO0eiDenUVVty/q/udRt2k5P5Mn2w9vavTnxR1ZkqFSdKcalOThOLUoyi8NNd"
        "6PRpdTbT5IyVefU6eufHNLPq8646cJxW3bGGVxO7TS8UoS/5o9ZonTfGjYxpaxp9WtcwWOuoSSVT0tPGH6voOGb23td7yvoValNW"
        "9rRTVGgnnhz2tvvbwjv67xPBk081pO8y4mi8PzUzxa8bRDjuTZJybJ8w+jUnzRyml2I4xQi51oRXfJHKaawkczxKfdrD3aGOcy80"
        "DzQR4oI80Tiy6sLRaJRSNbOFI5ZsbY1PeFHUK1XVFp8LJU3Juj1ikpcX8JYxw/ScUR2H0cNx2fvVptNWcGmu7zappzWmKb1/nNnS"
        "Imebim6tv1Nr67c6VUrdf1PC41eDh404pp4y/Hx7jleidE/xroVtqVXWlbVrihO4jbfBuJ8EX28XEvGPd+EPSbby1urtzWreOZ6r"
        "aQptL98TXL1+fj2HO6FenR3VcaLQa6nS9CVJLwk3H/8AyoHmvmtwRtPP1+5srSN5dCIpHOOj/adlf6Vf7g1GyutSo2k1So2VvFyl"
        "WqYT5pc8Lij9Oew99T23Zbysbyg9n3e29QoUnVt6vVzjSq4/BeYpZ7PT3+KNts8RO3ZjFJmHVSE59svRtvV9marq+uWk6ytLiPnU"
        "5NTcfM8xc8c28e08OjaPou+N0Ys7Gek6Va23W3EFUc5S4X25fZnK9zKc0c+XRcLhCFHYVpuLY2oX0NKq7Yp2lhUl1cL11mqke5Sl"
        "3pdmfOePSek0rS9At941LK/up3umUpS6uVtFzdx+KvN59/PHgXmdd4lcPzcZKR2xpukaduupW0uvsa60OnKnKVC+4JJxa7MtxSfv"
        "f95xTYu17LVbrUbvWJSVhpVPrK8IPnN8+WVzx5suwx86NpmfRlwS49pFh8a6rZ2HWdV8Krwo8fDnh4pJZxyz2n6NyaL+x7W7rS+v"
        "+EfB5JdZwcPFmKfZl47fE5noOu7V1vcdhbw29HSqkbiEra5o1ctyjJOMZxxjzsY78Z9pGqbcW6elW+0+dSVOjxKpVlH5SgoR7PS2"
        "0vaY+bMW97lGx4eXJ18KOevcWyY3z0v9jFN6cp9V8N619bjs4/HHf29nuPQb123Ha2vVbCnUlUoSiqtGUu3gfj6U017DKuTedpjY"
        "TCdn7Ze7NWenq6VrilKpx9Xx9jXLGV4npmuGTXg8HN+h77rZfNan6Ynq9n0dGnqF1U1a2ub2VOm5W9pRhKXXT8Hw9nd6OfoMZvMW"
        "n5bGI5Q44j2m3tv3e5NQ+A2TpKrwOeakmlhex+JzqpolnuXRtSc9pV9v3VnRdehV4JRjVwm+F5is9np7ck9FWp6ZU1KjZU9GhSvo"
        "UJud917bms9nBjC7V39xhbL7szEc4ZRXm63nBwnKD7YvDMjlNdabu3XbHS9M0eGkznXlGrVjWdXjXe8NLGEm/acourDStIvHpVDY"
        "eoX9nTfBUvXSm5zffKL4efsa9GBnLty25iKur0Jze72fZ6T0gWGlyjKtYXTjUjCplPgeVwv1NP6CN4T2vpdS/wBI0/SKjvIzx8Kl"
        "VeKbym4xjnsS5F5kTMRB4XDEUjnumfE1npdn8XbTu9wVpw4rmvOlPhjLvS81r3fSz1u/dAtdIuLG8s7epaUr+j1rtqmc0Zcsx581"
        "2rl3cwjJvOy2ev3Vtp7YvLe2d0rnrqEa/EocGMtrHa/A9Mc16Vf9cad8wp/Wkeq2Jp1rqu6LO0vaKrUJqpxQbaTxCTXZ6UFbe5xS"
        "Zjns9AhP33tvSpa7cW8IKNKN1Kmo+EVPGPce36QtLs9H3FK1saEaFHqYS4Itvm8+Jlxc4hbONFI95svb0Ny63C0qzlChCDq1XHtc"
        "VhYXrbRy+hZ6Xf3q0upse/tbKcurhe9VUU49ylLMeS9bfpMLZIidjEOtUKObba2raU973mjahSV1RoU5uPFlZ+S4vl6Geq1m62/V"
        "VGx0nTalKVOslK6qVG3Wisp8u7Lwy4952hbOPo/bpGl19Z1K3sLdfulaXDnuiu9v0JZZzTdtDam27upaR0ade5q0eKOKrUKOcpNc"
        "+bysn4Nvx0m30elVoaBc67qM5vrY9XPgpLuSwmn/APvoMOPeN4g7OOaxY0dM1GtZ0LtXcaT4XVjHhTl3pc32eJ5qWhXdXQ6utRdL"
        "4LSq9VJOT4uLl3Y7OaOQ7p0ixtbLTNep6VUsY1qvBcWFTMexvlzWVlRfd3pnubbWNIlsa6u46BCNpG6UZWnwhtSl5vncWMrtXLHc"
        "E3naNjs4btrbv7IqtzT+HULTqKXWZqfhf4eL7j1HYcu2pZaXr+r6pOenQpW8baVSlQ6xyVNrC7eWe8/PtXRdPq2F7rerqc7KyxFU"
        "YPDqzfc37V7x4tt91s42hRzK2vtr7jjWs6+mUNFqKDlRuY1fNTXdLksn49raHYVLK+1nV+KpZ2PmqlTf22fhnw5r3hx91s40hRzb"
        "S6u3t33D0t6PDS7icW6FahPPNLOGsLPJf/hw65t52lzVt6mOOlOUJY8U8MotvyKEKJQoUpCgFAShAUBKKJQoEUUmShAqRgQoCpGM"
        "KAsikCKRJkYTGJdLoTGR9VLglGFGAgzKDBJDRDR5GiWjKGMvValS4aiqrslyfrPxZPe1qUasHCa5P6D0tejO3nwyXLufidrTZovX"
        "aesOVnxTS2/ojJshk2T0NBybIZNkkcmyGTZJHJshk2SRybIZNkkcmyGTZJHJshk8tvbzuaihBet+BbrZ+3Rrd1a/Wv5MP0nIII/N"
        "aW0bakoQXJfSfrgjg6zN5l+XSHY02Lgrz6vLBHlijxwR5Yo8MvZC0UgRSNcsijnWwtRsrPam76Fzd29CrcWsY0adSooyqvhqcopv"
        "m+a7PE4MhML14o2ZVnad3a+x77RtV2zo1vquqWNnW0bUXWjG5rxhKcEnJYTfNcUl/RPDtXcllcb13PqN3fW1Clc0KsKM6tWMFNKS"
        "UUm3zfCkdXopGmcETvz6s4vPJ2D0e6/a/EGpbauNWno9e5qKta3kZuHDPEU05JrC81d6ymz9t3aXegabd3GtdIF3WuOrfwW3sL+c"
        "5Tl3OWX2f9ZOskJTh97eJ6mLcnN9D1CzpdGGv2VS7t4XVW4pyp0JVEpzSlT5qOcvsfuPx9HW4rPb2s1fjHiVleUJW9WUVngy1iWP"
        "Dlj2nFUUhnHExMT6ji6Of2XR/pFreR1C+3PpNbRqc+P9zq5q1YrnwuK7G+zk2zybF1nQLTduqTt+DS6NxSlSsKtZ8Sovlzbk3hvG"
        "eb9GTr0UYzimYmLSYtt0h3DoOoXO3NZhU3NvK1vIV04UqNG4c4RbWeOfJKK5YXpfoPRbevtJ0HWdd0HUdSt61hqtPg+G201KnFtS"
        "xz9U3z7mjrxCjDyI58+p43YmlbR0jbOtWWp6juXTri3hcU5W8beacqj4liUueIxT5t5fJGluuy0bpSvNU66FewrYpTq0ZKa4XCPn"
        "LHbhpdngzrxCh8rfnad/Q8XZzx7C0Z37vVujSlozqcX2791Ue3gx445fTjuPUb+3FQ3LuGd3aJ/BqVONCk2sOUVl5x3c2zjYoa02"
        "neZ3Ez6Q5l0VX1pp255Vr26oW1L4NOPHWqKEc5jyyz93R1qNrRsdZsaWoW+m6pcpfB7mthRws8sv0/p78HAUKMbY4tv8zFtnbmjX"
        "vxZ8O0zcO7bW7uryhOFPFdzo0OWPOk8Yk89nhF+JxbYV3Zbc3pKF5fW7oRjUoK5jLNKT7nxeDx2nDRMfK5TG/U8Tlip0Nl7nsNSp"
        "6nY6nS62U5fBKim4w7HnweJPHqOUajZXOr39TU9L35G30utLrJRnezhKhntSjlexPGDqxFIpx789+aiXM6Go2UekGxqQ1i6vLK3q"
        "qKur6tnCw84k+yOWel3dXpXO59SrUKsKtKdeUozhJSjJeKa7T0xSGKbTud3bGr3NfWaNndbe3TY6ZplOhGM6E63VSpNehLPZyw8d"
        "npPUb8utO13RNOvLPWKFxOyg6U6dWeK9VtxXFw9v4Ofadfoo1xi2mJ3PE5f0lX1rf6rYTtLmhcQjZQhKVKoppS4pcnjvPU7P1ajo"
        "e47K/uM9TTk4zaWcKUXHPszn2Hpy6LhGrB1IucFJOUU8ZXejLhiK8K357ud3m2dFWrz1mW4rKrY1K/XqjSalWk3LPAln2Z95+PpU"
        "+6uX/gU/7xp67sinOM47YulKLTX+lTfP+kem3Tr73LrFTUOp6mLjGEIZy0ku9musTxbyZ6P2bC16ht/Xo17tuNvWpyo1JpN8CbTT"
        "5elI5MtKuaVy7q437P4pzxKUL6fWyj4YzjPv9R1uKMrU3neFEubbJ1W0pbzuru51GToSpTjC4vaqUprMVHLffhHEKTSuoSbSXGnn"
        "2nhFFFdp3TlXSPeW19uR1rS4o3FPqYLjpTUo558so5DQuKuqbY0uhoGu2emTtqXDdUqtXqm5YWZZSb7cvweTrVCjGacojsd3Ye4b"
        "mx1faULSOvW9zd6fUc6k61TErhpPPBnm152F6j8W3Z2OpbLvdGq6laWNzK5VWLuZqEWvN736mcKKQcHLY7uZbJqWmj6tq1G4v7Tg"
        "VtOlCr1qUKjyvkt9uTwbV1Kwq6PqG39RuFawu2qlKvL5MZrHb/RX0nFUJTVOZWu2dH0KFW91zUrG+pKD6m2tarcqrfY8rD/u9J4t"
        "ranp9bS9R0HUays6V41UpVXzjCaxyfuj7nzOJopBNe8lznRdJ07aN58bajrFlcOlCToUbWfHKo2sZ9zfo9PI4beXMr28r3U1iVap"
        "Ko14NvJ4RRRG3NFCgQoZJQowoxlMKMhRFikAoxJQoBRSoKFAigLCgRSAlCgRQJjCYC6XFAikfVOEUYyEEDYFGBJaJaPJgloRLxNH"
        "irUY1YOE45X6D9LRDibKXms7wwtSLRtL1FbS6kW3SfGvB8mfklRqweJU5r2HIXEnhPdTXT/2h5LaSP8ArLj3DLwfuNwy8H7jkPCz"
        "cLM/bq9mHsk93HuGXg/cbhl4P3HIeFm4S9ur2Xsk93HuGXg/cbhl4P3HIuEVAvbq9l7JPdxzhl4P3G4ZeD9xyTgFQL2+vZeyT3ca"
        "4ZeD9xcaFWbxGnNt+g5Iqa8Co00u4xnX19IMaOe701vo9ao06v7nHw7z3Fta07eChTjg8sYHljE8efVXycukPVi01ac/UwieWKCM"
        "TyRR4pl6ohcUeSJMUWka5bIUhSBFxRiShA99omx9w7htfhemabOvQy49Y6kIJtduOJrPsMLWivOZZREz0ejQo5YuineP5H/OaP64"
        "roq3j+R/zmj+uYedT/1H4suCeziiE5X9iveP5H/OaP64/Yr3h+R/zmj+uHm0/wDUHhns4ohRyv7Fe8PyR+c0f1x+xZvD8kfnNH9c"
        "PNp/6hcM9nFBRyr7Fu7/AMkfnNL9cfsW7v8AyR+c0v1w82neDwz2cVKRyn7F27/yR+cUv1x+xdu/8kfnFL9YPNp3hcM9nFkKOU/Y"
        "v3d+SPzil+sP2L93fkn84pfrF5tO8Hhns4shRyS46ON1WlCderpM+CCcpcNanJ49Sk2zjaGLRPSVtMdSKMhJMKMKBFCZGAlFIEKA"
        "lCAgShMhBMhRhIsikCFGKIoEKAlCgQoiUUgQoCUICgRRQIQLFIEKAwUKBCCKFGQoCwoyFAWRSAQRFAhQEoTGQEopAhRIoTCYlkYU"
        "YE6XRSBCj6pwihBCgTGHBiLYDBRsAtkOJLieXAYHcbPFwhwnm4TcI7jZ4eE3CebhNwlutni4B4Dy8A8BcS2eLgNwHm4BUA4js8Ki"
        "UoHlUBUA4lwvGoFKB5FEpRDiZbIjE8kYiolxiYTLKIaMTyRRkikjCZZRBSKSMkKMZZFFolIoxLHYGzulittbRaelVNKheU6UpOnN"
        "VuraUm20/NeebZwBCjXelbxtZlW0xzh219nn+Lv57/lj9nj+Lv55/lnUyE0+y4u3+2fmW7u2Ps7/AMXvzz/LH7O38Xvzz/LOp0Ui"
        "9lxdl5lu7tf7Ov8AF788/wAs32df4vfnn+WdUiHs2LsfMs7W+zp/F788/wAs32c/4v8A55/lnVSFB7Nj7LzLO1fs5fxf/PP8s32c"
        "v4v/AJ5/9DqsS9mx9jx2dqfZx/i/+ef/AEN9nD+L/wCef/Q6sFB7Nj7Ljs7OuemytUt6kKGiQpVZRajOVzxqL8ccCz7zrNAikZUx"
        "1p8MKZmerITITMMikCKQFhQFICyKQIUBIoCkCYUYQLITCgTFAhCSUKBCCKFAUgLIpAhCSRQIpAmQmFAShQIUUkoUBSMZTITIURZC"
        "jIUBKFAKCVBFAigLCgKQEoUCKQSmFAUgJRjGAul0UgQo+qcEoUCFASjYMikBCE2DIE2DYFDgt1sMGwVgcBudk8JuEtI2C3WyeEeE"
        "pIUg3WyeEVEtIUg3OyFEVEtIUg3OyVEpRKSFINzsFEpIUhSCZOzJFJGQoxJQpGSKQIoxhQSyKFAikCKEBAlCgRQSmFGFBJYTIQMF"
        "CgECRBCgRFAikBYUYUCKEEJEoUCKRiShQCBKFAigTIUYSLCZCgTFIBMSUKAURKFGQoCUICgRQoyECwoqk4RqQdSLlBNOUU8ZXgdj"
        "XVpsujtChuGO3blK4uJW0aXw2eYtKT4s9/yew24sXHvziNmu+Tg25b7uuUKOS7C2/Za7qF3PUusdnY2s7qpCm8SqcOPNz3f4H79X"
        "0nQdV2fV3DothX02drdK3q0J1nVjNNLDTfPPNfSVcFrU49+/5K2aItw/zm4YKOd0tn6bd9G1PV6FKS1VRq15PjeJ06dXhly7OSaf"
        "sPWby2/Z6ZrGm2Wn03SjdWdCpLik5efNtN8/YV9NeteKflP4iuetrcMfP8nGBR2itqbSluaWzVYXivY0c/GPXv5fV8fyOzGDjOy9"
        "v2Wt3Wr6Zd0nO8haVJ2s4zaSqx5di7e3v8BtpLxaK7xz3j749FGprNZttPf7p9XFUKOTWmi2NPYN5rV1Sbu6l3G2tJcTSWEpSeOx"
        "8uJc/A/Z0dbd0vWKl9da1TlOyt1SpJKbj+6VJqMXle33muunta1ax6xuytmrWs27cnDikfu1/TXo+t32ntNK3rThHPfHPJ+7B+FG"
        "i0TWZiW6sxMbwUJybo+0aw1vWLihqNCVejStKlZQjNwblFxxzXrZ+3VdE0e82jV12y0660itQuI0eorVnUjWTx8lySeVnPsZurp7"
        "WpxxPf8AJqnPWt+CY7fm4ahRy/RNK0TT9pPcOs2VbUHVu/gtKhCs6aXmt5bXPufuR4d36Jpuh6pp1xZ06stPvbendKhOfnRi+2Of"
        "V3+kJ09opxzMen5mM9Ztw7fyHGEJ2FRttnVdrVtfW3rlQpXStup+GTy3wp5z7Tgd3OhVu607Wk6NCU5OnTcuJwjnks9+F3mObD5c"
        "RPFE79t/0OLLxzPKY2eJCjIUedvJjIxJ0whQIT6lwShQIUUkoUCFAShMhAtg2BQoEBQjgCyFIyRSQIYFDgUgISFIUhwElkhRkikg"
        "IwKFIUgQRSRkKAskUgQoEUUgQgWFGQoCUUgQgSKAUSKExjElCZCgTCjCRYpAKAkUAoCUJkISmRSBCgRFAKBkUUgQoERAUBIoCgTI"
        "UYUBYTIUBZFIBBFCgQoCUUgQhJIoEKBFCYyArpU5VakacFmU2opeLZ2rfbG3C+jWy0r4v/02hfSuKlLrqfm0+GfPPFh9q5ZydUoU"
        "bsWWtInijfeNuv7S15cdrbbTtt8v3c26LKtKeo6pp06tOlW1DT6tvQ43hSm8YX6fcfv1HSbraXRtdabrCp297fX0alKgqkZScYqO"
        "XybWOX0rxOvFlPK5Hu7vdFbUduW+jXlCNeVrUc6F1KT6yEX2w9K/w8DZjz1jHNZ67Tt97XfDabxaOm8b/c5toep09L23s2dfDtri"
        "4u7aun2OnUm4vPoWU/Yeu6T4R0zd+lwnJyjbWdum13qMpf8AI4AikFtVNsfBt2/KNjXTbX49+/5u6o6LXh0iz3k6tv8AETt+u+F9"
        "bHhx1KhjGc9vPsx7TrnZurrT972N8m406ly4Sz+LNuPP+ln2HHutqdX1XWT6vt4c8vcAZNVxWi1Y22nf75/+Kmn2iYtO/Lb7nYHS"
        "fQpaFaaXt23a4KUq93JLv46j4Pcso8+jVNK0Do7t56vC9lHVLx1Yq1cYzxTwl29ycc+065QoJ1X9ybxXrG0fL+QY0/uRSZ9d/q5p"
        "0pUaVbW7XWLdPqNUtKdxFvxxjHrwo+84agQo8+bJ5l5vttu34qcFYr2c46I+te47pUftvwCrwfysxx9J7bccdU/YRdx3jKh8Zwrw"
        "diuKm6uMri+RyxjP/WDrIUbqarhxeXt39eXP5fL0arafiyce/b058vm59pGm3G6OjpaVpahWvrTUOvnQc4xk4OLWVlpfhfQz83SV"
        "OnSu9J01VYVK9hYU6FfgeVGa7V/14nDqdSdKXFTnKEuzMXhmy28t5b7zG+picfBtz5R+BrgmL8W/LnP4uZWn3p73+dV9SBw5AUjT"
        "lyce3LpGzbjx8O/zndkUCFGltKMZGAumEKBCj6pwShBCgJQoEUgLIUZCgTIoEIJkUgRSIsikCExlEUCKRMmQoyFGKYoEKKSUKATF"
        "FCgQoiRQIpBKZCYUElkUgRSAlCCECyKQIQlEUBSAsKMhAshRhQFigQoERQIpAWFGFAihBCRKFAikYkoQQgSKBCSKEyFAWEyEEwow"
        "mJKFAKIkUCKQEoxhQIoUCKAsKBFICUKBCCIoEKAlCgKQFkKMhQJhMhQEoQQgShQIpEihMjAShRkKMUxSBCRKMYwF0whQCj6pwShQ"
        "IQJQoEUgLIUZCgRRjCBKFAikCKMYUBgoUCKQSWQowoCyKQCCKFAhQEiCFEihRkJiWFGQoCUKBFASZGFEihBCBKECjFMhRhRFkJkI"
        "EigEEUJhCSyFGQoETGECUUgQgSICgJQgKBFCCEJJQowhJhkJkKBEQECUUgQhJYpAKBFCYwEopAhKSUIIQRQgKAlCjIyAlCjIQTIp"
        "AKAkUAoCUUgQoERQCgMFCjIQLIoBQKCjGRiL/9k="
    ),
    "mercado_aviso": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHAABAQEAAgMBAAAAAAAAAAAAAQACBgcDBQgE/8QAVBAAAgEDAgMDBwIQCwYG"
        "AwAAAAECAwQRBQYHEiExQVEIEyJhcYGRFKQVFxgyMzZCUlNVdJKhsbLSFiM3YmZyorPB0eMkJkNzdYIlVpOU4fCjwtP/xAAbAQEB"
        "AAMBAQEAAAAAAAAAAAAAAQIDBQQGB//EADIRAQACAQIEAwYFBQEBAAAAAAABAgMEERIhMVEFE0EUIjI0YXEzUoGRsQah0eHwJEL/"
        "2gAMAwEAAhEDEQA/APn5GkCFHLe4oUCEkqSIUBIUSFEVCAogkaQIUAkSEghIkRShAQEkQmKoSQhUICQJEIEKISCEEJFKIhIqEhAh"
        "ASBFAKASRCiKUaQIUQaRpGUaRFKNIEKA0hQI0iBRpGUaQVpGkZRpAKNIEKINIUCFAaQoEaAUaRlGkQaQoEKCtI0jKNIgUKBGkAo0"
        "jKNIgUaQIUBpCgQoDSNIyjSClGkZQog0hMocgIgRFJERBEREVAQkEREFRERiqIiIOn0KBCjuOeUICRUKBGkFSEkRBCiFEEjQISCE"
        "hCoUCEgRBCRUhISKhAQEQEghJCSRIQEikQEghIQqEiIEQECEkJFQgJBpGkZRpEUo0gQoDSNIyjSAUaRlGkRWkaRlGkAo0jKNIDSF"
        "AhRBpGkZRpAKNIyaRBpCgQoDSEEKIrSNIyjSAUaRlGkQKNIyjSA0hRlGkFaQoyaRBpCjKFBWkKMo0gFCgEgcjkzkckCQCFRERBCB"
        "EUkREERERUREQdQIUCFHceAkRIgUKJCiKiISCQokKASIUQQkRFKEBQCSITFUJEgpEBIEiFAQoiIEQEikkQkVCRAIgJAkQgQkRFIo"
        "BRFKNIyaRBpCgQoDSNIyjSIrSFAjSAUaRlGkBpCgQkGkaRlCgNI0jKNIgUaRlGkFaQoyjSINIUZRpAaRpGUKINI0jKFBWkaRlCmB"
        "oUZNJkVpCjKFAaRpGUKA0hRlCiDQmckQaEyhIrRBkgEgEikgIgSIiKhAiBICIrqJCCE7jnoUCFAKEkRFQoiyQI5AiDWSyCEByKMj"
        "kikQTHJFIhkckCJnI5A0hTM5EitJimZQokjSEyKYVoiQmIhIQqEEJAiAgQkhIIQEikQQkVGkAoBRpAhRFaRpGUaQGkaRlCgNGkZQ"
        "og0jSMigNI0gQog0jSMiiK0hQIUBpCgQog0jSMo0gFGkZRpBSjSMoUQaQoyjSCtIUZRpAaQoyhRBpCmZyOSDWRyZyKYGsijIkUjk"
        "zkQNEBEVogLJAiBECRZIikgIikiIDqMiJHcc8oUCFEUkQECIEA5HJnJZGw0OTGTSjKXYm/YhEb9Dc5HJeZq/g5/msvM1fwU/zWZe"
        "Xbsx4o7nJJl5qr+Cn+ay81V/Bz/NY8u3ZeOO5THIeaq/g5/msfN1fwc/zWTy7djjjucjkPN1Pwc/zWXm6n4OfwJ5Vuy8de7SYph5"
        "up+Dl8C6rtTRjNLR1hYtEtI0jxpmkzDZk2hMo0mRSjSBEjFWkIIUAiAkEJCBCREUiAkUkQkEICRSjSA0gFGkZRpEGkKMo0gNIUZR"
        "pAaRpGUKINI0jKFEVpGkZQoDSNIyjRAo0jKNIK0hMo0gFGkZQoitIUZRpAaQoyjSA0hRlCiDQozkUQayKMoUFaQoyhyQaEyKIHI5"
        "BDkKRM5EgRMiQJBkQpIByRUOQIgSAiK6lFAKO65xQoEJFRAJBEQNgWTUY5i5SfLBd7/wCEU8ym8Qj2v/AAPFVrOrLL6JdFFdiR79"
        "JpPN963R5s+fg5R1eV3Cj0pQS/nSWWeOVepLtqSfvPHksnZpStI2rGzwWtNucy1zy++fxLnl98/iZyWTNjs1zy++fxLnl98/iZyW"
        "QbNc8vvn8S55ffP4mclkGzXPL75/EueX3z+JnJZBs1zy++fxNRr1IvpUkveePJZA/VC87qsU/wCdHoz9EWpRUoy5ovvPW5N0a8qM"
        "srqu9eJ49RoqZY3iNpejFqLU684eyTNJnijKMoqUHmL7DyJnzuSk0tNbdYdOtotG8No0jCNo1syjRk0jFSRCBCQkVCAkCIISKhIg"
        "EUAkUoUSIDSFGUaRBpGkZQoDSNIyhRFaRoyhRBpGkZQoDSNIyjSINIUZRpBWkKMoUBpGkZQoitI0jCNIDSNIyhRBpCjKFAayKMoU"
        "QaQoBIpRpGcjkBFGUKINCjKFBWkxyZHJA5HJkSKRAgHIgWSBECIpIMiRSQEQdToUCFHdc8omREEREAMy2LKC5pxXi0jKI35JMi4l"
        "yqNJdy5pe1ngyNafPVnLxkzGT6alYpWKx6ORaZtO8tZLJnJy3h3w8veIGoVqVGvC1tLbldevKLk1nOFFd7eH3rsNefUY8GOcuWdq"
        "wyx47ZLRWsbzLimSyd07i8nZ22mzr6HqtW4uaceZ0LiCSqY7VFx7H4LD9p0o8ptPo0aNF4jg1lZtgtvt1bM+myYZ2yQ1ksnY+gcI"
        "ZXun07nVL2pb1KsVKNGlFNwTXTmb7/V+k45vLY95tKpCpKormzqvlhXUeXEvvZLuf6zsZNFmpTzLV5OdTWYb38utubjeSyZyWTyP"
        "U1ksmcl2gayWTsvRuDrr2MK2qX1ShXqR5vM0op+b9Tb7X4/rOJbx2fdbRvadOpUVe3rJujWSxnHamu5rK+J68uizY6eZevJ5cesw"
        "5L8FZ5vQ5LJnJZPI9T9ljV9J0n2S6r1M/ZFnqqM+StCXhJHtOyTXgzjeKY4iYvHq9+jtymryRNo8cTyI48vdDRpAhRipEhA53wj4"
        "ZfTM1i8s6l7OxtrS387OtCmpvmckoxxldq5n7jtT6k/T/wDzTdf+0j+8ez8l3QfkOzb7V5wxU1G65Yvxp01hf2pTPY6fvydfygtQ"
        "2868naLTo2tOnzei60F51tLxxKaf9X1HQxYccUrN45y8t8l+KYrPR8/8VOHz4b7lhpMbqd5Rq28LinWlDkck201jL7HFnl4UbCsu"
        "Iu4K+j3Wp1dPnC2lXpyhTU+dqUU49Wu6WfcztvyqdB89o+ja7CLzbV52tRpfczXNHPscH+cdPcI9c/g9xG0K9lJxpyuVb1Hnpy1F"
        "yNv1Lmz7jzZMdaZuGY5NtbTbHvHVyTi1wWp8NdIstTttVq39K4uHb1Oeiocj5XKPY328svgdWn2Txy0T6N8MtYhGOalrCN5Dp2eb"
        "alL+zzHxuNXijHfavRcF5tXm5two4c/TJ16406peTsqFvbOvOtCmp9eaKUcZXblv3Hu+LXCCw4aaXY3VLW619cXld040p0VBKCjm"
        "Uspvsbivedh+Sxonyfb+sazODUru5jbwb+9pxy8e+p+g4f5TuufL96WelQlmGnWiclnsqVHzP+yoGU4qVwccxzljF7Tl4Y6NcOeA"
        "VrvraVpr1TXq1nK4lUi6MbZTUeWbj28y8Drje+3IbR3XqOhwuJXMbOooKrKPK5+innGXjtPp/wAnz+SrSv8AmXH99M+eeM/8qG4P"
        "yhfsRGfFSuGtojnP+DHe05JiWeHvCvXuIlxJ2MIW1hSly1r2snyRf3sV2yl6l6stZR3NZ+S3tqFGKvNa1itWS9KdF06cW/VFxlj4"
        "s7G4faRb6DsbRLG2gowhZ05y5fupyipSl75Nv3nzRuHj1vfVdUrV7PVJ6Za8781bUacPQjnom2m2/H9SNk48WGsTkjeZYceTJaeG"
        "dohzvcnkuQhbSq7b1urOtFZVC/isTfqnFLH5vvR0Zq+j3+galX0zU7adrd28uSpSn2p/qa7010aPoPgZxg1rdusVdv7hqU7qr5h1"
        "re6jBQk+VrMZKOE+jynhdjznPT8flR6Bb/JdH3BCCjceclZ1JJfXxac459mJfEwy4cd8fm4+TLHkvW/Bd0FaWte+uaVra0Z169aS"
        "hTp045lOT6JJLtZ3btTyZb68t6dzuTVFYOaT+SW0VOpH1Sm/RT9SUvaPkxbUoXd9qW5bmmpys8W1tlZ5ZyWZy9qjhf8AcznPGfi5"
        "V2BC30zSadKrq11TdTmqrMbennCljvbaeF2dOpMGDHGPzcvRcmS024KPXT8mHarp4p6trcZ/fSnSa+HIv1nX2+vJ+1za1pV1HSrh"
        "axZUk5VIxp8lanHvfLlqSXinn1Hqbfj3xBo3KrT1qFaOculUtaXI14dIpr3M+i+GW/qHEPbcdSVKNvd0pujdUIvKhNdcrPc00171"
        "3GyldPn92sbSwtOXHzmd4fGyNI53xs2rQ2pv26o2dNU7W9hG8pQS6Q5m1JL1c0ZYXcsHBEc29Zpaaz6PZW3FETBRpGUaRgrSFGUa"
        "CtITKYoK0jSMoUQaRpGUKA0hRlGkQaQoyhRBrIoyhQVtCjKEg1kcmcigNZHJlMSK0mQCgEcgiINZHJnI5IpEMlkg0QEFaLIDkgSD"
        "IkUkBZINEBEHVKFAhO856IiRBERAZZUfs1P+sv1gxpfZqf8AWX6zZj+KGFukvyN9WWTLfVlk+l3cprJ9CeTjTgtqalUUVzyv3Fy7"
        "2lThhfpfxPnnJ9EeTh9qOo/9Ql/dwPnv6nn/AMFvvH8uj4X8xH6u2D471qjTjvS+oKCVJalUhy93L51rB9fXl5b6fa1bu7rU6FvR"
        "g51Kk3iMIrtbZ8Xbg1ON/uDUb60nNUq13VrUpdksObafqfU439HbxkyW25cns8a51rH3fTR+LWNJttc02vp93HmpVo4eO2L7mvWn"
        "1OI8MNva5QtvorrmpahPz0c0bOrWk1FP7uSb7X3L4+rns0ljxP1jB4/g1GaNNwz73L6PyXJqKYtR5VLb7esd3zXrujXO39Ur6ddr"
        "06T6SXZOPdJepn4MneXEbaC3Lpfyi1pp6hapyp47ake+H+K9ftOi3lNpppruOdrtLOnycPpPR9jotVGfHv6x1ayfu0GMamuadCaT"
        "jK6pJp9650evyfv28/8Ax/Tfyql+2jy4/jh6cnwy+lDr7jPGP0AsptLmV0kn4Jwln9SOwTr7jR9rtn+Vr9iZ9f4h8vf7PlNB8xT7"
        "un8lkzksnxu765pPqj27fpy9rPTJ9Ue4/wCJL2s5nifw1evSfFLyxPJE8UTyxOHLoQ2hQITBk0hRI5Lw30H+Eu+9E0tx5qda6hKr"
        "HHbTj6c/7MWIjedoJnaN32BsLR6e0dhaRp9bFL5JZxnXfYoza56j/Ocj5K0TedSjxRt92VZuCqap8pq8z7Kc5vmX5smj7L17S/o5"
        "ol/pfyipbK8oTt3VprMoKUWm168M6c+pU0L/AMw6l/6cDqajFeeGKejxYr1jebersDi/oX8IuHGuWkYc9Wnbu5pY7eam+fC9vK17"
        "z4shOVOcZwk4yi0008NM++7Oy+TabQsq1R3Pm6MaM5zXWpiOG2vWfDG69Fltzc2qaRJNfI7qpRjnvipPlfvWH7zRr684s2aW3Wr7"
        "V0K+oby2bZ3dVKVHVLGLqx/rwxJe5to+H9SsKulald2Ff7La1p0J/wBaMmn+lH1N5NuufRTh3GxnJupplzUoYb68kvTi/Z6Ul7jq"
        "Dixs+pPjVV0qjFxjrNzQqU2l+FaUn+fzl1UeZjreDD7t7VfQXB7RPoBw20K1lFxqVLdXM89vNUbn19ikl7j5P4g65/CTe2taqpc0"
        "K93PzbT7acXyw/spH19vzV4bT2Hq9/RxS+S2coUO5Rm1yQX5zifEKMdbPDWuOF00bzNn155Pn8lWlf8AMuP76Z89cZ/5UNwflC/Y"
        "ifQvk+/yVaV/zLj++mfP3F2g7nixrdBSjB1buEOaXYsxissup/Ap+n8GL8WzvjgjxN03dG3bLRLi4hR1mwoxoOjN4deEFiM4ePRL"
        "K7U0+7A7s8nzaW5burfW7utJuq0nOo7aSdOcn2twknj/ALWkdW6t5OW49vaVeawta0+XyChUuuWj5xTfJFyxHp29OhxzQuN++9Bh"
        "GlT1qd5RisKnewVb+0/S/SJzbVimoqnl7zNsUubXfAXe2x7p6vs7Wqd5XpxlFciVGvyvtSUm4v4nWu7d2bw1XOkbov7+o7arzu2u"
        "ockqc0mstYTzhv4nenDDj/8Awu1e20LW9Op2t9c5jRuLZvzU5JN4cX1jnHTq+vgPlJ7Vs73alPcMKMY31hWhTlVS6zpTeOV+OJNN"
        "eGX4mOTDS2Ob4Z5dlpktF4rkjm15MEUti6jLHV6pNf8A4qX+Z1p5Rs5S4k1E3lRtKKXqWG/8WdleS/UT2RqVP7qOpzk/fSpf5HXH"
        "lIUJ0uI7nJYVayozj61mUf1xYy/K1Mf40urUfQnksTk7PcdNv0Y1LeSXraqZ/Uj57R9DeSzbzjp24bhr+LqVqFNP1xjNv9pHn0X4"
        "0f8AejdqPw5ek8p+KW6dInjq7Fpv1KpL/NnTKO5PKeqxe7NJpJ+lGw5mvU6ksfqZ02jDV/jWXB+HDSFGUaR525pMTKFEVpGkZQoD"
        "SNIyhRBpCjJpAaTFGciiK0hRlGkQKNIyhA0KMoUQaQpmUKCtCjORINITKYgaIBIpQ5Mjkg1kshkckUiZyICJkSKciZyOSBEyJFJF"
        "kgOq0REd1ziSIkAEIAYZUvs0P6yJlT+zQ/rI24/ihhfpL8TfVhkG+rDJ9E5TWT6H8nSrTo7M1SrVnGnThfTlKcnhRSpQy2+5Hztk"
        "9xR3lqNntOvtm0n5m0ubl3FxOL9KquWKUPVH0cvx6eHXmeL6K2sweTWdt5j9nq0eeMOTjns5hxh4sVN43UtH0mrKGi0J9ZLo7ua+"
        "6f8ANXcve+7Hl4XcOPlDpa9rNH+KWJ2tvNfX+E5Lw8F39vZjP5eGHDj6LTp63q9L/YYvNChJfZ2vumvvf1+zt7f1LUbTR7Cre3ta"
        "NC3ox5pSfd6l4vuSNEVx6XHGm08co/793x/9Q+O3y3nT4Z3tPKZj+I/7+7x61rVlt/TquoX9VU6FJe+T7opd7Z11sLd+o7u31eXV"
        "dunaRs5xpUE/RpLnhj2yfXL/AMEcI3hu3UN+azTp0adVW6nyWlrHq8vplpdsn+jsOV3ug3HDfZ1pfUpxWqyvqVWtNdUsQn/F+tYb"
        "T8cv1Hc8H0k4r+0Wj4ec/wCGrR+FV0uLbL+LflH0/wC9ZdtHT3FbZ30OunrtlTxbXEsXEYrpTqP7r2S/X7Ts7buvW25NJoajavEa"
        "ixOGcunNdsX7P1YZ+y9sqGo2la0uqaq0K0XCcH3pn2WpwU1WHaPvEtenzX02XeftMPmHJ7Dbz/8AH9M/K6X7aP0bt23cbW1mrY1c"
        "ypP06FV/8SD7H7e5+tH5duv/AHg0z8rpfto+RilqZYrbrEvqpvF8c2r0mH0udfcaftdsvyxfsTOwTr3jV9rll+WL9iZ9b4h8tf7P"
        "ltB8xT7unMlkzksnxj65tPqj3H3cvaz0qfVHuvu37Wc3xL4YevSdZeWJ5YniieWJxJdCG0aRlGjBk0juryW9C+W7u1HWJxzDT7Xz"
        "cXjsqVHhP82M/idKo51w/wCL+ucN7C6stIsdKrRuqqq1Kl1SqSnlJJLMZxWF17u9mzDatbxazDJEzWYh3xx34o6rw9p6Tb6JK3V3"
        "eSqTqOtT51GnHCXTPe5foZ1J9Upv38Lpv/tf/k4hv3iBq3EXVqOp6vTtaVSjQVCFO1jKMFFSbziUpPLcvHuRxozzam03mazyY48N"
        "YrtaOb664GcSNR4haLqM9YlQd9Z3EU/Mw5F5uUfR6eOYzOnvKU0H6F8QVqEIYp6nbQrN9znH0JL4Ri/ecS4fcStZ4b3d3c6RSsqz"
        "u6cadSF1CUo9HlNcso9er+J+jiDxU1jiTCyjq9lplCVk5ulO0pzjJqWMp805dPRRnfPW+Hht1SuKa5N46Od+S1rnyXcuq6NOWIXt"
        "tGvBPs56csYXum/zTt/cexpavxN2xuZUlKjp9CvGvLp2pfxS/OnN+4+S9o7pv9l7gtdd01UZXNtzcsaybhJSi4tSSabWG+87K+qj"
        "3n+LNv8A/oVv/wCpcGopGPgv6SmTFabcVXYHlO658h2ZZaTCWJ6jdJyXjTprmf8AacD5gRyrf/EnWeI93aXGr0rOi7SnKnThawlG"
        "PV5bfNKXXovgcVR59TljJfijo24acFdpfXnk+/yV6V/zLj++mfPPGZtcUNwNPDVxH9iJ7HZ3HXcmydv2+h6dY6RVtrdzlGdxSqSm"
        "+aTk8uNRLtfgcN3NuG63Xr15rd7ToU7m7mpzjRTUE8JdE233eJszZq2xVpHWGGPHNbzaX2HsHdthxD2hb3qlSqzqUvM31D7ypy4n"
        "FrwfavFM6d3L5MGpxv6tXbmq2U7OUnKFG8c4TprP1vMlJSx49DqTa27ta2bqK1DRL6pa1eycV1hVXhKL6Nfq7jtex8qXWaVCEb7b"
        "9hcVUsSnSrSpKXualj4m32jFlrEZesMPKvSd8bk3CzgFc7S12jr2v39tXuLXLt7e15nBSaxzSlJLsy+iXbh57jXlK7utbPbdHbNK"
        "rCd7fVYVatNPrTpReU37ZJY9jOF655TW5r+2lR0vT7HS5STTrda04/1c4ivemdS31/dand1by+uKtzc1pc1SrVk5Sm/FtmGTUY64"
        "5x4vVlTFe1uO7tjydN9W23teudC1CqqVtqrh5mcniMK6ykv+5PHtUfE7m4n8LLDiRZUeeu7PUbVS8xcxjzLD7YTXfHPr6fFP47R2"
        "VtTj7u/bNvTs61S31a1ppRjG8i3UjFdymmn+dkxwamkU8rLHJcuG0246dXvbXyYNyTvOS61nSqVqmv42n5yc2vVFxSz7zvTae1tI"
        "4d7ajp9pU83a26lWr3NZpOcu2U5Ps7F7kkdLz8qXUnTxT21aRqffSuZNfDlX6zgW8+LW6d80nbahdwt7JtN2lrFwpv8ArdW5exto"
        "2VzafDzxxvLCceXJyt0ePinvGG+N53mqW/N8jglb23MsN049j9WW5Sx6ziSYCc69ptM2n1eytYrG0FGkZQowZNI0ZQoDSNIyhRBp"
        "GkYTNIgcmkzKFBWkKMo0QaQpmMmkBpMUZQoitIUZQgaTFMymKZBpMTORRFaQoyIGhMiQImRIrWRyZyOQHImciRWiAiDRZAskVogy"
        "JAkBEHVogKO+5xJESAAEAMMqf2WH9ZCwh9lh7UbMfxQwt0l65vqyyZb6sJPofROWpy7kc84a8O5bjrR1TU6co6ZTl6MH0dxJdy/m"
        "rvfu8ces4cbQp7u1t07mTjZ20VVrJPDn1worwz4+CPoD/ZdMs/8AhW1rbw9UYU4JfoSR4dVqOH3K9XzXjvi84P8AzYfjnrPb7fUX"
        "Nza6VZTr1507e1t4ZlJ9Iwiv/vYdA7+31c7xv1SoKdPTqMsUKPfN9nPL1vuXd8c/p4i8Qau67p2NjKdPS6MvRXY68l90/V4L39vZ"
        "xewo1LfV7elWhKnUhcRjKElhxalhprxLpNNwzFr9ZPBfB/Z6+0Z49/0jt/t3Lw34fQ25QjqWo04y1OrHpF9Vbxfcv5z737vHNxl+"
        "1Ol+Vw/Zmc7OB8ZvtSpflcP2Zn3uowUw6S1KRy2adPmtl1Vb367uv+He8ZbX1bzdxN/Q+6ajWX3j7pr2d/q9iO+4yjOKlFqUWspp"
        "9Gj5Wydv8JN5/LLdbfvqn8fRjm1lJ/XwXbD2ru9XsOZ4RreGfIvPKen+HQ8V0e8edTr6/wCXKN87Tp7r0aVGKjG8o5nbVH3S74v1"
        "Ps+D7jo3Q6NS33Np9GtCVOpTvaUJwksOLU0mmfSp15vrZnNr+m7isafVXdFXcIrtXOkqn+D9z8T2eJ6LjmM1Osdft/p5fDtXwROG"
        "/Sen3dhnXnGv7XLL8sX7EzsM6842fa5Zfli/YmevxH5a/wBnl0HzFPu6ayWTOSyfFvr2k+qPeL65+09Cn1R76P1z9pzfEvhh69J1"
        "l5YnlieKJ5YnFl74bRtGF2GzCWTSIkJFQohMVQgICICiKRBCAkREChRISSqIhIISQogUKBCFhCRIilCSFASNIyJBoUZFMitJmkZQ"
        "oDSFGUxRBtCYRpAaQoyhRFaQmUKA0hRlCiDWRyGRyRShRlCiDSEyhQVoTIog0QCRSOTIgORyGSyQaIBIpEyJA5ECIpIiA6vFAhR3"
        "3NJERAAxBlgYkEPskfajUjMfskfajZj+KGFukvVt9WD7Ab6ssn0LmbPd7R3ZebQ1T5dawhVjOPm6tGbwpxznt7n07T228uJupbtt"
        "1ZxoxsbLKlOlCbk6j7uaWFlerH+Bw07z8n3ZWga1pNzrWpadSu722vXToyqtyjBKEWvQzyt5b6tM5/iGpxaTHOpyV32a8XhWHU6m"
        "MnDHH3eTgnwjcXQ3TuC2afSdja1F2eFWS/ZXv8DqrXH/AL+6h/1Wp/fM+yT401t/7/X/AP1Wp/fM4n9Pa/LrNXky5O0bR2jd2fEt"
        "PXDhrSv1fRxwLjP9qVL8sh+zM56cC40fajS/LIfszP2HX/L3+z850PzFPu6Qyea0u69jc0rq2qSpVqMlOE49sWuw8GSyfExMxzh9"
        "hMb8pfSGzd00N2aLTvIcsLiHoXFJfcT/AMn2r/4Pedp857I3ZW2lrULr0pWtXELmkvuoeK9a7V713n0RbXFG8t6dxb1I1KNWKnCc"
        "X0lFrKZ9j4drPaMfvfFHX/L5TxDSTgycvhnp/h5Trvjb9rdl+WL9iZ2IddcbvtbsvyxfsTNniPy1/s16D5in3dMZLIZLJ8U+w2aT"
        "6o9/HtftOPJ9Uchh2+85viPww9Wl6y8sTzRPFE8sTjS98No0ZRs1yzKEkJJEhIiKRASEFCCFBSICQQoBAUJIiKhRCiCRpAJAoiIM"
        "iKBCiBEkRAiAkEhISKhIgFM0jKEitIUZQoDSFGUKINCjKNIitIUZQpgaTHJlMUyDSIBQUijIkGhMiRWkKMiQImRQGhMiRSJkSBEB"
        "IpEyICQERXWSFAhR9A5hASIAGaMsDEjMfr4+1G2Y7GmbKTtMMbRvD07fVlka65K04+EmYyfQbuY1k+jvJonF7Q1OOVzLUG2vU6cP"
        "8mfN+TmPDfiXqHDvUKtSjRjd2NzhXFtKXLnHZKL7pLr6n8GuV4zpL6rS2xY+vKf2erRZq4ssWt0fXp8Ya3Wg9839VSXm3qlSXN3Y"
        "86+p2puTylXc6ZUt9A0mra3dWPL8ouZp+ayu2MV2vwb+DOjZTlOTlJuUpPLb7Wzmf034dn0k3yZo2322h6vE9TjzRFaTu+sDgHGq"
        "SjtKim8N3kMLx9GZx/b/ABrnaWELfWLGpc1qceVV6MknNLs5k+/1/oOLb437d7yr04ypK2sqDbp0VLmbf30n3v8AUfqGs8TwZNPN"
        "aTzn0fEaTw7NTPE2jlHq4xksmclk+XfRtZO0eEG9PMVVty/q/wAXUbdpOT+tk+2Hv7V68+KOrMmoVJ0pxqU5OE4tSjKLw013o9Gl"
        "1NtPkjJV59Tp658c0s+rzrjjhOK27YwyuZ3aaXilCX+aPWaJxvjRsY0tY0+rWuYLHnqEklU9bTxh+z9Bwze29rveV9CrUpq3taKa"
        "o0E88ue1t97eEd/XeJ4MmnmtJ3mXE0Xh+ameLXjaIcdyWTOSyfMPo2k+qORwOPUIudaEV3yRyKCOd4jPu1h6tLHOXmgeWJ44Hkic"
        "aXvhtGgQowlk0jmXD/h/T3vR1KtV1dabTsFTcpOh5xSUub+csY5fX2nDUdmcL5OOyd+Si2mrKDTXd6FY0Z7TFN69eX8s6REzzcO3"
        "ftqptHcN1o9St8o8xyuNXk5POKUVJPGXjtx29xzHQODf0Y29a6rW11Wle5t6l1C1+S875Ivt5uddzi+z7o1xYtp6/V2vrttDmnrF"
        "lCk0vwqa6P1+nj3HYVvcU6G8LrQbeS8xpO3lRS8JNx//AFUDz3zX4K7Tz9f0bK0jind85kdhcN9m2Go6PqO5dUsLvVKFlNUqNhax"
        "lKVephPqo9cLmj+lvsOQ09q2G+dOvrd7Ivdralb0nVtq3mpxpVsfcSbjFZfTuz3rsaNts9YnbsxjHMw6eQnY+w9C2zcbE1jWtwWU"
        "66srmPp0pNTcfQfIuqXpN49/ajwaFomg8QN3YsdPnouj2dq61zTjVc5S5ZduX2N5XuTLOaImeXQ4J5OAEdmWe6OHup6hDR620qVl"
        "p1SfmoX7rtVIdynLvS7M5k8es9Bo+kbbtt81LDUbupqGk0Zy81K0jKo7nvjH0Ovf1x4NCMvXeJTh7S4mhR3NpWiaXvGpW0i44e3e"
        "3qcqUpW+oebmnGS7OZuKTz4Nvw9Zw7h3tGw1i81S91yUlpujUnVuIQbTm/S6ZXXGIy7OvRGMZ42mZ9F4J9HGNE076MaxY6b53zPy"
        "u4p0POcvNyc0ks46Zxnsyfp3VoP8GdwXmkfKPlPyaUY+d5OTmzFPsy8dvic827uLZ24N06ba09sR0epC6pztLqhWy3OMk4xnHCWJ"
        "Yx34z7zx6xtZbw4x6jptSrKlQ5o1a04/XKEacOz1ttL3mPmzFve5Rsy4eXJ1kKOyHujYENRekLaVJ6Yqnmfl/nn57Gcec7M47/ru"
        "z4HG9/bVjs/cdXTqVWVW3lCNahKX1zg89H60017jKuTedpjZjNdo3cdQo5Rw42lS3fr7trqdSNpb0nXreb+umk0lFe1v4JnObLTd"
        "G1y/Wi1+G+p6ZY1W6dLUFRqRqU33Sk3Hp720u/JL5orOy1pvzdPCdh7I2XZfTEv9v6vQheUbWnVwpNpSw48suj8H2es9bq93tO7u"
        "LHStE0arSdO7hCpeVqrcriGeV5jnpltPpj3DzYmdoheHlu4eew0DRbncOr2ul2i/jbiajlrpFdrk/Ull+47B37Q2RtS9vNMoaBUr"
        "31ahmM/PSjTtm44jhZ6vPpdfHtPwbVjoVpt+jXttrXm5tWqTl5+Pmajp0EuxLEWn3d2e3s6GPm713iF4ee0uIbg0y30bVriwtr6N"
        "9GhLklXjDli5LtS6vKT6ZPOtr3z209xc1H5Eq3mMcz5+b2Y7Pecu3poOmWFjom6aeg1tOhXr8l3pNVyhnlbeOqzHmUX1x2NPByCO"
        "v6C+GUr9bXpqw+W8nyD5XLHN09Lnxn3YMJyztG0LwxvO7rzZ20f4W17yl9Erax+TUXVzW+6/SsJd77vA49jqc92Hpmjbn13W6lbS"
        "oU7WFpOtQtnUlJUXlYxLo2fn2Vt7SPoJqG6dfhUuLGxmqVO2g8eeqPHRvw9KPx69mDLzNpnf6JwuFidiW2obK3jb3dnX0m123dQp"
        "OdtdRr+g5LsjLos/B569h+HZO3dIeiajujX4Tr2NhNUoW0Hjz1Tp0bXd6Ufj16IeZtHODh7OFCdl6K9q8RK1XR4aDT0O/dOU7Wvb"
        "1OZNruksLPj2dUn1R1xcUKlrcVaFVYqUpuEl4NPDLW+/KeqTGzBEJkISECEEJiFCgEKcjkBIpTFGRINITKEDSIBIpECA0JkSKRAS"
        "BHJkSByOQEikUCEikiJAKIURB1khBCfQOYQEgoBmgIMMxJHkaMNGUI9bqNLlmqq7JdH6mfjye6qU41IOE1mL/Qeor0Z0J8suzufc"
        "zs6bNF67esOfmx8M/RjJZDJZPQ1HJZDJZAclkMlkByWQyWQHJZDJZAclkMlkByWQyeS3oTuKihBe1+A3Nn7NJoOdZ1X2Q6L2nu4I"
        "8FtQjQpqEV0X6T9MUcPV5vMvy6Q6ODHw15vJFHkiYijyJHil6IaRpAhRhLJpHYPDrU7Gx2dvW3ur22t61zZxjQp1asYyqvkq9Ipv"
        "Mn1XZ4o6/RGF6cUbMqztO7uPYGoaHrG09DttX1fT7KvoepuvCN1cRpynBJyWE31XNJfmn59n7psLnfu7NUvb+1t6N1b1oUJ1qsYK"
        "aUkoJNvq+VI6lE0zp458+rOMk8nZXDTcdm9t6ptW51meh3F1VVe0vo1HDlniKack1hegu9ZTZ++8s73bml3t1rvEm9r3Pm38jttO"
        "1KpOVSfc5ZfZ7u/tOp0KE4fe3iepF+Wzn+39SsaPCTcdjVvLand1rmnKnbyqxVSolKnlxjnLXR9ngz8PDDdFjtnXa30U5lYX1vK1"
        "rTis+by01LC7umPecPEynFG0xPqnFPKezsiw4a6JaX8dS1Ddui19CpT5/wCLrZq1orryOK7G+x4bZ5eHmu7bs96avO283o9C6oyo"
        "6dVrvmVB9Orcm8N4z1fqydZCjGcU2iYtKxbbpDvHbmp3W1tdhV3Zvq0voXKdOjQoXLqQi2s+cqZSUF0wvXL1HHds6ho23dd3FtzU"
        "9Vtq+nazS5Pl9rNTpwbUsdexdJvr3NHWSIw8iOfPqy43Z+j7J0TaWvWGrapuvS7m1p3NOVtC2mnOq+ZcspdcQjF9W8tYRS3np+g8"
        "YL7V/P07nTq+KM61CSqLlcIekmu3EorOPBnWIl8nfnad+WycfZ2NLhxoUtRd+t3aMtBdXm+zfxyjnPJy+OOmc578dx6PiRue33Zu"
        "epeWal8ko0429FyWHKMcvOO7Lb92DiwlrSYneZ3Jty2hzLhbue02zuGctQqSpWd3Rlb1Ksc5pttNS6de7Hvycshol5aXLvNR4oVH"
        "oqzKM6GpTdepHuSWWs+zPsOoiMb4t53iVi20bOxeGWt2VDiBeX19qrVCdCrGF1qFZKdRc0eXmlJ/XYXZ6jhGmzhT1i1qTlGMI3EJ"
        "OTeElzLrk/EKMoptMym7mXFi+tNS3ncXFldULqi6VNKpRqKcW1Hr1XQ5hbXdbWtmaJbbW3PYaNOzo8l7QrVvMyc8LMspN9vM/B83"
        "qOnkJhOL3YjssX5zLtjdl5puvbDp2EN0Wt5f6VWlUq1Lirid1JRlnzeeslmWE/Uev23LTNd4b19v1da0/TbyN555fLKqpxlHp2N9"
        "vf8AA64EkYto23+q8XPd2Bw1uLHQtc16hd6lZRhG0q0Kdd1oxp1mppJwbfXOMr1Hi2Xq2lX219T2jq15HT1d1VcW91U+sjNcvSXh"
        "9Yvi/UcFQice8zJFnYVrs7b+1ba51DcuqabqidJq2srKvJurJ9ksrDS/R17Tw7K1bSb7bWqbS1e7hp8buori3uZ/WQmuXo33L0F2"
        "+vqcDEeXvHOTi7Oztt6PpPDu9qa7q2vade16VKStbWxqeclUcljPq6ZXh17eh1xd3M727rXNTHPWqSqSx4t5Z4RFa7TvM8zfdCQm"
        "aIQEgRASKhISKhIgEQFEEJCFQkRiEQECEhRFQkiIEQEBQoEKIpQgJFQoEKEhRCiIrrIQQn0DlohIighLAGWjDR5MA0WJR4mjxVaU"
        "asHCayj9DiZcTOl5rO8MZrExtL1VXTZpt0nzrwfRn5ZUasHiVOa9x71xM4Z7qa2f/qHntp49Jei5ZeD+BcsvB/A9718WXXxZn7bX"
        "sx9nnu9Fyy8H8C5ZeD+B73D8WOH4se217Hs893oeWXg/gXLLwfwPfYfixw/Fj22vY9nnu9Byy8H8C5ZeD+B79J+I8rHt1ex7PPdx"
        "/ll4P4Go0as3iNObz6j36ibUTGddHpCxpp7vU0NJqzadZ8i8F2ntaFvChBRhHCPJGJ5IxPJm1V8nLpDfjw1rzUYnmijMYnkijxzL"
        "fENRRtIEjaRhLIoUBpGKkQORaDw/3Nuaz+WaVpU7i35nFVHUhTTa7cc0ln3GNrRWN5lYiZ6OPCcz+k7vj8SfOqP75fSe3x+JPnVH"
        "981+dj/NH7s+C3Zw1Gkcx+k9vj8SfOqP74/Sf3v+JPnVH98edj/NH7nBbs4aJzH6T+9/xJ86o/vj9J/e/wCJPnVH98nnU/NH7nBb"
        "s4chRzH6UG9/xJ86o/vj9KDe34k+dUf3yedT80fucFuzhxHMfpQ72/Enzqj++X0od7fiX51R/fJ5tPzR+68Fuzh6FHMPpQ72/Evz"
        "qj++P0ot7fiX51R/fHm0/NBwW7OHo0jlV1ws3jZW9S4raLPzdOLlLkrUpvC9UZNv3HFS1tFukm0x1QgKLIRQIQEQEghIURUJEQIg"
        "KASISKhIgEQExCRCJVCREUigEgSIQQhIiKRASBIhIqEhQEICQJEIUoUCExUkRIBQoEaIIiIK6yEhPoHMQghRBEOCIowGDWCwNxho"
        "HE8mA5S7ps8XKHKeXlLlLumzw8pcp5uUuUbmzxchch5uUlEbmzxcg8p5eUVEm5s8SgKgeVRFRHEuzxKBpQPIomlEx3XZhRNqJpRN"
        "JGMysQkjaRJGkjGZZbJI2gSEwlSjSBISKTsfZHGSvtDQqWj1NIhe0qMpOnNV/NNKUnJp+jLPVvwOuBRhkx1vG1oWtpid4dzfVFf0"
        "Y+ff6ZfVE/0Y+ff6Z00hRp9kxdv5bPNt3dy/VEf0Z+ff6ZfVEf0Z+ff6Z02JPZcXb+Tzbd3cn1RH9Gfn3+mX1Q/9Gfn3+mdNih7L"
        "i7fyebbu7k+qG/oz8+/0y+qF/o18+/0zpxCT2XF2/lfNt3dxfVC/0a+ff6Y/VC/0a+ff6Z04JPZcXY823d3F9UJ/Rr59/pj9UH/R"
        "r59/pnTwj2bF2PNt3dt3fH+vVtqkLbQIUa0otRqTuudRfjy8iz8TqUkRnTHWnwwk2mepFAhRmhQghASITEQkiEqRASBJEJFhCQgQ"
        "gJAkQkVCQkVCCEBQgJBCQhUICYhEEIEhISKhJEQIgIEKJCiKURCRUKAUJChASCISIrrISJH0DmFCCEBLBCYqBLBBUWBHA3RnBYNY"
        "HA3VjA8prA4JubMco8prA4G4zylym8CkTc2YUTXKaSHBN12ZURSNJDgm5sykaSFIUibqkjSQCiKRSJIUYqRAQISFEVIUQgQkRAoQ"
        "QogSIiKUKA0BISFEVCAkVGkAgIgJJEJEiKRASBIhAkJCRUICAiAkEJCRUJERSICQQkIEJqk4RqwdSLnBSTlFPGV3o7OvLPYlHZdv"
        "uWO2bpK5uZWkaXy6eYNRk+bPf9b2GzHj49+e2zG9+Hbk6wE5Vw723Ybh1K9qap52Vjp9nUvKtOlLEqnLj0c93b+g9hrWjbd1jZNX"
        "cug6dX0qdpdq2rW9Su60ZxaWJJvrnqv0+oVw2mvF/wBySckROzgonYdLZGl3nCylrVvSmtYUatxKXO8TpU6vLP0c4WIyT9x6rfO2"
        "7LSdb0qx02m6Ubuyt6suablmpNtN9fcL4LVrxT9P7lcsTOziQnbn8D9mS3XPY8dOvVfxo5+ifyh/ZPNc/wBZ9bjH+XrOJ7E23Ya9"
        "d61pV7Sc72nZ1alnOM2lGrDp2LtzldvgWdNaLRXeO36x6EZomN3EBOVWeg6fS4c32vXlJyvKt7C0s5c7SjhKUnhdH05l18D93DHb"
        "Gk65V1C712nOdjbKjSSU3D+Mq1FGLymvX8TCuC1rRXvzZTkiImezhBHsdx6U9E1/UNNaaVtXnTjnvin6L96wevRqtExO0s4neN4S"
        "NI5Xw00LTtf1y5t9Tt5XNCjZVK6pxqODcouOOq9rP36xoOh32yq24bDTLvRa9vcxofJ69Z1IV08fWuSTys59z92yuC1qccT3/swn"
        "LEW4XBRObaDo+gabsx7m12wr6k6158ko21Ou6UY+i25Nrr3P4I/PvfQNL2/q+l3NlSrS0y/tqV4rec/TjFvrDm9nf6xOC0V4t/8A"
        "pWMkTbhcSQo7Mo2uxq20K+5Ftm6VOjdq0dD5dPLfLF82f+466vZ29W8r1LSjKhbyqSlSpSlzOEM9It9+F3mOXFwbTvE7rS/F6PCR"
        "EaGwohRAdZCCE+gcwiAkVCQoioQECwOCQkAIlggiHApBQKHA4IASSHBFQosDggBHApACHAoSASNIEJFKEEJFJEIEKJCiKkJCBEQo"
        "gRBCRUKASBQokKIJCSIKSRCiKUICAkQmIhBCJUiAkEKISCEiCkQEgSISKhIiKRBCAoiEghIgrdKlOtUhSgsznJRivFs7e1Hh/uV8"
        "LLHR/ob/ALdb6hO5q0vP0/Rp8s/SzzYfauieTp8TZiyVrvvG+/1/013rNttp6Oe8Iq1Gep6vpk61OlX1LTattb+ceFKo8Yj+v4Hs"
        "NU0a72Zwsu9K1tU7a/v9QjUo26qRnJwio5l6Lax6P6V4nWabTTTw0e/vd219T2xbaHfW8LidnVc7e7lJ+cpxfbD1r/48DZTNWKTW"
        "eu07fqxtjni3jo55oGq09J2tsadxh2tzc3lpcRfY6dSbi8+pZT9x6zi1COlb10mFSTlG1srZSkl2qMpdf0HXJGNtTvTg27f2ha4d"
        "rcW/d3ytCuIcT6m+HVtv4PO28/8ALfPR5ceYVPGM57evZj39DrDY+tLTd/affpuNKpdOEs/eVG4vPs5s+44z56r5rzXnJ+bznk5n"
        "j4GRk1O9otWNue/6lcO0TEz6bOyeLVClt6z0jbFtJclGVe8ml3+cqS5Pgso/RoVXR9ucMraprVO+lHV751oK0cY1MU2lF+l3Jxz7"
        "0dXiT2n35vEem0fRfK92KzLnfF6hSr6/aa5axfybV7Olcxb8cYw/XhR+JwVEhRpy347zbbq2Urw1iHP+CyqvdF55j7N9Dq3J/WzD"
        "Hb6z3O6Y6utgXsd8Tt3q0LiD05c1N1sNrm+s6cuM/wD3B1QhNtNRw4+Dbv68uf0YWxb24t3Y2i6Vc7v4XrR9IVOvqFnqfyipbupG"
        "EnBwayuZpY9L9DPx8VqlKje6NparU6txp2m0re4828qNRdsfb3+84PSq1KMuanOUJdmYvDLLk2222+9mN88TTh258o/YjHtbfdzq"
        "y/kav/8ArC/u4HBgQmrJk4tvpGzZWvDv9UKAUamZIUQHWSEBPoHMJEJiqEkQUoQEgSJCBCRECIISKURCRUJIgEQEgSJCgISIikQF"
        "EUkQkEJISKkKJCgISIgjQIUAkRGKlCgFAKEkKIqEBCpCiEgSISSISJEUiAkCRCBISEioQEBEBIISEioQEikQEghIQIQEikQFEEKI"
        "RIhAURSICQQkKAkKJCiMkJEQSNIEKIEiIilCgRoCRCiIOsiIT6BzUhIiKRQCgEiFEEJIiSFCAhSSITEQkKCoQQkCRCBCQkEICiKR"
        "BCRUJEAigNIipCRAJIhIFCAklUKAUQKFAhRAoSIKhRCRUjSAUBCQkEICSVIgJBCiFAQgJFIgJBCREUiRIgRAQqEkJBCSJBSICQQk"
        "JBCCEikUCEgSIQIUBoiwkJERSSIUAoQQkEICRShQI0gJEJGI/9k="
    ),
    "mercado_ok": (
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIj"
        "JSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk"
        "JCQkJCQkJCT/wAARCAEsAtgDASIAAhEBAxEB/8QAHAABAQEAAgMBAAAAAAAAAAAAAQACBgcDBQgE/8QAWxAAAgEDAgMDBQgLCgoJ"
        "BQAAAAECAwQFBhEHEiExQVEIE2FxkRQiMjdSgaGyFRcjNlV0daSxs9IWGEJiZXOTwdPiJjM1VnKSosPR4SQlNENmgpTC8FOElaPx"
        "/8QAGwEBAQADAQEBAAAAAAAAAAAAAAECAwQFBgf/xAA0EQEAAQMCBQEFBwQDAQAAAAAAAQIDEQQSBRMhMVFBFDJhcdEiNIGRobHw"
        "BjNS4RUkwSP/2gAMAwEAAhEDEQA/AOkBBCYvmkRCUSEBREIoBIiEBKJCAoiEUAgJEQRCQgSEBQQkRBEKIQIQEIhIgEkQhEJEBCAk"
        "YkQECEiAhREgjSFAhQGkKBGkAo0gQoBNIEKCNIUCFAaFAhQGhAUAo0jKNIBRpGUaQQmkCFAJpAhQCaQIUEKNIyjSAUKBCgNIUCEg"
        "0hRlGkAo0jKFAaFAhQGkJkQhIC3AiIgiIiCIiIIiZEEBEQSUREB1eJEZvUQoiKhEEJEKIiIEiIoRBCRChAQIiEIhBCAiAhERCEQo"
        "iCEiECEBCSkJCBEREQkQhEJCBEQgQgIQo0CFAaQoEIGkKBCgjSFAhQGkKBCBoUCFAaFAhQRpCgQoDSFAhA0hQIQhRoyaQCjSMo0i"
        "BQoEKA0hQIUUJpGUIGkKBCiI0hRlCgNIUZ3HcDW47mdy3CNbkBAaICAdyAghIBCICIIiIgiIiIjrAiI2vVIoBCEUCEiIQECEBREI"
        "oBASIgIQFBCKAQhIiCISECEBCISIBJEIRCRAQgKIxQkIEJEBCRBCICAoUAoI0jSMo0gFCgQoDSEBQGkJlGkEKNGUaQGkKMo0gNIU"
        "CFBGkJk0gFGkZRpAKNIyhQGkKBCBoUZRpBCjSMigNIUZQkG0QItwNI1uYTFBGtxRkUBodzIgO4huW4QkG5AO4gQQkG5BCQCEREBE"
        "JEQR1gICbXrFCAojFCRECRFuUJbgJEO47mdx3AdyDcdwhEyIGkRncUwjRBuO4ChTMimEa3HcymIRogFMIRQIQEiIiShJCEQkIERC"
        "BEQhEJCBCiII0hQIQNCjKNIDQoyjSCFGkZRpAaFAhQQmkZRpAKNGUKA0hBCgNIUZNIIUaRlCBpGkZQgaQoyhRBpCjIoI2O5lCgNC"
        "mZQoDQoyhA0QFuBoTO5BGtxMiEI7mR3ASAgh3IiCEgIiEgIISIgOshBCbHqkiEIiIAEiICEA3BhotzO5Ld9iYWIa3Hczyz+TL2Fy"
        "z+TL2F2z4XZPhrcdzHLP5MvYPLP5MvYNs+Dlz4b3LcxtP5MvYO0vky9g2z4NlXhvcUzG0vky9hbS+S/YNs+E5c+HkTFM8e0vkv2D"
        "vsTEpNEx3h5ExTPGmaTIwmHkTFGEzSDHDSNIymIQkQkYoUSECEkQEJEEQkIEJEEJEQCjSMo0ghRpGUaQCjSMoUEaRpGUKA0jSMoU"
        "BpCjKNAaQoyjQQoUCFAaQghQGkJlCQaQoyjSCHc0ZFAJpGUKA0hRkUBpCZQ7gaQ7mdxTCZa3LcCQRrcdzKEBENy3CETIgJbgIQkG"
        "5bkQ7kAhCQEEJEQHWhIhNj1UJIiCYEJRBuTYbkVbhKShHmk+WPiZlKMYuUntFdp+CtXlWnzPou5eB0WbO7rPZ12NPv8AtVdn6Kl8"
        "+ylFRXi+rPBKvUk+tST+c8e5bndFMR0h300xT0hrnl8p+0ueXyn7TO5blZYa55fKftLnl8p+0zuW4MNc8vlP2lzy+U/aZ3LcGGue"
        "Xyn7S55fKftM7luDDXPL5T9pqNepB7xqSXznj3LcGH7KWRkulVKS8V0Z+6lVjVipQe6/Qel3PJQrzoT5o9nevE03LNNXbu57umpr"
        "jp0l7tM2mfnpVY1YKcXun9B5kzz6omJxLya6JpnEvIhRlM0iNUtITJpEYkSECIiASIQiEhAhAQiIhAhIQxKEEKA0hRlGkBpCjKNI"
        "BQoEKCNIUCEDQoyjQCaRlCiI0mKMoQNCmCEDSFGRTA0hR3JwS4b4/L4y5z+fsqVzb1W6VrTrL3u0X76p7VsvVI4TxJy2nr/Nu10z"
        "jLW0x9q3Dz1GOzuZd8t/k+Ht7+lw6a9NNFqLtU9+0eriQoyKI5Wh3M7juBpMdzKEDQoyKCNCZHcBEyIQ7iZEB3HcCCNEBbhCQCRC"
        "RBuEJbgICQEEdbISFGx6yJkRAEIMoGZbFmV1kl6RDOmMvy3tX3ypLsj1frPy7jWnz1py8ZMxuepTGIxD2aadsYhrctzO5y3h3w8v"
        "eIGQrUqNeFraW3K69eUXJrffZRXe3s+9dhqv6i3YtzduzimG23bquVRTTGZlxTctzunUXk7O2xs6+DytW4uaceZ0LiCSqbdqi49j"
        "8Fs/WdKPdNp9GjRouI2NZTNVirOO7Zf01yzOLkNbludj4DhDK9x9O5yl7Ut6lWKlGjSim4JrpzN9/o+k45rLQ95pKpCpKormzqvl"
        "hXUeXaXyZLuf6T2LmivUUcyqno86jWWa6+XTV1cb3LczuW5yOprctzO5doGty3Oy8NwddexhWyl9UoV6kebzNKKfm/Q2+1+P6TiW"
        "sdH3Wkb2nTqVFXt6ybo1ktt9u1NdzW69p13dFet0cyuno5bess3K9lM9Xody3M7lucjqfuxtdxqOk+yXVes9pFnoKM+StCS7pI97"
        "F9Tj1NPWJedraOsVPMmbR4os8iOV5stoUCNIjEo5xwh0Rjtf6rniMpWu6NurWdfmtpRjPmi4pdZRktur7jg52z5NHxi1PyfV+tAs"
        "N2mpiq7TE9sux/3sGjObl+ymf32328/R/sjoribpCjobWd9hLWdepa0lTnRqVmnOUZQT6tJLtbXZ3H1Dmst9j+K2mrSUto5DH3lD"
        "buck6dRfUftOoPKjxXufUuIyiWyu7SVF+l057/oqL2FmHoa2xbi3M0RiYn+fu684aaSo631nYYS5nXp21fnlWqUWlOMYwcujaa7U"
        "l2d53v8AvYtGb8v2Uz++2+3n6P8AZHCPJexPujVWVyclvG0s1SXolUktn7IS9p3Ficr7v4s5+zjLeNhjLWk4+EpSnN/ROPsEQaKx"
        "bm3FVcZzP8/Z838X9D47h/qmlicXXu61CdpCu5XUoynzOUk1vGMVt71dx2Jw84CaY1Zo3GZu+vszTubuEpTjQq01BNTlHonTb7F4"
        "nHfKX+MK3/J1L69Q7s4K/FfgP5qf6yYiOrGxYt1amuiY6Q4v+9h0d+Es/wD09H+yL97Fo78JZ/8Ap6P9kdH5vXurqWZv6dPVWehC"
        "FzUjGMb+qlFKT2SXMfi+2DrH/OzP/wD5Ct+0Mw1zqdNE45b9+g9I2OqOIdrpu8q3NOzq1a8JToyiqiUITktm012xW/Q7v/ex6O/C"
        "Wf8A6ej/AGR1DwMnKpxYwk5ycpSlcNyb3bfmKnVncXlGZvKYPTWLrYrJXuPqzveSU7WvKlKUeST2bi1uhHZdLRa5FV2unOJ+jxS8"
        "mPSGz5cnnk/F1qT/AN2dd8SOA2Q0dY1cvirqWTxtJc1aMoctahH5TS6Sj4tbbeG3U4da8SdaWleFanqrNSlB7pVbydSPzxk2n86P"
        "rTSmTeq9E47IZKjDe/soyuINbRlzR2l08H1+ZjpLO1Rp9VE0007Zh8UJNtJLds7x0H5OMslYUcjqq7uLTzqU42NukqkY9q55NPZ/"
        "xUt14p9Fwfgzg6Gc4lYuhVSqW9vOdy1JfC5E3Hp/pcp3nx113f6L01b0sVUdC+yNV0o11tvShFbya37+qXo3ffsSI9WjSWLfLqv3"
        "esQZeT3oOVLkVleRl/8AUV1Pm+np9B1lxJ4CXGlMfWzGCu6uQsKC5q1GrFeepR+Vuukku/otv0da0NWagt7tXlPN5KNwmn533TNy"
        "bXi9+p9WcMtYrWmh7S9ys6HuqSnb3Kk4pVHF7OW38ZbNr0svSW+17Pqs0RTtl8go7B4PcOrTiHl76jka11RsrSgpynbSjGbqSklF"
        "byi1tspd3ccR1PjqWI1LlcdQadG1vK1Gm0994xm0voSPofyb8J7g0VcZOcdp5G6k4vxp0/er/a5yRDi0ViLl/bV2ju8cfJv0ZKpO"
        "nHK5uU4bc0VcUd479m6830OitcacWktWZPCxlUnTta21KVTbmlTaUoN7JLflaO8tAaz+ynGbVtk6jdG5ioUevTe3fJ09acmcR8pX"
        "C+5NT47LQjtC+tnTk9u2dN9v+rKPsE9nVqrVqqzzLUYxP+vo4Vwy0rZaz1fa4bIVbilb1oVJSlbyUZpxg2tm012rwO6v3tmkfwjn"
        "f6al/ZHzjZX11jq8biyua9tWimlUozcJLft6rqfVHA6+u8jw9tLi9uq91WdasnUrVHOTSm9ur6ilhw6LVyZt105nvl6Sfk2aUcfe"
        "ZPORl4yq0mv1aOFay8nzK4O0q3+EvFlaNJOUqDp8lZRXbt1al9D8Ezj2rte6rxet87TtNR5WlSo5G5p06Xuqbpwiqskkot7JJLbb"
        "Y7v4M8QLrXWArrJcssjY1I06tSMeVVYyW8ZbLon0knt4ekvSW2iNLfqm1FOJfLB2Bw14R5DXkZX1as7DFQly+fcOaVaS7VBdPnl2"
        "L09dvycYMDDC8RclbWtOMaVzKFxThHps5pNr0e+5j6Quqltw80JOdCip0sTZe8gunnJRj3+uXa/SSIc+k0dNVyqLvalxmz4AaKtq"
        "KhWo313NLrUq3DTfzR2R6fUfk54i5oTqYC/uLO4S3jSuH5ylJ+G+3NH19fUdK5jW2os9ezvL/MXk6kpcyjGq4wh6IxXRfMdo8COI"
        "eWu85+5vKXla9oV6Up2860uadKcVzNbvq01v0fZstu8Zhut3tLdqi3y8Z9XUWWxN7gslXxuRoSoXVvLkqQl3PxXin2p96PyI7r8p"
        "PDUqdxiMzTilUqxnbVWl8Ll2lH9MvoOk0SejztTZ5NyaPDSOx+HHB2+1rQWTvq8sfi99oTUN6lfbt5U+iX8Z9/c+7gGNtJZHIWtl"
        "F8sritCkn4OTS/rPrTVWWo6A0Nc3lnQjyY+3hSt6XcnuoQ39CbW4iHRoNPRc3V3PdpcftuAuiqFFQqW17cSS285UuZKT9Pvdl9B6"
        "DU3k72FW3qVtO39ehcRTcbe6anTm/BSSTj63udNZDV+oMtdyu73M31WtKXNv55xUX6EtkvmSO3+BHEDKZa+uNPZW6q3kY0HXt61W"
        "XNOHK0nBt9Wuqa37Nn81iYl02r2lv1crl4z6ulL6xucZeVrK9oToXFCbhUpzWzi13HbnDjg7gNYaTtcxf3eUpXFWdSMo0KlNQSjJ"
        "pbJwb7vE/N5ReHpWmoMblKcVGV9QlCpsvhSptdX6dpxX/lR2HwN+Liw/na36yQiOrDS6WmNTVarjMRH0es/e7aU/CGb/AKal/Znr"
        "8v5OeOlbSeGzF3TuEt4xvFGcJehuKTXr2fqOt9Xay1NbarzVChqLMUqVO/rwhThe1IxhFVJJJJS6JLuOf8DNd53M5m6wuVvK1/RV"
        "s7inUrPmnTlGUVtzPq0+bv70vFjp2Z0V6W5c5XLw62xej60ddWumM1CtbTncxoVvNtKST74tprZrqnsdx/veNK/hDN/01L+zOOeU"
        "JTeNzuCy1nUnb3s6VSPnqUnGa5JRcWmuqfv31Otv3c6q/wA5s3/66r+0OkNGbOmrqt3Kd3V3Z+950r+EM3/TUv7Mf3vWlfwhm/6a"
        "l/ZnMcVc16mg7O6nWqSryxcKjqyk3Ny8ynzN9u+/Xc+Yv3caq/zmzf8A66r+0WcQ69T7NYimZt5y9zfaOx9rxPjpWFa6di7ulQ84"
        "5R87yyUW3vy7b9fA5TxK4SYPRumJZXH3eSq141oU+WvUg47Pt6KCf0nCtDXtzkOIWFuby4rXNepfUnOrWm5zl1S6t9Wd18d/vBqf"
        "jVL9LJEdHLYtW67F25t84+DqnhRoXG66yF/b5KveUYW1KNSDtpxi229uvNFnZX73zSu+32QzW667eepf2ZxfydP8s5f8Wh9Y7Lp5"
        "LzHFSvjm9lc4WlVXpcK1Rfom/YIiMOjRWLNVmmqunMzOHzfqvCrTmpMjiYynKna15Qpyn8Jw7Yt7d+zR7jhlo+21tqOWOvKlxStq"
        "dCdacqDSktmkurTXbJdx7fjvjfcWupXKjtG9tqdZvubW8H9EF7Tkvk6Y58uZyUl0+528H7ZS/wDaTHVw2tNE6vlTHTM/k90vJ+0q"
        "219kMzuu1eepf2Z0/wAQNO2ulNWXuHsqlepb26puMqzTm+anGT3aSXa33H0HpXJfZLVerGpbwt7ihbx9HLT6/wC1zHR/Gf4x8r6q"
        "H6mBao6OniFm1TYiu3Tjrj9/oxw/4aZDXVWdZVPceOpPlqXMo83NL5MV03f6PoO27LgVpC2pKNeF7dz751K7j9EdjkGEoW+itBUH"
        "5venj7B16qj0c5KHPN+tvf2nzhndb5/UN9Uu7zJ3K5pbxpU6jjTprfolFdOnj2+I6QtVFjR0U8yndVLt/OcAcJdUZSw97c2NdL3s"
        "ar87Tfr/AIS9e79R0nnMHf6cydbG5Ki6NxRezXapLukn3pnYvBviBlo6ioYHIXda8s7xSjT89PmlRmk5Jpvrs9mtvTue78obEUpY"
        "/FZhRSqwrO1lLbrKMk5JP1OMv9ZknExmGu/Zs37E37MYmO8OkBM7iYvGJbgQQkG5ER1yJIjY9dEIFEZZoywMyMxf3SPrQyMx+HH1"
        "otPeG6370PVN9WW5lvqy3PTy9lrc+hPJxpwWlMlUUVzyv3Fy72lThsvpftPnnc+iPJw+9HI/lCX6uB89/U8/9Cr5x+70eF/eI/F2"
        "wfHeao0460vqCglSWSqQ5e7l861sfX15eW+Ptat3d1qdC3owc6lSb2jCK7W2fF2oMnG/1Bkb60nNUq13VrUpdktnNtP0PqeN/R2Y"
        "uXKsdOjs411ppj5vpo/FmMTbZzG18fdx5qVaOz27Yvua9KfU4jww09nKFt9lc5kshPz0d6NnVrSain/Dkm+19y9vo57NJbeJ+sWO"
        "P2NRejTbZ+10+D8luaii1qOVRVnHrHl8153DXOn8pXx12vf0n0kuyce6S9DPwbneXEbSC1Li/dFrTTyFqnKnt21I98P616fWdFvd"
        "NpppruPO12lnT3NvpPZ9jotVF+3n1ju1ufuwMY1M5joTScZXVJNPvXOj1+5+/Tz/AOv8b+NUvro5bfvw6bnuy+lDr7jPGP2AsptL"
        "mV0kn4Jwlv8AoR2CdfcaPvds/wAbX1Jn1/EPu9fyfKaD7xR83T+5bmdy3Pjcvrmk+qPfxfV+s48n1RyCPa/Wc2p7Q4tb7sPNE8sT"
        "wxPLE43ky8iNIyjSDBo7Y8mj4xan5Pq/WgdTnbHk0fGLU/J9X60BHdv0n96n5uwONGVeE4kaAv8Am5Y0q81N/wARzpxl/stnn8pv"
        "E+69FWWQjHeVlexUn4QnFp/7SgcY8qltZHTrXR+ar/Wgdj60S1rwVu7qK55XOLp3yS7eaMY1dvXvHYr1K/tzet/Kf0cc8mHE+5dH"
        "ZDIyjtK8vHGL8YQikvplMxwfyv2b4o69vt94zqxjB+MIzlGP0RRyXQMY6M4L2V5Ncrt8bUyEt11bkpVf60jrjyWpOeY1BKTbk6FF"
        "tvtb5pDwU/Ymzb/H9HpfKX+MK3/J1L69Q7s4K/FfgP5qf6yZ0n5S/wAYVv8Ak6l9eod2cFfivwP8zP8AWTEd2Om+93P54Zr4HhbO"
        "vUlXtNKOq5Nzc3R5nLfrv17dz0WtcHw0o6PzdTH2ul43kLCvKg6Lo+cVRQfLy7PfffbbY+ac9/l3I/jVX67Pwky5a9fE5jZDnvAn"
        "41cH66/6iofTWttB4jX1jb2WYdyqVvV89DzFRQfNs116PuZ8zcCfjVwfrr/qKh2/5SGVyGJ0zi6uPvrqzqTveWUrerKm5Lkl0bTX"
        "Qsdm7RVU06WqqqMxn6P3W3k66GoVoVJ0sjXjFpunUufey9D2Sf0meNOfzulNIuw09hp08fOgqFW/pOPJaU373kjBdU9tlzbbLdbd"
        "ez5zpa31TRqRqU9SZhTi90/dlTt9p9b6hm8jw2yVS5SnKvh6s59O1ui2/pENli5bvUV02o2zh8++Tp8Y9P8AE639RzHypf8As+m/"
        "9O5/RSOAcB8nSxvEvGqtLljcxqW6b+VKD5V87SXznbvlFaVvM7pW0yNjRlXqYurKdSEIty81JJSkkvBqLfo3fcPRz2YmrRVxHn6P"
        "mIRhCVScYQi5Sk9kkt234H1bwl0BaYnQtjTzuFs5X9Vzr1Fc28ZTgpS3inut0+Xbp3EiMuHS6aq/VNMdHymuvQ+yMdShw/4a0lUS"
        "TxWNdSa8aihzS9st/afOGncbb6t4xU6FpSpqyr5apcRhTilBUYzlU2SXRLljsfUeo9T4PS9rTrZ2+o2lCtPzcHUi5KUtt9tkn4Fh"
        "6HDbcUxXXM/DP8/B8n8Nc9PDcQcPkqtR7SulTrTb7Y1PeSb+aTZ3x5Q2E+yegnewjvUx1xCtuu3kl7yS/wBqL+Y9quK3DnuzeP8A"
        "6CX7J77JU7HXGj7ulZV4XFpk7SpClVj2PmTSl18H+gRHRvsaamLVdqK4qy+LUfVHAH4trP8An6312fLE4TpVJU6kXGcG4yi+1Ndq"
        "PqbgB8Wtn/P1vrslLh4V/en5fR88a9+/rUf5Uuv1sjtnyYOzUv8A9p/vjqnWttXutfaipW9GpWqPKXW0acXJv7rLuR37wH0Zf6V0"
        "3dXWUt5213kasZ+ZmtpQpxTUeZdzbcnt6hHc0NEzqt0doy6645fGpa/zNv8AWZ3Jxa+LnO/i6+tE6C4zZynkOJd/WtpxnGydOhGS"
        "e6coJc3slzL5j6L1FYw1toe8trKpBrJWXNQm373eUeaDfo32LHq69PO+q/TT6/7fHJzzgd8ZuI9Vf9TM4VfWF3i7urZ31tVtrik+"
        "WdKrFxlF+pnafk96VvbzU/7oJ0JwsbKlOMKsotKpUknHaL79k5b+HTxMY7vJ0lEzfpiI9XLPKT+97EfjcvqM+fTvTylslSVDCYxS"
        "TquVS4lH5MUlFP595exnRKFXdt4lOdRP4Pc6Q++vC/j9D9ZE+kOOHxaZT/SofroHzJhr2ONy9jeyTcba4p1ml27Rkn/UfWPEDBz1"
        "dofI4+ylGpUuKMatBp9JyjJTik/Ttt85aezp4fG6xdpjvj/yXyKjsngB9/8AH8Uq/wDtOubi2r2dedvc0alCtTfLOnUi4yi/Bp9U"
        "dxeTxpa9+y11qKvRnSs4UHQoynFrzs5NbuPikotP0v0Mkd3FoqZm/TEeX7vKV/xenfXc/wC6OXcDfi4sP52t+skcE8pHI0quUwuP"
        "jJOpb0ataa8FNxS+oznfAz4uLD+drfrJGUd3rWpzr68ePo9fleAeBy2UvMjVyeThUu68684wcNk5Scml73s6nI9H6AwHDu2uq9pU"
        "qOVSO9e6u6kd1Bddt0kox7/09iOh9WcQNV2eqszbW+oMjSo0b6vTpwjWaUYqpJJL0JHG8pqrO5un5rJZi/u6e+/m61eUo7/6O+xM"
        "w5p1unt1TVRb+05Vxh1rbax1JD7Hy57Cxg6NKpt/jZN7ykvR2JerfvOB7mUJi8q7dm5XNdXeX1vh/i6sfyRT/Uo+S0fWmH+Lqx/I"
        "9P8AUo+SkZVPT4r2t/L6OScO/v6wP47S+sjvHjv94NT8apfpZ0bw7+/rA/jtL6yO8ePH3gVPxql+liOxo/ul3+ejhnk6f5ZzH4tD"
        "6xyHVeS+xnHXTs3LaFayjbyXjzzqxS/1mjjvk5/5ZzH4tD6x4eOl5PHcRcVe0/h29nQqx9ca1Rr9A9GVFezRU1+J/wDXuvKLxvNa"
        "YbJpfAqVLeT8eZKUfqyOScEbCOM4e0bmouT3VVq3Mm/BPlT9kEb4yWcMxw4ubmiudUJUrum/Ruk3/qyZ+jK/4I8I6tPfkqW2LjR3"
        "8KkoKO/+tIvrl2cuKNVXenttz/Pyeh4F38sr+6a/lvzXV8qz38Zcz/rOt+M/xj5X1UP1MDnnk6f5KzP8/T+qzgXGf4yMr6qH6mBJ"
        "7PP1M50FEz5+rvnWPxfZf8mVf1bPlI+sreNLV2hoQpzShksdyKT/AILnT26+pv6D5WymLvcLf1bDIW9S3uKMnGUJx2+deKfc+8lS"
        "8YiZmiuO2HIOFvxgYX+ff1Wdt+UB95dr+UKf6uodfcEtM3mU1db5XzM42NhzTnVcXyym4tRin47vf1L1HNfKHyFOngMZj+b7rWun"
        "XUf4sINP6ZoR2NNE06G5NXr/AKdEFuBGLxCQCRCQEVHXZEJm9hAIFRGWaBhlDxyML4cfWjcjxr4cfWWnu22+8PUt9WG4N9WG56L2"
        "Wtz6H8nSrTo6MylWrONOnC+nKU5PZRSpQ3bfcj523PcUdZZGz0nX0zaT8zaXNy7i4nF++qrlilD0R97u/Hp4dfM4voqtZY5NM4zM"
        "fk6tHfizc3z4cw4w8WKmsbqWHxNWUMLQn1kuju5r+E/4q7l877tvLwu4ce6HSz2Zo/cltO1t5r4fhOS8PBd/b2bb/l4YcOPstOnm"
        "8vS/6DF70KEl/j2v4TXyf0+rt7fyWRtMPYVb29rRoW9GPNKT7vQvF9yRoim3pbcabTx0j+fm+P8A6h47XdrnT2ZzVPSZj9o/n6vH"
        "ms1Zafx1XIX9VU6FJfPJ90Uu9s660Fq/I6u11eXVdunaRs5xpUE/e0lzw29cn13f9SOEaw1bkNeZmnTo06qt1PktLWPV7vpu0u2T"
        "+jsOV3uBuOG+jrS+pTisrK+pVa011S2hP7n6Vs2n47v0HucH0k2q/aKo93rP0atHwqnS2sXf7tfSPh/PWXbR09xW0d9jrp52yp7W"
        "1xLa4jFdKdR/wvVL9PrOztO5621JiaGRtXtGotpw33dOa7Yv1fo2Z+y9sqGRtK1pdU1VoVouE4PvTPstTYo1VnEfOJa9Per013M/"
        "KYfMO57DTz/6/wAZ+N0vro/Rq3TdxpbM1bGrvKk/f0Kr/wC8g+x+vufpR+XTr/wgxn43S+uj5GKKqLsU1d4l9VNcV25qp7TD6XOv"
        "uNP3u2X44vqTOwTr3jV97ll+OL6kz63iH3av5PltB94o+bpzctzO5bnxj65tPqjkEe046n1RyGBz6jtDi1vuw88DyxPFA8sew5Hl"
        "VPIjSMo0iNbSOwuB2qsPo/Wk8lnLz3JaOzqUlU83OfvnKLS2gm+59x16hDK3cmiqKo9HbXH/AFzp7W15hamAyHu2FtTrRqvzNSny"
        "uTjt8OK37H2HNOFvF/R2L4e2GF1HlVQuqEKlCpSlbVailTcpcvWMGtuVpdvcfOQly306yum5N2IjMvo7ibxf0ZkeHuQwunMqq1zW"
        "p07elRjbVqajT5o83WUEtuVNdpwjgFrfT+ishl62fv8A3HC5o040n5mpU5mm2/gRe3b3nVAjKVayuq5F3EZh2Hxx1XhtYaxo5HB3"
        "nuu1jZU6LqebnDaalNtbTSfY0do8MOL2idO6DxGKymb9z3lvTlGrS9y1pcrc5PtjBp9GuxnzYQylvWV0XJuxEZl9efb44df5xfmV"
        "x/Zl9vjh1/nF+Z3H9mfIgjc6P+Vu+I/X6ue6G1PicPxdhqC+u/M4xXd3Vdfzc5e9nCoovlScurku7vOY8d+I2l9Z6fx1pgsp7srU"
        "bvzs4+Yq0+WPJJb7zil2tHSSIZclOqri3VaiOkk+m77jHoatoW4xdPOb3k8XK3jT9y1+tR0nHbfk27e/fY+ZCESljU1Wc7fV5KFe"
        "rbV6dehUlTq0pKcJxezjJPdNPx3PovQflE4q9tKVnqzmsb2CUXdwpuVKt6WoreLfq29K7D5xEROE0+prsTmh9fU9c8NLSXuyjldP"
        "06nbz01BVPoW517xR4+WN3jLjC6TnVqyuIOnVv3FwUYvtVNPq21ut2lt3b9q6EIZdF3iVyqnbERDsfgdqHTmlNSXeW1DkFaKFs6V"
        "uvM1KnNKUlu/eRe2yW3X5R+/jvxBxGtbzFUMFeu7s7SnOc5+bnTXnJNLbaSTeyiuv8Y6qImXNGqqizyYjoTv3g5xb01p7RdLEZ/J"
        "u0uLWvUVKLoVanNTk+ZPeEWu2Ult6DoIRE4TT6iqxVvodn6f1JpXD8ZrrN+74SwVSpXqwruhUa+6Qb25OXm6Sk12d3gdyU+N3Dql"
        "Hlp52MI+EbKul+rPk0UXc32eIXLUTFMR1nP86vrKfHTh/GO6zspvwjZ19/pgcL1t5RVpKyqWelLetKvUi4+7biPKqW/fGPa36Xtt"
        "4M6CQobpZXOKXqoxGI+TySnKpOU5ycpye7k3u2/E7V4W8a6mkbWnhc3Rq3WMg/uNWn1qW6b7Nn8KPf4r09EdTo0YxLjs3q7VW6ie"
        "r60jxE4dZynCvWy2Iq7dV7rgoyj800mes1Hxz0jp+0lTxdb7K3MVtToW0XGmn3bza2S9W79B8vijLdLuq4rdmOkREvb6o1NkdXZq"
        "vlslUUq1V7KMekacV2Riu5L/AJ9p6tMyhRi8yqqapzPdpHb3DHjetPWVHCahp1a1lRShQuqa5p0Y90ZLviu7bql02fd1AhEThss3"
        "67NW6iX1j+77h5loxuquWw1WSW8XcxUZr5ppNHptT8dtMYS1lSw83lbtLlhClFxpQfdvJpdP9Hf5j5o3FMy3O6ri12YxEREvY53O"
        "32pMtcZXI1fO3NxLmk+xRXdFLuSXRHdPCjibpPTWibTG5XLe5runUquVP3PVnsnNtdYxa7H4nQwoxicOOxqq7Nc3I6zPl7XU97Qy"
        "Opste2tTzlvcXtarSns1zQlNtPZ9V0a7T1plCHPVVmctITKHcI+isbxY0Zb6LtcbUzPLd08bC3lT9zVntUVJRa35Nu3v32PnhMxu"
        "ImcujUaqu/FMVRHR7zRmRtsTqzE397V81bW91TqVZ8rlyxT6vZJt/Mdq8WuI+ltT6Qnj8TlPdN069Oap+Yqw6Lfd7yikdHpjuM+h"
        "a1ddu3VaiIxLsjgrq7C6SyeSr5q99yU69CMKb81OfM1Ld/BTPy8ZNTYnVeqLa+w137qt4WUKUp+bnDaanNtbSSfZJHAty3GemEnV"
        "V8nkYjH6voTTXFTRdTRmPxeeyMfPRtIW9xQqW1WafKuXq1Fp7pb9veep4t8TdO6h0k8ZhMi7qtWuKfnI+ZqQ2px3lvvKKXwlE6S3"
        "Iu6W+vid2q3y5iO2Pj+7trgtrjT+ksfk6WayHuWderCVNeZqT5kk0/gxZxHidm7DUOtshksZce6LSsqXJU5JR32pxi+kkn2p9xxT"
        "ciZ6Yc9eqrqsxZnGI/P+dXY3DPi1W0ZS+xeRo1LrFOTlHk/xlBvq+Xfo03126dep29T4haBztGNStlMZNLsjeQ5ZR+aaPlwtyxVh"
        "u0/E7tqnZ0mPi+ls3xj0hgLRwsbhZCtFe8t7SG0fnltyperd+g6F1bqzIayzFTJ5CSTa5KVKPwaUF2RX6d+9s9IRJqy16rX3dRGK"
        "ukeIaINy3MXE0QEEJAQHXokRtewiEAgBiDIsPHI8f8KPrPJI8f8ACXrMo7w3W/eh6Vvqy3Mt9WEn0PQe0py7kc84a8O5ajrRymTp"
        "yjjKcvewfR3El3L+Ku9/N47es4caQp6uzbp3MnGztoqrWSezn12UV4b+Pgj6A/6LjLP/ALq2tbeHojCnBL6EkcOq1G37FPd81x3i"
        "82P+tZ9+e8+Pl8Rc3NrirKdevOnb2tvDeUn0jCK/+dh0Dr7XVzrG/VKgp08dRltQo9832c8vS+5d3t3/AE8ReINXVd07GxlOni6M"
        "versdeS/hP0eC+ft7OL2FGpb5e3pVoSp1IXEYyhJbOLUtmmvEuk022Yqr7ycF4P7PT7Rfj7fpHj/AG7l4b8PoacoRyWRpxlk6sek"
        "X1VvF9y/jPvfzeO9xl+9Ol+Nw+rM52cD4zfelS/G4fVmfe6ixRZ0lVFEdMNOnvVXdVTXX3y6/wCHesZaXy3m7ib+x901GsvkPumv"
        "V3+j1I77jKM4qUWpRa3TT6NHytudv8JNZ+7Ldafvqn3ejHe1lJ/Dgu2HrXd6PUeZwjW7Z5Fc9J7fR6HFdHmOdR39fq5RrnSdPVeG"
        "lRioxvKO87ao+6XfF+h9nsfcdG4OjUt9TY+jWhKnUp3tKE4SWzi1NJpn0qdea60ZzZ/G6isafVXdFXcIrtXOkqn9T+Z+J2cT0W+Y"
        "vUd47/L/AE5eHavZE2a+09vm7DOvONf3uWX44vqTOwzrzjZ97ll+OL6kzr4j92r+Tl0H3ij5umty3M7lufFvr2k+qORwONJ9Uclp"
        "nPqO0OLW+7DzwPNE8MDzROV5NTaNoyjSI1SUKJCEQkQCICEREIEJEGJEBAhAQiEhAiIQiEBAhIQiIiIhQoBA0hRlCgNIUzI7hGy3"
        "MjuBrcUZQoDSFGUaCFCAoBFMzuO4RpMdzKFAIoBQQjuZEDW5bhuREa3LcBCEdzI7gO5bgJEImdx3KhLcNyINEAhCQEB1+RCja9hE"
        "IEAZZoGFh4pHjfavWeWR432r1lju3W/eh6FvqwfYDfVlueg9vD3ekdWXmkMp7utYQqxnHzdWjN7Kcd9+3ufTtPbay4m5LVturONG"
        "NjZbqU6UJuTqPu5pbLdejb+o4ad5+T7orAZrE3OayWOpXd7bXrp0ZVW5RglCLXvN+Vvdvq0zz+Iam1pLc6m5TnDXa4VZ1Opi5tjf"
        "5eTgnwjcXQ1TqC2afSdja1F2eFWS+qvn8DqrOP8Aw9yH5VqfrmfZJ8aZt/4fX/5VqfrmeJ/T2vu6zV3LtzxGI8Rl7PEtPTZs00U/"
        "F9HHAuM/3pUvxyH1ZnPTgXGj70aX45D6sz9h1/3ev5PznQ/eKPm6Q3PNaXdexuaV1bVJUq1GSnCce2LXYeDctz4mJmOsPsJjPSX0"
        "ho3VNDVmFp3kOWFxD3lxSX8Cf/B9q/5HvO0+c9EasraSzULr30rWrtC5pL+FDxXpXavnXefRFtcUby3p3FvUjUo1YqcJxfSUWt0z"
        "7Hh2s9ot/a96O/1fKcQ0k2LnT3Z7fR5Trvjb97dl+OL6kzsQ6643fe3Zfji+pM2cR+7V/Jr0H3ij5umNy3Dctz4p9hhpPqjk1PsR"
        "xdPqjlFLsRz3+0OHXe7DzwPNE8UDzROZ5FTa7TSMo0RrlpCCEIRAQhIiAhIQiEBCEiICFEIRCAgQkQQkQgQkREQgIQiAgQkQRCmR"
        "AO5pMyIRoUZEDSHczuKYRrctwRAaQmRQRoUZEDQmdy3IjQmdx3CEQIDRAW4RoTO4gImdxCHcTIkCIFuEImdx3CEgIDgIkhNj2URE"
        "BkGaBhYeKR45HlkeOSLHdttziYccb6stxrx5K04vukzG53Ze61ufR3k0Ti9IZOO65lkG2vQ6cP8Agz5v3OY8N+JeQ4d5CrUo0Y3d"
        "jc7K4tpS5d9uyUX3SXX0P2NeVxnSV6rS1WrffpP5OrRXqbV2Kquz69PjDN1oPXN/VUl5t5SpLm7tvOvqdqak8pV3OMqW+AxNW1u6"
        "seX3RczT81uu2MV2vwb9jOjZTlOTlJuUpPdt9rZ5n9N8Ov6Sa7l6MZxiHVxPU270RTROX1gcA41SUdJUU3s3eQ2Xj72Zx/T/ABrn"
        "aWELfMWNS5rU48qr0ZJOaXZzJ9/p+g4trjXt3rKvTjKkrayoNunRUuZt/Kk+9/oP1DWcTsXNPNNE9Z9HxGk4deovxNUdI9XGNy3M"
        "7lufLvo2tztHhBrTzFVacv6v3Oo27Scn8GT7YfP2r07+KOrNzUKk6U41KcnCcWpRlF7NNd6OjS6mrT3IuUufU6em/bmip9XnXHHC"
        "cVp2xhuuZ3aaXilCX/FHrMJxvjRsY0sxj6ta5gtvPUJJKp6Wnts/V9BwzW2trvWV9CrUpq3taKao0E9+Xftbfe3sj39dxOxc0800"
        "TmZeJouH3qL8VVxiIcd3LczuW58w+jaT6o5XS+Cji1CLnWhFd8kcqprZJGi/PSHBr5+zEPNA80TxQPNE53kVNo0jMTSI1y0jlGjd"
        "GUtVUMjcV8pHH0rGMJTnKlzrZqTbb5lttynF0djcLbend4DVVvVuIW1OrbwhKtP4NNONVOT9CMa5xGYab9U00TMPyPQWnFFta7x7"
        "aXZ5qPX/APYejtNMO50jeai91KKtbhUPMeb35t+Trzb9Ph+HcezvNE4a2tK9enrHGV506cpxpRS3m0t1Fe+7X2H68V8UOZ/H4f7o"
        "xz8WrfOMxVnrHo4KRHY2VttMaawWn8hXwavru8tIzlTdaUISfLBynLt69ei7OrMpnDbXXtxGO7roTsjP2mksBbY/Owws7lZOlGdK"
        "ynWcadPZJyk313fvorbs7T1WtdP46NDCZPC20ranlof9nct1Cfvdtm/9L6CRXlhTeiqY6d3DRO0rvA2GkVRsKGj7vUNdwUri7dOb"
        "hu+6O0Wv+HTqzj+ttLWmKrYzIWNvcW1pkPhWtdNToSW28Xv17/ofoEVxKU34qnHlw0jsrWdDR+l72rZRwc691Wo80dqsowo7ppNd"
        "er3W56+yx2D0npyxzGXsPspfZHeVC3lLlpwgu9+PRrtT7V6xFfTKRezETju4MJzDMS0xndP1cnYUKOHyVvNRlaed3VaL74r/AIJd"
        "j9B59ORw1thKVahpy61Dk5zfno+am6dFdyWyafd6e30F3dOy83pnDhJHNdcYC0o4fH521xlbEzupulWsqia5JLfZpNLbflfd16H6"
        "61ngdDYaxlkMVHLZS/pKrKNWW0KUWuzv8duzd7PquhN6c6JiMQ45jNM/ZHTeSzXuvzfuGUY+Z83vz77fwt+nb4M9Idm0auJuuHWd"
        "u8TbTs41ZR89bSnzqlNOPwX3prZ+09Rh8VhsBpejqPM2jyFa6qOFtauXLBbbreXsfj3dCRX3yxpu98+XCROeRscHrbDZC5x2MWKy"
        "dhT875ulLmp1YJN9my8H3Lu7TghlE5bKa9yI56rHT2I0XicxeYr3ZdVpSjyKrKCqPeXWT8El2I/RkrTStvg7HVUcNNxud6UbBVWo"
        "Opu1zN+C5Zdnb06GO9r53w+DrsjmOq8XibjTWO1HirN2Kuaro1bdTcoprm6r/Vf0dD29DTtppnEWVaWm7nP5C7pqpU2hKVOimk+X"
        "omt+v6ewb4ObGHXB73UWmf3P22Pre77e692UvOctL+B2e1de3p2M9zrDTdrDC22fssdcYt1KnmriyrRa5JddpLfrt0+ldnU8OrMD"
        "a29HTlPH20aVa+toObTfv5tR6vf0sbs4TmRMxhxEjn2WnprRNeGJ+wsMvdRhGVxXrz5dm1vsls9unX512nrNW4LG0sZYZ/DRnSsr"
        "5uMqE3v5qa36J/NL2CKli5nHTu4qeShRqXNanRpQc6lSShCK7ZNvZI7D1LbaR0xVto1cLO5uK9vGSpxqyjCC3fvu3tb+r3HrMRi8"
        "RgtM0tQ5e0d/WupuFtauXLHZbrd+x+Pd0G/pljzcxnD0epMFT07exsfdsLquoKVZQhsqTf8AB336v/kepOcxssJrPD39xj8asXkr"
        "Gn53zdOW8Kser7Ong+7w7Tg5aZytFWYxPdCRGTNCgEIRQCAluRBDuO5kUQaEyIQjuZEDRAREaEyJUImRIHcQEIhAQEgEIhIQIhII"
        "4CKIjY9ogJABlmgYIeOSPHJHmkjxyQbIl6TLUPN1VVXwZ9voZ+Dc5FcUI16bpyXR/QeguKE7ao4TXqfidVurMPX093fTj1hjctw3"
        "LczdB3LcNy3Ady3DctwHctw3LcB3LcNy3Ady3DctwHctw3PLb287mooQT9L8Bkftw1u6tx51r3sP0nIYI/NaW0LakqcF6/Sfrgjl"
        "uVbpeNqru+rp2eSKPLHsMRR5UjBwzLSNIyjSI1tHP+GlfHvD6jsL3J2lg72jCjCdxUjHtjUTaTa323RwASVRmMNdyjfTtc6+13hv"
        "8+cL/rw/bPDjb+0p8LctZTuqEbqpfRnCg6iVSUfuXVR7Wuj9jOGETbPrLDlzPvTlHNNdX9peYDStK2uqFapQsuSrCnUUnTly0+kk"
        "ux9H2+BwsSzGZyzqpzMT4cz1rf2l3pjSlG3uqFarQtpxqwp1FKVN8tPpJLsfR9vgebU2Wtv3L6T9y3VvVubSLlOnCopSptcrXMk9"
        "12d5wcSbWuLURj4O2MrWq6xnRyeA1f8AY2MqcVXs6t3Ol5qS7Wkn/Vs9u04lq24t6d9Y2lDUN7mVR2lXqVqznSjU3XwN32e31nFS"
        "JFGEps7fVy/ijfWuQ1Q61nc0Lml5iC56M1OO/Xpuj98KmO1tpfGY2WStsdlMYnShG6ly060Hsukv/LH2Pp13OBCXb0iDlfZiIns5"
        "hmMLgdNYGrbV7q2yebrzXJK2qNwtort32fXv7V3rp0OR291Vy2lMRQ05qGyxM7Wly3dGtV81Jy2W8t0m+3d+D3OrBJNGfVKrWY6z"
        "1dlamusfmdGQs46itrq8xtV1Ks69TaVy0pb8m/WS3lsvUeO+o43iHi8fWo5W1sMpaUfM1aFzLlU0u9Pw7X037TroiRR4YxZx2l2P"
        "y4XB6HzeIoZi2u7yUoym4zilOW8fe01vvJJLqz8eNucZqrSFtgbrIUMfkLGo5UJ3D5adWLb6b/Pt8yOCiXYvK+PXu7AtI47QOHya"
        "qZS0v8te0nQhStZc8aSafVv59+u3YjgACWIwyppxmZ7y5jnr60rcP8Da0rqhO4pVJupSjUTnBby7V2oMtfWlThthLOF1Qlc07mpK"
        "dGNROcFzVOrj2rtXtOHiTax5cfrlzDI31rPhnirOFzQlc07yUp0VUTnFfdOrj2pdV7T38shU1fiMfLF6k+xOQtqSpXFvO4lSjPbb"
        "3y27fp7e7Y6xEk0JNqHLNXShZ2NvZPU15l7tycriHuh1KEduzbd9v/zoex1vcysqGkrqCTnRtKdSKfe0oP8AqOG4qrZUL+jUyFtK"
        "5tYt+cpRk4uS28U137HttXampairWkbW0dra2dLzVKEpcz2//iS+YbesMdk5iHIM9iMZra9WZxmasLWdanF3FC7qckqbSS39iXo6"
        "dvU9fq7J423weO03i7lXlOzk6tW4j8GU3v2ePwpfQcPERSsW8Y69Icv4lX1rf5WxnaXNC4hGyhCUqVRTSlzS6PbvP0464xuqNJW2"
        "Dub+jYX9lUcqM672hUi2+m/z7fMjhAjb0wcv7MR4c9tY4/QmIySnk7W+yl5SdCFK1lzRprZ9W/n367diOBkRYjC0046kiIyZFCAo"
        "IhIQiIiIEQEqSSIiBIhIiEEJUJERBCQglCRBCREAkQoIhIQiIiCOBIQE2PbIMSYQA0JAYaMNHlaMtBlEvDKJ+evbwrw5Jx3X6D9b"
        "iYcSxOG2iuaZzD0VfE1YNuk+deD7T8cqNWDalTmvmOTuJhwNsXfLuo1n+UOM8svB+wuWXg/Ycl5PQXJ6C82Gz2ynw41yy8H7C5Ze"
        "D9hyXkLk9A5sHtlPhxrll4P2Fyy8H7DkvIvAeReA5sHtlPhxnll4P2Fyy8H7Dk3m14IfNrwQ5sHtlPhxjll4P2G40Ks3tGnNt+g5"
        "Mqa8EajTXgOb8GM62nw9Jb4atUadX7nHw7z3NraU7aCjTjsv0nmjA8kYmuquZcl7U1V9O0GMTyxQRieSKMHHVLUUeRIykbRGqSjS"
        "BGkGJREe7w+i8/n7b3VjsdOtQ3cedzhBNrt25mtyTMR3Y1VRHWZelI5T9q/V34I/OKX7Q/av1d+Cfzil+0TfT5Yc6j/KPzcWE5T9"
        "rDV34J/OKX7Rfaw1b+Cfzil+0N9PlObR/lH5uLico+1hq38E/nFL9ovtY6t/BP5xS/aG+nynNo/yj83FyOU/ax1b+Cfzil+0X2sd"
        "W/gn84pftDfT5ObR/lDi4nKPtZas/BP5xS/aL7WWrPwT+cUv2hvp8pzaP8ocYI5R9rLVn4J/OKX7Rfaz1Z+Cvzil+0N9Pk5tHmHG"
        "COR3HDvVFrQnWq4qfJBc0uWrTk9vUpNs46WJiey01RV2lCRFZEiIjFCSECEhAiIghIhAhIQiEBCIQEISIQISIIhASBIhKiEBIISJ"
        "EYkQEoiISCQkSCEQECIhCISECQgIREJBHAhATY9tEQoIC2HYgAGjWwbAyw0ZcTy7A4hll4XEy4Hn5Q5Qu54OQuQ83KXKF3PDyDyH"
        "m5S5Au54eQeQ83IXIE3PFyFyHm5B5Qm54lA0oHkUTSiE3MRibjE0om1EMJqEYm0iSNJEYTJSNIEjSDGUjaBIQiOdaS4pVtMYenjJ"
        "4yF3TpSk6clW820m22n7179WzgxEmmJ6S1126a4xU7T+3j/4f/PP7g/bw/8AD/55/cOqxMOVT4afZbXj93af28P5A/PP7g/bv/kD"
        "88/uHVgjlU+D2W14dpfbv/kD88/uF9u7+QPzz+4dXEOVT4T2W14do/bu/kD87/uD9u7+QPzv+4dXEOVT4PZrXh2j9u3+QPzv+4P2"
        "7f5B/O/7h1cI5VPhPZrXh2h9uz+Qfzv+4X27P5B/O/7h1eI5VPg9mt+HZdzxorVKE4UMLClUlFqM5XHMovx25Vv7TrUhMqaYp7M6"
        "LdNHuwhASs0RCEQohAhJEEQgIEJCEQkQCREEIgIRCSEIiIiBEBCISIoSIiIRASISIiiFERAiCEISIgISEIhIghIhCIiIDgZERse0"
        "hIQJFsSFBAWw7EEGxbCOwXLOwbGy2BljlHlN7FsDLHKPKb2LYGWOUeU3sWwTLCiPKb2FIJlhRNKJpIdiGWUjSQpCkGOUkKIUEyka"
        "SJIUEQkIRERAIgIQiAhERCEQgICREEJEIEJIghIiIISEIhIgEiIISIQISEIhAQiIhCISECEiCIQEgSISohNUnCNWDqRc4KScop7b"
        "rvR2bd2ehaOi7fUkdM3SVzcytY0vd094NRk+bfv+D2BttWeZnrEYdYCcq4d6bsNQ5K9qZTzsrHH2dS7q06UtpVOXb3u/d2/QewzW"
        "G07mNFVdS4LH18XO0u1bVrepXdaM4tLaSb679V9PoJhadPVVRvz5/Tu4MJ2FS0Ti7zhbSzVvSmswo1biUud7TpU6vLP3u+y2jJP5"
        "j1WudN2WJzeKscbTdGN3ZW9WXNNy3qTbTfX5hgr01dNO6fhP5uJEdufuP0ZLVc9Dxx16r+NHf7J+6H/jPNc/wPg7bf8AD0nE9Cab"
        "sM9d5rE3tJzvadnVqWc4zaUasOnYu3fddvgMMqtJXFUU5jrmPxj0cQQnKrPA4+nw5vs9eUnK8qXsLSzlztKOyUpPZdH05l18D93D"
        "HTGIzlXIXedpznY2yo0klNw+6VaijF7pr0+0Ya6dPVVVTTHrGXCBPY6jxTwmfyGNaaVtXnTjv3xT96/nWzPXEaaqZpmYlEct4aYL"
        "HZ/OXNvk7aVzQo2VSuqcajg3KLjt1XrZ+7MYDB3uiq2obDGXeFr29zGh7nr1nUhXT2+C5JPdb7/My4bqdPVVRvifP6d3BUJzbA4b"
        "AYzRj1NnbCvk3WvPclG2p13SjH3rbk2uvc/Yj8+t8Bi9P5fF3NlSrSxl/bUrxW85+/jFvrDm9Xf6RhJ09UUb5mPT9XEhOzKNroat"
        "pCvqRaZulCjdq0dD3dPdvli+bf8A8x11e1LereV6lpRlQt5VJSpUpS5nCG/SLffsu8TDG9Z5cRO6Jz4z9HgEiI0IhIDgREJse0hQ"
        "CAiCEIiIQg2HYUQQCJbAA7DsWwRbFsOw7AGwoth2IgHYUi2AthSFIUgg2LYRAEhRCEJIkIEJEEQgKCEQEIhIgIQEIRAQIQEIhIkA"
        "iAkREQhEJCBCAhEICBCQhEJEAkRBEKIQiEkIRERECRCEQkRRulTlWqwpQW85tRivFs7dyPD/AFK+Ftjh1jf+nW+Qnc1aXn6fvafL"
        "P32/Ns+1dE9zqAiRLdZu00RO6M5jHfH/AJLnvCKtRnk8vjJ1qdKvkcbVtrfzj2Uqj22j+n2HsMphrvRnC27xWaVO3v7/ACEalG3V"
        "SM5OEVHeXvW1t736V4nWabTTXRo9/e6tr5PTFtg763hcTs6rnb3cpPzlOL7Yelf8vAsS2W79MW5pnvETj8XPMBlaeJ0toedxs7W4"
        "uby0uIvsdOpNxe/oW6fzHrOLMI4rWuJhUk5RtbK2UpLvUZS6/QdckMlermq3sx4/SMO+FgriHE+prh1bb9zztvPe7fPR5dvMKntt"
        "vv2rfs2+fodYaHzSxuvrC/TcaVS6cJb/ACajcevq5t/mONeeq+a815yfm99+Tme3sMCZS5qt1UVUxjE5/GcfR2TxaoUtPWeI0xbS"
        "XJRlXvJpd/nKkuT2LdH6MFVw+nOGVtUzVO+lHL3zrQVo4xqbU2lF++7k47/Ojq9CTKe1f/Sa4p7xiPh/Ic74vUKNbP2mbtYv3Pl7"
        "Klcxb8dttvXso+04KRCWi9c5lc14xlz/AILKq9U3iof477HVvN9nwt4bdvpPc6pjl/3AXsdcTt3loXEHjlz03W2bXN8Dpy7b/wDz"
        "Y6oEZ6N1Gq22uXjz69Ovw+Ho7GwuKudX8L44fEKnXyFnk/dFS3dSMJODg1uuZpbe++hn5OK1SlSvcNi1Vp1bjHY2lb3HI91Gou2P"
        "r7/nOD0qtSjLmpzlCXZvF7MG2222232sZY16mJt7Mdekfk51ZfEzf/llfq6ZwUiDTcub9vTtGCRCiNSIiCOBCRI2PbIgIQkRBEKI"
        "QIQEIhIgEkQhEJEBCAojFCiECEkQEJEEKIhQEJCEREQCKBCEJEIRERBCICAkRBCRCBCCEBIiIiEhCISIBIiCEiECEhCIQEIiIQiE"
        "hAhAQiEBIISEqIiEghASISISoiIiBQgKCEQECIhCIQFAIoBCIQEIhIgFERBHAhBCbHtlCCEIiIQiFAhCSSIQIiEIkJIgEiIiSSIQ"
        "iQkQCRCBCgQhEJIUBCRBEKAQhJEhCISICEiCEiECEBCISIBEBCIiEiJCRAIgIREQgQkQQiAgJEQRCQoIhA0CUREEJEKIIQEqISIi"
        "EiFERCRFEICiBEBQQkRAQkQQiAgKIhDFEQoCEEIQkSID/9k="
    ),
    "logo": (
        "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAbsklEQVR4nO19e5xcRZ3v91d1zunu6e6ZnplkQggIhDwghBAY5BVh"
        "lvB0r7qu2oqorHv3ru6yKtx14YJcjMDls4i6l2XVqyz7UpCL45V7V+6i8ojDAkGvwyPkQYILEUIek8yr392nqn73j3O6p5/Tj5nI"
        "RvKbVHen+1T9qr5V9XtV1TnAEXpLiea9vHhcDI2NEQCMDAwwhlcxcAvPM5/fEG2geHwbjVW0Z9gAmLf2zEcHUDweFwAwPDys56G8"
        "f/cUj8clAAzPQ2fMpQMoHo+LctAvueTj4ekCn6q1Ol0ZtZqZF7MxMTACIJ7v2fYbIMoJEuNC0G4hxQ4ZcF7oIXrp0UfvSxeviMfj"
        "ci4d0Rko8biED/zg4KdsGU1c6hZUPO8W1mtljlXaQGkNrQ3YGDDYq97h0gU+lEQEIQSklJBSwpIEy5KvW5bcaFnOMDLdPx0dvccF"
        "UIFJO9QuJKVRPzg4aHNo6R+6rvvZfEGtzuUKyOdz0FoxmDWIQJj5d1gSAwCz/wYQSSktCgSCCAYdBBxrS8C2/4azr/7D6Oio28ls"
        "aAca4RfMgxfEL3EL6s5srrA2lUqjUMgbAjEJIgIJUDtVOEzIbxODDRtmBpPjBEQkEkYo6LxgO9b1o08OP+pfSQBMq8U2pw0bBG65"
        "xQwNDVkpveCOdLbw+UQihVwuq6QQgkgIeILmbUHkvzIbo40xwWDI6u6OIBxyvrZ0sfgvw8PDuohZa2XNQv600mvfFV8IrR5MpvMX"
        "Tk1NGgIghBBvF9AbEQEwxhgGEIv1ikgk+AQJecULTw0fKGLXLH9j8ntxcF38Ha5WP56aTp2cSiZdaUnbu+DtDn+RPBi10m4kGrVj"
        "PZFttrTePfr08OvNZsIsHbBBALeY1We/dxGReHJqKrUinUopaVkW+AjwdYkIWikVjkSsWCyyk0icv3nTQ2NFLOtmaVRUPB4Xr77a"
        "K1xr/8apRHpdKplQUlrWIaz+bw1prVQk2m3FusNP22rRhUuXTppG1pGoV0DR1FSB/V9NZ/Prkomk64HPOJKaJyktK5lIuulsYZ2y"
        "9391eHhYF6MF1VQzA4qK44zz4+sz6czjBw4cVEII64jQaY985awWLlxgdQWci57b9NAT9ZRydQcQsIFWxbdZ4rXs8+OTiVWFQt4Q"
        "Ud3eO0KzEzMbxwmI/t7urYEzjj599J7F2g9MlsZzBbBDQ0MSuMU4ewqfyBXUqlwuq4+A3zkRkcjlsjpXUKforfuvAm4xHsZl11Tn"
        "GRz8lJWl3ZvHJxIrlVtgrwMO11jCW00MZjaW7VB/X/eOEB+zZnT0HoV6M8APsTJ3HVxfKOiTCvk8z4z+t16xHZ7JmwWFfJ4LBX0S"
        "dx1cD4CL4WwAqDEr3Xzh47lcngE24PpW0hFql9jkcnkKBe2PA/hJ+S9U9s6D7/lUV2r3678an5hazGwYc5Q9XrgCIL8UZsCYsvnX"
        "KB+VZYKX6TdlhVXzZtNSTK0ZsSBBfX2xvZFj3rFs9OF7MvAx90a4b6OaibHTtNaLtVZzBl/4McHpDOPgtMHBaYNkllHRvjpEQkAX"
        "MnBTk3BTk1DZJBg+MIeSiEAkoPPpMt4pr7KzVbjF0pVWrLVezJMH1gAoYW4BwNDYGI0AYObTlTYAGw0Iq/lYrU+CCHnFYANccrqD"
        "05ZaUBr4+Q4Xz24vIBQgSIGqiIYX71WZBKLHrUFs6RkQgRDSe3ZiYvszMFyAtINgPgSrnkSA0VCFHHqWnoHu408DCYnUm9sxufPn"
        "ICKQ5QDc6WwggI1W2lhGmTMAPFvEvEIHKKVWKaX8/3FH+BMBedcgFhH49jXduPydAV/VE7TL+M5jWXz+20kYDVBxhYEAMMOoApZ9"
        "4CYcM3QFpOONeGZg6pUXsO27NyI/uRfCCXpybL6I4IkZZpx05e1YfM77IHxU2ADjW57B9vu/AJVNgKRdPWpa5OHlUUpBG31y+U8C"
        "8Ff7ATCbY7TW3lrcHISuMcC3P9eNy98VRCLFSCQYiYRBJsf4w/d34barIkhmjSemAIAEVDaJ4y79E5zwu1fCKMBNa7hpDZXW6Dtp"
        "LVb/x7tBlg3W8zwDSEDn0jjxfdfh2AvfB503M7wzGgNnnIeTrrzDEwqdguLJUNJaw7A+FpjB3Btmw8MMAEabfqNNWa72khCMRMZg"
        "/VoHl58VQGLcwJIoJUFAZsLgk5eGcMpxFrJ5AxKAcQsI9h2NYy64Cm7KeEtKQnpJSuSnFWInLsfS93weKjvtafb5MBMJMIUswouX"
        "4+jz4igktCduynlPKSxYcw56V66Dyvk6oUOT1GgD1txXjnlRszEAEGAzvKBdJywIgNKMtUstsKxVXESANkC4i7DqOAu5AkMQwag8"
        "ugaWwg53gTX5smmGhGWhkNJ4x4VXYOFpl0GlpwAh58NKh3HzCC9eARkQYFNH4RKBBCN6zClgrQBfOLTPi+Fj65RjXhteLuXodLox"
        "bKuJCUWAU+6QswFJy5eVjQwwAhvGivjNSPz6Rahs0sszl7UJ8mAR0vJxb1QWgSyfVzG1SzM9UUGHxLZrpXpceuWybxp3G5GALhh0"
        "DQxg+Qe/CF3IzI9p2iqWh8gRqWiBmeOkZm6nnlw2kBjMDDbaT8ozN8mA/QQwSEi4aY3FZ1+Mo8/7KAqpCZCQc6pzUdy2WOPSp05T"
        "tUtZM4Tm1tGtT09/s01pRgvLgRORsLpsON0W7JCEcAWkErCUKG2s85wlg+UfuA6RxSug8+kandFybcsGQBu5OuLVKGcdHVAEcQ7e"
        "X1t1ZJCwkNyzEy/+7RfhZhMIRAbQt/JcOBf1IB3aCafQj9jYebDcMFgQjGLYkTBWfuRWPP/1q2aQbBebks5prZ4VE6BdKumPyq8r"
        "O8D39LjstQNOTfOW+pgZbj4DpTUK+17B1OubvXYWXCz+q0sQWXYCOOvCSI1UbAuO3fEpSNUFCILKaCxYPYjjLv40XnvkLtjRBZ6V"
        "0gb5/l8bTfVFZQfYzOSodCLrzN22alSTtVlOYwCyCI7F0PksjPbC48J24ER6YYkojrnr9xCLrwElbUgThlOIIRd+A9MLnofQBCYG"
        "CQE3Y7D0P1yN2IlnQWUSINGuKKo0FA8t1ecjai+qztBmmkUHaAN0hQj7xxSe3ZKAY3OFtNPTWSz4wpmI/P5S6AMZQPKMEjYCyp4q"
        "k4wENoCwLZz00f8G6YTKZkCrdW2CWQ3NRdmXlzFDtUp4Dnb1bDmNARwbyBYYH9qwB1tfyyMYIBgGIAhmKo/+Pz8TPX9wCsxEDrBm"
        "dBCzgQwEEU6tRLl2IiGgsho9S5fhxPdeBzczDX+X5LxSKTg9x3LrYSsqLyj70EnyMqMaAcOAlAAJwsdu3YOnXkijJyqhDQBJMBM5"
        "9P7pGvRefZoHfrkXrRiyL4jp77yM/DNTEBFUBCVJSs9LvuhKDKx9N9z0lGeatlBfbstqK5s1c8Cnmt08O2K1jWH2RlAwKPBHX96L"
        "h59KIhazoDSDLAEzkUPPVavQ//kzYabzmInQAawMRH8QyYdexb5bn8DU7l/6EdTqaKgAG8bKj2yA0zMArXJtxvDbGdrzO71qdYA/"
        "MjqSclWDvzhYwhGBa+/ej/semUZPzIKrPPD1eBbRDyzHgv96DkzKRflZAlYGsi+I9E92YeympyACDgqpg375leASEXTeoGvRIqz4"
        "0AbofKalmE2pra1iyp3h4qXiLGiiA6rg6zB5ZAwj0iPxpb87iLu/P4GespGvJ3IIX3Y8Bm5fB87pmakCH/zeIDJPvYn9142ALAIE"
        "IKxgDY8ikZRwUxpHn3MZlqy7Em7RS+bm9WyVeE641Kf6ZmjRYeiIh5fXaEZvTOLuB8dxy98fRHePhNYMWAJ6MofQuqOx6CtDYM2e"
        "eeSLDFYGsieA3PNj2H/tz8CaQbYEDBA9ZpV3XYPjZkUvecUHb0DY95KJxOxTtmVHgEtt6yzV5zNLKKLznnY1Q8QsfOeRaVz7N2OI"
        "RIW3GG8JmOk8gmsHcNRdF4IkAa6ZkfuaIbsd5HdOYt9nn4DJuBABCzqXQfioE8FuDqk390AGatYzPSKCUYATjeCkK24Hs38+rWF7"
        "OqXOcKnHsbIDDOo3rNVqMQDNWNAj8fRTSfzxl/chFPRPLEmCSRTgLO/FUV9fDxG2wXldAT6FbbhvpLDvzx6HHs+CQhYIEoXUBE64"
        "9DNg7WLb/TdCOgRusD5LQsBNayw89Z04/pKrZ0RRg/q25dVy6aUzYvZMwjJq4Ih1xsQYIBgkjLyYwcdu2wsmQArACAKnXdjHRLD4"
        "GxdB9ofAWTVjbmoGhSzo8Sz2/tnjcHenQGEbBIl88iAWrX03lr77oyBhYf8v/w/eePKf4URkw+VJkgJuRuPE93wGseVnw81OewG7"
        "msHVbjvnOmtqSdS7xDNbue1kmBF0gB89PY39UxqBAMEQgbMKsi+Eo75xEexjI+C0OwO+YVBAwmRc7PvMEyi8MgkRtUEs4aanEDth"
        "EGv/9H/4GxdcyGAEr/yv25DY/TpkUDaYCQQ2BGFbOPnKv4R0umZWs8rqW2p0qyoAneHipfrdUDUDimcIOhwZzHBdhYBDsCTAROCC"
        "huiycdTX1yOwohcmUagAH7YAa8a+azYi98IYRI8DYgGVSyK8aBnOvOYfYHfFoF0ARBDShpuexMvfuwlgA2pQ36KXHFu6DMved8PM"
        "LKhb99Z6YG7HEFtUwhXWTCuJZ8DXfmCN2QMfyoAEYdF//x0ETx+Ans4DlihdDylAkrD/uhFkn94D0RsAGW9jVqB7AGde808I9g1A"
        "5wooxtnYKFhdPTi4dSNee+Re2BEJ1g30ge8lH3fxxzCw9nfhpicrF3Da1XclHdCZEvbemkRDuTxD0wpVgl+a1kSAZrAyWPSVC9B1"
        "/hLoyRyoBL53DQUlxm56Gumf7ILoC4C0t0gunTAGP/ePiC45HiqjQVKW8jEANhp2Vwyv/svXMPHyFlhdcpYthN5a8slX3IpAzyIY"
        "t9pLbmdcz20G1OMkqq6ZeW8WRymL/Wity8D3vjNZhYW3rUP48hOgJ6rAB0NEbBy87Vkkf/gKRF8QpAlsPDl9xtV/h77lq+Gmy8Av"
        "ZmaGFwYVMFph2/03QOVyIIm6I7roG3QdtQgrP3wrdMHfllnhBTcHtlIwzI5N/VRdUL0OaHH0l19RAz4RTLKAhTedje4PrYAZLwMf"
        "AAxD9AQw/tVfYvq72yD6goABjFHQbh6n/advYGDtOSgkVRX4VWQ0rGAEiV3P45WHvgY7JBqbpkUv+dzLseRdH/dMU9npecP51QN1"
        "dcDssSDvlVAFPlAZVv5kbVgZmiH6gpj85guY/NZmD3ztOylaY/Unvool512GQkLNClCxLkYr2JFevP7E32Lf6JOww9LfwVZLxZmw"
        "8kNfQOTolVA530sGN8G0bOjOORZUW3p7saCyqWSMqQS/GFb+k8ZhZdEXxPQ/bsX4X41CxAKeCSokVC6F/pXn4viLP4xCUjcBv3Y4"
        "CGlh+wM3IjcxCWE395JPvvIvPS+Zy3cBNqe57YqoT1U6oAromjL80WoYpkzpkQ9+z1Wr0P8XjcPKiR/sxIHbfw4Rdco6kyEIkE4A"
        "xjVoGkaurpPREE4I2QO78PKDX4K0W/CS15yFEy77zKxecl2+RYw6mgJl2JZR1b6gZr3sfV/RQEnQU3kvrHxz47By6pHXcODmpyFC"
        "FvwtaR4oRCAhPCumpe0ltXVirWCHe7Hn2WG8MfLD5l5yWmPZez+H3hXn+mvJLXbCHGdAcXNiOc3iB1R9zcX3svi5IHDKRdf5S7yw"
        "crZBWPnJNzF2/ZOeMpYE4TPxzj5QfZExKwD16mdgBSPY8YMvIbn7jZa85FUfuwPCCXkbA5qu38zM2I6puQ5oZWd0VYGCEPvjNV7I"
        "WOkZEVIMK4/ux/7//DOwYcASEGBkCwxjACGatnqWVlTrJwOybLjpCWy7/waAubmXfOKJWP7+G+Fmpto8BNOZGvaohW0pDZYzKz57"
        "ZTGoy4K1IARTFtlkZSD8sPLezz4Bk1UgR8IiRjJhMLQmhEvfGUY6Y3wPd3ZFVd324iysSVrD6orhwEuP4dVH7mnBS2Ycf8mncdSZ"
        "vweV46bbWjy/oQHvFlK9NjbgWA8Mrv3NDzHnt49DxgJgxV5MPxaAu9sLK5vJHCgkIYmRTBssO9bBA7cuwUBMQisu+m0tUSvh46I+"
        "+Lcf3Ynxl1+a3UtmAlk2jj7n/d62+EN6Hrp+vWutIC4HulYBV3nxIEdi4q+fR3bTHsieAETERn7bBPZe/TjcN72wsmRGNsdY3G/h"
        "f9++BAsX2khkjM+9E5k6+1QnEjDaxbbvXjerl1xsMytuDfuG2LQofmpESJ29oVx6pXo/+PspZ86dkiOh9qex549+iuCZi0AAss+N"
        "gbMKwgc/7zIiQcIPb1uCU44LgNPeyZly66A1RdzadWw0rGAU07uew84ffgWrP3EzCikNonrWTms3Fay0Djuh+nO3znqAr+1rBFhx"
        "Hw1AVFYUMyjg9WNmZDfSI7tLCywWMQrKY/Lgl5bgrNUhTCS1NyLL+bTbqKbClsHahR3uw68f+xb2/XJkVi+5NZ6zYNNyLKi2E9ra"
        "F1Q8HeVJy8pOAAARdbwkCRYBibQBDOP+m4/GJWdHMD2lYRdDE+VKqS382+ssIW1s+971vpfcjsk7P/ybUZ19QcWxXv+vNBOIQaUF"
        "HJ8Mg5iRyRlMJzTOXBHET792LH5/KIrEtJoBv4LjjNBrlWZq0aSm7HnJmbFd2P7AFyHtxgG7lvgyt8i7QY3qWEJ1gi5tQEEAlcQT"
        "eQe08wZDp3Xh2g/3Yf1pXQgHBZIJDavOob0KHdAi31bDx6WyjRew2/Psg+hf9Ts4bv0H/XhTq95vZXlzmwGtmqHtxDt8IjCkMCjk"
        "FS49swvvvawHWjOSGQMpq0yn8o91ymraiDYNEDYGMhjBy8M3z6wlz+Wwd7sGUEnX1VKDFbHOuBRzprMGOukpPNlQy1TzaYU6rBsb"
        "by05NYGt370eYAa1c8fT8u3RpRnYbqqngmv2BdWXUy1TURkLQDYJM9RK/hZ4zjKSmmb1lzEPvPQo/u1fvuVZRR2duu9UBPnYzr4v"
        "qJxBZ73ccgVLWVqZAfV+72CGGgUnHMOv/vkOjG/f3GQtebZ6zB82s+wLaj+1Nzp8UNoeUDNrue0nBkiAlYst3/nz5l5yBdsyC6hj"
        "fGoRqomGzoiGDnu5A8eqlRhP6dqKl05mgYYMRTH92nPY8YM7YHcJtHwLnDnpgGILm0VD5+yotEZ+3HQmtTyD2u/gmhK0CyfSh12P"
        "fhN7f/Ez2GFrbl5yy4ybiKA5tqvEIF+YTbR4q2E511TkMaoAZgI1DMwwtMrP2wBhMITlYOv9f9HcS2af9zx0fnX2Ygf4x9CRp+Lh"
        "2Q6SYYAk8PyvsiBTW1FmzyxNZwy2vpaDZRO0MRB2AOl9r6CQTIEko/oIEhsGiJDY9cLMJtu5JmMgnRAy+1/FtvtvgnSEty+pGiEG"
        "2BASv94MkranRzpM5MVw8uWY+x0Q9/9DE969mjrrZWMYXV0CG0eT+PGmJLoX2FCaS8kwo6vfwt8/MoGXd+UQCni71oQVQHb8dfz6"
        "iXvhRL0FS9bKu2+EVgjGbEzs2Ip9zz0MKxSdN3HBWsGO9OHNTf8Tux57AME+23vmTTnvXgtjLz6Ng9s2wgpGgA55M9h7Jg1owvsm"
        "PtMBQ0Pec7KEFLullGAuqsX2/wheT3/yjtfxfzdOoTsq0d1jobvHQldI4t7vH8SN396LUEjAsJ/LaFihbvzqR3di50P3QtqAE7Xg"
        "RCTsiIUDW/4fnvvmJ2FUHkSiw5o1+PN5b3/gBrz202FYQTnDO2xhzy824sV7P+2tXaMzVAAGM7OUEkKK3eWYV8SChMB2y/LOVXUq"
        "6QwDtk2YTGq8/wu7sH4wgtOXh6A0Y9PWDJ55KY1QQKB0fMtvFkAQ0sG2792APc8Oo2/lOZB2EMnd23Fgy8/ARkE6wTkF0+qTJ97Y"
        "GGy+92rs/tf70Lv8bJAQmN71Ag5uHQEJAbICHfP27AuGZUkIge3lv/kaLy6BYb369AvOnZycfmZ8fJyFlHO4bxyXRkw6o4HiipMt"
        "EAmJCru4opr+rSNVPg3jeqKShIQVinq3sTMGrS1dtV/fEu9cCkYVPN7SghWM+pfMgTcBRmvu7++n3t7weVuef2ZTEXN/BgwbAAiI"
        "7hctK7lXSrnYMHNra0UNmuQjHA3L0jKmYYapo5zLMoFZw3K6gECk+KUnj0s9dojM5CLvQBgogu7zLruo46KllGRZYm9A9L3ofeth"
        "XrpnXDwel6OjD2ccx348EAgwm/nRdNqUKeEWZzCz8W7aZNRvxj4/xLzZGB0IBNlx7MdHRx/OFO/TDZT5AcP+u2PJ+0KhIDHzLOc7"
        "j6R2EjOLUMghx5L3lWMNlCth78kOFLQLTwQce7vt2CcppQx1ejuqIwTAE2KOY1PAcbYv6HUeB0DljzyseYDD6OioGwwE7oxGImS0"
        "v3f838EoOjyTp3wjkQgFA4E7R0ZGVNMHOACgwcFBOZXE6NjBiVPdQl6TaHn36hEqIzZG205ADizoeykWxeDo6Gjx9rtcvKZavDDi"
        "cRodHXWDocA1sVg3OgkYHyGPGMyxWDeCocA1o6OjLuLx4saSEtU3M/1Hs65YddZd04nUNZMTE97T8450RWtEgFLa7evrs3u6I3+9"
        "c9svrm30uNtGdj4hHheDr74qptO0cWJyal0qmVJSdnyw6m1FWmsViUatvt6ep5YsCl8426PQZ3O0BABes+bchelc4cnxyamV6XRK"
        "WdKyOg9U/HYTgaC0UuFwxOrvje0IB50LNm/edABo/Hjb2UxMA2ygzZs3jTnSXNbfG9sRjUQtpV33kNT+t4CUdt1oJGr198Z2BCxc"
        "unnzpjFgQ0PwgZZCDV7MYtWqdx5V0Pz9RCp1/tTUVNnjbLnOxHqbEHmjvvg4295YTEQjkX8N2jK+ZcvP9xexa1JESyQAmFWrVjka"
        "0S+nM5lrp6ankc/ltBCC3q4Pe2NmY4zhQDAoYz09CHcF74qEzPWjo6MufMyaldFOsK1U4MmnnnNxIV+4I53JDiaTSRQKBUNELESz"
        "R/T8NhCz8R5qTo7jiGg0inBXaNQJODdsf+nZx/yLWgIfaD/aSUBcAMN6aGjIGjuY/4NsPve5XC6/JpfLIp/PQ2vNDGgCAKLDvjfY"
        "M+fBAAiQQkoKBoIIBoMIBgObQ4Hg3QMLAv80MjKifJFT19ppRB3iMyPbhoaGrP0HM5cXCvojyi1cWFBqiVLae2CNf5J+LjeDfUuJ"
        "AEECUkpYlgXLkrBt603bcjY6jnxw0YKuH3vAA63I+wYs5lC9eFyUOxcrV54XhcWnslGnKe2ezAbHsjE9AAJz5PVWEAHICUnjROJN"
        "kmK7FM5m9NBLO555Jlm6ynOw2hr11UzmoaLFhxW3PwIOTyo+C7Jz4Is036OSgLgoLjiPjAwwMFwRfDrMiIA4zbRnhIHqUylH6LCm"
        "/w/oEVhNJBrZyQAAAABJRU5ErkJggg=="
    ),
}
_AUMID = "LS.IQBotEscaner"
_NOTI_PC = {"listo": False, "dir": None, "propio": False}


def _preparar_noti_pc():
    """Una sola vez: guarda las imágenes y registra la app para que Windows muestre el nombre del bot con su logo."""
    if _NOTI_PC["listo"]:
        return
    import base64
    carpeta = os.path.join(nucleo.DATOS, "notificaciones")
    os.makedirs(carpeta, exist_ok=True)
    for k, partes in _IMG_NOTI.items():
        ruta = os.path.join(carpeta, k + "_iqn" + (".png" if k == "logo" else ".jpg"))   # _iqn: imágenes nuevas
        if not os.path.exists(ruta):
            with open(ruta, "wb") as f:
                f.write(base64.b64decode("".join(partes)))
    try:
        import winreg
        clave = winreg.CreateKey(winreg.HKEY_CURRENT_USER, "Software\\Classes\\AppUserModelId\\" + _AUMID)
        winreg.SetValueEx(clave, "DisplayName", 0, winreg.REG_SZ, NOMBRE_APP)
        winreg.SetValueEx(clave, "IconUri", 0, winreg.REG_SZ, os.path.join(carpeta, "logo_iqn.png"))
        winreg.SetValueEx(clave, "IconBackgroundColor", 0, winreg.REG_SZ, "FF0B1122")
        winreg.SetValueEx(clave, "ShowInSettings", 0, winreg.REG_DWORD, 1)
        winreg.CloseKey(clave)
        _NOTI_PC["propio"] = True
    except Exception as e:
        _aviso_error("registro Windows", e)
    _NOTI_PC["dir"] = carpeta
    _NOTI_PC["listo"] = True


def _notificar_windows(titulo, texto, tipo=None):
    import base64, subprocess
    from xml.sax.saxutils import escape
    _preparar_noti_pc()
    carpeta = _NOTI_PC["dir"]
    imagenes = ""
    if tipo in _IMG_NOTI:
        hero = os.path.join(carpeta, tipo + "_iqn.jpg").replace("\\", "/")
        imagenes += f"<image placement='hero' src='file:///{escape(hero)}'/>"
    logo = os.path.join(carpeta, "logo_iqn.png").replace("\\", "/")
    imagenes += f"<image placement='appLogoOverride' src='file:///{escape(logo)}'/>"
    xml = ("<toast><visual><binding template='ToastGeneric'>" + imagenes + "<text>" + escape(titulo) + "</text><text>"
           + escape(texto) + "</text><text placement='attribution'>" + NOMBRE_APP + "</text></binding></visual>"
           "<audio src='ms-winsoundevent:Notification.Default'/></toast>")
    xml = xml.replace("'", "''")                  # comillas para PowerShell
    def enviar(app_id):
        ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
              "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null;"
              "$x = New-Object Windows.Data.Xml.Dom.XmlDocument; $x.LoadXml('" + xml + "');"
              "$n = [Windows.UI.Notifications.ToastNotification]::new($x);"
              "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('" + app_id + "').Show($n)")
        cod = base64.b64encode(ps.encode("utf-16-le")).decode()
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-EncodedCommand", cod],
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=20,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        return r.returncode == 0 and not r.stderr.strip(), r.stderr.decode("utf-8", "ignore").strip()[:200]
    ok, err = enviar(_AUMID) if _NOTI_PC["propio"] else (False, "")
    if not ok:                                    # respaldo: como notificación de Windows PowerShell
        ok, err2 = enviar("{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe")
        if not ok:
            _aviso_error("Windows", RuntimeError(err2 or err or "Windows no mostró la notificación"))


def _bot_activo():
    try:
        return _API[0]._bot if _API else None
    except Exception:
        return None


def _notificar_simple(titulo, texto):
    """Último recurso: notificación normal de Android, sin diseño."""
    from java import jclass
    ctx = _ctx()
    Notification = jclass("android.app.Notification")
    _canal(ctx, "iqbot_alertas", "Ganadas, Stop Win, Stop Loss y mercado",
           jclass("android.app.NotificationManager").IMPORTANCE_HIGH, alerta=True)
    b = _builder(ctx, "iqbot_alertas")
    b.setSmallIcon(_icono_chico(ctx)).setColor(_color("#F5A524")).setContentTitle(titulo).setContentText(texto).setAutoCancel(True) \
     .setContentIntent(_pi_abrir(ctx)).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
    _NOTIF_N[0] += 1
    ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).notify(_NOTIF_N[0], b.build())


def _ruta_perfil():
    return os.path.join(nucleo.DATOS, "perfil.json")


# =====================================================================
#  CONTRASEÑA RECORDADA (solo si el usuario activa "Recordar contraseña en este equipo")
#  PC: cifrada con la protección de Windows (DPAPI: solo esa cuenta de Windows en ese equipo la puede abrir).
#  Celular: cifrada con una llave propia guardada en la carpeta privada de la app.
#  Nunca va en config_bot.json, ni en el diagnóstico, ni en la exportación de datos.
# =====================================================================
def _ruta_cred():
    return os.path.join(nucleo.DATOS, "credenciales.dat")


def _dpapi(datos, cifrar):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    entrada = BLOB(len(datos), ctypes.cast(ctypes.create_string_buffer(datos, len(datos)), ctypes.POINTER(ctypes.c_char)))
    salida = BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if cifrar else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(entrada), None, None, None, None, 0x01, ctypes.byref(salida)):   # sin ventanas
        raise OSError("DPAPI")
    try:
        return ctypes.string_at(salida.pbData, salida.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(salida.pbData)


def _llave_local():
    ruta = os.path.join(nucleo.DATOS, ".llave")
    try:
        with open(ruta, "rb") as f:
            k = f.read()
        if len(k) == 32:
            return k
    except Exception:
        pass
    k = os.urandom(32)
    with open(ruta, "wb") as f:
        f.write(k)
    return k


def _flujo(llave, nonce, n):
    import hashlib
    out = b""; i = 0
    while len(out) < n:
        out += hashlib.sha256(llave + nonce + i.to_bytes(4, "big")).digest(); i += 1
    return out[:n]


def _proteger(texto):
    import base64, hmac, hashlib
    datos = texto.encode("utf-8")
    if sys.platform == "win32":
        try:
            return "w:" + base64.b64encode(_dpapi(datos, True)).decode()
        except Exception:
            pass                                  # sin DPAPI: se usa la llave propia
    k = _llave_local(); nonce = os.urandom(16)
    c = bytes(a ^ b for a, b in zip(datos, _flujo(k, nonce, len(datos))))
    m = hmac.new(k, nonce + c, hashlib.sha256).digest()
    return "l:" + base64.b64encode(nonce + m + c).decode()


def _desproteger(s):
    import base64, hmac, hashlib
    t, b = s.split(":", 1)
    raw = base64.b64decode(b)
    if t == "w":
        return _dpapi(raw, False).decode("utf-8")
    k = _llave_local(); nonce, m, c = raw[:16], raw[16:48], raw[48:]
    if not hmac.compare_digest(m, hmac.new(k, nonce + c, hashlib.sha256).digest()):
        raise ValueError("credencial alterada")
    return bytes(a ^ b for a, b in zip(c, _flujo(k, nonce, len(c)))).decode("utf-8")


def _leer_cred():
    try:
        with open(_ruta_cred(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _escribir_cred(d):
    try:
        with open(_ruta_cred(), "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


def guardar_clave(broker, email, clave):
    d = _leer_cred()
    d[broker] = {"email": email.strip().lower(), "c": _proteger(clave)}
    _escribir_cred(d)


def clave_guardada(broker, email):
    e = _leer_cred().get(broker)
    if not e or e.get("email") != str(email or "").strip().lower():
        return None
    try:
        return _desproteger(e["c"])
    except Exception:
        return None


def borrar_clave(broker):
    d = _leer_cred()
    if d.pop(broker, None) is not None:
        _escribir_cred(d)


def _leer_perfil():
    """Datos del usuario que no se cambian (su nombre)."""
    try:
        with open(_ruta_perfil(), encoding="utf-8") as f:
            p = json.load(f)
        return p if isinstance(p, dict) else {}
    except Exception:
        return {}


def _quitar_aviso_mercado():
    """Borra la tarjeta de mercado (errático / óptimo) cuando el bot se detiene."""
    if not _es_android():
        return
    try:
        from java import jclass
        _ctx().getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE).cancel(77)
    except Exception:
        pass


def notificar_sistema(titulo, texto, **datos):
    if str(datos.get("tipo", "")).startswith("mercado"):
        b = getattr(nucleo, "BOT_ACTUAL", None)
        if b is None or b.detener or b.terminado:
            return                                       # sin bot trabajando no hay avisos de mercado
    if _es_android():
        try:
            _notificar_android(titulo, texto, **datos)
        except Exception as e:
            _aviso_error("aviso", e)
            try:
                _notificar_simple(titulo, texto)
            except Exception as e2:
                _aviso_error("aviso simple", e2)
        return
    try:
        if sys.platform.startswith("win"):
            tipo = datos.get("tipo")
            if tipo == "ganada":
                d = datos.get("dir")
                titulo = f"{datos.get('par', '')} {'▲ CALL' if d == 'call' else '▼ PUT'} · {nucleo.texto_dinero(datos.get('monto', 0))}"
                texto = f"{datos.get('op', 'Entrada')} · Sesión {nucleo.texto_dinero(datos.get('sesion', 0))}"
            elif tipo in ("stopwin", "stoploss"):
                titulo = f"{nucleo.texto_dinero(datos.get('monto', 0))} · {'Meta cumplida' if tipo == 'stopwin' else 'Saldo protegido'}"
            _notificar_windows(titulo, texto, tipo)
    except Exception as e:
        _aviso_error("Windows", e)


nucleo.NOTIFICAR = notificar_sistema


def _permisos_android():
    """Pide permiso de notificaciones (Android 13+) y que no se limite la batería."""
    from java import jclass, jarray
    ctx = _actividad()
    Build = jclass("android.os.Build$VERSION")
    if Build.SDK_INT >= 33 and ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0:
        permisos = jarray(jclass("java.lang.String"))(["android.permission.POST_NOTIFICATIONS"])
        _en_ui(lambda: ctx.requestPermissions(permisos, 77))
    Context = jclass("android.content.Context")
    pm = ctx.getSystemService(Context.POWER_SERVICE)
    if Build.SDK_INT >= 23 and not pm.isIgnoringBatteryOptimizations(ctx.getPackageName()):
        Intent = jclass("android.content.Intent")
        Uri = jclass("android.net.Uri")
        i = Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + ctx.getPackageName()))
        _en_ui(lambda: ctx.startActivity(i))


_SERVICIO = {"texto": "Toca para abrir", "activo": False, "error": "", "cerrojos": []}


def servicio_iniciar(servicio, intent):
    """Lo llama el servicio de Android al arrancar (o al tocar un botón de sus notificaciones):
    notificación fija + CPU y wifi despiertos."""
    from java import jclass
    Build = jclass("android.os.Build$VERSION")
    _SERVICIO["ctx"] = servicio.getApplicationContext()
    notif = _noti_trabajando(servicio, _SERVICIO["texto"], _bot_activo())
    if Build.SDK_INT >= 34:
        ServiceInfo = jclass("android.content.pm.ServiceInfo")
        servicio.startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    else:
        servicio.startForeground(1, notif)
    if not _SERVICIO["cerrojos"]:
        Context = jclass("android.content.Context")
        PowerManager = jclass("android.os.PowerManager")
        cpu = servicio.getSystemService(Context.POWER_SERVICE).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "iqbot:operando")
        cpu.acquire()
        _SERVICIO["cerrojos"].append(cpu)
        try:
            WifiManager = jclass("android.net.wifi.WifiManager")
            wifi = servicio.getApplicationContext().getSystemService(Context.WIFI_SERVICE) \
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "iqbot:wifi")
            wifi.acquire()
            _SERVICIO["cerrojos"].append(wifi)
        except Exception:
            pass
    _SERVICIO["activo"] = True


def servicio_detener(servicio=None):
    for c in _SERVICIO["cerrojos"]:
        try:
            if c.isHeld():
                c.release()
        except Exception:
            pass
    _SERVICIO["cerrojos"] = []
    _SERVICIO["activo"] = False
    _quitar_aviso_mercado()
    _SERVICIO["ctx"] = None


def _actualizar_noti(texto):
    """Cambia el texto de la notificación fija (ganancias de la sesión)."""
    _SERVICIO["texto"] = texto
    if not _SERVICIO["activo"]:
        return
    try:
        from java import jclass
        ctx = _ctx()
        nm = ctx.getSystemService(jclass("android.content.Context").NOTIFICATION_SERVICE)
        nm.notify(1, _noti_trabajando(ctx, texto, _bot_activo()))
    except Exception:
        pass


def segundo_plano(encender, texto="Toca para abrir"):
    """Celular: enciende o apaga el servicio que mantiene vivo el bot con la app cerrada o bloqueada.
    Devuelve (ok, motivo)."""
    if not _es_android():
        return True, ""
    try:
        from java import jclass
        ctx = _actividad()
        Intent = jclass("android.content.Intent")
        i = Intent()
        i.setClassName(ctx.getPackageName(), "iqbot.servicio.ServicioBot")
        if encender:
            _SERVICIO["texto"] = texto
            try:
                _permisos_android()
            except Exception:
                pass
            if jclass("android.os.Build$VERSION").SDK_INT >= 26:
                r = ctx.startForegroundService(i)
            else:
                r = ctx.startService(i)
            if r is None:
                return False, "este APK no trae el servicio de segundo plano"
            _SERVICIO["activo"] = True
            threading.Thread(target=lambda: (time.sleep(2), _actualizar_noti(texto)), daemon=True).start()
        else:
            ctx.stopService(i)
            servicio_detener()
        return True, ""
    except Exception as e:
        _SERVICIO["error"] = str(e)[:150]
        return False, _SERVICIO["error"]


def _vigilar_fin(bot):
    """Mientras el bot trabaja actualiza la tarjeta fija (y la esconde con la app abierta);
    al terminar apaga el servicio."""
    ultimo = None
    while not bot.terminado:
        try:
            clave = (_app_visible(), round(bot.pnl, 2), bot.stats["ganadas"], getattr(bot, "pausado", False),
                     getattr(bot, "ultima_ganada", ""), str((getattr(bot, "ultima_entrada", None) or {}).get("par")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("dir")),
                     str((getattr(bot, "ultima_entrada", None) or {}).get("intento")), len(bot.abiertas))
            if clave != ultimo:
                _actualizar_noti("")
                ultimo = clave
        except Exception:
            pass
        time.sleep(2)
    segundo_plano(False)


def anotar_error():
    try:
        with open(nucleo.ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}]\n{traceback.format_exc()}")
    except Exception:
        pass


AUTOR_CORREOS = {"serpaleiner79@gmail.com", "leiser9208@gmail.com"}      # solo el autor ve y usa "Exportar datos"
AUTOR_IDS = {"196447152", "197023901", "197054166"}   # cuentas del autor (IQ Option y Exnova)


def es_autor(api):
    try:
        if str(api._cfg.get("email", "")).strip().lower() in AUTOR_CORREOS:
            return True
        return bool(api._broker) and str(api._broker.id_iq()).strip() in AUTOR_IDS
    except Exception:
        return False


class Api:
    """Métodos que la ventana puede llamar (window.pywebview.api.*)."""

    def __init__(self):
        _API[:] = [self]
        self._cfg = nucleo.cargar_config()
        self._broker = None
        self._bot = None
        self._nombre = "DEMO"
        self._login = {"fase": "inactivo", "mensaje": ""}
        self._evento_codigo = threading.Event()
        self._codigo = ""
        viejo = getattr(nucleo, "BOT_ACTUAL", None)      # se cerró la ventana con el bot trabajando: se retoma
        if viejo is not None and not viejo.terminado and not viejo.detener:
            self._bot, self._broker, self._nombre = viejo, viejo.b, viejo.cuenta
        ajustar_teclado_android()
        self._prep = {"listo": False, "mensaje": "Revisando la librería de conexión…"}
        threading.Thread(target=self._preparar, daemon=True).start()

    # ---------- arranque ----------
    def _preparar(self):
        try:
            if not nucleo.CONGELADO:
                nucleo.asegurar_librerias()
                if self._cfg.get("actualizar_libreria", True):
                    nucleo.actualizar_libreria()
            elif self._cfg.get("actualizar_libreria", True):
                # .exe / Android: busca versión nueva de la librería en GitHub y la usa si es válida
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones de la librería de conexión…"}
                cambio, msg = nucleo.actualizar_libreria_embebida()
                if cambio:
                    self._prep = {"listo": True, "mensaje": msg}
            # actualizaciones del bot publicadas por el autor (firmadas)
            arr = _arranque()
            if arr is not None and getattr(arr, "URL_ACTUALIZACIONES", ""):
                self._prep = {"listo": False, "mensaje": "Buscando actualizaciones del bot…"}
                nueva = arr.buscar_actualizacion(lambda t: self._prep.update(mensaje=t))
                if nueva:
                    self._prep = {"listo": False, "mensaje": f"Actualización {nueva} instalada. Reiniciando…"}
                    time.sleep(1.5)
                    reiniciar_programa()
                    return
            if self._prep.get("mensaje", "").startswith("Librería de IQ Option actualizada"):
                self._prep = {"listo": True, "mensaje": self._prep["mensaje"]}
            else:
                self._prep = {"listo": True, "mensaje": "Listo para conectar" + self._estado_actualizaciones(arr)}
        except BaseException as e:
            anotar_error()
            self._prep = {"listo": True, "mensaje": f"Aviso al preparar: {str(e)[:80]}"}

    def _estado_actualizaciones(self, arr):
        """Texto corto para la pantalla de inicio: versión y si la revisión de actualizaciones falló."""
        if arr is None or not getattr(arr, "URL_ACTUALIZACIONES", ""):
            return ""                                  # la versión ya se ve abajo a la izquierda
        try:
            with open(os.path.join(arr.DATOS, "actualizaciones.log"), encoding="utf-8") as f:
                ultima = f.read().strip().splitlines()[-1]
            hora = time.mktime(time.strptime(ultima[1:20], "%Y-%m-%d %H:%M:%S"))
            if time.time() - hora < 120 and ("No se pudo" in ultima or "inválida" in ultima or "no coincide" in ultima):
                return " · no se pudo revisar actualizaciones"
        except Exception:
            pass
        return ""

    def preparacion(self):
        return nucleo.txt_broker(self._prep)

    def guardar_nombre(self, nombre):
        """El nombre del usuario se guarda UNA sola vez; después no se puede cambiar."""
        p = _leer_perfil()
        if p.get("nombre"):
            return {"ok": False, "nombre": p["nombre"], "mensaje": "El nombre ya está guardado."}
        limpio = " ".join(str(nombre or "").split())[:24]
        if sum(ch.isalpha() for ch in limpio) < 2:
            return {"ok": False, "mensaje": "Escribe tu nombre (al menos 2 letras)."}
        p["nombre"] = limpio
        try:
            with open(_ruta_perfil(), "w", encoding="utf-8") as f:
                json.dump(p, f, ensure_ascii=False)
        except Exception as e:
            return {"ok": False, "mensaje": f"No se pudo guardar: {e}"}
        return {"ok": True, "nombre": limpio}

    def inicio(self):
        arr = _arranque()
        if arr is not None:
            try:
                arr.confirmar()        # la ventana abrió bien con esta versión
            except Exception:
                pass
        broker = self._cfg.get("broker") if self._cfg.get("broker") in nucleo.BROKERS else "iqoption"
        correos = dict(self._cfg.get("correos") or {})
        correos.setdefault("iqoption", self._cfg.get("email", "") if broker == "iqoption" else "")
        return {"email": correos.get(broker, ""), "correos": correos, "broker": broker,
                "cuenta": self._cfg.get("cuenta", "PRACTICE"),
                "version": nucleo.VERSION_BOT, "nombre": _leer_perfil().get("nombre", ""),
                "bot_activo": bool(self._bot and not self._bot.terminado and not self._bot.detener),
                "novedades": self._novedades(),
                "claves": {b: e.get("email", "") for b, e in _leer_cred().items() if isinstance(e, dict)}}

    def _novedades(self):
        """Lo nuevo de esta versión, solo la primera vez que se abre después de actualizar."""
        try:
            p = _leer_perfil()
            if not p.get("build_visto") and not self._cfg.get("email"):
                self.novedades_vistas()                   # instalación nueva (nunca entró): nada que anunciar
                return None
            if int(p.get("build_visto", 0)) >= nucleo.BUILD_BOT:
                return None
            n = dict(getattr(nucleo, "NOVEDADES", {}) or {})
            if not n.get("items") or not n.get("mostrar"):
                return None                               # el autor decide en cada publicación si se muestra
            esp = n.get("especial")
            if esp and esp in (p.get("especiales_vistos") or []):
                n.pop("especial")                         # el anuncio especial sale una sola vez
            n["version"], n["build"] = nucleo.VERSION_BOT, nucleo.BUILD_BOT
            return n
        except Exception:
            return None

    def novedades_vistas(self):
        p = _leer_perfil()
        p["build_visto"] = nucleo.BUILD_BOT
        esp = (getattr(nucleo, "NOVEDADES", {}) or {}).get("especial")
        if esp:
            p["especiales_vistos"] = sorted(set(p.get("especiales_vistos") or []) | {esp})
        try:
            with open(_ruta_perfil(), "w", encoding="utf-8") as f:
                json.dump(p, f, ensure_ascii=False)
        except Exception:
            pass
        return {"ok": True}

    def crear_cuenta(self, broker=None):
        """Abre el registro del broker elegido con el enlace de afiliado del autor (en el navegador del equipo)."""
        enlace = ENLACES_REGISTRO.get(broker or self._cfg.get("broker") or "iqoption", ENLACE_REGISTRO)
        try:
            if ABRIR_ENLACE:
                ABRIR_ENLACE(enlace)
            else:
                import webbrowser
                webbrowser.open(enlace, new=2)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "mensaje": str(e)}

    # ---------- inicio de sesión ----------
    def guardar_broker(self, broker):
        """El broker que el cliente toca queda recordado aunque todavía no haya entrado."""
        if broker in nucleo.BROKERS and self._broker is None:
            self._cfg["broker"] = broker
            try:
                nucleo.guardar_config(self._cfg)
            except Exception:
                pass
        return {"ok": True}

    def olvidar_clave(self, broker):
        borrar_clave(broker if broker in nucleo.BROKERS else "iqoption")
        return {"ok": True}

    def iniciar_sesion(self, email, clave, cuenta, broker="iqoption", recordar=False):
        if self._login["fase"] in ("conectando", "codigo", "licencia"):
            return {"ok": False, "mensaje": "Ya se está conectando…"}
        if "@" not in (email or ""):
            return {"ok": False, "mensaje": "Escribe un correo válido."}
        b_elegido = broker if broker in nucleo.BROKERS else "iqoption"
        guardada = False
        if not clave:
            clave = clave_guardada(b_elegido, email)
            guardada = bool(clave)
        if not clave:
            return {"ok": False, "mensaje": "Escribe tu contraseña."}
        if not self._prep["listo"]:
            return {"ok": False, "mensaje": "Espera un momento: se está preparando la librería de conexión."}
        if self._broker is None:
            nucleo.usar_broker(broker if broker in nucleo.BROKERS else "iqoption")
        self._login = {"fase": "conectando", "mensaje": ""}
        threading.Thread(target=self._hacer_login, args=(email.strip(), clave, cuenta, bool(recordar), guardada),
                         daemon=True).start()
        return {"ok": True}

    def _pedir_codigo(self):
        self._evento_codigo.clear()
        self._login = {"fase": "codigo", "mensaje": ""}
        self._evento_codigo.wait(300)
        self._login = {"fase": "conectando", "mensaje": ""}
        return self._codigo

    def enviar_codigo(self, codigo):
        self._codigo = (codigo or "").strip()
        self._evento_codigo.set()
        return {"ok": True}

    def _hacer_login(self, email, clave, cuenta, recordar=False, guardada=False):
        try:
            broker, error = nucleo.BrokerIQ.iniciar_sesion(email, clave, self._pedir_codigo)
            if broker and recordar and not guardada:
                try:
                    guardar_clave(nucleo.BROKER, email, clave)
                except Exception as e:
                    _aviso_error("guardar contraseña", e)
            clave = None
            if not broker:
                if guardada:                         # la guardada ya no sirve (la cambió): se borra
                    borrar_clave(nucleo.BROKER)
                    error = (error or "") + "\nLa contraseña guardada no funcionó y se borró. Escríbela de nuevo."
                self._login = {"fase": "error", "mensaje": error, "clave_borrada": guardada}
                return
            self._login = {"fase": "licencia", "mensaje": ""}
            id_iq = broker.id_iq()
            # La primera vez en esta cuenta se manda el nombre del perfil para la hoja de licencias
            # (el cliente lo ve avisado en el inicio de sesión). Después ya no se vuelve a mandar.
            marca = f"{nucleo.BROKER}:{id_iq}"
            enviados = list(self._cfg.get("perfil_enviado") or [])
            perfil = broker.perfil_publico() if id_iq and marca not in enviados else None
            ok, msg = nucleo.verificar_licencia(email, id_iq, perfil)
            if ok and perfil:
                self._cfg["perfil_enviado"] = (enviados + [marca])[-10:]
            if not ok:
                self._login = {"fase": "sin_licencia", "mensaje": msg, "id_iq": id_iq}
                return
            cuenta = "REAL" if cuenta == "REAL" else "PRACTICE"
            broker.usar_cuenta(cuenta)
            self._broker = broker
            self._nombre = "REAL" if cuenta == "REAL" else "DEMO"
            self._cfg["email"] = email
            self._cfg["cuenta"] = cuenta
            self._cfg["broker"] = nucleo.BROKER                       # se recuerda el broker elegido
            self._cfg["correos"] = {**(self._cfg.get("correos") or {}), nucleo.BROKER: email}
            nucleo.guardar_config(self._cfg)
            self._login = {"fase": "listo", "mensaje": "", "licencia": msg}
        except Exception as e:
            anotar_error()
            self._login = {"fase": "error", "mensaje": f"Error inesperado al conectar: {e}"}

    def estado_login(self):
        return nucleo.txt_broker(self._login)

    def hay_operacion(self):
        """True si hay una operación abierta o saliendo (para preguntar antes de cerrar sesión o configurar)."""
        b = self._bot
        if not b or b.terminado:
            return False
        try:
            return bool(b.abiertas or b.riesgo_abierto > 0.0001 or b.activas())
        except Exception:
            return False

    def _terminar_bot(self, motivo):
        """Detiene el bot y espera a que cierre lo que tiene abierto. La sesión del día queda guardada
        (P/L y recuperación pendiente) para retomarla al volver a operar."""
        _quitar_aviso_mercado()
        b = self._bot
        if b and not b.terminado:
            if not b.detener:
                b.detener = True
                b.log(motivo, "yellow")
            fin = time.time() + 20 * 60
            while not b.terminado and time.time() < fin:
                time.sleep(0.3)

    def ir_a_config(self):
        self._terminar_bot("Pausa para cambiar la configuración: la sesión sigue al volver a operar.")
        try:
            self._sesion = self._bot.estado_sesion() if self._bot else None   # solo en memoria (misma sesión)
        except Exception:
            self._sesion = None
        self._bot = None
        return {"ok": True}

    def cerrar_sesion(self):
        self._terminar_bot("Cerrando sesión.")
        self._sesion = None                      # al salir del bot, la próxima vez empieza de cero
        try:
            if self._broker:
                self._broker.api.api.close()
        except Exception:
            pass
        self._broker = None
        self._bot = None
        self._login = {"fase": "inactivo", "mensaje": ""}
        return {"ok": True}

    def salir_app(self):
        """Cerrar sesión cierra la app por completo (la próxima vez empieza de cero)."""
        def cerrar():
            time.sleep(0.4)                          # deja que la pantalla reciba la respuesta
            try:
                self.al_cerrar()
            except Exception:
                pass
            if _es_android():
                try:
                    segundo_plano(False)             # apaga la notificación fija y el servicio
                except Exception:
                    pass
                try:
                    _en_ui(lambda: _actividad().finishAndRemoveTask())
                except Exception:
                    pass
                time.sleep(1.0)
                try:
                    from java import jclass
                    P = jclass("android.os.Process")
                    P.killProcess(P.myPid())
                except Exception:
                    os._exit(0)
            else:
                try:
                    import webview
                    for w in list(webview.windows):
                        w.destroy()
                except Exception:
                    os._exit(0)
        threading.Thread(target=cerrar, daemon=True).start()
        return {"ok": True}

    # ---------- configuración ----------
    def datos_config(self):
        c = dict(self._cfg)
        c["max_pares"] = nucleo.MAX_PARES
        saldo = self._broker.saldo() if self._broker else None
        return {"cfg": c, "email": self._cfg.get("email", ""), "broker": nucleo.BROKER,
                "cuenta": self._cfg.get("cuenta", "PRACTICE"), "saldo": saldo if isinstance(saldo, (int, float)) else None,
                "moneda": getattr(self._broker, "moneda", "USD") if self._broker else "USD",
                "tasa": getattr(self._broker, "tasa", 1.0) if self._broker else 1.0,
                "autor": es_autor(self)}

    def _mezclar(self, parcial):
        c = dict(self._cfg)
        c.update({k: v for k, v in (parcial or {}).items() if k in nucleo.DEFAULT_CONFIG})
        return c

    def tabla_recuperacion(self, parcial):
        c = self._mezclar(parcial)
        c["recuperacion"] = "auto"
        if c.get("recuperacion") == "ninguna":
            return {"filas": [], "total": float(c.get("monto_entrada") or 0), "mult_insuficiente": False}
        try:
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            filas = nucleo.tabla_recuperacion(c, 0.85)
        except Exception:
            return {"filas": [], "total": 0, "mult_insuficiente": False}
        return {"filas": [{"paso": e, "monto": m, "perdido": p, "neto": round(n, 2)} for e, m, p, n in filas],
                "total": filas[-1][2] if filas else 0,
                "mult_insuficiente": c["rec_modo"] == "multiplicador" and any(n <= 0 for _, _, _, n in filas[1:])}

    def iniciar_bot(self, parcial):
        if not self._broker:
            return {"ok": False, "mensaje": "No hay sesión iniciada."}
        if self._bot and not self._bot.terminado:
            return {"ok": False, "mensaje": "El bot ya está funcionando."}
        c = self._mezclar(parcial)
        try:
            c["monto_entrada"] = float(c["monto_entrada"])
            c["max_operaciones_simultaneas"] = 1                       # una operación a la vez
            c["recuperacion"] = "auto"                                 # recuperación automática fija
            c["max_pares"] = nucleo.MAX_PARES                          # siempre todos los pares
            c["payout_minimo"] = nucleo.PAGO_MINIMO                    # fijo: 80 % o más
            c["rec_max"] = max(1, min(6, int(c["rec_max"])))
            c["rec_multiplicador"] = max(1.0, float(c["rec_multiplicador"]))
            c["stop_win"] = float(c["stop_win"]); c["stop_loss"] = float(c["stop_loss"])
            c["anticipo_ms"] = nucleo.ANTICIPO_MS                      # fijo: 300 ms antes del cierre
            c["tf_auto"] = False                                       # una sola temporalidad (1 a 5 minutos)
            tfs = [int(t) for t in (c.get("temporalidades") or []) if int(t) in nucleo.TEMPORALIDADES]
            c["temporalidades"] = tfs[:1] or [1]
            c["estrategia"] = "rsi" if c.get("estrategia") == "rsi" else "bollinger"
            c["bb_periodo"] = max(2, min(200, int(c["bb_periodo"])))
            c["bb_desv"] = max(0.5, min(5.0, float(c["bb_desv"])))
            c["rsi_periodo"] = max(2, min(100, int(c["rsi_periodo"])))
            c["rsi_alto"] = max(1.0, min(99.0, float(c["rsi_alto"])))
            c["rsi_bajo"] = max(1.0, min(99.0, float(c["rsi_bajo"])))
            c["rsi_direccion"] = "invertida" if c.get("rsi_direccion") == "invertida" else "normal"
            c["estiro"] = max(0.0, min(200.0, float(c.get("estiro", 20))))
            # "al estirarse": para todos (solo aplica con Bollinger)
            c["entrada"] = "estirado" if c.get("entrada") == "estirado" else "cierre"
            if c["estrategia"] == "rsi" and c["rsi_bajo"] >= c["rsi_alto"]:
                return {"ok": False, "mensaje": "En el RSI el nivel bajo tiene que ser menor que el alto."}
            c["incluir_digital"] = bool(c.get("incluir_digital", False))
            c["modo_riesgo"] = "normal"                                # cada quien maneja su riesgo con sus stops
        except Exception:
            return {"ok": False, "mensaje": "Revisa los números de la configuración."}
        if c["monto_entrada"] < 1:
            return {"ok": False, "mensaje": f"La entrada mínima en {nucleo.nombre_broker()} es $1."}
        if not c["temporalidades"]:
            return {"ok": False, "mensaje": "Elige la temporalidad."}
        if not (c["incluir_mercado_real"] or c["incluir_otc"] or c["incluir_digital"]):
            return {"ok": False, "mensaje": "Elige al menos un mercado: real, OTC o digital."}
        if c["stop_win"] <= 0 or c["stop_loss"] <= 0:
            return {"ok": False, "mensaje": "Los stops deben ser mayores que cero."}
        saldo = self._broker.saldo()
        aviso_seguro = None
        if isinstance(saldo, (int, float)) and c["stop_loss"] > saldo:
            return {"ok": False, "mensaje": f"El stop loss (${c['stop_loss']:.2f}) es mayor que tu saldo (${saldo:.2f})."}
        self._cfg = c
        nucleo.guardar_config(c)
        threading.Thread(target=nucleo.limpiar_viejos, args=(es_autor(self),), daemon=True).start()
        try:
            self._bot = nucleo.Bot(self._broker, c, self._nombre)
            self._bot.autor = es_autor(self)          # autor: sus resultados al resumen semanal
            if aviso_seguro:
                self._bot.log(aviso_seguro, "yellow")
            sesion, self._sesion = getattr(self, "_sesion", None), None
            if sesion:
                self._bot.retomar_sesion(sesion)      # volvió de Configuración: sigue la misma sesión
            self._bot.iniciar_hilos()
            ok_sp, motivo_sp = segundo_plano(True, f"{'REAL' if c.get('cuenta') == 'REAL' else 'DEMO'} · operando")
            if _es_android():
                if ok_sp:
                    self._bot.log("📱 Segundo plano activo: puedes bloquear el celular o usar otras apps.", "green")
                else:
                    self._bot.log(f"⚠ No se pudo activar el segundo plano ({motivo_sp}). Deja la app abierta "
                                  f"y la pantalla encendida.", "bold yellow")
            threading.Thread(target=_vigilar_fin, args=(self._bot,), daemon=True).start()
        except Exception as e:
            anotar_error()
            return {"ok": False, "mensaje": f"No se pudo iniciar: {e}"}
        return {"ok": True}

    # ---------- operaciones ----------
    def estado(self):
        if not self._bot:
            return {}
        try:
            r = self._bot.resumen_gui()
            if isinstance(r, dict):
                if not hasattr(self, "_es_autor"):
                    self._es_autor = es_autor(self)
                r["autor"] = self._es_autor              # solo el autor ve "Enviar diagnóstico"
                r["broker"] = nucleo.BROKER
            return nucleo.txt_broker(r)
        except Exception:
            anotar_error()
            return {}

    def pausar(self):
        if self._bot:
            self._bot.pausado = not self._bot.pausado
            self._bot.log("⏸ Bot en pausa: sigue analizando pero no abre operaciones." if self._bot.pausado
                         else "▶ Bot reanudado.", "yellow")
        return {"pausado": bool(self._bot and self._bot.pausado)}

    def detener(self):
        _quitar_aviso_mercado()
        if self._bot and not self._bot.detener:
            self._bot.detener = True
            self._bot.log("Deteniendo por pedido del usuario: se esperan las operaciones abiertas.", "yellow")
        return {"ok": True}

    def bot_operando(self):
        """True solo si el bot está trabajando (no detenido). Así la X pregunta solo cuando hace falta."""
        return bool(self._bot and not self._bot.detener and not self._bot.terminado)

    def al_cerrar(self):
        if self._bot:
            self._bot.detener = True


# ---------- ícono de IQNOVA BOT en Windows (llega con la actualización, sin reinstalar) ----------
_ICONO_ICO = (
    "AAABAAkAEBAAAAAAIAAsAwAAlgAAABQUAAAAACAASwQAAMIDAAAYGAAAAAAgAFoFAAANCAAAICAAAAAAIAClBwAAZw0AACgoAAAA"
    "ACAADwoAAAwVAAAwMAAAAAAgAC0NAAAbHwAAQEAAAAAAIAAjEgAASCwAAICAAAAAACAAZCYAAGs+AAAAAAAAAAAgAHVRAADPZAAA"
    "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAC80lEQVR4nG2TT2hcZRTFf/e+Ny9vJkkp0zbNBElQkKa2WCWWQosL"
    "MRK0rVRQdGNBBEUEVy6EIkW0Irpx48adxSCuXFQFpV0VpUWkCtGmxaY2YBJxkmb+ZTIz33evi0nFRQ/czeVyOPdwjgAK2OTUTGWz"
    "7ceD2SiYcFeop6oreVHOzf/83TKgAnDf3unHN7q9s+BjImAGSAJuuDsICID2dwJLpaxwcuHq+QsyOTVTWVtrzrl7udsNod1FhnMn"
    "dlok+RAi2icB4mYTzXLXNE9VWSuXh/ZrvdY6gVm5s9kN9+zU9LkjaSJZnoweeiYRTROLIQFPcEtGpo4lA9t3p7HbCm5ertdaJ9Rj"
    "qAjR6xtRZh7J+PxUifGJCfa8+B73PvkaYWMdj4G0tI0HX/mAHfseI7Qb4rh7jKPqbtHdBAvkA3C7qvx16zeubTvNyNGj7Nr3FJ1m"
    "FTQhdAy3iLvhZuIeTd2jmEWSxKlWO7z04Qq8f4T6pUs0Ly/wwMvvUhjcjnXbiCq44x7vjKiZEWJksGDMfl3l11cfJf/7H4YuHub2"
    "jR9IBopMPn+GXruOAI73VVjEzFCsLyuGHpVPn6Bba9D4qMqBN06zev0iV2ffYWL6GGOHXyC0ewjy3xuYkRqGdXpklUHWbjR4+NvL"
    "1PcepNNzCvkwN7//hNGDx9nz7FuAY7G35UHEcFQ8epJBfaHGoW9+4Yu3x1A1rGf98Ikwd/ZNus110uL/CDwi4q4xRsXNYwgceGiI"
    "XSMZjVaPbDDBYhct5DSXr/H77CkKJe27YAE38xijpiq+0glRshz/8nyVP241WJxfpP3x66zfvIJoghYGWP7pK348E6n9eQXNim6x"
    "J5qmKzI+PlVZbVTnLFq5FyyEjkleFMJmkzQfRDQBdxAltGtoVnRNslQTXdsxvHO/AIyM3T+9sdH5zCyOqUKMW8WxiG/1UADRBHcj"
    "UV0aKOUnV5euX5A7dR4fn6w0WptPR7fdW/d3gyeqK8Ol/Nzi4vwyoP8CqDqpcrFZW+MAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1J"
    "SERSAAAAFAAAABQIBgAAAI2JHQ0AAAQSSURBVHicfZVdaNZ1FMc/5/f/PW+b22K6x7dkDl35UpEGq+2iRI2QQiga5KYZ3lRERReB"
    "gSBRFpQ33XRTFFFKYdELEVEGhjExqCudqOEUddNtztn27Hn2/H+/c7p4Nl8iOnD4wbn4/r7n7XuEmjlAuzbvaBg+N9ipqvMsIjj+"
    "2xQkwZxzo8XWRUf6vvtoYhZDoDuBA3Hp6o3bqtPh9ajahggCmIHIjZd/xcBInBvI5vzus8cPfgrdiQC0rdrQW67Gz0JaRTBLHBbV"
    "MBwiDtMAzCBSQxRJMFMBxGeyFLLJ1oH+X/ZJR0dv47mRsydCiAudWJwO+FLZaJrjIJ1CY8AXGmtAAAimkVCeJMnX4RIfDEl8kgy1"
    "tixd6S5PXuhSjYuESKWqftkC4bWeeupcmYb2Tm5ft41YLWEGZobGlCRXx9JNz1GYu4SYTntMUY2LLk9e6HIWYoupmhO1yXKg+8Ec"
    "b7zaxP0rhPnrXmbNMzsp3vsYaWkMSTyhMkFj2xru2vESxbWPEiuTtdKqmoXY4qKqmamYKpgSg0IASYXTv77L+QU/sHzLTupalhEq"
    "E9fTTksRzDDTWZeoag7ijWBQWpo9Rw9d46djZZp35Tk/8A2Selb07sFiyuzH4hIMvRkQiDOTZkqMkXwBDv85Qc+bQzR9sAkfHGOv"
    "HKc8cpHi2rUsWf8s1clRcMn1ht8KCI5YY6hm5CTwxU9j8M4GGuYKl57/nbuf3svAwfcoDY3T/vgLNLXdR5gaRxw1hqoww5oYcXE2"
    "ZY2EEGj7cCOF9mZObf6SVZt3M7+jk7H+3zj11dvkGjOs2PIWLltghhBmN0oWiXgiIEYYr9DYfQe2uoXhrd/TmoOkuJhQUjINzZw/"
    "9DEt9zzC4s71ZAqNxDK1oZ9N14AIDhQNETfHUzp8kStPfMv7PQ089EAD166WSRKHaUR8hhOf76R0eYTG1hVYbVbglhoqTomYRRJv"
    "TAxO8uLDBZ58ah5j4ymJm0lJFeezlEfP0b9vFwi1dTTDdBYwokScRRNUzVRBjGzeQdYRQ4rzWTJ1CRqraEzxdbcxePQA5w5+Qn3R"
    "oxoxjbWGqJpFE5+IjRgqGpVsDvb9fIWJitLXXyE7tZfSsWVUrg4iiUdDlSRfz6mv9zD990Uu/fEjLldAYypOnCRiI7K8o6Px8l/D"
    "J9IQFzohVlPzoRzJzclAWqoxKzTVxMZmRMeMtHQNn6/H+Www08R7PzR/eXGlABQX3tkzVa7sS0NK4sScw2I0TG6Wr5tNEJdAbWXF"
    "ZzLU5fO9w0Mn9zvADQ+d3F/IZ7dnMv6MgUStCaGYOSw6QZzIjCNOBIdFByY+488Uctntw0Mn9wNuVjVrJ6Crq+H0wHCnRp0HJvyv"
    "ibnEjba3FY/09fVdPwH/ABCTZrtUkIqCAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAFIUlE"
    "QVR4nJWWa2hdVRbHf2vvc869uXn0YRvbxjLx0TTRqogf1IHBUUOHEQVbWws+6tiR4AMVQdQPUxyQgp/8oFRlsGgdx6lvfIvUgtCi"
    "CFK1qWnLWDOR1LS2SWyS+zhn773mw7m5SaYDUxdsOOxzzlrr/19r7f8WZswAQVVl1eVrun3q5qsG4TRMxKhNovH+L94+ICI67QtA"
    "Zq1wzqrVd6Spu88F14NSrP/+f9zr9EM1stFAkkRPH+7/5IV6EBVYb4XX/fKeq7emmd7jXYZqOJ3E/xcSbBSTxPLMjwO77lXWWwHo"
    "vOCajdWq256ltUwEa4wYIxBCjlOMBVU0eJBZiFQRMWAMhKCqQVXxcVKIi8Xo9sH9n74kfX198Xs7v9ubOteDBjUitpop5arS3GRI"
    "bCCrTGJshC225FGlzowIwaX4WgVbKGKiAmjwKkaSKBq4vvf8S8zuL4dWOO+6NHgjorZS81zYadn6YBtdyyANMV3rHmXxpdeSlX8B"
    "ETQEFMWnFUpnnk3PbY/RvGwlPq2gYDV447zr2v3l0IqomlYWoiFWDRiEci2waXWRP985j6nj4zyx93f0rNvIxDBUjg4yMbQvRyKC"
    "r02x9LJ1nLdmAxoKDLz8MCYp5lSqxNW0stAgoqoBNKAaEAKqSjbmaGkrUhn6Fz989T7VjiG6N2xB4oTgs/z7OlPphM9rpMpsX4io"
    "yYuVb6gGQggYgTgWdn9VplI7wNEr3uHIvDdoW34u51z3ENnUGIhB1QOKMTYP1XBef8571dU38qU+sHC+5cmnRvj7njLdb95A1LaI"
    "Yw/vxtXgN723sPii1aSTo3kHqTamYTrJRhAchmzmhXOetlbD0zuOs3nHOCt2/BGzpMSPt7xDobyEiZH9GAsrb/orSdsifFaZads6"
    "RdRpUg2Q5dM2Q5EAacpn+6boeLaX0sXtDK7fwZmL19C9cTP92+6nfHyM1rOW0nXjY7jq1H8NdZiDAsA4HEEDoATncJnj7K1X0fL7"
    "5Qze/BZNo51c/MAWCMLkyCEOvbkFn8GyK/5Ax283kE6cQCyNAs8sxeGmESgqivulyqK/XMa8m7o4vGkn2WeHaevuwgj4tEzcvIDh"
    "Pf9geM+72BhWrN1M6/IL8CmISD3zGZryIk+fPSEgsSH79me+ufEjLh36iUfv6mD8RBkjAIIGj01KHHxtMyeHjtCy9CzOOP9KfJpP"
    "9SkUuWwGQfCeqNny8z8P0nt8hDeeO4/2ViF1oR4ANDjExlRPHmP/y4/ktHg3p8izKaq3KQ1oogGXCLeuPYMFiywnpzzWgKrLHQDB"
    "p8SleRz9+kN++HgbSWtCyByz/cyhSMlkLqzAxISDlggj4LKUpCXCxAXUpTlalxE3tXHo7ccZPbSP5vYIVY8GP7fQZBKJMaNoyFQ1"
    "9kGJE3j+gxP4SNi+q0rtyOf0v/I3xg5/g08r2EIJVY+IIaQ1vt12L5PDm/j3rlfyJIKfnuRMjBmVvr6++NW3du5NU9cjooqIraUB"
    "XwlEJUtilbR8EhPFRIVmZikYiCG4Gq5SJio2YeJiflyrSJJEAxvW9l4iAEs6ujdOlqvbnUszEWONIMaI+KCo1gUHRcOpSiciIAZ0"
    "WnDUR1ESt5SKt48MH3hJACuCX9B+7jO1Wna3d+5ULfwVZqOIQiF+duzY9/eoYhuiL0JoX7ryT+Vq5X7vXA9I8de51qqNooFSsemp"
    "Yz8dfFG1IfoNa1xbOjtXdWf4+aie1rUFEY2x44OD/adcW/4DHcEq47+JV/8AAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAA"
    "IAAAACAIBgAAAHN6evQAAAdsSURBVHicpZdrjFXVFcd/a5/HPfde5o7ADE8ZMHUApTLVamyttioq1DTpl4IYraVp01pIjWmx9i21"
    "Jk1Nm1p1+qHpg4rYpzGlKULUxFqrto0aUCoCVUBAkeExw9y5j3P2Xv1wzj33DmA/wE527rnnrLPXWv/1X/99tjB+SParAMYIq1bd"
    "VxgZOSKcxqhUJung4O0N5/SU63feAO4y8D0nAvMv+uT19XptaZK4AcVVQM3pBADiBBn2fW9rFBX/uP3FP2/UDl+dARjAXXjZ8hlH"
    "hw//stm0S6y1OHUdsZ7mEDBi8DyPMPQ2Teye/LmXn/vdgZZPyS70g1fcNO3Qobf/Vm8k/c42ExEB5DQzP3GoU1WMF/pRwd/Z2zv9"
    "Yy/+ff07mYO7UFWGDh14qF6P+23SbIqIr+ArakCNnvHEFxHfJs1mvR73Dx068JCqAnelJZh30eLFw8O1TXGjnogxfgt3I4ICIpAS"
    "SUiRySzUMY5G+RNBxKAoAmiHnTqXBIXI7+4uLnn9pc2bfYCxau3mJEkU0cw4dTpadxjAOihFBlyMTZqpA8/H+GFuf2IQtlEF8QCH"
    "FxbbdqIkSaJj1drNwGajqpIkdqG6RFAMqhhRqnXHxy8OefInk7jzhjKNRoxf7GLBZ3/KwMqfE1Z6sHEtjVS1PQGXNJi9eCUXf+03"
    "TF5wJUmj2mGHUZekPlXFrFixpoBzFXUOxQGKujSIO5eVufT9AV9f3sWss8bomr+ImZdfRc/CS5m3/B7UJuCyd7KyubhOcfIs5lx3"
    "KxPPXcjs61al8DuXWTnUOXCusmLFmoIhfz3NQNXh1OGb9L8dVWp1KPiAH2BHLY2hJr0LLmHWoi/QHD2SclkzB84iXoBLYuJqGpwY"
    "D1Wbo6QdAfu0yJQ9yKUq638BSgWHFIvs3bwe7d1D5cvn07PnWs5dspKjO55lZM8r+NGELIGMRyKIMdlaDlQYJyoZJwyAI3uptQAK"
    "6oitYro8NvyzyuuvHqV8YUT4xS5qlTeo1t7ED33m3fh9TBCiNs6yanMh7wrtuN9CudVpaeFaCLjcMLFKb7fHCy/XuOXbe/DO62HG"
    "/ddSmDOFYw++xvHf78SFSvfsebzvE3cQV4+lrZeVYlxPqMsTU1JfKXeyANpZp9FZ5ygV4LntDT61+k3oqzBr8Gq8vi6O/foVDv/o"
    "30jJR62QVBNmX3MzPQPX0aweQcTL4c1lIUO0s9SqnQjkzrMHqqgot927jyNRxJyfLcLvn8joo//lrTseo3/pNzGeYc8T6wgrPi5x"
    "nLf8bsKu3rQ1kfHl7lhbtaMkeQAt4mTwiKfUhmvYckDf4NWEA71UH9/Dvts3cPZHbuCCFV8Bhdf/tIbqOwcBKE2ZxrylazIBGleA"
    "DJGWU5fzraMEHQQUJak2kILHjPuuIvrwDGpP7+fA7Y8zae7lfOBLD2Ibihif5sgQr63/FuIZ4mrMzMuWMOOyG2keP4x4/v9FQDu7"
    "ANoEdEkCBY+pP7yC0qI+6s8fYO9tT9M4NkrP+ZfiRyGaCKoOv1Th3a2b2L35V4RdAfGYZd6y71KePjdFwrSAPpEDLUQ6SIhqKljV"
    "mGigl8rSuSRb3+WNW5/inLIyu69EbXQstwNFbYJf7Gbnhh9wdNdreIFH2DWJ+cvuRrVTU06FQB7A7jb81mJKPvUtQxxc+RTbPvMk"
    "U5Mmj947m0kliC35btiCUYzBNetsW7caGzdRm1Ca2ocXldvNcBIHWte7yaU4j0oUsZYjj2zno1McG+8/h/kzA46PWYy0qa1ZZs4m"
    "+NEEju76Fzse+zFB2cc243Fi1Gq790CAdl3yUjikO+DB1dO5oL/A8KjDMyconGpeU2djgvJEdm9+gIMv/YNwQoBa29EFp+DAe+lA"
    "azcUZxkds8RjDiMgLTo5izrbzqwTUuOxbd1XaRwbxvgGtek35akQGE9C11rEZeRR4sThGQjO8imEQr3pUNvEL3oEJQ+1cS7hLUJ6"
    "YZHRt3fwn0e+Q1D2CMoZwEmzo3CZLGdS7K9du7YxedrcEWgjIEZQ67hn3UG+EQgbnxnhrSMBpVf/yt5nrsSPyrz17MN4hVKKSMY2"
    "tU2C8kT2P/9bSr1zmHbJlez6y/04ZzG0ex9AREfWrl3bEICeGfPXjY3Vb8qw9VMDGKs7jAjWKaXIQ12MO+GTbPzOl6+OrVcR46Nq"
    "8QqlTrsEMV6pFK0fOrD90wZgQjF82DMiztm8Xs4p5UiICjChKFnL+XiFMl6hhPGCvHQnT4cXlTFBmKHU3g2ds3hGJCqGD0MqKUZE"
    "3OSp/U9Ux2rXqNqmiAlPTuvMh6prinhhuVR88vDBndeqqmkpofTMnHpLFAW7QELnbKLqElWXfsCdwdR0Js7ZBCSMomBXz8ypt6iq"
    "tBCA7Jg0MPChmfveGfpFvdFYYq3NxeJMh4jgeR5RobDp7Gk9n9+y5YX9dBzNWiO9IUJf34LrR2u1ZXESL1Q4k8OpCgwHfrB1QrH4"
    "h717t23MkjLAuMNp/kb2mx3PDatWrSqMjIyc5vG8ooODgw3n8vY76Xj+P4WZKBIgC1ecAAAAAElFTkSuQmCCiVBORw0KGgoAAAAN"
    "SUhEUgAAACgAAAAoCAYAAACM/rhtAAAJ1klEQVR4nL2Ya4xdVRXHf3ufc+5j7p1X22mnrVChLVAqHSovUxSRlBDEImCKFCFpMAJi"
    "RL9AI6ilQCMBokZEEYwaeQeBEkyJUANpIAKltCJtgQkVLKXv6Tzu3OfZa/nh3Me5d25BCXAmJzl3z9p7/dd/vfbe0PZZaaP303oO"
    "rc9MHFrqwSMO4JTTls0dyY2fHrrKcSLSq6rexwHHGOOstUO+F7zenc0899L6BwdbdbcHuHSpxyOPuIWnfXPe6PDojaVi6euiBCKK"
    "opGMtjHrI4wZDNYarKGSTCWf6Orp+umm9Q9vq2GYCLD6j2NPWLJsLJe/u1QJs+IqgIamHdEfwxMZbXzrBSQDP9eZ7bh868YnH4yD"
    "NM3gvrpsNFd8oFAoYCA0xnhtePjYcaqqU/DT6TRd2dTFWzeurYM0rFxpWbVKT/rieXN37xvZnM8XksaCwVhVMKZ1tU9mTFFRgY6O"
    "dKm/r/v4Dc+vGYSVxrJqqwF0/9DYLcVSOW1QQbGqCiiq0RsFUPOYai0yW8a0jVx8LKKtaQzFgkqxVE7vHxq7JVK2NbLnhEXnzd61"
    "Z/8bxVLZs9ZA1a0166yBcgieBWtBBIwx0eIuxHhBFfwHsKVUqRJUBOMH0XeznIooqWTCzZg+9ehXnn9suwUYHR9f7AQfxKmqabVu"
    "rCD0ZsGzSr4oWAuuUkJFCLK9hKXxD2UQA65cAOPhZ7oJi7l2cgbEOcEfGRs7E8ACVMrhAhHXML36WhMB+v65aV7+9SSe+Vkvxx7u"
    "k8+XSPf0MfDdezj5ukeZveQaXGm8ypBOfAFXLpLpn8PCH97LyT96lMNOX44r5SfOAUQclXJ4XB2giOtVkapA4y1XhGk9hhUXZuhJ"
    "WxbMD7hySZbxkTGmn3Quk+cPgM1wxDmX0n/yBVRyQ2A9lJa4NQZXzjPztEvpmT0bP9nNZ8+6ikTXFKRSisVABFJFEHGT6gBBjbYk"
    "ACgiSioBTqBYUaSopIJosSA7CZsEW/FwYzDngmvJ9M/BlXLVEJbGWiqAwQYJXEmQUFAVbJCM4rBFbxWLaQDUiL0mq1XrE42JPGEA"
    "EcX4AcPvvMrOvz/DWHYL4x07SGayHHXhKlRcFVCDlWjdSIextpoVBhWpGtBcIagbVQVYw90UsDWQ9bgAE1hUKqg1vLv2Pt7cuZr3"
    "B/7M+/P+QEEP0jf/JA5ffDnlmqtbS0lLpjc0T2SwJmnrghpHr02Mhk7JdFh2vFfmtkeG8HN5upcN0H/zYjwvgxwM0bwjLClHnvM9"
    "emafSJgfmZAA2oJPD6UzZoyt06Mxt9IQcqKkE4bRccc3Vu3iX68NM/ncI5m88guoONxQgV1XP035/SGMD9YPOGbZamyQRF3Y8MoE"
    "9porRpNe1QhTg8GGi+MTRJSEFyXJRTfvZsPGYaYtnsXk1V/CWIPmQ3b/4FmKr+/D78kChrBQoWf2XGYvuZZKfjiq7DSz0s7FxJiL"
    "GxOVmTZJoqqY6vfy2/fwt2eH6Fs0ncm3fhmb9NCKY881zzP6jzeYteTb7H75CVyxjPU9yrmQWYsvoW/gLCq5g/XS0wquXo7aJIno"
    "IRiM4iIqAwkf/rO/xF/XDTFpYApTfv4VbDYAUfb9+EUOPr2JWWcuZ/5F17Prxb/wzrp7CLIWdYqKMu+iG0l09SGVYoOwVhcfIkma"
    "GIxcEEv5qHnjcGiuRPecbqb+6gy8ySkwsP+mlxl6fAMzTj2fBctvRyrgp7t4+8nbODj4JkEmICyGZPr7OXrpKlxxnGhP2YbFtkki"
    "ddlqklAXVISoagkuV8abnGbaHWfgz8yCNRy4bSND92+i7/NnsPA7d4LxEKcY6yGVEtvuX4ErlbGBpZwLmbHobGacejHl3AGM57ch"
    "MF5aYiClicEaYq3Gs+BKIbYzQf8dZxDM6cF4huE7NzPyp62YDmX6wq+R7O7AlcIoYSTES2UZfnsDg2t+TpCO6qArCUcvvY5M/1zC"
    "Yq5lh9NanOOtNhaD0lL3VBVCYepNi0gtnIqxhpE/vs6eX76KdiWxxuAqRdRpddtVXd9VCDK9vPvMb9iz6QUS2QBXdiS7Msy7+BaM"
    "9aq1sIbyg5Ik7mKYWPENmJSP6fAZf/gNdt78MrNmZ7j6/B4qZYet9b+WeFIUrMfW+1dQGh7BS3qUx4WpA2cy9fizCQuKsQ2d9b8J"
    "XafFxY0dSM35hr0/eYFdl6zl3ytfIpEJeOiGmZw6P01YkbqSOEBQ1Dm8RJrx3YNse+gGvISte8dPplvyROv7gDiD2upilZZ2pIIN"
    "DHKwSO659zjmiBSPrv4MJyzsYN9IWI/VJlUxV4kLCbKT2PnCA7y3/gkSWQ910tzqagkSYy0eiyqRsB/T0KTYGCE0MHVGkmd/cRjT"
    "en1kzBF4tXIxAWGLAoeX7GDbw9fTM/dEOvpm4MpC/Agbd28Dffy7rYsbQMUJvhU8A6P5aKvffIBq4+KaanFYP0F5dB9b7r0Wg6l2"
    "pmajWrO3rYvrdMeojvdm0ejgJGKIzlQKGFQbmwxM43d9w+sq+Jlu9m5+irefupsg6yEujM1pZrFuvDY8Wd0PRiOtG1ZjoFASPAup"
    "wGDTlkJJAMGV8/hJiwkCjG8Ii+MNkDE3qQsJOroZXHMzQ29tJdkVYDyDsR6ulI9crtLEYBW21gEay1ATxdU6lPBg74EKq+/by3BB"
    "2Pxajjsf20uQ7mTH8w+yZ/MrqBth+9rfknv/TbwgVe3jcVYErEUqZV77/VWMvPMWYXGYwSdvpTi8B+P5Da/FCIowVSvmYUcOXDE8"
    "krsrrJRDY0xzP8KQLwrTp/jk8kK+KKRSHq5cwnoBQbaH4sFdeIlU1d7W2DRVhRFjXjKDn8pQHN6Fl8hMkFfV0A8Sfk939sod2//5"
    "OwvQ1ZtZ51nC6HqtFgCNupjtMBwYCQmdkEqCOocNEmCU0ug+vGQHtYNSq6tqYyohNpFCXJny2AG8ZJbawaqRdKqq6nmWsKs3s65m"
    "nge4aTPnPTaWGz9fVULi5afGQ72lxS2unqS0lbUPeGrdp/2c0Bjrd2Yzj+/Zue0CosuMKCUn9fWtSCYSBRGx1aht2cBKPb6aGvqE"
    "sVYGW/ustEkKABURsclEojCpr29FlTy1kZaldtvm9YNdnZ2XpVIpK05sxKTq/3Up9NHGVFVC58SmUinb1dl52bbN6wdhqQUk1u2j"
    "69fDjxj41ujY6F3FUjkr4jCGT/QCUxXfWo9UMpHr7uq+4t3tmx+IXwW3avYAN3/+KfMODA+vyhcK5zknn+gVsOfZSkc6vWZyT8/K"
    "LVte2lbDUJvSjpq6wDELTjpqbHj89EpY/pyo9qrS/hL9fwXYUCrGmgMJP7Glsyfz3BuvbXirVfeHPZbYXvFTeA6p778F+pa6IKZy"
    "mwAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAwAAAAMAgGAAAAVwL5hwAADPRJREFUeJzNmnmQXNV1xn/nvtf9epme0cIw"
    "AwZJSCgasAXEmMUQMthgYyDYCZUxiyGpshOwC3ClDNhUglEJh5TjwtgkeGFJSLApLI8DoWwnMS4MsoAQFsdIJZBAK2KRRttsvb53"
    "78kfr5fXPT2DnQKSW3W7Xk/fe95ZvvOdc98bmHOsMsPDw/7ca965Ed97lZlrjcz6y8iIx+ioBbjzzjtTd92/dqgaVpa5yM4TwXub"
    "dQVAFesZcyAdZLdf8anhTVdeeWXYqctvYoDUpzvjI5cdtffg5GerleofRVG0XFVQnWXX22IBiICI4vv+K0EmeKh/fu931/38+9sB"
    "E69A5zJA6h/63pMuuHaqWL6pVrO9URSi6gBsp4B3YAjgiRh8P0U67U0W8tmbNz77469rS19NLk5eyxVX3OmtfeZf75su1S6uVMqI"
    "aCQiBmROLL79Q52qOlXxM5ksPfn0A8Mn/eGf3nXXlQ0nKsRhAWBkZMSIiHvsmYfun5yuXFwpF0MjqCA+ikGVd3diBPGNoJVyMZyc"
    "qlzy2DMP3S8ibmRkpKm31LX3GB21x554/rUTU+Vby6VizfNM+t31+NzDWlfL5vLpvkL2uhef/+nXGzpLTFOr9YyPXnTEzp17Nk2X"
    "yoERMbxzqfq/HepUXU8uW128eGBo3SNrXoNVYoaHHzeA7hk7eE01tLmYZ1RaMGufxihGuv0GIlI3u/veuaaIxPuZdb8IqtXQ5vaM"
    "HbwG0OHhx40AMjKyKvX0hrWbS8XyYlCVRG40xIkIAhQrMRfkg7qpKCIGdRG2VsWkUhg/QJ0l3vFWpCUggq2VQMELcvEenblPwYFI"
    "Lp/deerK4RWjo6tDA+i2Xb9eYaNoiToLYDptF8BaR6XmOGXI58SjPUpVh1OHiGBrZbx0ngXHnEK6cCi2Mh0bhXtr36vD1soUFq2k"
    "96gTsGEFdbbrWsCos9goWrJt169XAOoDFKuV5c6Bok5UZ1ZZgcgq3/hsL5/5WBZV+MaDRb58X5GsVyHbv5iVf/735AcXUZsaZ+M/"
    "Xs/Bl5/Cz/ZSd8oszhdsWGHZx69n0dmXI8DrTz7My6OrMH4wSxTUOYdXrFaWAxsMgFM3X2P60hmYF6VYcbz/aJ/PnJulWFYqNeXq"
    "j+cYOjLF9FSRI864lN7Fiwina6QL8xj61C2kCguxUaUV/M4pYGtl8gNLOfJDl+NCsFXHe37vExSOXImtFuOy3LlPVVUVp24+1LFu"
    "aPQIimr7BMVapS8vOAtOwTpwDnqzYJ3gB3ls1SG+ISxF5AYOZfmFN2KrJRCZIbPhJ3UWL9PT5H4F1Cl+tlCPXHd9UI11bhjg4qV1"
    "oLVb3NjknNIgmQZZRA4ERTyDFxiM9fHEJ5qEw079KId/8CJq0wcQ482UW0d1rGiCsUVQtfEK7RK5OnG4+vKYbSx1D3SpiNSRlcSh"
    "gjHgiUX9FFt+chtP/tUIr2buZtfxd1EsvIIrK0dfeD35wWVEDTh0q7idadH0obZulphNHW3SgHoMmmFMzAT2mvI8E8No/8ESYJl4"
    "+SX0/AqVk3YwHWxkfOkTaCikewusuOgr4GwMgQ65mvg2Yyjd9WlGxSUNoCWs0+KE5XErrWQzhqtu38PGnRWCUo2FX/gg/dechimm"
    "8bwculEwHoTFkP6VJ7Ho7CsJG1BS1+bJLkFoGtcdES34JQywLWW7MEZDeadQKHhc++0x7v23SXLVkN5Pv48F15xANDaNWZhm/Hsv"
    "svtrj6CBIuIRlizL/uAq5i07ibA0EWMPTXiyiwWqTUO75qTOMABaEOlki3g6Vfw+j6/cu4/bfniQHhvS88kVHHLDydgDFbxDskw9"
    "uIV9tzyN6cngpaTONIJJpRi65Ba8dAa1UVPlTmWS6GlGYgYLNXS1CQNcAkJdvG+d0pcz/PO/HOSmf9pPPgrJnb+U/tWnYSeqeAsy"
    "FB/ZydiNT2CyafIDS5jYsRUviMVHZcu8pctZdsEXCYvjcZXWWbxfV1DfAhENGjI0bOnweOO7c0o+Izy9scjnv7OXoBqSPfNI+r96"
    "BloK8foCSk++ztiXnqJW3Mvis/6MwfdfwPp7rsaFNcQDMYZa0bL47MvoP+FjhMWD9Xxox3N7DObOyUZ9T7AQTeuaCVTHvhHHnsmQ"
    "8ECV/KmDDNx2JkQOk09ReWEvY9c+QW1iL4OnfIL3/ckqTDrDxLbn2PLwN0llDaoOQVCnHHPxzaR7+3FhpUWt3SDUKHZddErq3GKh"
    "1kmoxcMK6iwWhynWyLx3IYN/92HwBAk8qlvG2fP5x6mO7WHhccP87hXfikWHFdKFBex89E72/PdTpPJeTN01R25wkBUjq+PaMNvQ"
    "hMIzEJTIBdra5oTXG12kOhyKm6qRWtLHwLfOwuRTiCdEbxbZffVj1HYfZP6xJ3Pi5+7GpHO4iCbGxXi89MANVMcnMH7ckofTlsNP"
    "O5f3nH5pokp3iUGCNmfgfzYabWEMUIdVhyuF+IN5Br99Fv4hWVQVO15l91WPYt8oomnLkg9fQbZ/HlGlWj/6K+osJp2ltGcrm9bc"
    "jBfUjRLBVh0rRv6S/GHLiarTzdZkJpC69VANw5IsZJPlId7oVNHI4c0LGLz9Q6QW9aKhRauWPdf8gvKmg7hcCqOCOouLtHmiarJd"
    "FJLKz+f1p37Aa798mHSPFxNDBOneHo699Ktx7x9XyASCNNFpdEag/lnPYj+xqz2hjKBTNXouHiJ7ymHYvSUwwthfPMbks2MsOCJL"
    "Lu3xxpSrP0zqcGOjajqHF+TYNHoT85Z/gFz/4diaEhWV/uPOJKqWiCpV/CCTuH0HC3XKnZkDLmFhq4RLxqf6whjRq5No5Nh7/Vqm"
    "172BNy/g3usG+J0jUtSqrusTo6YktRg/TW1qHy9+/waI+QgEXKQc9oHz8NLBTDLSdn3aWUhpYyHXDFsCY84hGZ/K+n28dslPeeOi"
    "nzD+81epBCnu/sKhnDdcYHza1h/4zdYO1C9tSCrXx94Xfsb2/7iHVI+HWgcILmqHT2Nvs53uUgdUO9vptrC1PkVjI+xYifJr0xQW"
    "BvzD9YNcfm4fpXGL582ifFJeo0WxEX6+j1ce/hsOvPwifs5DnZsJvY4IzCq30wBNcmzTe4onlqoqx6/Isv7uJXz6vD6mJh2eJ203"
    "kY6bNJkjcS1icGGVjfddi61WEW+WXqitW53JQm2pCtTh1M5CjSkoUWjp7xMOH0gxMeXihvI39VSCy9VZ/GyB8a3P8PKDt5LKeajO"
    "cujXTsy3WAi0vRdK1oGuvQcQRooLFS8JullbYm1GtK0oqeJsSKpnAdsfuYPdz68jlfdnPrnQxgGLWfVqrwNN22bJeo0Vbz4jqMsw"
    "Ur+QuN9pGWVasrRDXn2zGI+N37uOyvg4xpfmftTV5c2uT7IBbNCotrzdETIFMcr4tEX8OOd8A0ZgomgBS1iaxEubmPPTgq0WcVGN"
    "hMntMp3FS2cp7n6Fl+7/Mn42NlgA8QxhqdFyuy76NCLgtGmAGHOgXkOlI+I4p+Qyhl9tKnLXw/vpyRmCtOH2H+1j844SuUIPOx69"
    "h/Ft2wl6M1T2H2Drv38zrsqJito2oQ6l+bz+nw+w5cf34AceXsaw8xdrmNj+K7wgizrXjpqYWETqOlN3EStX/v7K18Z2r6+UyyrG"
    "dBIKImCdElk4+ZgcUaQ8v7lEOi0YY7DVMqmeBfQtPpbpN3dQ3v8qXpCvw4u5h8bda9/SExHjMb71WcRLIcbECneWCOc0k83KoYcO"
    "Hrd5wy83+IAMDQ1sfnP/2A5gcT1u7Q93NX4S4Rl4asM0CPRkDE5pwiEqTzK2/nG8VBo/yCcw/RYGAF46w/jWZ+Ncy+QTLp+x34GI"
    "55kdxw0NbN68AREY9mFtdORRx/3twYmpL9oojETE73ZfIcY+xAjUtt+keUDpfsqafcS9VN1n6rruFkBVI89P+fP7Cl/btX39l2DY"
    "N7DWATKwsO+OIO0XnVNR7Q5e1fh8bF2346erd5Zuduqbg6rV2VZn2n2NOqcSpP3iwMK+O2Kb1joTh2XEPPfcul09+fyqIAg852zY"
    "it//hwnO2TAIAq8nn1/13HPrdsGIAVwiRUY8kR/Zwxcdu2ZicvqTYa0aGuP5gPy2kHi7htQfNDpno1Q6SPX19vzwjVdfvEj1jz2I"
    "X3wnknXUqao5/5zTL+vrLaxJB5mUdVacuojWqf/dHM6pi6yzkg4yqb7ewprzzzn9MlU1MNrUp/uLbhFdvPT46yanpm6sVKt9Noqo"
    "c9q79KJbPRA83ycTBBO9hcJf79z2wq2qOueL7s6/6fGnDC/Zt3v/5yqV0oVRaI+2Haehd0Z9wRPBT3lbMpnMg4cM9n/nhf9auyOp"
    "Vzdluw2Pese0amRV+gebfraiUiovc+rmqbp35J89EHG++AeCXGbbxUPnbF49urrWqctvO0xcJ/6vxrBPR1HtHP8D/CJlT2//E3QA"
    "AAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAQAAAAEAIBgAAAKppcd4AABHqSURBVHic3Zt7tFxVfcc/e+9z5nln7s3NkwAG"
    "QiImGCKSBIjIpDTFYqko6bURXHUtK7WKCgqVVkMplGJrFV91KbK02iJkrahVl11YDZBLTZBHSElCIBgDicS872vuzJ2Zsx/945x5"
    "3Tsz92YZRPzN2rmTM+f89u/327/Hdz+O4ETp1ltlbtMmCdDf328Be8I8Ti7JXC4XyrNqleW2214eefr6+hQgxl8XQryirQWJSNYp"
    "UUsOzXSrhLpVL1x99ZJisbJKlysrjDVnWOu6Hc6baocnkwRCSyEGlSdf9GLxJ1Op2Kafb7xvRzvZW/PoQH19fWrDhg1GCMEbV/7Z"
    "1YVS6QOlUmmlMUhtDNYanHMnR5sTJQcIEEIipcRTCqWwiURiSzqR+MpTW75zn3OupkM7Nm0NUH1weW7tsnx+9PNjpcqbSqUyRgcA"
    "WghACCGm5EUvHzlwOFcdB095PolEnGQitjmT6brhif71T3YyQkvhqw8sXbnm2nx+9EuFwlhc64qRUiIQ6hUa80lJAA5nrLV4Xkyl"
    "08lyJpP88NNbvn9PLpfz+vv7datnmqh645IL3vbJ/Gj5jnx+xAmBFUKq0O9eDSRwzhrnkJlMVmS64ut2PPbDf2plBNn4n76+PtXf"
    "36+XXnjl+0dHy3eMDA9pKQQCoXAu1P9V0RwCoaQQjAwP6fxo+Y6lF175/v7+fj2+QtQ9oK9PsWGDWXbJmvMGBvKPDw0PCyWl5BWO"
    "8ZNAzlhre7q7XW9vZsWTj3x3W1VXaFLuVtnXt0tsf37k0cHhwnJjAhO6/aufnLNGKV9N604/ce5rsxdt2LDYVcujhDDu4Tb7/K+C"
    "NcVysFzrshFCqN8BXz4pTQihtC6bYjlY/vyvgjVwmw11rnuAFELYBUtWPzo0XLjAWm1DA/z+kHPOSOnJnu70Y3t2bLzIOScBK0O0"
    "hF226qpzyuVghdFBlPToaFjnQuspWW+tkhEIhFAIoUDIkzKoQsg6TwRTSdACoYwOKJeDFctWXXUOYOFW6eVym2R/P7aYL63Wxkpw"
    "eirQVkooVRzFkotwOXSnQody0T1CSEyliA0qIARCSrxEBud+s/lKUByOlHaoeBLpxafI0xltrFfMl1YDz+Rym6TXX2VaqSzXWkdB"
    "4drzAKSAwphj/hzFey9PMatH8r87Ktz/cAlPQYgSJbo0SnbeUk658EpkLMHRpx/m2I6fouJpOGEjCHAWZw1zV76TaQvPpzIywIHN"
    "Gygd24+MJyfnKUBrTVCpLAfoDy8hATv/9X+4eWRkdKW1xgjax78QUA4cr5mpeODOaZx+qgeBg4Tg39YX+Jt7RsimPSpjBXoWLGfp"
    "B+/GT/o4C0LBc/d/hv0P3UMs3YuzmilXWSEx5VEWXrWOMy5fiymD9KF4+BjbvvgeSoO/RnqxKOxak8MZKZXKZru27N354JsIHRkr"
    "hMAZ0+Osq5qadk0KR6FkufatSU4/zWPgmGVk1FEYsFx7eZLF8zyKZYvA8JrVf4WX8CmPVAgKmqBgWPD2j9I9/3x0aSS0yJSCHkyl"
    "SPqUhZz65rVUhg16zFAerJCaPYNT33w1plyIXK8TL4SzFmdNdzSVtpL6GEiHBefo+HEOJWBur8RVHL4HXlQwPU8wu0cSBAblJ/C7"
    "puO0QygPoTycFUhP8bo/vx3pJ3E2iETr/AGBM5pYZmbkmxIhFUIpnHbEumdHCXYSPq76F1Urf+N8JPynoxFDgY2LDF710KjZyAUd"
    "Dmd1ZDQDwiGUIChpus9cwPwrbiQoDiOmUhmqZmoV4yKqAtWbJ+MzLkIaDGCjTujAoW4FUe280Xa17y4skbEUXlLix32kFkgjUHhU"
    "CobXXPouZi59C0FhCCFb1tAGxR1uQi/jyDGp7PXf64b06to0cuqQmGr1fSJZW/3dYoxh1/q/hZJj2orlZN43n8AOMePgZSTyc7HW"
    "cfY7/56RfU+jx/JI5UdZvEXfon2fDULRaoQn3tfMv+YBzrlodWeyiKzGZXNP1oIXE0hhqIwVMTbg2LZ+Bg4/RvFPn2V4xhPkp23n"
    "4Bn3Yz2NLTtSs2ezcM0tmHKxIfW268t1NIJr+3Qzn7qe4wxQs9CUQqBZEG0c2Yxk2+4S254bIZkUmJIhNqOX07/xDrreMB9R8PF0"
    "F3Q5rAqQUhKMauZe+BbmrlxLMDpAOPdq0ddky24t8kVrPtXf6ySbuLjIklPR39WV70pJfvlShatuOcCxvMVzDjzJ7M/niJ/TixmM"
    "RjjtCDaOoYpJnIqQYtny2jU3k5qzMCxlLapwGHXVUWxvhclkr/2Oq5e+JivWOpia9s44UgnJkSHD2z95gH1HNamYwGjH7M/mSF50"
    "CnaoBAhUb5z8+j28tO6/CILhKH8KrIZYpovXrb0DZ00byV2DjO30n4rsjUYYb4CaBacQ/85hrEPEBMWyZc0tB9j5YplsShIUNbM+"
    "dTHp1fOwA6Wwk+kJ8j/Yw7HbH4MEYVmMSEhJUDTMXLKceX/0ASqjAyDVhNhtFXonKntTuZxogOr1yUPAOvA9gRWCtbf9mi07xujJ"
    "KirDFWbeehGZKxdgj0fK9yYobNzHkU9sBs8Ry87AT/U07SdVjXDWFdfRs2AFemykGR80jXAnmkT2caPfZABrIztNkkjCGu/wPcFH"
    "/uUgP9kySs80j/LxMjNuXk73NYuikXfIngRjjx7k8I39CKWwtsyc865g/0NfHzfpEiFK9H0WvetOpJ/AmurapavFf/vxDw00KYaJ"
    "8oBt6wGNMdeiOecwxpFNS2771lHu/u9hMtN9ykfH6P3wefRcuwQ7WALnkN1xSjuOcuj6hxBWURk7ztwVfZx1xYfY9+DXOLBlA36X"
    "xJkwHISU6DFDz1kLWfC2m9HF4XCq0hj/U8ECbWSvwWBck/c1I8HIgp1SCIDRmmdeKJFMKfTxMXre+3p6b3gjdqgM1iEyMSq/HOLQ"
    "dQ/iihAEQ8xYfClLr/0MThu8eJrnv3M7owcOoBKqBnGFUlRGDfNWv5uZb/hjgtFBmFAaWyvfkOI6y+8iXdt6QDs3iqxvbbgllkgp"
    "9LExsu88mxl/dwE2XwmVT/vogwUOfvBB7ECAcXm6572R86/7GkLFsFojvTjB6ADP3rcOopCqk8BZx6K1/0i8exY2CKtIxxJQ9Y4p"
    "hMB4PuOQYIMRmnSvKm+xxiA8iT5eouutZzLz9pXYsQC0RaR8zFCZQ9c9iH6pgFEl0jMXsOz6f8dLZrAVh5ASawO8VDdHd/yUF3/8"
    "DfwuVQ+FCBuk58zm7L7bIpQo6gm8A02KYaIc1wEJ2hqretKz0SyvrrwZLJHKncasT1+CCywEFpHwcGOaQx9+iMpzg5B0JLKncP71"
    "3yIxbSambBCyYfJkNX66hz0/+jQDu3fhpRTONofC3JWXc+rF1xDkjzegxPbqj5e9VRCMP87QjAShIePWMXOT8kNlEstmM+euVeH+"
    "fMVATOGc49DHNlHaehjZE8eWA5a857NkT59HUNQI1dhVxFtIrK6w69sfx5TK0fpI2GcNJfZ9gvTc10YLHuPGq1H9hkTX9tMElsYb"
    "oJZl3bjvDmssSIEZqRBf3MspX7wUkfRwJQ2+RPiSIx9/hGL/S6jeBC4wePEE8ewsTOT2LSTGWYOXyDC8dyu/+P5d+ElZn/OLECXG"
    "MxkWveufI/DUoRC2Cd/xIVDPFeMNUMukzd9dtP7tKgb/9C7mfOlS5LQ4rhiAJ5FJjyO3bGb0gRdQvQlM2RLuIjucCVqe4mjM1c4E"
    "+F297Nv4FQ4/9TP8tIogcQSQCoZZS5dxxmXXUckf6+AE9UowSR1o0lQ2P17N9vW/zjmQAlfUdF+zCP+MbsxwBaRAZmIcvfNx8hue"
    "R05LYCqWbFrV3JHWR1gawrUunFAeu+67mdLgENKvrvKAUJKgaFnwtpvofd3FmJJpw9c18WtfyZqz6YQQaESDTbhDgB2pIBIKlfZR"
    "0xMc/9xWhr+5E39GksKQ5s73zeDCxQlGx2yIYVqrXzNsrXpZg4wlKR7ey3Pr/wEVawgFBM5IvESas/7kxrZYqFHmtq1zCDQYYnzN"
    "tA6Z9hm+7zmGv7WLYP8IR+94jKGvPk18epKRgYCbrpnODX8xg/yYQYiqtTtR44iAMxq/axoHHl3Pr/q/T6yhNCLAGYeMxWm5XztB"
    "5nYeMPHRhh2gcFREdKMDhKuuRglQAjemOXLLZkRMISuGWHeMoWMB176jh3/9wCyCvKl10mnu3nSuqOG7swYv3sXuDbcwbeEyUrNO"
    "w1RsODGqLX62zyn1GV97co0DS7u5AHXs5SAaUcATyLSP9ARFz2NoQPOXb+/hyx+dQ6FokVTD88RGv1E64flU8sd45t6bgYkosbNm"
    "U+h33D0NSNDW+LSahwsR7hlIZwkCx6olCb73qdP42k1zCLTDugblq8HdUZTGWV7Dx2q8VA9Ht/8Pex+4pwklTqYaDbK3xgHNujYZ"
    "oKZ9TQHqikR/BRYpHOWy5iNrpvGOt3aTL9pw26s6OE1x2E7ahnhsFapG46d62PODTzGwe2cTSuzIc4Ls41qLEJm4IjRBKmhWxoFw"
    "jBYtJm+RYnxVqmf4zi7ZuWQJKbG6zM7/uDFCiZ3iu54FJrFAwz0TDFDlNTkTHEjpULJdTE6WjFzDPa2bMyFKHNr7BLu/92n8lGpa"
    "SmvdJ235tZOpaTbYiAPat87u3Zzh293TFFltajZYo4mle3nxJ1/m0JOP4Ke9GkpsyXQy2SMj/Ob7As7Vq1Lz09EGbXRfq5ua+prM"
    "20KHFcrjmXtvClGiN47nhNLYSe7q73WSNR5U/avj8Ie3GMeBowEiJggChzbhXqDWjoPHAzxPostjVEaOIn2B0wFWa4Ry6NIolULD"
    "JkhndwNrULEkhUN72HXfOryExDmNswZnNNIXlAZ/HZ01YBLZq8o7U1VFAtI5hxByKFS/c/2y1hFLCu7+4XH27y/TOytGNqNIT/f4"
    "6g8HeO7FMZJxgUWw94EvoMcqxHvixDI+XiK8VskfQyhvkjzR0KfR+F29HNhyP3t//J8kpvn4KUWiN07h4BH2P/x1VCzVPjyqakcd"
    "CiGHojCQAnIe9OvTzzrv3qGhkWu0DrQQouMZISmgWLLMPyXO+6+czuxej03bRrn3J4N4StROcevSKD1nLuO0S9aiYkkObX2Aw0/9"
    "KDwi07FCtKIQmlkdcNrFVzNj8UpKg4fZ99A3KR59AS+eZrJzQs457Xm+19uT/fa+X257N+Q8UT0/O3/RsusHjo98vlQqainkFA5J"
    "CUoViy7VQUCqS1V7CkWWCl0uYIMyEB6S8pPZSQVtb4OwH10cgajcqngK5ccnxwmAdVYnEimvd3r2hr3PPvmFXC7nedFrL2S6Mhvz"
    "w6O25FBTObZjrSPhC2Rc1XKLsc2j6qzBi6Ugnq5emZKgbSkyrJ/uabhkp87ToXxP2kxXZiOEr/w0HZQ8dd6SRweGhi9w1loh+D07"
    "KIkRUsread0/P/DijpUNByWBXE4650in0nclEnERvgkS1vTfjxYu5ycScZFOpj/nnIPoRavQAOEZerm277LvphPxx5XylJsspb6K"
    "KDws7al0Iv742r7LvgvISOfGaO9TsMGce+4l5x0+fuTxoaFhIVV0XH481ng1UF1mZ421PT3dbvb0WSu2b39kW1VXaEKCGwz0qe3b"
    "H9mW7Up/KJPNKKONqc2QJgdtv1stlNkZbUwmm1HZrvSHxis/zgCREXI57xe7t97dnc2sy2aznjEG56zpOM/+Xfw4a4wxZLNZrzub"
    "WfeL3VvvJpfzGpWHto4dgqMFi5b/9cjw8Bfyo4WY0dpIKaH6HsGJ4piXm6ITJ7jwpSnleSrTla5kuzPX73l261erOrV8rDWFrnLO"
    "Gy5aPjyUv6tQKF48ViqFO0QCHR6DZ8JqwG+fXLT84HAOTypFMpEgnU79rLsn87Fn/u/RJ8a7fSNNInz4oBCCsxevWJvPj1xXKpXf"
    "FGgjtNZYZ6sTqZOv1xRJCBG9OOnhe8olEvHNmUz2y7t3Pb4+xPvtlYep5XZJw47i68+74NzRfPkPdFA5Xxt7JtZ2O4H32zZBNOs2"
    "UopBT6kXYn7sqVSi6+GdO3+2vZ3svyG1f3lavkKt3cvTkawvG8nwhaOcR6sltd8+Sch50UtQJyzP/wMYZ4gEZ/palAAAAABJRU5E"
    "rkJggolQTkcNChoKAAAADUlIRFIAAACAAAAAgAgGAAAAwz5hywAAJitJREFUeJztfXmcZUV1//dU3fv2fq/36VnYZusRmBFEhkWS"
    "BvxhjCII2gISo7+EYJQYoqJCElnEBJWYjyaoUSE/Y1SMTXAJ0QQ+A3TUD8s4yjYbMMAMA9PT0+vrfuu9Vef3x733Ld33db/3+vbM"
    "EPv7mer3pvveuqfqnDp16pxTdYElLGEJv72gw/68/n7RNzxcem53dzcDwMBhJuRoQD+A4Yq+GOzuZgwMaAB85KgKHDeJvr4+Azfd"
    "JI40Ja8duH2Gxe+zxdIA1N/fLwZmSPPr+y5upWJ4nTD4JNY4AeDlYKQYiBEgF4mWoxPEGkwZEI8IyANa8HNQeo827eefHPzxROWV"
    "fn0ZGBlB1+cSq7xfnHJO/4kS4q2K9QWs1BsU627WBKU1lFLQWoOZwfy/SevVA4IQBCElpBCQUoCIIUkMSyl/zYT7YVn/9ZvHfrTT"
    "u6O/v18GLQiBCYBLnAKA3t6zW2Kdy/tB9D7bUufYShuFQhGFfB6WbbHWWnMVx+lw2yJHCcp9QEQkhBCGYVIkEkE4HIYhYBuG8QsQ"
    "/2thfOQHO3YMTgPVfb1QBNHxpVG/bNMF8RWJ1g8y9J/Ztj4hk80hm83Atm3baSIJIvpt5fa8YADsQAPMpmEa0VgM8VgUhiFfIPAd"
    "Q4XC1w9suy8blDZYEC8qJfGUsy55Nwl5a9FSG9LpNHLZnGIwhBBi7hH+26b6Z2IuFjBrrTWBEI1FZTKZhGnKXdDq00888sN7gIVr"
    "g6YFoK+vzxgcHLTXn3ZhZzwS/pJSfOXkZBrTmYxNIEGClqz+AMGaNcA6Ho8bqdYkDCG+M53Pf/TZbfeNeLxopt6mBMB74KYz3nmO"
    "lMa/5PLF1aNjo0prTc6IX8JiQWuthRDc0d4ho5HQC1rrP3zy0Xt/2awQNCwA3oNOOfOd72cS35ycnDLTU1O2FNJwamNHqxO52v23"
    "XcUvFORwidnlltOvSis72dJipFItFjFf9cSjP/x2M0LQkAB4D3j9me/8BEh+4dDICOfzBZZSCvzWLeOOMIiglNKRSJi6OjuJoD/x"
    "xCM//LtGhaBudV1W+xddDyG/cPDgsCrkC1hi/hECM6SUopAv4ODBYcUkbt90xkXXDw4O2o4XsT7UpQE85m888+KrpDC+OTR00LYs"
    "WwopaEnDH2EQoJVm0zRUT88yQ2n7T55+9Md31qsJ5hUAb5mxcfPFvyMkPXzo0BgXCkUhhCBe4v5RAQJBa83hcEh3dbWTVnzu04//"
    "+Of1LBHnEwAB3ITTTtvWbpvGkxPpqRVT6WktpRRLzD+6QHBsgpZkQrSlWl7JFu1Tnt122hhwCwDoWvfNaQP09/cTcIu2Tfm1fMFa"
    "MZWesqUUDvMZS+UoKgyGlEJMpafsXN5eGTXl14BbtMPD2qj5R099vP7Miy7RLO49MDRkg2E4y7ul0X9UwuUNEeyenh5DCL7kyUd+"
    "/KO5poJaAkAA6Mwz+8M5FJ4Zn5g+YXp6mpecPK8NaK11IpGgtlTixVEKn7z/0YECyvqiCr4M7evrkwB0nqyrLZtXT09PqyXmv3Yg"
    "hBDT09PKUry6kwpXA9AuT2fBTwMQAGzadEEM0ciusfH0ymw2547+JdX/2gBBa61jsSi1tyVfQS6/4amnHsi6f6xi4qxR7UoKy3js"
    "Ulvxqmw2q4UgUXLxLpWjv4AhBIlsNqtthVUyHrsUAPtpgVkCMDg4qAFAa/0nmUyulLbBS/x/7ZQKnmUyWdZaXwUAg+eeO2s5OGMK"
    "uEkAt+iNZ1/Uq4vqmeFDo1JrTQTC0rr/tQWPZ0II7u7qUALy5Kd/9ZPdHo+966o0QF/fwwIAJNM7bJsN27bVEvNfm2AwCATbtpWt"
    "2JAmXQiUeeyh6j+Dg+d66v+CfCEPgL2Y7qKBCBACkML5bDpfjAgkBEhI0NGai1KiUbg0LnZyHANgyufz0Fq/BSjzuETSjO+8efNb"
    "kxkt9oyOTnQWLYudFL7FEQIpCJbNyBUZWgOCgEiIEDIJWrMzl82ZMQWABIgI2ipA20UwM0hKyFAERBLMgeROLhAO47VdhLaKYNYg"
    "EhBmGMIwwXqx9oIQmJlDpkkdHa0jcaHXPP74f6Xh8hoAymHD/n6BgQFVlEavtnWnZVtMXvcHTJs3ysfSGsvaBN643kRHkjA5zdj5"
    "so39hzSScYIkQM/xbBIC2irCtgqIdR+HWPfxkKEoCpMHMbV/N1RxEkY06XbwEQIRwBrWdBrhth7EV6+FEW2BNT2OzIHnUUyPwIgl"
    "4SR6BN3Rzj8nExudRdPoBbDV4zVQIQB9w8M0CIAgN2hW0EorIYURNPfJZWrRYlzXH8PVb4vhmE4JwwCUAobGFf51Sx63D2RgKYYh"
    "ybdfSAioYg6hZDd6L7wWnSefByMed+q3gcyru/HS/Xdi+Dc/hRFpAfgICAERWNkgIbHm4o9j+RnvRCjZCZIAKyA/fgD7/+du7B/8"
    "NoQ0ARIBCwF74WKlmQ1ScgOArR6vgUoN4EJrvVYpXTb8uPQjADjpAwWL8bWPJPG+C2OwphkFi5EvAiCgMyVw/fsTOHWNgSs/NwGl"
    "HfuAK+cDElDFPCLtK/H6D9+JxIoVsLKAKminzURIrOrFpg/ejufuOQZ7H/gazFgrWFdOB4ts2BKBtQIJiZP/+B/RfeoZsDKAthhc"
    "ZBARwq3LseHyjyGxfAN23X0DhBkOljZXhzMYSmnokF4z85LZ1hJjhVJ2eVHpisJCCwBICUxOa3z4whje9/YYJkc0ChaXDEFBgG0D"
    "E4c0fu+cCP76vQlMZTUEeaR5QqkBAnqv+FvEl69AYdKCEwRxDCwQQRU07IzC2kv+HJ0b/w+s7ARISLeWYNo0V1tBAio/jRPe/hfo"
    "PvUM5MctsOKSIQgisM3IT1hY+btvw6rf/UPY2bTTEYHRwaX/KKXArFfWFABvly6z7tRKOwvJgBeARYuxrE3gmnfEUMxoSIkScz0Q"
    "AaYB5CY1/u9bYthwjESuoMurA0Gw89PoOPFcdGw4Bda0gjBMzLQWSQgwCFox1r/nRoRTy6CtvKNmFx0EXcwj1rMWK856N4pTGsIw"
    "Zi9xiCCEhJ3TWHXuBxBKdoFta1ZbmkVJCAjQSgGgDqDMa6BCALzt2UwcdTemlGsJoAgCcgXGxhMMHNMtUbRmM98DEWArIJUkbO41"
    "kStyxbUE1jba1p0J0NziSSSgixqxri6se9enoax8mQmLqQKEgLJySB5/Csx4CKwrpq9ZRApomxBp70Bi5QYoK1fOqA5KHTETswaD"
    "o0D1VvzycBg40RUYEqX7guwpApRmdKUEhMS8to4z5RO6WkX1SsBV9WZLR+1OrQAJCSuj0LP5zVh+9uWwpsdKU8HiFYfOUEtnfWm3"
    "rEGSYSbaK1YswdBSxUt2qfF4jUrybkL5Uq66LSA0UVfVOrRMV6M1EQmogsa6S65DfPl6qELGmYcXC1w5/OoFoWJ5HiQx7oc/TXP0"
    "Ai8C/5vpmOZuqQIRtA2YiTh6L/uMK0tBd/QMlNrb8E2LT8dN5a9lAbhlrhqCmoyapL+qhubqIyFgZxU6TnoDjrvgT2FNjy/iVLBQ"
    "VgY8Hc2BGhrAdcN6WiAQOrg5zQh3JnNvLtmmWoOVDdYKrJ3P0jWkwaQBqnb+OEKgccLbPoi2dWfAzqXhGCSlBwXW1qZFgCv6Kch+"
    "r6SnYrD7CEB1py2KHC50lcMMI5pAKGkglAghlDBgxiVEiECaYFgChiUg7JnNI8eFYBjovfxWyHAcrGxnTR6grDfD+pldsjh0zP7N"
    "HFuIeMbnQuEZOI3WN+N61oCQGH7qAaT3P4Xi5BjMlg4kVqxHqnsjcCwwnXoGWhYRyRyDxPiJzpNLTkQBlVNIHb8aq9/xCez+/l86"
    "KwrV1O7qYMGVX4Lud3/MFgAGqtKAgkKzdXH5Xq1s2HYRrBl7t9wFbRfdeDLAWYUVn/h9JC/qhVUccx0+jMTEyVjxwuUgFS7triUp"
    "UcwoHHveZRjb9XOMPHU/jFgrWAckBMzl0mhjgzZOZ6Z0zcBhC5xzxc+676noD7uYh1XIuf58hhFJIJTsRKi1E4aVQNeH34SWa9ZA"
    "5/IwVAsMOw7DbsFU+5M4tOp+CE0zHEcCrBm977kRoVQ3tJ3H0XB4TcDsn7feOZeBZaYFNBs10DpmZxCHQwAXclDuXF3yDLBj5KlD"
    "02i5bC06PnEaeEoDoJIRyKRh2AlMtz4DO5QDaVEigoigihqx7m6sf9dNUIVchav2cFsAM7snOGtkvoHnIwDuzYzyZ2DWSH2doxkw"
    "TaCYZzz6zBSk9AnlGgJqLI/ERWvQdfNZ0BnLqb9qEDv0aypAGblZj/e8hMvPvAAr33QFip6XcMFtXYggBNjnlTwEw2+L4CwBWLyo"
    "+Xyy6F7l8jAWEbj69iE88FgG8ZiEqiTMENDjecTPPwbLbvsdcFE7UjNLgxMYCia3wii2gIXzu6orPC/hpZ9EYnkvVCFTisgtBM3r"
    "gcML/5ZyWXkEqQIcQWTUWgcyHD7GEwIfveMg/uU/J5BKSaiKYAAZAnoij+gZy7Hsi+c69dnaN7JEmsBhG9E962Ao0/ENzLrI8RKG"
    "WhLovfyzjgFccjk32damFcACn1uz37msCGbAVwAqk0GC1ETzQSmgJSVx67dG8KXvjyHZasBWFTcaAmqygPDJnej58nmgkABb/sxn"
    "W0N0RJD+t+dw4O9+BoqhpnojIWBlFLpOPg3HX/AhWJkxkJRVC9fGutzrxSakoCLeEWS/16JlHl0XpCKbe1jYipFsk7hjYAw33jmC"
    "lpSErmS+JPBUEaHVKSy/480QyRA4r/xjyraGbI9g6r7nMXrrNky+8iSK0wU4u9v8aSApYGUVVl/4YbSuPdNNzmj2+OIg+22h4Brf"
    "HcwWAC8cWbV+DKD4Px8AYNuMZKuB7/1sEtf+w0EkEqJ62SoJnLUhe+Lo+eqbIZfFwFkbkP7MF20RZAf3Y/hT/wMRCcEupFGcGgXN"
    "yU8Ca4IwDLzuis9ChGNOPl+pL+pva9Ps99ocVJ/P9Of4EFYzFhA02OcbUGb+z345hT/6/AFEwqJ0KhoAh/l5BZEKY/lXzkfouBR4"
    "yvJlPtsaojWM3K+GMPTRhwENkCHBtg2tLJSOsasBEgJ2TiF1wlqsveiTsLOTZS3QcJc004dza8mFoZEpYJ55o3kCZjBfMZJJiV8+"
    "mcUVn3kVRE7eYMnmEwQuKlBYoucfzkP4xA6odAEw/EY+QybDKOwYxdCfPwQuOPexUhChKIxQwrUB5nb2lLyE578XXaf+PqzMOEg2"
    "OBVUBhaOMKqTe2ejjnyAgMyRGQTYitESl3h6TwHvvvEV5ArsbgjxKCPHugeh5+/PRfT0HuiJAsjwIVkxqMVEce8khq550LkuIgEN"
    "aLuIaMcqRDo6oG1d59Yjx0u44bJb3FzCgnuf14h5Ta/mEWSfV/GwVksPI0rdpxiJqMDLwxYu+etXcGhCIRIR5bW+u3mALY1lnzsH"
    "sXNXQY/ngVrMjxlQw1kMXbMF9lAGFDMAxQAJsLKROnYT8qOvggxRVyJIlZew/xaoYq7CTVwfg7lpYTi8aqN2PoD7GRycDlGKQWHC"
    "xLTGpZ9+BXteLSIRE1Cexe/O0zpjoeuWs5C4cA3UWA3mawZFJHS6iAPXbEFxzySoJeQwHwBrG0a0BavedDl23n0T8qMHIE3UJwSu"
    "l3DFmW/Byjdd6XoJ6z1/sbl+WxzWz81LX1dwyRJFwMaoBsIhQlEB/Te/gm278kglZPVanwg6XUTnDZuRvGwD9FjeX+1rBpkCXFQY"
    "uvYhFJ4ZhUyF3WkDENJEcXoMx/zu+9HeexKm9+/A7oGbIQxCvf5Oz0u4/l2fQmKF6yUkUVdbm0OwfV6ipbQyqcMV7E/UwgszIIhh"
    "2YwP/s0BDG7NoDU1g/mSoCcKaL/2DWj945Ohx/L+Sz3NjkYgwsGP/w9yjx2AaA2DXeaTNFDMjKF9/dnofdfHYGUVzJYODG39MV4e"
    "vBehuGMczosKL+GGy//WGRrs7VFYJBsgyPm/DlpmCYCz5OWK/wQDpRktMYH7HknjO1vSaGmVsOwZzB/Lo/WqjWj/yKnQ4wV/5jMA"
    "QaCQwMEbfo7Mg/sg2iKlkU9Cws5NId69Fm/48NchzIizI4edEPJz934W6X17ISOyrk2jJS/hxjfi+Ldc46wK5nEQcbOqYMEaxJeY"
    "0qdfc+deBQQMrWxYlkY0RFW5/mQI6LE8kldsQOenTodOF/2tdfceETdx6OZHMP2TPZDt1cx3Nox24Y3XfgvRzh5nv6AQYNYgw4SV"
    "m8TO7/0lWGs4OyDqsAdcL+GaC69B67ozYWXT8wpB6d66rlps1G7jnFNA2XhYuBrS7hvCvN3BJfiGdeHfc8wQyRBGPr8V6bt3QbRH"
    "ymqfBLRVgAxF8cY/+xZajlkNO2uDZLmJrGyYsRRGdw7ixZ9+HWZcglU99kCFl/C9t0GGY2BlVfTS7PYubBUQXJmPAv98gJIflgOZ"
    "fhzm+8y5blg3Nm9YF4BiiLYwxv7xN5i482mI9kjJ2gcJaDed69QP3Yn23o2wphVI+mS8KQUz3oYXfvYljO54Ekas/qnAzim0rl6L"
    "tRdfX60FZrW7We3J5Y/ATACPh/4Cueh+AK21L/OdsG4B0TOWo+eLfZgrrAvFEO0RTNz1DMa+/GuI1nBZjbgHMGirgE1XfQXLTj0b"
    "xSm7pveOoUHu1u2dd98AO5d3vL31LA2lRHFa4bg3X4llp75tXnsg+Ek0eNQIB1cqj2bUjjOKWWt3V+oMeGHdkzrcsK6cO6zbHkH6"
    "+7swctvjEMlQhYYi5yCk3BRO/oPbsepNb0UxbfuO/BJdDLBWMCIJpPc+hefuvR1G1LER6gM5XsIrbkW4tafkJayO4aOCxgbBjff3"
    "fGp4rsD03MEgbi41geAwX/kxvyKs23PH+XWFdaf/Yw8O3fwIRNysIo+EQDEzht7+m3D8Wy5zR34NZ00lbwCwsmDG27Dv4btwYOvD"
    "jj3gN03NAJFwvITLutHb/xmoYtbZ81/5iKZN+eDPLahwBvg+MfApwInkcW3me2Hdr7wZRk+8ZliX3bBu5qGXcfD6X4BM9wSJEvMN"
    "FKZGsObtH8X6iz/oML9uT125O4QRwq7v/xVyo2MQZp2uYiFhTSusOOv3sPKc9zk7jmsJ3lGO2vkATU0B8zDfC+vecT5Cx9cO68LW"
    "kK1h5B4/gIMfG3TSuQ1RmvdJSBSnDuG48/4IJ15+PayMAs0d7Pell7WCMCPIje7F7n+7GdJs3EvY++4bkFjRCzufcY9+m9lvDcAz"
    "2gKeAqqmpRmoEQ5250p3zqz/OTWYPzOse1IH9BxhXZEKo7B9FEPXPuTcZ5ZjxEQCdn4Kyzdfio0fuA12XjvNqDOnv6qPAWdpGG/H"
    "gcf/HfsevqcpL+Hr3vs5oHSohnMOUpN+oPKXgEqZh/52wGxPYON0l27Uvq6myrBuXymsWyuyJ1pMFF+YxIFrHoSeLLph3QqqXAt+"
    "1dnvgTDJWcfXwfy52sVaQUZa8Oy/fwbpl5vwEm46Hce/9SMoZioPn3htoMa+APezbpWE0mvgq1AV1v0dxM49Zt6wrjWUwdA1W6AO"
    "VoR1Z0BK6Zz3o7nuke80ieFrZbOGkCbs7AR2fvcGgBv0EmYU1r7jI2hfdxbs7KQ7HTUpBEGvAko8BBoIBjVGPDP7MN9pjM5a6Lrl"
    "bCQuXD1vWFdNFjH0Zw+i+NIkqMX0Zb7wPHtEjTF/njaxtmHEUhjZ/hBeaNZL+Aefc7yE2kZzTuDF1Bz+dc/hB3C+1Tf1+1ROBJ2x"
    "0Hn9ZiQv650nrCvBBYWD1z6IwvZRyGQYsH2YL0RFkmaD4Oqvvu1QNsx4K/b85xcxuuOpJryE67D2nX8FKzvpHkHTOJ0Bj39U8tAP"
    "tXMCKyOCNUopR2YmQ6QT0299/0lou2rj/GFdMIY+Nojc40PVYd2KQS4Eue9Ean6UlLrCL5PXLeRmEe347idh53INewmPv+APsOzU"
    "t7tewmaWhmWjLbhEDG8qmA2/gyJR82o/cv1Uv6VhdEfR+oGToKctfzFjOGFdU+Dg9T9H9uGXISvDuuSsSAtFdplPC2J+vdAlL+ET"
    "ePbeLzTuJVSM173X8xLmmwwHLkY7654CuMZ3vzr9VT8XFMzjU5DtEcfFO3Oudm8rhXXve8G5toL5tmJEQoRT10Vg287IpZkVNARv"
    "ZM1/pVY2zEQ79j14Jw5sfahhL2F8WRc2vOdWqGK+QRJrj9TmUVGhz8nbc28PL2kD/+LNMbNrJeic7R6Q6EOPF9b9wlakvz8jrOuW"
    "fEbjq3+xDBednUAuq53zgj260LgZUKa1LqvGodEIYefdNzTsJSxOM1aefRlWvukK2Dk0eCRdBQ0BlDIP/bFAV7BPxa5FX3xuAsWd"
    "o46vv6ic5aCbmSPaIxi74zeY+OaMsC4AIQlTaYXPXN2Fyy5tw9iUOiK5y8za8RKO7MWuu29syEvoHHAokDr+RPeQ8qMjLcQPtT2B"
    "zpfmaiUClMLIbY/DHsrA6I5BJEzIVBgiFcb4V5/E2Jd/Ux3WBWBIQnrCxnVXduDTf9gJPancndqeaqwwkBpFE/ewtmHG2/Dq4/dg"
    "30MD9XsJXWiryakq0HmgwhD0gY+Z6rM3sCbcNxLMfNeBZlDURH7HKF658qdIXtaL0Lo2qPE8Mv/9EjKD+yFazKo5z5CEyQkbf3xR"
    "K27/cDcm0wqplFGxm2umUDbXueUj5+aDE99jrWFEWrD7npvRtm4zEsuPg13Q9an1hRw5E5TBW8Wc2XXWXKfU180MYq+rZjRWM0TM"
    "hH0wi9HPb3VSuJUT8xeJUNXINw3CxLiNS89L4p8+3oNs1hVCqnyS+2PBR8zVKzpui1hDGCas7AS2f+dT2Hzd9yq8hMGr9tIKLqD6"
    "Kvcz+U1gvieE8DxqoxLeFeR3crdmUEhCtoVBcRMiFfZn/oTC+afH8e2/Wg7b5moP74zRX9PwrAPNGI4MlHMJt2/Bnv/8pwa8hI0+"
    "b6YxGkSllabzbNTwAzT4DHjWu5/V7xp/mh1jz2W+EC7zx2yctSmKH9yyEqYk2PbM3JAF2iNV9TTXuSUhiLdhz323N5RLeFTBb8E2"
    "/9V1LjcAgNhfCCrgvR0km2dH7Z+fxH/ctgrJqHCdPj5U8IzfLHiANLGcAjvp5crG9u9c15CXsCGyFkCjf5lVcRWCywfwJi5iEPxf"
    "g0bkvDUkk2NsWh3GnTcsx8AtK5CIOMyXNcWxmp7mjl6Z8b2JwkpBRhOYfOkJ7P73zzXoJayXSO9hzdNZXY1Xl3+fBZ/H5D6HSiPH"
    "0edCALk8Y/OGCD7/p904ZU0EiYRAZlqX/l5XxQsmbmH1sLIRSrRj75ZvoPN156Ln9POcjKSmj5M5slj08wEIGgQNQQzbUli7ysQ5"
    "ZyTADEylVWNR3dnzQQOoGFULGlJOEUYIO773SeRGRyHNAF/3FgSNMzVJY1NA5SgJqFEVVRUthso4o176RQjroafGJoc6Hh+MHmEN"
    "aUaRHdmLnd/7tJOZFNgJiwvXUrPr8z4b2B1ceVsQxQMR5pjr62vGQrsniLawthGKt+HVx36AvQ/9AKFEY17CxaRvFq1zPMvXBnC0"
    "RuVoCwo8NzVz3FZNT3OVVOUDLABc2gSgYUSS2D1wI9rXbUZi+fH1ewlr0VjiWkD97noCa9U2T0pYkMyfWXcz9ywGPU3Ak0Xt7jjO"
    "jGP7v37C2YFcZy7h3JUv1hQwG/5vDFmsfl4I75u9v/LeoPsWcL2ErTj0zBY8f99XF+YlXPRxN7viBeUDNFJ4luputJUVbuCmneVB"
    "zq7loj0v4X98HiM7nnATSBoXAp71vyD6vVyzX5fV2BdwlKhaAPWbM/XUs1hg51W1SmH7tz8GK5tzTiVdwB7B4FHvFFAluEET0mR9"
    "R5M81gDrCi/hwN/CjAowN7oqWIQ5qrI+n6r9TwmbaXUHkp3q1Fc++r0+7095q6JHj0djPSq23AZvCirlAyxC8byEL235Ol59/EGY"
    "caOuXMIyuRVtCjgruJYyqhCAHQ5HiPSivMCUnacNT9hQ7ivj5wIBgGYMjdvOWQNeJeSMtmJ62A1Bz0Epuwmm+WlYmQnU9dLihYAd"
    "ARNGCDu+c13JSzhvLiEJaAUU0iPuMXTB0sjwvK1exTtKvV8WgP7StwwJLw8nwP3qzIiEBJ7ek8PLw5ZzLGyNdjIAwyBMphUe25mB"
    "ESZozaV6SEiM7voFWBNK74Pzq4c1ZIiR3vcU8uOvQMgQvDXxohWtIUNRZEdewo7v/iWEScBcUwFrCIORGz2EqZefgQxFAdaB0eMN"
    "HeekU84AqOR1WQD6hoddDYCR0rn6JQYtnBTNQMgERsdsfOVHowi1SCjFs4SAGbAsRrTVwP/7r3Hs2VdArHSqGANawYi04NDTD2Bk"
    "528QSkpo20IFsW6/KufNcSC8+N9fgdu2IEW6dluVhVC8Ha8++gO8tOVuhFOG84q7GSOb2Tk+JxQX2Lvl6yhMHgRJs2LFtHD2u6PG"
    "eVcC0UgVr+FjAxBoSFZ4soJLenKOiY23CHz5nkP41r0jSHWaCLuaQGlnvjcNQmu3iZ89PIkb7zqAaMw7Q9iTZ3Z3CGs8fdeHMPXK"
    "PkRazdLvWDvbtI2IhBmT2PG9v8Ghpx+AEW1pbD5eaGu1ghFNYtf3b8DQtl8i2h4CSY9GBWaGNASibSZe2vIjvPjfX4URS5VeixcE"
    "KnknhQCBh2Ze45MRxM9KQ5ZGS2M5AXMXT7ANg3DV7fvx8b/fj5cPWYiGCS1xgXhUYHjCxme/cQD9N76Eou3kCDBX0+Cp2cyhF/Ho"
    "bRdj70MD0MVpGFEBIyZABiG9bzu2fulq7PnZ38P0OnbxB39FW52pSiuFbf94JXbdcweszCiMiIAZk5AhQm5sP57655vw1F0fgjC8"
    "428C7G+PfwRIQwJMz84hJP0SGFDrTzrrdMu2Hz94cNgJ5i+CRegZgJlphfY2A69fE0VbUmIqq/D0njyGhi1EEwLCfaevP9wOtgpQ"
    "xTziy9cisXwdhBFCYWII6X3bYRemXeYfqdQtBkgAWsHKTSHWeSySx54EI5pEIX0I6Ze3ozBxEGY8Bde6RaCJph7vCLxsWTeZhrH5"
    "2e2PbPV47V1SdfnazZuTPIU9I4dGO4vFIhNVHMwTMKQkWBYjX3DPBxSEcIgQCgloVWfeD5G7JStXmmdJGpChKEjUt6Vr8UEg4Rxk"
    "qaw8nPMHJIQZhTDMRaSRwKw5FApRZ1fHCFlY8/zzj6dRkSw8U9wEAL3+xDPvn5hMX5BOp5UQi5vq4iSEVJyyNceadb6KnDN6vCnj"
    "KEzYrKTRmxMXc1kKQGutksmkbE0l7392x6O/B5fH3t+rbIC+vj7Hbia6PxIJo5IVizVdOgYgw9YMpZ1VQVN1MUNr50RSDnAZFWip"
    "pNE9UWWxnlXmG3MkEgEJur+Sxx58NUBv7xt7LeCZg8OHpFaaqHQQ4hJeKyA42+mFFLysu0uZwMm7d/9qN+bSAO4fxO7dv9ptSPlI"
    "LBqD1q75fMSHz1JpTAUwtNYqFo3BkPIRP+YDPstAT0VIgW/E47Hyq3KO3g2uS5gJl1dEQDweIwh8A5it/isunf275aedFk1kxM6R"
    "sfFjcrkcE4nSDv0lHO0gMGsdjUaps6Pt5ekJ/boDB7bl3D9WMdH38Ja+vj55YNu2rDTk7alkkpir/MJLOOrBYGZOJZMkSd5+4MC2"
    "bF9fn+/ZdbUUOwGg447rC4Vj2adHxyfWTE9nWIgA3qu+hEWH1lonEnHqaG99vpCJbdq7d7CI2QsEALVTwhjop717B/NE4uOtqRQJ"
    "IXQpTLlI8fSlssACOJa/ELo1lSKCuG7v3sE80F/TnzvHiB5Q/f39cveOx35iSDHQ0d5uaK3sCglZKkdR8aC1sjva2w0hxcDuHY/9"
    "pL+/7Pb1w3y2vQCA9etPa4eUT4yNT6xMT6W1lFKAa4jUEg47yP2hlNLJlqRob0vtF4xTdu3aOu5eUtMtOt+croF+evbZbSMM+4rW"
    "1pSKRCKsSnldR1rul4o3DJXSHIlEuLU1pdhW7921a+uoq/rn9InXYdQNKPT1Gc/t/PXPQfqD3V1dMmQaSmvNtOQcOOIgELTWHAoZ"
    "qrurS4L56uee+/XP0ddnzKX6PdRn1Q8O2n19fcbzO7fdBejre3p6DNM0lNKqnJC1NB8cPrh9TQCUVmyahupZ1mOA9Kee3/2rf+7r"
    "6zMwOGjPWQfKddSNvr4+Y3Bw0F674bTrAXHb8KFhncvl4dkES1JwuEClOT8ajaC7q1sA+vrnd237vMejBmpqDN4D1mw47Spi+qfx"
    "iQmZnpqyhRAGLUY68RKq4Z76prW2ky0tRltrq2LmP93z7LY7G2W+W13jKAlB72nnCRLfyuZyx46NjSqlNC05ixYXWmstpeD29g4Z"
    "i0b3adYf2LN720PNMB9YQIjHe+AJJ5y8zIzEvmgr+8qJiUlMT0/bAESlICyFkptDpZGtnffx6EQiYbS2pmBI47tWPvvxF1985mCz"
    "zHeesSCUnQzrNpx+CYFvLRStkybTaWSzWcVgCBLCTfhZEoM6UX4PA1iz1gRCLBaTqWQS4ZC5nUGffm7X1h86V83t6Kn3WQukt18A"
    "A2rVqlXReMvyP9HMHykWrbXTmWlksznYtmUDREQkyMv/WkI1PM+KAw0wm4ZpRGMxJOJxhELm80LQP+Qzw9/cu3dv3mW8/3FsDSBA"
    "VpQlcdmyTfGW1tB7GPx+ZdvnWLYt8/k8CoUCLMtmR51VJcP9topERR8QCSmEaRgUDocRiURgGoaShvELAv3L1ETxBwcPPuXs7Fng"
    "qK9E0B1P6O8XGCgTt3r1xo0iHPp9VnyBZvV6rXSX0hrK1lBald42Vp19+L8Z5TNwiQSEEJBSwDAMSCEgJB0SQj5Jgh7QBeunL7zw"
    "1DOlW/v7JQYWPur9qAkaniBUEXvssRvbIpHwWjJova30egKWA0gxdIww76s//7eBAJoiwgiBhhj8nGL9nJ2z9+zb9/R41XU+ffla"
    "gujr6zNwmF/78BrHYeuzwz33EgCBvj7qc38xONjtSvXAYSblaEA/+vqcjZqDADA4yECNc3aXsIQlLCFw/H/jVtxabBIMawAAAABJ"
    "RU5ErkJggolQTkcNChoKAAAADUlIRFIAAAEAAAABAAgGAAAAXHKoZgAAUTxJREFUeJztvXmAJEWZ9/99IjLr7nO6G2RghnNmGGA4"
    "BkEQaGRfdUURDxq8j3V3XQ90XQFPGEfE6+eKB+u76x6uiueIK4ev16q0yiDHcDo9NwzH3EefdWVmxPP7I7Oqq3u6uzKr65zJj0Z3"
    "MV2VFRkZzxNPRDzPE0BISEhISEhISEhISEhISEhISEhISEhIyOEJNboCdYaKv1etwsDQEAHA3r17j7R2CAHQ19fHawBgzXIGVrP3"
    "zzzHRw47DueOT8AqGhgYor1791JfXx+vWbNGNbpSIc3OKtHff68APAUxqRwOS8VwuCkAMTAwQHv37qXBwUFnhr/T8uUDSZka77SV"
    "0WdGZBcrtAnINiYdJ6IoA0bdax1SN4ihGNohRl5D7Gaph1nxCNg5mE6kR54ZHMzN9Ln+/n7DG0QYgK5ztWvGYaAAXI09OHipBlZP"
    "eTBnX/C6xZZjnyGEOI1AKxhYQYQekGgXRAkhJEAEIrcZ6HBojpCysDeYMzNYa2jtaDClmfgAGNs1sIW13kzgDaY0/vLo/T99ZuoV"
    "Zu9zrUar9ngaGBgQnnlWfABnnPfaYwFcAMJlRHQBES+R0owLIQEAmpX3wN2ilNLMzMwAAwzmw9POC3FhwNX1BCImIQQECSGkICIB"
    "IQSEkMUBQWsFpewsgzaz5vsh8Fso/PnJB//n+eI1V60SA0NDtGbNGo0WnCa0mAJYJQYGhqh0Lr/87CtONuLmSwn0amh+sTTMNiHI"
    "E3AHjuMox1Fs2zY5SpFSmlwFwMQ8ORKEHHkQuTYfCWJBAkIQS0OyIQ02DAOGIcgwDCmlASEEtNZwlDMG5vu0UnflMtZvtq7/5bbC"
    "9QYGBuT0QanZaREFMFXwF53xyq72ZORyAt5EwGWmGYkBgKNsOLatLMthy7KFZduklCZmLgp50dz3RoKQI53CIOD9V0k/ISJIKThi"
    "GhyJRHQkYpBpmlJKEwzAtqwswL8Die+PpvO/ePbJnw8DraUImlwCpgr+shWvWGImon8D0FtNM3IMAVCOjbxlqVwuj7xlC8dRpLXb"
    "7u5DBGa+zXDUDykwmxgwmCeVghAChiE5GjF1LBZFNBopVQY7wfxdx7L/c8NjP98CtIYiaFYF4M3xXcE/7axXnklR40NCiKtNMxrX"
    "yoFl5VU2m0cubwnbdohZeyYdNe9dhbQ27kIRmN3BxTQNjkUjOh6PIhKJSiEN2LaV0ax/jLy69S+P3v0E4O4gDA4OKjThqNN0ouJq"
    "TW/Ef+Erlhgy9jFBeLNpREylbORyeSeTzclcLk9a66KpdgiM8ndXeBxN1wp1wk8bHa4EefaztFNhaimEQCwW5UQ8rmKxiCGlCcex"
    "LK34e3Yu//mNT/xiMzC1bzcLzfT4CQMDAmvWqEVnvLKrM2FeBxLXmhGzzbFt5HI5lU5nRd6yiBkQVDLSN51eDTkiKOl/mhlEQDQS"
    "4WQyrmOxmDQME7Ztj4P110cy9peeffLnwxgYkGiiHYOmUAClmnHF+Ve+HiS+aJqRE5VykMtm1Xg6I/J5mwBP8ENCmhTtrRdEoya3"
    "pRI6FotL6U4NnlLM169/4Gc/BZrHGmi0NBXn+qeff8VRgowvCSnfIgDk8nlnfCItc9k8MRiCBIAmUZshIbNQECjNGgRCLB7ltlRS"
    "xaJRQwNgpb7LmYnrnnjiN3s9JdBQa6CBCmCVKPhYr3jRlVcA4uumaS62bUulJzI0ns4IrTSEIK+aoeiHtBIFZyINIQXakgmdTCXY"
    "NCPStu1nNOF9f7n/f34OL2alUTsFjVEA7jxIARArzn/t54QUNxARcrmcMzo2buTzFoQQodiHtDyFPqy1RjQaRUd7yonFYgYzQyv1"
    "xSce+NnHAOhGTQnqrgC8LRHnzBe9ciHD/JZhRF6qHEtPpDMYG08LZoYgCgU/5LCCUFgoJLS3JXUqmYA0IsJx7F9Lod756Nq7dhZk"
    "o971qhuFGzzj/NesJEE/MaR5vGXlndHRMSOTzUEIUc/qhIQ0BK01EvEYOjvaHTMSNRxlb2fNVz35wM/W1VsJ1E0BFIX/vCuuFML4"
    "rpCyLZfLOSMjo4ZlO6HwhxxRaK0RMQ10dnY4sVjMUEqNA/rNT/z5zrvrqQTqogAKN7TivCvfRVL+BxGQzWb18PCY0JpBotGbESEh"
    "9YUAaM0QgtDV2a7jibhgBjtK/d36B+/8z3opgZpLXuFGTj//ig8bMvIlsNYT6QxGRscFUAjOCWf8IUciVIwz6Oxo06lkAiAhHNv+"
    "8F8euuvL9VACNbW7Czdw2nmvvt4wol8CKzU+kaaRkTF3c48wGYbVCI5kvXPYJrnySTPcu+c9SABGRsbE+ESawEoZkcg/n3Heq68f"
    "HBx0+vv7a5qhqmYWQHHkP++K9xtG5OvM2pmYSMvR0XGiwl03w0MICWk0niwwMzo62rgtlVQgYSgn//4nH7znX2ppCdREARQX/F74"
    "qjcJI/I9glYT6YwYGfGEPyQkZEaYGZ2d7ZxKxjVISOXYb3rywbt/UCslUPUpwMDAgBwcHHROPeeVF5M0vkVgnU5nKRT+kJDyEBFG"
    "RsYonckSmDUJ41vLV77qosHBQWdgYEBW/fuqe7lVAlitl7/4VYukIx+SUvblslm9/+CIKKTdDAkJKYebm7Knu1PH4nGhHLVXKfXC"
    "oXX3PFuQsWp9UzUlkjAwIJavh5Rt+XsNI3JBPpdR+w+MSK155pj9kJCQGWFmCEno6e5U0VhCOo51vxqPXjp0GlQ1w4mrNgXo7++X"
    "WLNGUSrzVcOIXOBYeWd4ZFwqL2nH5LJzWMISlnKFiKCUxvDIuHSsvGMYkQtEMncr1qxR/f39VZsKVEUBFOb9K86/4nWmEfsH7djO"
    "6PiEkbdsL36fq/E1ISFHEG5MTN6yMTo+YWjHdgzTfO+K8694XTXXA6pgl68SAHD2hY8e7Sg8JoVcMD4xgZGRcSG8mX8o/iEhwSnm"
    "FtCMzs423daWglJqv+3IszauW7HH/ev81gPmbQEMDAwRsFo7Dt9mGJHefD7HY2MTonTOT2EJS1gClwJEhLGxCZHP5dkwIn2GtG8D"
    "VmtX9ubHvC5QiGFecf4VrxPSvEMpxzlwYMSL5w9DekNCqgHBtQKisQgWdHU60jAMW9mvX//A3T+dbx6B+VgAtGb5cl65cqCDGV8B"
    "mNPpjMjl867wh9IfElIVmAEhCLlcHplMRgDMgnHryef9dfua5csZ8xjIK1YAAwMDAqtXa1tkbzDM6HFW3lIT42khqBDgwPBOVQhL"
    "WMIynwIv/TgRxibSwspbyjAjixJsfASrV+uBgYGK5bhCzeHm81tx3hXHM+gvQlDs4PAIZTI5IkEIbf+QkBpAAGtGIhHn7q4O1ppz"
    "efDpmx+8e3uleQUr0hze4gNr8E2GaSZyubzOZHKuq28o/CEhtYHdBcFMNke5XF4bppmIsr4RAFe6IBj8Q6tWCaxezadf8KqlQovH"
    "ARgHDg5TNpenQurukJCQ2qGZEY9FeUF3JwPsaMFn/uX+ezZh1SrC6mBWQGCJHRhyR38ofFQaRiSXy+tcKPwhIXVDECGXy1Mul9fS"
    "iERg46MA2JPNQAT8gBuIcOb5Vx6vtRoiIWIHDg4jm81TmNMvJKR+aK0Rj0d5QXcXWHNOCLH88Qfu3B40WCiQ1Pb33ysAQGn1d0Yk"
    "Es/nLZXLWeR6/HFYwhKWOhV3W9CivLsjEFeO+jtgUkb9EsQCIAC8vH8gJTKZTdIwjjl4YFinM7miy29ISEj90JqRTMT1ggVdwrGt"
    "HTqZXDY0uCbt/Zn9XMO3tihEIIl87nLDjBxjuaO/CMN8Q0IaAxEhm8uLfD6vjEh0oZnJXQ6Ag0QL+lYAl156qQYAdvQ7CcS5XA5K"
    "K4TyHxLSGIgArRVyuRwIxI7W7wAmZdXXNXy+TwDQS898+fFmxNxIRNH9+w9y3rKppc1/xjyjIVqYgoF4JN//YXDvWjOiEZN7erqJ"
    "mfO2ZS/b9PivtsOT2XKf92UB9Pf3CwAwDeNVphmJWpalLNsmUXD8adWCJqhDI+/9SL//RtehCkUQwbJtsixLmWYkahrGq4BJmS2H"
    "r5zjg4ODriYheh0zkMvloTVDSlcBcJnPh4SE1AYigBUjl8sjHk+CCa8FcFtRZst93sd7XPP/7P9zjGFEtwgSib37DrBdsABCQkIa"
    "imZGxDS5t3cBadYZpZ2TN6771S74mAaUNRMKpoQU0RcbRiRh27ZSjkPkHeEdlrCEpbGFiOA4Dtm2rQwjkhAwLgL8TQN87wIQ+KWC"
    "BCzLZq314bB+EhJyWOAmDNGwLJsFCTDwf/x+tqwCGBwcVKtWrRIgOl9rhbyVFwXNExIS0hwwgLxlCa0VBOFFq7BKDA4Ols0UVEYB"
    "rBIAeM09644lYIlSDmzbOexO+CECpAAM6f4ufV3/XU4CkQAJeWghgcNi76pezNaOQuJwcmApTANs2yalHBCw5CfnPrbQ/dOqOWV8"
    "zl2AgYEhWrMG0KxWmGYkls/ltVL6sFn7K8Qv5SxG3mIoPflv2nsdMQjxKEEQoKp2Hst02O2sJKCVBZXPg7V3DBwR3MwwAEkDMhID"
    "SRPMyv33UCEcAgkBZg1tZaEdC2DvYRYy7AgJYUYgjRgAgLlmD7ZuEAFKaXJsR0dj0Vjezq0A8FxBhmdjTgWwd+9eAgABnCGEhKMc"
    "zVoLEgKtPAkgcgV6PKPBDJyyUOL0402cukjiqC4BKQgHxjQ271D4y3YbG55VyFqMjqRw51tc3XsnYUDbOTj5LCIdveg8cSWSxyxF"
    "rOsYiEgC2skhP7wL48+tx/gzT8KeGIaMJSEME6wrzgd52EEkwGDYmVEII4bkMacgdcwyJI46CWayC9rOwZ44iMzepzH+/Hpk9z0L"
    "EGDEUq4SqPJzrS8E1hqOcnRcJISAPAPAzwsyPBtzKoC+vj4GAEE4FcywbQcMRsvm+2V3IFCaMZphvORME++5IoGLT49gQbsASj2o"
    "iQDNSGcY67bY+M9fZnHHn3IQBMSjBKUwv8HXG7yJBOz0MOILFmPhK9+I3rNehviCF0DM8GS0DaT3PIO96+7BjrVrYI3thZnoCJUA"
    "AyQllJUFGDj63FfjmIuuQfuiFTBi0p3oFrosAawAeyKD4S0P4Pl7v4PhLQ/AiCVAwgBr3aJGFbvKz3YtR0E4FZiU4dkod6sEgE8/"
    "9/IHpBE5b/++fSqTy8mWjP33hD9nMSIG4bN/k8LfvDwBwwRyWYbtWdSF6U3htRRAIkaAAH75YB7/9K/jeHqPQntiHkqgaLkTnOw4"
    "XvCiq3DSlR9CrLsLKg+wwzOapUQCwiTICJDevRNbfvYl7Hv0FzASHa6ZeyTOCBggIeHkxhHvWYwlA59AzxkXghWgLLgCPX3AIoIQ"
    "AjIKaAd4/o8/wlN3fxnsWBBmtGWVgNYaiXhc9fT0SMexH1j/8M9fBE+GZ/vMXLdJAHjFipcmVcTcIoR8wb59+9my7JZcBBQCyNuu"
    "Gf+dGzpw6coo0mPanevLuRtCedZhe5vA83sdvOGWEazb4qA96SmBSiCCyk3gxFffgBMufztUDtC2Agkx9wIVM1gryKgBksCWO76M"
    "Z3/7764S0K0/lw1KQfjbFp2JFX/3VcQW9MBOu5qZ5hyoGKw1iATMFOHghsfx5H98ACo3BjIjgG49K5eZEYmY3NfbQ0qrnQdZnLJr"
    "3T0ZzKEE5mohci8qu8DcyVpBtWgHI3LNfikI377eFf7RYe2O8GWEH5jcFRgd1zhmgcSPPtmJk46RyOQZFRlDQsLJjGHRS9+DE1/5"
    "dtgTCqwYJH2sThOBpAFla6icwpKBf8LCi98KJz3irm4fSRBBWVnEe4/Hir//OiKdPbAnlLfSX+7BUHE3wBqz0b3sTJz2zlsBIVvW"
    "AgBcK0C7ctrZY413l3v/7K20ahUAwCH0CiHjWmuw1tSKDSMEMJpmrH5rEi95oSv8pq8oiKmYEhjPMBb2SPzbB9pdP8ugI4UQcLKj"
    "6D6tHydd+X63w1KZUX8G3C1BASenccpVN6Dz5PPgZMe9bYzWG70qgVkDRDj1zV9AtKsbKqtcJRoQkiby4w56Tj8HJ15xnduO1ILt"
    "SJMKQBDFlUj2uH9YNWvnmlUBFBIMsoleISSU0pqLq6SNdn70X4RwV/v7z4jg716ZQHqsMuEvYEpgbILx4rMi+NvL4xhNM6Tw2yYA"
    "awdGrA0nvfp697+ZKt+TJgIrQEgDS675NGQ8BVaOd73Gt31NixBQ2XEsvPjN6Fp6Gpx0ZcJfQEgJe0Lh2IuvRtcp50Pl0p4SQOPv"
    "1WffIgDMTEorLYQkbeg+oJjGf+b7nu0Pk1uA1ENEYNbMzC1oADC0Bj742gRiUarKXr4QgJ1jvP+KBPo6CZbDvj+osuPoO+dydJxw"
    "kjtizXNBlYSAyim0Lz4eJ11xPZzceEnHPVwhsLIRae/BcZe+AyrPoHl7bLnH2cmIwHGXvctbhJ1z/azJ8AYYZrDWTESQGvOYAngQ"
    "uMM9kaT1dkmJgGyesfQ4iUtOjyCXLYzW80MQkLOAE44x8JIzo0jntL/rag2SEfSddTlYcdXmmSQl7LTCsZe8Hn1nvxJOesRd2Txc"
    "EQSVz6BryYWI9/RA21wVpUdCwMkzuk45H8mjToS2cy3nMcgANINBBCa0A5OD+UyUbTUGYgCgwUVl2Ghjx29xBZWx8hQTnR0Ctqre"
    "2g4DgAAuOcMsLr6XM9C0shDtegFSxy6HtsutUgeDIMCKseSqjyPWfQy0nQfcwJDDrhScXjpPOR9U1cgUAitGJBVF2+IzPQXQOm0I"
    "AGD3HEHvdpLl7ri8AtBsetsBpV/TMmgGli8ygCqfWOzmRweWHGsiFiFoLqNciKAdG/EFxyKSTII1o6pLzURQNiPe04OTX3+TqwAK"
    "f6retzQcAgCtIcwoEkedBNbzWEOZEQYEkDz6lJZyEabSV95UnRllzcDyUwDvyJ+C7BS6bSsUhruF19fh+oFXtZ+40yJ0pQjxiLvN"
    "iDnqAgBgDTPZDTLgKYDqQkLATiscfe6lWHjRm2Gnh0FCwvXebPzzqEYBAGYNGYl7XpA1UHAMRNoWuDst3Bpt51UbpYM0UfmMX4HX"
    "wwloncUAr56mSTUxXjQDhiTXvdiBqxRm+R7yGo7kPLYgfEAkoHIaJ135IYw89RAye7ZBRhKeu3DVRaX+EAAwCv4QNTFKGRCGicKI"
    "0Sr9vTRFp18C9MaCfiln6zYR9axnsWPO/pa69CMiaMUwkwksvXo1HrvtbcX98lacwh0KTTVHa0phLt0a7cYzvCpHZatQjV7tCLwy"
    "UgdKO2Uj6wF3KuBkFLpPPROLX/beSS/BRj+Laj/PWir40u9r9D3XsK8HVwB17swtRRO1DUlXCRz/8r9F19IXw8mMHR6uwjzL65CK"
    "2sOnAmjllm6mutezLgRmAkmJpdeshhFvAysbrbavfSiNMu1aDX/19qUAJi2hVm2M2sNlW4en/a497oKgQtuixTjp1TfAyU14MQSt"
    "DZf8rP33tBYcsHV89IbJDMAtOXbU6SlO2e5rXDUOYYqX4DmvKm4Ntmb3dqlXP2zFZVMfa9FT8LULwABcD6OCBdkqzeI1QzF3Xo3q"
    "zQXDdPbrU70t19LvLvESHNv+GOyJAyAjArSQo8skbj4qd2G+dg1asOiIW8vyZa9d3BqXf74V2IMt1Bh1G/7Lfw830nwq8RJcctWq"
    "KV6CIXPRSqI/nSquAbSS0JdSN5nz0zyHvIc9q0q7I7EvV+vK93wKXoJHnduPhZe8FXZ6GDMmHgw5omj9FaE5qM9ikd/re4LrCToJ"
    "CWEQZERAmAJkEEBukAtrVeKHzmDyzmZlAmkCeeZE4d/9UvASPPnKD6HtuNOh8hNovdDhcBegmgQcAry59OHdJpVRWCCZrW287Tcy"
    "IiBJcHJpKCsDlZsACQkj3gYj0Q4jLiEkoJXrXkwOQSqCMjRscwJaWJAqDsNOQioBJeFNVH3YO56XoJFwvQQf/fpbwKzRcss69a5r"
    "K7VNwMqWVwAzJb1sye2AGjN9q4Sn/rdWNiAM7N/wR9x/y9XIDe+Ck5uAtvNutt9IDJG2HiT7TkT74hVYsPxCtHWfCtWew0jf/Zjo"
    "HIJjjoFJQ2gTkXwPUsOno2PfCyFVBEpy0TKYs5qlXoIvfS+euudLMNt6gFbyEah3NVukWSrBnwXA0xywWiU6gut4goG3ZFwMxSYC"
    "M0M7DrRyoL3c/faB55De8xRImiAhiodZKDsHa2w/xp59Ajsf/ino+waO/fDrkXrnYuR5BwSiIO168inDQcZ8Gun2LRjteQhHPz2A"
    "eHohtPRnCRS8BE94xd9jePNajGx7yHUUaoXzBTwrq6bLc9OUeKv090K27uIGiY/HGWARsJD1onXCI+tnu/GUXwBBKQd2PgvHykEX"
    "jvkCIIwIjHgKwoy40WwkAJLesV9xmG1dMFQKC957LqJ/3wZbH4Ch2kDaLN4dsYDQURh2G6z4bjy37JvIpJ4DKfIZuFLqJfhp92Qc"
    "5YCIGv7cypaCgvVxl/OHi9/VCmUybHGGsxBmIcDx4C71jG2YTynUtz4dpfBlBDDgeMd8TUbhldTCzdmG4jl1JYuDLAB1II32ty7F"
    "guvOhchJkJbeYt/0B8pgUiAVAwsLu078IZSZhbsuWP7hF7wEO44/wfMSdHMJNvq5+Sn+7rB6NPp+g7ZNkD7vWwGw97OuAjUPJjtK"
    "7btK8bu0gm1loJ3g82kyCGo4h/aBpej52PnQ45Zrepa7DGkIFYMV34OR3gcgNIF9hq8WvASPu/Rq9J19OeyWOFtgenevx/e1Bm5X"
    "Cdbjg+0B1XNO3SK4VhdBawU7n/WENqCaNATUwTzaLj8BvasvBOcc98I+L+MuDEYw3vUklFQgDvJY3Tx4SwZuLOYSbImTn+rgWcXF"
    "H62BW99g7eK/p7RaaxSoYZULGYHACraVq+wihoAeziF+ybHo+9zFYEcDKqgSYZCWsKMHYEdHfU8DAAAkoGyNRG8vTnn9KjcRZkvY"
    "eS3YF+sCB2qasgqgFb3F64HWDDNKGB5XmJjIopK09GQQ9GgesXOPwtFf7gdJAhyNii4GARY2lJF2xTfAJUi4U4EXnHcZFl70FliH"
    "QcBQiD/KbgO6GqJRyy/NidJAIiawa5+N99y6C47DiMUo2NmckqDHbERP7cbRX70MIm6C806Fwg8ADGIB0kbhPwNBJKDyGie/9jqM"
    "bHsQmb1PQUTiaL6AoXpaJ63a5/2vkQTMBxCiNRAxCRM5jatu2onHt+YRr0D4OW3DWNSGo79+GWR31J33z+d0G9IQKg7D7qhsekwE"
    "7QBmKoGl19wMgJpQ+F3Cfjg7QWXV1xTgkL3XRu91BNoXqd4+gGb3NGEG402f3om1T2TR0SaDHTcmCZx1IHsTOPq2y2AckwKnHUDO"
    "Q/hZQFEO8YnFMK0EWDAqGSlJCDhphQWnnY3FL38f7PQoSBiNf4bTnmfdcnRy8Stbo6Bk+5v9Td99TAF0cUQpdqtWWCMCivWsRnUL"
    "i/uRKOFtn9mFX6ydQEeXAcfvuYCAezhJTkGkIjj6ay9B9JQu6FELMOZZQ1YwIil07ru42BEqpeAleKLnJTi69SHIeMo1fZrkuTPV"
    "aTuaAAI3NpQ7IMWMQARUJR/A1AVlnvzVAqVaHpzsjQTJhMAHvrIH3//VKDo6ZWDhh61BEYGjv3IpYmf2Qo/m5y/8CqB2gfyvJmDu"
    "6AVHAOj5XJPAmkCGgWXX3Fxy4jAa/jyL/bBKz7Us3nNv+D0HaZuSuvvhsM4KXOq9WCkMd/BLtQnc+O/78I07RtDeacAJ4jZPBCgN"
    "ZsZRX7wE8QuOgR7JA8Y8Q3EdDdEZQfbePXjuhh9hbNdjkCbAPD+ffhICKlvwEvwInOw4iJpkV6AJqtC0VNA2AWIBeNrr5i/s/Z6P"
    "+5JSQFunxK0/OIjPfGc/2jsEtApwPQLADM4r9H7mIqReuhhqOFcl4Y8i+8Au7Lnhj9BWHgc2/qFq4f0FL8FFl15dkkvQQKOf6SS1"
    "1gSt2ecPrfvctFo2iIqotKs4itHeKfGtu4bx4W/sRSoloTnA9TwTRGds9Nz4IrS/9mSo4TxonsLPDkN0RJB7cj92f/D34LwDEYth"
    "5OlHoSygekk+XC/BZVe7XoKqBY/LDpmbI0IBVILjMNo7JH72+zG8+8t7kIh5HhF+pZ/gbq2NWVhw3bnoeMty6IO5+a32A4DDEG0m"
    "rK2j2H3t76DHLVBUgoSB7P5nYU2kISQFqOhc9yCgLI14by9OuepT3pHjoQI4nPAfDFRiVTTayAlkDFUgB45yhf/edRm87bO7ICVB"
    "yIDXEgQ9kkfXe89C19+tgB6ugvArBiUNOLvS2H3t76D2ZEBxA+xoCGHAyYy5GX8lUC0TuTAVeMF5f4WFF78F9oQ7FWjcc/V+Vuf2"
    "ysPcoPusrL+Dg/XTilKCtcIYUGn/cBSjPSXxyMYsrl61A3mHEYtQwL1+AX0wi453nIYFHzrH3eqb78ipGRQzoEby2H3t72BvH4No"
    "M8GF9QgiKDsLOzNazExWredU8BI8peAl6J043ChHoWremx9aob9PEqznh/kASlCKkUoIbHnewutu3InhCR1Y+KeE9X78fOgJuyRj"
    "Q4VoBkUkdM7B7g/+Hvn1ByDaI5PCDwBEYKW8UGRUywAoXtv1Ekxi2TU3u1mMWDd0pKuXAVD4rlYpQE3yAfC0izf6NsuXySOS/HUV"
    "pYF4TGD3sIPX3bgDz+61kYyLYCN/Iaz3FSeg99PBw3pnRDPIEGDN2PPhe5F7aDdEZ9SNGiyFXXNdGKb731Uetgpegj2nnYPFL3vf"
    "tBOG6t3FMe11bZjsO43vz35KYbdrctJSHt85AVF68dq3fXXwORnSGohGCONZjatu3Im/PJVHR5uEE2S7rzSs9/MlYb3z8e9ndtcN"
    "TIG91w0ic+/zEN0xN2JwCq7fvjCiMGJt4Bo57ZEUsDMKJ17+bgxvvg8jWxuQS7Da1s1c8LTfTc4Uj0WfdfZnAUzvTY1OfhYoUdrc"
    "FPz7lWa88dM7cf+TWXQGFP5iWO/KaoT1ejAAIlDMwL5VazF+z1OQ3dEZhB+e/CsYiQ5E2nrg+gHVRAVMegm+4RYY8dTkicP1fJ71"
    "mpSXfl8rlJnqXgYfCkCVaBNutJVTucU4A+wN0JEI4V1f2I1f3T+Bjk4JO8jIXxrW+7WXuGG9lpq/8DNDpEzs//yDGPvRJsjuOHgW"
    "12MCQTsWEj2LEEkl3bWBGm3XTfESvPKjsHPj7onDdXuePNWyq5UymPJ9dbq3qvR1nvKrHEesH0DBvz+RELj2q3vwg1+PoqMzYHDP"
    "IWG9sfmH9QKAZojOKA589RGMfmu9a/bPtRhBAlrZaF98Bow41dwkn/QSvAZHnXNFfXMJBng8RxyHtE35fnDE5gPQDKTaJD7xzX34"
    "v3cMu8IfcOSvelgvACiG6Iph+N+fxPBtj0F0Rt3KzomGMCLoXvJi5EbGIQwDtd8oJ7BmLLv6Ji+XYP28BA+nflhtgsqqLwVw6NSr"
    "0bZOIJvoEBwFtHVI3LbmID773f1o75BQQYR/hrBeHrerJvyj39+AA198CKI9MmmqzAYRlJVD8qgTsWDZedi05gvIj+6DMFFbJeD5"
    "BsR7e7FkYDXUFC/B2j5TKn5HrZncS2qNEnyZpLwC0NO1Sivp30MVgeO4/v3f/+Uo/vG2vUglA/r3HxLW21eVsF52NGRXFGM/24r9"
    "n74fImlO3sIckJBQ+QyOPvdKJHqTGH/ucWy+42aICJUcMFobSr0Ej73krbAnDoJk7acC9eyB9VpvrA5TNy79ZAQprwAK75h7UG1K"
    "uPDDq7ftCf8v/jSOd31xF6IRcr3m/N7XjGG91Ynsk10xTPz2Wez75J9AEYk5DxotqY+284gtWIjjLnkznCwj0taDnWt/hJ1rfwUz"
    "JcGqxusBRS/B69F27GlQuTqdOFynvtgip4JNUiqnPh6DLwvg0Cu3BqXamxWju11i7eNZvOkzOwG4239lp9elF2MG5xR6P/NiL6y3"
    "WjH9MWTv34k91w26VrQhfPU8EhJOdgwnvPQ9SB7dB2W5SkNE4th8x2qkd+2CjIraWgKlXoJvuMUV/ppaHvXuh63V56fUtyoWQJHW"
    "MoaAyaZwNINSEo9tzeGqm3YgnWNEzACJPL1b1xkbPTe9CO2vOcUL651nmzgM0RFF7ol92P2he8GWBkx/WomEATszigXLLsYJL30H"
    "nLQCSYBZQ5gRWKN7sfGHN3nz8tp24kkvwbNx/MuvhZ0eAUTAMJOQKuI976pYAMXrtZomdFEaaE8I7Nlt4XU37sDeEYV4NIB/PwHF"
    "sN4Pe2G91YjscxjUZsLaMjwZ1hvzKfwkoJ08zEQnTn/rFyBMc8oJtgWnoH2P/wrP/O93EEnKOmwNTnoJdi27CCozWp+pQMjsVNcC"
    "KKHRi53+FkTBzIiYwM4DDt5w0w48vdNGKhHQv78Y1nsmuv6+ymG9O9PYde3voPa5Yb3wsxNBBAZDWTmc8fZ/RvsJJ8PJKi9llwcX"
    "lEA7tt39RQxv3QQjLt1DSWvGpJfgqW+4BTLe5uYS9OpTzedat7Go9PtaocxU9zL4dAUuvRqDqbkLiMHM0BpIRgmrv70ff/pLDm1t"
    "IuBev4A+mEPH25djwYdWQo9VMax3OIfd1/4WzjPjoKTpT/hBICLYmVEsf9MtWHjBy2FPqENX3sntESQMaCuHDT/4OFTeqmqegBlr"
    "V+IlePJrPuadOCzB1ewzbjOg9oe+crHfN7o/++73XpuU/ixHgCnA1HZp5lK6fmbbNsbTCvFIsMM7yCCogzm0DyyZDOsF5rcUUgjr"
    "zdrY/YHfI7/hIES7X+F3BcwaP4glV34UJ73i7bAm1MweeAULSCvIeBtGtz2IbXd/DWZc1NgKKPESfMk1OGrlFZNRg1V8vuA6rUh5"
    "7djo/hykXYBgbRN4CjDd6mjGUkA5Dpg52Go/UHJa7/FVDeuFIcCKsfufBpFbtweiIzqrf/90SBqwxvfj+Je9F0uv+iCstAKJ8o+P"
    "lQMz2YVn/vffsPfxP8NM1HoqAABuLsGlV68qOXFYtNwsoPS7WqUExX9KMO9nq+wFaOUUt78C7eUWw3oXou/zl7gCOt/gGi+slwyB"
    "vR/9I7J/eB6ia6aw3pkhacAa249jL3oLTn/LKnfODwH/GokAImz44SeQHx2DMII4P1SA5xuQ6O3F0qtv9tyEq3XxSrt6cOrncVgd"
    "CvUNUuMAx4MXVECzMtkxtHKgKxjlpob1Xlr9sN6b1mL8F0/PHtY7U52kAXv8AI4655VY8a7/D8rWAIvyCqnkQTFryEgCmV1bsPkn"
    "n627l+DCS94Oq+glWM0eVNve2Lx9fWaK9Q2g3P0rgKYe+gs3TNC6QuEvhPUuq1FY72cfwNiaTZBdsUBmvz0xjO6lF+Psf/gXAAKs"
    "yZ81Mu0trB2YqS7sWPsD7LzvHkTq6CW45HXXo+3Y06Fy6fDY8XoQoMv6PxhkiuXV6JnOTDMfgtYKOtAen4ck6FqE9bLr6HPg1nUY"
    "/fZQ+bDeEkgacDKjaF+8Audc+03ISBzaZlBZ4efid09vI2aGjCaw+Y7VmNi5s25egpFUEqe+8bMAkbf+UHBOmscsty4+ul6/b3j/"
    "DlCKzeSvfXwoAD3tWk2mvb3quMJfwYhWCOvtibthvQurGNbbGcXwN5/A8Dce9xnW60JCQmUnEO85Hiuv/S9E2rqgLO1r0Q/A7MLB"
    "bthwfmwfNvzwRtTLS9D2vARP+OsP1Dd3wJEMA1U5HLR4LTSd6LsVIoC1rkz4S8N6v35ZdcN6u2MYvX0DDnzpYX9hvR4kJJSVhdm2"
    "AOd+4FtI9B4DlfW34l/KbF/FWsFMdGLf47/GM7/9rjsVqJuX4HvQvewiOJnReSmBpuuHTURQWQ2YD6B5mp69bTnWGqpC4S+G9d7a"
    "j9iZfVDVOK23ENb70y3Yf/OffYf1Aii6+MpIHCvf919oX3wKnMwMjj5l8PTi7H8veAne9QWMbNsCI1YvL0GJU9/oeglqxy5Ty9mY"
    "31mPwb+tefq8H8ibAxB8eQK3oAXArvATEZi5MuEnAhSDtRfWe+FC6JHcvM/sg6MhumOY+PUz2PfJ+1zffj9hvQBAAqwdMANn/8M3"
    "seDUs2BPOBXF15c17JkhvDwCG77/MSjbBgku96l5MekleCJOec0n4JTmEgxInWb/AJp87XsG3Hq7asBPb265WAAGg+AJf6Azuj28"
    "sF6dtdH7qQuQfNli17+/SmG9mft2YM9H/gASBEh/Yb2uktBQVg4r3vlVHHXORbDGFUhWEFFXOtOYYx2NtYYRb8fwlj9j2923uQ5C"
    "lSygBqDoJXjZNTh65athpYddBVdJX0DJfdaKQls2wdpekHYpvKiKBaCLFyxt9cbcnSv87ve7c/6AXYDcH3rCRu8nz0f7wBL3wM55"
    "C78X1vvYXuz50CDY1oApfC76EQgEJzuO5W/5Ao675FWwxiob+Q+lTHsqB2ayE9t/8y/Y+8SDMJN19BK85lOIL1gIZeVKFiN993AA"
    "9XBK45LfrVBmqvvcVNDzAwpdlWBMmmNKqSnhr74ohvXmseC6leh422nQw3l3lJ4Pyg3rzW8exu4P/A56wnIz+vhe8RewJg5iyes/"
    "iRNf9iZY405lI3+R2TrEbO91FdDGH3wM+bFxN4y/bl6Cn4F28q1nZzctwZ9bSwRsl95WRcIPTIb1/sOZ6Hr3mdAj+eqF9e6YwO73"
    "/w5qf84N6/Ut/K5//4mvuBZLXvPe2YN7AhC4ZVhDRBOY2LkJm+/4XO19A4BpuQTf5p44XIHSa8xQdHgRwBW4+KOuFL6RMA/hL4T1"
    "vm05Fnx4JfRYFc651wyKG1AHcth17W/hPDcOkfQZ04/J4J7j+t+B5W/6pBfTH8S/f5brFl4EaSblwEx1Y8efbsfOtb9wpwJ18xL8"
    "CNqOOx2O71yCPOVXzeBDXrQOAaoczBW4pO3rMZspbMEQAKV1RcJPBkEP59B2VWlYL807so8iEjptY/cHfgdr4zBEuzn1tN656iQN"
    "WOMHcPS5V2LFO78AZfn07/dBsQYUsL1ZQ0Ti2LTmJmT27G6Al6D/E4cne0YNIfd7vP+3RAGAyajVaq8BlAh/PY45KxV+rXVli1Ne"
    "WG/qFcej7+YLwfkqhfWaAqw0dn/oXuQe2Rs4rNeeOIgFp/bjrHd/Dazh37/fz/ULLzhge3uHi+ZH9mDDD25ydzFqLGaTXoLnlHgJ"
    "GgC47BF49TiDpNT6bIVSidHizw+AJ3VMQThr+j/Pa45A0FpXFNxTDOu9eCH6Pn+xa5pXJaxXgARhz0f+gOyfdgQL6xUCTmYUHcef"
    "jZXv/yakGYN2/Pj3B6hi8Uew5wTADRhKdmLPYz/H9t98t665BE965XuxYNnFRS/BuWuK2ocCMBcTYdW8v1fpf5O9iH23j6+04FO7"
    "Z53mRISKhX9KWO+tl4KkcLfmqhLWK7H3prVI//IZyBmP6p6lTiSgbQuJvhNwzvv/C2aqI5h/f+DKVobWCma8HVvv+hxGntpcXy/B"
    "N33WPW7csUFlzbQabwO25M7E5HN3q1/lWIDpr2uCN8dgzZWN/NNP601UKawXDJE0sf8zf8b4TzZDdMXAPoUfANwjvDLoPuV8pF5w"
    "NJysUyPhL1Dhk2I3l6DKZzD0vTp7CZ5wIk557cdh58YBP9mOalYjFOf+rcQhcqr9n/szB7V2DPGYuvpXsfAfclpvtkphve1RHPjy"
    "wxj97oZAYb2lCCnB2qm62V9VCG6sQLwdw1vux7a7v143L0FrQmHRZW/E0SuvnJJLMKRCRJUsgCmSWdMlTBdVybyzlqf1dkYx/K+P"
    "Y/hfnwgU1luKEOQJffUW/GaGp76s8FmwchBJdmH7r26rm5cgeV6Cy96wGrGuYydPHJ5SP67DAkAB70sbvbwf6NmVtE01zwWofZN7"
    "C1E8Pf+AD2oW1usG94x+ZwgHvrwOoj0Kv2G9U6onRMWBLw2HCBu+/9G6ewkuu+ZmKCt/6FoAtWYz1otJHe6vlXwrgKkhmLUyARg6"
    "6OgqCLDV5Gm9K3qrdFovQ3bFMPaTzdh3ywNeWG9w4ScqjPwzmDo1Z37PhFlDRhOY2LkRm37y2fp6CZ7/UhzX/3ZY6dJcgsHbvzo0"
    "elj3L0OlW6V+8G8B1KHtdWD/fgIcDWbgqC/1V/e03u4oxn+5HftuXAsRM+A7rHdK9QhClHo1eP8+v9qVhad937yupRxEPC/BHWt/"
    "UdcTh5e8/qPeicNpoOTkI7f96qMJWs3a8FS37/dX4AlY3SaZYlcEGf1d7xWwpdB3y0VI/dUiqGqF9XbFkPnjDuz9yB/czMCSApu+"
    "RPCEf7K6LtUTzhlhbxSooqnOzJCRGDb9+Eakd9fZS/BNn0chXLoRNOlS7SzwlF9+CCYtNWiNorNFBR1WZx303HgB2l5zsnda7/yE"
    "nwthvY/swZ5/utd17fUd1juJK/yz16Ue+9dczS8pegnuxoYf3FhXL8He01fihL/+oLcr4HoJ1nVUbkUTIMDjCeYKXIMFoKIXWpBL"
    "S4Iet9H9vrPQ+dZToQ9U58BO2W4iv/Egdl/7e+i0HSistwBhZuGvWz/imhhqbi7BZCf2PnoPtv+mvicOn/Sq96J72UWws4VcgvVb"
    "C2BqQQ1QUAI+8Hk2YG0awc3rV6ipX5XlCn/ikoXo+oczoYarFdZrwn52HLuv/R3UwWBhvaWQV5dDLJoSd+qaU6OvcbMIdWDLnZ/D"
    "yLb6eQkKw8Cpb/48jFgbtHJQN8O8HgtftcKnzDY8H4A7lffvuwxmkCR0vuM01xTVPL/+oLyw3v0Z7Hr/7+DsmAAFCesteS2Em1zD"
    "zVk4jzrNi1r2WO1mLc5nMPS9j9bNS9DJKnSecBJOee0n4WTHDjlcpFVltBkIoAB42uvqbFsEW7EgcF4hcnInYmf2QmfmudevGRST"
    "0BMWdl/7e1hbhiHaApzW6+kf5oKjD6YJ//R7rRelbVvdbSbXS7ANB7esxda7vlZXL8HFl70RR618tbseII3ibdZe11a7HWtVSuvr"
    "j4pSghWcseZbgICzCwLY0jBP7oRIRSoy0YsUwnot5Yb1Pr4vUFivEIBlM6ImIR6lQ+5pxnutvLYVUL3nNP0+oN0Th7f/+jbsfeKB"
    "+uUS1IxT3/hpxLqOgbJy3mJk7alFO9bm2QTvYcGPB+fqxS+j8DtIvZlhdEUr2pefchOFsN4b/ojsfTtdF1+fwT1CAPk8o7tN4qvv"
    "70M0IqC9kX/Oe52uqGtA6eVrFnfOKHro1ctLsOAbkOzrw7I33OK6CXNtPQLY+1mrdqzFcwnaGgGjAflQ1+x5FBRfB6g0AWrCntRE"
    "QWH3IhQ3sO9T92Pi18HCegUBygsu/N6NL8BlZycwkdUQNNkZZ73XOq8LVOs5zXgvrCGjSUzs2IhNa26pm5egNaFwzPkvx3H974CT"
    "HSkq3Zp8n/ezVu1Y7VKoL1B4TlUJBtJT3YCrqm4DXoy9raFnx6HzCoFX2hgAM0Sbif2f807r7Y76Dut15/hAPq/xHzccjcsubMO+"
    "EeX5HnGZ2ynaaTWlnjqGlXvi8PN/+i52rP1F/U4cthgnX3kD4j2LoR0E7we+qYPJVnXc+vo9GqQp8gH4fn5eIk5r40HY20bck3eC"
    "rANoN7LvwFcfwei31rvZfAIs+BEBExmNr33wKLz5rztgjSgYRtCDqmrboerdXZkZ0oxj448+gYld9fESZEUwogmYyXbPQbA2CqA1"
    "Rb/0dbXCgb2Rc9o/VKFMr7YPpHuwx+j3NoBiAfbqHffAzpF/fxLD//JY4LBeIYDxMY3P/G0P3ntVF0ZHFIxDMlmXu9d6Udq2NS6s"
    "IcyCl+An6uIlCG+3JZDreGBq0d9rXQq/AvRrX+8qrjIEu3gQfFsByjXhx+/chom7t0H2Jtz5+2ydQbPr5dcbx+jtG7D/iw9BtPk/"
    "rRcADAmMjSh86A1d+MTbezA+qiHrtAIdmMJ91WG6UfxKb1dgz6P3YPtvvl2XqcDU5dUa0lJmAE/Kqc96+7YA6tiffEGmwN6b1mL8"
    "rm0QPfFJa0Cx68PvmfYiaUJ0RDD8709g/833BzqtFwAMSRgdUXjnqzrxz+/rQ3pCuwmGpvW9pmmeOsnFdFz/gA5s+dnnMLx1M4x4"
    "PbYG60CT6vnZCOq82HBPwIokh+FG/dkae64fxN5P/An29lFQ3IDojEJ2RSE6IgAB2XV7sOt9v8X+zz/kKokAFqphEEZHFV5zaTv+"
    "7bqjkcu5H5zJWinbT+qlIRox4/C+WAgDKp/G0PduqIuXYM1pweoH1f8+z2NiT24Y5bO1VgADRAwOsk+mGTAEyCCMfX8jJn6xHbEz"
    "ehA5sQMiZcLZl4W18SDym4bBlqrA7HeF/9KVCXzn4y+AUuxu/82oMtmdk84xj2GvN9WjPzWq3zJ7uQQ3r8XWu76KU6+5zjvluBoH"
    "nTaCamZWqA8lSd59ZfMsrwBq7+Dlus+CgisBb14iOqOArZC5bycyf3je7f0EkClBcQmKBtstMCRhdELhnGUx/PhTxyBmEnIWz32O"
    "KM1tXBT+Vg+LcsqSTZ0prAc8/auvY8GpF6P39PNhZ2qV/rz2NKodq4GfFvd9IiNPeVHdJiHvkgUrI7CYKAYEQaTMqYLImHTW94mU"
    "hImMxinHRvDTmxeiu00ikysj/IUFcZrDwiijIKpJcRRo1MINCRAIQ9+7AS/62D0wYkl3XaZZMyGXo9kWwGZlWvtWMylosevWKD66"
    "YLhU3EcKwl66CBhwm0gKIJvT6OuS+OnNC7G4z0Q6q/2fID7H100uzNdzMaBBFHIJ7tiITWs+UxcvwVrRKqIPoEQ2q7gNeMhjq1GL"
    "TDGRG5CEQQogbzNSMcIdn16I00+MYiytYASJNmyKAa45uix7Jw4//8fvYMd9/69OW4NHONMevR+V23QTM0ahUvXryFIAluN+7w9W"
    "HYMLVsQxNh5Q+IFmkb3mwTtxeOOP6+QlGDIFP8Jd9j1T31DbHl4QN0ZhKlB7iTIkIZvnovC//PwUxkaDCP80T6yy7z2CYIY0osgP"
    "78aGH3y8Pl6CVaUF9wFL6lszC6BWjozTl/+ohvGzRN5q/7jCgnaJO29ZiCsvacPYmA448k9972z3VfeOxLV9Tn6L9nIJ7n7kHjz9"
    "63p5CVaH0hl1K5RKKLsLUNQi3rdwDcMvC5TuBpC3HhBoe3AOBLnZe/KWxkRGoX9lEv/24aOxdHEk4MhfIGDO/3roAU+TNks+S2b3"
    "xOEtP7sF3UsvQMfiJXByzb01yIxi/oamWNrxARd/+KesAhCFa3qtMCmc9WBSB0/6CAR/HAWhZ2ZkLYadVTiq18Cqt/fgn67uhhSo"
    "bM7vMfmp2VuGDnlRQ7ztyKZxYmGAhAEnN46h26/HeTf8xBP+6TZfE0HuYFfwU2kFqCRw32+NfVkAU6fjjWuMQmqGyRwtPj5DQNZi"
    "OHkFSMKS4yK4+tI2vOvyThx/bASZCQVLo2LhL1KuLwd9MvOtS7MIv0fBS/Dg5rXYeudXcOobr4c15ri5/ZqQ4uyzuZqxDJOV9dub"
    "fbX+5By2IHwNomCFFOwzRkl9Dq0XAXAcxmmLI7j07AQuOSOBS89KoHuBATurMTbqQErycxT9nPgfaVuqN1Ud1u6Jw0//6mtYcOol"
    "6D3jfNgZ5WX5bS54hlfNTlFOA1h/Abt+k5hrJTJPYK/okuL+txQaubyDj7+5G1/5+AvwuktSSMQIYyMOLJthyGpFNvi9SpO0XyPx"
    "PL3Wf+96L5egl2apKWniKcpckP96+1QA0+zXRi93zmaeFWcGPCVbouUw1KjCyISGUq65X1WvVC6pzKz1rJc9yVNfNllhXcgluAGb"
    "fnxzC/gGcMPbLLAsFPtbeXzlBPR/uQZT2hAlDUNwffylqJ07uq/2CfBgaluRxlI4cfi5P34HO+77eZNuDbZAQ85A0GEm+ApMPTpx"
    "1aif+eYaHs3SLjztd/NROHF4w48+gc6TzkF8wdFQtgZRM24NNm87ToFp2vJ4tXICojSSrUUaA0A961pO89arJpOGT5M/J9YQRgz5"
    "4V0Y+n7zegk2X43mggNbAP6Tgpb+bhHqXd257I16dm9C8zgBzUUxl+Ajd+PpX/93U04FWm4JMKCs+kwK6o0nrdCrSqjfw/NnGwVN"
    "IF4pDNT9EJJKcf0DOrD5fz6D4a2bmiyXYGv1dwCTMupTVis8HLQ1qMuUpahx5/4e5joa5U2zFuEDZggpofNprL/9euhmyiXIaBkv"
    "wKn4r/NhPQWoC7P7Ic38vnrRQs+qkFH44Kb7sPnOr7iHjTbZVKBlCCirFfphtkrvqmPeeMakD8Jc76srrfKc4HkJduPpX34VPade"
    "jN4zXtREXoKt0o4VxMkE/5JWaYw6MaXN/bRNrduvVZ8PF/Mmrr+9FbwEm5HgbeVfAfDUl61Q6iIMfOh/zlyXesPl24gb/4ymFK0h"
    "okmM79iAjT/+dMO9BEuXdxreNj5KJQSeAlR6KndDqJP0lQ5Ssy6+evuANR/Q/NRllvc3BZ6X4PN/+DYWLL8Ux130yoadLTBleafZ"
    "2mkGuOSF3+r6jAac1DNE1GJWWaGytVNbkyfIz77RR15dap4Zu+T6LfWYSiAvl+CGH34MXSefg3h3Y7wE63mYSzWgYu4C/yNf8BZt"
    "ldZoBD7apj4WQGs/JGaG8HIJDt3+sab1Emw6KmiiwAogfAyHwjO8CpkfrpdgJ3Y3sZdgs1FJ7/NxNJguWQ1B60yIADRmtWK2tqlj"
    "mxUtwFZ5TjNTyCW4+ac3e7kElzYol2CrtOP0/l6NYCCB1lsNOdJplWCAcjCDpHvi8PrvXteAE4dbrQ156mBdlaPBSi/Sau1RZ5qj"
    "efhwGPyLuF6C7Ti46U/Y8rNbYSbqOBVowTYMWmWfrsCF4yZbrUXqVWf2TjguU5U6tR+11jZNWdz1gG489cuvYO/jf4aZNMC6Xkqg"
    "tdpyckeqBrsArdUUHgyMZ1X143EZICJk8hq2wxA0d6xf4ZwDlZ/w+lSV1yeIoB2GsrIAidZ8VnNA3v7pX26/rvZeggQ4uQnP6aVl"
    "vF4ABB/yyh8OSq4rVms1gwsBgGYcGHUVQJXlHySA0bR2jxbzoUpJCNjpEWhnskNXqzZEgLZt2JkR13++xUaucrBWMKJJTDw/hA0/"
    "Wl1DL0G3La2JA2BuzV2HYqpbKt9AZXcBSJMqWf5HIDejBsMggAhD23Ngp7pOOMwMSMLQMyXXnvM4cg0yIsgeeA7W+AgiqU73GPNq"
    "VIoBMoHc3l3Ij+wGGSbq43ZYX7joJfjf6D3tJTi2Jl6CAqyA9M5NAHmKtFXacXpcCsMu95Gy4xYLnWaeNmJRaxStGWaU8OcNGQyP"
    "OojI6nkxEhGgGPc+OjF1l2S24jm3ZA88h7FnnoCMcNVGMGYNaTJGtj0Ea/wAhDTgaoUydWrBwswQkTiGfvBRTOzaVWVLgCGkQH4s"
    "h+FtD0FGou61m+C+fRWPgreuZmTK3fGsCmCwr89dttJiH8AgQa4OqHVEQxULMxCLELbvtDD4WBrRuISec5T2h/auu+35PP70ZAbR"
    "mHCvO1d94OkBrbB73d2ud1vVBhaCVoQ9j9wNEtK1Tpqg/WtTNKQZQ35kF9bf/pGqegmy1pAxYHjzfcjufQrCiKNlIoG8QgSQcDUA"
    "g/YDk7I8E7NbAGu8RiG1nzVDClcDtI5n9FS++tP9cBztdZj5oTTDTAj83zsPYP8BG1ETviwLZgUjlsKuh36K0We2w4jNP/0VawUz"
    "IXBgw8PY++RvYMTbXOetwxhWk7kEn/rVfyGSktDKmf+FCdA28PSvv+H28hbzpWC4o78UgjQzmNR+AEVZnok5pgDL3buXYkRrxUII"
    "QcXkgA1XdL6L0kAyITC4bgL/cfdBpDokbKfyB2s7jI42iQceT+Nf7zyIREpAaZ/1YYCkCSczio0/+RQgAZD2pz1mgJlBElCWg01r"
    "VgFKAaCatmfTFC+L0Oaf3oyDm4cQSRrz8g/Qyka0TeKZ39+O/UO/hxFvA2vd+Pv0WQAAzCAQCyEEa8VQYsT9w/JZO9gcCmC1+yst"
    "RxicJ6Li6Mlo/HQnSGEG4gmBG/51F/7w0Dg6uoyKlIDtMNqSErv223jn559D3taQgooh0r7qohWMRCf2rLsLm37yZUTbDHeeGVAJ"
    "sNYg0jDjEutv/yQObrkfMt4GZt3w9q7PM2WQkNBWFo//+z8gPzriWlQVWALasRFtN7F//WPY+OMbYcQmrahG36fv9vDuhYQrpwzO"
    "w7ZH3H9dPeu9z7UIyACQX2DtA3CQhIAQAu7xoJWPoI1AM0NKQt7WGLjpGfzvn8fR0W2CGXAUl5U9pRmOYnR0GNix38aVH3saG7bn"
    "EI8JKB3suNSCEjATndh652ex6Y7bEElJkEFu5y2bXFSDlQMZFZBRiSe/sxrP/PabMJNdgHYC1QUt9hxLcZWAO6Wa2DGEh7/yVuTH"
    "9sNMuZZA+akVu85EzIh1mdg/tA7rvv4WsGN5acgaegxuYNzJOUMIUQibPphfIPZ5f571QZe7RwLAJ596/n3SMC/cv2+/SmcyUopW"
    "UwEuQhAsS8MQhM+9+2i85zU9MCMCuayC7UwqglKNakhCIiYASfjF2lG8/ys78NROC20pCaXm0wru+YR2ZgzHXvxWnHrNjYgvWACV"
    "B5StAS4ezD75CRIQJkFGgYmdz2Po+5/E7ofvhJnsbtk962pAwoCTGUXy6FNw+tu+iL4VF0ErQOUxQ7u49itJCSMGqLzCM7/9Fjb/"
    "z+eg7CxkJNZEacmDoTUjmYir3t5e6TjWfVs3PHgRpnbnQ5hTAfT39xuDg4POScvO+5YZibxjeHjYGR0dM0Tdo7GqhxDuVDmbVrhk"
    "ZQofeH0v+s9MoqfLACSV2FIAGEiPKzy0MYN/u+sAfjI4AhAhHnVH/mpAQsKeGEa87wQc/1fvwgte+Gokeo+FKGzle1UBAcoC0ru3"
    "Y+f9a/DM7/8b+bHdMBOd9XOLbWJISKh8BgDhmBe9Hov/6m/QsfhsGDH370XlTu5razyLfX/5X2z/9TdxYNOfYMbbvR2U1hR+AqC0"
    "RkdHu9PV1WXYlvXf2zY++E709xsYHJx1XuQvI5DmTQBgGrKlzKKZ0BoQBLS1G/jD42n84dE0Tjo2ggtPS2Lpoii62iSkIIymFbbv"
    "tnD/+gyefCoHZWskU9Jr6OrZP6wVzFQX8qO7MfT9T+Cp//c1dJ50LtoXrUCkvRfSTEBZE8iP7sHo049i5OlHYY0fgBFPhcJfAmsF"
    "GYmDwXj+j9/Drgd/ho7jz0Tniecg0XciIqleKDuH3PBOZPZswcjTj2L8+SGQNBBJdbsLfi0q/MDkQGEarkizxgYA6AcwOMfn5lQA"
    "RV8A4vWsNaRhCCLRylNHAG71lWKk4gJEhGf22Nj27MGpq5teXxARgXiUIGIGlC6/XlBRfZSCkBHIthicfAZ7Hvsldq+7ByACgYpp"
    "noQ0IaMJRNq8DjvfqLg5jcPWo+C0Y6a6wFpheOtDOLDxPoAAIndez1p5U6kYzESn+2+tnmjEe45EAoYhBWsN1noDAAwOzu4DUPjo"
    "XAgA+sTlKxcJlpsAxPbu3c+27VA19tMbjifwRK5VQJj0cyCvVTV7Hr5FW7zWkOtlOJOLMFfPe9C9Hup0T3Wm+FxLzoPnwj8W3qNb"
    "9NSfGWB3V8Q0De47qpfAnGWhl25b//Bz8GR4to/6efwEgE5a9sLHDNM8Y//+AzqdzgghWt8SmMpM0tAoCWmmurQ6R0BbEqC1RjKZ"
    "0D09C4Rj209s2/jQWd5f55TSsqt5/f39EoBm1g8QEaIR09UmU7KPHg4FPv/tSKtLq5cjoC09SyYaiWgiglL6QQDsye6clFUAhQUE"
    "Bn7NmhGJREi0WIx0SMjhjiBCJGISawYJ/BqYe/Gv+Lmy7xgc1ADgQN/nOE7GNE1pmAYfNvOnkJAWh5lhmAabpikdx84owp8AFGV3"
    "Lvxs6GsA4rlNj+4E9J+llIhFozpUACEhzQEzIxaNaiklGPzAsxvX7UKZxb8Cvjx6+vv7BQAoxT9jBuLxKFc3o01ISEilEBHi8Zgb"
    "uaz4p8CkzJb9rM/vEAD0okUrTjAS0Q1SUHTv3v2ctywSdT6uKSQkZBKtNaLRCPf19pBinVdZe9kzzzy+HdW0ANwLrRLPPvvE02D9"
    "eykNjsWiurig2uhV0LCE5YgsLrFYTEvDYGL+nSv8q3wJPxAgK3B//70CAEiIbzEzxeNxNzrQWwtodFOEJSxHXGE3+s81/5kgxH8D"
    "k7Lqh8CRrMuX96fyOr3RkMbC/fsP6IlMRsgWDg4KCWlVlNZIJZO6Z0G3cJSzIyoyy4aGhtLen9nPNYJILvf39xtDQ4MTYPwXESGZ"
    "jGvXVx0tkzg1JKTVKcgbESGZiGkiApj+c2hoaMJz/vEtjUGX8gUAfdJp5x5HijYKQfG9+w4gl8uROx0IeLWQkJDAkOf6G4vFuK9n"
    "ATRzliUv8+P7P52gtrvGwIDctv7h57TWPxRCUiqVVEBoAYSE1IuCrLWlkkpISZr197etf/g5DAxIBBB+wGc+gCmsWc4AiAzzc0o5"
    "b4rHopFYLMa5XI7cVEShJggJqR0E1hqxeIxjsahQjpMTRvTzAMiTzUBUsHq3WgMDYtvQn7cy4ztSGqK9LVmDw/dCQkIOhQEitLcl"
    "lZSGYOA7W9ev3QYMCFc2g1Hh8v0aBkAw6Wbl2GOxWEwkEjHWLZpLLSSkVdBaI5GIcywWE8qxx2DSzQDIk8nAVLp/pzEwILY++eDz"
    "DPoSCSHa21JKimqe0RYSEjIdKSXa25KKhBAM+tLWJx98HgMDgRb+SpmPQz8Bq2j58nsTeZ1+0pBy8ejoGA+PjIpWThoaEtKsaK3R"
    "1dmhOzrayVFqezLSdcYTT1yYBVYXfIMCMx9JZWCIhoYGJ0DiH5lBqVSSY7EowqlASEh1cbf9okilkszu0Rz/+MQTv0kDQ/NafJvn"
    "UL1GYWBAbtvw4J3Kce6Q0pCdHe1q0kU4XBQMCZkfrtePEAKdHe1KSlMqx7lj26aH73K3/dbMK6NpNWJ6BQAsW7byKAf0mBCyZ2xs"
    "HMPDw0JI2dwOAsUEkQ2tReM4kjduWuXZE0Erhe6uLt3W3gat1H6L+KxnN67b471jXuZ2NSbrGhigjRvX7WLN72aGaEsldTKZhNZq"
    "sqEbfXjanAeqHaGFm6AO4bOfuXh101ohmUoilUpqZghmfreb8GOAME/hL9x+dfBOIDlxyTlfN83I+23bcvbtO2BYtg0hqPk1bUhI"
    "M0HuUV8R00Rfb49jGKZhO9bXn9r8yAeAfgOY/bSfgF9TNQgDA2LlU0+J4XHcaxrmhfl8Tu3dv19qrUFV/aqQkMObwkGffT09KhqN"
    "Sdux13a14dJ1J56osWaNRpWG1GpLZfEgEVJ4UErjqEwmo/cfOODmEkBrHioaElIv3NmJKyW9CxboeCIhtHL2sEMv3LYteLBPOaq9"
    "Ya+BAfnU0Lpn4ajXKaXy8XgMXZ2dmplLppzc8ClWWMLSXMWViUKij67OTh2Px6CVyrGjXucKf/Bgn3JQNS82iTtHOWnJ2deQMH5I"
    "BDU+PiGGh0eIBBVvtEZfHhLSUhRkoSD83V2dnEqlNBhSa3XNts2P/Lia8/5SauSyN+j09/cb2zY/+iOt7feCSbalkqqrq5NZc3Ea"
    "0PCUSmEJSxMUFF5rRldnJ6dSKQUmqRznPds2P/Lj/v7aCD9QMwUADA66SuCpzY/9X1s514OE0ZZK6q6uTvdQkWb2DwgJqSfMxZG/"
    "LZXUABmOtj/81NZH/7W/v98YHKyN8AN1sMILN3D8Kedcb0r5RYBVOp0RB4eHiQGE5wuEHMkwM4iA7q4uTiYSGiCplbp+25ZHvlRr"
    "4QfqNA0v3MgJS855nxTiNiLibDbLBw8OC0cphMFDIUciWmsYUmJBd5eOxeOCmaEc531Pb33sG/UQfqCO63CFGzrxlLPeCCG/JYWM"
    "WvmcOjA8Iq28BSE9JRDODEIOZzyJ00ojEo1gQXeXikSiUmmVh1bvfGrLYz+ol/CXVKc+FKcDx599iYzQj6RhHO3YtjMyOmpMpDMQ"
    "RAAV1kNDQg43CGCGZkYqmUBnR4djmKahHGe3tnH1008/8sd6Cr9Xo/pSuMHjTj7tJFNEvyOlcSFrpSbSaRodHRNKe1OCUAeEHE6Q"
    "a/JLIdHR0a5TySSTkFI5zlqb8297buv6bfUWfq9ajcANYzz55JOjmtpuFVK+h4hg5fPO8Oiokcvm4PoLhAuEIa0Pg8GaEY/H0NnR"
    "4USiUYOZoZX6RszMf2hoaMgqyES969ZICSu6NJ68dOVVDNwqhTxWKUen02mMjo0LFS4QhrQ4WmtIKdHR3q6TyQSkNITS6nkC/ePW"
    "TQ/f4b2tqu69QWikdGkABAzIrZvW/SQqxQtZq++SEKK9vV309fU4bvYTDjMMhbQcWmswM1KpJPf19Trt7W2ChBDM6rtRKV64ddPD"
    "d3h5/AkNEn6gabxxJ82fpcvPfbXj6C9KaSxlVsjl8s7Y+ITM5XJUOAwxJKRZ0VqDiBCPxbitLaWisaghSEIpZ5NhiBs2DT18l/vO"
    "xpj802kSBQDArYsAoJZeeGGbOpj/R9b8ISmNLq0d5HJ5NZ5Oi1y2oAgKYRQFuOQyfqnkM4cTjCP73oHg9z/1c+6eFUNrBhEhFo9x"
    "WzKpY7GoFEJCKTVMgm6VHP3Kpk1rxwEUAnqaYpm7CZ9+iTWw9PzjNdkf0ZrfJqWZ0Fohn885E+mMzOZypJWGu3NYUAZN0aYhhz2e"
    "2DODGRBSIB6LcSqZUNFozHAF384IIb4t2Pjipk0PbHc/1xyjfilNqAAAAIT+fglvS2TJ6SuXKYs/CMabpSHbmBmWlVeZbBbZXE7Y"
    "lk2aXQ1MdOjeQagWQiphpn7Ent++IEIkEuFYLKYT8RgikagkIihHjUPQ7dLE1zb/Zd1GAIVsWQpN2BWbVQEUEG7uM1drLlly3gmO"
    "zv8tg95uGOZCIkApB3nLcrLZHOXzeWE7DrG3aFhQCCEhlcBAMVAHAIgEDNPgeCyq47EYRyIRQ0oDzAzHcXYQ+NuGiP7H5s0PPu1e"
    "YUB6J/Y07Sp2q0jHFEWwaNGiLmF2voqBtwiil5hmxARcZWDZtrLyFuctS1iWRUppmkxR7s3bCNNehxyplAalTk1lTxCCIKTkiGly"
    "NBLRkYhJphmRhuGeqWtZls3g3xNwu7ZH7nn22WeH3c82v+AXaLXuLzAwQFgzOY865pilS2U0crkQ4koCXmSaZpSEAGsNRzlwbEc5"
    "jsO2Y8O2HVJKCW+LhrQXljw1MrnprLSQmkCu8icCgZgIkFKyYRhsGgYbpgHTMMgwDCmlASJyR3rl5LXWf9aO+pmynV/s3LlpU/GS"
    "AwMSa1pD8Au0mgIoQBgYENOTI/Yed/JJESN2gQRdJiSdJ0icJKSMCXK3Dgs+BcwaWmsopTW7wEtSEKYpOEIgAoSQRIJIkBBCEISQ"
    "EFK400Z2t/S0dnJa8TbN/CBY/54V1j733PptpZeaqS+2Cq2qAEoR/f39YvDQRRaxaNGKxTD0coBOl0KcCmAJM04QhA4IERdCFN2N"
    "w7WCI4/Cgp7WmgFkGDzMmp9m1ptZ601KqyGHeP2eZzY9i6mjOvX398vBwUGNFhrtZ+Jw6/UC6BcDA328Zs3M2y29vctThoFu09S9"
    "MMxOIm4jiDaA4gBHmciod6VD6o1mYpEmzbuIaNgmjMAQw86YGNm1a11mpk8MDAzINWv2EtD6Qn+k4DkWDUg3p1rR7TIkZC7EwMCU"
    "PiNwGPebw/bG5qDEhXDA/d2/l/obV5+QBjAIAIN93pRxzfT8nCEhISEhISEhISEhISEhISEhISEhISEhIS3O/w+PLs/EmtqB+AAA"
    "AABJRU5ErkJggg=="
)


def _ruta_icono():
    carpeta = os.path.join(nucleo.DATOS, "notificaciones")
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, "icono_iqn.ico")
    if not os.path.exists(ruta):
        import base64
        with open(ruta, "wb") as f:
            f.write(base64.b64decode("".join(_ICONO_ICO)))
    return ruta


def _icono_ventana():
    """Pone el ícono nuevo en la ventana y en la barra de tareas (Windows)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        u = ctypes.windll.user32
        u.FindWindowW.restype = ctypes.c_void_p
        u.LoadImageW.restype = ctypes.c_void_p
        u.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_void_p]
        ruta = _ruta_icono()
        grande = u.LoadImageW(None, ruta, 1, 48, 48, 0x10)          # IMAGE_ICON, LR_LOADFROMFILE
        chico = u.LoadImageW(None, ruta, 1, 16, 16, 0x10)
        for _ in range(60):
            hwnd = u.FindWindowW(None, NOMBRE_APP)
            if hwnd:
                u.SendMessageW(hwnd, 0x0080, 1, grande)              # WM_SETICON, ICON_BIG
                u.SendMessageW(hwnd, 0x0080, 0, chico)               # WM_SETICON, ICON_SMALL
                return
            time.sleep(0.5)
    except Exception as e:
        _aviso_error("ícono de la ventana", e)


_PS_ACCESOS = r"""
$ErrorActionPreference = 'SilentlyContinue'
$sh = New-Object -ComObject WScript.Shell
$ico = $env:IQN_ICO; $exe = $env:IQN_EXE
$carpetas = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'),
              [Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('CommonPrograms'),
              (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'))
$n = 0
foreach ($c in $carpetas) {
  if (-not $c -or -not (Test-Path $c)) { continue }
  $fijado = $c -like '*User Pinned*'
  Get-ChildItem -Path $c -Filter *.lnk -Recurse -Depth 2 | ForEach-Object {
    $l = $sh.CreateShortcut($_.FullName)
    $esBot = ($exe -and $l.TargetPath -and ($l.TargetPath -ieq $exe)) -or ($_.BaseName -match 'IQ ?Bot')
    if ($esBot) {
      try {
        $l.IconLocation = "$ico,0"; $l.Save(); $n++
        if (-not $fijado -and $_.BaseName -ne 'IQNOVA BOT') {
          $nuevo = Join-Path $_.DirectoryName 'IQNOVA BOT.lnk'
          if (-not (Test-Path $nuevo)) { Rename-Item -LiteralPath $_.FullName -NewName 'IQNOVA BOT.lnk' }
        }
      } catch {}
    }
  }
}
try { Start-Process -WindowStyle Hidden ie4uinit.exe -ArgumentList '-show' } catch {}
Write-Output $n
"""


def _actualizar_accesos():
    """Una vez por versión: los accesos directos del bot (escritorio, menú Inicio, barra de tareas)
    quedan con el ícono y el nombre de IQNOVA BOT."""
    if sys.platform != "win32":
        return
    try:
        p = _leer_perfil()
        if p.get("accesos_iqn") == nucleo.BUILD_BOT:
            return
        import base64, subprocess
        env = dict(os.environ, IQN_ICO=_ruta_icono(),
                   IQN_EXE=sys.executable if getattr(sys, "frozen", False) else "")
        cod = base64.b64encode(_PS_ACCESOS.encode("utf-16-le")).decode()
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", cod],
                           env=env, capture_output=True, text=True, timeout=60, creationflags=0x08000000)
        p = _leer_perfil()
        p["accesos_iqn"] = nucleo.BUILD_BOT
        with open(_ruta_perfil(), "w", encoding="utf-8") as f:
            json.dump(p, f, ensure_ascii=False)
        if (r.stdout or "").strip() not in ("", "0"):
            print(f"Accesos directos actualizados a IQNOVA BOT: {(r.stdout or '').strip()}")
    except Exception as e:
        _aviso_error("accesos directos", e)


def main():
    nucleo.ordenar_archivos()
    import webview
    api = Api()
    with open(ruta_recurso("interfaz.html"), encoding="utf-8") as f:
        html = f.read()
    ventana = webview.create_window(NOMBRE_APP, html=html, js_api=api, width=1240, height=800,
                                    min_size=(720, 540), background_color="#0B0F14", confirm_close=False)

    def al_intentar_cerrar():
        # pregunta solo si el bot está operando; si ya se detuvo (o no ha empezado) cierra directo
        ventana.confirm_close = api.bot_operando()

    ventana.events.closing += al_intentar_cerrar
    ventana.events.closed += lambda: api.al_cerrar()
    ventana.events.shown += lambda: threading.Thread(target=_icono_ventana, daemon=True).start()
    threading.Thread(target=_actualizar_accesos, daemon=True).start()
    opciones = {"gui": "edgechromium"} if sys.platform == "win32" else {}
    webview.start(**opciones, localization={
        "global.quitConfirmation": "El bot está operando. ¿Cerrarlo? Las operaciones abiertas siguen en el broker hasta su vencimiento.",
        "global.ok": "Aceptar", "global.quit": "Cerrar", "global.cancel": "Cancelar"})


def arrancar():
    try:
        main()
    except Exception:
        anotar_error()
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, "No se pudo abrir la ventana de " + NOMBRE_APP + ".\n\n"
                                             "Si la ventana no aparece, instala 'Microsoft Edge WebView2 Runtime' "
                                             "(gratis, de microsoft.com) y vuelve a abrir el programa.\n\n"
                                             "Detalle en errores.log, carpeta: " + nucleo.DATOS, NOMBRE_APP, 0x10)
        except Exception:
            raise


if __name__ == "__main__":
    arrancar()
